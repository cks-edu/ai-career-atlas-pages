# Deterministic graphs versus autonomous loops

A workflow graph names allowed transitions. An autonomous agent may select an action dynamically, but your executor can still limit the states and transitions it accepts. Start with explicit transitions when the process is known; add model choice only where it is useful.

Represent transitions as a table. Reject an event that is not defined for the current state. Return the original state without inventing a successful transition. In a multi-agent system, each agent’s proposal still enters this same application boundary.

Task: Implement transition. Trace the valid route and an attempted shortcut; explain which decision truly needs a model.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Current state → proposed event → transition table → next state.
State: Status changes only through permitted events.
Boundary: An agent proposal cannot skip a required review state.
Failure: A draft jumps directly to sent without approval.
Control: Accept only defined transitions and reject the rest.
Observability: Record previous state, event and resulting state per run.
Blast radius: The workflow instance; shared state risks cross-run interference.
Trade-off: Graphs are predictable; dynamic loops need stronger budgets and policy.

Limit: An in-memory transition table is not a durable workflow engine. Checkpoint persistence and repeated side effects need their own contracts.

Sources:
https://docs.langchain.com/oss/python/langgraph/workflows-agents
