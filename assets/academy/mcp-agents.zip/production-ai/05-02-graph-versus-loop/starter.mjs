function transition(status,event) { return event === "send" ? "sent" : status; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(transition('draft','validate')==='review');
console.log("PASS: Validation precedes review");
}
{
assert(transition('draft','send')==='draft'); assert(transition('review','send')==='review');
console.log("PASS: Sending cannot skip approval");
}
{
assert(transition('review','approve')==='ready'); assert(transition('ready','send')==='sent'); assert(transition('unknown','send')==='unknown');
console.log("PASS: Approved work can proceed; unknown states do not advance");
}
