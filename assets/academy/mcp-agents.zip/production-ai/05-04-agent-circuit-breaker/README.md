# Runaway loops: stop before the next tool call

Two agents can keep asking each other to try again without advancing the task. Limit steps and resources before dispatch, and distinguish a stopped run from a successful one. A write still needs approval even when the step budget has room.

MAX_STEPS is the number of calls allowed. With stepCount counting completed calls, stop at stepCount >= MAX_STEPS before another call. Check the consumed budget too. A read may proceed from untrusted context; a write requires a separately trusted approval.

Task: Implement the guard. Add a deadline and a no-progress counter in your own extension. Record stopped versus completed as different outcomes.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Agent proposal → step/budget gate → trust gate → tool dispatch.
State: Completed steps, budget use and source trust belong to this run.
Boundary: Untrusted content cannot approve a write or reset the budget.
Failure: Cyclic negotiation repeatedly spends credits without useful progress.
Control: Halt at the call limit; deny unapproved writes from untrusted context.
Observability: Emit stop reason, call count, elapsed time and estimated/actual usage.
Blast radius: The tenant or account sharing the run budget.
Trade-off: Tighter limits contain loops but may stop useful long tasks.

Limit: A step counter is not a wall-clock deadline or a money meter. Add cancellation, timeouts and concurrency-safe accounting in a real executor.

Sources:
https://docs.langchain.com/oss/python/langgraph/workflows-agents
https://opentelemetry.io/docs/concepts/observability-primer/
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
