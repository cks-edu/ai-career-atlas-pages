function callToolWithCircuitBreaker(state,toolCall) { return "allow"; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(callToolWithCircuitBreaker({stepCount:1,maxSteps:3,spent:1,budget:10,trusted:false},{kind:'read'})==='allow');
console.log("PASS: A bounded read proceeds");
}
{
assert(callToolWithCircuitBreaker({stepCount:3,maxSteps:3,spent:1,budget:10,trusted:true},{kind:'read'})==='halt'); assert(callToolWithCircuitBreaker({stepCount:0,maxSteps:3,spent:10,budget:10,trusted:true},{kind:'read'})==='halt');
console.log("PASS: The exact step or resource limit halts");
}
{
const s={stepCount:0,maxSteps:3,spent:0,budget:10,trusted:false}; assert(callToolWithCircuitBreaker(s,{kind:'write',approved:true})==='deny'); assert(callToolWithCircuitBreaker({...s,trusted:true},{kind:'write',approved:false})==='deny'); assert(callToolWithCircuitBreaker({...s,trusted:true,approvedWrite:true},{kind:'write',approved:true})==='allow');
console.log("PASS: Untrusted or unapproved writes are denied");
}
