function callToolWithCircuitBreaker(state, toolCall) {
  if (!Number.isSafeInteger(state.maxSteps) || state.maxSteps <= 0 || !Number.isFinite(state.budget) || state.budget <= 0) return 'halt';
  if (!Number.isSafeInteger(state.stepCount) || state.stepCount < 0 || state.stepCount >= state.maxSteps) return 'halt';
  if (!Number.isFinite(state.spent) || state.spent < 0 || state.spent >= state.budget) return 'halt';
  if (toolCall.kind !== 'read' && toolCall.kind !== 'write') return 'deny';
  // approvedWrite is the executor-owned result of the exact-action approval gate, not a tool argument.
  if (toolCall.kind === 'write' && (!state.trusted || state.approvedWrite !== true)) return 'deny';
  return 'allow';
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(callToolWithCircuitBreaker({stepCount:1,maxSteps:3,spent:1,budget:10,trusted:false},{kind:'read'})==='allow');
console.log("PASS: A bounded read proceeds");
}
{
assert(callToolWithCircuitBreaker({stepCount:3,maxSteps:3,spent:1,budget:10,trusted:true},{kind:'read'})==='halt'); assert(callToolWithCircuitBreaker({stepCount:0,maxSteps:3,spent:10,budget:10,trusted:true},{kind:'read'})==='halt');
console.log("PASS: The exact step or resource limit halts");
}
{
const s={stepCount:0,maxSteps:3,spent:0,budget:10,trusted:false}; assert(callToolWithCircuitBreaker(s,{kind:'write',approved:true})==='deny'); assert(callToolWithCircuitBreaker({...s,trusted:true},{kind:'write',approved:false})==='deny'); assert(callToolWithCircuitBreaker({...s,trusted:true,approvedWrite:true},{kind:'write',approved:true})==='allow');
console.log("PASS: Untrusted or unapproved writes are denied");
}
