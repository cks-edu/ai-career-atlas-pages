# Idempotency, read/write isolation and approval

Separate read tools from write tools. A write needs authority bound to the exact action the person reviewed. Reusing approval for a changed recipient or payload defeats the review. A retry also needs an operation ID so it does not repeat an external effect.

This fixture compares an authenticated approval digest supplied by the application with the proposed action digest. Reads remain read-only; writes require a valid, unexpired matching approval and operation ID. Digest generation and authentication are outside this simplified gate.

Task: Implement approvedWrite. Write an ADR showing how authenticated approval and a durable idempotency record sit outside agent state.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Proposal → read/write classification → exact approval → idempotent executor.
State: Action digest, operation ID and approval expiry bind the decision.
Boundary: A changed payload needs a new reviewed approval.
Failure: An old approval is reused for a different destination.
Control: Require a matching digest and valid approval before any write.
Observability: Audit actor, digest, operation ID and rejection reason.
Blast radius: The downstream resource authorized by the write credential.
Trade-off: Review adds latency but limits irreversible actions.

Limit: A caller-controlled approved flag is not approval. A digest proves equality, not reviewer identity; keep approval records outside model-editable state.

Sources:
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
https://modelcontextprotocol.io/specification/2026-07-28/server/tools
https://docs.langchain.com/oss/python/langgraph/workflows-agents
