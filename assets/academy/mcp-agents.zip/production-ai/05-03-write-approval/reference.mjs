function approvedWrite(action, approval, now) {
  if (action.kind === 'read') return true;
  return action.kind === 'write' && typeof action.operationId === 'string' && !!action.operationId &&
    !!approval && approval.authenticated === true && approval.digest === action.digest && approval.expires > now;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(approvedWrite({kind:'read'},null,10)); assert(approvedWrite({kind:'write',operationId:'op1',digest:'d'}, {authenticated:true,digest:'d',expires:20},10));
console.log("PASS: Read and properly approved writes pass");
}
{
assert(!approvedWrite({kind:'write',operationId:'op1',digest:'new'}, {authenticated:true,digest:'old',expires:20},10)); assert(!approvedWrite({kind:'write',operationId:'op1',digest:'d'},{authenticated:true,digest:'d',expires:10},10));
console.log("PASS: Changed or expired approval fails");
}
{
assert(!approvedWrite({kind:'write',operationId:'op1',digest:'d'},{authenticated:false,digest:'d',expires:20},10)); assert(!approvedWrite({kind:'write',digest:'d'},null,10));
console.log("PASS: Untrusted approval and missing identity fail");
}
