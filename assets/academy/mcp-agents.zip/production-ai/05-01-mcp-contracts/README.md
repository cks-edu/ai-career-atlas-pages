# MCP servers: resources, prompts and typed tools

MCP standardizes how a client discovers capabilities from a server. Resources supply context, prompts supply reusable interaction templates, and tools expose operations. A tool’s input schema describes arguments; it is not permission to perform the operation.

Check that a discovered tool has the exact supported name and an object input schema before exposing it to your application. Negotiate the actual protocol version with the SDK in a real connection. This sandbox validates a synthetic descriptor; it does not run an MCP server.

Task: Implement reviewedTool and compare one resource, one prompt and one tool in your notes. Use the official SDK guide for a separate real server extension.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Client → capability discovery → descriptor validation → permitted tool.
State: Tool name and inputSchema describe the contract.
Boundary: A server-supplied description cannot authorize side effects.
Failure: A malicious descriptor requests arbitrary shell execution.
Control: Expose only reviewed tool names and object argument schemas.
Observability: Log server identity, protocol version and tool-list changes.
Blast radius: All operations exposed through the connected server.
Trade-off: An allowlist needs maintenance but limits unexpected capabilities.

Limit: Discovery metadata and tool annotations are not a trusted authorization boundary. Authenticate the server and constrain execution separately.

Sources:
https://modelcontextprotocol.io/specification/2026-07-28/server/tools
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
