function reviewedTool(tool,allowed) { return !!tool; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(reviewedTool({name:'lookup',inputSchema:{type:'object',additionalProperties:false}},['lookup']));
console.log("PASS: A reviewed typed descriptor passes");
}
{
assert(!reviewedTool({name:'shell',inputSchema:{type:'object',additionalProperties:false}},['lookup']));
console.log("PASS: Unexpected tools are hidden");
}
{
assert(!reviewedTool({name:'lookup'},['lookup'])); assert(!reviewedTool({name:'lookup',inputSchema:{type:'string'}},['lookup']));
console.log("PASS: Missing or open contracts are rejected");
}
