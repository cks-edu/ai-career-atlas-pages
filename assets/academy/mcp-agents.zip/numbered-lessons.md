# Multi-Agent Systems, MCP & Tool Protocols — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## intermediate

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

MCP: Model Context Protocol: a standard interface for context and tools.

input schema: The expected argument shape and constraints for an operation.

state graph: Named states connected by explicitly permitted transitions.

agent loop: A repeated propose/execute/observe cycle that needs stopping rules.

idempotency key: A stable operation identity used to reconcile repeated requests.

human-in-the-loop: A person reviews a concrete action before permitted execution.

circuit breaker: A control that stops further work under declared failure/resource conditions.

token velocity: Token usage per time interval, measured with explicit boundaries.

### MCP servers: resources, prompts and typed tools

MCP standardizes how a client discovers capabilities from a server. Resources supply context, prompts supply reusable interaction templates, and tools expose operations. A tool’s input schema describes arguments; it is not permission to perform the operation.

Check that a discovered tool has the exact supported name and an object input schema before exposing it to your application. Negotiate the actual protocol version with the SDK in a real connection. This sandbox validates a synthetic descriptor; it does not run an MCP server.

Discovery metadata and tool annotations are not a trusted authorization boundary. Authenticate the server and constrain execution separately.

Mental model: Client → capability discovery → descriptor validation → permitted tool. Picture the boundary as a checked gate between stages.

Boundary: Discovery metadata and tool annotations are not a trusted authorization boundary. Authenticate the server and constrain execution separately.

Worked example: function reviewedTool(tool, allowed) {
  return !!tool && allowed.includes(tool.name) && !!tool.inputSchema &&
    tool.inputSchema.type === 'object' && tool.inputSchema.additionalProperties === false;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract mcp-agents.zip, install Node.js LTS, then open production-ai/05-01-mcp-contracts.

Tools for this exercise: JavaScript · local isolated workbench; MCP SDK, LangGraph as documented optional extensions

Course tool and framework map: MCP SDK (Open source / open protocol); LangGraph (Open source · optional paid services)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement reviewedTool and compare one resource, one prompt and one tool in your notes. Use the official SDK guide for a separate real server extension.

Terminal folder: production-ai/05-01-mcp-contracts

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Check that a discovered tool has the exact supported name and an object input schema before exposing it to your application. Negotiate the actual protocol version with the SDK in a real connection. This sandbox validates a synthetic descriptor; it does not run an MCP server.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement reviewedTool and compare one resource, one prompt and one tool in your notes. Use the official SDK guide for a separate real server extension.

Expected: A reviewed typed descriptor passes

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Unexpected tools are hidden; Missing or open contracts are rejected

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A reviewed typed descriptor passes; Unexpected tools are hidden; Missing or open contracts are rejected. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Expose only reviewed tool names and object argument schemas. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/05-01-mcp-contracts/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Client → capability discovery → descriptor validation → permitted tool. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. What does an MCP input schema establish? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A server-supplied description cannot authorize side effects. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: What does an MCP input schema establish?

Interview: What does an MCP input schema establish? Explain the decision, a failing case and a production limitation.

Quiz: What does an MCP input schema establish?

The argument contract; permission still needs enforcement.

That the server can be trusted.

That every proposed write is approved.

Reference: The argument contract; permission still needs enforcement. — Schemas describe shape. Server trust, user scope and action approval remain independent checks.

Sources:

MCP: typed tools and user interaction: https://modelcontextprotocol.io/specification/2026-07-28/server/tools

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### Deterministic graphs versus autonomous loops

A workflow graph names allowed transitions. An autonomous agent may select an action dynamically, but your executor can still limit the states and transitions it accepts. Start with explicit transitions when the process is known; add model choice only where it is useful.

Represent transitions as a table. Reject an event that is not defined for the current state. Return the original state without inventing a successful transition. In a multi-agent system, each agent’s proposal still enters this same application boundary.

An in-memory transition table is not a durable workflow engine. Checkpoint persistence and repeated side effects need their own contracts.

Mental model: Current state → proposed event → transition table → next state. Picture the boundary as a checked gate between stages.

Boundary: An in-memory transition table is not a durable workflow engine. Checkpoint persistence and repeated side effects need their own contracts.

Worked example: function transition(status, event) {
  const table = {draft:{validate:'review'},review:{approve:'ready'},ready:{send:'sent'}};
  return table[status]?.[event] || status;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract mcp-agents.zip, install Node.js LTS, then open production-ai/05-02-graph-versus-loop.

Tools for this exercise: JavaScript · local isolated workbench; MCP SDK, LangGraph as documented optional extensions

Course tool and framework map: MCP SDK (Open source / open protocol); LangGraph (Open source · optional paid services)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement transition. Trace the valid route and an attempted shortcut; explain which decision truly needs a model.

Terminal folder: production-ai/05-02-graph-versus-loop

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Represent transitions as a table. Reject an event that is not defined for the current state. Return the original state without inventing a successful transition. In a multi-agent system, each agent’s proposal still enters this same application boundary.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement transition. Trace the valid route and an attempted shortcut; explain which decision truly needs a model.

Expected: Validation precedes review

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Sending cannot skip approval; Approved work can proceed; unknown states do not advance

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Validation precedes review; Sending cannot skip approval; Approved work can proceed; unknown states do not advance. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Accept only defined transitions and reject the rest. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/05-02-graph-versus-loop/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Current state → proposed event → transition table → next state. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A model proposes send while the graph is in draft. What should happen? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: An agent proposal cannot skip a required review state. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A model proposes send while the graph is in draft. What should happen?

Interview: A model proposes send while the graph is in draft. What should happen? Explain the decision, a failing case and a production limitation.

Quiz: A model proposes send while the graph is in draft. What should happen?

Let another model vote.

Reject the transition using the graph contract.

Rename draft as ready.

Reference: Reject the transition using the graph contract. — The executor controls legal transitions. Model confidence does not satisfy a missing approval step.

Sources:

LangGraph: workflows and agents: https://docs.langchain.com/oss/python/langgraph/workflows-agents

### Idempotency, read/write isolation and approval

Separate read tools from write tools. A write needs authority bound to the exact action the person reviewed. Reusing approval for a changed recipient or payload defeats the review. A retry also needs an operation ID so it does not repeat an external effect.

This fixture compares an authenticated approval digest supplied by the application with the proposed action digest. Reads remain read-only; writes require a valid, unexpired matching approval and operation ID. Digest generation and authentication are outside this simplified gate.

A caller-controlled approved flag is not approval. A digest proves equality, not reviewer identity; keep approval records outside model-editable state.

Mental model: Proposal → read/write classification → exact approval → idempotent executor. Picture the boundary as a checked gate between stages.

Boundary: A caller-controlled approved flag is not approval. A digest proves equality, not reviewer identity; keep approval records outside model-editable state.

Worked example: function approvedWrite(action, approval, now) {
  if (action.kind === 'read') return true;
  return action.kind === 'write' && typeof action.operationId === 'string' && !!action.operationId &&
    !!approval && approval.authenticated === true && approval.digest === action.digest && approval.expires > now;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract mcp-agents.zip, install Node.js LTS, then open production-ai/05-03-write-approval.

Tools for this exercise: JavaScript · local isolated workbench; MCP SDK, LangGraph as documented optional extensions

Course tool and framework map: MCP SDK (Open source / open protocol); LangGraph (Open source · optional paid services)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement approvedWrite. Write an ADR showing how authenticated approval and a durable idempotency record sit outside agent state.

Terminal folder: production-ai/05-03-write-approval

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This fixture compares an authenticated approval digest supplied by the application with the proposed action digest. Reads remain read-only; writes require a valid, unexpired matching approval and operation ID. Digest generation and authentication are outside this simplified gate.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement approvedWrite. Write an ADR showing how authenticated approval and a durable idempotency record sit outside agent state.

Expected: Read and properly approved writes pass

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Changed or expired approval fails; Untrusted approval and missing identity fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Read and properly approved writes pass; Changed or expired approval fails; Untrusted approval and missing identity fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require a matching digest and valid approval before any write. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/05-03-write-approval/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Proposal → read/write classification → exact approval → idempotent executor. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A model edits the destination after a reviewer approved the original action. Can it use that approval? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A changed payload needs a new reviewed approval. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A model edits the destination after a reviewer approved the original action. Can it use that approval?

Interview: A model edits the destination after a reviewer approved the original action. Can it use that approval? Explain the decision, a failing case and a production limitation.

Quiz: A model edits the destination after a reviewer approved the original action. Can it use that approval?

Yes, the task is similar.

Yes, if it explains the change.

No; the changed action needs a new approval.

Reference: No; the changed action needs a new approval. — Bind approval to the reviewed payload, scope and expiry. Similar intent does not establish authorization.

Sources:

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

MCP: typed tools and user interaction: https://modelcontextprotocol.io/specification/2026-07-28/server/tools

LangGraph: workflows and agents: https://docs.langchain.com/oss/python/langgraph/workflows-agents

### Runaway loops: stop before the next tool call

Two agents can keep asking each other to try again without advancing the task. Limit steps and resources before dispatch, and distinguish a stopped run from a successful one. A write still needs approval even when the step budget has room.

MAX_STEPS is the number of calls allowed. With stepCount counting completed calls, stop at stepCount >= MAX_STEPS before another call. Check the consumed budget too. A read may proceed from untrusted context; a write requires a separately trusted approval.

A step counter is not a wall-clock deadline or a money meter. Add cancellation, timeouts and concurrency-safe accounting in a real executor.

Mental model: Agent proposal → step/budget gate → trust gate → tool dispatch. Picture the boundary as a checked gate between stages.

Boundary: A step counter is not a wall-clock deadline or a money meter. Add cancellation, timeouts and concurrency-safe accounting in a real executor.

Worked example: function callToolWithCircuitBreaker(state, toolCall) {
  if (!Number.isSafeInteger(state.maxSteps) || state.maxSteps <= 0 || !Number.isFinite(state.budget) || state.budget <= 0) return 'halt';
  if (!Number.isSafeInteger(state.stepCount) || state.stepCount < 0 || state.stepCount >= state.maxSteps) return 'halt';
  if (!Number.isFinite(state.spent) || state.spent < 0 || state.spent >= state.budget) return 'halt';
  if (toolCall.kind !== 'read' && toolCall.kind !== 'write') return 'deny';
  // approvedWrite is the executor-owned result of the exact-action approval gate, not a tool argument.
  if (toolCall.kind === 'write' && (!state.trusted || state.approvedWrite !== true)) return 'deny';
  return 'allow';
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract mcp-agents.zip, install Node.js LTS, then open production-ai/05-04-agent-circuit-breaker.

Tools for this exercise: JavaScript · local isolated workbench; MCP SDK, LangGraph as documented optional extensions

Course tool and framework map: MCP SDK (Open source / open protocol); LangGraph (Open source · optional paid services)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement the guard. Add a deadline and a no-progress counter in your own extension. Record stopped versus completed as different outcomes.

Terminal folder: production-ai/05-04-agent-circuit-breaker

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

MAX_STEPS is the number of calls allowed. With stepCount counting completed calls, stop at stepCount >= MAX_STEPS before another call. Check the consumed budget too. A read may proceed from untrusted context; a write requires a separately trusted approval.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement the guard. Add a deadline and a no-progress counter in your own extension. Record stopped versus completed as different outcomes.

Expected: A bounded read proceeds

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: The exact step or resource limit halts; Untrusted or unapproved writes are denied

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A bounded read proceeds; The exact step or resource limit halts; Untrusted or unapproved writes are denied. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Halt at the call limit; deny unapproved writes from untrusted context. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/05-04-agent-circuit-breaker/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Agent proposal → step/budget gate → trust gate → tool dispatch. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. With three calls allowed and three completed, should the executor start a fourth call? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Untrusted content cannot approve a write or reset the budget. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: With three calls allowed and three completed, should the executor start a fourth call?

Interview: With three calls allowed and three completed, should the executor start a fourth call? Explain the decision, a failing case and a production limitation.

Quiz: With three calls allowed and three completed, should the executor start a fourth call?

No; halt before dispatch and report unfinished status.

Yes; halt only after the fourth returns.

Yes; retry limits are optional when a model asks.

Reference: No; halt before dispatch and report unfinished status. — Check the next action before execution. Off-by-one budgets allow exactly the overspend they were meant to prevent.

Sources:

LangGraph: workflows and agents: https://docs.langchain.com/oss/python/langgraph/workflows-agents

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
