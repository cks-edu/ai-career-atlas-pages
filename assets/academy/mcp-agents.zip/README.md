# Multi-Agent Systems, MCP & Tool Protocols

Connect tools through typed contracts and bounded workflows.

Use the in-browser Practise workbench, or extract the course ZIP and install a currently supported Node.js LTS from nodejs.org. Run each reference.mjs from its numbered production-ai folder; run starter.mjs to see the failing initial checks. No packages or model files are required.

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Mental model: follow Path → State → Boundary → Failure → Control → Observability → Blast radius → Trade-off; inspect each lesson’s concrete version before changing code.

Tools and alternatives:
MCP SDK — Open source / open protocol. Implement reviewed tool contracts and capability discovery. Alternative: A direct typed REST API for a narrower integration.
LangGraph — Open source · optional paid services. Bounded state graphs and approval checkpoints. Alternative: A durable workflow engine or explicit application state machine.

Project: Build an independently changed learning artifact for Multi-Agent Systems, MCP & Tool Protocols. Connect tools through typed contracts and bounded workflows. Use synthetic data and make the tested scope explicit.
Draw the eight-node path and identify data, authority and resource boundaries.
Implement your own changed policy using the four lessons; retain valid and invalid cases.
Inject a declared failure, capture the result, repair it and run the regression checks.
Write an ADR with options, trade-offs, source/runtime versions, limitations and a rollback/recovery decision.

The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.
