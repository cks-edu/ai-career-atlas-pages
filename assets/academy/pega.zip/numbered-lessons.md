# Pega System Architect / Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Acceptance criteria: Describe an observable result that determines whether a requirement has been met.

Apply acceptance criteria in Pega System Architect / Developer: Use the concept to complete this role exercise: Draw case stages, assignments and completion conditions

Case lifecycle and stages: A case describes work moving through stages with responsibilities and completion conditions. Separate the business outcome from the screens used to collect information.

### Acceptance criteria

Describe an observable result that determines whether a requirement has been met. In this role, work through: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. The practical workshop develops this into: Draw the case lifecycle and acceptance conditions, then follow a Pega Academy exercise in its provided environment. Add a fictional missing-evidence case to the workbook.

Mental model: A delivery receipt lists what must arrive, not just that a truck drove.

Boundary: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Role application: A parcel passes through named stations, each with an exit rule.

A case describes work moving through stages with responsibilities and completion conditions. Separate the business outcome from the screens used to collect information.

Worked example: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review.

Shared foundation example: Given an empty title, submitting a request shows an error and creates no ticket.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Pega case management and decision rules (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Pega System Architect / Developer: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review.

Predict the worked case

Read this case without running a tool: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in acceptance criteria.

Connect the concept to the role

Apply this rule: Describe an observable result that determines whether a requirement has been met. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies acceptance criteria to this case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Acceptance criteria; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with acceptance criteria. Use the glossary below, then write your prediction for: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Pega System Architect / Developer role interview. Explain acceptance criteria using this case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate acceptance criteria to a system or workflow you know. Explain acceptance criteria using this case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Turn “make it easier” into a measurable task outcome.

Interview: Explain acceptance criteria using this case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. State the evidence, one alternative and where the mental model stops.

Quiz: After the Case lifecycle and stages rehearsal, check this foundation: A requirement says “make this workflow easier.” What makes its acceptance testable?

A defined user task and observable result, reviewed with the relevant stakeholder.

A count of implementation files without a user outcome.

A statement that the chosen tool is widely used.

Reference: A defined user task and observable result, reviewed with the relevant stakeholder. — Acceptance criteria describe observable outcomes. Stakeholder review is still needed to ensure the outcome solves the right problem.

Sources:

Pega Academy: https://academy.pega.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Case lifecycle and stages

A case describes work moving through stages with responsibilities and completion conditions. Separate the business outcome from the screens used to collect information. In this role, work through: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. The practical workshop develops this into: Draw the case lifecycle and acceptance conditions, then follow a Pega Academy exercise in its provided environment. Add a fictional missing-evidence case to the workbook.

Mental model: A parcel passes through named stations, each with an exit rule.

Boundary: A screen navigation change is not necessarily a completed business stage.

Worked example: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Pega case management and decision rules (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Pega System Architect / Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Draw the case lifecycle and acceptance conditions, then follow a Pega Academy exercise in its provided environment. Add a fictional missing-evidence case to the workbook.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Draw the case lifecycle and acceptance conditions, then follow a Pega Academy exercise in its provided environment. Add a fictional missing-evidence case to the workbook.

Expected: Every stage has an owner and an observable exit condition.

Role workshop · debug and verify

A screen navigation change is not necessarily a completed business stage. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save case lifecycle and acceptance table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Every stage has an owner and an observable exit condition.

Expected: Every stage has an owner and an observable exit condition.

Troubleshoot: The role exercise differs from the prediction: A screen navigation change is not necessarily a completed business stage.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: case lifecycle and acceptance table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with case lifecycle and stages. Use the glossary below, then write your prediction for: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Pega System Architect / Developer role interview. Explain case lifecycle and stages using this case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate case lifecycle and stages to a system or workflow you know. Explain case lifecycle and stages using this case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A screen navigation change is not necessarily a completed business stage.

Interview: Explain case lifecycle and stages using this case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review.

Every stage has an owner and an observable exit condition.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Every stage has an owner and an observable exit condition. — A case describes work moving through stages with responsibilities and completion conditions. Separate the business outcome from the screens used to collect information. Every stage has an owner and an observable exit condition.

Sources:

Pega Academy: https://academy.pega.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Traceability: Connect a user need to the proposed change, its test and its evidence.

Apply traceability in Pega System Architect / Developer: Use the concept to complete this role exercise: Define decision-table boundary cases and escalation rules

Decision tables and boundary tests: Decision rules map inputs to outcomes and need coverage for boundaries, overlaps and defaults. A missing default can leave cases unresolved.

### Traceability

Connect a user need to the proposed change, its test and its evidence. In this role, work through: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. The practical workshop develops this into: Write the decision table and test 99,100,101,missing and negative. Implement it in the authorized exercise environment if available and compare observed routing.

Mental model: Labels connect a parcel to its order and delivery receipt.

Boundary: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Role application: A sorting chart must have a destination for every valid parcel.

Decision rules map inputs to outcomes and need coverage for boundaries, overlaps and defaults. A missing default can leave cases unresolved.

Worked example: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy.

Shared foundation example: Need R1 points to screen S1, test T1 and a recorded observation.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Pega case management and decision rules (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Pega System Architect / Developer: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy.

Predict the worked case

Read this case without running a tool: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in traceability.

Connect the concept to the role

Apply this rule: Connect a user need to the proposed change, its test and its evidence. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies traceability to this case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Traceability; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with traceability. Use the glossary below, then write your prediction for: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Pega System Architect / Developer role interview. Explain traceability using this case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate traceability to a system or workflow you know. Explain traceability using this case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you identify which tests are affected by a changed requirement?

Interview: Explain traceability using this case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. State the evidence, one alternative and where the mental model stops.

Quiz: After the Decision tables and boundary tests rehearsal, check this foundation: A requirement changes. What evidence helps identify affected checks?

The total number of screenshots in the project.

Links from the requirement to its design, test cases and recorded results.

Only the latest file modification time.

Reference: Links from the requirement to its design, test cases and recorded results. — Traceability connects a need to the change and its verification; documents without those links do not establish impact.

Sources:

Pega Academy: https://academy.pega.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Decision tables and boundary tests

Decision rules map inputs to outcomes and need coverage for boundaries, overlaps and defaults. A missing default can leave cases unresolved. In this role, work through: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. The practical workshop develops this into: Write the decision table and test 99,100,101,missing and negative. Implement it in the authorized exercise environment if available and compare observed routing.

Mental model: A sorting chart must have a destination for every valid parcel.

Boundary: A greater-than rule instead of greater-than-or-equal misroutes the boundary case.

Worked example: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Pega case management and decision rules (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Pega System Architect / Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write the decision table and test 99,100,101,missing and negative. Implement it in the authorized exercise environment if available and compare observed routing.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write the decision table and test 99,100,101,missing and negative. Implement it in the authorized exercise environment if available and compare observed routing.

Expected: No overlapping route or silent unhandled valid input.

Role workshop · debug and verify

A greater-than rule instead of greater-than-or-equal misroutes the boundary case. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save decision table and boundary evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: No overlapping route or silent unhandled valid input.

Expected: No overlapping route or silent unhandled valid input.

Troubleshoot: The role exercise differs from the prediction: A greater-than rule instead of greater-than-or-equal misroutes the boundary case.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: decision table and boundary evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with decision tables and boundary tests. Use the glossary below, then write your prediction for: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Pega System Architect / Developer role interview. Explain decision tables and boundary tests using this case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate decision tables and boundary tests to a system or workflow you know. Explain decision tables and boundary tests using this case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A greater-than rule instead of greater-than-or-equal misroutes the boundary case.

Interview: Explain decision tables and boundary tests using this case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Amounts below 100 use standard review; 100 and above use senior review in this fictional policy.

Ignore the failing case and keep only the successful screenshot.

No overlapping route or silent unhandled valid input.

Treat any successful command as proof that all business and access rules passed.

Reference: No overlapping route or silent unhandled valid input. — Decision rules map inputs to outcomes and need coverage for boundaries, overlaps and defaults. A missing default can leave cases unresolved. No overlapping route or silent unhandled valid input.

Sources:

Pega Academy: https://academy.pega.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Release decision and ownership: Document the evidence, remaining risk, responsible owner and recovery trigger for a change.

Apply release decision and ownership in Pega System Architect / Developer: Use the concept to complete this role exercise: Plan ruleset promotion, audit evidence and failed-integration handling

Case operations and rule changes: Rule changes affect in-flight work and audit history. Define the treatment of existing cases, SLA monitoring and exception handling before rollout.

### Release decision and ownership

Document the evidence, remaining risk, responsible owner and recovery trigger for a change. In this role, work through: A new approval rule should not silently invalidate a previously completed approval. The practical workshop develops this into: Prepare a rule-change impact assessment, test new and existing cases and define an exception queue with an owner. Use platform-supported promotion guidance from the current learning environment.

Mental model: A flight checklist has an accountable pilot and reasons to delay departure.

Boundary: A checklist supports judgment; it does not transfer accountability to a tool.

Role application: Changing station instructions must account for parcels already on the conveyor.

Rule changes affect in-flight work and audit history. Define the treatment of existing cases, SLA monitoring and exception handling before rollout.

Worked example: A new approval rule should not silently invalidate a previously completed approval.

Shared foundation example: Hold a release if unauthorized users can export records, even if basic navigation works.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Pega case management and decision rules (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Pega System Architect / Developer: A new approval rule should not silently invalidate a previously completed approval.

Predict the worked case

Read this case without running a tool: A new approval rule should not silently invalidate a previously completed approval. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in release decision and ownership.

Connect the concept to the role

Apply this rule: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A checklist supports judgment; it does not transfer accountability to a tool.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies release decision and ownership to this case: A new approval rule should not silently invalidate a previously completed approval. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A new approval rule should not silently invalidate a previously completed approval. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Release decision and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with release decision and ownership. Use the glossary below, then write your prediction for: A new approval rule should not silently invalidate a previously completed approval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Pega System Architect / Developer role interview. Explain release decision and ownership using this case: A new approval rule should not silently invalidate a previously completed approval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate release decision and ownership to a system or workflow you know. Explain release decision and ownership using this case: A new approval rule should not silently invalidate a previously completed approval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would make a conditional approval expire?

Interview: Explain release decision and ownership using this case: A new approval rule should not silently invalidate a previously completed approval. State the evidence, one alternative and where the mental model stops.

Quiz: After the Case operations and rule changes rehearsal, check this foundation: A release has a known access-control defect but basic navigation passes. What should the decision include?

Only the navigation pass count.

An anonymous approval with no recovery trigger.

The defect evidence, impact, accountable owner and explicit release or hold criteria.

Reference: The defect evidence, impact, accountable owner and explicit release or hold criteria. — A release decision needs evidence and ownership. Basic checks do not cancel a serious unresolved risk.

Sources:

Pega Academy: https://academy.pega.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Case operations and rule changes

Rule changes affect in-flight work and audit history. Define the treatment of existing cases, SLA monitoring and exception handling before rollout. In this role, work through: A new approval rule should not silently invalidate a previously completed approval. The practical workshop develops this into: Prepare a rule-change impact assessment, test new and existing cases and define an exception queue with an owner. Use platform-supported promotion guidance from the current learning environment.

Mental model: Changing station instructions must account for parcels already on the conveyor.

Boundary: A completed deployment does not prove existing cases can still finish.

Worked example: A new approval rule should not silently invalidate a previously completed approval.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Pega case management and decision rules (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Pega System Architect / Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Prepare a rule-change impact assessment, test new and existing cases and define an exception queue with an owner. Use platform-supported promotion guidance from the current learning environment.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

A new approval rule should not silently invalidate a previously completed approval. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Prepare a rule-change impact assessment, test new and existing cases and define an exception queue with an owner. Use platform-supported promotion guidance from the current learning environment.

Expected: A clear old/new behavior matrix and operational handoff.

Role workshop · debug and verify

A completed deployment does not prove existing cases can still finish. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Pega change and case-recovery pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A clear old/new behavior matrix and operational handoff.

Expected: A clear old/new behavior matrix and operational handoff.

Troubleshoot: The role exercise differs from the prediction: A completed deployment does not prove existing cases can still finish.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: Pega change and case-recovery pack; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with case operations and rule changes. Use the glossary below, then write your prediction for: A new approval rule should not silently invalidate a previously completed approval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Pega System Architect / Developer role interview. Explain case operations and rule changes using this case: A new approval rule should not silently invalidate a previously completed approval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate case operations and rule changes to a system or workflow you know. Explain case operations and rule changes using this case: A new approval rule should not silently invalidate a previously completed approval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A completed deployment does not prove existing cases can still finish.

Interview: Explain case operations and rule changes using this case: A new approval rule should not silently invalidate a previously completed approval. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A new approval rule should not silently invalidate a previously completed approval.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A clear old/new behavior matrix and operational handoff.

Reference: A clear old/new behavior matrix and operational handoff. — Rule changes affect in-flight work and audit history. Define the treatment of existing cases, SLA monitoring and exception handling before rollout. A clear old/new behavior matrix and operational handoff.

Sources:

Pega Academy: https://academy.pega.com/

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys
