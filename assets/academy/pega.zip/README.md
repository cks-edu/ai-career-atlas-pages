# Pega System Architect / Developer

Software Engineering

Start with case lifecycle and stages. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward Pega change and case-recovery pack.

## beginner

Draw the case lifecycle and acceptance conditions, then follow a Pega Academy exercise in its provided environment. Add a fictional missing-evidence case to the workbook.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Case lifecycle and stages
A case describes work moving through stages with responsibilities and completion conditions. Separate the business outcome from the screens used to collect information.
Mental model: A parcel passes through named stations, each with an exit rule.
Limit: A screen navigation change is not necessarily a completed business stage.
Example: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A screen navigation change is not necessarily a completed business stage.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Draw the case lifecycle and acceptance conditions, then follow a Pega Academy exercise in its provided environment. Add a fictional missing-evidence case to the workbook.
Expected: Every stage has an owner and an observable exit condition.

6. Role workshop · debug and verify
A screen navigation change is not necessarily a completed business stage. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save case lifecycle and acceptance table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Every stage has an owner and an observable exit condition.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Case lifecycle and stages: A screen navigation change is not necessarily a completed business stage.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: case lifecycle and acceptance table
Every stage has an owner and an observable exit condition.

Interview: Work through this Pega System Architect / Developer case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A case describes work moving through stages with responsibilities and completion conditions. Separate the business outcome from the screens used to collect information. Expected evidence: Every stage has an owner and an observable exit condition. Diagnosis: A screen navigation change is not necessarily a completed business stage. State the limits of the mental model: A parcel passes through named stations, each with an exit rule.

Resume: Built case lifecycle and acceptance table using Pega case management and decision rules; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Write the decision table and test 99,100,101,missing and negative. Implement it in the authorized exercise environment if available and compare observed routing.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Decision tables and boundary tests
Decision rules map inputs to outcomes and need coverage for boundaries, overlaps and defaults. A missing default can leave cases unresolved.
Mental model: A sorting chart must have a destination for every valid parcel.
Limit: A greater-than rule instead of greater-than-or-equal misroutes the boundary case.
Example: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A greater-than rule instead of greater-than-or-equal misroutes the boundary case.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write the decision table and test 99,100,101,missing and negative. Implement it in the authorized exercise environment if available and compare observed routing.
Expected: No overlapping route or silent unhandled valid input.

6. Role workshop · debug and verify
A greater-than rule instead of greater-than-or-equal misroutes the boundary case. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save decision table and boundary evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: No overlapping route or silent unhandled valid input.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Decision tables and boundary tests: A greater-than rule instead of greater-than-or-equal misroutes the boundary case.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: decision table and boundary evidence
No overlapping route or silent unhandled valid input.

Interview: Work through this Pega System Architect / Developer case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Decision rules map inputs to outcomes and need coverage for boundaries, overlaps and defaults. A missing default can leave cases unresolved. Expected evidence: No overlapping route or silent unhandled valid input. Diagnosis: A greater-than rule instead of greater-than-or-equal misroutes the boundary case. State the limits of the mental model: A sorting chart must have a destination for every valid parcel.

Resume: Built decision table and boundary evidence using Pega case management and decision rules; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Prepare a rule-change impact assessment, test new and existing cases and define an exception queue with an owner. Use platform-supported promotion guidance from the current learning environment.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Case operations and rule changes
Rule changes affect in-flight work and audit history. Define the treatment of existing cases, SLA monitoring and exception handling before rollout.
Mental model: Changing station instructions must account for parcels already on the conveyor.
Limit: A completed deployment does not prove existing cases can still finish.
Example: A new approval rule should not silently invalidate a previously completed approval.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A completed deployment does not prove existing cases can still finish.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A new approval rule should not silently invalidate a previously completed approval. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Prepare a rule-change impact assessment, test new and existing cases and define an exception queue with an owner. Use platform-supported promotion guidance from the current learning environment.
Expected: A clear old/new behavior matrix and operational handoff.

6. Role workshop · debug and verify
A completed deployment does not prove existing cases can still finish. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Pega change and case-recovery pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A clear old/new behavior matrix and operational handoff.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Case operations and rule changes: A completed deployment does not prove existing cases can still finish.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Pega change and case-recovery pack
A clear old/new behavior matrix and operational handoff.

Interview: Work through this Pega System Architect / Developer case: A new approval rule should not silently invalidate a previously completed approval. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Rule changes affect in-flight work and audit history. Define the treatment of existing cases, SLA monitoring and exception handling before rollout. Expected evidence: A clear old/new behavior matrix and operational handoff. Diagnosis: A completed deployment does not prove existing cases can still finish. State the limits of the mental model: Changing station instructions must account for parcels already on the conveyor.

Resume: Built Pega change and case-recovery pack using Pega case management and decision rules; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Pega Academy: https://academy.pega.com/
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
SAP Learning Journeys: https://learning.sap.com/learning-journeys
