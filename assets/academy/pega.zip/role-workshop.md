# Pega System Architect / Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Case lifecycle and stages

A case describes work moving through stages with responsibilities and completion conditions. Separate the business outcome from the screens used to collect information.
Mental model: A parcel passes through named stations, each with an exit rule.
Case: A request moves Intake → Review → Fulfillment; missing evidence keeps it in Review.
Task: Draw the case lifecycle and acceptance conditions, then follow a Pega Academy exercise in its provided environment. Add a fictional missing-evidence case to the workbook.
Acceptance: Every stage has an owner and an observable exit condition.
Troubleshooting: A screen navigation change is not necessarily a completed business stage.
Deliverable: case lifecycle and acceptance table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Decision tables and boundary tests

Decision rules map inputs to outcomes and need coverage for boundaries, overlaps and defaults. A missing default can leave cases unresolved.
Mental model: A sorting chart must have a destination for every valid parcel.
Case: Amounts below 100 use standard review; 100 and above use senior review in this fictional policy.
Task: Write the decision table and test 99,100,101,missing and negative. Implement it in the authorized exercise environment if available and compare observed routing.
Acceptance: No overlapping route or silent unhandled valid input.
Troubleshooting: A greater-than rule instead of greater-than-or-equal misroutes the boundary case.
Deliverable: decision table and boundary evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Case operations and rule changes

Rule changes affect in-flight work and audit history. Define the treatment of existing cases, SLA monitoring and exception handling before rollout.
Mental model: Changing station instructions must account for parcels already on the conveyor.
Case: A new approval rule should not silently invalidate a previously completed approval.
Task: Prepare a rule-change impact assessment, test new and existing cases and define an exception queue with an owner. Use platform-supported promotion guidance from the current learning environment.
Acceptance: A clear old/new behavior matrix and operational handoff.
Troubleshooting: A completed deployment does not prove existing cases can still finish.
Deliverable: Pega change and case-recovery pack

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
