# CRM / Salesforce Developer

Software Engineering

Begin with acceptance criteria. Model a service-request object and field permissions in a learning environment. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Model a service-request object and field permissions in a learning environment

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Object, record and field
A Salesforce object describes a kind of business information; records are instances and fields hold their values. Access must be considered at each relevant level.
Mental model: A filing cabinet has a folder type, individual folders and labeled entries.
Limit: The analogy does not encode sharing, permission sets or field-level security.
Example: Model a Service Request with title, status and owner; decide who may view or edit each.
Recall: Why can access to an object still be insufficient to read a particular field?

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Apply the role exercise
Model a service-request object and field permissions in a learning environment
Expected: A role-specific artifact linked to a requirement and at least one test.

4. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: enterprise-crm-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Model a service-request object and field permissions in a learning environment? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Describe an observable result that determines whether a requirement has been met. For this role, explicitly address: Model a service-request object and field permissions in a learning environment.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Define validation, automation and five acceptance cases

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Automation and transaction limits
Flows and Apex execute business behavior within platform constraints. Design for multiple records and test recursion or repeated triggers.
Mental model: A conveyor handles a batch of parcels within a fixed shift budget.
Limit: Exact limits vary by operation and platform context; check the official documentation.
Example: Test a validation rule with one valid record, one invalid record and a mixed batch.
Recall: Why does working for one record not prove the automation handles a bulk import?

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Apply the role exercise
Define validation, automation and five acceptance cases
Expected: A role-specific artifact linked to a requirement and at least one test.

4. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: enterprise-crm-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Define validation, automation and five acceptance cases? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Connect a user need to the proposed change, its test and its evidence. For this role, explicitly address: Define validation, automation and five acceptance cases.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Plan a sandbox release with access review and rollback evidence

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Metadata deployment
A platform release includes configuration and code. Promote reviewed metadata, test permissions and plan for business data already changed.
Mental model: Move both the building plan and the operating instructions, then inspect the doors.
Limit: A sandbox is not necessarily identical to production data or integrations.
Example: Prepare a release manifest, access test matrix and rollback/forward-fix decision.
Recall: Which effects of a Flow cannot be reversed just by redeploying old metadata?

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Apply the role exercise
Plan a sandbox release with access review and rollback evidence
Expected: A role-specific artifact linked to a requirement and at least one test.

4. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: enterprise-crm-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Plan a sandbox release with access review and rollback evidence? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. For this role, explicitly address: Plan a sandbox release with access review and rollback evidence.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
SAP Learning Journeys: https://learning.sap.com/learning-journeys
