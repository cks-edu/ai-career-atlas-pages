# CRM / Salesforce Developer

Software Engineering

Start with salesforce data model and layered access. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward CRM release manifest, access regression evidence and rollback/forward-fix ADR.

## beginner

Inspect fixture.json, run beginner and write object/field/record access decisions. In a fresh Trailhead Playground create Service Request with text name, Amount currency and Status picklist; compare the configured fields with the local contract.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Salesforce data model and layered access
An object defines a record type, fields hold values and record ownership/sharing determine access. Object permission does not imply access to every field or record. Begin with the synthetic Service Request contract before configuring a Playground.
Mental model: A cabinet has folder types, individual folders and separately restricted pages.
Limit: An administrator's successful test does not prove ordinary-user permissions; test the intended user context.
Example: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation.
Recall: Explain the expected result before running the exercise, then diagnose this failure: An administrator's successful test does not prove ordinary-user permissions; test the intended user context.

1. Inspect the business fixture
Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Inspect fixture.json, run beginner and write object/field/record access decisions. In a fresh Trailhead Playground create Service Request with text name, Amount currency and Status picklist; compare the configured fields with the local contract.
```
python3 enterprise_lab.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: One valid baseline request, one rejected negative amount and denied cross-owner access.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py beginner --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Build in a fresh Trailhead Playground
From Setup → Object Manager create Service Request with a text record name. Add Amount (Currency) and Status (Picklist: New, Closed). Create a validation rule Amount__c < 0 with an inline explanation. Save a request with 10 and another with -1. Use a dedicated learning org and no customer records.
Expected: The positive amount saves; the negative amount is rejected. Record API names because labels and API names can differ.

6. Assemble the portfolio evidence
Create object dictionary, permission matrix and local/Playground evidence. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: One valid baseline request, one rejected negative amount and denied cross-owner access.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: An administrator's successful test does not prove ordinary-user permissions; test the intended user context.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: object dictionary, permission matrix and local/Playground evidence
One valid baseline request, one rejected negative amount and denied cross-owner access.

Interview: Work through this CRM / Salesforce Developer case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An object defines a record type, fields hold values and record ownership/sharing determine access. Object permission does not imply access to every field or record. Begin with the synthetic Service Request contract before configuring a Playground. Expected evidence: One valid baseline request, one rejected negative amount and denied cross-owner access. Diagnosis: An administrator's successful test does not prove ordinary-user permissions; test the intended user context. State the limits of the mental model: A cabinet has folder types, individual folders and separately restricted pages.

Resume: Built object dictionary, permission matrix and local/Playground evidence using Salesforce Platform and Trailhead; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Run intermediate and inspect the complete list traversal. Use --broken to stop after the first item and observe the failed count assertion. Repair the iteration; then use the linked Apex bulk lesson to implement collection-based processing in a Playground.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Bulk validation and partial success
Salesforce automation may receive collections of records. Keep validation and database operations bulk-aware, and make the all-or-none versus partial-success policy explicit rather than assuming one-record behavior generalizes.
Mental model: A receiving desk must process a whole tray within its work budget, not open a new desk for each envelope.
Limit: Do not place SOQL or DML inside a loop merely because a single-record test passes; inspect platform limits for the execution context.
Example: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not place SOQL or DML inside a loop merely because a single-record test passes; inspect platform limits for the execution context.

1. Inspect the business fixture
The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run intermediate and inspect the complete list traversal. Use --broken to stop after the first item and observe the failed count assertion. Repair the iteration; then use the linked Apex bulk lesson to implement collection-based processing in a Playground.
```
python3 enterprise_lab.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: 199 accepted, 1 rejected and all 200 input IDs accounted for in the reference.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py intermediate --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Exercise a bulk save in the Playground
After creating the fields and rule, use a permitted Apex development tool to construct 200 Service_Request__c records and call Database.insert(records, false). Inspect every SaveResult; exactly one record has Amount__c=-1. Keep queries and DML outside the construction loop. Follow the bulk Apex lesson for platform context.
```
// Execute anonymously only in your learning org after creating the fields/rule.
// This tests validation in the executing context, not ordinary-user sharing/FLS.
Savepoint checkpoint = Database.setSavepoint();
try {
    List<Service_Request__c> requests = new List<Service_Request__c>();
    for (Integer i = 0; i < 200; i++) {
        requests.add(new Service_Request__c(
            Name = 'Atlas lab ' + i,
            Amount__c = (i == 199 ? -1 : 10),
            Status__c = 'New'
        ));
    }
    Database.SaveResult[] results = Database.insert(requests, false);
    Integer accepted = 0;
    Integer rejected = 0;
    for (Database.SaveResult result : results) {
        if (result.isSuccess()) {
            accepted++;
        } else {
            rejected++;
            for (Database.Error problem : result.getErrors()) {
                System.debug(problem.getStatusCode() + ': ' + problem.getMessage());
            }
        }
    }
    System.assertEquals(199, accepted);
    System.assertEquals(1, rejected);
    System.debug('accepted=' + accepted + ' rejected=' + rejected);
} finally {
    // Undo the records from this transaction; unrelated metadata is unchanged.
    Database.rollback(checkpoint);
}

```
Apex source, not a shell command. Run using an authorized anonymous-Apex tool in the learning org after creating Service_Request__c, Amount__c, Status__c and the negative-amount validation rule. The transaction rolls back its inserted records; record automation may have additional effects, so use a fresh learning org.
Expected: 199 successes and one validation error for this fixture, assuming no additional org automation. Different results require inspecting SaveResult errors rather than changing expected counts.

6. Assemble the portfolio evidence
Create bulk test matrix and Apex/Flow implementation notes. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: 199 accepted, 1 rejected and all 200 input IDs accounted for in the reference.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: Do not place SOQL or DML inside a loop merely because a single-record test passes; inspect platform limits for the execution context.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: bulk test matrix and Apex/Flow implementation notes
199 accepted, 1 rejected and all 200 input IDs accounted for in the reference.

Interview: Work through this CRM / Salesforce Developer case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Salesforce automation may receive collections of records. Keep validation and database operations bulk-aware, and make the all-or-none versus partial-success policy explicit rather than assuming one-record behavior generalizes. Expected evidence: 199 accepted, 1 rejected and all 200 input IDs accounted for in the reference. Diagnosis: Do not place SOQL or DML inside a loop merely because a single-record test passes; inspect platform limits for the execution context. State the limits of the mental model: A receiving desk must process a whole tray within its work budget, not open a new desk for each envelope.

Resume: Built bulk test matrix and Apex/Flow implementation notes using Salesforce Platform and Trailhead; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run advanced with the access matrix. Create a release manifest for the Service Request object and rule, list dependencies and write a sandbox validation/forward-fix plan. Include a repeated automation event and its deduplication policy.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Metadata release and access regression
A Salesforce release includes fields, rules, automation and access configuration. Redeploying metadata does not automatically reverse record changes or notifications. Retest least-privilege users after promotion.
Mental model: Move the floor plan and the lock schedule together, then verify each door.
Limit: A system-context automation can bypass assumptions from UI tests; review execution context and field access explicitly.
Example: Alice can read r1; Bob and an unknown caller remain denied after the simulated release.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A system-context automation can bypass assumptions from UI tests; review execution context and field access explicitly.

1. Inspect the business fixture
Alice can read r1; Bob and an unknown caller remain denied after the simulated release. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run advanced with the access matrix. Create a release manifest for the Service Request object and rule, list dependencies and write a sandbox validation/forward-fix plan. Include a repeated automation event and its deduplication policy.
```
python3 enterprise_lab.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: All four baseline access cases match the contract; no rollback claim is made for external effects.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py advanced --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Review metadata and access
List custom object, fields, rule and permission configuration in a deployment manifest. In a sandbox or other permitted learning org validate record sharing and field access as intended users, then test a repeated automation event. Use the org-supported deployment workflow and current test requirements.
Expected: Release evidence includes normal-user access tests; administrator-only tests are explicitly insufficient.

6. Assemble the portfolio evidence
Create CRM release manifest, access regression evidence and rollback/forward-fix ADR. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: All four baseline access cases match the contract; no rollback claim is made for external effects.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: A system-context automation can bypass assumptions from UI tests; review execution context and field access explicitly.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: CRM release manifest, access regression evidence and rollback/forward-fix ADR
All four baseline access cases match the contract; no rollback claim is made for external effects.

Interview: Work through this CRM / Salesforce Developer case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A Salesforce release includes fields, rules, automation and access configuration. Redeploying metadata does not automatically reverse record changes or notifications. Retest least-privilege users after promotion. Expected evidence: All four baseline access cases match the contract; no rollback claim is made for external effects. Diagnosis: A system-context automation can bypass assumptions from UI tests; review execution context and field access explicitly. State the limits of the mental model: Move the floor plan and the lock schedule together, then verify each door.

Resume: Built CRM release manifest, access regression evidence and rollback/forward-fix ADR using Salesforce Platform and Trailhead; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
Salesforce Trailhead: objects and fields: https://trailhead.salesforce.com/content/learn/modules/data_modeling/objects_intro
Salesforce Trailhead: bulk Apex triggers: https://trailhead.salesforce.com/content/learn/modules/apex_triggers/apex_triggers_bulk
