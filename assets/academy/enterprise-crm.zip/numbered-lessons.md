# CRM / Salesforce Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Acceptance criteria: Describe an observable result that determines whether a requirement has been met.

Object, record and field: A Salesforce object describes a kind of business information; records are instances and fields hold their values. Access must be considered at each relevant level.

Apex: Salesforce programming language; the bulk example runs in an authorized learning org.

SOQL: Salesforce Object Query Language: queries records using the platform object model.

DML: Data manipulation language operations such as insert and update; bulk operations process collections.

Metadata: Definitions such as objects, fields and rules, distinct from the business records they describe.

Salesforce data model and layered access: An object defines a record type, fields hold values and record ownership/sharing determine access. Object permission does not imply access to every field or record. Begin with the synthetic Service Request contract before configuring a Playground.

### Acceptance criteria

Describe an observable result that determines whether a requirement has been met. In this role, work through: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. The practical workshop develops this into: Inspect fixture.json, run beginner and write object/field/record access decisions. In a fresh Trailhead Playground create Service Request with text name, Amount currency and Status picklist; compare the configured fields with the local contract.

Mental model: A delivery receipt lists what must arrive, not just that a truck drove.

Boundary: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Role application: A cabinet has folder types, individual folders and separately restricted pages.

An object defines a record type, fields hold values and record ownership/sharing determine access. Object permission does not imply access to every field or record. Begin with the synthetic Service Request contract before configuring a Playground.

Worked example: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation.

Shared foundation example: Given an empty title, submitting a request shows an error and creates no ticket.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Salesforce Platform and Trailhead (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for CRM / Salesforce Developer: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation.

Predict the worked case

Read this case without running a tool: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in acceptance criteria.

Connect the concept to the role

Apply this rule: Describe an observable result that determines whether a requirement has been met. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies acceptance criteria to this case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Acceptance criteria; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with acceptance criteria. Use the glossary below, then write your prediction for: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the CRM / Salesforce Developer role interview. Explain acceptance criteria using this case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate acceptance criteria to a system or workflow you know. Explain acceptance criteria using this case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Turn “make it easier” into a measurable task outcome.

Interview: Explain acceptance criteria using this case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. State the evidence, one alternative and where the mental model stops.

Quiz: After the Salesforce data model and layered access rehearsal, check this foundation: A requirement says “make this workflow easier.” What makes its acceptance testable?

A defined user task and observable result, reviewed with the relevant stakeholder.

A count of implementation files without a user outcome.

A statement that the chosen tool is widely used.

Reference: A defined user task and observable result, reviewed with the relevant stakeholder. — Acceptance criteria describe observable outcomes. Stakeholder review is still needed to ensure the outcome solves the right problem.

Sources:

Salesforce Trailhead: objects and fields: https://trailhead.salesforce.com/content/learn/modules/data_modeling/objects_intro

Salesforce Trailhead: bulk Apex triggers: https://trailhead.salesforce.com/content/learn/modules/apex_triggers/apex_triggers_bulk

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

### Salesforce data model and layered access

An object defines a record type, fields hold values and record ownership/sharing determine access. Object permission does not imply access to every field or record. Begin with the synthetic Service Request contract before configuring a Playground. In this role, work through: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. The practical workshop develops this into: Inspect fixture.json, run beginner and write object/field/record access decisions. In a fresh Trailhead Playground create Service Request with text name, Amount currency and Status picklist; compare the configured fields with the local contract.

Mental model: A cabinet has folder types, individual folders and separately restricted pages.

Boundary: An administrator's successful test does not prove ordinary-user permissions; test the intended user context.

Worked example: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Salesforce Platform and Trailhead (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Inspect fixture.json, run beginner and write object/field/record access decisions. In a fresh Trailhead Playground create Service Request with text name, Amount currency and Status picklist; compare the configured fields with the local contract.

Inspect the business fixture

Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Inspect fixture.json, run beginner and write object/field/record access decisions. In a fresh Trailhead Playground create Service Request with text name, Amount currency and Status picklist; compare the configured fields with the local contract.

```
python3 enterprise_lab.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: One valid baseline request, one rejected negative amount and denied cross-owner access.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py beginner --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Build in a fresh Trailhead Playground

From Setup → Object Manager create Service Request with a text record name. Add Amount (Currency) and Status (Picklist: New, Closed). Create a validation rule Amount__c < 0 with an inline explanation. Save a request with 10 and another with -1. Use a dedicated learning org and no customer records.

Expected: The positive amount saves; the negative amount is rejected. Record API names because labels and API names can differ.

Assemble the portfolio evidence

Create object dictionary, permission matrix and local/Playground evidence. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: One valid baseline request, one rejected negative amount and denied cross-owner access.

Expected: One valid baseline request, one rejected negative amount and denied cross-owner access.

Troubleshoot: The role exercise differs from the prediction: An administrator's successful test does not prove ordinary-user permissions; test the intended user context.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-beginner-2.md: object dictionary, permission matrix and local/Playground evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with salesforce data model and layered access. Use the glossary below, then write your prediction for: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the CRM / Salesforce Developer role interview. Explain salesforce data model and layered access using this case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate salesforce data model and layered access to a system or workflow you know. Explain salesforce data model and layered access using this case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: An administrator's successful test does not prove ordinary-user permissions; test the intended user context.

Interview: Explain salesforce data model and layered access using this case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation.

One valid baseline request, one rejected negative amount and denied cross-owner access.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: One valid baseline request, one rejected negative amount and denied cross-owner access. — An object defines a record type, fields hold values and record ownership/sharing determine access. Object permission does not imply access to every field or record. Begin with the synthetic Service Request contract before configuring a Playground. One valid baseline request, one rejected negative amount and denied cross-owner access.

Sources:

Salesforce Trailhead: objects and fields: https://trailhead.salesforce.com/content/learn/modules/data_modeling/objects_intro

Salesforce Trailhead: bulk Apex triggers: https://trailhead.salesforce.com/content/learn/modules/apex_triggers/apex_triggers_bulk

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Traceability: Connect a user need to the proposed change, its test and its evidence.

Automation and transaction limits: Flows and Apex execute business behavior within platform constraints. Design for multiple records and test recursion or repeated triggers.

Apex: Salesforce programming language; the bulk example runs in an authorized learning org.

SOQL: Salesforce Object Query Language: queries records using the platform object model.

DML: Data manipulation language operations such as insert and update; bulk operations process collections.

Metadata: Definitions such as objects, fields and rules, distinct from the business records they describe.

Bulk validation and partial success: Salesforce automation may receive collections of records. Keep validation and database operations bulk-aware, and make the all-or-none versus partial-success policy explicit rather than assuming one-record behavior generalizes.

### Traceability

Connect a user need to the proposed change, its test and its evidence. In this role, work through: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. The practical workshop develops this into: Run intermediate and inspect the complete list traversal. Use --broken to stop after the first item and observe the failed count assertion. Repair the iteration; then use the linked Apex bulk lesson to implement collection-based processing in a Playground.

Mental model: Labels connect a parcel to its order and delivery receipt.

Boundary: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Role application: A receiving desk must process a whole tray within its work budget, not open a new desk for each envelope.

Salesforce automation may receive collections of records. Keep validation and database operations bulk-aware, and make the all-or-none versus partial-success policy explicit rather than assuming one-record behavior generalizes.

Worked example: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error.

Shared foundation example: Need R1 points to screen S1, test T1 and a recorded observation.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Salesforce Platform and Trailhead (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for CRM / Salesforce Developer: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error.

Predict the worked case

Read this case without running a tool: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in traceability.

Connect the concept to the role

Apply this rule: Connect a user need to the proposed change, its test and its evidence. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies traceability to this case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Traceability; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with traceability. Use the glossary below, then write your prediction for: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the CRM / Salesforce Developer role interview. Explain traceability using this case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate traceability to a system or workflow you know. Explain traceability using this case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you identify which tests are affected by a changed requirement?

Interview: Explain traceability using this case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. State the evidence, one alternative and where the mental model stops.

Quiz: After the Bulk validation and partial success rehearsal, check this foundation: A requirement changes. What evidence helps identify affected checks?

The total number of screenshots in the project.

Links from the requirement to its design, test cases and recorded results.

Only the latest file modification time.

Reference: Links from the requirement to its design, test cases and recorded results. — Traceability connects a need to the change and its verification; documents without those links do not establish impact.

Sources:

Salesforce Trailhead: objects and fields: https://trailhead.salesforce.com/content/learn/modules/data_modeling/objects_intro

Salesforce Trailhead: bulk Apex triggers: https://trailhead.salesforce.com/content/learn/modules/apex_triggers/apex_triggers_bulk

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

### Bulk validation and partial success

Salesforce automation may receive collections of records. Keep validation and database operations bulk-aware, and make the all-or-none versus partial-success policy explicit rather than assuming one-record behavior generalizes. In this role, work through: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. The practical workshop develops this into: Run intermediate and inspect the complete list traversal. Use --broken to stop after the first item and observe the failed count assertion. Repair the iteration; then use the linked Apex bulk lesson to implement collection-based processing in a Playground.

Mental model: A receiving desk must process a whole tray within its work budget, not open a new desk for each envelope.

Boundary: Do not place SOQL or DML inside a loop merely because a single-record test passes; inspect platform limits for the execution context.

Worked example: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Salesforce Platform and Trailhead (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run intermediate and inspect the complete list traversal. Use --broken to stop after the first item and observe the failed count assertion. Repair the iteration; then use the linked Apex bulk lesson to implement collection-based processing in a Playground.

Inspect the business fixture

The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run intermediate and inspect the complete list traversal. Use --broken to stop after the first item and observe the failed count assertion. Repair the iteration; then use the linked Apex bulk lesson to implement collection-based processing in a Playground.

```
python3 enterprise_lab.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: 199 accepted, 1 rejected and all 200 input IDs accounted for in the reference.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py intermediate --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Exercise a bulk save in the Playground

After creating the fields and rule, use a permitted Apex development tool to construct 200 Service_Request__c records and call Database.insert(records, false). Inspect every SaveResult; exactly one record has Amount__c=-1. Keep queries and DML outside the construction loop. Follow the bulk Apex lesson for platform context.

```
// Execute anonymously only in your learning org after creating the fields/rule.
// This tests validation in the executing context, not ordinary-user sharing/FLS.
Savepoint checkpoint = Database.setSavepoint();
try {
    List<Service_Request__c> requests = new List<Service_Request__c>();
    for (Integer i = 0; i < 200; i++) {
        requests.add(new Service_Request__c(
            Name = 'Atlas lab ' + i,
            Amount__c = (i == 199 ? -1 : 10),
            Status__c = 'New'
        ));
    }
    Database.SaveResult[] results = Database.insert(requests, false);
    Integer accepted = 0;
    Integer rejected = 0;
    for (Database.SaveResult result : results) {
        if (result.isSuccess()) {
            accepted++;
        } else {
            rejected++;
            for (Database.Error problem : result.getErrors()) {
                System.debug(problem.getStatusCode() + ': ' + problem.getMessage());
            }
        }
    }
    System.assertEquals(199, accepted);
    System.assertEquals(1, rejected);
    System.debug('accepted=' + accepted + ' rejected=' + rejected);
} finally {
    // Undo the records from this transaction; unrelated metadata is unchanged.
    Database.rollback(checkpoint);
}

```

Apex source, not a shell command. Run using an authorized anonymous-Apex tool in the learning org after creating Service_Request__c, Amount__c, Status__c and the negative-amount validation rule. The transaction rolls back its inserted records; record automation may have additional effects, so use a fresh learning org.

Expected: 199 successes and one validation error for this fixture, assuming no additional org automation. Different results require inspecting SaveResult errors rather than changing expected counts.

Assemble the portfolio evidence

Create bulk test matrix and Apex/Flow implementation notes. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: 199 accepted, 1 rejected and all 200 input IDs accounted for in the reference.

Expected: 199 accepted, 1 rejected and all 200 input IDs accounted for in the reference.

Troubleshoot: The role exercise differs from the prediction: Do not place SOQL or DML inside a loop merely because a single-record test passes; inspect platform limits for the execution context.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-intermediate-2.md: bulk test matrix and Apex/Flow implementation notes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with bulk validation and partial success. Use the glossary below, then write your prediction for: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the CRM / Salesforce Developer role interview. Explain bulk validation and partial success using this case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate bulk validation and partial success to a system or workflow you know. Explain bulk validation and partial success using this case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not place SOQL or DML inside a loop merely because a single-record test passes; inspect platform limits for the execution context.

Interview: Explain bulk validation and partial success using this case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error.

Ignore the failing case and keep only the successful screenshot.

199 accepted, 1 rejected and all 200 input IDs accounted for in the reference.

Treat any successful command as proof that all business and access rules passed.

Reference: 199 accepted, 1 rejected and all 200 input IDs accounted for in the reference. — Salesforce automation may receive collections of records. Keep validation and database operations bulk-aware, and make the all-or-none versus partial-success policy explicit rather than assuming one-record behavior generalizes. 199 accepted, 1 rejected and all 200 input IDs accounted for in the reference.

Sources:

Salesforce Trailhead: objects and fields: https://trailhead.salesforce.com/content/learn/modules/data_modeling/objects_intro

Salesforce Trailhead: bulk Apex triggers: https://trailhead.salesforce.com/content/learn/modules/apex_triggers/apex_triggers_bulk

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Release decision and ownership: Document the evidence, remaining risk, responsible owner and recovery trigger for a change.

Metadata deployment: A platform release includes configuration and code. Promote reviewed metadata, test permissions and plan for business data already changed.

Apex: Salesforce programming language; the bulk example runs in an authorized learning org.

SOQL: Salesforce Object Query Language: queries records using the platform object model.

DML: Data manipulation language operations such as insert and update; bulk operations process collections.

Metadata: Definitions such as objects, fields and rules, distinct from the business records they describe.

Metadata release and access regression: A Salesforce release includes fields, rules, automation and access configuration. Redeploying metadata does not automatically reverse record changes or notifications. Retest least-privilege users after promotion.

### Release decision and ownership

Document the evidence, remaining risk, responsible owner and recovery trigger for a change. In this role, work through: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. The practical workshop develops this into: Run advanced with the access matrix. Create a release manifest for the Service Request object and rule, list dependencies and write a sandbox validation/forward-fix plan. Include a repeated automation event and its deduplication policy.

Mental model: A flight checklist has an accountable pilot and reasons to delay departure.

Boundary: A checklist supports judgment; it does not transfer accountability to a tool.

Role application: Move the floor plan and the lock schedule together, then verify each door.

A Salesforce release includes fields, rules, automation and access configuration. Redeploying metadata does not automatically reverse record changes or notifications. Retest least-privilege users after promotion.

Worked example: Alice can read r1; Bob and an unknown caller remain denied after the simulated release.

Shared foundation example: Hold a release if unauthorized users can export records, even if basic navigation works.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Salesforce Platform and Trailhead (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for CRM / Salesforce Developer: Alice can read r1; Bob and an unknown caller remain denied after the simulated release.

Predict the worked case

Read this case without running a tool: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in release decision and ownership.

Connect the concept to the role

Apply this rule: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A checklist supports judgment; it does not transfer accountability to a tool.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies release decision and ownership to this case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Release decision and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with release decision and ownership. Use the glossary below, then write your prediction for: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the CRM / Salesforce Developer role interview. Explain release decision and ownership using this case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate release decision and ownership to a system or workflow you know. Explain release decision and ownership using this case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would make a conditional approval expire?

Interview: Explain release decision and ownership using this case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. State the evidence, one alternative and where the mental model stops.

Quiz: After the Metadata release and access regression rehearsal, check this foundation: A release has a known access-control defect but basic navigation passes. What should the decision include?

Only the navigation pass count.

An anonymous approval with no recovery trigger.

The defect evidence, impact, accountable owner and explicit release or hold criteria.

Reference: The defect evidence, impact, accountable owner and explicit release or hold criteria. — A release decision needs evidence and ownership. Basic checks do not cancel a serious unresolved risk.

Sources:

Salesforce Trailhead: objects and fields: https://trailhead.salesforce.com/content/learn/modules/data_modeling/objects_intro

Salesforce Trailhead: bulk Apex triggers: https://trailhead.salesforce.com/content/learn/modules/apex_triggers/apex_triggers_bulk

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

### Metadata release and access regression

A Salesforce release includes fields, rules, automation and access configuration. Redeploying metadata does not automatically reverse record changes or notifications. Retest least-privilege users after promotion. In this role, work through: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. The practical workshop develops this into: Run advanced with the access matrix. Create a release manifest for the Service Request object and rule, list dependencies and write a sandbox validation/forward-fix plan. Include a repeated automation event and its deduplication policy.

Mental model: Move the floor plan and the lock schedule together, then verify each door.

Boundary: A system-context automation can bypass assumptions from UI tests; review execution context and field access explicitly.

Worked example: Alice can read r1; Bob and an unknown caller remain denied after the simulated release.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Salesforce Platform and Trailhead (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run advanced with the access matrix. Create a release manifest for the Service Request object and rule, list dependencies and write a sandbox validation/forward-fix plan. Include a repeated automation event and its deduplication policy.

Inspect the business fixture

Alice can read r1; Bob and an unknown caller remain denied after the simulated release. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run advanced with the access matrix. Create a release manifest for the Service Request object and rule, list dependencies and write a sandbox validation/forward-fix plan. Include a repeated automation event and its deduplication policy.

```
python3 enterprise_lab.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: All four baseline access cases match the contract; no rollback claim is made for external effects.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py advanced --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Review metadata and access

List custom object, fields, rule and permission configuration in a deployment manifest. In a sandbox or other permitted learning org validate record sharing and field access as intended users, then test a repeated automation event. Use the org-supported deployment workflow and current test requirements.

Expected: Release evidence includes normal-user access tests; administrator-only tests are explicitly insufficient.

Assemble the portfolio evidence

Create CRM release manifest, access regression evidence and rollback/forward-fix ADR. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: All four baseline access cases match the contract; no rollback claim is made for external effects.

Expected: All four baseline access cases match the contract; no rollback claim is made for external effects.

Troubleshoot: The role exercise differs from the prediction: A system-context automation can bypass assumptions from UI tests; review execution context and field access explicitly.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-advanced-2.md: CRM release manifest, access regression evidence and rollback/forward-fix ADR; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with metadata release and access regression. Use the glossary below, then write your prediction for: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the CRM / Salesforce Developer role interview. Explain metadata release and access regression using this case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate metadata release and access regression to a system or workflow you know. Explain metadata release and access regression using this case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A system-context automation can bypass assumptions from UI tests; review execution context and field access explicitly.

Interview: Explain metadata release and access regression using this case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Alice can read r1; Bob and an unknown caller remain denied after the simulated release.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

All four baseline access cases match the contract; no rollback claim is made for external effects.

Reference: All four baseline access cases match the contract; no rollback claim is made for external effects. — A Salesforce release includes fields, rules, automation and access configuration. Redeploying metadata does not automatically reverse record changes or notifications. Retest least-privilege users after promotion. All four baseline access cases match the contract; no rollback claim is made for external effects.

Sources:

Salesforce Trailhead: objects and fields: https://trailhead.salesforce.com/content/learn/modules/data_modeling/objects_intro

Salesforce Trailhead: bulk Apex triggers: https://trailhead.salesforce.com/content/learn/modules/apex_triggers/apex_triggers_bulk

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
