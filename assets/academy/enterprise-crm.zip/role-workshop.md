# CRM / Salesforce Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Salesforce data model and layered access

An object defines a record type, fields hold values and record ownership/sharing determine access. Object permission does not imply access to every field or record. Begin with the synthetic Service Request contract before configuring a Playground.
Mental model: A cabinet has folder types, individual folders and separately restricted pages.
Case: Request r1 belongs to Alice; Bob cannot read it under this lab's private-record policy. A negative amount fails validation.
Task: Inspect fixture.json, run beginner and write object/field/record access decisions. In a fresh Trailhead Playground create Service Request with text name, Amount currency and Status picklist; compare the configured fields with the local contract.
Acceptance: One valid baseline request, one rejected negative amount and denied cross-owner access.
Troubleshooting: An administrator's successful test does not prove ordinary-user permissions; test the intended user context.
Deliverable: object dictionary, permission matrix and local/Playground evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Bulk validation and partial success

Salesforce automation may receive collections of records. Keep validation and database operations bulk-aware, and make the all-or-none versus partial-success policy explicit rather than assuming one-record behavior generalizes.
Mental model: A receiving desk must process a whole tray within its work budget, not open a new desk for each envelope.
Case: The fixture has 200 requests with one invalid amount; the local partial-success policy accepts 199 and reports one error.
Task: Run intermediate and inspect the complete list traversal. Use --broken to stop after the first item and observe the failed count assertion. Repair the iteration; then use the linked Apex bulk lesson to implement collection-based processing in a Playground.
Acceptance: 199 accepted, 1 rejected and all 200 input IDs accounted for in the reference.
Troubleshooting: Do not place SOQL or DML inside a loop merely because a single-record test passes; inspect platform limits for the execution context.
Deliverable: bulk test matrix and Apex/Flow implementation notes

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Metadata release and access regression

A Salesforce release includes fields, rules, automation and access configuration. Redeploying metadata does not automatically reverse record changes or notifications. Retest least-privilege users after promotion.
Mental model: Move the floor plan and the lock schedule together, then verify each door.
Case: Alice can read r1; Bob and an unknown caller remain denied after the simulated release.
Task: Run advanced with the access matrix. Create a release manifest for the Service Request object and rule, list dependencies and write a sandbox validation/forward-fix plan. Include a repeated automation event and its deduplication policy.
Acceptance: All four baseline access cases match the contract; no rollback claim is made for external effects.
Troubleshooting: A system-context automation can bypass assumptions from UI tests; review execution context and field access explicitly.
Deliverable: CRM release manifest, access regression evidence and rollback/forward-fix ADR

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
