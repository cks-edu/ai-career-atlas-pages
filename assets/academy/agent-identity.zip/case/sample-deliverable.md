# SAMPLE — Authorization matrix and approval integrity report
Role: Agent identity & authorization
Case: Approval is reused for another action
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The agent gateway rejects every action whose arguments differ from the human-approved action digest.

## Evidence table
| Record | changed_arguments (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 1 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three actions reuse approval after changing resource or action parameters.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Bind approval to identity, exact action scope, expiry and a replay-resistant request record.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in agent identity & authorization.
Before release: Changed, expired and revoked approvals fail without effects; the original approved action can complete once.

## Design choice and trade-off
Validate authority outside the model; retain a trace from user approval to actual resource action.
Broad approvals reduce friction but expand blast radius; scope must reflect the consequence of the action.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Delegated tool gateway: Unauthorized actions have zero side effects.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
