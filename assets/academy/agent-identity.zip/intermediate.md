## intermediate — Scoped delegated authority

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Identity protocols, policy enforcement and distributed systems. Often hired within security or platform teams.

### Scoped delegated authority
Grant only the actions, resources and duration needed for a task. Check policy at the service boundary and record the delegation chain.
Mental model: A visitor badge opens one room for one afternoon.
Boundary: A narrow token can still be misused within its permitted scope.
Worked example: A temporary token permits reading project A tickets but denies export and project B access; test both denials.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Delegated agent authorization gateway
Build a policy boundary for agents acting on behalf of users across tenants. Put policy evaluation before each tool execution. Log a decision ID and delegation chain; prevent a tool result from widening the next tool’s authority.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local CLI only; no credentials or real tenant data are provided.
Worked example: Define fictional principals, agents, delegated scopes, resources and expiry times. Model both the human identity and the acting agent; do not use real credentials.
Recall: Report allowed/denied cases, revocation delay and decision trace completeness. Policy tests do not replace identity-provider integration tests. Identify one observation that would contradict your claim.

### Terms
Scoped delegated authority: Grant only the actions, resources and duration needed for a task. Check policy at the service boundary and record the delegation chain.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CLI: Command-line interface: a program operated by commands in a terminal.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Install OPA from its official distribution and use Rego v1. Run only the local policy files in this pack. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a policy boundary for agents acting on behalf of users across tenants. A tenant-scoped read policy and four allow/deny tests. Real identity verification, delegation, revocation and enforcement integration are tasks to implement. Local CLI only; no credentials or real tenant data are provided.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install OPA from its official distribution and use Rego v1. Run only the local policy files in this pack. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
opa version
opa test . -v
opa eval -d authz.rego -i request.json data.portfolio.authz.allow
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A tenant-scoped read policy and four allow/deny tests. Real identity verification, delegation, revocation and enforcement integration are tasks to implement.

2. Prepare the project inputs
Define fictional principals, agents, delegated scopes, resources and expiry times. Model both the human identity and the acting agent; do not use real credentials.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the included OPA tests and extend input with subject, actor, tenant, action, resource and approval expiry. Deny missing or mismatched attributes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Put policy evaluation before each tool execution. Log a decision ID and delegation chain; prevent a tool result from widening the next tool’s authority.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report allowed/denied cases, revocation delay and decision trace completeness. Policy tests do not replace identity-provider integration tests. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The agent gateway rejects every action whose arguments differ from the human-approved action digest. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Parse error: check OPA/Rego version and imports.
Unexpected allow: inspect all decision inputs and missing attributes.
Policy passes but app leaks: verify enforcement happens before retrieval/tool execution.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: No server is started. Retain test output and policy revision.

### Portfolio
Build a policy boundary for agents acting on behalf of users across tenants.
Define fictional principals, agents, delegated scopes, resources and expiry times. Model both the human identity and the acting agent; do not use real credentials.
Run the included OPA tests and extend input with subject, actor, tenant, action, resource and approval expiry. Deny missing or mismatched attributes.
Put policy evaluation before each tool execution. Log a decision ID and delegation chain; prevent a tool result from widening the next tool’s authority.
Report allowed/denied cases, revocation delay and decision trace completeness. Policy tests do not replace identity-provider integration tests.
Deliverables: OPA policy and gateway contract; Delegation/revocation test suite. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report allowed/denied cases, revocation delay and decision trace completeness. Policy tests do not replace identity-provider integration tests. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Agent identity & authorization. Use this scenario: Reuse an approval for a different resource and replay it after revocation. Both must fail even if the agent’s natural-language plan says permission was granted.
Review: Start with the task and permitted scope. Explain scoped delegated authority: Grant only the actions, resources and duration needed for a task. Check policy at the service boundary and record the delegation chain. Show the input and observed output, then address Report allowed/denied cases, revocation delay and decision trace completeness. Policy tests do not replace identity-provider integration tests. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [OPA policy and gateway contract; Delegation/revocation test suite. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

