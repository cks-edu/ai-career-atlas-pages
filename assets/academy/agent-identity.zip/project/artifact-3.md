# Threat model and decision audit example

Project: Delegated agent authorization gateway
Status: blank work product — not completed evidence

## Purpose and audience
Build a policy boundary for agents acting on behalf of users across tenants.

## Required content
Add tests for scope reduction, revoked delegation and confused-deputy attempts. Write a sequence diagram from user approval to downstream enforcement.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report allowed/denied cases, revocation delay and decision trace completeness. Policy tests do not replace identity-provider integration tests.

## Failure evidence
Reuse an approval for a different resource and replay it after revocation. Both must fail even if the agent’s natural-language plan says permission was granted.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
