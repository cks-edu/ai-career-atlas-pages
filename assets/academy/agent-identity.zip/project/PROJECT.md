# Delegated agent authorization gateway

Career: Agent identity & authorization
Reviewed: 2026-10-22

Build a policy boundary for agents acting on behalf of users across tenants.

## Prerequisites
Identity protocols, policy enforcement and distributed systems. Often hired within security or platform teams.

## Included starter versus your implementation
A tenant-scoped read policy and four allow/deny tests. Real identity verification, delegation, revocation and enforcement integration are tasks to implement.

Local CLI only; no credentials or real tenant data are provided.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Install OPA from its official distribution and use Rego v1. Run only the local policy files in this pack.

```sh
opa version
opa test . -v
opa eval -d authz.rego -i request.json data.portfolio.authz.allow
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Define fictional principals, agents, delegated scopes, resources and expiry times. Model both the human identity and the acting agent; do not use real credentials.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run the included OPA tests and extend input with subject, actor, tenant, action, resource and approval expiry. Deny missing or mismatched attributes.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Put policy evaluation before each tool execution. Log a decision ID and delegation chain; prevent a tool result from widening the next tool’s authority.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Add tests for scope reduction, revoked delegation and confused-deputy attempts. Write a sequence diagram from user approval to downstream enforcement.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Reuse an approval for a different resource and replay it after revocation. Both must fail even if the agent’s natural-language plan says permission was granted.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report allowed/denied cases, revocation delay and decision trace completeness. Policy tests do not replace identity-provider integration tests.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. No server is started. Retain test output and policy revision.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. OPA policy and gateway contract — artifact-1.md
2. Delegation/revocation test suite — artifact-2.md
3. Threat model and decision audit example — artifact-3.md

## Troubleshooting
- Parse error: check OPA/Rego version and imports.
- Unexpected allow: inspect all decision inputs and missing attributes.
- Policy passes but app leaks: verify enforcement happens before retrieval/tool execution.

## Extension
Integrate a sandbox identity provider and verify token audience, issuer and expiration at the gateway.

## Primary learning resources
- Open Policy Agent: https://www.openpolicyagent.org/docs/policy-testing — Open source · local CLI; Rego policy decisions and allow/deny regression tests.
- FastAPI: https://fastapi.tiangolo.com/tutorial/ — Open source · local; Typed API, validation and local service tests.
- OWASP GenAI security guidance: https://genai.owasp.org/llm-top-10/ — Public guidance; Threat-model and defensive-test planning.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
