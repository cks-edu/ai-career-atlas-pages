## advanced — Repeatable benchmark execution

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Repeatable benchmark execution
Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs.
Mental model: Every contestant starts the obstacle course from the same line.
Boundary: Deterministic fixtures may underrepresent open-ended real workflows.
Worked example: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Outcome-based agent benchmark
Evaluate agents on final task outcomes with controlled environments and bounded resources. Compare a scripted baseline and an agent on identical initial states. Add CI for fixture integrity and outcome-check tests.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Recall: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. Identify one observation that would contradict your claim.

### Terms
Repeatable benchmark execution: Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Evaluate agents on final task outcomes with controlled environments and bounded resources. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Compare a scripted baseline and an agent on identical initial states. Add CI for fixture integrity and outcome-check tests.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Evaluate agents on final task outcomes with controlled environments and bounded resources.
Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.
Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Compare a scripted baseline and an agent on identical initial states. Add CI for fixture integrity and outcome-check tests.
Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.
Add human review for tasks where exact automated outcome checks are insufficient.
Deliverables: Task harness and isolated fixtures; Outcome assertion suite and raw traces; Benchmark card and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A reviewer must reproduce one result and identify which capabilities you implemented. Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.

### Interview
Explain your advanced solution for Agent evaluation / benchmark engineer. Use this scenario: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Review: Start with the task and permitted scope. Explain repeatable benchmark execution: Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs. Show the input and observed output, then address Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Task harness and isolated fixtures; Outcome assertion suite and raw traces; Benchmark card and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

