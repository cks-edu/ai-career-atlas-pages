# SAMPLE — Agent benchmark integrity report
Role: Agent evaluation / benchmark engineer
Case: The verifier believes the agent
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The benchmark requires zero false successes when final task state is deliberately wrong.

## Evidence table
| Record | false_successes (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three verifiers accept a success message even when the required final state is absent.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Validate final state using independent checks outside the editable agent workspace.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in agent evaluation / benchmark engineer.
Before release: Replay genuine success, fake success text and attempted verifier modification.

## Design choice and trade-off
Separate evaluated actions from scoring authority; record trajectories and independent outcome checks.
A verifier must allow different valid solutions without trusting self-reported completion.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Agent task arena: Scores reflect final behavior and include failed or timed-out runs.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
