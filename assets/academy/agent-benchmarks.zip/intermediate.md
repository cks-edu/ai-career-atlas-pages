## intermediate — Independent verifiers

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Sandboxed execution, state validation, distributed jobs and statistics.

### Independent verifiers
Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately.
Mental model: An athlete must not be able to edit the scoreboard.
Boundary: A protected verifier can still contain bugs or incomplete criteria.
Worked example: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Outcome-based agent benchmark
Evaluate agents on final task outcomes with controlled environments and bounded resources. Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Recall: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. Identify one observation that would contradict your claim.

### Terms
Independent verifiers: Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Evaluate agents on final task outcomes with controlled environments and bounded resources. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The benchmark requires zero false successes when final task state is deliberately wrong. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Evaluate agents on final task outcomes with controlled environments and bounded resources.
Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.
Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.
Deliverables: Task harness and isolated fixtures; Outcome assertion suite and raw traces. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Agent evaluation / benchmark engineer. Use this scenario: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Review: Start with the task and permitted scope. Explain independent verifiers: Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately. Show the input and observed output, then address Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Task harness and isolated fixtures; Outcome assertion suite and raw traces. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

