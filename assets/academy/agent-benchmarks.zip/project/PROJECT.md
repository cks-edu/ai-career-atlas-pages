# Outcome-based agent benchmark

Career: Agent evaluation / benchmark engineer
Reviewed: 2026-10-22

Evaluate agents on final task outcomes with controlled environments and bounded resources.

## Prerequisites
Sandboxed execution, state validation, distributed jobs and statistics.

## Included starter versus your implementation
A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+; the scoring skeleton needs only the standard library.

```sh
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Compare a scripted baseline and an agent on identical initial states. Add CI for fixture integrity and outcome-check tests.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Task harness and isolated fixtures — artifact-1.md
2. Outcome assertion suite and raw traces — artifact-2.md
3. Benchmark card and comparison report — artifact-3.md

## Troubleshooting
- Missing predictions: keep them in the denominator.
- Metric disagrees with humans: inspect rubric validity before optimizing the model.
- Scores change: compare candidate, dataset and evaluator versions separately.

## Extension
Add human review for tasks where exact automated outcome checks are insufficient.

## Primary learning resources
- Python: https://docs.python.org/3/library/venv.html — Open source · local; Isolated environments and reproducible scripts.
- Git: https://git-scm.com/docs — Open source · local; Versioned changes, patches and reproducible source revisions.
- GitHub Actions: https://docs.github.com/en/actions — Commercial hosted service · usage limits; CI checks and reviewable build artifacts; paid usage may apply.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
