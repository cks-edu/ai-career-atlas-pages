# Task harness and isolated fixtures

Project: Outcome-based agent benchmark
Status: blank work product — not completed evidence

## Purpose and audience
Evaluate agents on final task outcomes with controlled environments and bounded resources.

## Required content
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.

## Failure evidence
Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
