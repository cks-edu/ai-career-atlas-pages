# Agent evaluation / benchmark engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Outcome-based agent tasks: Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

### Outcome-based agent tasks

Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded. In this role, work through: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A delivery is complete when the correct parcel reaches its destination, not when the driver describes the route.

Boundary: A final-state check may miss forbidden actions taken along the way.

Worked example: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Agent evaluation / benchmark engineer: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment.

Predict the worked case

Read this case without running a tool: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in outcome-based agent tasks.

Connect the concept to the role

Apply this rule: Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A final-state check may miss forbidden actions taken along the way.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies outcome-based agent tasks to this case: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Outcome-based agent tasks; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with outcome-based agent tasks. Use the glossary below, then write your prediction for: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent evaluation / benchmark engineer role interview. Explain outcome-based agent tasks using this case: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate outcome-based agent tasks to a system or workflow you know. Explain outcome-based agent tasks using this case: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain outcome-based agent tasks using this case: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment.

Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded. — Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded. A final-state check may miss forbidden actions taken along the way.

Sources:

Python: https://docs.python.org/3/library/venv.html

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

### Diagnose: The verifier believes the agent

The benchmark requires zero false successes when final task state is deliberately wrong. Three verifiers accept a success message even when the required final state is absent. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate final state using independent checks outside the editable agent workspace. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A delivery is complete when the correct parcel reaches its destination, not when the driver describes the route.

The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment.

Worked example: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate final state using independent checks outside the editable agent workspace.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Python (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The benchmark requires zero false successes when final task state is deliberately wrong. Three verifiers accept a success message even when the required final state is absent. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The benchmark requires zero false successes when final task state is deliberately wrong. Apply this toy-case rule manually: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An agent’s claim that it completed a task is not evidence. Success should be checked against the resulting state.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use a fictional file containing “Meeting: Tuesday”. The task is to change only Tuesday to Thursday.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after fixture and a checklist for independent verification.

Preparation · Try step 2

Write expected final content and checks that unrelated text stays unchanged.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after fixture and a checklist for independent verification.

Preparation · Try step 3

Review two claims: “Done” with the file unchanged, and the correct file with an empty explanation. Decide which result passes the content check.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after fixture and a checklist for independent verification.

Preparation · Explain and check your result

The unchanged file fails regardless of the agent’s claim; checking the result is separate from judging the explanation. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A before/after fixture and a checklist for independent verification. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The benchmark requires zero false successes when final task state is deliberately wrong. Apply this toy-case rule manually: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three verifiers accept a success message even when the required final state is absent. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three verifiers accept a success message even when the required final state is absent. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the verifier believes the agent. Use the glossary below, then write your prediction for: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate final state using independent checks outside the editable agent workspace. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent evaluation / benchmark engineer role interview. Explain diagnose: the verifier believes the agent using this case: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate final state using independent checks outside the editable agent workspace. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the verifier believes the agent to a system or workflow you know. Explain diagnose: the verifier believes the agent using this case: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate final state using independent checks outside the editable agent workspace. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Replay genuine success, fake success text and attempted verifier modification. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the verifier believes the agent using this case: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate final state using independent checks outside the editable agent workspace. State the evidence, one alternative and where the mental model stops.

Quiz: The verifier believes the agent: The benchmark requires zero false successes when final task state is deliberately wrong.

Change the acceptance rule after seeing an inconvenient result.

Validate final state using independent checks outside the editable agent workspace.

Omit failed cases and report only the successful demonstrations.

Reference: Validate final state using independent checks outside the editable agent workspace. — Validate final state using independent checks outside the editable agent workspace. Replay genuine success, fake success text and attempted verifier modification.

Sources:

Python: https://docs.python.org/3/library/venv.html

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Sandboxed execution, state validation, distributed jobs and statistics.

Terms:

Independent verifiers: Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Independent verifiers

Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately. In this role, work through: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An athlete must not be able to edit the scoreboard.

Boundary: A protected verifier can still contain bugs or incomplete criteria.

Worked example: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Sandboxed execution, state validation, distributed jobs and statistics.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Agent evaluation / benchmark engineer: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it.

Predict the worked case

Read this case without running a tool: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in independent verifiers.

Connect the concept to the role

Apply this rule: Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A protected verifier can still contain bugs or incomplete criteria.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies independent verifiers to this case: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Independent verifiers; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with independent verifiers. Use the glossary below, then write your prediction for: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent evaluation / benchmark engineer role interview. Explain independent verifiers using this case: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate independent verifiers to a system or workflow you know. Explain independent verifiers using this case: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain independent verifiers using this case: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it.

Treat a passing starter as proof of the whole role workflow.

Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately.

Ignore the failure because the tool produced an output.

Reference: Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately. — Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately. A protected verifier can still contain bugs or incomplete criteria.

Sources:

Python: https://docs.python.org/3/library/venv.html

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

### Integrate: Outcome-based agent benchmark

Evaluate agents on final task outcomes with controlled environments and bounded resources. Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures. In this role, work through: Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: An athlete must not be able to edit the scoreboard.

An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it.

Worked example: Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Evaluate agents on final task outcomes with controlled environments and bounded resources. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Evaluate agents on final task outcomes with controlled environments and bounded resources.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The benchmark requires zero false successes when final task state is deliberately wrong. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-intermediate-2.md: Task harness and isolated fixtures; Outcome assertion suite and raw traces. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: outcome-based agent benchmark. Use the glossary below, then write your prediction for: Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent evaluation / benchmark engineer role interview. Explain integrate: outcome-based agent benchmark using this case: Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: outcome-based agent benchmark to a system or workflow you know. Explain integrate: outcome-based agent benchmark using this case: Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. Identify one observation that would contradict your claim.

Interview: Explain integrate: outcome-based agent benchmark using this case: Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Outcome-based agent benchmark at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.

Reference: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. — Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.

Sources:

Python: https://docs.python.org/3/library/venv.html

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Repeatable benchmark execution: Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Repeatable benchmark execution

Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs. In this role, work through: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Every contestant starts the obstacle course from the same line.

Boundary: Deterministic fixtures may underrepresent open-ended real workflows.

Worked example: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Agent evaluation / benchmark engineer: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success.

Predict the worked case

Read this case without running a tool: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in repeatable benchmark execution.

Connect the concept to the role

Apply this rule: Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Deterministic fixtures may underrepresent open-ended real workflows.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies repeatable benchmark execution to this case: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Repeatable benchmark execution; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with repeatable benchmark execution. Use the glossary below, then write your prediction for: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent evaluation / benchmark engineer role interview. Explain repeatable benchmark execution using this case: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate repeatable benchmark execution to a system or workflow you know. Explain repeatable benchmark execution using this case: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain repeatable benchmark execution using this case: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs.

Reference: Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs. — Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs. Deterministic fixtures may underrepresent open-ended real workflows.

Sources:

Python: https://docs.python.org/3/library/venv.html

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

### Defend: Outcome-based agent benchmark

Evaluate agents on final task outcomes with controlled environments and bounded resources. Compare a scripted baseline and an agent on identical initial states. Add CI for fixture integrity and outcome-check tests. In this role, work through: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: Every contestant starts the obstacle course from the same line.

A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success.

Worked example: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); Git (Open source · local); GitHub Actions (Commercial hosted service · usage limits)

Evaluate agents on final task outcomes with controlled environments and bounded resources. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Evaluate agents on final task outcomes with controlled environments and bounded resources.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Compare a scripted baseline and an agent on identical initial states. Add CI for fixture integrity and outcome-check tests.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A reviewer must reproduce one result and identify which capabilities you implemented. Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-advanced-2.md: Task harness and isolated fixtures; Outcome assertion suite and raw traces; Benchmark card and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: outcome-based agent benchmark. Use the glossary below, then write your prediction for: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent evaluation / benchmark engineer role interview. Explain defend: outcome-based agent benchmark using this case: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: outcome-based agent benchmark to a system or workflow you know. Explain defend: outcome-based agent benchmark using this case: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. Identify one observation that would contradict your claim.

Interview: Explain defend: outcome-based agent benchmark using this case: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Outcome-based agent benchmark at this level?

Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area. — Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area. Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.

Sources:

Python: https://docs.python.org/3/library/venv.html

Git: https://git-scm.com/docs

GitHub Actions: https://docs.github.com/en/actions

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/
