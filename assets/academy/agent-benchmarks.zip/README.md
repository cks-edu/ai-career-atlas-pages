# Agent evaluation / benchmark engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Outcome-based agent tasks. An agent’s claim that it completed a task is not evidence. Success should be checked against the resulting state. Then try Define a file-edit success check. The three levels build toward Outcome-based agent benchmark. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Outcome-based agent tasks

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Outcome-based agent tasks
Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded.
Mental model: A delivery is complete when the correct parcel reaches its destination, not when the driver describes the route.
Boundary: A final-state check may miss forbidden actions taken along the way.
Worked example: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The verifier believes the agent
The benchmark requires zero false successes when final task state is deliberately wrong. Three verifiers accept a success message even when the required final state is absent. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate final state using independent checks outside the editable agent workspace.
Recall: Replay genuine success, fake success text and attempted verifier modification. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Outcome-based agent tasks: Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An agent’s claim that it completed a task is not evidence. Success should be checked against the resulting state.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional file containing “Meeting: Tuesday”. The task is to change only Tuesday to Thursday.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after fixture and a checklist for independent verification.

3. Try step 2
Write expected final content and checks that unrelated text stays unchanged.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after fixture and a checklist for independent verification.

4. Try step 3
Review two claims: “Done” with the file unchanged, and the correct file with an empty explanation. Decide which result passes the content check.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after fixture and a checklist for independent verification.

5. Explain and check your result
The unchanged file fails regardless of the agent’s claim; checking the result is separate from judging the explanation. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A before/after fixture and a checklist for independent verification. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The benchmark requires zero false successes when final task state is deliberately wrong. Apply this toy-case rule manually: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three verifiers accept a success message even when the required final state is absent. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Agent evaluation / benchmark engineer.
Use a fictional file containing “Meeting: Tuesday”. The task is to change only Tuesday to Thursday.
Write expected final content and checks that unrelated text stays unchanged.
Review two claims: “Done” with the file unchanged, and the correct file with an empty explanation. Decide which result passes the content check.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A before/after fixture and a checklist for independent verification. Include beginner-worksheet.md and your completed Agent benchmark integrity report.
Check: The unchanged file fails regardless of the agent’s claim; checking the result is separate from judging the explanation.

### Interview
Explain your beginner solution for Agent evaluation / benchmark engineer. Use this scenario: The benchmark requires zero false successes when final task state is deliberately wrong.
Review: Start with the task and permitted scope. Explain outcome-based agent tasks: Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded. Show the input and observed output, then address Validate final state using independent checks outside the editable agent workspace. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A before/after fixture and a checklist for independent verification. Include beginner-worksheet.md and your completed Agent benchmark integrity report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Independent verifiers

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Sandboxed execution, state validation, distributed jobs and statistics.

### Independent verifiers
Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately.
Mental model: An athlete must not be able to edit the scoreboard.
Boundary: A protected verifier can still contain bugs or incomplete criteria.
Worked example: An agent changes result.json to success without doing the task; the verifier reads the actual application state and rejects it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Outcome-based agent benchmark
Evaluate agents on final task outcomes with controlled environments and bounded resources. Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Recall: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. Identify one observation that would contradict your claim.

### Terms
Independent verifiers: Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Evaluate agents on final task outcomes with controlled environments and bounded resources. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The benchmark requires zero false successes when final task state is deliberately wrong. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Evaluate agents on final task outcomes with controlled environments and bounded resources.
Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.
Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.
Deliverables: Task harness and isolated fixtures; Outcome assertion suite and raw traces. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Agent evaluation / benchmark engineer. Use this scenario: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Review: Start with the task and permitted scope. Explain independent verifiers: Keep expected results and verifier logic outside the agent's writable workspace. Test false successes and unauthorized side effects deliberately. Show the input and observed output, then address Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Task harness and isolated fixtures; Outcome assertion suite and raw traces. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Repeatable benchmark execution

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Repeatable benchmark execution
Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs.
Mental model: Every contestant starts the obstacle course from the same line.
Boundary: Deterministic fixtures may underrepresent open-ended real workflows.
Worked example: A second run finds a ticket created by the first. Reset the fixture and rerun before counting it as a new success.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Outcome-based agent benchmark
Evaluate agents on final task outcomes with controlled environments and bounded resources. Compare a scripted baseline and an agent on identical initial states. Add CI for fixture integrity and outcome-check tests.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Recall: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. Identify one observation that would contradict your claim.

### Terms
Repeatable benchmark execution: Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Evaluate agents on final task outcomes with controlled environments and bounded resources. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Compare a scripted baseline and an agent on identical initial states. Add CI for fixture integrity and outcome-check tests.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Evaluate agents on final task outcomes with controlled environments and bounded resources.
Create ten tasks in a disposable local repository, each with initial files, allowed actions and a hidden outcome assertion. Use no real external accounts.
Adapt the evaluation starter to reset each task directory from a clean fixture and record tool calls, duration and final artifact hashes.
Implement deterministic outcome checks independent of the agent’s own success message. Set time, token and tool-call budgets and retain timeout failures.
Compare a scripted baseline and an agent on identical initial states. Add CI for fixture integrity and outcome-check tests.
Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment.
Add human review for tasks where exact automated outcome checks are insufficient.
Deliverables: Task harness and isolated fixtures; Outcome assertion suite and raw traces; Benchmark card and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A reviewer must reproduce one result and identify which capabilities you implemented. Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.

### Interview
Explain your advanced solution for Agent evaluation / benchmark engineer. Use this scenario: Create an agent output claiming success while leaving the file unchanged, then one that modifies the evaluator. Reject both and keep evaluator files outside the writable task area.
Review: Start with the task and permitted scope. Explain repeatable benchmark execution: Reset environments, preserve task versions and record action budgets. Compare repeated attempts and failures without allowing leftover state to help later runs. Show the input and observed output, then address Report verified task success, budget violations, repeated-run variance and forbidden side effects. Do not score tool-call count as task accomplishment. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Task harness and isolated fixtures; Outcome assertion suite and raw traces; Benchmark card and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Python — Open source · local
Isolated environments and reproducible scripts.
Alternative: A spreadsheet for manual evidence exercises, or another supported programming language for implementation; reproduce the same acceptance checks.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Git — Open source · local
Versioned changes, patches and reproducible source revisions.
Alternative: Mercurial is open source, but Git dominates many team workflows; GitHub and GitLab are hosting choices rather than Git replacements.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

GitHub Actions — Commercial hosted service · usage limits
CI checks and reviewable build artifacts; paid usage may apply.
Alternative: GitLab CI (open-core/commercial offerings) or Jenkins (open source); runners and compute still need operating resources.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Python: https://docs.python.org/3/library/venv.html
Git: https://git-scm.com/docs
GitHub Actions: https://docs.github.com/en/actions
Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
GitHub Actions: https://docs.github.com/en/actions
Kubernetes: https://kubernetes.io/docs/tutorials/
