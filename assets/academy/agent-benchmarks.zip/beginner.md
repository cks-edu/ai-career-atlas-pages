## beginner — Outcome-based agent tasks

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Outcome-based agent tasks
Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded.
Mental model: A delivery is complete when the correct parcel reaches its destination, not when the driver describes the route.
Boundary: A final-state check may miss forbidden actions taken along the way.
Worked example: The agent says it created a ticket; verify the expected ticket record and fields in a fresh task environment.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The verifier believes the agent
The benchmark requires zero false successes when final task state is deliberately wrong. Three verifiers accept a success message even when the required final state is absent. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate final state using independent checks outside the editable agent workspace.
Recall: Replay genuine success, fake success text and attempted verifier modification. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Outcome-based agent tasks: Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An agent’s claim that it completed a task is not evidence. Success should be checked against the resulting state.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional file containing “Meeting: Tuesday”. The task is to change only Tuesday to Thursday.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after fixture and a checklist for independent verification.

3. Try step 2
Write expected final content and checks that unrelated text stays unchanged.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after fixture and a checklist for independent verification.

4. Try step 3
Review two claims: “Done” with the file unchanged, and the correct file with an empty explanation. Decide which result passes the content check.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after fixture and a checklist for independent verification.

5. Explain and check your result
The unchanged file fails regardless of the agent’s claim; checking the result is separate from judging the explanation. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A before/after fixture and a checklist for independent verification. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The benchmark requires zero false successes when final task state is deliberately wrong. Apply this toy-case rule manually: Review when false_successes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three verifiers accept a success message even when the required final state is absent. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Agent evaluation / benchmark engineer.
Use a fictional file containing “Meeting: Tuesday”. The task is to change only Tuesday to Thursday.
Write expected final content and checks that unrelated text stays unchanged.
Review two claims: “Done” with the file unchanged, and the correct file with an empty explanation. Decide which result passes the content check.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A before/after fixture and a checklist for independent verification. Include beginner-worksheet.md and your completed Agent benchmark integrity report.
Check: The unchanged file fails regardless of the agent’s claim; checking the result is separate from judging the explanation.

### Interview
Explain your beginner solution for Agent evaluation / benchmark engineer. Use this scenario: The benchmark requires zero false successes when final task state is deliberately wrong.
Review: Start with the task and permitted scope. Explain outcome-based agent tasks: Specify the final state an agent must achieve and the permitted actions. A plausible narrative or a long tool trace is not proof that the task succeeded. Show the input and observed output, then address Validate final state using independent checks outside the editable agent workspace. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A before/after fixture and a checklist for independent verification. Include beginner-worksheet.md and your completed Agent benchmark integrity report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

