# IT Support / Service Desk — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Layered diagnosis: Check local process, address resolution, connection and application response separately.

Apply layered diagnosis in IT Support / Service Desk: Use the concept to complete this role exercise: Record the symptom, environment and first safe diagnostic

Symptoms and safe triage: Start with the user's failed action, scope and time before changing settings. Separate what was observed from what is suspected so another technician can continue the investigation.

### Layered diagnosis

Check local process, address resolution, connection and application response separately. In this role, work through: One user gets HTTP 404 while another cannot connect at all. The practical workshop develops this into: Run diagnose.py and open ticket-template.md. Record OS, command, exact error and whether one or several users are affected. Compare /health with /missing.

Mental model: Follow a letter from address book to road to reception desk.

Boundary: Layers interact; one successful check does not establish every other layer.

Role application: A doctor records the symptoms before prescribing a treatment.

Start with the user's failed action, scope and time before changing settings. Separate what was observed from what is suspected so another technician can continue the investigation.

Worked example: One user gets HTTP 404 while another cannot connect at all.

Shared foundation example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: OS networking tools and a ticket workbook (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for IT Support / Service Desk: One user gets HTTP 404 while another cannot connect at all.

Predict the worked case

Read this case without running a tool: One user gets HTTP 404 while another cannot connect at all. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in layered diagnosis.

Connect the concept to the role

Apply this rule: Check local process, address resolution, connection and application response separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Layers interact; one successful check does not establish every other layer.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies layered diagnosis to this case: One user gets HTTP 404 while another cannot connect at all. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: One user gets HTTP 404 while another cannot connect at all. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Layered diagnosis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with layered diagnosis. Use the glossary below, then write your prediction for: One user gets HTTP 404 while another cannot connect at all. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the IT Support / Service Desk role interview. Explain layered diagnosis using this case: One user gets HTTP 404 while another cannot connect at all. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate layered diagnosis to a system or workflow you know. Explain layered diagnosis using this case: One user gets HTTP 404 while another cannot connect at all. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is a 404 different from connection refused?

Interview: Explain layered diagnosis using this case: One user gets HTTP 404 while another cannot connect at all. State the evidence, one alternative and where the mental model stops.

Quiz: After the Symptoms and safe triage rehearsal, check this foundation: A request returns HTTP 500 rather than connection refused. Which next step best follows the evidence?

Inspect application and upstream error evidence for that request.

Assume DNS failed before any server response.

Immediately rewrite the local firewall policy.

Reference: Inspect application and upstream error evidence for that request. — An HTTP response points beyond the basic connection boundary; identify its origin before diagnosing the application.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Symptoms and safe triage

Start with the user's failed action, scope and time before changing settings. Separate what was observed from what is suspected so another technician can continue the investigation. In this role, work through: One user gets HTTP 404 while another cannot connect at all. The practical workshop develops this into: Run diagnose.py and open ticket-template.md. Record OS, command, exact error and whether one or several users are affected. Compare /health with /missing.

Mental model: A doctor records the symptoms before prescribing a treatment.

Boundary: Do not reset network settings simply because a web page failed; locate the failing layer.

Worked example: One user gets HTTP 404 while another cannot connect at all.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OS networking tools and a ticket workbook (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required IT Support / Service Desk workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run diagnose.py and open ticket-template.md. Record OS, command, exact error and whether one or several users are affected. Compare /health with /missing.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

One user gets HTTP 404 while another cannot connect at all. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run diagnose.py and open ticket-template.md. Record OS, command, exact error and whether one or several users are affected. Compare /health with /missing.

```
python3 diagnose.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A 404 is classified as an application response rather than failed connectivity.

Role workshop · debug and verify

Do not reset network settings simply because a web page failed; locate the failing layer. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save support ticket with a layered evidence table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A 404 is classified as an application response rather than failed connectivity.

Expected: A 404 is classified as an application response rather than failed connectivity.

Troubleshoot: The role exercise differs from the prediction: Do not reset network settings simply because a web page failed; locate the failing layer.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: support ticket with a layered evidence table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with symptoms and safe triage. Use the glossary below, then write your prediction for: One user gets HTTP 404 while another cannot connect at all. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the IT Support / Service Desk role interview. Explain symptoms and safe triage using this case: One user gets HTTP 404 while another cannot connect at all. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate symptoms and safe triage to a system or workflow you know. Explain symptoms and safe triage using this case: One user gets HTTP 404 while another cannot connect at all. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not reset network settings simply because a web page failed; locate the failing layer.

Interview: Explain symptoms and safe triage using this case: One user gets HTTP 404 while another cannot connect at all. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? One user gets HTTP 404 while another cannot connect at all.

A 404 is classified as an application response rather than failed connectivity.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A 404 is classified as an application response rather than failed connectivity. — Start with the user's failed action, scope and time before changing settings. Separate what was observed from what is suspected so another technician can continue the investigation. A 404 is classified as an application response rather than failed connectivity.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Least privilege and change scope: Use only the rights required for the task and record exactly what you intend to change.

Apply least privilege and change scope in IT Support / Service Desk: Use the concept to complete this role exercise: Distinguish DNS, connection and HTTP-path failures

Escalation and change control: Escalate with evidence and a clear question. A change should have an owner, scope, expected result and rollback; repeating random fixes destroys diagnostic context.

### Least privilege and change scope

Use only the rights required for the task and record exactly what you intend to change. In this role, work through: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. The practical workshop develops this into: Create a timeline of three safe checks, write the next team's question and propose one reversible lab-only change. Record approval assumptions and a rollback trigger.

Mental model: Borrow a key to one room rather than the master key.

Boundary: Permissions cannot replace backups or ownership of a change.

Role application: Pass the next technician a labeled map, not a bag of guesses.

Escalate with evidence and a clear question. A change should have an owner, scope, expected result and rollback; repeating random fixes destroys diagnostic context.

Worked example: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause.

Shared foundation example: Run the loopback diagnostic without changing DNS or firewall settings.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: OS networking tools and a ticket workbook (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for IT Support / Service Desk: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause.

Predict the worked case

Read this case without running a tool: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in least privilege and change scope.

Connect the concept to the role

Apply this rule: Use only the rights required for the task and record exactly what you intend to change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Permissions cannot replace backups or ownership of a change.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies least privilege and change scope to this case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Least privilege and change scope; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with least privilege and change scope. Use the glossary below, then write your prediction for: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the IT Support / Service Desk role interview. Explain least privilege and change scope using this case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate least privilege and change scope to a system or workflow you know. Explain least privilege and change scope using this case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What information should a change ticket contain before modifying a network setting?

Interview: Explain least privilege and change scope using this case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. State the evidence, one alternative and where the mental model stops.

Quiz: After the Escalation and change control rehearsal, check this foundation: A diagnostic only needs to read a local log. Which access is appropriate?

Permanent administrator rights for convenience.

The narrow read permission required for that log.

Write access to every service configuration.

Reference: The narrow read permission required for that log. — Match permissions to the task. Extra privileges add risk without evidence that they are required.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Escalation and change control

Escalate with evidence and a clear question. A change should have an owner, scope, expected result and rollback; repeating random fixes destroys diagnostic context. In this role, work through: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. The practical workshop develops this into: Create a timeline of three safe checks, write the next team's question and propose one reversible lab-only change. Record approval assumptions and a rollback trigger.

Mental model: Pass the next technician a labeled map, not a bag of guesses.

Boundary: Multiple simultaneous changes prevent attribution; change one variable and record it.

Worked example: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OS networking tools and a ticket workbook (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required IT Support / Service Desk workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a timeline of three safe checks, write the next team's question and propose one reversible lab-only change. Record approval assumptions and a rollback trigger.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a timeline of three safe checks, write the next team's question and propose one reversible lab-only change. Record approval assumptions and a rollback trigger.

```
python3 diagnose.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A recipient can reproduce the symptom and understand what remains unknown.

Role workshop · debug and verify

Multiple simultaneous changes prevent attribution; change one variable and record it. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save escalation note and change proposal. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A recipient can reproduce the symptom and understand what remains unknown.

Expected: A recipient can reproduce the symptom and understand what remains unknown.

Troubleshoot: The role exercise differs from the prediction: Multiple simultaneous changes prevent attribution; change one variable and record it.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: escalation note and change proposal; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with escalation and change control. Use the glossary below, then write your prediction for: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the IT Support / Service Desk role interview. Explain escalation and change control using this case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate escalation and change control to a system or workflow you know. Explain escalation and change control using this case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Multiple simultaneous changes prevent attribution; change one variable and record it.

Interview: Explain escalation and change control using this case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause.

Ignore the failing case and keep only the successful screenshot.

A recipient can reproduce the symptom and understand what remains unknown.

Treat any successful command as proof that all business and access rules passed.

Reference: A recipient can reproduce the symptom and understand what remains unknown. — Escalate with evidence and a clear question. A change should have an owner, scope, expected result and rollback; repeating random fixes destroys diagnostic context. A recipient can reproduce the symptom and understand what remains unknown.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Recovery evidence: A recovery is complete when the original user operation works and important side effects have been checked.

Apply recovery evidence in IT Support / Service Desk: Use the concept to complete this role exercise: Write a recovery and escalation note another technician can reproduce

Knowledge-base verification: A support article should be tested by a new reader and include expected results, branching diagnosis and a safe stopping point. Resolution means the original task works.

### Recovery evidence

A recovery is complete when the original user operation works and important side effects have been checked. In this role, work through: A user must open the intended task page after a corrected URL, not merely receive ping replies. The practical workshop develops this into: Turn the lab incident into a guide with success, 404 and connection-refused branches. Follow it from a fresh terminal and record ambiguities and the final user check.

Mental model: Repair a tap, then test water flow and inspect for leaks.

Boundary: One successful retry does not establish long-term reliability.

Role application: A recipe must explain what cooked food looks like, not only when to turn on the oven.

A support article should be tested by a new reader and include expected results, branching diagnosis and a safe stopping point. Resolution means the original task works.

Worked example: A user must open the intended task page after a corrected URL, not merely receive ping replies.

Shared foundation example: After correcting a path, record HTTP status, timestamp and the user-visible result.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: OS networking tools and a ticket workbook (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for IT Support / Service Desk: A user must open the intended task page after a corrected URL, not merely receive ping replies.

Predict the worked case

Read this case without running a tool: A user must open the intended task page after a corrected URL, not merely receive ping replies. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in recovery evidence.

Connect the concept to the role

Apply this rule: A recovery is complete when the original user operation works and important side effects have been checked. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: One successful retry does not establish long-term reliability.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies recovery evidence to this case: A user must open the intended task page after a corrected URL, not merely receive ping replies. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A user must open the intended task page after a corrected URL, not merely receive ping replies. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Recovery evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with recovery evidence. Use the glossary below, then write your prediction for: A user must open the intended task page after a corrected URL, not merely receive ping replies. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the IT Support / Service Desk role interview. Explain recovery evidence using this case: A user must open the intended task page after a corrected URL, not merely receive ping replies. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate recovery evidence to a system or workflow you know. Explain recovery evidence using this case: A user must open the intended task page after a corrected URL, not merely receive ping replies. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would you record for the next person handling the incident?

Interview: Explain recovery evidence using this case: A user must open the intended task page after a corrected URL, not merely receive ping replies. State the evidence, one alternative and where the mental model stops.

Quiz: After the Knowledge-base verification rehearsal, check this foundation: A repair command succeeds after an outage. Which check most directly tests recovery?

Confirm that a process exists.

Confirm the runbook file was opened.

Repeat the original user operation and inspect important side effects.

Reference: Repeat the original user operation and inspect important side effects. — Recovery must be measured at the affected operation, not inferred solely from a successful repair command.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Knowledge-base verification

A support article should be tested by a new reader and include expected results, branching diagnosis and a safe stopping point. Resolution means the original task works. In this role, work through: A user must open the intended task page after a corrected URL, not merely receive ping replies. The practical workshop develops this into: Turn the lab incident into a guide with success, 404 and connection-refused branches. Follow it from a fresh terminal and record ambiguities and the final user check.

Mental model: A recipe must explain what cooked food looks like, not only when to turn on the oven.

Boundary: A workaround that hides the symptom may not resolve the cause; label it explicitly.

Worked example: A user must open the intended task page after a corrected URL, not merely receive ping replies.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OS networking tools and a ticket workbook (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required IT Support / Service Desk workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Turn the lab incident into a guide with success, 404 and connection-refused branches. Follow it from a fresh terminal and record ambiguities and the final user check.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A user must open the intended task page after a corrected URL, not merely receive ping replies. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Turn the lab incident into a guide with success, 404 and connection-refused branches. Follow it from a fresh terminal and record ambiguities and the final user check.

```
python3 diagnose.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A reproducible article with escalation criteria and no sensitive account data.

Role workshop · debug and verify

A workaround that hides the symptom may not resolve the cause; label it explicitly. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save knowledge-base article and verification transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A reproducible article with escalation criteria and no sensitive account data.

Expected: A reproducible article with escalation criteria and no sensitive account data.

Troubleshoot: The role exercise differs from the prediction: A workaround that hides the symptom may not resolve the cause; label it explicitly.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: knowledge-base article and verification transcript; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with knowledge-base verification. Use the glossary below, then write your prediction for: A user must open the intended task page after a corrected URL, not merely receive ping replies. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the IT Support / Service Desk role interview. Explain knowledge-base verification using this case: A user must open the intended task page after a corrected URL, not merely receive ping replies. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate knowledge-base verification to a system or workflow you know. Explain knowledge-base verification using this case: A user must open the intended task page after a corrected URL, not merely receive ping replies. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A workaround that hides the symptom may not resolve the cause; label it explicitly.

Interview: Explain knowledge-base verification using this case: A user must open the intended task page after a corrected URL, not merely receive ping replies. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A user must open the intended task page after a corrected URL, not merely receive ping replies.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A reproducible article with escalation criteria and no sensitive account data.

Reference: A reproducible article with escalation criteria and no sensitive account data. — A support article should be tested by a new reader and include expected results, branching diagnosis and a safe stopping point. Resolution means the original task works. A reproducible article with escalation criteria and no sensitive account data.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
