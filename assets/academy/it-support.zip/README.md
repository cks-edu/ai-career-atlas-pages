# IT Support / Service Desk

Software Engineering

Start with symptoms and safe triage. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward knowledge-base article and verification transcript.

## beginner

Run diagnose.py and open ticket-template.md. Record OS, command, exact error and whether one or several users are affected. Compare /health with /missing.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Layered diagnosis
Check local process, address resolution, connection and application response separately.
Mental model: Follow a letter from address book to road to reception desk.
Limit: Layers interact; one successful check does not establish every other layer.
Example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path.
Recall: Why is a 404 different from connection refused?

### Symptoms and safe triage
Start with the user's failed action, scope and time before changing settings. Separate what was observed from what is suspected so another technician can continue the investigation.
Mental model: A doctor records the symptoms before prescribing a treatment.
Limit: Do not reset network settings simply because a web page failed; locate the failing layer.
Example: One user gets HTTP 404 while another cannot connect at all.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not reset network settings simply because a web page failed; locate the failing layer.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
One user gets HTTP 404 while another cannot connect at all. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run diagnose.py and open ticket-template.md. Record OS, command, exact error and whether one or several users are affected. Compare /health with /missing.
```
python3 diagnose.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A 404 is classified as an application response rather than failed connectivity.

6. Role workshop · debug and verify
Do not reset network settings simply because a web page failed; locate the failing layer. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save support ticket with a layered evidence table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A 404 is classified as an application response rather than failed connectivity.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Symptoms and safe triage: Do not reset network settings simply because a web page failed; locate the failing layer.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: support ticket with a layered evidence table
A 404 is classified as an application response rather than failed connectivity.

Interview: Work through this IT Support / Service Desk case: One user gets HTTP 404 while another cannot connect at all. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Start with the user's failed action, scope and time before changing settings. Separate what was observed from what is suspected so another technician can continue the investigation. Expected evidence: A 404 is classified as an application response rather than failed connectivity. Diagnosis: Do not reset network settings simply because a web page failed; locate the failing layer. State the limits of the mental model: A doctor records the symptoms before prescribing a treatment.

Resume: Built support ticket with a layered evidence table using OS networking tools and a ticket workbook; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create a timeline of three safe checks, write the next team's question and propose one reversible lab-only change. Record approval assumptions and a rollback trigger.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Least privilege and change scope
Use only the rights required for the task and record exactly what you intend to change.
Mental model: Borrow a key to one room rather than the master key.
Limit: Permissions cannot replace backups or ownership of a change.
Example: Run the loopback diagnostic without changing DNS or firewall settings.
Recall: What information should a change ticket contain before modifying a network setting?

### Escalation and change control
Escalate with evidence and a clear question. A change should have an owner, scope, expected result and rollback; repeating random fixes destroys diagnostic context.
Mental model: Pass the next technician a labeled map, not a bag of guesses.
Limit: Multiple simultaneous changes prevent attribution; change one variable and record it.
Example: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Multiple simultaneous changes prevent attribution; change one variable and record it.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a timeline of three safe checks, write the next team's question and propose one reversible lab-only change. Record approval assumptions and a rollback trigger.
```
python3 diagnose.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A recipient can reproduce the symptom and understand what remains unknown.

6. Role workshop · debug and verify
Multiple simultaneous changes prevent attribution; change one variable and record it. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save escalation note and change proposal. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A recipient can reproduce the symptom and understand what remains unknown.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Escalation and change control: Multiple simultaneous changes prevent attribution; change one variable and record it.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: escalation note and change proposal
A recipient can reproduce the symptom and understand what remains unknown.

Interview: Work through this IT Support / Service Desk case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Escalate with evidence and a clear question. A change should have an owner, scope, expected result and rollback; repeating random fixes destroys diagnostic context. Expected evidence: A recipient can reproduce the symptom and understand what remains unknown. Diagnosis: Multiple simultaneous changes prevent attribution; change one variable and record it. State the limits of the mental model: Pass the next technician a labeled map, not a bag of guesses.

Resume: Built escalation note and change proposal using OS networking tools and a ticket workbook; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Turn the lab incident into a guide with success, 404 and connection-refused branches. Follow it from a fresh terminal and record ambiguities and the final user check.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Recovery evidence
A recovery is complete when the original user operation works and important side effects have been checked.
Mental model: Repair a tap, then test water flow and inspect for leaks.
Limit: One successful retry does not establish long-term reliability.
Example: After correcting a path, record HTTP status, timestamp and the user-visible result.
Recall: What would you record for the next person handling the incident?

### Knowledge-base verification
A support article should be tested by a new reader and include expected results, branching diagnosis and a safe stopping point. Resolution means the original task works.
Mental model: A recipe must explain what cooked food looks like, not only when to turn on the oven.
Limit: A workaround that hides the symptom may not resolve the cause; label it explicitly.
Example: A user must open the intended task page after a corrected URL, not merely receive ping replies.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A workaround that hides the symptom may not resolve the cause; label it explicitly.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A user must open the intended task page after a corrected URL, not merely receive ping replies. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Turn the lab incident into a guide with success, 404 and connection-refused branches. Follow it from a fresh terminal and record ambiguities and the final user check.
```
python3 diagnose.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A reproducible article with escalation criteria and no sensitive account data.

6. Role workshop · debug and verify
A workaround that hides the symptom may not resolve the cause; label it explicitly. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save knowledge-base article and verification transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A reproducible article with escalation criteria and no sensitive account data.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Knowledge-base verification: A workaround that hides the symptom may not resolve the cause; label it explicitly.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: knowledge-base article and verification transcript
A reproducible article with escalation criteria and no sensitive account data.

Interview: Work through this IT Support / Service Desk case: A user must open the intended task page after a corrected URL, not merely receive ping replies. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A support article should be tested by a new reader and include expected results, branching diagnosis and a safe stopping point. Resolution means the original task works. Expected evidence: A reproducible article with escalation criteria and no sensitive account data. Diagnosis: A workaround that hides the symptom may not resolve the cause; label it explicitly. State the limits of the mental model: A recipe must explain what cooked food looks like, not only when to turn on the oven.

Resume: Built knowledge-base article and verification transcript using OS networking tools and a ticket workbook; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting
Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html
Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
