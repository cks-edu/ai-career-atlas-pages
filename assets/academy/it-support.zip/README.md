# IT Support / Service Desk

Software Engineering

Begin with layered diagnosis. Record the symptom, environment and first safe diagnostic. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Record the symptom, environment and first safe diagnostic

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required.

### Layered diagnosis
Check local process, address resolution, connection and application response separately.
Mental model: Follow a letter from address book to road to reception desk.
Limit: Layers interact; one successful check does not establish every other layer.
Example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path.
Recall: Why is a 404 different from connection refused?

### Apply layered diagnosis in IT Support / Service Desk
Use the concept to complete this role exercise: Record the symptom, environment and first safe diagnostic
Mental model: Follow a letter from address book to road to reception desk.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py beginner
```
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Record the symptom, environment and first safe diagnostic
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: it-support-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Record the symptom, environment and first safe diagnostic? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Check local process, address resolution, connection and application response separately. For this role, explicitly address: Record the symptom, environment and first safe diagnostic.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Distinguish DNS, connection and HTTP-path failures

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required.

### Least privilege and change scope
Use only the rights required for the task and record exactly what you intend to change.
Mental model: Borrow a key to one room rather than the master key.
Limit: Permissions cannot replace backups or ownership of a change.
Example: Run the loopback diagnostic without changing DNS or firewall settings.
Recall: What information should a change ticket contain before modifying a network setting?

### Apply least privilege and change scope in IT Support / Service Desk
Use the concept to complete this role exercise: Distinguish DNS, connection and HTTP-path failures
Mental model: Borrow a key to one room rather than the master key.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Run the loopback diagnostic without changing DNS or firewall settings. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py intermediate
```
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Distinguish DNS, connection and HTTP-path failures
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: it-support-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Distinguish DNS, connection and HTTP-path failures? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Use only the rights required for the task and record exactly what you intend to change. For this role, explicitly address: Distinguish DNS, connection and HTTP-path failures.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Write a recovery and escalation note another technician can reproduce

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required.

### Recovery evidence
A recovery is complete when the original user operation works and important side effects have been checked.
Mental model: Repair a tap, then test water flow and inspect for leaks.
Limit: One successful retry does not establish long-term reliability.
Example: After correcting a path, record HTTP status, timestamp and the user-visible result.
Recall: What would you record for the next person handling the incident?

### Apply recovery evidence in IT Support / Service Desk
Use the concept to complete this role exercise: Write a recovery and escalation note another technician can reproduce
Mental model: Repair a tap, then test water flow and inspect for leaks.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: After correcting a path, record HTTP status, timestamp and the user-visible result. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py advanced
```
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Write a recovery and escalation note another technician can reproduce
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: it-support-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Write a recovery and escalation note another technician can reproduce? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A recovery is complete when the original user operation works and important side effects have been checked. For this role, explicitly address: Write a recovery and escalation note another technician can reproduce.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting
Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html
Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
