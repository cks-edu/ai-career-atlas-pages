# IT Support / Service Desk — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Symptoms and safe triage

Start with the user's failed action, scope and time before changing settings. Separate what was observed from what is suspected so another technician can continue the investigation.
Mental model: A doctor records the symptoms before prescribing a treatment.
Case: One user gets HTTP 404 while another cannot connect at all.
Task: Run diagnose.py and open ticket-template.md. Record OS, command, exact error and whether one or several users are affected. Compare /health with /missing.
Acceptance: A 404 is classified as an application response rather than failed connectivity.
Troubleshooting: Do not reset network settings simply because a web page failed; locate the failing layer.
Deliverable: support ticket with a layered evidence table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Escalation and change control

Escalate with evidence and a clear question. A change should have an owner, scope, expected result and rollback; repeating random fixes destroys diagnostic context.
Mental model: Pass the next technician a labeled map, not a bag of guesses.
Case: A working loopback health check and failed remote connection narrow the investigation but do not identify the remote cause.
Task: Create a timeline of three safe checks, write the next team's question and propose one reversible lab-only change. Record approval assumptions and a rollback trigger.
Acceptance: A recipient can reproduce the symptom and understand what remains unknown.
Troubleshooting: Multiple simultaneous changes prevent attribution; change one variable and record it.
Deliverable: escalation note and change proposal

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Knowledge-base verification

A support article should be tested by a new reader and include expected results, branching diagnosis and a safe stopping point. Resolution means the original task works.
Mental model: A recipe must explain what cooked food looks like, not only when to turn on the oven.
Case: A user must open the intended task page after a corrected URL, not merely receive ping replies.
Task: Turn the lab incident into a guide with success, 404 and connection-refused branches. Follow it from a fresh terminal and record ambiguities and the final user check.
Acceptance: A reproducible article with escalation criteria and no sensitive account data.
Troubleshooting: A workaround that hides the symptom may not resolve the cause; label it explicitly.
Deliverable: knowledge-base article and verification transcript

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
