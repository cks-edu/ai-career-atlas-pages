## beginner — Experiment lineage

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Experiment lineage
Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited.
Mental model: A recipe card records ingredients, oven settings and the finished batch.
Boundary: A tracking system cannot recover inputs that were never versioned.
Worked example: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Training results cannot be reproduced
Every promoted model must reference both its dataset version and code revision. Count missing references. Three candidates lack sufficient lineage for reproducible promotion. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked.
Recall: Rebuild a candidate from its recorded inputs and compare declared evaluation tolerance. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Experiment lineage: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A model learns from training examples; evaluation examples check how it behaves on unseen data. Information from the future must not be used to predict the past.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine predicting whether a package arrives late at dispatch time. List dispatch time, destination, promised date, actual arrival date and final complaint outcome.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

3. Try step 2
Mark which fields are known at dispatch and which become available later.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

4. Try step 3
Sketch a split that trains on earlier shipments and checks later shipments.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

5. Explain and check your result
Actual arrival and final complaints are excluded from prediction inputs; the target can still use arrival later to measure lateness. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A feature-availability table and a time-based evaluation plan. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every promoted model must reference both its dataset version and code revision. Count missing references. Apply this toy-case rule manually: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three candidates lack sufficient lineage for reproducible promotion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to MLOps / ML platform engineer.
Imagine predicting whether a package arrives late at dispatch time. List dispatch time, destination, promised date, actual arrival date and final complaint outcome.
Mark which fields are known at dispatch and which become available later.
Sketch a split that trains on earlier shipments and checks later shipments.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A feature-availability table and a time-based evaluation plan. Include beginner-worksheet.md and your completed Model promotion evidence manifest.
Check: Actual arrival and final complaints are excluded from prediction inputs; the target can still use arrival later to measure lateness.

### Interview
Explain your beginner solution for MLOps / ML platform engineer. Use this scenario: Every promoted model must reference both its dataset version and code revision. Count missing references.
Review: Start with the task and permitted scope. Explain experiment lineage: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. Show the input and observed output, then address Block promotion until immutable code, data and model artifacts are linked. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A feature-availability table and a time-based evaluation plan. Include beginner-worksheet.md and your completed Model promotion evidence manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

