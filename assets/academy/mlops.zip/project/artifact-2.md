# CI promotion gate with rejected candidate evidence

Project: Reproducible model promotion pipeline
Status: blank work product — not completed evidence

## Purpose and audience
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.

## Required content
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

## Failure evidence
Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
