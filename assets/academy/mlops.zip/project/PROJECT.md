# Reproducible model promotion pipeline

Career: MLOps / ML platform engineer
Reviewed: 2026-10-22

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.

## Prerequisites
Build Python/SQL fluency, basic probability and statistics, supervised learning concepts and reproducible software environments. DevOps skills help, but cannot substitute for understanding leakage and validation.

## Included starter versus your implementation
A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. MLflow experiment and reproducible training code — artifact-1.md
2. CI promotion gate with rejected candidate evidence — artifact-2.md
3. Model card and rollback procedure — artifact-3.md

## Troubleshooting
- Poor metrics: inspect class balance and split construction before tuning.
- Too-good metrics: check duplicate groups and target-derived features.
- Changed results: compare package versions, seeds and preprocessing.

## Extension
Serve the approved artifact in a local container and test schema drift before considering a cloud endpoint.

## Primary learning resources
- scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html — Open source · CPU; Pipelines, baselines, data splits and statistical evaluation.
- MLflow: https://mlflow.org/docs/latest/ml/tracking/quickstart/ — Open source · hosted offerings optional; Record experiments, parameters and evaluation artifacts.
- GitHub Actions: https://docs.github.com/en/actions — Commercial hosted service · usage limits; CI checks and reviewable build artifacts; paid usage may apply.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
