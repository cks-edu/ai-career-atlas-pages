# MLflow experiment and reproducible training code

Project: Reproducible model promotion pipeline
Status: blank work product — not completed evidence

## Purpose and audience
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.

## Required content
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

## Failure evidence
Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
