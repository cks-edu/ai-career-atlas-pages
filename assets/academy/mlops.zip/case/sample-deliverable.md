# SAMPLE — Model promotion evidence manifest
Role: MLOps / ML platform engineer
Case: Training results cannot be reproduced
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
Every promoted model must reference both its dataset version and code revision. Count missing references.

## Evidence table
| Record | missing_lineage (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 1 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three candidates lack sufficient lineage for reproducible promotion.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Block promotion until immutable code, data and model artifacts are linked.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in mlops / ml platform engineer.
Before release: Rebuild a candidate from its recorded inputs and compare declared evaluation tolerance.

## Design choice and trade-off
Version training inputs and evaluation datasets; promote immutable artifacts after independent checks.
More lineage metadata requires discipline but is cheaper than reconstructing an unexplained production model.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Train, version and promote a small model: Record data and code lineage plus the split strategy. Demonstrate a rejected promotion. Describe why repeated tuning on this holdout would contaminate evaluation.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
