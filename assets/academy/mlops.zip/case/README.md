# MLOps / ML platform engineer — Training results cannot be reproduced

Local synthetic evidence-and-decision lab. The Python replay tests a numeric contract; it does not call a model, run a GPU workload, deploy cloud infrastructure or validate a real business decision.

## Brief
Every promoted model must reference both its dataset version and code revision. Count missing references.

## Contract
Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard.

## Setup
Extract this ZIP into a new empty folder. Open a terminal there for the optional Python replay. On macOS/Linux use python3; on Windows use py -3 instead. Python 3.9+; standard library only. No installation commands or paid resources. Spreadsheet/browser learners can complete the same table and memo without Python.

## 1. Set up and define the contract
Read the brief and model promotion evidence manifest template. Restate the acceptance rule in your own words, including its units. Download and extract the pack into a new folder; open a terminal in that folder. Python 3.9+ is sufficient and there are no external dependencies.

Exit check: You can distinguish the case contract from a general industry rule.

```sh
python3 --version
```

## 2. Inspect the evidence before checking the answer
Read evidence.csv. Make a five-row decision table using missing_lineage in count. Mark each record as review or within_demo_bound. Explain what a value exactly on the threshold means.

Exit check: All five records have a decision and an evidence-based reason; keep this first attempt.

```sh
python3 analyze.py
```

## 3. Reproduce and repair the broken review rule
The supplied rule uses 3 and misses the case failures. Use the threshold and comparison controls, or edit policy.json locally, to match the stated contract. Do not edit the evidence or answer contract to make a test pass. Block promotion until immutable code, data and model artifacts are linked. The threshold edit repairs only this replay, not the underlying system.

Exit check: Run Check policy. The fixture and boundary cases must agree with the contract.

```sh
python3 verify.py
python3 analyze.py
```

## 4. Write the role-specific deliverable
Complete the draft template as model promotion evidence manifest. Cite record IDs, state your decision, name a fictional accountable owner and distinguish observations from causal hypotheses. Address this trade-off: More lineage metadata requires discipline but is cheaper than reconstructing an unexplained production model.

Exit check: A reviewer can trace the recommendation to evidence and identify who must act.

## 5. Rehearse verification and challenge an assumption
Rebuild a candidate from its recorded inputs and compare declared evaluation tolerance. Add one new example on each side of the boundary and one exactly at it. Explain how missing or unreliable evidence should be handled. For this lab, an absent numeric field is an error, not an automatic pass.

Exit check: Document expected results, one rejected alternative and a condition that reopens the finding.

```sh
python3 verify.py
```

## 6. Compare, revise and present
Reveal the sample only after drafting. Compare the evidence table, decision, trade-off and limitations; revise your own artifact rather than copying it. Present a two-minute explanation. Then extend the work toward: Train, version and promote a small model — Read dataset, fit and train. The label is x > 0; seed 42 and disjoint 90/30 rows make the exercise reproducible..

Exit check: Export your notes and compare with a peer. Self-checkmarks do not certify the written deliverable.

## Expected execution
The original policy deliberately reports zero reviews; verify.py exits nonzero on the fixture and boundary checks. After repair, the report lists 3 review cases and all four tests pass. The report prints to standard output and does not overwrite your files.

## Troubleshooting
- Missing file: open the terminal in the extracted pack directory.
- Python missing: use the in-browser exercise; install Python only from its official distribution if you choose the local route.
- JSON error: use double quotes, numeric threshold and no trailing comma.
- Fixture passes but boundary fails: distinguish > from >= and keep the stated units.
- Missing evidence: reject the malformed record for review; do not silently treat missing as zero.

## Files and answer disclosure
policy.json is the intentionally broken rule; contract.json contains the check oracle. sample-deliverable.md is the worked answer. Keep them closed until you have made an attempt. learner-deliverable.md is your editable template. In-browser notes are separate from these local files.

## Sources
- MLflow: https://mlflow.org/docs/latest/
- Kubernetes: https://kubernetes.io/docs/tutorials/
- GitHub Actions: https://docs.github.com/en/actions
