## intermediate — Promotion gates

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build Python/SQL fluency, basic probability and statistics, supervised learning concepts and reproducible software environments. DevOps skills help, but cannot substitute for understanding leakage and validation.

### Promotion gates
Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline.
Mental model: A factory tests a sample before releasing the production batch.
Boundary: An offline gate does not establish real-world outcomes after deployment.
Worked example: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Reproducible model promotion pipeline
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Recall: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Identify one observation that would contradict your claim.

### Terms
Promotion gates: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
Every promoted model must reference both its dataset version and code revision. Count missing references. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.
Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.
Deliverables: MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for MLOps / ML platform engineer. Use this scenario: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Review: Start with the task and permitted scope. Explain promotion gates: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. Show the input and observed output, then address Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

