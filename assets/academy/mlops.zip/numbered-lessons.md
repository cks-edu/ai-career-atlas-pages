# MLOps / ML platform engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Experiment lineage: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

### Experiment lineage

Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. In this role, work through: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A recipe card records ingredients, oven settings and the finished batch.

Boundary: A tracking system cannot recover inputs that were never versioned.

Worked example: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for MLOps / ML platform engineer: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.

Predict the worked case

Read this case without running a tool: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in experiment lineage.

Connect the concept to the role

Apply this rule: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A tracking system cannot recover inputs that were never versioned.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies experiment lineage to this case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Experiment lineage; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with experiment lineage. Use the glossary below, then write your prediction for: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain experiment lineage using this case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate experiment lineage to a system or workflow you know. Explain experiment lineage using this case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain experiment lineage using this case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.

Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. — Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. A tracking system cannot recover inputs that were never versioned.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

### Diagnose: Training results cannot be reproduced

Every promoted model must reference both its dataset version and code revision. Count missing references. Three candidates lack sufficient lineage for reproducible promotion. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A recipe card records ingredients, oven settings and the finished batch.

Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.

Worked example: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

Every promoted model must reference both its dataset version and code revision. Count missing references. Three candidates lack sufficient lineage for reproducible promotion. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every promoted model must reference both its dataset version and code revision. Count missing references. Apply this toy-case rule manually: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A model learns from training examples; evaluation examples check how it behaves on unseen data. Information from the future must not be used to predict the past.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine predicting whether a package arrives late at dispatch time. List dispatch time, destination, promised date, actual arrival date and final complaint outcome.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

Preparation · Try step 2

Mark which fields are known at dispatch and which become available later.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

Preparation · Try step 3

Sketch a split that trains on earlier shipments and checks later shipments.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

Preparation · Explain and check your result

Actual arrival and final complaints are excluded from prediction inputs; the target can still use arrival later to measure lateness. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A feature-availability table and a time-based evaluation plan. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every promoted model must reference both its dataset version and code revision. Count missing references. Apply this toy-case rule manually: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three candidates lack sufficient lineage for reproducible promotion. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three candidates lack sufficient lineage for reproducible promotion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: training results cannot be reproduced. Use the glossary below, then write your prediction for: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain diagnose: training results cannot be reproduced using this case: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: training results cannot be reproduced to a system or workflow you know. Explain diagnose: training results cannot be reproduced using this case: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Rebuild a candidate from its recorded inputs and compare declared evaluation tolerance. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: training results cannot be reproduced using this case: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. State the evidence, one alternative and where the mental model stops.

Quiz: Training results cannot be reproduced: Every promoted model must reference both its dataset version and code revision. Count missing references.

Change the acceptance rule after seeing an inconvenient result.

Block promotion until immutable code, data and model artifacts are linked.

Omit failed cases and report only the successful demonstrations.

Reference: Block promotion until immutable code, data and model artifacts are linked. — Block promotion until immutable code, data and model artifacts are linked. Rebuild a candidate from its recorded inputs and compare declared evaluation tolerance.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build Python/SQL fluency, basic probability and statistics, supervised learning concepts and reproducible software environments. DevOps skills help, but cannot substitute for understanding leakage and validation.

Terms:

Promotion gates: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Promotion gates

Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. In this role, work through: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A factory tests a sample before releasing the production batch.

Boundary: An offline gate does not establish real-world outcomes after deployment.

Worked example: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build Python/SQL fluency, basic probability and statistics, supervised learning concepts and reproducible software environments. DevOps skills help, but cannot substitute for understanding leakage and validation.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for MLOps / ML platform engineer: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.

Predict the worked case

Read this case without running a tool: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in promotion gates.

Connect the concept to the role

Apply this rule: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An offline gate does not establish real-world outcomes after deployment.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies promotion gates to this case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Promotion gates; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with promotion gates. Use the glossary below, then write your prediction for: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain promotion gates using this case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate promotion gates to a system or workflow you know. Explain promotion gates using this case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain promotion gates using this case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.

Treat a passing starter as proof of the whole role workflow.

Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline.

Ignore the failure because the tool produced an output.

Reference: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. — Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. An offline gate does not establish real-world outcomes after deployment.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

### Integrate: Reproducible model promotion pipeline

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions. In this role, work through: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: A factory tests a sample before releasing the production batch.

A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.

Worked example: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

Every promoted model must reference both its dataset version and code revision. Count missing references. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-intermediate-2.md: MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: reproducible model promotion pipeline. Use the glossary below, then write your prediction for: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain integrate: reproducible model promotion pipeline using this case: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: reproducible model promotion pipeline to a system or workflow you know. Explain integrate: reproducible model promotion pipeline using this case: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Identify one observation that would contradict your claim.

Interview: Explain integrate: reproducible model promotion pipeline using this case: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Reproducible model promotion pipeline at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

Reference: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. — Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Training-serving consistency: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Training-serving consistency

Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. In this role, work through: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A ruler measured in centimeters cannot be read as inches at delivery.

Boundary: Distribution change is a signal to investigate, not proof that retraining is the right response.

Worked example: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for MLOps / ML platform engineer: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.

Predict the worked case

Read this case without running a tool: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in training-serving consistency.

Connect the concept to the role

Apply this rule: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Distribution change is a signal to investigate, not proof that retraining is the right response.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies training-serving consistency to this case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Training-serving consistency; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with training-serving consistency. Use the glossary below, then write your prediction for: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain training-serving consistency using this case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate training-serving consistency to a system or workflow you know. Explain training-serving consistency using this case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain training-serving consistency using this case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain.

Reference: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. — Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. Distribution change is a signal to investigate, not proof that retraining is the right response.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

### Defend: Reproducible model promotion pipeline

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback. In this role, work through: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: A ruler measured in centimeters cannot be read as inches at delivery.

Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.

Worked example: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-advanced-2.md: MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence; Model card and rollback procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: reproducible model promotion pipeline. Use the glossary below, then write your prediction for: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain defend: reproducible model promotion pipeline using this case: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: reproducible model promotion pipeline to a system or workflow you know. Explain defend: reproducible model promotion pipeline using this case: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Identify one observation that would contradict your claim.

Interview: Explain defend: reproducible model promotion pipeline using this case: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Reproducible model promotion pipeline at this level?

Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. — Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions
