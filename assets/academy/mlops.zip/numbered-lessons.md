# MLOps / ML platform engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Experiment lineage: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

### Record what produced a model result

MLOps connects data, training, evaluation and deployment. A result is useful only when another person can identify what produced it. Start with a run manifest: the input revision, code revision, configuration and evaluation scope.

How it works
Serialize a small manifest and hash the exact dataset bytes. The hash changes when the data changes. Record software versions separately: a data hash does not identify the training environment.

Where the model stops
A hash establishes byte identity, not whether the data is correct, licensed or representative of future traffic.

Make one change
Create two dataset revisions with one changed label. Save a manifest for each, including runtime version, code revision and split rule. Explain why the two results should not share an unqualified dataset name.

Mental model: A laboratory notebook records the sample, procedure and instrument settings behind a measurement.

Boundary: A hash establishes byte identity, not whether the data is correct, licensed or representative of future traffic.

Worked example: import hashlib,json
rows=b'id,label\n1,positive\n2,negative\n'
manifest={'run_id':'demo-1','data_sha256':hashlib.sha256(rows).hexdigest(),'code_revision':'learning-v1','seed':17}
assert len(manifest['data_sha256'])==64
assert hashlib.sha256(rows+b'3,positive\n').hexdigest()!=manifest['data_sha256']
assert json.loads(json.dumps(manifest))==manifest
print(json.dumps(manifest,sort_keys=True))


Setup: Download and extract mlops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/run-manifest. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Create two dataset revisions with one changed label. Save a manifest for each, including runtime version, code revision and split rule. Explain why the two results should not share an unqualified dataset name.

Terminal folder: course-labs/beginner/run-manifest

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Serialize a small manifest and hash the exact dataset bytes. The hash changes when the data changes. Record software versions separately: a data hash does not identify the training environment.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/run-manifest. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The changed bytes produce a different digest. Your manifests let a reviewer trace the two runs without claiming that either dataset is representative.

Build your change

Create two dataset revisions with one changed label. Save a manifest for each, including runtime version, code revision and split rule. Explain why the two results should not share an unqualified dataset name.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The changed bytes produce a different digest. Your manifests let a reviewer trace the two runs without claiming that either dataset is representative.

Break, repair and explain

Deliberately violate this boundary: A hash establishes byte identity, not whether the data is correct, licensed or representative of future traffic. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The changed bytes produce a different digest. Your manifests let a reviewer trace the two runs without claiming that either dataset is representative.

Troubleshoot: My result does not match Record what produced a model result: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Serialize a small manifest and hash the exact dataset bytes. The hash changes when the data changes. Record software versions separately: a data hash does not identify the training environment. Then inspect this limit: A hash establishes byte identity, not whether the data is correct, licensed or representative of future traffic. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/run-manifest/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Record what produced a model result line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A laboratory notebook records the sample, procedure and instrument settings behind a measurement.

seeker: Prepare a coursework example for MLOps / ML platform engineer. Answer this interview question before revealing the rubric: What does a dataset checksum establish? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A hash establishes byte identity, not whether the data is correct, licensed or representative of future traffic. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What does a dataset checksum establish?

Interview: What does a dataset checksum establish? Defend your answer using your actual lab result and this boundary: A hash establishes byte identity, not whether the data is correct, licensed or representative of future traffic.

Quiz: What does a dataset checksum establish?

The labels are unbiased.

The exact bytes can be compared for identity.

The model will perform well.

Reference: The exact bytes can be compared for identity. — Identity supports reproducibility. Data quality, permission and coverage remain separate questions.

Sources:

Python: cryptographic hashes: https://docs.python.org/3/library/hashlib.html

DVC: data and experiment management: https://doc.dvc.org/start

### Keep evaluation examples outside training decisions

A held-out set estimates performance on examples that did not shape the fitted model. Split related records carefully: two rows from the same person or session can leak information across a naive row-level split.

How it works
The fixture checks group disjointness rather than only row IDs. Overlapping customer groups invalidate this declared evaluation boundary. Real projects choose time, group or random splits according to the task.

Where the model stops
Disjoint groups do not guarantee representative evaluation. Fit preprocessing on training data only and document any time-based assumptions.

Make one change
Create six synthetic groups with two rows each. Allocate whole groups to train and evaluation. Add a preprocessing statistic computed from training rows only, then show how accidentally including evaluation rows changes it.

Mental model: An exam stops measuring transfer when its answers were included in the practice sheet.

Boundary: Disjoint groups do not guarantee representative evaluation. Fit preprocessing on training data only and document any time-based assumptions.

Worked example: train=[{'id':1,'customer':'a'},{'id':2,'customer':'b'}]
test=[{'id':3,'customer':'c'}]
def separate(a,b): return not ({x['customer'] for x in a}&{x['customer'] for x in b})
assert separate(train,test)
assert not separate(train,[{'id':4,'customer':'a'}])
print('PASS: group boundary catches a different row from the same customer')


Setup: Download and extract mlops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/split-boundaries. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Create six synthetic groups with two rows each. Allocate whole groups to train and evaluation. Add a preprocessing statistic computed from training rows only, then show how accidentally including evaluation rows changes it.

Terminal folder: course-labs/beginner/split-boundaries

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture checks group disjointness rather than only row IDs. Overlapping customer groups invalidate this declared evaluation boundary. Real projects choose time, group or random splits according to the task.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/split-boundaries. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The overlap test rejects a new row from customer a. Your report records split membership and a preprocessing leakage case.

Build your change

Create six synthetic groups with two rows each. Allocate whole groups to train and evaluation. Add a preprocessing statistic computed from training rows only, then show how accidentally including evaluation rows changes it.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The overlap test rejects a new row from customer a. Your report records split membership and a preprocessing leakage case.

Break, repair and explain

Deliberately violate this boundary: Disjoint groups do not guarantee representative evaluation. Fit preprocessing on training data only and document any time-based assumptions. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The overlap test rejects a new row from customer a. Your report records split membership and a preprocessing leakage case.

Troubleshoot: My result does not match Keep evaluation examples outside training decisions: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture checks group disjointness rather than only row IDs. Overlapping customer groups invalidate this declared evaluation boundary. Real projects choose time, group or random splits according to the task. Then inspect this limit: Disjoint groups do not guarantee representative evaluation. Fit preprocessing on training data only and document any time-based assumptions. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/split-boundaries/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Keep evaluation examples outside training decisions line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: An exam stops measuring transfer when its answers were included in the practice sheet.

seeker: Prepare a coursework example for MLOps / ML platform engineer. Answer this interview question before revealing the rubric: Unique row IDs appear in both sets, but the same person is in each. Is leakage ruled out? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Disjoint groups do not guarantee representative evaluation. Fit preprocessing on training data only and document any time-based assumptions. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Unique row IDs appear in both sets, but the same person is in each. Is leakage ruled out?

Interview: Unique row IDs appear in both sets, but the same person is in each. Is leakage ruled out? Defend your answer using your actual lab result and this boundary: Disjoint groups do not guarantee representative evaluation. Fit preprocessing on training data only and document any time-based assumptions.

Quiz: Unique row IDs appear in both sets, but the same person is in each. Is leakage ruled out?

No; related records can cross the boundary.

Yes; row IDs differ.

Yes; use a larger model.

Reference: No; related records can cross the boundary. — Leakage can follow people, sessions or time rather than row identity. Define the evaluation unit before splitting.

Sources:

scikit-learn: leakage and evaluation pitfalls: https://scikit-learn.org/stable/common_pitfalls.html

### Reproduce a baseline before optimizing it

A baseline gives later changes a reference point. Keep its inputs, split and settings stable enough to compare outcomes. Reproducibility is a property you test in a declared environment, not a promise created by writing down a seed.

How it works
Use an isolated pseudorandom generator instead of relying on shared global state. The fixture repeats a shuffle in one Python environment. Record library versions and hardware when the actual model has nondeterministic operations.

Where the model stops
A fixed seed alone does not guarantee identical outputs across packages, operating systems, hardware or parallel algorithms.

Make one change
Run the baseline twice, record Python and package versions, then change one setting. Compare outputs and explain which conditions were held fixed. Do not tune on the final evaluation set.

Mental model: Two cooks can compare recipes only when the ingredients and measurement units are known.

Boundary: A fixed seed alone does not guarantee identical outputs across packages, operating systems, hardware or parallel algorithms.

Worked example: import random
def split(seed):
    rows=list(range(10));random.Random(seed).shuffle(rows)
    return rows[:7],rows[7:]
a,b=split(17);c,d=split(17)
assert (a,b)==(c,d)
assert set(a).isdisjoint(b) and set(a)|set(b)==set(range(10))
print({'train':a,'test':b})


Setup: Download and extract mlops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/repeatable-runs. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Run the baseline twice, record Python and package versions, then change one setting. Compare outputs and explain which conditions were held fixed. Do not tune on the final evaluation set.

Terminal folder: course-labs/beginner/repeatable-runs

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Use an isolated pseudorandom generator instead of relying on shared global state. The fixture repeats a shuffle in one Python environment. Record library versions and hardware when the actual model has nondeterministic operations.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/repeatable-runs. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Two calls with seed 17 produce the same local split. Your evidence separates repeatability in this environment from a cross-platform guarantee.

Build your change

Run the baseline twice, record Python and package versions, then change one setting. Compare outputs and explain which conditions were held fixed. Do not tune on the final evaluation set.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Two calls with seed 17 produce the same local split. Your evidence separates repeatability in this environment from a cross-platform guarantee.

Break, repair and explain

Deliberately violate this boundary: A fixed seed alone does not guarantee identical outputs across packages, operating systems, hardware or parallel algorithms. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Two calls with seed 17 produce the same local split. Your evidence separates repeatability in this environment from a cross-platform guarantee.

Troubleshoot: My result does not match Reproduce a baseline before optimizing it: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Use an isolated pseudorandom generator instead of relying on shared global state. The fixture repeats a shuffle in one Python environment. Record library versions and hardware when the actual model has nondeterministic operations. Then inspect this limit: A fixed seed alone does not guarantee identical outputs across packages, operating systems, hardware or parallel algorithms. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/repeatable-runs/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Reproduce a baseline before optimizing it line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Two cooks can compare recipes only when the ingredients and measurement units are known.

seeker: Prepare a coursework example for MLOps / ML platform engineer. Answer this interview question before revealing the rubric: Does seed=17 establish reproducibility for every training system? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A fixed seed alone does not guarantee identical outputs across packages, operating systems, hardware or parallel algorithms. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does seed=17 establish reproducibility for every training system?

Interview: Does seed=17 establish reproducibility for every training system? Defend your answer using your actual lab result and this boundary: A fixed seed alone does not guarantee identical outputs across packages, operating systems, hardware or parallel algorithms.

Quiz: Does seed=17 establish reproducibility for every training system?

Yes.

Only for GPU models.

No; environment and algorithm behavior also matter.

Reference: No; environment and algorithm behavior also matter. — Seeds control selected randomness. Reproducibility also depends on inputs, software, hardware and algorithm settings.

Sources:

Python: reproducible pseudorandom generators: https://docs.python.org/3/library/random.html

scikit-learn: leakage and evaluation pitfalls: https://scikit-learn.org/stable/common_pitfalls.html

### Experiment lineage

Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. In this role, work through: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A recipe card records ingredients, oven settings and the finished batch.

Boundary: A tracking system cannot recover inputs that were never versioned.

Worked example: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for MLOps / ML platform engineer: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.

Predict the worked case

Read this case without running a tool: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in experiment lineage.

Connect the concept to the role

Apply this rule: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A tracking system cannot recover inputs that were never versioned.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies experiment lineage to this case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Experiment lineage; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with experiment lineage. Use the glossary below, then write your prediction for: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain experiment lineage using this case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate experiment lineage to a system or workflow you know. Explain experiment lineage using this case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain experiment lineage using this case: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.

Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. — Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. A tracking system cannot recover inputs that were never versioned.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

### Diagnose: Training results cannot be reproduced

Every promoted model must reference both its dataset version and code revision. Count missing references. Three candidates lack sufficient lineage for reproducible promotion. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A recipe card records ingredients, oven settings and the finished batch.

Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.

Worked example: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

Every promoted model must reference both its dataset version and code revision. Count missing references. Three candidates lack sufficient lineage for reproducible promotion. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every promoted model must reference both its dataset version and code revision. Count missing references. Apply this toy-case rule manually: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A model learns from training examples; evaluation examples check how it behaves on unseen data. Information from the future must not be used to predict the past.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine predicting whether a package arrives late at dispatch time. List dispatch time, destination, promised date, actual arrival date and final complaint outcome.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

Preparation · Try step 2

Mark which fields are known at dispatch and which become available later.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

Preparation · Try step 3

Sketch a split that trains on earlier shipments and checks later shipments.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

Preparation · Explain and check your result

Actual arrival and final complaints are excluded from prediction inputs; the target can still use arrival later to measure lateness. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A feature-availability table and a time-based evaluation plan. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every promoted model must reference both its dataset version and code revision. Count missing references. Apply this toy-case rule manually: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three candidates lack sufficient lineage for reproducible promotion. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three candidates lack sufficient lineage for reproducible promotion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: training results cannot be reproduced. Use the glossary below, then write your prediction for: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain diagnose: training results cannot be reproduced using this case: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: training results cannot be reproduced to a system or workflow you know. Explain diagnose: training results cannot be reproduced using this case: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Rebuild a candidate from its recorded inputs and compare declared evaluation tolerance. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: training results cannot be reproduced using this case: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked. State the evidence, one alternative and where the mental model stops.

Quiz: Training results cannot be reproduced: Every promoted model must reference both its dataset version and code revision. Count missing references.

Change the acceptance rule after seeing an inconvenient result.

Block promotion until immutable code, data and model artifacts are linked.

Omit failed cases and report only the successful demonstrations.

Reference: Block promotion until immutable code, data and model artifacts are linked. — Block promotion until immutable code, data and model artifacts are linked. Rebuild a candidate from its recorded inputs and compare declared evaluation tolerance.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build Python/SQL fluency, basic probability and statistics, supervised learning concepts and reproducible software environments. DevOps skills help, but cannot substitute for understanding leakage and validation.

Terms:

Promotion gates: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Track parameters, metrics and artifacts

Parameters describe choices; metrics record measurements; artifacts hold files such as predictions and reports. Keep them together under a run ID so a comparison can be reproduced and reviewed.

How it works
The standard-library fixture validates a run record. The optional MLflow extension logs a real local run and retrieves its metric. Use synthetic examples; no model provider or cloud account is needed.

Where the model stops
Logging a number does not validate its calculation or denominator. A tracking UI cannot decide whether two runs are comparable.

Make one change
Log your baseline’s split seed and dataset hash, then store predictions beside its measured metric. Compare two runs on the same held-out records. Use the MLflow extension or a clearly labelled JSON manifest.

Mental model: A results folder needs the recipe, measurement and actual output, not just a trophy labelled best.

Boundary: Logging a number does not validate its calculation or denominator. A tracking UI cannot decide whether two runs are comparable.

Worked example: run={'id':'r1','params':{'threshold':0.6},'metrics':{'accuracy':0.75},'artifacts':['predictions.csv']}
assert 0<=run['metrics']['accuracy']<=1
assert run['params']['threshold']==0.6
assert 'predictions.csv' in run['artifacts']
print(run)


Setup: Download and extract mlops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/experiment-records. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python · optional MLflow

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Log your baseline’s split seed and dataset hash, then store predictions beside its measured metric. Compare two runs on the same held-out records. Use the MLflow extension or a clearly labelled JSON manifest.

Terminal folder: course-labs/intermediate/experiment-records

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The standard-library fixture validates a run record. The optional MLflow extension logs a real local run and retrieves its metric. Use synthetic examples; no model provider or cloud account is needed.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/experiment-records. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The local record distinguishes configuration, measurement and artifact identity. Your comparison names the same evaluation set for both runs.

Build your change

Log your baseline’s split seed and dataset hash, then store predictions beside its measured metric. Compare two runs on the same held-out records. Use the MLflow extension or a clearly labelled JSON manifest.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The local record distinguishes configuration, measurement and artifact identity. Your comparison names the same evaluation set for both runs.

Break, repair and explain

Deliberately violate this boundary: Logging a number does not validate its calculation or denominator. A tracking UI cannot decide whether two runs are comparable. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Optional native-tool extension

Optional real-tool extension requiring Python 3.11+ in its own environment. The downloaded folder already contains tracking_demo.py. The commands install the version tested on 27 October 2026 from PyPI. No model, provider key or cloud account is required. Keep the regular exercise.py as the dependency-free rehearsal; it supports Python 3.9+.

```
python3 --version
# Confirm Python 3.11+ before creating this optional environment.
python3 -m venv .venv
# macOS/Linux activation; Windows PowerShell: .venv\Scripts\Activate.ps1
. .venv/bin/activate
python -m pip install mlflow==3.17.2
python -m pip show mlflow
python tracking_demo.py
```

This is a separate optional environment. Do not claim a platform or model was executed from the local reference check.

Expected: A run ID prints and get_run retrieves accuracy=0.75 from the real MLflow store. No model was trained and no hosting service was deployed.

Expected: The local record distinguishes configuration, measurement and artifact identity. Your comparison names the same evaluation set for both runs.

Troubleshoot: My result does not match Track parameters, metrics and artifacts: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The standard-library fixture validates a run record. The optional MLflow extension logs a real local run and retrieves its metric. Use synthetic examples; no model provider or cloud account is needed. Then inspect this limit: Logging a number does not validate its calculation or denominator. A tracking UI cannot decide whether two runs are comparable. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No server is required. Keep learning-runs.db and the run ID as evidence. Deactivate the environment; remove only this exercise’s files if you no longer need them.

Deliverable: course-labs/intermediate/experiment-records/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Track parameters, metrics and artifacts line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A results folder needs the recipe, measurement and actual output, not just a trophy labelled best.

seeker: Prepare a coursework example for MLOps / ML platform engineer. Answer this interview question before revealing the rubric: Which belongs in the artifact set? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Logging a number does not validate its calculation or denominator. A tracking UI cannot decide whether two runs are comparable. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which belongs in the artifact set?

Interview: Which belongs in the artifact set? Defend your answer using your actual lab result and this boundary: Logging a number does not validate its calculation or denominator. A tracking UI cannot decide whether two runs are comparable.

Quiz: Which belongs in the artifact set?

The prediction file used to calculate the metric.

Only the candidate’s marketing name.

A claim that the model is perfect.

Reference: The prediction file used to calculate the metric. — Retain the evidence behind the score. A metric without inputs and outputs can hide calculation or comparison errors.

Sources:

MLflow: tracking experiments: https://mlflow.org/docs/latest/ml/tracking/

MLflow: tracking quickstart: https://mlflow.org/docs/latest/ml/tracking/quickstart/

### Verify the artifact that will actually be loaded

A model artifact and its preprocessing contract must travel together. A service needs the expected feature names, types and artifact version. Check the package before switching a release alias.

How it works
The fixture compares feature order and artifact checksum with a declared manifest. It does not deserialize a model. In real deployments, avoid loading untrusted serialized artifacts and verify supported runtime versions.

Where the model stops
A checksum from the same untrusted source as the file is not independent authenticity proof. Pickle-based artifacts can execute code when loaded.

Make one change
Package a synthetic feature contract, environment manifest and artifact digest. Test swapped columns, missing features and changed bytes. Document how an authorized publisher and trusted store would be verified separately.

Mental model: An appliance needs both the right part and the instructions for connecting it.

Boundary: A checksum from the same untrusted source as the file is not independent authenticity proof. Pickle-based artifacts can execute code when loaded.

Worked example: import hashlib
artifact=b'synthetic model bytes'
manifest={'features':['age_days','count'],'sha256':hashlib.sha256(artifact).hexdigest()}
def compatible(features,body):
    return features==manifest['features'] and hashlib.sha256(body).hexdigest()==manifest['sha256']
assert compatible(['age_days','count'],artifact)
assert not compatible(['count','age_days'],artifact)
assert not compatible(['age_days','count'],artifact+b'changed')
print('PASS: feature order and artifact bytes checked')


Setup: Download and extract mlops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/artifact-contract. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Package a synthetic feature contract, environment manifest and artifact digest. Test swapped columns, missing features and changed bytes. Document how an authorized publisher and trusted store would be verified separately.

Terminal folder: course-labs/intermediate/artifact-contract

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture compares feature order and artifact checksum with a declared manifest. It does not deserialize a model. In real deployments, avoid loading untrusted serialized artifacts and verify supported runtime versions.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/artifact-contract. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Reordered features and modified bytes are rejected. Your package preserves preprocessing identity and loading limitations.

Build your change

Package a synthetic feature contract, environment manifest and artifact digest. Test swapped columns, missing features and changed bytes. Document how an authorized publisher and trusted store would be verified separately.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Reordered features and modified bytes are rejected. Your package preserves preprocessing identity and loading limitations.

Break, repair and explain

Deliberately violate this boundary: A checksum from the same untrusted source as the file is not independent authenticity proof. Pickle-based artifacts can execute code when loaded. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Reordered features and modified bytes are rejected. Your package preserves preprocessing identity and loading limitations.

Troubleshoot: My result does not match Verify the artifact that will actually be loaded: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture compares feature order and artifact checksum with a declared manifest. It does not deserialize a model. In real deployments, avoid loading untrusted serialized artifacts and verify supported runtime versions. Then inspect this limit: A checksum from the same untrusted source as the file is not independent authenticity proof. Pickle-based artifacts can execute code when loaded. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/artifact-contract/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Verify the artifact that will actually be loaded line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: An appliance needs both the right part and the instructions for connecting it.

seeker: Prepare a coursework example for MLOps / ML platform engineer. Answer this interview question before revealing the rubric: A file matches a supplied checksum. Is it automatically safe to deserialize? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A checksum from the same untrusted source as the file is not independent authenticity proof. Pickle-based artifacts can execute code when loaded. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A file matches a supplied checksum. Is it automatically safe to deserialize?

Interview: A file matches a supplied checksum. Is it automatically safe to deserialize? Defend your answer using your actual lab result and this boundary: A checksum from the same untrusted source as the file is not independent authenticity proof. Pickle-based artifacts can execute code when loaded.

Quiz: A file matches a supplied checksum. Is it automatically safe to deserialize?

Yes.

No; origin, trust and serialization format still matter.

Only when it is small.

Reference: No; origin, trust and serialization format still matter. — Integrity relative to a checksum is different from authenticity or safe execution. Verify origin and avoid unsafe loading paths.

Sources:

Python: cryptographic hashes: https://docs.python.org/3/library/hashlib.html

OWASP: authorization guidance: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### Define a release gate before comparing candidates

A promotion rule states what a candidate must improve and which constraints it must preserve. Decide the rule before examining candidate outcomes; otherwise the gate can be changed to favor the preferred model.

How it works
The fixture requires the same evaluation data, a minimum score and an acceptable latency. These numbers are classroom thresholds, not industry standards. Release authorization remains a separate decision.

Where the model stops
A passing aggregate can hide a failing subgroup. A metric check is not automatic permission to deploy to real users.

Make one change
Add subgroup floors and a missing-metric rejection. Run three candidate reports, retain rejected cases and write a release recommendation with an owner and rollback trigger. Keep the gate separate from production credentials.

Mental model: A sporting event needs its rules before the final score is known.

Boundary: A passing aggregate can hide a failing subgroup. A metric check is not automatic permission to deploy to real users.

Worked example: def eligible(r):
    return r.get('dataset')=='heldout-v1' and r.get('accuracy',-1)>=0.8 and 0<=r.get('p95_ms',-1)<=120
assert eligible({'dataset':'heldout-v1','accuracy':0.82,'p95_ms':100})
assert not eligible({'dataset':'other','accuracy':0.95,'p95_ms':90})
assert not eligible({'dataset':'heldout-v1','accuracy':0.9,'p95_ms':200})
assert not eligible({'dataset':'heldout-v1','accuracy':0.9})
print('PASS: comparable data, quality and measured latency required')


Setup: Download and extract mlops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/promotion-policy. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add subgroup floors and a missing-metric rejection. Run three candidate reports, retain rejected cases and write a release recommendation with an owner and rollback trigger. Keep the gate separate from production credentials.

Terminal folder: course-labs/intermediate/promotion-policy

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture requires the same evaluation data, a minimum score and an acceptable latency. These numbers are classroom thresholds, not industry standards. Release authorization remains a separate decision.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/promotion-policy. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Incomparable data, excessive latency and missing latency all fail. Your added slices prevent an acceptable average from hiding a critical regression.

Build your change

Add subgroup floors and a missing-metric rejection. Run three candidate reports, retain rejected cases and write a release recommendation with an owner and rollback trigger. Keep the gate separate from production credentials.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Incomparable data, excessive latency and missing latency all fail. Your added slices prevent an acceptable average from hiding a critical regression.

Break, repair and explain

Deliberately violate this boundary: A passing aggregate can hide a failing subgroup. A metric check is not automatic permission to deploy to real users. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Incomparable data, excessive latency and missing latency all fail. Your added slices prevent an acceptable average from hiding a critical regression.

Troubleshoot: My result does not match Define a release gate before comparing candidates: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture requires the same evaluation data, a minimum score and an acceptable latency. These numbers are classroom thresholds, not industry standards. Release authorization remains a separate decision. Then inspect this limit: A passing aggregate can hide a failing subgroup. A metric check is not automatic permission to deploy to real users. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/promotion-policy/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Define a release gate before comparing candidates line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A sporting event needs its rules before the final score is known.

seeker: Prepare a coursework example for MLOps / ML platform engineer. Answer this interview question before revealing the rubric: A better accuracy uses a different, easier evaluation set. Can it establish candidate improvement? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A passing aggregate can hide a failing subgroup. A metric check is not automatic permission to deploy to real users. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A better accuracy uses a different, easier evaluation set. Can it establish candidate improvement?

Interview: A better accuracy uses a different, easier evaluation set. Can it establish candidate improvement? Defend your answer using your actual lab result and this boundary: A passing aggregate can hide a failing subgroup. A metric check is not automatic permission to deploy to real users.

Quiz: A better accuracy uses a different, easier evaluation set. Can it establish candidate improvement?

No; compare on the declared common evaluation contract.

Yes; any higher number is better.

Yes; if the name contains advanced.

Reference: No; compare on the declared common evaluation contract. — The evaluation population and metric definition are part of the result. Changing them breaks the direct comparison.

Sources:

scikit-learn: leakage and evaluation pitfalls: https://scikit-learn.org/stable/common_pitfalls.html

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

### Promotion gates

Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. In this role, work through: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A factory tests a sample before releasing the production batch.

Boundary: An offline gate does not establish real-world outcomes after deployment.

Worked example: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build Python/SQL fluency, basic probability and statistics, supervised learning concepts and reproducible software environments. DevOps skills help, but cannot substitute for understanding leakage and validation.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for MLOps / ML platform engineer: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.

Predict the worked case

Read this case without running a tool: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in promotion gates.

Connect the concept to the role

Apply this rule: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An offline gate does not establish real-world outcomes after deployment.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies promotion gates to this case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Promotion gates; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with promotion gates. Use the glossary below, then write your prediction for: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain promotion gates using this case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate promotion gates to a system or workflow you know. Explain promotion gates using this case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain promotion gates using this case: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.

Treat a passing starter as proof of the whole role workflow.

Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline.

Ignore the failure because the tool produced an output.

Reference: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. — Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. An offline gate does not establish real-world outcomes after deployment.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

### Integrate: Reproducible model promotion pipeline

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions. In this role, work through: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: A factory tests a sample before releasing the production batch.

A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.

Worked example: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

Every promoted model must reference both its dataset version and code revision. Count missing references. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-intermediate-2.md: MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: reproducible model promotion pipeline. Use the glossary below, then write your prediction for: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain integrate: reproducible model promotion pipeline using this case: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: reproducible model promotion pipeline to a system or workflow you know. Explain integrate: reproducible model promotion pipeline using this case: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Identify one observation that would contradict your claim.

Interview: Explain integrate: reproducible model promotion pipeline using this case: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Reproducible model promotion pipeline at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

Reference: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. — Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Training-serving consistency: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Separate drift signals from measured model quality

A changed input distribution is a reason to investigate, not proof that model quality fell. Production labels may arrive days later. Track input behavior, service health and delayed outcome evidence as different signals.

How it works
The fixture compares input means and marks quality unknown until labels exist. This simple rule is a transparent toy detector. A real monitor needs a suitable reference window, sample-size checks and task-specific validation.

Where the model stops
A mean can hide multimodal or subgroup shifts. Drift does not automatically justify retraining, and stable inputs do not prove stable outcomes.

Make one change
Add sample-count and subgroup checks, then simulate labels arriving a day later. Write separate alert messages for changed inputs, slow service and measured error rate. Explain who investigates each signal.

Mental model: A changed weather forecast is a warning to inspect the roof; it is not evidence that the roof leaked.

Boundary: A mean can hide multimodal or subgroup shifts. Drift does not automatically justify retraining, and stable inputs do not prove stable outcomes.

Worked example: from statistics import mean
reference=[10,11,9,10];current=[20,21,19,20]
alert=abs(mean(current)-mean(reference))>5
quality=None  # Ground-truth labels have not arrived.
assert alert and quality is None
print({'input_shift_alert':alert,'measured_quality':quality})


Setup: Download and extract mlops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/monitoring-delays. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add sample-count and subgroup checks, then simulate labels arriving a day later. Write separate alert messages for changed inputs, slow service and measured error rate. Explain who investigates each signal.

Terminal folder: course-labs/advanced/monitoring-delays

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture compares input means and marks quality unknown until labels exist. This simple rule is a transparent toy detector. A real monitor needs a suitable reference window, sample-size checks and task-specific validation.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/monitoring-delays. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The input-shift alert is true while quality stays unknown. Your report does not label unlabeled traffic as an accuracy regression.

Build your change

Add sample-count and subgroup checks, then simulate labels arriving a day later. Write separate alert messages for changed inputs, slow service and measured error rate. Explain who investigates each signal.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The input-shift alert is true while quality stays unknown. Your report does not label unlabeled traffic as an accuracy regression.

Break, repair and explain

Deliberately violate this boundary: A mean can hide multimodal or subgroup shifts. Drift does not automatically justify retraining, and stable inputs do not prove stable outcomes. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The input-shift alert is true while quality stays unknown. Your report does not label unlabeled traffic as an accuracy regression.

Troubleshoot: My result does not match Separate drift signals from measured model quality: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture compares input means and marks quality unknown until labels exist. This simple rule is a transparent toy detector. A real monitor needs a suitable reference window, sample-size checks and task-specific validation. Then inspect this limit: A mean can hide multimodal or subgroup shifts. Drift does not automatically justify retraining, and stable inputs do not prove stable outcomes. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/monitoring-delays/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Separate drift signals from measured model quality line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A changed weather forecast is a warning to inspect the roof; it is not evidence that the roof leaked.

seeker: Prepare a coursework example for MLOps / ML platform engineer. Answer this interview question before revealing the rubric: Input drift is detected without outcome labels. What is known? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A mean can hide multimodal or subgroup shifts. Drift does not automatically justify retraining, and stable inputs do not prove stable outcomes. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Input drift is detected without outcome labels. What is known?

Interview: Input drift is detected without outcome labels. What is known? Defend your answer using your actual lab result and this boundary: A mean can hide multimodal or subgroup shifts. Drift does not automatically justify retraining, and stable inputs do not prove stable outcomes.

Quiz: Input drift is detected without outcome labels. What is known?

The model is definitely wrong.

Inputs changed under this detector; outcome quality remains unmeasured.

Retraining must happen immediately.

Reference: Inputs changed under this detector; outcome quality remains unmeasured. — Drift describes a distribution signal. Confirm impact with outcome evidence and inspect other causes before changing the model.

Sources:

Python: statistics functions: https://docs.python.org/3/library/statistics.html

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

### Rollback the serving contract as a unit

A rollback must restore a compatible model and preprocessing version. Changing only the model alias can leave the service interpreting features with the wrong transformation. Keep the previous healthy release identity and test its readiness.

How it works
The fixture updates one release pointer to a bundle containing model and transform versions. It rejects incomplete bundles. Actual rollback also depends on available artifacts, compatible schemas and a healthy service.

Where the model stops
An in-memory pointer is not a deployment. Database schema changes, queued jobs and external side effects may not be reversible by changing a model version.

Make one change
Create a local service configuration with a release manifest. Test the old bundle on a known request before changing the pointer. Record recovery time, health evidence and a case that a model rollback cannot repair.

Mental model: Restoring an old engine while keeping incompatible wiring can leave the vehicle broken.

Boundary: An in-memory pointer is not a deployment. Database schema changes, queued jobs and external side effects may not be reversible by changing a model version.

Worked example: releases={'r1':{'model':'m1','transform':'t1'},'r2':{'model':'m2','transform':'t2'}}
def choose(release):
    bundle=releases[release]
    if set(bundle)!={'model','transform'}: raise ValueError('Incomplete bundle')
    return dict(bundle)
active=choose('r2');active=choose('r1')
assert active=={'model':'m1','transform':'t1'}
assert releases['r2']['transform']=='t2'
print('PASS: model and transform roll back together')


Setup: Download and extract mlops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/rollback-identity. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Create a local service configuration with a release manifest. Test the old bundle on a known request before changing the pointer. Record recovery time, health evidence and a case that a model rollback cannot repair.

Terminal folder: course-labs/advanced/rollback-identity

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture updates one release pointer to a bundle containing model and transform versions. It rejects incomplete bundles. Actual rollback also depends on available artifacts, compatible schemas and a healthy service.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/rollback-identity. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The reference restores both version identifiers. Your rehearsal demonstrates an actual local readiness check and states the untested deployment boundary.

Build your change

Create a local service configuration with a release manifest. Test the old bundle on a known request before changing the pointer. Record recovery time, health evidence and a case that a model rollback cannot repair.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The reference restores both version identifiers. Your rehearsal demonstrates an actual local readiness check and states the untested deployment boundary.

Break, repair and explain

Deliberately violate this boundary: An in-memory pointer is not a deployment. Database schema changes, queued jobs and external side effects may not be reversible by changing a model version. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The reference restores both version identifiers. Your rehearsal demonstrates an actual local readiness check and states the untested deployment boundary.

Troubleshoot: My result does not match Rollback the serving contract as a unit: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture updates one release pointer to a bundle containing model and transform versions. It rejects incomplete bundles. Actual rollback also depends on available artifacts, compatible schemas and a healthy service. Then inspect this limit: An in-memory pointer is not a deployment. Database schema changes, queued jobs and external side effects may not be reversible by changing a model version. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/rollback-identity/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Rollback the serving contract as a unit line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Restoring an old engine while keeping incompatible wiring can leave the vehicle broken.

seeker: Prepare a coursework example for MLOps / ML platform engineer. Answer this interview question before revealing the rubric: What must accompany an older model when its feature transform changed? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: An in-memory pointer is not a deployment. Database schema changes, queued jobs and external side effects may not be reversible by changing a model version. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What must accompany an older model when its feature transform changed?

Interview: What must accompany an older model when its feature transform changed? Defend your answer using your actual lab result and this boundary: An in-memory pointer is not a deployment. Database schema changes, queued jobs and external side effects may not be reversible by changing a model version.

Quiz: What must accompany an older model when its feature transform changed?

Its compatible preprocessing contract.

Only the latest dashboard theme.

A higher confidence label.

Reference: Its compatible preprocessing contract. — Serving inputs must match the artifact’s feature contract. Rollback is a compatibility change, not just a name switch.

Sources:

MLflow: tracking experiments: https://mlflow.org/docs/latest/ml/tracking/

Python: cryptographic hashes: https://docs.python.org/3/library/hashlib.html

### Capstone: a traceable, reversible model release

Use a small CPU baseline and synthetic or openly permitted data. Connect dataset and split identity, tracked experiments, artifact checks, a declared promotion gate, a local health test and a rollback rehearsal.

How it works
The fixture requires a complete chain of release evidence. It validates presence, not truth: each item must point to actual saved outputs from your implementation. Reuse the original course project for real model training.

Where the model stops
A filled checklist alone is not production experience. Report local execution, simulated policies and optional hosted CI as separate scopes.

Make one change
Run the original CPU training project, add manifests and MLflow or JSON tracking, compare candidates on a held-out set, and expose a local health endpoint. Break a feature contract, roll back, and publish an incident report with actual outputs and limitations.

Mental model: A release dossier lets another engineer reconstruct the experiment and safely find the last working package.

Boundary: A filled checklist alone is not production experience. Report local execution, simulated policies and optional hosted CI as separate scopes.

Worked example: required={'data_hash','split_report','run_id','artifact_hash','gate_report','health_result','rollback_result'}
def ready(report): return required<=report.keys() and all(type(report[k]) is str and report[k].strip() for k in required)
report={key:'learning-evidence/'+key for key in required}
assert ready(report)
del report['rollback_result'];assert not ready(report)
print('PASS: rollback evidence cannot be silently omitted')


Setup: Download and extract mlops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/mlops-capstone. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Run the original CPU training project, add manifests and MLflow or JSON tracking, compare candidates on a held-out set, and expose a local health endpoint. Break a feature contract, roll back, and publish an incident report with actual outputs and limitations.

Terminal folder: course-labs/advanced/mlops-capstone

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture requires a complete chain of release evidence. It validates presence, not truth: each item must point to actual saved outputs from your implementation. Reuse the original course project for real model training.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/mlops-capstone. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The fixture blocks a release dossier without rollback evidence. Your deliverable includes changed source, run records, metrics, a failed case and an observed local recovery.

Build your change

Run the original CPU training project, add manifests and MLflow or JSON tracking, compare candidates on a held-out set, and expose a local health endpoint. Break a feature contract, roll back, and publish an incident report with actual outputs and limitations.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The fixture blocks a release dossier without rollback evidence. Your deliverable includes changed source, run records, metrics, a failed case and an observed local recovery.

Break, repair and explain

Deliberately violate this boundary: A filled checklist alone is not production experience. Report local execution, simulated policies and optional hosted CI as separate scopes. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The fixture blocks a release dossier without rollback evidence. Your deliverable includes changed source, run records, metrics, a failed case and an observed local recovery.

Troubleshoot: My result does not match Capstone: a traceable, reversible model release: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture requires a complete chain of release evidence. It validates presence, not truth: each item must point to actual saved outputs from your implementation. Reuse the original course project for real model training. Then inspect this limit: A filled checklist alone is not production experience. Report local execution, simulated policies and optional hosted CI as separate scopes. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/mlops-capstone/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Capstone: a traceable, reversible model release line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A release dossier lets another engineer reconstruct the experiment and safely find the last working package.

seeker: Prepare a coursework example for MLOps / ML platform engineer. Answer this interview question before revealing the rubric: Which résumé statement is supported by this project? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A filled checklist alone is not production experience. Report local execution, simulated policies and optional hosted CI as separate scopes. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which résumé statement is supported by this project?

Interview: Which résumé statement is supported by this project? Defend your answer using your actual lab result and this boundary: A filled checklist alone is not production experience. Report local execution, simulated policies and optional hosted CI as separate scopes.

Quiz: Which résumé statement is supported by this project?

Operated millions of production predictions.

Guaranteed model fairness.

Built and tested a local model-release and rollback learning project, with measured evidence.

Reference: Built and tested a local model-release and rollback learning project, with measured evidence. — Describe what you actually built and observed. Classroom data and a local rehearsal cannot establish production scale or universal quality.

Sources:

MLflow: tracking quickstart: https://mlflow.org/docs/latest/ml/tracking/quickstart/

scikit-learn: leakage and evaluation pitfalls: https://scikit-learn.org/stable/common_pitfalls.html

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

### Training-serving consistency

Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. In this role, work through: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A ruler measured in centimeters cannot be read as inches at delivery.

Boundary: Distribution change is a signal to investigate, not proof that retraining is the right response.

Worked example: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for MLOps / ML platform engineer: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.

Predict the worked case

Read this case without running a tool: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in training-serving consistency.

Connect the concept to the role

Apply this rule: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Distribution change is a signal to investigate, not proof that retraining is the right response.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies training-serving consistency to this case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Training-serving consistency; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with training-serving consistency. Use the glossary below, then write your prediction for: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain training-serving consistency using this case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate training-serving consistency to a system or workflow you know. Explain training-serving consistency using this case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain training-serving consistency using this case: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain.

Reference: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. — Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. Distribution change is a signal to investigate, not proof that retraining is the right response.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions

### Defend: Reproducible model promotion pipeline

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback. In this role, work through: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: A ruler measured in centimeters cannot be read as inches at delivery.

Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.

Worked example: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-advanced-2.md: MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence; Model card and rollback procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: reproducible model promotion pipeline. Use the glossary below, then write your prediction for: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the MLOps / ML platform engineer role interview. Explain defend: reproducible model promotion pipeline using this case: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: reproducible model promotion pipeline to a system or workflow you know. Explain defend: reproducible model promotion pipeline using this case: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Identify one observation that would contradict your claim.

Interview: Explain defend: reproducible model promotion pipeline using this case: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Reproducible model promotion pipeline at this level?

Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. — Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it. Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Kubernetes: https://kubernetes.io/docs/tutorials/

GitHub Actions: https://docs.github.com/en/actions
