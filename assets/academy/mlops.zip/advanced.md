## advanced — Training-serving consistency

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Training-serving consistency
Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain.
Mental model: A ruler measured in centimeters cannot be read as inches at delivery.
Boundary: Distribution change is a signal to investigate, not proof that retraining is the right response.
Worked example: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Reproducible model promotion pipeline
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Recall: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Identify one observation that would contradict your claim.

### Terms
Training-serving consistency: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.
Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback.
Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.
Serve the approved artifact in a local container and test schema drift before considering a cloud endpoint.
Deliverables: MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence; Model card and rollback procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

### Interview
Explain your advanced solution for MLOps / ML platform engineer. Use this scenario: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Review: Start with the task and permitted scope. Explain training-serving consistency: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. Show the input and observed output, then address Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence; Model card and rollback procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

