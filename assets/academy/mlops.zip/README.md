# MLOps / ML platform engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Experiment lineage. A model learns from training examples; evaluation examples check how it behaves on unseen data. Information from the future must not be used to predict the past. Then try Spot information leakage. The three levels build toward Reproducible model promotion pipeline. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Experiment lineage

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Experiment lineage
Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited.
Mental model: A recipe card records ingredients, oven settings and the finished batch.
Boundary: A tracking system cannot recover inputs that were never versioned.
Worked example: Two models share a filename but were trained on different CSVs. Track hashes and run identifiers rather than overwriting model.pkl.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Training results cannot be reproduced
Every promoted model must reference both its dataset version and code revision. Count missing references. Three candidates lack sufficient lineage for reproducible promotion. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Block promotion until immutable code, data and model artifacts are linked.
Recall: Rebuild a candidate from its recorded inputs and compare declared evaluation tolerance. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Experiment lineage: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A model learns from training examples; evaluation examples check how it behaves on unseen data. Information from the future must not be used to predict the past.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine predicting whether a package arrives late at dispatch time. List dispatch time, destination, promised date, actual arrival date and final complaint outcome.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

3. Try step 2
Mark which fields are known at dispatch and which become available later.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

4. Try step 3
Sketch a split that trains on earlier shipments and checks later shipments.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A feature-availability table and a time-based evaluation plan.

5. Explain and check your result
Actual arrival and final complaints are excluded from prediction inputs; the target can still use arrival later to measure lateness. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A feature-availability table and a time-based evaluation plan. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every promoted model must reference both its dataset version and code revision. Count missing references. Apply this toy-case rule manually: Review when missing_lineage >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three candidates lack sufficient lineage for reproducible promotion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to MLOps / ML platform engineer.
Imagine predicting whether a package arrives late at dispatch time. List dispatch time, destination, promised date, actual arrival date and final complaint outcome.
Mark which fields are known at dispatch and which become available later.
Sketch a split that trains on earlier shipments and checks later shipments.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A feature-availability table and a time-based evaluation plan. Include beginner-worksheet.md and your completed Model promotion evidence manifest.
Check: Actual arrival and final complaints are excluded from prediction inputs; the target can still use arrival later to measure lateness.

### Interview
Explain your beginner solution for MLOps / ML platform engineer. Use this scenario: Every promoted model must reference both its dataset version and code revision. Count missing references.
Review: Start with the task and permitted scope. Explain experiment lineage: Record the dataset version, transformation code, parameters and resulting model together. Without this chain, a model score cannot be reproduced or audited. Show the input and observed output, then address Block promotion until immutable code, data and model artifacts are linked. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A feature-availability table and a time-based evaluation plan. Include beginner-worksheet.md and your completed Model promotion evidence manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Promotion gates

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Build Python/SQL fluency, basic probability and statistics, supervised learning concepts and reproducible software environments. DevOps skills help, but cannot substitute for understanding leakage and validation.

### Promotion gates
Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline.
Mental model: A factory tests a sample before releasing the production batch.
Boundary: An offline gate does not establish real-world outcomes after deployment.
Worked example: A candidate improves average accuracy but fails a critical subgroup check; keep it in staging and document the trade-off.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Reproducible model promotion pipeline
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Recall: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Identify one observation that would contradict your claim.

### Terms
Promotion gates: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
Every promoted model must reference both its dataset version and code revision. Count missing references. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.
Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.
Deliverables: MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for MLOps / ML platform engineer. Use this scenario: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Review: Start with the task and permitted scope. Explain promotion gates: Promotion moves a candidate into an environment only after agreed checks pass. Keep model selection separate from deployment authorization and compare against a stable baseline. Show the input and observed output, then address Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Training-serving consistency

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Training-serving consistency
Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain.
Mental model: A ruler measured in centimeters cannot be read as inches at delivery.
Boundary: Distribution change is a signal to investigate, not proof that retraining is the right response.
Worked example: Training scales age with stored statistics; serving uses those same fitted statistics instead of fitting on each request.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Reproducible model promotion pipeline
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Recall: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. Identify one observation that would contradict your claim.

### Terms
Training-serving consistency: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build a model pipeline where promotion depends on repeatable evaluation and traceable artifacts.
Begin with the bundled scikit-learn dataset; use a fixed test partition and three seeds. Replace it later with a licensed dataset whose target matches the proposed business problem.
Run train.py and inspect metrics.json. Add MLflow logging for split seed, preprocessing, estimator parameters, dataset hash and artifact path.
Create a candidate-versus-champion comparison script that reads saved predictions. Define the promotion rule before running candidates; fail on missing metrics or incompatible data versions.
Add CI that trains the small baseline, runs leakage/regression checks and uploads reports. Keep release approval separate from the metric check; document who owns rollback.
Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison.
Serve the approved artifact in a local container and test schema drift before considering a cloud endpoint.
Deliverables: MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence; Model card and rollback procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.

### Interview
Explain your advanced solution for MLOps / ML platform engineer. Use this scenario: Introduce a feature derived from the target and prove that your review catches it. Replace the candidate with a deliberately worse dummy classifier; the promotion gate must reject it.
Review: Start with the task and permitted scope. Explain training-serving consistency: Use compatible feature transformations and model versions at training and inference. Monitor changes in inputs and outcomes, then investigate before deciding to retrain. Show the input and observed output, then address Report per-class performance, run-to-run variance, lineage completeness and recovery to the prior artifact. Repeated test-set tuning invalidates the comparison. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [MLflow experiment and reproducible training code; CI promotion gate with rejected candidate evidence; Model card and rollback procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

GitHub Actions — Commercial hosted service · usage limits
CI checks and reviewable build artifacts; paid usage may apply.
Alternative: GitLab CI (open-core/commercial offerings) or Jenkins (open source); runners and compute still need operating resources.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
GitHub Actions: https://docs.github.com/en/actions
MLflow: https://mlflow.org/docs/latest/
Kubernetes: https://kubernetes.io/docs/tutorials/
GitHub Actions: https://docs.github.com/en/actions
