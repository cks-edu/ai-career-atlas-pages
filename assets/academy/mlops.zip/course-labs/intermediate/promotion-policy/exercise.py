def eligible(r):
    return r.get('dataset')=='heldout-v1' and r.get('accuracy',-1)>=0.8 and 0<=r.get('p95_ms',-1)<=120
assert eligible({'dataset':'heldout-v1','accuracy':0.82,'p95_ms':100})
assert not eligible({'dataset':'other','accuracy':0.95,'p95_ms':90})
assert not eligible({'dataset':'heldout-v1','accuracy':0.9,'p95_ms':200})
assert not eligible({'dataset':'heldout-v1','accuracy':0.9})
print('PASS: comparable data, quality and measured latency required')
