# Define a release gate before comparing candidates

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://scikit-learn.org/stable/common_pitfalls.html
https://www.nist.gov/itl/ai-risk-management-framework
