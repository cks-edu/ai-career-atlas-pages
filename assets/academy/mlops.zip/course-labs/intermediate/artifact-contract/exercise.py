import hashlib
artifact=b'synthetic model bytes'
manifest={'features':['age_days','count'],'sha256':hashlib.sha256(artifact).hexdigest()}
def compatible(features,body):
    return features==manifest['features'] and hashlib.sha256(body).hexdigest()==manifest['sha256']
assert compatible(['age_days','count'],artifact)
assert not compatible(['count','age_days'],artifact)
assert not compatible(['age_days','count'],artifact+b'changed')
print('PASS: feature order and artifact bytes checked')
