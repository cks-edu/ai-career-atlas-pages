import mlflow
mlflow.set_tracking_uri("sqlite:///learning-runs.db")
mlflow.set_experiment("skillbadi-learning")
with mlflow.start_run() as run:
    mlflow.log_param("dataset_revision", "synthetic-v1")
    mlflow.log_metric("accuracy", 0.75)
    run_id = run.info.run_id
saved = mlflow.MlflowClient().get_run(run_id)
assert saved.data.metrics["accuracy"] == 0.75
print("PASS: real MLflow run persisted and retrieved:", run_id)
