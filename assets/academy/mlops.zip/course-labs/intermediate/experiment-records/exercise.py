run={'id':'r1','params':{'threshold':0.6},'metrics':{'accuracy':0.75},'artifacts':['predictions.csv']}
assert 0<=run['metrics']['accuracy']<=1
assert run['params']['threshold']==0.6
assert 'predictions.csv' in run['artifacts']
print(run)
