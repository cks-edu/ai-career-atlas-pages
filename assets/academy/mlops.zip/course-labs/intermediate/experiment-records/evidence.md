# Track parameters, metrics and artifacts

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://mlflow.org/docs/latest/ml/tracking/
https://mlflow.org/docs/latest/ml/tracking/quickstart/
