# MLOps / ML platform engineer — core lessons

Begin with run manifests, held-out data boundaries and reproducible baselines. Continue to tracked experiments, artifact contracts and predeclared release gates. Finish with drift-versus-quality reasoning, compatible rollback and a traceable CPU-model release. Hosted deployment remains an optional extension.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A small model release dossier connecting dataset and code identity, run records, held-out evaluation, a local health check and a measured rollback rehearsal.
