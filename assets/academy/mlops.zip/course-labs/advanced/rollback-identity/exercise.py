releases={'r1':{'model':'m1','transform':'t1'},'r2':{'model':'m2','transform':'t2'}}
def choose(release):
    bundle=releases[release]
    if set(bundle)!={'model','transform'}: raise ValueError('Incomplete bundle')
    return dict(bundle)
active=choose('r2');active=choose('r1')
assert active=={'model':'m1','transform':'t1'}
assert releases['r2']['transform']=='t2'
print('PASS: model and transform roll back together')
