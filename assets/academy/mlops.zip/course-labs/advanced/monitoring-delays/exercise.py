from statistics import mean
reference=[10,11,9,10];current=[20,21,19,20]
alert=abs(mean(current)-mean(reference))>5
quality=None  # Ground-truth labels have not arrived.
assert alert and quality is None
print({'input_shift_alert':alert,'measured_quality':quality})
