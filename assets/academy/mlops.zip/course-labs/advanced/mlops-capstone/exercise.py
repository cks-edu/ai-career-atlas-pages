required={'data_hash','split_report','run_id','artifact_hash','gate_report','health_result','rollback_result'}
def ready(report): return required<=report.keys() and all(type(report[k]) is str and report[k].strip() for k in required)
report={key:'learning-evidence/'+key for key in required}
assert ready(report)
del report['rollback_result'];assert not ready(report)
print('PASS: rollback evidence cannot be silently omitted')
