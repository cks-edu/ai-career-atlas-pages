# Capstone: a traceable, reversible model release

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://mlflow.org/docs/latest/ml/tracking/quickstart/
https://scikit-learn.org/stable/common_pitfalls.html
https://opentelemetry.io/docs/concepts/observability-primer/
