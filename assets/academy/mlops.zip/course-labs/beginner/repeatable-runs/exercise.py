import random
def split(seed):
    rows=list(range(10));random.Random(seed).shuffle(rows)
    return rows[:7],rows[7:]
a,b=split(17);c,d=split(17)
assert (a,b)==(c,d)
assert set(a).isdisjoint(b) and set(a)|set(b)==set(range(10))
print({'train':a,'test':b})
