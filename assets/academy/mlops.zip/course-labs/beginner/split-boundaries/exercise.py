train=[{'id':1,'customer':'a'},{'id':2,'customer':'b'}]
test=[{'id':3,'customer':'c'}]
def separate(a,b): return not ({x['customer'] for x in a}&{x['customer'] for x in b})
assert separate(train,test)
assert not separate(train,[{'id':4,'customer':'a'}])
print('PASS: group boundary catches a different row from the same customer')
