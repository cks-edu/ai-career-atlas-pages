import hashlib,json
rows=b'id,label\n1,positive\n2,negative\n'
manifest={'run_id':'demo-1','data_sha256':hashlib.sha256(rows).hexdigest(),'code_revision':'learning-v1','seed':17}
assert len(manifest['data_sha256'])==64
assert hashlib.sha256(rows+b'3,positive\n').hexdigest()!=manifest['data_sha256']
assert json.loads(json.dumps(manifest))==manifest
print(json.dumps(manifest,sort_keys=True))
