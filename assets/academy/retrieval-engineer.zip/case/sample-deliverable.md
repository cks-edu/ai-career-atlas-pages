# SAMPLE — Freshness audit and deletion runbook
Role: RAG / retrieval engineer
Case: Deleted policies still retrieved
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes.

## Evidence table
| Record | deletion_lag (minutes) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 10 | within_demo_bound |
| case-3 | 18 | review |
| case-4 | 45 | review |
| case-5 | 5 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two deleted sources remain discoverable beyond the stated freshness limit.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in rag / retrieval engineer.
Before release: Check deleted and active sources using normal user identities; a fresh ingestion job alone is insufficient.

## Design choice and trade-off
Carry source version and access metadata through indexing; test removal and permission changes.
Faster reindexing reduces stale results but increases processing cost; deletion needs its own propagation guarantee.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Public handbook search: Publish retrieval metrics and examples where each baseline fails.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
