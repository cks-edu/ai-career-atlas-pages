# Permission-aware knowledge search

Career: RAG / retrieval engineer
Reviewed: 2026-10-22

Build a knowledge assistant that respects document ownership, deletion and evidence freshness.

## Prerequisites
SQL, indexing, data pipelines and relevance measurement; learn embeddings and ranking fundamentals.

## Included starter versus your implementation
An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter.

```sh
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Ingestion and search service with deletion tests — artifact-1.md
2. Judged query set and retrieval comparison — artifact-2.md
3. Permission-flow diagram and freshness dashboard — artifact-3.md

## Troubleshooting
- No such module fts5: use a Python build linked to SQLite with FTS5.
- No results: inspect tenant, source text and literal query phrase.
- Deletion leak: inspect caches and derived chunks as well as source records.

## Extension
Add document-level ACLs with group membership changes and measure the maximum revocation propagation delay.

## Primary learning resources
- SQLite FTS5: https://www.sqlite.org/fts5.html — Public domain · local; Full-text retrieval with explicit tenant filtering.
- pgvector: https://github.com/pgvector/pgvector — Open source · PostgreSQL extension; Vector retrieval comparison; requires a PostgreSQL installation.
- Ollama: https://docs.ollama.com/api/generate — Open source runtime · model licenses vary; Local generation; choose a model that fits memory and permitted use.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
