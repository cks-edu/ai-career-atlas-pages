# Judged query set and retrieval comparison

Project: Permission-aware knowledge search
Status: blank work product — not completed evidence

## Purpose and audience
Build a knowledge assistant that respects document ownership, deletion and evidence freshness.

## Required content
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

## Failure evidence
Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
