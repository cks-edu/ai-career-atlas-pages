# Permission-flow diagram and freshness dashboard

Project: Permission-aware knowledge search
Status: blank work product — not completed evidence

## Purpose and audience
Build a knowledge assistant that respects document ownership, deletion and evidence freshness.

## Required content
Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

## Failure evidence
Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
