## advanced — Grounded answer evaluation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Grounded answer evaluation
Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined.
Mental model: First inspect the evidence delivered to a witness, then inspect the witness's explanation.
Boundary: A correct citation format does not prove the claim is supported.
Worked example: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Permission-aware knowledge search
Build a knowledge assistant that respects document ownership, deletion and evidence freshness. Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.
Worked example: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Recall: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Identify one observation that would contradict your claim.

### Terms
Grounded answer evaluation: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a knowledge assistant that respects document ownership, deletion and evidence freshness. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

2. Prepare the project inputs
Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
No such module fts5: use a Python build linked to SQLite with FTS5.
No results: inspect tenant, source text and literal query phrase.
Deletion leak: inspect caches and derived chunks as well as source records.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

### Portfolio
Build a knowledge assistant that respects document ownership, deletion and evidence freshness.
Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.
Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.
Add document-level ACLs with group membership changes and measure the maximum revocation propagation delay.
Deliverables: Ingestion and search service with deletion tests; Judged query set and retrieval comparison; Permission-flow diagram and freshness dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A reviewer must reproduce one result and identify which capabilities you implemented. Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

### Interview
Explain your advanced solution for RAG / retrieval engineer. Use this scenario: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Review: Start with the task and permitted scope. Explain grounded answer evaluation: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. Show the input and observed output, then address Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Ingestion and search service with deletion tests; Judged query set and retrieval comparison; Permission-flow diagram and freshness dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

