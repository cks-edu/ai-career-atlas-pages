## beginner — Relevance judgments

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Relevance judgments
Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters.
Mental model: A library catalog points to a useful shelf, not automatically the right page.
Boundary: Similarity scores are not probabilities that an answer is correct.
Worked example: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Deleted policies still retrieved
The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Two deleted sources remain discoverable beyond the stated freshness limit. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval.
Recall: Check deleted and active sources using normal user identities; a fresh ingestion job alone is insufficient. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Relevance judgments: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Retrieval means finding relevant information before writing an answer. Finding a useful passage and producing a correct answer are separate checks.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Write three fictional school rules: “Library closes at 6 pm”; “Books may be borrowed for 14 days”; “Lost cards must be reported to reception.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

3. Try step 2
Match these questions to a rule: “When does the library close?”, “How long can I keep a book?”, “Is printing free?”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

4. Try step 3
Copy the supporting sentence for each answer; mark the printing question as not covered.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

5. Explain and check your result
Every factual answer has a supporting sentence; missing information is left unknown rather than invented. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A three-row question, answer and source table. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Apply this toy-case rule manually: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two deleted sources remain discoverable beyond the stated freshness limit. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to RAG / retrieval engineer.
Write three fictional school rules: “Library closes at 6 pm”; “Books may be borrowed for 14 days”; “Lost cards must be reported to reception.”
Match these questions to a rule: “When does the library close?”, “How long can I keep a book?”, “Is printing free?”
Copy the supporting sentence for each answer; mark the printing question as not covered.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A three-row question, answer and source table. Include beginner-worksheet.md and your completed Freshness audit and deletion runbook.
Check: Every factual answer has a supporting sentence; missing information is left unknown rather than invented.

### Interview
Explain your beginner solution for RAG / retrieval engineer. Use this scenario: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes.
Review: Start with the task and permitted scope. Explain relevance judgments: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. Show the input and observed output, then address Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A three-row question, answer and source table. Include beginner-worksheet.md and your completed Freshness audit and deletion runbook.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

