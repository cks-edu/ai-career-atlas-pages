import sqlite3
with sqlite3.connect(':memory:') as db:
    db.execute('CREATE VIRTUAL TABLE docs USING fts5(tenant UNINDEXED,id UNINDEXED,body)')
    db.executemany('INSERT INTO docs VALUES (?,?,?)',[('team-a','a','password reset'),('team-b','b','password reset')])
    rows=db.execute('SELECT id,body FROM docs WHERE docs MATCH ? AND tenant=?',('password','team-a')).fetchall()
    assert [r[0] for r in rows]==['a']
print('PASS: only team-a context returned')
