# Filter access before results become context

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
https://www.sqlite.org/fts5.html
