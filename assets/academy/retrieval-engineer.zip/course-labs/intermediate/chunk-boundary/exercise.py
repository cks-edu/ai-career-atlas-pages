def chunk(text,size=24,overlap=6):
    if not 0<=overlap<size: raise ValueError('Invalid overlap')
    return [{'start':i,'end':min(i+size,len(text)),'text':text[i:i+size]} for i in range(0,len(text),size-overlap)]
text='Returns are allowed within 14 days unless an item was opened.'
parts=chunk(text)
assert parts[1]['start']==18
assert all(p['text']==text[p['start']:p['end']] for p in parts)
print(parts)
