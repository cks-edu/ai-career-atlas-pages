def fuse(rankings,k=60):
    scores={}
    for ranking in rankings:
        if len(ranking)!=len(set(ranking)): raise ValueError('Duplicate result ID')
        for rank,key in enumerate(ranking,1): scores[key]=scores.get(key,0)+1/(k+rank)
    return sorted(scores,key=lambda key:(-scores[key],key))
assert fuse([['a','b'],['b','c']])[0]=='b'
assert fuse([])==[]
print(fuse([['a','b'],['b','c']]))
