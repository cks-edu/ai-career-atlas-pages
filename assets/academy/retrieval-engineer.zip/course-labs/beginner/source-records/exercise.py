sources={'policy-1':{'revision':2,'title':'Demo return policy','text':'Returns accepted within 14 days.'}}
chunks=[{'id':'policy-1:c1','source_id':'policy-1','revision':2,'text':sources['policy-1']['text']}]
result=chunks[0]
assert result['source_id'] in sources
assert result['revision']==sources[result['source_id']]['revision']
print(result)
