import re
docs={'a':'reset your password','b':'track a delivery'}
def words(text): return set(re.findall(r'\w+',text.lower()))
def search(query):
    scored=[(len(words(query)&words(text)),key) for key,text in docs.items()]
    return [key for score,key in sorted(scored,key=lambda x:(-x[0],x[1])) if score>0]
assert search('password reset')==['a']
assert search('volcano')==[]
print('PASS: matching result and honest no-match')
