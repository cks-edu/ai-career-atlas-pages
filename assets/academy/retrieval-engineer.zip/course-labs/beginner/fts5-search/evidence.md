# Search real text with SQLite FTS5

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://www.sqlite.org/fts5.html
https://docs.python.org/3/library/sqlite3.html
