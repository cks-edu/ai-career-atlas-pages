import sqlite3
with sqlite3.connect(':memory:') as db:
    db.execute('CREATE VIRTUAL TABLE docs USING fts5(id UNINDEXED, body)')
    db.executemany('INSERT INTO docs VALUES (?,?)',[('a','reset your password'),('b','track a delivery')])
    rows=db.execute('SELECT id FROM docs WHERE docs MATCH ? ORDER BY rank',('password',)).fetchall()
    assert rows==[('a',)]
    assert db.execute('SELECT id FROM docs WHERE docs MATCH ?',('volcano',)).fetchall()==[]
print('PASS: real FTS5 match and no-match')
