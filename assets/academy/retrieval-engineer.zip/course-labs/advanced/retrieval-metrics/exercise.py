def recall_at_k(results,relevant,k):
    if k<1: raise ValueError('Positive k required')
    if not relevant: return None
    return len(set(results[:k])&set(relevant))/len(set(relevant))
assert recall_at_k(['a','b','c'],{'a','c'},2)==0.5
assert recall_at_k(['a','a'],{'a','b'},2)==0.5
assert recall_at_k([],set(),2) is None
print('PASS: recall denominator, duplicates and unknown evidence')
