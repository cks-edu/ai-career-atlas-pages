# Measure retrieval before judging the answer

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://qdrant.tech/documentation/search/hybrid-queries/
https://www.nist.gov/itl/ai-risk-management-framework
