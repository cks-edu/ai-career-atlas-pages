# Update the index and its caches together

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://docs.python.org/3/library/sqlite3.html
https://docs.python.org/3/library/hashlib.html
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
