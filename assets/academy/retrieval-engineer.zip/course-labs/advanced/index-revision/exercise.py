cache={}
def key(tenant,permission_rev,corpus_rev,query): return (tenant,permission_rev,corpus_rev,query)
cache[key('a',1,4,'returns')]='old rule'
assert cache.get(key('a',1,4,'returns'))=='old rule'
assert cache.get(key('a',1,5,'returns')) is None
assert cache.get(key('a',2,4,'returns')) is None
assert cache.get(key('b',1,4,'returns')) is None
print('PASS: corpus, permissions and tenant isolate cached answers')
