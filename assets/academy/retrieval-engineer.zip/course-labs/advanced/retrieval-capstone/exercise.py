sources={'returns':{'revision':3,'text':'Returns within 14 days.'}}
def context_valid(result):
    source=sources.get(result.get('source_id'))
    return bool(source and result.get('revision')==source['revision'] and result.get('text')==source['text'])
assert context_valid({'source_id':'returns','revision':3,'text':'Returns within 14 days.'})
assert not context_valid({'source_id':'returns','revision':2,'text':'Returns within 30 days.'})
print('PASS: stale or altered context rejected')
