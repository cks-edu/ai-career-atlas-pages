# RAG / retrieval engineer — core lessons

Learn source identity and lexical search before real SQLite FTS5, chunk boundaries, hybrid rankings and access filtering. Then measure retrieval, version the corpus and test a source-linked search service. A citation provides evidence to inspect; it does not guarantee a generated answer is correct.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A searchable support corpus with document revisions, tenant-aware FTS5 queries, relevance judgments, deletion tests and explicit no-evidence results.
