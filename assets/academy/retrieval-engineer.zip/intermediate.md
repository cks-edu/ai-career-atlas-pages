## intermediate — Chunking and access filters

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, indexing, data pipelines and relevance measurement; learn embeddings and ranking fundamentals.

### Chunking and access filters
Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval.
Mental model: Cut a textbook into cards, keeping chapter labels and borrowing restrictions on every card.
Boundary: Larger chunks can dilute relevance and do not replace permission checks.
Worked example: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Permission-aware knowledge search
Build a knowledge assistant that respects document ownership, deletion and evidence freshness. Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.
Worked example: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Recall: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Identify one observation that would contradict your claim.

### Terms
Chunking and access filters: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a knowledge assistant that respects document ownership, deletion and evidence freshness. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

2. Prepare the project inputs
Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
No such module fts5: use a Python build linked to SQLite with FTS5.
No results: inspect tenant, source text and literal query phrase.
Deletion leak: inspect caches and derived chunks as well as source records.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

### Portfolio
Build a knowledge assistant that respects document ownership, deletion and evidence freshness.
Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.
Deliverables: Ingestion and search service with deletion tests; Judged query set and retrieval comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for RAG / retrieval engineer. Use this scenario: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Review: Start with the task and permitted scope. Explain chunking and access filters: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. Show the input and observed output, then address Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Ingestion and search service with deletion tests; Judged query set and retrieval comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

