# RAG / retrieval engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Relevance judgments. Retrieval means finding relevant information before writing an answer. Finding a useful passage and producing a correct answer are separate checks. Then try Build a tiny answer-source table. The three levels build toward Permission-aware knowledge search. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Relevance judgments

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Relevance judgments
Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters.
Mental model: A library catalog points to a useful shelf, not automatically the right page.
Boundary: Similarity scores are not probabilities that an answer is correct.
Worked example: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Deleted policies still retrieved
The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Two deleted sources remain discoverable beyond the stated freshness limit. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval.
Recall: Check deleted and active sources using normal user identities; a fresh ingestion job alone is insufficient. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Relevance judgments: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Retrieval means finding relevant information before writing an answer. Finding a useful passage and producing a correct answer are separate checks.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Write three fictional school rules: “Library closes at 6 pm”; “Books may be borrowed for 14 days”; “Lost cards must be reported to reception.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

3. Try step 2
Match these questions to a rule: “When does the library close?”, “How long can I keep a book?”, “Is printing free?”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

4. Try step 3
Copy the supporting sentence for each answer; mark the printing question as not covered.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

5. Explain and check your result
Every factual answer has a supporting sentence; missing information is left unknown rather than invented. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A three-row question, answer and source table. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Apply this toy-case rule manually: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two deleted sources remain discoverable beyond the stated freshness limit. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to RAG / retrieval engineer.
Write three fictional school rules: “Library closes at 6 pm”; “Books may be borrowed for 14 days”; “Lost cards must be reported to reception.”
Match these questions to a rule: “When does the library close?”, “How long can I keep a book?”, “Is printing free?”
Copy the supporting sentence for each answer; mark the printing question as not covered.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A three-row question, answer and source table. Include beginner-worksheet.md and your completed Freshness audit and deletion runbook.
Check: Every factual answer has a supporting sentence; missing information is left unknown rather than invented.

### Interview
Explain your beginner solution for RAG / retrieval engineer. Use this scenario: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes.
Review: Start with the task and permitted scope. Explain relevance judgments: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. Show the input and observed output, then address Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A three-row question, answer and source table. Include beginner-worksheet.md and your completed Freshness audit and deletion runbook.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Chunking and access filters

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, indexing, data pipelines and relevance measurement; learn embeddings and ranking fundamentals.

### Chunking and access filters
Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval.
Mental model: Cut a textbook into cards, keeping chapter labels and borrowing restrictions on every card.
Boundary: Larger chunks can dilute relevance and do not replace permission checks.
Worked example: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Permission-aware knowledge search
Build a knowledge assistant that respects document ownership, deletion and evidence freshness. Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.
Worked example: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Recall: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Identify one observation that would contradict your claim.

### Terms
Chunking and access filters: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a knowledge assistant that respects document ownership, deletion and evidence freshness. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

2. Prepare the project inputs
Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
No such module fts5: use a Python build linked to SQLite with FTS5.
No results: inspect tenant, source text and literal query phrase.
Deletion leak: inspect caches and derived chunks as well as source records.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

### Portfolio
Build a knowledge assistant that respects document ownership, deletion and evidence freshness.
Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.
Deliverables: Ingestion and search service with deletion tests; Judged query set and retrieval comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for RAG / retrieval engineer. Use this scenario: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Review: Start with the task and permitted scope. Explain chunking and access filters: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. Show the input and observed output, then address Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Ingestion and search service with deletion tests; Judged query set and retrieval comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Grounded answer evaluation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Grounded answer evaluation
Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined.
Mental model: First inspect the evidence delivered to a witness, then inspect the witness's explanation.
Boundary: A correct citation format does not prove the claim is supported.
Worked example: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Permission-aware knowledge search
Build a knowledge assistant that respects document ownership, deletion and evidence freshness. Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.
Worked example: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Recall: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Identify one observation that would contradict your claim.

### Terms
Grounded answer evaluation: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a knowledge assistant that respects document ownership, deletion and evidence freshness. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

2. Prepare the project inputs
Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
No such module fts5: use a Python build linked to SQLite with FTS5.
No results: inspect tenant, source text and literal query phrase.
Deletion leak: inspect caches and derived chunks as well as source records.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

### Portfolio
Build a knowledge assistant that respects document ownership, deletion and evidence freshness.
Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.
Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.
Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.
Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.
Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.
Add document-level ACLs with group membership changes and measure the maximum revocation propagation delay.
Deliverables: Ingestion and search service with deletion tests; Judged query set and retrieval comparison; Permission-flow diagram and freshness dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A reviewer must reproduce one result and identify which capabilities you implemented. Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

### Interview
Explain your advanced solution for RAG / retrieval engineer. Use this scenario: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.
Review: Start with the task and permitted scope. Explain grounded answer evaluation: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. Show the input and observed output, then address Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Ingestion and search service with deletion tests; Judged query set and retrieval comparison; Permission-flow diagram and freshness dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
SQLite FTS5 — Public domain · local
Full-text retrieval with explicit tenant filtering.
Alternative: PostgreSQL full-text search (open source); compare deployment effort, concurrency and language processing.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

pgvector — Open source · PostgreSQL extension
Vector retrieval comparison; requires a PostgreSQL installation.
Alternative: OpenSearch (open source) or a commercial managed vector service; compare filters, indexing and operating cost.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Ollama — Open source runtime · model licenses vary
Local generation; choose a model that fits memory and permitted use.
Alternative: llama.cpp (open source) for local inference, or a commercial hosted API; model licenses and memory requirements remain separate.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
SQLite FTS5: https://www.sqlite.org/fts5.html
pgvector: https://github.com/pgvector/pgvector
Ollama: https://docs.ollama.com/api/generate
pgvector: https://github.com/pgvector/pgvector
PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
