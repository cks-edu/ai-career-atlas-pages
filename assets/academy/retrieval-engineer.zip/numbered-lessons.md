# RAG / retrieval engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Relevance judgments: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Start with documents, chunks and source IDs

Retrieval finds relevant pieces of information before an answer is written. A document is the source; a chunk is one searchable part. Preserve the relationship so a result can link to its actual evidence.

How it works
Each chunk below names its document and revision. A result resolves through this source table. Keep the original text and authorized source location when you build a real index.

Where the model stops
A real source URL and a correct ID do not prove that an answer is supported. Someone must compare the claim with the cited text.

Make one change
Add a second document with a different return period and a third with missing provenance. Keep only identified, permitted sources in your searchable list. Explain how a citation should expose the edition.

Mental model: A library index points to a page in a particular edition, not just to a book-shaped object.

Boundary: A real source URL and a correct ID do not prove that an answer is supported. Someone must compare the claim with the cited text.

Worked example: sources={'policy-1':{'revision':2,'title':'Demo return policy','text':'Returns accepted within 14 days.'}}
chunks=[{'id':'policy-1:c1','source_id':'policy-1','revision':2,'text':sources['policy-1']['text']}]
result=chunks[0]
assert result['source_id'] in sources
assert result['revision']==sources[result['source_id']]['revision']
print(result)


Setup: Download and extract retrieval-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/source-records. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a second document with a different return period and a third with missing provenance. Keep only identified, permitted sources in your searchable list. Explain how a citation should expose the edition.

Terminal folder: course-labs/beginner/source-records

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Each chunk below names its document and revision. A result resolves through this source table. Keep the original text and authorized source location when you build a real index.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/source-records. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The reference chunk resolves to policy-1 revision 2. Your list retains different policies as different sources and flags unknown provenance.

Build your change

Add a second document with a different return period and a third with missing provenance. Keep only identified, permitted sources in your searchable list. Explain how a citation should expose the edition.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The reference chunk resolves to policy-1 revision 2. Your list retains different policies as different sources and flags unknown provenance.

Break, repair and explain

Deliberately violate this boundary: A real source URL and a correct ID do not prove that an answer is supported. Someone must compare the claim with the cited text. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The reference chunk resolves to policy-1 revision 2. Your list retains different policies as different sources and flags unknown provenance.

Troubleshoot: My result does not match Start with documents, chunks and source IDs: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Each chunk below names its document and revision. A result resolves through this source table. Keep the original text and authorized source location when you build a real index. Then inspect this limit: A real source URL and a correct ID do not prove that an answer is supported. Someone must compare the claim with the cited text. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/source-records/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Start with documents, chunks and source IDs line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A library index points to a page in a particular edition, not just to a book-shaped object.

seeker: Prepare a coursework example for RAG / retrieval engineer. Answer this interview question before revealing the rubric: What does a valid source ID establish? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A real source URL and a correct ID do not prove that an answer is supported. Someone must compare the claim with the cited text. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What does a valid source ID establish?

Interview: What does a valid source ID establish? Defend your answer using your actual lab result and this boundary: A real source URL and a correct ID do not prove that an answer is supported. Someone must compare the claim with the cited text.

Quiz: What does a valid source ID establish?

Every generated claim is correct.

The result can be resolved to a known source record.

The document is current forever.

Reference: The result can be resolved to a known source record. — Identity enables evidence lookup. It does not establish freshness, authorization or support for every claim.

Sources:

Python: JSON documents and parsing: https://docs.python.org/3/library/json.html

Python: cryptographic hashes: https://docs.python.org/3/library/hashlib.html

### Build your first keyword retriever

Keyword retrieval compares a query with document terms. Begin with a transparent baseline so you can inspect why each result matched. This simple overlap score is useful for learning, but it is not BM25 or semantic embedding search.

How it works
Tokenize words consistently, score their set overlap and use a stable ID to break ties. A query with no matches returns no result rather than inventing an answer.

Where the model stops
Word overlap misses synonyms, ignores word order and can rank repeated boilerplate poorly. Evaluate against examples before selecting a more complex retriever.

Make one change
Add five short support documents and six queries, including a synonym and a no-answer case. Write the expected relevant IDs before running the search. Record one failure rather than editing the expectations to fit the score.

Mental model: An index clerk highlights shared words, then lists the pages with the most matches.

Boundary: Word overlap misses synonyms, ignores word order and can rank repeated boilerplate poorly. Evaluate against examples before selecting a more complex retriever.

Worked example: import re
docs={'a':'reset your password','b':'track a delivery'}
def words(text): return set(re.findall(r'\w+',text.lower()))
def search(query):
    scored=[(len(words(query)&words(text)),key) for key,text in docs.items()]
    return [key for score,key in sorted(scored,key=lambda x:(-x[0],x[1])) if score>0]
assert search('password reset')==['a']
assert search('volcano')==[]
print('PASS: matching result and honest no-match')


Setup: Download and extract retrieval-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/keyword-search. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add five short support documents and six queries, including a synonym and a no-answer case. Write the expected relevant IDs before running the search. Record one failure rather than editing the expectations to fit the score.

Terminal folder: course-labs/beginner/keyword-search

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Tokenize words consistently, score their set overlap and use a stable ID to break ties. A query with no matches returns no result rather than inventing an answer.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/keyword-search. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The known phrase returns a; the unrelated query returns nothing. Your test table shows where lexical overlap stops being enough.

Build your change

Add five short support documents and six queries, including a synonym and a no-answer case. Write the expected relevant IDs before running the search. Record one failure rather than editing the expectations to fit the score.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The known phrase returns a; the unrelated query returns nothing. Your test table shows where lexical overlap stops being enough.

Break, repair and explain

Deliberately violate this boundary: Word overlap misses synonyms, ignores word order and can rank repeated boilerplate poorly. Evaluate against examples before selecting a more complex retriever. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The known phrase returns a; the unrelated query returns nothing. Your test table shows where lexical overlap stops being enough.

Troubleshoot: My result does not match Build your first keyword retriever: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Tokenize words consistently, score their set overlap and use a stable ID to break ties. A query with no matches returns no result rather than inventing an answer. Then inspect this limit: Word overlap misses synonyms, ignores word order and can rank repeated boilerplate poorly. Evaluate against examples before selecting a more complex retriever. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/keyword-search/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Build your first keyword retriever line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: An index clerk highlights shared words, then lists the pages with the most matches.

seeker: Prepare a coursework example for RAG / retrieval engineer. Answer this interview question before revealing the rubric: No document matches a query. What should this baseline return? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Word overlap misses synonyms, ignores word order and can rank repeated boilerplate poorly. Evaluate against examples before selecting a more complex retriever. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: No document matches a query. What should this baseline return?

Interview: No document matches a query. What should this baseline return? Defend your answer using your actual lab result and this boundary: Word overlap misses synonyms, ignores word order and can rank repeated boilerplate poorly. Evaluate against examples before selecting a more complex retriever.

Quiz: No document matches a query. What should this baseline return?

The first document anyway.

A confident generated answer.

An empty result with an explicit no-match state.

Reference: An empty result with an explicit no-match state. — A retriever should preserve missing evidence. Returning an arbitrary page can turn a known gap into misleading context.

Sources:

SQLite: FTS5 full-text search: https://www.sqlite.org/fts5.html

### Search real text with SQLite FTS5

SQLite FTS5 builds a full-text index inside a local database. Unlike the previous Python score, this exercise runs an actual search engine. Search syntax and authorization still need their own boundaries.

How it works
Create an in-memory FTS5 table, insert two documents and query with a parameter. MATCH uses the full-text query language. Parameterization protects the SQL boundary but does not remove FTS syntax errors.

Where the model stops
Some Python SQLite builds omit FTS5. If creation reports no such module, check sqlite3.sqlite_version and your distribution’s FTS5 support; do not describe a skipped test as a pass.

Make one change
Add a phrase query and an invalid FTS expression. Catch and report the syntax error without exposing database details. Explain why the SQL placeholder does not turn user text into a harmless literal search term.

Mental model: An indexed filing cabinet finds a term without opening every folder in your application code.

Boundary: Some Python SQLite builds omit FTS5. If creation reports no such module, check sqlite3.sqlite_version and your distribution’s FTS5 support; do not describe a skipped test as a pass.

Worked example: import sqlite3
with sqlite3.connect(':memory:') as db:
    db.execute('CREATE VIRTUAL TABLE docs USING fts5(id UNINDEXED, body)')
    db.executemany('INSERT INTO docs VALUES (?,?)',[('a','reset your password'),('b','track a delivery')])
    rows=db.execute('SELECT id FROM docs WHERE docs MATCH ? ORDER BY rank',('password',)).fetchall()
    assert rows==[('a',)]
    assert db.execute('SELECT id FROM docs WHERE docs MATCH ?',('volcano',)).fetchall()==[]
print('PASS: real FTS5 match and no-match')


Setup: Download and extract retrieval-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/fts5-search. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python sqlite3 · SQLite FTS5

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a phrase query and an invalid FTS expression. Catch and report the syntax error without exposing database details. Explain why the SQL placeholder does not turn user text into a harmless literal search term.

Terminal folder: course-labs/beginner/fts5-search

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Create an in-memory FTS5 table, insert two documents and query with a parameter. MATCH uses the full-text query language. Parameterization protects the SQL boundary but does not remove FTS syntax errors.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/fts5-search. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The actual FTS5 query returns a only. Your additional cases distinguish a valid no-match result from a malformed query.

Build your change

Add a phrase query and an invalid FTS expression. Catch and report the syntax error without exposing database details. Explain why the SQL placeholder does not turn user text into a harmless literal search term.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The actual FTS5 query returns a only. Your additional cases distinguish a valid no-match result from a malformed query.

Break, repair and explain

Deliberately violate this boundary: Some Python SQLite builds omit FTS5. If creation reports no such module, check sqlite3.sqlite_version and your distribution’s FTS5 support; do not describe a skipped test as a pass. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The actual FTS5 query returns a only. Your additional cases distinguish a valid no-match result from a malformed query.

Troubleshoot: My result does not match Search real text with SQLite FTS5: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Create an in-memory FTS5 table, insert two documents and query with a parameter. MATCH uses the full-text query language. Parameterization protects the SQL boundary but does not remove FTS syntax errors. Then inspect this limit: Some Python SQLite builds omit FTS5. If creation reports no such module, check sqlite3.sqlite_version and your distribution’s FTS5 support; do not describe a skipped test as a pass. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/fts5-search/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Search real text with SQLite FTS5 line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: An indexed filing cabinet finds a term without opening every folder in your application code.

seeker: Prepare a coursework example for RAG / retrieval engineer. Answer this interview question before revealing the rubric: A parameterized MATCH query is protected from SQL string concatenation. What still needs handling? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Some Python SQLite builds omit FTS5. If creation reports no such module, check sqlite3.sqlite_version and your distribution’s FTS5 support; do not describe a skipped test as a pass. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A parameterized MATCH query is protected from SQL string concatenation. What still needs handling?

Interview: A parameterized MATCH query is protected from SQL string concatenation. What still needs handling? Defend your answer using your actual lab result and this boundary: Some Python SQLite builds omit FTS5. If creation reports no such module, check sqlite3.sqlite_version and your distribution’s FTS5 support; do not describe a skipped test as a pass.

Quiz: A parameterized MATCH query is protected from SQL string concatenation. What still needs handling?

FTS query syntax and access policy.

Nothing else.

Only the font size.

Reference: FTS query syntax and access policy. — SQL parameters protect one boundary. The FTS language is still parsed, and permitted documents must be selected independently.

Sources:

SQLite: FTS5 full-text search: https://www.sqlite.org/fts5.html

Python: SQLite database interface: https://docs.python.org/3/library/sqlite3.html

### Relevance judgments

Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. In this role, work through: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A library catalog points to a useful shelf, not automatically the right page.

Boundary: Similarity scores are not probabilities that an answer is correct.

Worked example: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for RAG / retrieval engineer: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.

Predict the worked case

Read this case without running a tool: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in relevance judgments.

Connect the concept to the role

Apply this rule: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Similarity scores are not probabilities that an answer is correct.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies relevance judgments to this case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Relevance judgments; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with relevance judgments. Use the glossary below, then write your prediction for: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain relevance judgments using this case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate relevance judgments to a system or workflow you know. Explain relevance judgments using this case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain relevance judgments using this case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.

Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. — Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. Similarity scores are not probabilities that an answer is correct.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Diagnose: Deleted policies still retrieved

The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Two deleted sources remain discoverable beyond the stated freshness limit. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A library catalog points to a useful shelf, not automatically the right page.

For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.

Worked example: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Two deleted sources remain discoverable beyond the stated freshness limit. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Apply this toy-case rule manually: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Retrieval means finding relevant information before writing an answer. Finding a useful passage and producing a correct answer are separate checks.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Write three fictional school rules: “Library closes at 6 pm”; “Books may be borrowed for 14 days”; “Lost cards must be reported to reception.”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

Preparation · Try step 2

Match these questions to a rule: “When does the library close?”, “How long can I keep a book?”, “Is printing free?”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

Preparation · Try step 3

Copy the supporting sentence for each answer; mark the printing question as not covered.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

Preparation · Explain and check your result

Every factual answer has a supporting sentence; missing information is left unknown rather than invented. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A three-row question, answer and source table. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Apply this toy-case rule manually: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two deleted sources remain discoverable beyond the stated freshness limit. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two deleted sources remain discoverable beyond the stated freshness limit. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: deleted policies still retrieved. Use the glossary below, then write your prediction for: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain diagnose: deleted policies still retrieved using this case: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: deleted policies still retrieved to a system or workflow you know. Explain diagnose: deleted policies still retrieved using this case: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Check deleted and active sources using normal user identities; a fresh ingestion job alone is insufficient. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: deleted policies still retrieved using this case: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. State the evidence, one alternative and where the mental model stops.

Quiz: Deleted policies still retrieved: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes.

Change the acceptance rule after seeing an inconvenient result.

Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval.

Omit failed cases and report only the successful demonstrations.

Reference: Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. — Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. Check deleted and active sources using normal user identities; a fresh ingestion job alone is insufficient.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, indexing, data pipelines and relevance measurement; learn embeddings and ranking fundamentals.

Terms:

Chunking and access filters: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Choose chunk boundaries that preserve meaning

Chunking changes what can be retrieved together. Very small pieces may omit the rule’s condition; very large pieces may mix unrelated topics. Keep source offsets or another reproducible locator so a reviewer can inspect the original context.

How it works
This character-window fixture uses an explicit overlap and returns start/end offsets. It demonstrates boundary mechanics, not token counts or a model context budget. Compare the excerpt with the source before indexing.

Where the model stops
Characters are not model tokens. Overlap adds duplicates and does not guarantee that an exception remains with its rule.

Make one change
Compare character windows with sentence-based chunks for three rules that contain exceptions. Keep offsets, label the complete relevant evidence and report a query whose answer changes when the exception is missing.

Mental model: Photocopying half a sentence can preserve the words while losing the exception on the next line.

Boundary: Characters are not model tokens. Overlap adds duplicates and does not guarantee that an exception remains with its rule.

Worked example: def chunk(text,size=24,overlap=6):
    if not 0<=overlap<size: raise ValueError('Invalid overlap')
    return [{'start':i,'end':min(i+size,len(text)),'text':text[i:i+size]} for i in range(0,len(text),size-overlap)]
text='Returns are allowed within 14 days unless an item was opened.'
parts=chunk(text)
assert parts[1]['start']==18
assert all(p['text']==text[p['start']:p['end']] for p in parts)
print(parts)


Setup: Download and extract retrieval-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/chunk-boundary. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Compare character windows with sentence-based chunks for three rules that contain exceptions. Keep offsets, label the complete relevant evidence and report a query whose answer changes when the exception is missing.

Terminal folder: course-labs/intermediate/chunk-boundary

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. This character-window fixture uses an explicit overlap and returns start/end offsets. It demonstrates boundary mechanics, not token counts or a model context budget. Compare the excerpt with the source before indexing.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/chunk-boundary. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Every printed excerpt resolves to its original offsets. Your comparison shows a real completeness trade-off instead of assuming overlap guarantees context.

Build your change

Compare character windows with sentence-based chunks for three rules that contain exceptions. Keep offsets, label the complete relevant evidence and report a query whose answer changes when the exception is missing.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Every printed excerpt resolves to its original offsets. Your comparison shows a real completeness trade-off instead of assuming overlap guarantees context.

Break, repair and explain

Deliberately violate this boundary: Characters are not model tokens. Overlap adds duplicates and does not guarantee that an exception remains with its rule. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Every printed excerpt resolves to its original offsets. Your comparison shows a real completeness trade-off instead of assuming overlap guarantees context.

Troubleshoot: My result does not match Choose chunk boundaries that preserve meaning: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: This character-window fixture uses an explicit overlap and returns start/end offsets. It demonstrates boundary mechanics, not token counts or a model context budget. Compare the excerpt with the source before indexing. Then inspect this limit: Characters are not model tokens. Overlap adds duplicates and does not guarantee that an exception remains with its rule. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/chunk-boundary/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Choose chunk boundaries that preserve meaning line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Photocopying half a sentence can preserve the words while losing the exception on the next line.

seeker: Prepare a coursework example for RAG / retrieval engineer. Answer this interview question before revealing the rubric: Does a 500-character chunk always fit a 500-token budget? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Characters are not model tokens. Overlap adds duplicates and does not guarantee that an exception remains with its rule. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does a 500-character chunk always fit a 500-token budget?

Interview: Does a 500-character chunk always fit a 500-token budget? Defend your answer using your actual lab result and this boundary: Characters are not model tokens. Overlap adds duplicates and does not guarantee that an exception remains with its rule.

Quiz: Does a 500-character chunk always fit a 500-token budget?

Yes.

No; characters and model tokens are different units.

Only if overlap is zero.

Reference: No; characters and model tokens are different units. — Tokenization depends on the model and text. Measure with the selected tokenizer when enforcing a token budget.

Sources:

SQLite: FTS5 full-text search: https://www.sqlite.org/fts5.html

Python: JSON documents and parsing: https://docs.python.org/3/library/json.html

### Combine rankings without mixing score scales

A lexical retriever and a vector retriever may return different score ranges. Combining ranked lists is one way to compare them without pretending raw scores share a unit. Keep an evaluation set to test whether fusion actually helps.

How it works
Reciprocal-rank fusion adds 1/(k+rank) for each result. The lists below are synthetic; no vector model is executed. Their stable ordering makes the contribution of each retriever visible.

Where the model stops
The fusion constant is a design choice, not a universal optimum. Correlated retrievers and poor candidates can still produce poor fused results.

Make one change
Run FTS5 on your query set and compare its ranking with a separately declared second retriever. Fuse the IDs and measure relevance before/after. If using embeddings, record model name, version and distance metric.

Mental model: Two judges can combine ordered shortlists even when one scores out of ten and another out of one hundred.

Boundary: The fusion constant is a design choice, not a universal optimum. Correlated retrievers and poor candidates can still produce poor fused results.

Worked example: def fuse(rankings,k=60):
    scores={}
    for ranking in rankings:
        if len(ranking)!=len(set(ranking)): raise ValueError('Duplicate result ID')
        for rank,key in enumerate(ranking,1): scores[key]=scores.get(key,0)+1/(k+rank)
    return sorted(scores,key=lambda key:(-scores[key],key))
assert fuse([['a','b'],['b','c']])[0]=='b'
assert fuse([])==[]
print(fuse([['a','b'],['b','c']]))


Setup: Download and extract retrieval-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/hybrid-ranking. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python · SQLite FTS5 · optional vector retriever

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Run FTS5 on your query set and compare its ranking with a separately declared second retriever. Fuse the IDs and measure relevance before/after. If using embeddings, record model name, version and distance metric.

Terminal folder: course-labs/intermediate/hybrid-ranking

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Reciprocal-rank fusion adds 1/(k+rank) for each result. The lists below are synthetic; no vector model is executed. Their stable ordering makes the contribution of each retriever visible.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/hybrid-ranking. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The fixture ranks b first because both lists support it. Your experiment states whether fusion improved relevant-document recall for your actual cases.

Build your change

Run FTS5 on your query set and compare its ranking with a separately declared second retriever. Fuse the IDs and measure relevance before/after. If using embeddings, record model name, version and distance metric.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The fixture ranks b first because both lists support it. Your experiment states whether fusion improved relevant-document recall for your actual cases.

Break, repair and explain

Deliberately violate this boundary: The fusion constant is a design choice, not a universal optimum. Correlated retrievers and poor candidates can still produce poor fused results. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The fixture ranks b first because both lists support it. Your experiment states whether fusion improved relevant-document recall for your actual cases.

Troubleshoot: My result does not match Combine rankings without mixing score scales: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Reciprocal-rank fusion adds 1/(k+rank) for each result. The lists below are synthetic; no vector model is executed. Their stable ordering makes the contribution of each retriever visible. Then inspect this limit: The fusion constant is a design choice, not a universal optimum. Correlated retrievers and poor candidates can still produce poor fused results. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/hybrid-ranking/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Combine rankings without mixing score scales line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Two judges can combine ordered shortlists even when one scores out of ten and another out of one hundred.

seeker: Prepare a coursework example for RAG / retrieval engineer. Answer this interview question before revealing the rubric: Why avoid adding unrelated raw similarity and keyword scores directly? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The fusion constant is a design choice, not a universal optimum. Correlated retrievers and poor candidates can still produce poor fused results. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why avoid adding unrelated raw similarity and keyword scores directly?

Interview: Why avoid adding unrelated raw similarity and keyword scores directly? Defend your answer using your actual lab result and this boundary: The fusion constant is a design choice, not a universal optimum. Correlated retrievers and poor candidates can still produce poor fused results.

Quiz: Why avoid adding unrelated raw similarity and keyword scores directly?

Their numeric scales may not be comparable.

Rankings are always perfect.

Vectors guarantee true answers.

Reference: Their numeric scales may not be comparable. — A score is meaningful within its retrieval method. Rank fusion avoids a direct unit mismatch, but it still needs evaluation.

Sources:

Qdrant: hybrid and multi-stage queries: https://qdrant.tech/documentation/search/hybrid-queries/

### Filter access before results become context

A relevant document may still belong to another tenant. Apply access rules as part of retrieval and again where necessary before returning context. A model must never receive a forbidden excerpt and be expected to hide it.

How it works
The query below binds tenant and search term separately. The tenant comes from authenticated context in a real service. This exercise uses a synthetic caller value and actual SQLite filtering.

Where the model stops
A client-supplied tenant string is not authentication. Filters must reflect current permissions, including revoked access and deleted documents.

Make one change
Add a current-permission table and a revoked document. Test both tenants, an unknown principal and a cached result from before revocation. Keep the forbidden text out of the returned context.

Mental model: The librarian checks your library card before handing you a private file, not after you have read it.

Boundary: A client-supplied tenant string is not authentication. Filters must reflect current permissions, including revoked access and deleted documents.

Worked example: import sqlite3
with sqlite3.connect(':memory:') as db:
    db.execute('CREATE VIRTUAL TABLE docs USING fts5(tenant UNINDEXED,id UNINDEXED,body)')
    db.executemany('INSERT INTO docs VALUES (?,?,?)',[('team-a','a','password reset'),('team-b','b','password reset')])
    rows=db.execute('SELECT id,body FROM docs WHERE docs MATCH ? AND tenant=?',('password','team-a')).fetchall()
    assert [r[0] for r in rows]==['a']
print('PASS: only team-a context returned')


Setup: Download and extract retrieval-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/retrieval-access. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python sqlite3 · SQLite FTS5

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a current-permission table and a revoked document. Test both tenants, an unknown principal and a cached result from before revocation. Keep the forbidden text out of the returned context.

Terminal folder: course-labs/intermediate/retrieval-access

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The query below binds tenant and search term separately. The tenant comes from authenticated context in a real service. This exercise uses a synthetic caller value and actual SQLite filtering.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/retrieval-access. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Only team-a’s result is returned. Your revocation case denies a previously accessible document and invalidates affected cache entries.

Build your change

Add a current-permission table and a revoked document. Test both tenants, an unknown principal and a cached result from before revocation. Keep the forbidden text out of the returned context.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Only team-a’s result is returned. Your revocation case denies a previously accessible document and invalidates affected cache entries.

Break, repair and explain

Deliberately violate this boundary: A client-supplied tenant string is not authentication. Filters must reflect current permissions, including revoked access and deleted documents. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Only team-a’s result is returned. Your revocation case denies a previously accessible document and invalidates affected cache entries.

Troubleshoot: My result does not match Filter access before results become context: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The query below binds tenant and search term separately. The tenant comes from authenticated context in a real service. This exercise uses a synthetic caller value and actual SQLite filtering. Then inspect this limit: A client-supplied tenant string is not authentication. Filters must reflect current permissions, including revoked access and deleted documents. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/retrieval-access/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Filter access before results become context line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: The librarian checks your library card before handing you a private file, not after you have read it.

seeker: Prepare a coursework example for RAG / retrieval engineer. Answer this interview question before revealing the rubric: Is it safe to send both tenants’ excerpts to the model and ask it to hide the other tenant? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A client-supplied tenant string is not authentication. Filters must reflect current permissions, including revoked access and deleted documents. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Is it safe to send both tenants’ excerpts to the model and ask it to hide the other tenant?

Interview: Is it safe to send both tenants’ excerpts to the model and ask it to hide the other tenant? Defend your answer using your actual lab result and this boundary: A client-supplied tenant string is not authentication. Filters must reflect current permissions, including revoked access and deleted documents.

Quiz: Is it safe to send both tenants’ excerpts to the model and ask it to hide the other tenant?

Yes.

Yes, if the prompt is clear.

No; prevent forbidden context from reaching the model.

Reference: No; prevent forbidden context from reaching the model. — The information boundary is crossed when the model receives the text. Enforce permissions before that point.

Sources:

OWASP: authorization guidance: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

SQLite: FTS5 full-text search: https://www.sqlite.org/fts5.html

### Chunking and access filters

Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. In this role, work through: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Cut a textbook into cards, keeping chapter labels and borrowing restrictions on every card.

Boundary: Larger chunks can dilute relevance and do not replace permission checks.

Worked example: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, indexing, data pipelines and relevance measurement; learn embeddings and ranking fundamentals.

Tools for this exercise: Document or text editor

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for RAG / retrieval engineer: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.

Predict the worked case

Read this case without running a tool: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in chunking and access filters.

Connect the concept to the role

Apply this rule: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Larger chunks can dilute relevance and do not replace permission checks.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies chunking and access filters to this case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Chunking and access filters; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with chunking and access filters. Use the glossary below, then write your prediction for: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain chunking and access filters using this case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate chunking and access filters to a system or workflow you know. Explain chunking and access filters using this case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain chunking and access filters using this case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.

Treat a passing starter as proof of the whole role workflow.

Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval.

Ignore the failure because the tool produced an output.

Reference: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. — Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. Larger chunks can dilute relevance and do not replace permission checks.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Integrate: Permission-aware knowledge search

Build a knowledge assistant that respects document ownership, deletion and evidence freshness. Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision. In this role, work through: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Role application: Cut a textbook into cards, keeping chapter labels and borrowing restrictions on every card.

A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.

Worked example: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.

Setup: Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Build a knowledge assistant that respects document ownership, deletion and evidence freshness. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Build a knowledge assistant that respects document ownership, deletion and evidence freshness.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

Prepare the project inputs

Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Deliverable: lesson-intermediate-2.md: Ingestion and search service with deletion tests; Judged query set and retrieval comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: permission-aware knowledge search. Use the glossary below, then write your prediction for: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain integrate: permission-aware knowledge search using this case: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: permission-aware knowledge search to a system or workflow you know. Explain integrate: permission-aware knowledge search using this case: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Identify one observation that would contradict your claim.

Interview: Explain integrate: permission-aware knowledge search using this case: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Permission-aware knowledge search at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

Reference: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. — Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Grounded answer evaluation: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Measure retrieval before judging the answer

A generation failure may begin with missing evidence. Evaluate the retriever separately using queries with judged relevant document IDs. Recall@k measures how much relevant evidence appears within the first k results.

How it works
Intersect the returned top-k IDs with the judged relevant set. Count unique IDs, and handle queries with no known relevant documents separately. Do not turn an undefined no-evidence case into perfect recall.

Where the model stops
Judgments can be incomplete. High recall does not prove correct ordering, source freshness or answer faithfulness.

Make one change
Create at least ten judged queries, including no-answer, synonym and permission-filtered cases. Compare k=1 and k=3, preserve the cases where recall worsens, and separately assess generated answer support.

Mental model: Check whether the ingredients reached the kitchen before blaming the recipe.

Boundary: Judgments can be incomplete. High recall does not prove correct ordering, source freshness or answer faithfulness.

Worked example: def recall_at_k(results,relevant,k):
    if k<1: raise ValueError('Positive k required')
    if not relevant: return None
    return len(set(results[:k])&set(relevant))/len(set(relevant))
assert recall_at_k(['a','b','c'],{'a','c'},2)==0.5
assert recall_at_k(['a','a'],{'a','b'},2)==0.5
assert recall_at_k([],set(),2) is None
print('PASS: recall denominator, duplicates and unknown evidence')


Setup: Download and extract retrieval-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/retrieval-metrics. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Create at least ten judged queries, including no-answer, synonym and permission-filtered cases. Compare k=1 and k=3, preserve the cases where recall worsens, and separately assess generated answer support.

Terminal folder: course-labs/advanced/retrieval-metrics

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Intersect the returned top-k IDs with the judged relevant set. Count unique IDs, and handle queries with no known relevant documents separately. Do not turn an undefined no-evidence case into perfect recall.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/retrieval-metrics. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The fixture returns 0.5 for partial coverage and None for no judged evidence. Your report separates retrieval errors from generation errors.

Build your change

Create at least ten judged queries, including no-answer, synonym and permission-filtered cases. Compare k=1 and k=3, preserve the cases where recall worsens, and separately assess generated answer support.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The fixture returns 0.5 for partial coverage and None for no judged evidence. Your report separates retrieval errors from generation errors.

Break, repair and explain

Deliberately violate this boundary: Judgments can be incomplete. High recall does not prove correct ordering, source freshness or answer faithfulness. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The fixture returns 0.5 for partial coverage and None for no judged evidence. Your report separates retrieval errors from generation errors.

Troubleshoot: My result does not match Measure retrieval before judging the answer: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Intersect the returned top-k IDs with the judged relevant set. Count unique IDs, and handle queries with no known relevant documents separately. Do not turn an undefined no-evidence case into perfect recall. Then inspect this limit: Judgments can be incomplete. High recall does not prove correct ordering, source freshness or answer faithfulness. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/retrieval-metrics/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Measure retrieval before judging the answer line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Check whether the ingredients reached the kitchen before blaming the recipe.

seeker: Prepare a coursework example for RAG / retrieval engineer. Answer this interview question before revealing the rubric: Recall@3 is high. What remains unproven? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Judgments can be incomplete. High recall does not prove correct ordering, source freshness or answer faithfulness. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Recall@3 is high. What remains unproven?

Interview: Recall@3 is high. What remains unproven? Defend your answer using your actual lab result and this boundary: Judgments can be incomplete. High recall does not prove correct ordering, source freshness or answer faithfulness.

Quiz: Recall@3 is high. What remains unproven?

That relevant IDs were found.

Whether the final answer is faithful and the sources are permitted/current.

The chosen value of k.

Reference: Whether the final answer is faithful and the sources are permitted/current. — Retrieval coverage is one component. Answer support, permission and freshness need separate checks.

Sources:

Qdrant: hybrid and multi-stage queries: https://qdrant.tech/documentation/search/hybrid-queries/

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

### Update the index and its caches together

Changing a source creates a new corpus state. Track an explicit revision for indexed chunks and cached answers. A stale cache can reintroduce deleted or superseded content even after the search index is repaired.

How it works
The fixture keys a cached response by tenant, permission revision, corpus revision and query. Changing any boundary avoids reusing the old answer. Real storage also needs a deletion and invalidation policy.

Where the model stops
A revision key prevents a known cache mismatch; it does not guarantee that all replicas or external caches have removed old data.

Make one change
Implement a source update and deletion in a temporary SQLite index. After each commit, advance the corpus revision and test that an old answer cannot be returned through your cache. Write down the multi-replica limitation.

Mental model: A new book edition needs a new index; old photocopies do not update themselves.

Boundary: A revision key prevents a known cache mismatch; it does not guarantee that all replicas or external caches have removed old data.

Worked example: cache={}
def key(tenant,permission_rev,corpus_rev,query): return (tenant,permission_rev,corpus_rev,query)
cache[key('a',1,4,'returns')]='old rule'
assert cache.get(key('a',1,4,'returns'))=='old rule'
assert cache.get(key('a',1,5,'returns')) is None
assert cache.get(key('a',2,4,'returns')) is None
assert cache.get(key('b',1,4,'returns')) is None
print('PASS: corpus, permissions and tenant isolate cached answers')


Setup: Download and extract retrieval-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/index-revision. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python 3 · standard library

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Implement a source update and deletion in a temporary SQLite index. After each commit, advance the corpus revision and test that an old answer cannot be returned through your cache. Write down the multi-replica limitation.

Terminal folder: course-labs/advanced/index-revision

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture keys a cached response by tenant, permission revision, corpus revision and query. Changing any boundary avoids reusing the old answer. Real storage also needs a deletion and invalidation policy.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/index-revision. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: All three changed boundaries miss the old cache. Your update test verifies the source, search results and cache in the same release report.

Build your change

Implement a source update and deletion in a temporary SQLite index. After each commit, advance the corpus revision and test that an old answer cannot be returned through your cache. Write down the multi-replica limitation.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. All three changed boundaries miss the old cache. Your update test verifies the source, search results and cache in the same release report.

Break, repair and explain

Deliberately violate this boundary: A revision key prevents a known cache mismatch; it does not guarantee that all replicas or external caches have removed old data. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: All three changed boundaries miss the old cache. Your update test verifies the source, search results and cache in the same release report.

Troubleshoot: My result does not match Update the index and its caches together: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture keys a cached response by tenant, permission revision, corpus revision and query. Changing any boundary avoids reusing the old answer. Real storage also needs a deletion and invalidation policy. Then inspect this limit: A revision key prevents a known cache mismatch; it does not guarantee that all replicas or external caches have removed old data. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/index-revision/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Update the index and its caches together line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A new book edition needs a new index; old photocopies do not update themselves.

seeker: Prepare a coursework example for RAG / retrieval engineer. Answer this interview question before revealing the rubric: The index is updated but an answer cache uses only query text. What can happen? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A revision key prevents a known cache mismatch; it does not guarantee that all replicas or external caches have removed old data. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: The index is updated but an answer cache uses only query text. What can happen?

Interview: The index is updated but an answer cache uses only query text. What can happen? Defend your answer using your actual lab result and this boundary: A revision key prevents a known cache mismatch; it does not guarantee that all replicas or external caches have removed old data.

Quiz: The index is updated but an answer cache uses only query text. What can happen?

The old answer can still be served.

Every answer becomes current.

Permissions are automatically refreshed.

Reference: The old answer can still be served. — Cache identity must include the relevant data and access boundaries, with an explicit invalidation plan.

Sources:

Python: SQLite database interface: https://docs.python.org/3/library/sqlite3.html

Python: cryptographic hashes: https://docs.python.org/3/library/hashlib.html

OWASP: authorization guidance: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### Capstone: a source-linked support search service

Build a small support knowledge base with repeatable ingestion, FTS5 search, current permission filtering, source revision links and no-evidence handling. Add generation only after the retrieval contract is measurable.

How it works
The fixture checks the shape and source revision of returned context. Your service must also validate claim support, handle changed permissions, and keep a held-out query set separate from tuning examples.

Where the model stops
Schema checks and citations are not factual verification. This learning project must state which corpus, users and query cases were actually tested.

Make one change
Deliver an ingest script, FTS5 query interface, ten-query relevance set, permission tests and an update/deletion replay. Return source IDs and excerpts or an explicit no-evidence result. Keep screenshots, outputs, a failure analysis and an honest résumé bullet.

Mental model: A reference desk hands back the right page and edition, then says when the library has no answer.

Boundary: Schema checks and citations are not factual verification. This learning project must state which corpus, users and query cases were actually tested.

Worked example: sources={'returns':{'revision':3,'text':'Returns within 14 days.'}}
def context_valid(result):
    source=sources.get(result.get('source_id'))
    return bool(source and result.get('revision')==source['revision'] and result.get('text')==source['text'])
assert context_valid({'source_id':'returns','revision':3,'text':'Returns within 14 days.'})
assert not context_valid({'source_id':'returns','revision':2,'text':'Returns within 30 days.'})
print('PASS: stale or altered context rejected')


Setup: Download and extract retrieval-engineer.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/retrieval-capstone. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Python sqlite3 · SQLite FTS5

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Deliver an ingest script, FTS5 query interface, ten-query relevance set, permission tests and an update/deletion replay. Return source IDs and excerpts or an explicit no-evidence result. Keep screenshots, outputs, a failure analysis and an honest résumé bullet.

Terminal folder: course-labs/advanced/retrieval-capstone

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture checks the shape and source revision of returned context. Your service must also validate claim support, handle changed permissions, and keep a held-out query set separate from tuning examples.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/retrieval-capstone. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Stale context is rejected by the fixture. Your portfolio demonstrates actual retrieval and access tests, with answer faithfulness reviewed separately.

Build your change

Deliver an ingest script, FTS5 query interface, ten-query relevance set, permission tests and an update/deletion replay. Return source IDs and excerpts or an explicit no-evidence result. Keep screenshots, outputs, a failure analysis and an honest résumé bullet.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Stale context is rejected by the fixture. Your portfolio demonstrates actual retrieval and access tests, with answer faithfulness reviewed separately.

Break, repair and explain

Deliberately violate this boundary: Schema checks and citations are not factual verification. This learning project must state which corpus, users and query cases were actually tested. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Stale context is rejected by the fixture. Your portfolio demonstrates actual retrieval and access tests, with answer faithfulness reviewed separately.

Troubleshoot: My result does not match Capstone: a source-linked support search service: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture checks the shape and source revision of returned context. Your service must also validate claim support, handle changed permissions, and keep a held-out query set separate from tuning examples. Then inspect this limit: Schema checks and citations are not factual verification. This learning project must state which corpus, users and query cases were actually tested. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/retrieval-capstone/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Capstone: a source-linked support search service line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A reference desk hands back the right page and edition, then says when the library has no answer.

seeker: Prepare a coursework example for RAG / retrieval engineer. Answer this interview question before revealing the rubric: A response includes a real source link. Can it still be misleading? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Schema checks and citations are not factual verification. This learning project must state which corpus, users and query cases were actually tested. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A response includes a real source link. Can it still be misleading?

Interview: A response includes a real source link. Can it still be misleading? Defend your answer using your actual lab result and this boundary: Schema checks and citations are not factual verification. This learning project must state which corpus, users and query cases were actually tested.

Quiz: A response includes a real source link. Can it still be misleading?

No.

Yes; the claim may not be supported by that source.

Only if the link is broken.

Reference: Yes; the claim may not be supported by that source. — A functioning citation provides a way to check evidence. The claim still needs comparison with the cited excerpt.

Sources:

SQLite: FTS5 full-text search: https://www.sqlite.org/fts5.html

OWASP: authorization guidance: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

NIST: AI Risk Management Framework overview: https://www.nist.gov/itl/ai-risk-management-framework

### Grounded answer evaluation

Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. In this role, work through: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: First inspect the evidence delivered to a witness, then inspect the witness's explanation.

Boundary: A correct citation format does not prove the claim is supported.

Worked example: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for RAG / retrieval engineer: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.

Predict the worked case

Read this case without running a tool: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in grounded answer evaluation.

Connect the concept to the role

Apply this rule: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A correct citation format does not prove the claim is supported.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies grounded answer evaluation to this case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Grounded answer evaluation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with grounded answer evaluation. Use the glossary below, then write your prediction for: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain grounded answer evaluation using this case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate grounded answer evaluation to a system or workflow you know. Explain grounded answer evaluation using this case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain grounded answer evaluation using this case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined.

Reference: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. — Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. A correct citation format does not prove the claim is supported.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Defend: Permission-aware knowledge search

Build a knowledge assistant that respects document ownership, deletion and evidence freshness. Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing. In this role, work through: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Role application: First inspect the evidence delivered to a witness, then inspect the witness's explanation.

A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.

Worked example: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

Setup: Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Build a knowledge assistant that respects document ownership, deletion and evidence freshness. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Build a knowledge assistant that respects document ownership, deletion and evidence freshness.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

Prepare the project inputs

Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A reviewer must reproduce one result and identify which capabilities you implemented. Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Deliverable: lesson-advanced-2.md: Ingestion and search service with deletion tests; Judged query set and retrieval comparison; Permission-flow diagram and freshness dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: permission-aware knowledge search. Use the glossary below, then write your prediction for: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain defend: permission-aware knowledge search using this case: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: permission-aware knowledge search to a system or workflow you know. Explain defend: permission-aware knowledge search using this case: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Identify one observation that would contradict your claim.

Interview: Explain defend: permission-aware knowledge search using this case: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Permission-aware knowledge search at this level?

Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. — Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
