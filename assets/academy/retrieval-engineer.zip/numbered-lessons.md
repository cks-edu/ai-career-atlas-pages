# RAG / retrieval engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Relevance judgments: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Relevance judgments

Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. In this role, work through: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A library catalog points to a useful shelf, not automatically the right page.

Boundary: Similarity scores are not probabilities that an answer is correct.

Worked example: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for RAG / retrieval engineer: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.

Predict the worked case

Read this case without running a tool: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in relevance judgments.

Connect the concept to the role

Apply this rule: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Similarity scores are not probabilities that an answer is correct.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies relevance judgments to this case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Relevance judgments; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with relevance judgments. Use the glossary below, then write your prediction for: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain relevance judgments using this case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate relevance judgments to a system or workflow you know. Explain relevance judgments using this case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain relevance judgments using this case: For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.

Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. — Retrieval ranks stored passages for a question. Create judgments of which passage actually supports the requested answer before optimizing embeddings or search parameters. Similarity scores are not probabilities that an answer is correct.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Diagnose: Deleted policies still retrieved

The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Two deleted sources remain discoverable beyond the stated freshness limit. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A library catalog points to a useful shelf, not automatically the right page.

For a question about refunds, a passage about payment methods is related but insufficient. Label the refund-window passage relevant and preserve its identifier.

Worked example: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Two deleted sources remain discoverable beyond the stated freshness limit. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Apply this toy-case rule manually: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Retrieval means finding relevant information before writing an answer. Finding a useful passage and producing a correct answer are separate checks.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Write three fictional school rules: “Library closes at 6 pm”; “Books may be borrowed for 14 days”; “Lost cards must be reported to reception.”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

Preparation · Try step 2

Match these questions to a rule: “When does the library close?”, “How long can I keep a book?”, “Is printing free?”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

Preparation · Try step 3

Copy the supporting sentence for each answer; mark the printing question as not covered.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row question, answer and source table.

Preparation · Explain and check your result

Every factual answer has a supporting sentence; missing information is left unknown rather than invented. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A three-row question, answer and source table. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Apply this toy-case rule manually: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two deleted sources remain discoverable beyond the stated freshness limit. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two deleted sources remain discoverable beyond the stated freshness limit. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: deleted policies still retrieved. Use the glossary below, then write your prediction for: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain diagnose: deleted policies still retrieved using this case: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: deleted policies still retrieved to a system or workflow you know. Explain diagnose: deleted policies still retrieved using this case: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Check deleted and active sources using normal user identities; a fresh ingestion job alone is insufficient. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: deleted policies still retrieved using this case: Review when deletion_lag > 15 (minutes). This is a declared toy-case contract, not an industry standard. Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. State the evidence, one alternative and where the mental model stops.

Quiz: Deleted policies still retrieved: The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes.

Change the acceptance rule after seeing an inconvenient result.

Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval.

Omit failed cases and report only the successful demonstrations.

Reference: Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. — Propagate tombstones through document, chunk and cache indexes, then replay permission-aware retrieval. Check deleted and active sources using normal user identities; a fresh ingestion job alone is insufficient.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, indexing, data pipelines and relevance measurement; learn embeddings and ranking fundamentals.

Terms:

Chunking and access filters: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Chunking and access filters

Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. In this role, work through: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Cut a textbook into cards, keeping chapter labels and borrowing restrictions on every card.

Boundary: Larger chunks can dilute relevance and do not replace permission checks.

Worked example: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, indexing, data pipelines and relevance measurement; learn embeddings and ranking fundamentals.

Tools for this exercise: Document or text editor

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for RAG / retrieval engineer: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.

Predict the worked case

Read this case without running a tool: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in chunking and access filters.

Connect the concept to the role

Apply this rule: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Larger chunks can dilute relevance and do not replace permission checks.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies chunking and access filters to this case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Chunking and access filters; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with chunking and access filters. Use the glossary below, then write your prediction for: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain chunking and access filters using this case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate chunking and access filters to a system or workflow you know. Explain chunking and access filters using this case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain chunking and access filters using this case: A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.

Treat a passing starter as proof of the whole role workflow.

Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval.

Ignore the failure because the tool produced an output.

Reference: Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. — Split documents without losing the context needed to interpret a passage. Keep document identity, version and access metadata attached through indexing and retrieval. Larger chunks can dilute relevance and do not replace permission checks.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Integrate: Permission-aware knowledge search

Build a knowledge assistant that respects document ownership, deletion and evidence freshness. Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision. In this role, work through: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Role application: Cut a textbook into cards, keeping chapter labels and borrowing restrictions on every card.

A chunk says within 30 days but omits the preceding exclusion for damaged goods. Expand or link its context before using it as evidence.

Worked example: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.

Setup: Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Build a knowledge assistant that respects document ownership, deletion and evidence freshness. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Build a knowledge assistant that respects document ownership, deletion and evidence freshness.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

Prepare the project inputs

Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The knowledge pilot requires a tombstoned source to disappear from results within 15 minutes. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Deliverable: lesson-intermediate-2.md: Ingestion and search service with deletion tests; Judged query set and retrieval comparison. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: permission-aware knowledge search. Use the glossary below, then write your prediction for: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain integrate: permission-aware knowledge search using this case: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: permission-aware knowledge search to a system or workflow you know. Explain integrate: permission-aware knowledge search using this case: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Identify one observation that would contradict your claim.

Interview: Explain integrate: permission-aware knowledge search using this case: Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Permission-aware knowledge search at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

Reference: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. — Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Grounded answer evaluation: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Grounded answer evaluation

Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. In this role, work through: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: First inspect the evidence delivered to a witness, then inspect the witness's explanation.

Boundary: A correct citation format does not prove the claim is supported.

Worked example: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for RAG / retrieval engineer: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.

Predict the worked case

Read this case without running a tool: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in grounded answer evaluation.

Connect the concept to the role

Apply this rule: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A correct citation format does not prove the claim is supported.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies grounded answer evaluation to this case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Grounded answer evaluation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with grounded answer evaluation. Use the glossary below, then write your prediction for: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain grounded answer evaluation using this case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate grounded answer evaluation to a system or workflow you know. Explain grounded answer evaluation using this case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain grounded answer evaluation using this case: A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined.

Reference: Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. — Evaluate retrieval and answer generation separately. Check whether a relevant source was found, whether the answer follows it and whether unsupported questions are declined. A correct citation format does not prove the claim is supported.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Defend: Permission-aware knowledge search

Build a knowledge assistant that respects document ownership, deletion and evidence freshness. Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing. In this role, work through: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Role application: First inspect the evidence delivered to a witness, then inspect the witness's explanation.

A question with no policy in the corpus should produce an explicit unknown response, not a confidently cited unrelated page.

Worked example: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

Setup: Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQLite FTS5 (Public domain · local); pgvector (Open source · PostgreSQL extension); Ollama (Open source runtime · model licenses vary)

Build a knowledge assistant that respects document ownership, deletion and evidence freshness. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Build a knowledge assistant that respects document ownership, deletion and evidence freshness.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

Prepare the project inputs

Extend documents.json to 30 fictional policy documents across two tenants, three topics and two revisions. Add 20 judged queries, including unanswerable questions and requests for another tenant’s content.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the SQLite FTS5 starter. Add chunk IDs, source version and valid-from timestamps. Keep tenant filtering inside the retrieval query, before any result becomes model context.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a deletion/update pipeline that replaces affected chunks atomically. Add a query cache keyed by tenant, principal permissions and corpus revision.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add a pgvector retrieval variant using the official extension setup and compare it with FTS5 on the same judgments. If adding generation, return source IDs and abstain when evidence is missing.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. A reviewer must reproduce one result and identify which capabilities you implemented. Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Deliverable: lesson-advanced-2.md: Ingestion and search service with deletion tests; Judged query set and retrieval comparison; Permission-flow diagram and freshness dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: permission-aware knowledge search. Use the glossary below, then write your prediction for: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the RAG / retrieval engineer role interview. Explain defend: permission-aware knowledge search using this case: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: permission-aware knowledge search to a system or workflow you know. Explain defend: permission-aware knowledge search using this case: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark. Identify one observation that would contradict your claim.

Interview: Explain defend: permission-aware knowledge search using this case: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Permission-aware knowledge search at this level?

Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. — Revoke access to one source and repeat a previously cached query. Delete a document during reindexing; prove that the old text does not survive in search results or cached answers. Report Recall@5, reciprocal rank, unsupported answer rate, permission leaks and update-to-search lag. A small hand-authored corpus is a mechanism test, not a broad relevance benchmark.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

pgvector: https://github.com/pgvector/pgvector

Ollama: https://docs.ollama.com/api/generate

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
