## advanced — Contamination-aware reporting

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Contamination-aware reporting
Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible.
Mental model: An audit trail records which samples were excluded and why.
Boundary: A cleaned set may change the task distribution and needs its own limitations.
Worked example: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Corpus-to-benchmark overlap audit
Detect exact and near overlap between a training corpus and a benchmark before interpreting results. Produce a quarantine manifest and rerun evaluation on a clean subset. Separate shared topic vocabulary from actual answer-bearing overlap.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Recall: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. Identify one observation that would contradict your claim.

### Terms
Contamination-aware reporting: Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Detect exact and near overlap between a training corpus and a benchmark before interpreting results. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Produce a quarantine manifest and rerun evaluation on a clean subset. Separate shared topic vocabulary from actual answer-bearing overlap.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Detect exact and near overlap between a training corpus and a benchmark before interpreting results.
Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.
Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Produce a quarantine manifest and rerun evaluation on a clean subset. Separate shared topic vocabulary from actual answer-bearing overlap.
Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.
Scale candidate generation with Spark while preserving a reproducible small reference test.
Deliverables: Overlap scanner and labeled pair set; Quarantine/provenance manifest; Contamination impact report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A reviewer must reproduce one result and identify which capabilities you implemented. Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.

### Interview
Explain your advanced solution for Training-data quality & contamination detection. Use this scenario: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Review: Start with the task and permitted scope. Explain contamination-aware reporting: Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible. Show the input and observed output, then address Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Overlap scanner and labeled pair set; Quarantine/provenance manifest; Contamination impact report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

