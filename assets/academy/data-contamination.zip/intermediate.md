## intermediate — Overlap detection methods

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Text processing, similarity search and statistical sampling.

### Overlap detection methods
Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks.
Mental model: A librarian checks identical titles, then similar editions with different covers.
Boundary: Aggressive normalization can erase meaningful differences.
Worked example: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Corpus-to-benchmark overlap audit
Detect exact and near overlap between a training corpus and a benchmark before interpreting results. Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Recall: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. Identify one observation that would contradict your claim.

### Terms
Overlap detection methods: Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Detect exact and near overlap between a training corpus and a benchmark before interpreting results. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The training protocol requires duplicate-family groups to stay within a single split. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Detect exact and near overlap between a training corpus and a benchmark before interpreting results.
Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.
Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.
Deliverables: Overlap scanner and labeled pair set; Quarantine/provenance manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Training-data quality & contamination detection. Use this scenario: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Review: Start with the task and permitted scope. Explain overlap detection methods: Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks. Show the input and observed output, then address Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Overlap scanner and labeled pair set; Quarantine/provenance manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

