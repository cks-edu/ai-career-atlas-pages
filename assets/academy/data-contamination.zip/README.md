# Training-data quality & contamination detection

AI Engineering · Beginner → Intermediate → Advanced

Start with Provenance and split leakage. Evaluation contamination occurs when test material leaks into training or development. Similar-looking text is a signal to investigate, not automatic proof of misuse. Then try Find overlap in two tiny datasets. The three levels build toward Corpus-to-benchmark overlap audit. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Provenance and split leakage

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Provenance and split leakage
Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout.
Mental model: An exam is not unseen if its answers were in the practice booklet.
Boundary: Absence of an exact match does not establish absence of contamination.
Worked example: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Near duplicates cross the split
The training protocol requires duplicate-family groups to stay within a single split. Three partitions contain families spread across training and evaluation. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Group duplicate families before splitting and retain a traceable manifest.
Recall: Check exact and approximate overlap on seeded cases and review suspected false positives. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Provenance and split leakage: Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Evaluation contamination occurs when test material leaks into training or development. Similar-looking text is a signal to investigate, not automatic proof of misuse.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Training contains “Library closes at six” and “Loans last fourteen days”. Testing contains “Library closes at six” and “The library shuts at 6 pm”.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An overlap report with exact, possible and unknown categories.

3. Try step 2
Mark the exact duplicate and the likely paraphrase separately.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An overlap report with exact, possible and unknown categories.

4. Try step 3
Write what additional provenance and split information you would inspect before making a contamination claim.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An overlap report with exact, possible and unknown categories.

5. Explain and check your result
You distinguish identical text from semantic similarity and do not treat either alone as proof of intentional misconduct. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An overlap report with exact, possible and unknown categories. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The training protocol requires duplicate-family groups to stay within a single split. Apply this toy-case rule manually: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three partitions contain families spread across training and evaluation. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Training-data quality & contamination detection.
Training contains “Library closes at six” and “Loans last fourteen days”. Testing contains “Library closes at six” and “The library shuts at 6 pm”.
Mark the exact duplicate and the likely paraphrase separately.
Write what additional provenance and split information you would inspect before making a contamination claim.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An overlap report with exact, possible and unknown categories. Include beginner-worksheet.md and your completed Data contamination audit and split manifest.
Check: You distinguish identical text from semantic similarity and do not treat either alone as proof of intentional misconduct.

### Interview
Explain your beginner solution for Training-data quality & contamination detection. Use this scenario: The training protocol requires duplicate-family groups to stay within a single split.
Review: Start with the task and permitted scope. Explain provenance and split leakage: Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout. Show the input and observed output, then address Group duplicate families before splitting and retain a traceable manifest. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An overlap report with exact, possible and unknown categories. Include beginner-worksheet.md and your completed Data contamination audit and split manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Overlap detection methods

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Text processing, similarity search and statistical sampling.

### Overlap detection methods
Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks.
Mental model: A librarian checks identical titles, then similar editions with different covers.
Boundary: Aggressive normalization can erase meaningful differences.
Worked example: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Corpus-to-benchmark overlap audit
Detect exact and near overlap between a training corpus and a benchmark before interpreting results. Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Recall: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. Identify one observation that would contradict your claim.

### Terms
Overlap detection methods: Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Detect exact and near overlap between a training corpus and a benchmark before interpreting results. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The training protocol requires duplicate-family groups to stay within a single split. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Detect exact and near overlap between a training corpus and a benchmark before interpreting results.
Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.
Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.
Deliverables: Overlap scanner and labeled pair set; Quarantine/provenance manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Training-data quality & contamination detection. Use this scenario: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Review: Start with the task and permitted scope. Explain overlap detection methods: Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks. Show the input and observed output, then address Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Overlap scanner and labeled pair set; Quarantine/provenance manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Contamination-aware reporting

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Contamination-aware reporting
Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible.
Mental model: An audit trail records which samples were excluded and why.
Boundary: A cleaned set may change the task distribution and needs its own limitations.
Worked example: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Corpus-to-benchmark overlap audit
Detect exact and near overlap between a training corpus and a benchmark before interpreting results. Produce a quarantine manifest and rerun evaluation on a clean subset. Separate shared topic vocabulary from actual answer-bearing overlap.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Recall: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. Identify one observation that would contradict your claim.

### Terms
Contamination-aware reporting: Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Detect exact and near overlap between a training corpus and a benchmark before interpreting results. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Produce a quarantine manifest and rerun evaluation on a clean subset. Separate shared topic vocabulary from actual answer-bearing overlap.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Detect exact and near overlap between a training corpus and a benchmark before interpreting results.
Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.
Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.
Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.
Produce a quarantine manifest and rerun evaluation on a clean subset. Separate shared topic vocabulary from actual answer-bearing overlap.
Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.
Scale candidate generation with Spark while preserving a reproducible small reference test.
Deliverables: Overlap scanner and labeled pair set; Quarantine/provenance manifest; Contamination impact report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A reviewer must reproduce one result and identify which capabilities you implemented. Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.

### Interview
Explain your advanced solution for Training-data quality & contamination detection. Use this scenario: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.
Review: Start with the task and permitted scope. Explain contamination-aware reporting: Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible. Show the input and observed output, then address Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Overlap scanner and labeled pair set; Quarantine/provenance manifest; Contamination impact report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
DuckDB — Open source · local
CSV ingestion, SQL transforms and reproducible analysis.
Alternative: SQLite (public domain) for embedded transactional SQL or PostgreSQL (open source) for a shared service.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Apache Spark — Open source · compute costs vary
Scale data transformations after validating local output.
Alternative: DuckDB or Polars (open source) for single-machine workloads; distributed execution is justified by measured needs.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
DuckDB: https://duckdb.org/docs/stable/clients/python/overview
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
Apache Spark: https://spark.apache.org/docs/latest/
Apache Spark: https://spark.apache.org/docs/latest/
pgvector: https://github.com/pgvector/pgvector
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
