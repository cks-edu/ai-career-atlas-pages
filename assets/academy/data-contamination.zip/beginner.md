## beginner — Provenance and split leakage

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Provenance and split leakage
Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout.
Mental model: An exam is not unseen if its answers were in the practice booklet.
Boundary: Absence of an exact match does not establish absence of contamination.
Worked example: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Near duplicates cross the split
The training protocol requires duplicate-family groups to stay within a single split. Three partitions contain families spread across training and evaluation. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Group duplicate families before splitting and retain a traceable manifest.
Recall: Check exact and approximate overlap on seeded cases and review suspected false positives. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Provenance and split leakage: Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Evaluation contamination occurs when test material leaks into training or development. Similar-looking text is a signal to investigate, not automatic proof of misuse.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Training contains “Library closes at six” and “Loans last fourteen days”. Testing contains “Library closes at six” and “The library shuts at 6 pm”.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An overlap report with exact, possible and unknown categories.

3. Try step 2
Mark the exact duplicate and the likely paraphrase separately.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An overlap report with exact, possible and unknown categories.

4. Try step 3
Write what additional provenance and split information you would inspect before making a contamination claim.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An overlap report with exact, possible and unknown categories.

5. Explain and check your result
You distinguish identical text from semantic similarity and do not treat either alone as proof of intentional misconduct. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An overlap report with exact, possible and unknown categories. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The training protocol requires duplicate-family groups to stay within a single split. Apply this toy-case rule manually: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three partitions contain families spread across training and evaluation. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Training-data quality & contamination detection.
Training contains “Library closes at six” and “Loans last fourteen days”. Testing contains “Library closes at six” and “The library shuts at 6 pm”.
Mark the exact duplicate and the likely paraphrase separately.
Write what additional provenance and split information you would inspect before making a contamination claim.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An overlap report with exact, possible and unknown categories. Include beginner-worksheet.md and your completed Data contamination audit and split manifest.
Check: You distinguish identical text from semantic similarity and do not treat either alone as proof of intentional misconduct.

### Interview
Explain your beginner solution for Training-data quality & contamination detection. Use this scenario: The training protocol requires duplicate-family groups to stay within a single split.
Review: Start with the task and permitted scope. Explain provenance and split leakage: Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout. Show the input and observed output, then address Group duplicate families before splitting and retain a traceable manifest. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An overlap report with exact, possible and unknown categories. Include beginner-worksheet.md and your completed Data contamination audit and split manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

