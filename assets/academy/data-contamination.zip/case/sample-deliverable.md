# SAMPLE — Data contamination audit and split manifest
Role: Training-data quality & contamination detection
Case: Near duplicates cross the split
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The training protocol requires duplicate-family groups to stay within a single split.

## Evidence table
| Record | cross_split_families (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 4 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three partitions contain families spread across training and evaluation.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Group duplicate families before splitting and retain a traceable manifest.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in training-data quality & contamination detection.
Before release: Check exact and approximate overlap on seeded cases and review suspected false positives.

## Design choice and trade-off
Combine provenance, grouping and sampled review; record both missed and overflagged pairs.
Aggressive deduplication may remove legitimate diversity; report the precision/recall trade-off.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Contamination scanner: Report detector errors and group-level split integrity.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
