# Training-data quality & contamination detection — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Provenance and split leakage: Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Provenance and split leakage

Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout. In this role, work through: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An exam is not unseen if its answers were in the practice booklet.

Boundary: Absence of an exact match does not establish absence of contamination.

Worked example: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Apache Spark (Open source · compute costs vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Training-data quality & contamination detection: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims.

Predict the worked case

Read this case without running a tool: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in provenance and split leakage.

Connect the concept to the role

Apply this rule: Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Absence of an exact match does not establish absence of contamination.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies provenance and split leakage to this case: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Provenance and split leakage; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with provenance and split leakage. Use the glossary below, then write your prediction for: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Training-data quality & contamination detection role interview. Explain provenance and split leakage using this case: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate provenance and split leakage to a system or workflow you know. Explain provenance and split leakage using this case: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain provenance and split leakage using this case: A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims.

Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout. — Trace where examples originated and how they entered training and evaluation. Repeated or transformed versions of the same item can invalidate a claimed holdout. Absence of an exact match does not establish absence of contamination.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Apache Spark: https://spark.apache.org/docs/latest/

Apache Spark: https://spark.apache.org/docs/latest/

pgvector: https://github.com/pgvector/pgvector

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Diagnose: Near duplicates cross the split

The training protocol requires duplicate-family groups to stay within a single split. Three partitions contain families spread across training and evaluation. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Group duplicate families before splitting and retain a traceable manifest. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: An exam is not unseen if its answers were in the practice booklet.

A public benchmark question appears in a scraped training dump; record the overlap and isolate affected evaluation claims.

Worked example: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Group duplicate families before splitting and retain a traceable manifest.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Apache Spark (Open source · compute costs vary)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The training protocol requires duplicate-family groups to stay within a single split. Three partitions contain families spread across training and evaluation. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The training protocol requires duplicate-family groups to stay within a single split. Apply this toy-case rule manually: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Evaluation contamination occurs when test material leaks into training or development. Similar-looking text is a signal to investigate, not automatic proof of misuse.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Training contains “Library closes at six” and “Loans last fourteen days”. Testing contains “Library closes at six” and “The library shuts at 6 pm”.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An overlap report with exact, possible and unknown categories.

Preparation · Try step 2

Mark the exact duplicate and the likely paraphrase separately.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An overlap report with exact, possible and unknown categories.

Preparation · Try step 3

Write what additional provenance and split information you would inspect before making a contamination claim.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An overlap report with exact, possible and unknown categories.

Preparation · Explain and check your result

You distinguish identical text from semantic similarity and do not treat either alone as proof of intentional misconduct. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: An overlap report with exact, possible and unknown categories. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The training protocol requires duplicate-family groups to stay within a single split. Apply this toy-case rule manually: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three partitions contain families spread across training and evaluation. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three partitions contain families spread across training and evaluation. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: near duplicates cross the split. Use the glossary below, then write your prediction for: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Group duplicate families before splitting and retain a traceable manifest. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Training-data quality & contamination detection role interview. Explain diagnose: near duplicates cross the split using this case: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Group duplicate families before splitting and retain a traceable manifest. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: near duplicates cross the split to a system or workflow you know. Explain diagnose: near duplicates cross the split using this case: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Group duplicate families before splitting and retain a traceable manifest. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Check exact and approximate overlap on seeded cases and review suspected false positives. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: near duplicates cross the split using this case: Review when cross_split_families >= 1 (count). This is a declared toy-case contract, not an industry standard. Group duplicate families before splitting and retain a traceable manifest. State the evidence, one alternative and where the mental model stops.

Quiz: Near duplicates cross the split: The training protocol requires duplicate-family groups to stay within a single split.

Change the acceptance rule after seeing an inconvenient result.

Group duplicate families before splitting and retain a traceable manifest.

Omit failed cases and report only the successful demonstrations.

Reference: Group duplicate families before splitting and retain a traceable manifest. — Group duplicate families before splitting and retain a traceable manifest. Check exact and approximate overlap on seeded cases and review suspected false positives.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Apache Spark: https://spark.apache.org/docs/latest/

Apache Spark: https://spark.apache.org/docs/latest/

pgvector: https://github.com/pgvector/pgvector

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Text processing, similarity search and statistical sampling.

Terms:

Overlap detection methods: Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Overlap detection methods

Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks. In this role, work through: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A librarian checks identical titles, then similar editions with different covers.

Boundary: Aggressive normalization can erase meaningful differences.

Worked example: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Text processing, similarity search and statistical sampling.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Apache Spark (Open source · compute costs vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Training-data quality & contamination detection: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example.

Predict the worked case

Read this case without running a tool: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in overlap detection methods.

Connect the concept to the role

Apply this rule: Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Aggressive normalization can erase meaningful differences.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies overlap detection methods to this case: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Overlap detection methods; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with overlap detection methods. Use the glossary below, then write your prediction for: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Training-data quality & contamination detection role interview. Explain overlap detection methods using this case: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate overlap detection methods to a system or workflow you know. Explain overlap detection methods using this case: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain overlap detection methods using this case: Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example.

Treat a passing starter as proof of the whole role workflow.

Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks.

Ignore the failure because the tool produced an output.

Reference: Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks. — Use exact matching first, then normalized or similarity-based matching where appropriate. Inspect flagged pairs and state false-positive and false-negative risks. Aggressive normalization can erase meaningful differences.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Apache Spark: https://spark.apache.org/docs/latest/

Apache Spark: https://spark.apache.org/docs/latest/

pgvector: https://github.com/pgvector/pgvector

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Integrate: Corpus-to-benchmark overlap audit

Detect exact and near overlap between a training corpus and a benchmark before interpreting results. Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs. In this role, work through: Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A librarian checks identical titles, then similar editions with different covers.

Normalize whitespace to catch duplicates, but inspect similar passages before deleting them as the same example.

Worked example: Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Apache Spark (Open source · compute costs vary)

Detect exact and near overlap between a training corpus and a benchmark before interpreting results. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Detect exact and near overlap between a training corpus and a benchmark before interpreting results.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The training protocol requires duplicate-family groups to stay within a single split. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-intermediate-2.md: Overlap scanner and labeled pair set; Quarantine/provenance manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: corpus-to-benchmark overlap audit. Use the glossary below, then write your prediction for: Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Training-data quality & contamination detection role interview. Explain integrate: corpus-to-benchmark overlap audit using this case: Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: corpus-to-benchmark overlap audit to a system or workflow you know. Explain integrate: corpus-to-benchmark overlap audit using this case: Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. Identify one observation that would contradict your claim.

Interview: Explain integrate: corpus-to-benchmark overlap audit using this case: Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Corpus-to-benchmark overlap audit at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.

Reference: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. — Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Apache Spark: https://spark.apache.org/docs/latest/

Apache Spark: https://spark.apache.org/docs/latest/

pgvector: https://github.com/pgvector/pgvector

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Contamination-aware reporting: Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Contamination-aware reporting

Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible. In this role, work through: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An audit trail records which samples were excluded and why.

Boundary: A cleaned set may change the task distribution and needs its own limitations.

Worked example: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Apache Spark (Open source · compute costs vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Training-data quality & contamination detection: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches.

Predict the worked case

Read this case without running a tool: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in contamination-aware reporting.

Connect the concept to the role

Apply this rule: Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A cleaned set may change the task distribution and needs its own limitations.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies contamination-aware reporting to this case: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Contamination-aware reporting; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with contamination-aware reporting. Use the glossary below, then write your prediction for: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Training-data quality & contamination detection role interview. Explain contamination-aware reporting using this case: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate contamination-aware reporting to a system or workflow you know. Explain contamination-aware reporting using this case: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain contamination-aware reporting using this case: Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible.

Reference: Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible. — Version the detection pipeline and report affected counts, review decisions and sensitivity to thresholds. Re-evaluate after removing contaminated groups where possible. A cleaned set may change the task distribution and needs its own limitations.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Apache Spark: https://spark.apache.org/docs/latest/

Apache Spark: https://spark.apache.org/docs/latest/

pgvector: https://github.com/pgvector/pgvector

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Defend: Corpus-to-benchmark overlap audit

Detect exact and near overlap between a training corpus and a benchmark before interpreting results. Produce a quarantine manifest and rerun evaluation on a clean subset. Separate shared topic vocabulary from actual answer-bearing overlap. In this role, work through: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: An audit trail records which samples were excluded and why.

Publish original and cleaned evaluation results with the number of removed source groups and unresolved near-matches.

Worked example: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Apache Spark (Open source · compute costs vary)

Detect exact and near overlap between a training corpus and a benchmark before interpreting results. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Detect exact and near overlap between a training corpus and a benchmark before interpreting results.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create 100 synthetic documents and 20 benchmark questions with planted exact, paraphrased and unrelated overlaps. Keep the planted answer key separate during threshold tuning.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Normalize text conservatively, preserve raw text and compute exact hashes in DuckDB. Record normalization version and candidate pair IDs.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Add character n-gram TF-IDF similarity or MinHash for candidate discovery. Tune thresholds on a validation subset and manually adjudicate ambiguous pairs.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Produce a quarantine manifest and rerun evaluation on a clean subset. Separate shared topic vocabulary from actual answer-bearing overlap.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. A reviewer must reproduce one result and identify which capabilities you implemented. Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-advanced-2.md: Overlap scanner and labeled pair set; Quarantine/provenance manifest; Contamination impact report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: corpus-to-benchmark overlap audit. Use the glossary below, then write your prediction for: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Training-data quality & contamination detection role interview. Explain defend: corpus-to-benchmark overlap audit using this case: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: corpus-to-benchmark overlap audit to a system or workflow you know. Explain defend: corpus-to-benchmark overlap audit using this case: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination. Identify one observation that would contradict your claim.

Interview: Explain defend: corpus-to-benchmark overlap audit using this case: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Corpus-to-benchmark overlap audit at this level?

Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives. — Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives. Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Apache Spark: https://spark.apache.org/docs/latest/

Apache Spark: https://spark.apache.org/docs/latest/

pgvector: https://github.com/pgvector/pgvector

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
