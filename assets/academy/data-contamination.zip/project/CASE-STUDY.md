# Corpus-to-benchmark overlap audit

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Detect exact and near overlap between a training corpus and a benchmark before interpreting results.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.

## Limitations and next iteration
Scale candidate generation with Spark while preserving a reproducible small reference test.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
