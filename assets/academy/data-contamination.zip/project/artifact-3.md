# Contamination impact report

Project: Corpus-to-benchmark overlap audit
Status: blank work product — not completed evidence

## Purpose and audience
Detect exact and near overlap between a training corpus and a benchmark before interpreting results.

## Required content
Produce a quarantine manifest and rerun evaluation on a clean subset. Separate shared topic vocabulary from actual answer-bearing overlap.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report pair precision/recall on planted cases, adjudication counts and performance before/after quarantine. The method cannot prove absence of all contamination.

## Failure evidence
Change punctuation and reorder a copied answer, then add unrelated documents on the same topic. Inspect both false negatives and false positives.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
