# Security Operations Analyst — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Events, alerts and incidents

An event is an observation, an alert is a rule match and an incident is an investigated situation requiring response. Keep confidence and evidence separate from assumptions about intent.
Mental model: A smoke detector sound is a signal to investigate, not proof of arson.
Case: Three denied logins can be user error or suspicious activity depending on context.
Task: Create a synthetic log with timestamps, user IDs and outcomes. Group denied actions and write two plausible explanations plus the next evidence required.
Acceptance: A triage note that does not label every denial malicious.
Troubleshooting: Missing timestamps or time zones can make unrelated events look connected; normalize them.
Deliverable: event timeline and triage record

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Detection context and false positives

A detection needs a population, time window and threshold. Test both expected attacks and ordinary activity that could trigger it.
Mental model: A guard needs a rule that catches intruders without stopping every delivery worker.
Case: Five failures followed by success for one user in ten minutes may deserve review.
Task: Build a small log query or Python grouping script for that sequence. Add a benign mistyped-password fixture and a distributed attempt across users; record misses and false positives.
Acceptance: The report states which scenarios the rule detects and which it misses.
Troubleshooting: Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly.
Deliverable: detection rule and labeled test dataset

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Evidence-preserving escalation

Containment should be proportionate and authorized. Preserve relevant logs, document confidence and hand off with a clear action request and recovery criteria.
Mental model: Secure the scene while keeping the evidence needed to understand what happened.
Case: A suspicious login from a new context requires identity verification before destructive account actions.
Task: Write an incident package with timeline, affected assets, alternative explanations, proposed containment and a communications owner. Rehearse the decision using only the synthetic dataset.
Acceptance: An auditable escalation with clear uncertainty and authorization boundaries.
Troubleshooting: A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence.
Deliverable: SOC case file and response decision record

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
