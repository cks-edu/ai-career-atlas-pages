# Security Operations Analyst — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Authentication and authorization: Authentication establishes identity; authorization decides which action that identity may perform.

Apply authentication and authorization in Security Operations Analyst: Use the concept to complete this role exercise: Separate an event, an alert and a confirmed incident

Events, alerts and incidents: An event is an observation, an alert is a rule match and an incident is an investigated situation requiring response. Keep confidence and evidence separate from assumptions about intent.

### Authentication and authorization

Authentication establishes identity; authorization decides which action that identity may perform. In this role, work through: Three denied logins can be user error or suspicious activity depending on context. The practical workshop develops this into: Create a synthetic log with timestamps, user IDs and outcomes. Group denied actions and write two plausible explanations plus the next evidence required.

Mental model: An ID card tells who you are; the door policy says where you may enter.

Boundary: A valid login does not authorize access to every record.

Role application: A smoke detector sound is a signal to investigate, not proof of arson.

An event is an observation, an alert is a rule match and an incident is an investigated situation requiring response. Keep confidence and evidence separate from assumptions about intent.

Worked example: Three denied logins can be user error or suspicious activity depending on context.

Shared foundation example: Alice may read but not write; an unknown user is denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Structured logs and Python (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Security Operations Analyst: Three denied logins can be user error or suspicious activity depending on context.

Predict the worked case

Read this case without running a tool: Three denied logins can be user error or suspicious activity depending on context. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in authentication and authorization.

Connect the concept to the role

Apply this rule: Authentication establishes identity; authorization decides which action that identity may perform. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A valid login does not authorize access to every record.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies authentication and authorization to this case: Three denied logins can be user error or suspicious activity depending on context. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Three denied logins can be user error or suspicious activity depending on context. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Authentication and authorization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with authentication and authorization. Use the glossary below, then write your prediction for: Three denied logins can be user error or suspicious activity depending on context. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Operations Analyst role interview. Explain authentication and authorization using this case: Three denied logins can be user error or suspicious activity depending on context. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate authentication and authorization to a system or workflow you know. Explain authentication and authorization using this case: Three denied logins can be user error or suspicious activity depending on context. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Where should an object ownership check happen?

Interview: Explain authentication and authorization using this case: Three denied logins can be user error or suspicious activity depending on context. State the evidence, one alternative and where the mental model stops.

Quiz: After the Events, alerts and incidents rehearsal, check this foundation: A logged-in user requests another user’s private record. What must the service still check?

Whether this identity is permitted to perform this action on that record.

Only whether the session token has the correct syntax.

Only whether the record identifier exists.

Reference: Whether this identity is permitted to perform this action on that record. — Authentication establishes identity; authorization checks the action and resource.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Events, alerts and incidents

An event is an observation, an alert is a rule match and an incident is an investigated situation requiring response. Keep confidence and evidence separate from assumptions about intent. In this role, work through: Three denied logins can be user error or suspicious activity depending on context. The practical workshop develops this into: Create a synthetic log with timestamps, user IDs and outcomes. Group denied actions and write two plausible explanations plus the next evidence required.

Mental model: A smoke detector sound is a signal to investigate, not proof of arson.

Boundary: Missing timestamps or time zones can make unrelated events look connected; normalize them.

Worked example: Three denied logins can be user error or suspicious activity depending on context.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Structured logs and Python (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Security Operations Analyst workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a synthetic log with timestamps, user IDs and outcomes. Group denied actions and write two plausible explanations plus the next evidence required.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Three denied logins can be user error or suspicious activity depending on context. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a synthetic log with timestamps, user IDs and outcomes. Group denied actions and write two plausible explanations plus the next evidence required.

Expected: A triage note that does not label every denial malicious.

Role workshop · debug and verify

Missing timestamps or time zones can make unrelated events look connected; normalize them. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save event timeline and triage record. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A triage note that does not label every denial malicious.

Expected: A triage note that does not label every denial malicious.

Troubleshoot: The role exercise differs from the prediction: Missing timestamps or time zones can make unrelated events look connected; normalize them.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: event timeline and triage record; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with events, alerts and incidents. Use the glossary below, then write your prediction for: Three denied logins can be user error or suspicious activity depending on context. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Operations Analyst role interview. Explain events, alerts and incidents using this case: Three denied logins can be user error or suspicious activity depending on context. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate events, alerts and incidents to a system or workflow you know. Explain events, alerts and incidents using this case: Three denied logins can be user error or suspicious activity depending on context. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Missing timestamps or time zones can make unrelated events look connected; normalize them.

Interview: Explain events, alerts and incidents using this case: Three denied logins can be user error or suspicious activity depending on context. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Three denied logins can be user error or suspicious activity depending on context.

A triage note that does not label every denial malicious.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A triage note that does not label every denial malicious. — An event is an observation, an alert is a rule match and an incident is an investigated situation requiring response. Keep confidence and evidence separate from assumptions about intent. A triage note that does not label every denial malicious.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Code and data separation: Parameterized SQL keeps input values separate from SQL instructions.

Apply code and data separation in Security Operations Analyst: Use the concept to complete this role exercise: Analyze synthetic denied actions without assuming malicious intent

Detection context and false positives: A detection needs a population, time window and threshold. Test both expected attacks and ordinary activity that could trigger it.

### Code and data separation

Parameterized SQL keeps input values separate from SQL instructions. In this role, work through: Five failures followed by success for one user in ten minutes may deserve review. The practical workshop develops this into: Build a small log query or Python grouping script for that sequence. Add a benign mistyped-password fixture and a distributed attempt across users; record misses and false positives.

Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.

Boundary: Parameters protect values; dynamic table names still require explicit allowlists.

Role application: A guard needs a rule that catches intruders without stopping every delivery worker.

A detection needs a population, time window and threshold. Test both expected attacks and ordinary activity that could trigger it.

Worked example: Five failures followed by success for one user in ten minutes may deserve review.

Shared foundation example: The malicious-looking owner string is treated as a value and returns zero rows.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Structured logs and Python (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Security Operations Analyst: Five failures followed by success for one user in ten minutes may deserve review.

Predict the worked case

Read this case without running a tool: Five failures followed by success for one user in ten minutes may deserve review. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in code and data separation.

Connect the concept to the role

Apply this rule: Parameterized SQL keeps input values separate from SQL instructions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Parameters protect values; dynamic table names still require explicit allowlists.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies code and data separation to this case: Five failures followed by success for one user in ten minutes may deserve review. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Five failures followed by success for one user in ten minutes may deserve review. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Code and data separation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with code and data separation. Use the glossary below, then write your prediction for: Five failures followed by success for one user in ten minutes may deserve review. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Operations Analyst role interview. Explain code and data separation using this case: Five failures followed by success for one user in ten minutes may deserve review. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate code and data separation to a system or workflow you know. Explain code and data separation using this case: Five failures followed by success for one user in ten minutes may deserve review. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is escaping one example string weaker than using parameters?

Interview: Explain code and data separation using this case: Five failures followed by success for one user in ten minutes may deserve review. State the evidence, one alternative and where the mental model stops.

Quiz: After the Detection context and false positives rehearsal, check this foundation: A query binds a user value through a parameter. Can that same placeholder choose an arbitrary table name?

Yes, placeholders bind all SQL syntax.

No; structural identifiers need an allowlisted query design.

Yes, if the identifier arrives over HTTPS.

Reference: No; structural identifiers need an allowlisted query design. — Parameters bind values, not arbitrary SQL structure. Transport security does not change SQL semantics.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Detection context and false positives

A detection needs a population, time window and threshold. Test both expected attacks and ordinary activity that could trigger it. In this role, work through: Five failures followed by success for one user in ten minutes may deserve review. The practical workshop develops this into: Build a small log query or Python grouping script for that sequence. Add a benign mistyped-password fixture and a distributed attempt across users; record misses and false positives.

Mental model: A guard needs a rule that catches intruders without stopping every delivery worker.

Boundary: Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly.

Worked example: Five failures followed by success for one user in ten minutes may deserve review.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Structured logs and Python (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Security Operations Analyst workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Build a small log query or Python grouping script for that sequence. Add a benign mistyped-password fixture and a distributed attempt across users; record misses and false positives.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Five failures followed by success for one user in ten minutes may deserve review. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Build a small log query or Python grouping script for that sequence. Add a benign mistyped-password fixture and a distributed attempt across users; record misses and false positives.

Expected: The report states which scenarios the rule detects and which it misses.

Role workshop · debug and verify

Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save detection rule and labeled test dataset. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The report states which scenarios the rule detects and which it misses.

Expected: The report states which scenarios the rule detects and which it misses.

Troubleshoot: The role exercise differs from the prediction: Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: detection rule and labeled test dataset; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with detection context and false positives. Use the glossary below, then write your prediction for: Five failures followed by success for one user in ten minutes may deserve review. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Operations Analyst role interview. Explain detection context and false positives using this case: Five failures followed by success for one user in ten minutes may deserve review. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate detection context and false positives to a system or workflow you know. Explain detection context and false positives using this case: Five failures followed by success for one user in ten minutes may deserve review. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly.

Interview: Explain detection context and false positives using this case: Five failures followed by success for one user in ten minutes may deserve review. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Five failures followed by success for one user in ten minutes may deserve review.

Ignore the failing case and keep only the successful screenshot.

The report states which scenarios the rule detects and which it misses.

Treat any successful command as proof that all business and access rules passed.

Reference: The report states which scenarios the rule detects and which it misses. — A detection needs a population, time window and threshold. Test both expected attacks and ordinary activity that could trigger it. The report states which scenarios the rule detects and which it misses.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Threat models and regression: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.

Apply threat models and regression in Security Operations Analyst: Use the concept to complete this role exercise: Write an escalation decision with evidence preservation and false-positive limits

Evidence-preserving escalation: Containment should be proportionate and authorized. Preserve relevant logs, document confidence and hand off with a clear action request and recovery criteria.

### Threat models and regression

State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. In this role, work through: A suspicious login from a new context requires identity verification before destructive account actions. The practical workshop develops this into: Write an incident package with timeline, affected assets, alternative explanations, proposed containment and a communications owner. Rehearse the decision using only the synthetic dataset.

Mental model: Mark doors and valuable rooms on a building map before choosing locks.

Boundary: A threat model is a living hypothesis, not proof that the system is secure.

Role application: Secure the scene while keeping the evidence needed to understand what happened.

Containment should be proportionate and authorized. Preserve relevant logs, document confidence and hand off with a clear action request and recovery criteria.

Worked example: A suspicious login from a new context requires identity verification before destructive account actions.

Shared foundation example: Reader-write, unknown-read and unsupported-delete must all be denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Structured logs and Python (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Security Operations Analyst: A suspicious login from a new context requires identity verification before destructive account actions.

Predict the worked case

Read this case without running a tool: A suspicious login from a new context requires identity verification before destructive account actions. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in threat models and regression.

Connect the concept to the role

Apply this rule: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A threat model is a living hypothesis, not proof that the system is secure.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies threat models and regression to this case: A suspicious login from a new context requires identity verification before destructive account actions. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A suspicious login from a new context requires identity verification before destructive account actions. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Threat models and regression; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with threat models and regression. Use the glossary below, then write your prediction for: A suspicious login from a new context requires identity verification before destructive account actions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Operations Analyst role interview. Explain threat models and regression using this case: A suspicious login from a new context requires identity verification before destructive account actions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate threat models and regression to a system or workflow you know. Explain threat models and regression using this case: A suspicious login from a new context requires identity verification before destructive account actions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would a new export endpoint change the threat model?

Interview: Explain threat models and regression using this case: A suspicious login from a new context requires identity verification before destructive account actions. State the evidence, one alternative and where the mental model stops.

Quiz: After the Evidence-preserving escalation rehearsal, check this foundation: A denied action is fixed after a security defect. What helps detect its recurrence?

Document only the successful authorized path.

Remove the denied case because it now passes.

Add a repeatable negative test tied to the actor, action and trust boundary.

Reference: Add a repeatable negative test tied to the actor, action and trust boundary. — Regression checks preserve evidence for important misuse cases; the threat model explains why the control matters.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Evidence-preserving escalation

Containment should be proportionate and authorized. Preserve relevant logs, document confidence and hand off with a clear action request and recovery criteria. In this role, work through: A suspicious login from a new context requires identity verification before destructive account actions. The practical workshop develops this into: Write an incident package with timeline, affected assets, alternative explanations, proposed containment and a communications owner. Rehearse the decision using only the synthetic dataset.

Mental model: Secure the scene while keeping the evidence needed to understand what happened.

Boundary: A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence.

Worked example: A suspicious login from a new context requires identity verification before destructive account actions.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Structured logs and Python (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Security Operations Analyst workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write an incident package with timeline, affected assets, alternative explanations, proposed containment and a communications owner. Rehearse the decision using only the synthetic dataset.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A suspicious login from a new context requires identity verification before destructive account actions. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write an incident package with timeline, affected assets, alternative explanations, proposed containment and a communications owner. Rehearse the decision using only the synthetic dataset.

Expected: An auditable escalation with clear uncertainty and authorization boundaries.

Role workshop · debug and verify

A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save SOC case file and response decision record. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: An auditable escalation with clear uncertainty and authorization boundaries.

Expected: An auditable escalation with clear uncertainty and authorization boundaries.

Troubleshoot: The role exercise differs from the prediction: A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: SOC case file and response decision record; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with evidence-preserving escalation. Use the glossary below, then write your prediction for: A suspicious login from a new context requires identity verification before destructive account actions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Operations Analyst role interview. Explain evidence-preserving escalation using this case: A suspicious login from a new context requires identity verification before destructive account actions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate evidence-preserving escalation to a system or workflow you know. Explain evidence-preserving escalation using this case: A suspicious login from a new context requires identity verification before destructive account actions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence.

Interview: Explain evidence-preserving escalation using this case: A suspicious login from a new context requires identity verification before destructive account actions. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A suspicious login from a new context requires identity verification before destructive account actions.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

An auditable escalation with clear uncertainty and authorization boundaries.

Reference: An auditable escalation with clear uncertainty and authorization boundaries. — Containment should be proportionate and authorized. Preserve relevant logs, document confidence and hand off with a clear action request and recovery criteria. An auditable escalation with clear uncertainty and authorization boundaries.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
