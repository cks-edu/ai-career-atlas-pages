# Security Operations Analyst

Software Engineering

Start with events, alerts and incidents. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward SOC case file and response decision record.

## beginner

Create a synthetic log with timestamps, user IDs and outcomes. Group denied actions and write two plausible explanations plus the next evidence required.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Authentication and authorization
Authentication establishes identity; authorization decides which action that identity may perform.
Mental model: An ID card tells who you are; the door policy says where you may enter.
Limit: A valid login does not authorize access to every record.
Example: Alice may read but not write; an unknown user is denied.
Recall: Where should an object ownership check happen?

### Events, alerts and incidents
An event is an observation, an alert is a rule match and an incident is an investigated situation requiring response. Keep confidence and evidence separate from assumptions about intent.
Mental model: A smoke detector sound is a signal to investigate, not proof of arson.
Limit: Missing timestamps or time zones can make unrelated events look connected; normalize them.
Example: Three denied logins can be user error or suspicious activity depending on context.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Missing timestamps or time zones can make unrelated events look connected; normalize them.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Three denied logins can be user error or suspicious activity depending on context. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a synthetic log with timestamps, user IDs and outcomes. Group denied actions and write two plausible explanations plus the next evidence required.
Expected: A triage note that does not label every denial malicious.

6. Role workshop · debug and verify
Missing timestamps or time zones can make unrelated events look connected; normalize them. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save event timeline and triage record. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A triage note that does not label every denial malicious.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Events, alerts and incidents: Missing timestamps or time zones can make unrelated events look connected; normalize them.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: event timeline and triage record
A triage note that does not label every denial malicious.

Interview: Work through this Security Operations Analyst case: Three denied logins can be user error or suspicious activity depending on context. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An event is an observation, an alert is a rule match and an incident is an investigated situation requiring response. Keep confidence and evidence separate from assumptions about intent. Expected evidence: A triage note that does not label every denial malicious. Diagnosis: Missing timestamps or time zones can make unrelated events look connected; normalize them. State the limits of the mental model: A smoke detector sound is a signal to investigate, not proof of arson.

Resume: Built event timeline and triage record using Structured logs and Python; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Build a small log query or Python grouping script for that sequence. Add a benign mistyped-password fixture and a distributed attempt across users; record misses and false positives.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Code and data separation
Parameterized SQL keeps input values separate from SQL instructions.
Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.
Limit: Parameters protect values; dynamic table names still require explicit allowlists.
Example: The malicious-looking owner string is treated as a value and returns zero rows.
Recall: Why is escaping one example string weaker than using parameters?

### Detection context and false positives
A detection needs a population, time window and threshold. Test both expected attacks and ordinary activity that could trigger it.
Mental model: A guard needs a rule that catches intruders without stopping every delivery worker.
Limit: Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly.
Example: Five failures followed by success for one user in ten minutes may deserve review.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Five failures followed by success for one user in ten minutes may deserve review. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Build a small log query or Python grouping script for that sequence. Add a benign mistyped-password fixture and a distributed attempt across users; record misses and false positives.
Expected: The report states which scenarios the rule detects and which it misses.

6. Role workshop · debug and verify
Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save detection rule and labeled test dataset. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The report states which scenarios the rule detects and which it misses.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Detection context and false positives: Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: detection rule and labeled test dataset
The report states which scenarios the rule detects and which it misses.

Interview: Work through this Security Operations Analyst case: Five failures followed by success for one user in ten minutes may deserve review. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A detection needs a population, time window and threshold. Test both expected attacks and ordinary activity that could trigger it. Expected evidence: The report states which scenarios the rule detects and which it misses. Diagnosis: Raising a threshold until alerts vanish may hide attacks; assess the trade-off explicitly. State the limits of the mental model: A guard needs a rule that catches intruders without stopping every delivery worker.

Resume: Built detection rule and labeled test dataset using Structured logs and Python; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write an incident package with timeline, affected assets, alternative explanations, proposed containment and a communications owner. Rehearse the decision using only the synthetic dataset.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Threat models and regression
State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.
Mental model: Mark doors and valuable rooms on a building map before choosing locks.
Limit: A threat model is a living hypothesis, not proof that the system is secure.
Example: Reader-write, unknown-read and unsupported-delete must all be denied.
Recall: How would a new export endpoint change the threat model?

### Evidence-preserving escalation
Containment should be proportionate and authorized. Preserve relevant logs, document confidence and hand off with a clear action request and recovery criteria.
Mental model: Secure the scene while keeping the evidence needed to understand what happened.
Limit: A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence.
Example: A suspicious login from a new context requires identity verification before destructive account actions.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A suspicious login from a new context requires identity verification before destructive account actions. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write an incident package with timeline, affected assets, alternative explanations, proposed containment and a communications owner. Rehearse the decision using only the synthetic dataset.
Expected: An auditable escalation with clear uncertainty and authorization boundaries.

6. Role workshop · debug and verify
A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save SOC case file and response decision record. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: An auditable escalation with clear uncertainty and authorization boundaries.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Evidence-preserving escalation: A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: SOC case file and response decision record
An auditable escalation with clear uncertainty and authorization boundaries.

Interview: Work through this Security Operations Analyst case: A suspicious login from a new context requires identity verification before destructive account actions. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Containment should be proportionate and authorized. Preserve relevant logs, document confidence and hand off with a clear action request and recovery criteria. Expected evidence: An auditable escalation with clear uncertainty and authorization boundaries. Diagnosis: A user attribution from an IP alone is insufficient; seek corroborating identity and device evidence. State the limits of the mental model: Secure the scene while keeping the evidence needed to understand what happened.

Resume: Built SOC case file and response decision record using Structured logs and Python; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
