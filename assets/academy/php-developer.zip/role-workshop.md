# PHP Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Request data and output encoding

PHP receives untrusted request values. Validation decides what is acceptable; HTML encoding decides how accepted text is safely displayed. Neither substitutes for authorization.
Mental model: Check the parcel before storing it, then put its label behind glass when displaying it.
Case: A title containing <b>A</b> must display literally if markup is not part of the contract.
Task: Create a local PHP form, handle POST, trim and validate the title and render with htmlspecialchars using UTF-8. Start php -S 127.0.0.1:8137 in that folder and test blank and markup inputs.
Acceptance: Blank input shows an error; markup renders as text; development server is loopback-only.
Troubleshooting: If HTML executes, inspect every output context; HTML encoding is not a universal JavaScript or URL encoder.
Deliverable: form.php and request/output evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Prepared statements and transactions

Bind SQL values through PDO prepared statements and keep multi-step changes inside an explicit transaction. String concatenation lets input become query syntax.
Mental model: A prepared form reserves spaces for values without letting the value rewrite the instructions.
Case: The title x' OR '1'='1 is stored or rejected as data, never used as SQL logic.
Task: Use PDO SQLite in a disposable local database. Create a tasks table, prepare an INSERT, bind the title and select the result. Add a failed multi-step transaction and confirm rollback.
Acceptance: One intended row and no unintended selection; failed transaction leaves prior data unchanged.
Troubleshooting: If the driver is missing, check php -m for pdo_sqlite; do not remove parameter binding to bypass setup.
Deliverable: PDO implementation and injection/rollback tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Sessions and CSRF

A session identifies an interaction; a state-changing browser form also needs protection against forged cross-site submissions. Tokens and cookie attributes address different threats.
Mental model: An ID badge does not prove that every instruction presented with it was intentionally sent by its owner.
Case: A POST without the session-bound CSRF token is denied even if the session cookie exists.
Task: Add a random session token, compare it safely on POST and test missing/wrong/correct values. Document Secure-cookie behavior under HTTPS and why the local development server is not a production deployment.
Acceptance: Only the matching-token request mutates state; session data is absent from public logs.
Troubleshooting: A token regenerated on every request can invalidate open forms; define lifecycle and retry behavior.
Deliverable: session-threat model, tests and deployment checklist

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
