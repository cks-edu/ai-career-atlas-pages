# PHP Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Request and response: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.

Apply request and response in PHP Developer: Use the concept to complete this role exercise: Follow the PHP form tutorial and explain server-side validation

Request data and output encoding: PHP receives untrusted request values. Validation decides what is acceptable; HTML encoding decides how accepted text is safely displayed. Neither substitutes for authorization.

### Values, functions and deliberate errors

Use integer cents for this exercise to avoid floating-point money surprises. declare(strict_types=1) makes scalar type behavior explicit for calls in the file. Guard the allowed range as well as the PHP type. Small functions are easier to test than a large request handler.

Mental model: A function is a small workshop: inputs enter, a result leaves, and its contract says what it accepts.

Boundary: A type declaration does not establish business validity: a negative integer is still an integer.

Worked example: A total function can accept integer cents; reject a negative quantity before multiplication.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: PHP CLI

Course tool and framework map: 



Read total() in the fixture. Predict the valid total and the negative-quantity failure before running it. Add a zero-quantity assertion and rerun.

Commands (after setup)

```
php -v
php -l native-php/check.php
php native-php/check.php values
```

Expected: Syntax check succeeds; values prints PASS values. The fixture verifies 3 × 125 = 375 and rejects negative quantity.

Troubleshoot: TypeError or failed assertion: Inspect the supplied type and business range separately. Do not remove the guard just to make the test pass; show both valid and invalid cases.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/beginner/values-functions-and-deliberate-errors.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Walk through the invalid input and name where the program rejects it.

new: Start by describing values, functions and deliberate errors in your own words. Read total() in the fixture. Predict the valid total and the negative-quantity failure before running it. Add a zero-quantity assertion and rerun. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for values, functions and deliberate errors. Walk through the invalid input and name where the program rejects it. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect values, functions and deliberate errors to one system you already know. Walk through the invalid input and name where the program rejects it. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why can an integer pass a type check but still be invalid?

Interview: Walk through the invalid input and name where the program rejects it.

Quiz: Quantity -1 is an integer. What else is needed?

A business range check.

A longer variable name.

HTML encoding.

Reference: A business range check. — Types describe shape; validation enforces domain rules such as nonnegative quantities.

Sources:

PHP: type declarations: https://www.php.net/manual/en/language.types.declarations.php

### Request and response

Treat method, path, headers and body as separate parts of a request. The server chooses a status and response type. Trace one request in a terminal before adding a framework. A browser address bar normally sends GET; it cannot stand in for every API test.

Mental model: A service counter: the request is your order and the response is the result.

Boundary: Networks can time out; sending an order does not prove it was fulfilled.

Worked example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: PHP CLI + curl

Course tool and framework map: 



Start the bundled local server, then compare a valid endpoint with an unknown route in a second terminal.

Commands (after setup)

```
php -S 127.0.0.1:8138 -t native-php
# Second terminal, from the extracted pack:
curl -i http://127.0.0.1:8138/index.php
curl -i http://127.0.0.1:8138/missing
```

Expected: First request: HTTP 200 with JSON {"status":"ok"}. Second: HTTP 404 with JSON error. Stop the server with Ctrl+C; this server is for local development only.

Troubleshoot: Address already in use or connection refused: Check the first terminal for startup errors; choose another unused local port in both commands. Do not terminate an unrelated process.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/beginner/request-and-response.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain the difference between HTTP status, transport failure and application error.

new: Start by describing request and response in your own words. Start the bundled local server, then compare a valid endpoint with an unknown route in a second terminal. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for request and response. Explain the difference between HTTP status, transport failure and application error. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect request and response to one system you already know. Explain the difference between HTTP status, transport failure and application error. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Draw the request and response for adding one task.

Interview: Explain the difference between HTTP status, transport failure and application error.

Quiz: The server returns 404. Which conclusion is supported?

The TCP connection failed.

A server replied, but this route was not found.

The database is certainly offline.

Reference: A server replied, but this route was not found. — 404 is an HTTP response. Inspect the requested path and handler; it does not diagnose the database.

Sources:

PHP: development web server: https://www.php.net/manual/en/features.commandline.webserver.php

curl: command reference: https://curl.se/docs/manpage.html

### Request data and output encoding

Untrusted input crosses two boundaries: accepting a valid value and displaying it safely in an output context. HTML text requires HTML encoding; SQL parameters require prepared statements. Neither operation authorizes access.

Mental model: Check the parcel before storing it, then put its label behind glass when displaying it.

Boundary: If HTML executes, inspect every output context; HTML encoding is not a universal JavaScript or URL encoder.

Worked example: A title containing <b>A</b> must display literally if markup is not part of the contract.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: PHP htmlspecialchars

Course tool and framework map: 



Run an HTML-text encoding example, then change the input to include quotes and an ampersand. Keep the explicit UTF-8 encoding.

Commands (after setup)

```
php native-php/check.php encoding
```

Expected: The test prints PASS encoding. The fixture checks that <b>A</b> becomes &lt;b&gt;A&lt;/b&gt; rather than executable markup.

Troubleshoot: Raw HTML is still displayed as markup: Check that the encoded variable, not the original input, is written. htmlspecialchars is for appropriate HTML contexts, not a general URL/JavaScript sanitizer.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/beginner/request-data-and-output-encoding.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Describe validation, authorization and encoding with three different examples.

new: Start by describing request data and output encoding in your own words. Run an HTML-text encoding example, then change the input to include quotes and an ampersand. Keep the explicit UTF-8 encoding. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for request data and output encoding. Describe validation, authorization and encoding with three different examples. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect request data and output encoding to one system you already know. Describe validation, authorization and encoding with three different examples. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If HTML executes, inspect every output context; HTML encoding is not a universal JavaScript or URL encoder.

Interview: Describe validation, authorization and encoding with three different examples.

Quiz: Which operation makes <b>A</b> literal text inside an HTML paragraph?

Concatenate it unchanged.

Hash the input.

HTML-encode it at output.

Reference: HTML-encode it at output. — Output encoding depends on context. Validation and authorization remain separate checks.

Sources:

PHP: HTML output encoding: https://www.php.net/manual/en/function.htmlspecialchars.php

### Composer and repeatable dependencies

Composer’s manifest records dependencies and scripts. For applications, the lock file records selected dependency versions. install respects that selection; update re-resolves it. Review new dependencies, platform requirements and advisories before upgrading.

Mental model: The manifest is a shopping requirement; the lock file is the exact receipt.

Boundary: A lock file does not freeze PHP extensions, operating systems or vulnerabilities.

Worked example: Use composer install for an existing application; use update deliberately when changing dependency selections.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: Composer

Course tool and framework map: 



Install Composer from its official instructions. From the native-php directory, validate the supplied dependency-free manifest and run its test script. Keep any generated lock file when dependencies are added.

Commands (after setup)

```
cd native-php
composer validate --strict
composer install
composer run test
```

Expected: Composer validates the manifest and the test script prints all PHP fixture PASS lines. No third-party package is required by this starter.

Troubleshoot: Composer cannot find PHP or a required extension: Run php -v and php -m in the same terminal. Install the required PHP runtime/extension using your platform instructions; never bypass platform checks to claim success.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/beginner/composer-and-repeatable-dependencies.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain why a lock file and a runtime version are both needed for reproducibility.

new: Start by describing composer and repeatable dependencies in your own words. Install Composer from its official instructions. From the native-php directory, validate the supplied dependency-free manifest and run its test script. Keep any generated lock file when dependencies are added. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for composer and repeatable dependencies. Explain why a lock file and a runtime version are both needed for reproducibility. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect composer and repeatable dependencies to one system you already know. Explain why a lock file and a runtime version are both needed for reproducibility. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why might two developers get different packages without a lock file?

Interview: Explain why a lock file and a runtime version are both needed for reproducibility.

Quiz: How should CI install an application with a reviewed lock file?

Always update to newest versions.

Run composer install using the lock file.

Ignore the lock file.

Reference: Run composer install using the lock file. — install reproduces selected dependencies; update changes selections and should be reviewed.

Sources:

Composer: dependency management: https://getcomposer.org/doc/01-basic-usage.md

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Validation at a boundary: Check input before storing or using it. Client checks help people; the server must also enforce the rule.

Apply validation at a boundary in PHP Developer: Use the concept to complete this role exercise: Add a parameterized database query and a server-side validation case

Prepared statements and transactions: Bind SQL values through PDO prepared statements and keep multi-step changes inside an explicit transaction. String concatenation lets input become query syntax.

### Validation at a boundary

Perform server-side validation before committing state. Reject malformed fields with a clear client error; distinguish them from server faults. Valid syntax does not establish ownership or permission, and client-side validation is only a convenience.

Mental model: A gate with a checklist before a parcel enters a warehouse.

Boundary: Valid input can still be unauthorized; validation is not access control.

Worked example: A blank title receives 400 and does not change task count.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: PHP filter/validation boundary

Course tool and framework map: 



Run the boundary fixture. Add a blank string and an array as invalid quantities; record why a JSON number and a numeric string may need different API policy.

Commands (after setup)

```
php native-php/check.php validation
```

Expected: PASS validation: the example accepts integer 3 and rejects -1 and string "3". The strict input policy is deliberate for this exercise.

Troubleshoot: A numeric string is unexpectedly rejected: Inspect the API contract. If strings are allowed, parse and validate them explicitly; do not silently accept arbitrary coercions.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/intermediate/validation-at-a-boundary.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Design distinct responses for invalid data, unauthenticated callers and forbidden actions.

new: Start by describing validation at a boundary in your own words. Run the boundary fixture. Add a blank string and an array as invalid quantities; record why a JSON number and a numeric string may need different API policy. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for validation at a boundary. Design distinct responses for invalid data, unauthenticated callers and forbidden actions. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect validation at a boundary to one system you already know. Design distinct responses for invalid data, unauthenticated callers and forbidden actions. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why must the server reject invalid input even if the form already checks it?

Interview: Design distinct responses for invalid data, unauthenticated callers and forbidden actions.

Quiz: A valid invoice ID arrives. What still needs checking?

Whether this caller may access that invoice.

Only the spelling of the route.

Nothing; validation is sufficient.

Reference: Whether this caller may access that invoice. — Input validity and resource authorization are separate boundaries.

Sources:

PHP: type declarations: https://www.php.net/manual/en/language.types.declarations.php

### Prepared statements and transactions

PDO placeholders bind values rather than SQL syntax. They cannot safely substitute arbitrary table or column identifiers. Use a transaction when several writes must succeed together; confirm rollback behavior and constraints with a real database driver.

Mental model: A prepared form reserves spaces for values without letting the value rewrite the instructions.

Boundary: If the driver is missing, check php -m for pdo_sqlite; do not remove parameter binding to bypass setup.

Worked example: The title x' OR '1'='1 is stored or rejected as data, never used as SQL logic.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: PDO + SQLite

Course tool and framework map: 



Enable pdo_sqlite in PHP. Run the in-memory PDO fixture. It inserts a quoted name, attempts a duplicate unique key, rolls back and verifies the final count.

Commands (after setup)

```
php -m
php native-php/check.php database
```

Expected: PASS database; a bound quoted value is stored intact and the failed transaction leaves one committed row. The database disappears when the process exits.

Troubleshoot: could not find driver: Enable pdo_sqlite for the CLI runtime shown by php --ini, then rerun. Do not substitute string-concatenated SQL.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/intermediate/prepared-statements-and-transactions.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain transaction atomicity and why it does not make arbitrary SQL safe.

new: Start by describing prepared statements and transactions in your own words. Enable pdo_sqlite in PHP. Run the in-memory PDO fixture. It inserts a quoted name, attempts a duplicate unique key, rolls back and verifies the final count. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for prepared statements and transactions. Explain transaction atomicity and why it does not make arbitrary SQL safe. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect prepared statements and transactions to one system you already know. Explain transaction atomicity and why it does not make arbitrary SQL safe. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the driver is missing, check php -m for pdo_sqlite; do not remove parameter binding to bypass setup.

Interview: Explain transaction atomicity and why it does not make arbitrary SQL safe.

Quiz: Can a placeholder safely choose an arbitrary ORDER BY column?

Yes, every SQL fragment can be bound.

No; allowlist the identifier and bind only values.

Only if the column comes from a cookie.

Reference: No; allowlist the identifier and bind only values. — Placeholders represent values, not SQL identifiers. Allowlist structural choices.

Sources:

PHP: prepared statements: https://www.php.net/manual/en/pdo.prepared-statements.php

PHP: transactions and rollback: https://www.php.net/manual/en/pdo.transactions.php

### Authentication and resource authorization

Store password hashes, not plaintext or reversible password encryption. password_verify checks a candidate against a stored hash. After authentication, enforce a resource policy using trusted server-side identity, not a user-supplied owner field.

Mental model: A building badge identifies a person; each locked room still needs its own permission check.

Boundary: A valid session or an unguessable record ID is not a permission policy.

Worked example: An authenticated user requesting another user’s invoice must be denied unless the policy grants access.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: PHP password_hash / password_verify

Course tool and framework map: 



Run the authentication fixture and inspect its server-side owner check. Add a test for a different invoice owner and describe the policy rather than exposing sensitive invoice contents.

Commands (after setup)

```
php native-php/check.php auth
```

Expected: PASS auth: the correct password verifies, an incorrect password fails and another owner is denied. All credentials are synthetic.

Troubleshoot: A hash string changes on each run: A random salt makes new hashes differ. Use password_verify; do not compare a newly generated hash with a stored hash as plain strings.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/intermediate/authentication-and-resource-authorization.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Show where identity is established and where authorization is enforced.

new: Start by describing authentication and resource authorization in your own words. Run the authentication fixture and inspect its server-side owner check. Add a test for a different invoice owner and describe the policy rather than exposing sensitive invoice contents. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for authentication and resource authorization. Show where identity is established and where authorization is enforced. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect authentication and resource authorization to one system you already know. Show where identity is established and where authorization is enforced. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why does a logged-in user still need an ownership check?

Interview: Show where identity is established and where authorization is enforced.

Quiz: A user changes invoice=12 to invoice=13. What prevents an ownership leak?

A hidden form field.

A server-side authorization check on invoice 13.

A longer session cookie.

Reference: A server-side authorization check on invoice 13. — Never trust client-supplied ownership. Resolve the identity and resource policy on the server.

Sources:

PHP: password_hash: https://www.php.net/manual/en/function.password-hash.php

PHP: session security: https://www.php.net/manual/en/security.sessions.php

### Routes, middleware and test boundaries

Separate transport parsing, access policy and domain work. A Laravel route can use a controller and middleware, but framework defaults still need review. Read the exact installed-version documentation; web and API middleware groups have different behavior.

Mental model: Routing is a switchboard; middleware is a checkpoint; the service does the actual work.

Boundary: A neat architecture cannot compensate for missing integration tests or incorrect policy.

Worked example: In Laravel, keep authentication and rate-limit middleware explicit; test an allowed request, a forbidden user and an invalid payload.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: Laravel + PHPUnit

Course tool and framework map: 



First run the dependency-free route-contract fixture. Then, in an authorized Laravel learning project, create a GET /health route returning JSON and add feature tests for 200 and an unknown route. Record your Laravel and PHP versions.

Commands (after setup)

```
php native-php/check.php routes
# In your separate Laravel project after adding the route and tests:
php artisan route:list
php artisan test
```

Expected: Local fixture prints PASS routes for GET 200, unknown path 404 and unsupported method 405. Laravel tests should assert your route’s status and JSON; the starter is not a Laravel installation.

Troubleshoot: artisan not found: You are outside a Laravel application or have not installed it. Use the official routing guide and its installation links; do not run artisan in the plain PHP starter.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/intermediate/routes-middleware-and-test-boundaries.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Describe unit and HTTP feature tests for the same resource policy.

new: Start by describing routes, middleware and test boundaries in your own words. First run the dependency-free route-contract fixture. Then, in an authorized Laravel learning project, create a GET /health route returning JSON and add feature tests for 200 and an unknown route. Record your Laravel and PHP versions. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for routes, middleware and test boundaries. Describe unit and HTTP feature tests for the same resource policy. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect routes, middleware and test boundaries to one system you already know. Describe unit and HTTP feature tests for the same resource policy. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Which failures need an HTTP integration test rather than only a function test?

Interview: Describe unit and HTTP feature tests for the same resource policy.

Quiz: Where should invoice ownership policy run?

Only in the browser.

In a server-side policy/service reached by the route.

Only in the CSS.

Reference: In a server-side policy/service reached by the route. — A controller or middleware can invoke server-side policy; UI visibility alone does not authorize an operation.

Sources:

Laravel: routing and middleware: https://laravel.com/framework/docs/13.x/routing

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

State and recovery: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.

Apply state and recovery in PHP Developer: Use the concept to complete this role exercise: Document session security, deployment configuration and rollback

Sessions and CSRF: A session identifies an interaction; a state-changing browser form also needs protection against forged cross-site submissions. Tokens and cookie attributes address different threats.

### State and recovery

Separate volatile process memory from durable records. A successful write is not the same as a tested backup. State your recovery point objective (acceptable data loss) and recovery time objective (acceptable downtime) before designing a restore drill.

Mental model: A whiteboard versus a saved notebook.

Boundary: A database also fails; persistence needs backups and tested recovery.

Worked example: Restart this lab server: the task list becomes empty. Explain why before adding a database.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: PDO + database backup tooling

Course tool and framework map: 



Run the SQLite transaction fixture, then write a restore checklist for a file-backed database: pause writes or use a supported consistent backup, restore to a separate location, verify data and a business request.

Commands (after setup)

```
php native-php/check.php database
```

Expected: The transaction assertions pass. Your deliverable additionally names the backup mechanism, isolated restore target, latest restored record and elapsed restore time; the in-memory fixture itself is not a backup drill.

Troubleshoot: Copying a live database gives inconsistent evidence: Use the database’s supported backup process and include associated journal/WAL requirements. Verify a restored copy; never overwrite the only source.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/advanced/state-and-recovery.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain what data a code rollback cannot restore.

new: Start by describing state and recovery in your own words. Run the SQLite transaction fixture, then write a restore checklist for a file-backed database: pause writes or use a supported consistent backup, restore to a separate location, verify data and a business request. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for state and recovery. Explain what data a code rollback cannot restore. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect state and recovery to one system you already know. Explain what data a code rollback cannot restore. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Name two things required before calling this service production ready.

Interview: Explain what data a code rollback cannot restore.

Quiz: Which evidence demonstrates recoverability?

A backup filename only.

A successful restore plus data and behavior checks.

A green code build alone.

Reference: A successful restore plus data and behavior checks. — Backups are useful when a restore meets the stated data-loss and downtime goals.

Sources:

PHP: prepared statements: https://www.php.net/manual/en/pdo.prepared-statements.php

### Sessions and CSRF

A session authenticates ongoing requests, but a browser may attach its cookie to an unwanted request. Protect state-changing browser requests with an appropriate CSRF control, secure cookie attributes and server checks. Regenerate IDs at privilege transitions, not blindly on every request.

Mental model: An ID badge does not prove that every instruction presented with it was intentionally sent by its owner.

Boundary: A token regenerated on every request can invalidate open forms; define lifecycle and retry behavior.

Worked example: A POST without the session-bound CSRF token is denied even if the session cookie exists.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: PHP sessions + framework CSRF middleware

Course tool and framework map: 



Inspect and run the constant-time token comparison fixture. Explain the missing-token and wrong-token cases. In a browser application, test your framework’s real CSRF middleware separately.

Commands (after setup)

```
php native-php/check.php csrf
```

Expected: PASS csrf: a matching token passes; absent and incorrect tokens fail. This isolated function is not an end-to-end browser security test.

Troubleshoot: The token always changes before comparison: Create/store the expected token in the session with the correct lifecycle. Do not replace it before comparing the submitted token. Avoid logging secrets.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/advanced/sessions-and-csrf.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Distinguish CSRF from XSS and explain why each needs its own controls.

new: Start by describing sessions and csrf in your own words. Inspect and run the constant-time token comparison fixture. Explain the missing-token and wrong-token cases. In a browser application, test your framework’s real CSRF middleware separately. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for sessions and csrf. Distinguish CSRF from XSS and explain why each needs its own controls. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect sessions and csrf to one system you already know. Distinguish CSRF from XSS and explain why each needs its own controls. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A token regenerated on every request can invalidate open forms; define lifecycle and retry behavior.

Interview: Distinguish CSRF from XSS and explain why each needs its own controls.

Quiz: Why is a valid session cookie insufficient for a state-changing form?

The browser can attach it to an unwanted request.

Sessions never identify users.

Cookies prevent all attacks automatically.

Reference: The browser can attach it to an unwanted request. — Session identity does not prove user intent. Apply CSRF controls and authorization.

Sources:

PHP: session security: https://www.php.net/manual/en/security.sessions.php

Laravel: routing and middleware: https://laravel.com/framework/docs/13.x/routing

### Queues, retries and idempotency

Model at-least-once delivery: a worker can commit work and then crash before acknowledgement. Durable uniqueness can stop a repeated business key from applying the change twice. For external effects, use provider idempotency features and explicit reconciliation.

Mental model: A delivery slip may be presented twice; the ledger must record whether that delivery was already applied.

Boundary: A process-local array cannot deduplicate work across processes or restarts.

Worked example: A payment request uses the same business operation key on retry. The database enforces uniqueness; a transactional outbox closes a database-to-queue publishing gap.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: Laravel queues + database unique constraints

Course tool and framework map: 



Run the SQLite deduplication fixture. Inspect the unique job key and transaction. Change the payload while retaining the same key and decide whether your production contract should reject conflicting retries.

Commands (after setup)

```
php native-php/check.php queue
```

Expected: PASS queue: applying the same key twice creates one ledger row. A second distinct key creates a second row. The sample is local and does not run a broker.

Troubleshoot: Duplicate external actions despite one ledger entry: Database atomicity does not cover external APIs. Design an outbox and provider-side idempotency/reconciliation; rehearse crash positions.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/advanced/queues-retries-and-idempotency.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Draw the commit-to-ack crash window and explain recovery.

new: Start by describing queues, retries and idempotency in your own words. Run the SQLite deduplication fixture. Inspect the unique job key and transaction. Change the payload while retaining the same key and decide whether your production contract should reject conflicting retries. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for queues, retries and idempotency. Draw the commit-to-ack crash window and explain recovery. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect queues, retries and idempotency to one system you already know. Draw the commit-to-ack crash window and explain recovery. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: What happens if a worker crashes after committing but before acknowledging?

Interview: Draw the commit-to-ack crash window and explain recovery.

Quiz: A worker crashes after committing and before ack. What is a safe expectation?

The job can be delivered again.

The queue proves no duplicate is possible.

Retry must always use a new business key.

Reference: The job can be delivered again. — Design for redelivery and reuse the business operation identity. Do not assume exactly-once external effects.

Sources:

Laravel: queues and retries: https://laravel.com/framework/docs/13.x/queues

PHP: prepared statements: https://www.php.net/manual/en/pdo.prepared-statements.php

### Observable releases and recovery evidence

Build once, test the resulting artifact and promote it unchanged. Keep secrets outside the image, disable public error details and monitor request errors and latency. Pair compatible database changes with an explicit recovery decision; code rollback alone cannot undo data loss.

Mental model: A release is a reversible route with checkpoints; backups are lifeboats that must be tested.

Boundary: Rolling back code does not reverse a destructive schema change or an external side effect.

Worked example: Deploy additive schema changes before code that uses them; later remove old fields only after compatibility is no longer needed.

Setup: Install a supported PHP CLI (8.2 or newer for these fixtures), with PDO and pdo_sqlite enabled. Download and extract the starter ZIP into a new folder. Open a terminal in the extracted folder that contains native-php. Run php -v and php -m. Commands start from this folder unless a step says cd. On Windows, use PowerShell with curl.exe for curl requests, or a Linux shell in WSL. Composer is needed only when its lesson introduces it.

Tools for this exercise: Composer + CI + PHP runtime

Course tool and framework map: 



Run the complete PHP fixture suite and syntax checks. Create a release-evidence.md containing runtime, dependency lock hash, test results, health check, migration compatibility and rollback/restore criteria.

Commands (after setup)

```
php -l native-php/index.php
php native-php/check.php all
# If Composer is installed:
cd native-php
composer validate --strict
composer run test
```

Expected: All checks pass; your release evidence states which checks ran locally and which production checks remain untested. Do not label this a cloud deployment.

Troubleshoot: Tests pass but the deployed runtime lacks an extension: Check the deployment runtime and required extensions in CI and on the target. Build/test the same artifact; retain a compatible previous release.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: php-developer/advanced/observable-releases-and-recovery-evidence.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Define a release gate using real user signals and a compatible recovery path.

new: Start by describing observable releases and recovery evidence in your own words. Run the complete PHP fixture suite and syntax checks. Create a release-evidence.md containing runtime, dependency lock hash, test results, health check, migration compatibility and rollback/restore criteria. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for observable releases and recovery evidence. Define a release gate using real user signals and a compatible recovery path. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect observable releases and recovery evidence to one system you already know. Define a release gate using real user signals and a compatible recovery path. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: What evidence would justify continuing a rollout after a migration?

Interview: Define a release gate using real user signals and a compatible recovery path.

Quiz: A migration deletes a column used by the old release. Is code rollback enough?

Yes, always.

No; compatibility or data recovery must be planned.

Only changing the image tag is required.

Reference: No; compatibility or data recovery must be planned. — Schema and external state survive a code rollback. Use staged compatible changes and rehearsed data recovery.

Sources:

Composer: dependency management: https://getcomposer.org/doc/01-basic-usage.md

PHP: development web server: https://www.php.net/manual/en/features.commandline.webserver.php
