# Numbered lesson workbook

Core lessons and original role workshops remain in README.md. Commands below require the stated setup; examples are learning environments, not production deployments.

## beginner

### Values, functions and deliberate errors
Use integer cents for this exercise to avoid floating-point money surprises. declare(strict_types=1) makes scalar type behavior explicit for calls in the file. Guard the allowed range as well as the PHP type. Small functions are easier to test than a large request handler.

Mental model: A function is a small workshop: inputs enter, a result leaves, and its contract says what it accepts.
Limit: A type declaration does not establish business validity: a negative integer is still an integer.

Practice: Read total() in the fixture. Predict the valid total and the negative-quantity failure before running it. Add a zero-quantity assertion and rerun.
```
php -v
php -l native-php/check.php
php native-php/check.php values
```
Expected: Syntax check succeeds; values prints PASS values. The fixture verifies 3 × 125 = 375 and rejects negative quantity.
Troubleshooting: TypeError or failed assertion: Inspect the supplied type and business range separately. Do not remove the guard just to make the test pass; show both valid and invalid cases.

Tools: PHP CLI
Deliverable: php-developer/beginner/values-functions-and-deliberate-errors.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Walk through the invalid input and name where the program rejects it.

new: Start by describing values, functions and deliberate errors in your own words. Read total() in the fixture. Predict the valid total and the negative-quantity failure before running it. Add a zero-quantity assertion and rerun. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for values, functions and deliberate errors. Walk through the invalid input and name where the program rejects it. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect values, functions and deliberate errors to one system you already know. Walk through the invalid input and name where the program rejects it. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Quantity -1 is an integer. What else is needed?
A business range check.
A longer variable name.
HTML encoding.
Reference: A business range check. — Types describe shape; validation enforces domain rules such as nonnegative quantities.
Sources: https://www.php.net/manual/en/language.types.declarations.php

### Request and response
Treat method, path, headers and body as separate parts of a request. The server chooses a status and response type. Trace one request in a terminal before adding a framework. A browser address bar normally sends GET; it cannot stand in for every API test.

Mental model: A service counter: the request is your order and the response is the result.
Limit: Networks can time out; sending an order does not prove it was fulfilled.

Practice: Start the bundled local server, then compare a valid endpoint with an unknown route in a second terminal.
```
php -S 127.0.0.1:8138 -t native-php
# Second terminal, from the extracted pack:
curl -i http://127.0.0.1:8138/index.php
curl -i http://127.0.0.1:8138/missing
```
Expected: First request: HTTP 200 with JSON {"status":"ok"}. Second: HTTP 404 with JSON error. Stop the server with Ctrl+C; this server is for local development only.
Troubleshooting: Address already in use or connection refused: Check the first terminal for startup errors; choose another unused local port in both commands. Do not terminate an unrelated process.

Tools: PHP CLI + curl
Deliverable: php-developer/beginner/request-and-response.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain the difference between HTTP status, transport failure and application error.

new: Start by describing request and response in your own words. Start the bundled local server, then compare a valid endpoint with an unknown route in a second terminal. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for request and response. Explain the difference between HTTP status, transport failure and application error. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect request and response to one system you already know. Explain the difference between HTTP status, transport failure and application error. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: The server returns 404. Which conclusion is supported?
The TCP connection failed.
A server replied, but this route was not found.
The database is certainly offline.
Reference: A server replied, but this route was not found. — 404 is an HTTP response. Inspect the requested path and handler; it does not diagnose the database.
Sources: https://www.php.net/manual/en/features.commandline.webserver.php https://curl.se/docs/manpage.html

### Request data and output encoding
Untrusted input crosses two boundaries: accepting a valid value and displaying it safely in an output context. HTML text requires HTML encoding; SQL parameters require prepared statements. Neither operation authorizes access.

Mental model: Check the parcel before storing it, then put its label behind glass when displaying it.
Limit: If HTML executes, inspect every output context; HTML encoding is not a universal JavaScript or URL encoder.

Practice: Run an HTML-text encoding example, then change the input to include quotes and an ampersand. Keep the explicit UTF-8 encoding.
```
php native-php/check.php encoding
```
Expected: The test prints PASS encoding. The fixture checks that <b>A</b> becomes &lt;b&gt;A&lt;/b&gt; rather than executable markup.
Troubleshooting: Raw HTML is still displayed as markup: Check that the encoded variable, not the original input, is written. htmlspecialchars is for appropriate HTML contexts, not a general URL/JavaScript sanitizer.

Tools: PHP htmlspecialchars
Deliverable: php-developer/beginner/request-data-and-output-encoding.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Describe validation, authorization and encoding with three different examples.

new: Start by describing request data and output encoding in your own words. Run an HTML-text encoding example, then change the input to include quotes and an ampersand. Keep the explicit UTF-8 encoding. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for request data and output encoding. Describe validation, authorization and encoding with three different examples. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect request data and output encoding to one system you already know. Describe validation, authorization and encoding with three different examples. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Which operation makes <b>A</b> literal text inside an HTML paragraph?
Concatenate it unchanged.
Hash the input.
HTML-encode it at output.
Reference: HTML-encode it at output. — Output encoding depends on context. Validation and authorization remain separate checks.
Sources: https://www.php.net/manual/en/function.htmlspecialchars.php

### Composer and repeatable dependencies
Composer’s manifest records dependencies and scripts. For applications, the lock file records selected dependency versions. install respects that selection; update re-resolves it. Review new dependencies, platform requirements and advisories before upgrading.

Mental model: The manifest is a shopping requirement; the lock file is the exact receipt.
Limit: A lock file does not freeze PHP extensions, operating systems or vulnerabilities.

Practice: Install Composer from its official instructions. From the native-php directory, validate the supplied dependency-free manifest and run its test script. Keep any generated lock file when dependencies are added.
```
cd native-php
composer validate --strict
composer install
composer run test
```
Expected: Composer validates the manifest and the test script prints all PHP fixture PASS lines. No third-party package is required by this starter.
Troubleshooting: Composer cannot find PHP or a required extension: Run php -v and php -m in the same terminal. Install the required PHP runtime/extension using your platform instructions; never bypass platform checks to claim success.

Tools: Composer
Deliverable: php-developer/beginner/composer-and-repeatable-dependencies.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain why a lock file and a runtime version are both needed for reproducibility.

new: Start by describing composer and repeatable dependencies in your own words. Install Composer from its official instructions. From the native-php directory, validate the supplied dependency-free manifest and run its test script. Keep any generated lock file when dependencies are added. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for composer and repeatable dependencies. Explain why a lock file and a runtime version are both needed for reproducibility. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect composer and repeatable dependencies to one system you already know. Explain why a lock file and a runtime version are both needed for reproducibility. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: How should CI install an application with a reviewed lock file?
Always update to newest versions.
Run composer install using the lock file.
Ignore the lock file.
Reference: Run composer install using the lock file. — install reproduces selected dependencies; update changes selections and should be reviewed.
Sources: https://getcomposer.org/doc/01-basic-usage.md

## intermediate

### Validation at a boundary
Perform server-side validation before committing state. Reject malformed fields with a clear client error; distinguish them from server faults. Valid syntax does not establish ownership or permission, and client-side validation is only a convenience.

Mental model: A gate with a checklist before a parcel enters a warehouse.
Limit: Valid input can still be unauthorized; validation is not access control.

Practice: Run the boundary fixture. Add a blank string and an array as invalid quantities; record why a JSON number and a numeric string may need different API policy.
```
php native-php/check.php validation
```
Expected: PASS validation: the example accepts integer 3 and rejects -1 and string "3". The strict input policy is deliberate for this exercise.
Troubleshooting: A numeric string is unexpectedly rejected: Inspect the API contract. If strings are allowed, parse and validate them explicitly; do not silently accept arbitrary coercions.

Tools: PHP filter/validation boundary
Deliverable: php-developer/intermediate/validation-at-a-boundary.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Design distinct responses for invalid data, unauthenticated callers and forbidden actions.

new: Start by describing validation at a boundary in your own words. Run the boundary fixture. Add a blank string and an array as invalid quantities; record why a JSON number and a numeric string may need different API policy. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for validation at a boundary. Design distinct responses for invalid data, unauthenticated callers and forbidden actions. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect validation at a boundary to one system you already know. Design distinct responses for invalid data, unauthenticated callers and forbidden actions. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: A valid invoice ID arrives. What still needs checking?
Whether this caller may access that invoice.
Only the spelling of the route.
Nothing; validation is sufficient.
Reference: Whether this caller may access that invoice. — Input validity and resource authorization are separate boundaries.
Sources: https://www.php.net/manual/en/language.types.declarations.php

### Prepared statements and transactions
PDO placeholders bind values rather than SQL syntax. They cannot safely substitute arbitrary table or column identifiers. Use a transaction when several writes must succeed together; confirm rollback behavior and constraints with a real database driver.

Mental model: A prepared form reserves spaces for values without letting the value rewrite the instructions.
Limit: If the driver is missing, check php -m for pdo_sqlite; do not remove parameter binding to bypass setup.

Practice: Enable pdo_sqlite in PHP. Run the in-memory PDO fixture. It inserts a quoted name, attempts a duplicate unique key, rolls back and verifies the final count.
```
php -m
php native-php/check.php database
```
Expected: PASS database; a bound quoted value is stored intact and the failed transaction leaves one committed row. The database disappears when the process exits.
Troubleshooting: could not find driver: Enable pdo_sqlite for the CLI runtime shown by php --ini, then rerun. Do not substitute string-concatenated SQL.

Tools: PDO + SQLite
Deliverable: php-developer/intermediate/prepared-statements-and-transactions.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain transaction atomicity and why it does not make arbitrary SQL safe.

new: Start by describing prepared statements and transactions in your own words. Enable pdo_sqlite in PHP. Run the in-memory PDO fixture. It inserts a quoted name, attempts a duplicate unique key, rolls back and verifies the final count. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for prepared statements and transactions. Explain transaction atomicity and why it does not make arbitrary SQL safe. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect prepared statements and transactions to one system you already know. Explain transaction atomicity and why it does not make arbitrary SQL safe. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Can a placeholder safely choose an arbitrary ORDER BY column?
Yes, every SQL fragment can be bound.
No; allowlist the identifier and bind only values.
Only if the column comes from a cookie.
Reference: No; allowlist the identifier and bind only values. — Placeholders represent values, not SQL identifiers. Allowlist structural choices.
Sources: https://www.php.net/manual/en/pdo.prepared-statements.php https://www.php.net/manual/en/pdo.transactions.php

### Authentication and resource authorization
Store password hashes, not plaintext or reversible password encryption. password_verify checks a candidate against a stored hash. After authentication, enforce a resource policy using trusted server-side identity, not a user-supplied owner field.

Mental model: A building badge identifies a person; each locked room still needs its own permission check.
Limit: A valid session or an unguessable record ID is not a permission policy.

Practice: Run the authentication fixture and inspect its server-side owner check. Add a test for a different invoice owner and describe the policy rather than exposing sensitive invoice contents.
```
php native-php/check.php auth
```
Expected: PASS auth: the correct password verifies, an incorrect password fails and another owner is denied. All credentials are synthetic.
Troubleshooting: A hash string changes on each run: A random salt makes new hashes differ. Use password_verify; do not compare a newly generated hash with a stored hash as plain strings.

Tools: PHP password_hash / password_verify
Deliverable: php-developer/intermediate/authentication-and-resource-authorization.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Show where identity is established and where authorization is enforced.

new: Start by describing authentication and resource authorization in your own words. Run the authentication fixture and inspect its server-side owner check. Add a test for a different invoice owner and describe the policy rather than exposing sensitive invoice contents. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for authentication and resource authorization. Show where identity is established and where authorization is enforced. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect authentication and resource authorization to one system you already know. Show where identity is established and where authorization is enforced. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: A user changes invoice=12 to invoice=13. What prevents an ownership leak?
A hidden form field.
A server-side authorization check on invoice 13.
A longer session cookie.
Reference: A server-side authorization check on invoice 13. — Never trust client-supplied ownership. Resolve the identity and resource policy on the server.
Sources: https://www.php.net/manual/en/function.password-hash.php https://www.php.net/manual/en/security.sessions.php

### Routes, middleware and test boundaries
Separate transport parsing, access policy and domain work. A Laravel route can use a controller and middleware, but framework defaults still need review. Read the exact installed-version documentation; web and API middleware groups have different behavior.

Mental model: Routing is a switchboard; middleware is a checkpoint; the service does the actual work.
Limit: A neat architecture cannot compensate for missing integration tests or incorrect policy.

Practice: First run the dependency-free route-contract fixture. Then, in an authorized Laravel learning project, create a GET /health route returning JSON and add feature tests for 200 and an unknown route. Record your Laravel and PHP versions.
```
php native-php/check.php routes
# In your separate Laravel project after adding the route and tests:
php artisan route:list
php artisan test
```
Expected: Local fixture prints PASS routes for GET 200, unknown path 404 and unsupported method 405. Laravel tests should assert your route’s status and JSON; the starter is not a Laravel installation.
Troubleshooting: artisan not found: You are outside a Laravel application or have not installed it. Use the official routing guide and its installation links; do not run artisan in the plain PHP starter.

Tools: Laravel + PHPUnit
Deliverable: php-developer/intermediate/routes-middleware-and-test-boundaries.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Describe unit and HTTP feature tests for the same resource policy.

new: Start by describing routes, middleware and test boundaries in your own words. First run the dependency-free route-contract fixture. Then, in an authorized Laravel learning project, create a GET /health route returning JSON and add feature tests for 200 and an unknown route. Record your Laravel and PHP versions. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for routes, middleware and test boundaries. Describe unit and HTTP feature tests for the same resource policy. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect routes, middleware and test boundaries to one system you already know. Describe unit and HTTP feature tests for the same resource policy. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Where should invoice ownership policy run?
Only in the browser.
In a server-side policy/service reached by the route.
Only in the CSS.
Reference: In a server-side policy/service reached by the route. — A controller or middleware can invoke server-side policy; UI visibility alone does not authorize an operation.
Sources: https://laravel.com/framework/docs/13.x/routing

## advanced

### State and recovery
Separate volatile process memory from durable records. A successful write is not the same as a tested backup. State your recovery point objective (acceptable data loss) and recovery time objective (acceptable downtime) before designing a restore drill.

Mental model: A whiteboard versus a saved notebook.
Limit: A database also fails; persistence needs backups and tested recovery.

Practice: Run the SQLite transaction fixture, then write a restore checklist for a file-backed database: pause writes or use a supported consistent backup, restore to a separate location, verify data and a business request.
```
php native-php/check.php database
```
Expected: The transaction assertions pass. Your deliverable additionally names the backup mechanism, isolated restore target, latest restored record and elapsed restore time; the in-memory fixture itself is not a backup drill.
Troubleshooting: Copying a live database gives inconsistent evidence: Use the database’s supported backup process and include associated journal/WAL requirements. Verify a restored copy; never overwrite the only source.

Tools: PDO + database backup tooling
Deliverable: php-developer/advanced/state-and-recovery.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain what data a code rollback cannot restore.

new: Start by describing state and recovery in your own words. Run the SQLite transaction fixture, then write a restore checklist for a file-backed database: pause writes or use a supported consistent backup, restore to a separate location, verify data and a business request. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for state and recovery. Explain what data a code rollback cannot restore. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect state and recovery to one system you already know. Explain what data a code rollback cannot restore. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Which evidence demonstrates recoverability?
A backup filename only.
A successful restore plus data and behavior checks.
A green code build alone.
Reference: A successful restore plus data and behavior checks. — Backups are useful when a restore meets the stated data-loss and downtime goals.
Sources: https://www.php.net/manual/en/pdo.prepared-statements.php

### Sessions and CSRF
A session authenticates ongoing requests, but a browser may attach its cookie to an unwanted request. Protect state-changing browser requests with an appropriate CSRF control, secure cookie attributes and server checks. Regenerate IDs at privilege transitions, not blindly on every request.

Mental model: An ID badge does not prove that every instruction presented with it was intentionally sent by its owner.
Limit: A token regenerated on every request can invalidate open forms; define lifecycle and retry behavior.

Practice: Inspect and run the constant-time token comparison fixture. Explain the missing-token and wrong-token cases. In a browser application, test your framework’s real CSRF middleware separately.
```
php native-php/check.php csrf
```
Expected: PASS csrf: a matching token passes; absent and incorrect tokens fail. This isolated function is not an end-to-end browser security test.
Troubleshooting: The token always changes before comparison: Create/store the expected token in the session with the correct lifecycle. Do not replace it before comparing the submitted token. Avoid logging secrets.

Tools: PHP sessions + framework CSRF middleware
Deliverable: php-developer/advanced/sessions-and-csrf.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Distinguish CSRF from XSS and explain why each needs its own controls.

new: Start by describing sessions and csrf in your own words. Inspect and run the constant-time token comparison fixture. Explain the missing-token and wrong-token cases. In a browser application, test your framework’s real CSRF middleware separately. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for sessions and csrf. Distinguish CSRF from XSS and explain why each needs its own controls. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect sessions and csrf to one system you already know. Distinguish CSRF from XSS and explain why each needs its own controls. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Why is a valid session cookie insufficient for a state-changing form?
The browser can attach it to an unwanted request.
Sessions never identify users.
Cookies prevent all attacks automatically.
Reference: The browser can attach it to an unwanted request. — Session identity does not prove user intent. Apply CSRF controls and authorization.
Sources: https://www.php.net/manual/en/security.sessions.php https://laravel.com/framework/docs/13.x/routing

### Queues, retries and idempotency
Model at-least-once delivery: a worker can commit work and then crash before acknowledgement. Durable uniqueness can stop a repeated business key from applying the change twice. For external effects, use provider idempotency features and explicit reconciliation.

Mental model: A delivery slip may be presented twice; the ledger must record whether that delivery was already applied.
Limit: A process-local array cannot deduplicate work across processes or restarts.

Practice: Run the SQLite deduplication fixture. Inspect the unique job key and transaction. Change the payload while retaining the same key and decide whether your production contract should reject conflicting retries.
```
php native-php/check.php queue
```
Expected: PASS queue: applying the same key twice creates one ledger row. A second distinct key creates a second row. The sample is local and does not run a broker.
Troubleshooting: Duplicate external actions despite one ledger entry: Database atomicity does not cover external APIs. Design an outbox and provider-side idempotency/reconciliation; rehearse crash positions.

Tools: Laravel queues + database unique constraints
Deliverable: php-developer/advanced/queues-retries-and-idempotency.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Draw the commit-to-ack crash window and explain recovery.

new: Start by describing queues, retries and idempotency in your own words. Run the SQLite deduplication fixture. Inspect the unique job key and transaction. Change the payload while retaining the same key and decide whether your production contract should reject conflicting retries. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for queues, retries and idempotency. Draw the commit-to-ack crash window and explain recovery. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect queues, retries and idempotency to one system you already know. Draw the commit-to-ack crash window and explain recovery. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: A worker crashes after committing and before ack. What is a safe expectation?
The job can be delivered again.
The queue proves no duplicate is possible.
Retry must always use a new business key.
Reference: The job can be delivered again. — Design for redelivery and reuse the business operation identity. Do not assume exactly-once external effects.
Sources: https://laravel.com/framework/docs/13.x/queues https://www.php.net/manual/en/pdo.prepared-statements.php

### Observable releases and recovery evidence
Build once, test the resulting artifact and promote it unchanged. Keep secrets outside the image, disable public error details and monitor request errors and latency. Pair compatible database changes with an explicit recovery decision; code rollback alone cannot undo data loss.

Mental model: A release is a reversible route with checkpoints; backups are lifeboats that must be tested.
Limit: Rolling back code does not reverse a destructive schema change or an external side effect.

Practice: Run the complete PHP fixture suite and syntax checks. Create a release-evidence.md containing runtime, dependency lock hash, test results, health check, migration compatibility and rollback/restore criteria.
```
php -l native-php/index.php
php native-php/check.php all
# If Composer is installed:
cd native-php
composer validate --strict
composer run test
```
Expected: All checks pass; your release evidence states which checks ran locally and which production checks remain untested. Do not label this a cloud deployment.
Troubleshooting: Tests pass but the deployed runtime lacks an extension: Check the deployment runtime and required extensions in CI and on the target. Build/test the same artifact; retain a compatible previous release.

Tools: Composer + CI + PHP runtime
Deliverable: php-developer/advanced/observable-releases-and-recovery-evidence.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Define a release gate using real user signals and a compatible recovery path.

new: Start by describing observable releases and recovery evidence in your own words. Run the complete PHP fixture suite and syntax checks. Create a release-evidence.md containing runtime, dependency lock hash, test results, health check, migration compatibility and rollback/restore criteria. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for observable releases and recovery evidence. Define a release gate using real user signals and a compatible recovery path. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect observable releases and recovery evidence to one system you already know. Define a release gate using real user signals and a compatible recovery path. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: A migration deletes a column used by the old release. Is code rollback enough?
Yes, always.
No; compatibility or data recovery must be planned.
Only changing the image tag is required.
Reference: No; compatibility or data recovery must be planned. — Schema and external state survive a code rollback. Use staged compatible changes and rehearsed data recovery.
Sources: https://getcomposer.org/doc/01-basic-usage.md https://www.php.net/manual/en/features.commandline.webserver.php
