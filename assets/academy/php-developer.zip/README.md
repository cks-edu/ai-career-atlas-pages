# PHP Developer

Software Engineering

Start with the numbered Beginner lessons. Each lesson combines explanation, a mental model, guided practice, a checked quiz and source reading. Change the guidance lens to match your goal; core concepts remain the same. Existing labs and projects remain available in their tabs.

## beginner

Create a local PHP form, handle POST, trim and validate the title and render with htmlspecialchars using UTF-8. Start php -S 127.0.0.1:8137 in that folder and test blank and markup inputs.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Request and response
A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.
Mental model: A service counter: the request is your order and the response is the result.
Limit: Networks can time out; sending an order does not prove it was fulfilled.
Example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.
Recall: Draw the request and response for adding one task.

### Request data and output encoding
PHP receives untrusted request values. Validation decides what is acceptable; HTML encoding decides how accepted text is safely displayed. Neither substitutes for authorization.
Mental model: Check the parcel before storing it, then put its label behind glass when displaying it.
Limit: If HTML executes, inspect every output context; HTML encoding is not a universal JavaScript or URL encoder.
Example: A title containing <b>A</b> must display literally if markup is not part of the contract.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If HTML executes, inspect every output context; HTML encoding is not a universal JavaScript or URL encoder.

### Values, functions and deliberate errors
PHP executes statements on the server or in a command-line process. Name values, pass them to small functions and check both expected results and invalid input.
Mental model: A function is a small workshop: inputs enter, a result leaves, and its contract says what it accepts.
Limit: A type declaration does not establish business validity: a negative integer is still an integer.
Example: A total function can accept integer cents; reject a negative quantity before multiplication.
Recall: Why can an integer pass a type check but still be invalid?

### Composer and repeatable dependencies
Composer resolves PHP package dependencies. Commit composer.json and the application lock file so another developer can install the selected versions.
Mental model: The manifest is a shopping requirement; the lock file is the exact receipt.
Limit: A lock file does not freeze PHP extensions, operating systems or vulnerabilities.
Example: Use composer install for an existing application; use update deliberately when changing dependency selections.
Recall: Why might two developers get different packages without a lock file?

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A title containing <b>A</b> must display literally if markup is not part of the contract. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a local PHP form, handle POST, trim and validate the title and render with htmlspecialchars using UTF-8. Start php -S 127.0.0.1:8137 in that folder and test blank and markup inputs.
```
php -S 127.0.0.1:8137
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Blank input shows an error; markup renders as text; development server is loopback-only.

6. Role workshop · debug and verify
If HTML executes, inspect every output context; HTML encoding is not a universal JavaScript or URL encoder. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save form.php and request/output evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Blank input shows an error; markup renders as text; development server is loopback-only.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Request data and output encoding: If HTML executes, inspect every output context; HTML encoding is not a universal JavaScript or URL encoder.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: form.php and request/output evidence
Blank input shows an error; markup renders as text; development server is loopback-only.

Interview: Work through this PHP Developer case: A title containing <b>A</b> must display literally if markup is not part of the contract. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: PHP receives untrusted request values. Validation decides what is acceptable; HTML encoding decides how accepted text is safely displayed. Neither substitutes for authorization. Expected evidence: Blank input shows an error; markup renders as text; development server is loopback-only. Diagnosis: If HTML executes, inspect every output context; HTML encoding is not a universal JavaScript or URL encoder. State the limits of the mental model: Check the parcel before storing it, then put its label behind glass when displaying it.

Resume: Built form.php and request/output evidence using PHP; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Use PDO SQLite in a disposable local database. Create a tasks table, prepare an INSERT, bind the title and select the result. Add a failed multi-step transaction and confirm rollback.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Validation at a boundary
Check input before storing or using it. Client checks help people; the server must also enforce the rule.
Mental model: A gate with a checklist before a parcel enters a warehouse.
Limit: Valid input can still be unauthorized; validation is not access control.
Example: A blank title receives 400 and does not change task count.
Recall: Why must the server reject invalid input even if the form already checks it?

### Prepared statements and transactions
Bind SQL values through PDO prepared statements and keep multi-step changes inside an explicit transaction. String concatenation lets input become query syntax.
Mental model: A prepared form reserves spaces for values without letting the value rewrite the instructions.
Limit: If the driver is missing, check php -m for pdo_sqlite; do not remove parameter binding to bypass setup.
Example: The title x' OR '1'='1 is stored or rejected as data, never used as SQL logic.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If the driver is missing, check php -m for pdo_sqlite; do not remove parameter binding to bypass setup.

### Authentication and resource authorization
Authentication establishes who a caller is. Authorization decides whether that caller may perform this action on this specific resource. Check authorization on the server for every sensitive operation.
Mental model: A building badge identifies a person; each locked room still needs its own permission check.
Limit: A valid session or an unguessable record ID is not a permission policy.
Example: An authenticated user requesting another user’s invoice must be denied unless the policy grants access.
Recall: Why does a logged-in user still need an ownership check?

### Routes, middleware and test boundaries
A route selects a handler from the method and path. Middleware applies cross-cutting checks before or after it. Keep business rules testable outside the HTTP layer.
Mental model: Routing is a switchboard; middleware is a checkpoint; the service does the actual work.
Limit: A neat architecture cannot compensate for missing integration tests or incorrect policy.
Example: In Laravel, keep authentication and rate-limit middleware explicit; test an allowed request, a forbidden user and an invalid payload.
Recall: Which failures need an HTTP integration test rather than only a function test?

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
The title x' OR '1'='1 is stored or rejected as data, never used as SQL logic. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use PDO SQLite in a disposable local database. Create a tasks table, prepare an INSERT, bind the title and select the result. Add a failed multi-step transaction and confirm rollback.
```
php -m
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: One intended row and no unintended selection; failed transaction leaves prior data unchanged.

6. Role workshop · debug and verify
If the driver is missing, check php -m for pdo_sqlite; do not remove parameter binding to bypass setup. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save PDO implementation and injection/rollback tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One intended row and no unintended selection; failed transaction leaves prior data unchanged.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Prepared statements and transactions: If the driver is missing, check php -m for pdo_sqlite; do not remove parameter binding to bypass setup.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: PDO implementation and injection/rollback tests
One intended row and no unintended selection; failed transaction leaves prior data unchanged.

Interview: Work through this PHP Developer case: The title x' OR '1'='1 is stored or rejected as data, never used as SQL logic. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Bind SQL values through PDO prepared statements and keep multi-step changes inside an explicit transaction. String concatenation lets input become query syntax. Expected evidence: One intended row and no unintended selection; failed transaction leaves prior data unchanged. Diagnosis: If the driver is missing, check php -m for pdo_sqlite; do not remove parameter binding to bypass setup. State the limits of the mental model: A prepared form reserves spaces for values without letting the value rewrite the instructions.

Resume: Built PDO implementation and injection/rollback tests using PHP; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Add a random session token, compare it safely on POST and test missing/wrong/correct values. Document Secure-cookie behavior under HTTPS and why the local development server is not a production deployment.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State and recovery
State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.
Mental model: A whiteboard versus a saved notebook.
Limit: A database also fails; persistence needs backups and tested recovery.
Example: Restart this lab server: the task list becomes empty. Explain why before adding a database.
Recall: Name two things required before calling this service production ready.

### Sessions and CSRF
A session identifies an interaction; a state-changing browser form also needs protection against forged cross-site submissions. Tokens and cookie attributes address different threats.
Mental model: An ID badge does not prove that every instruction presented with it was intentionally sent by its owner.
Limit: A token regenerated on every request can invalidate open forms; define lifecycle and retry behavior.
Example: A POST without the session-bound CSRF token is denied even if the session cookie exists.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A token regenerated on every request can invalidate open forms; define lifecycle and retry behavior.

### Queues, retries and idempotency
Queues move slow work out of the request. A worker may receive a job again after a crash. Make repeated business operations safe using a durable unique key and atomic state changes.
Mental model: A delivery slip may be presented twice; the ledger must record whether that delivery was already applied.
Limit: A process-local array cannot deduplicate work across processes or restarts.
Example: A payment request uses the same business operation key on retry. The database enforces uniqueness; a transactional outbox closes a database-to-queue publishing gap.
Recall: What happens if a worker crashes after committing but before acknowledging?

### Observable releases and recovery evidence
Release an immutable application artifact with dependencies, compatible migrations and a recovery plan. Measure behavior after release and rehearse restoring data separately from replacing code.
Mental model: A release is a reversible route with checkpoints; backups are lifeboats that must be tested.
Limit: Rolling back code does not reverse a destructive schema change or an external side effect.
Example: Deploy additive schema changes before code that uses them; later remove old fields only after compatibility is no longer needed.
Recall: What evidence would justify continuing a rollout after a migration?

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A POST without the session-bound CSRF token is denied even if the session cookie exists. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add a random session token, compare it safely on POST and test missing/wrong/correct values. Document Secure-cookie behavior under HTTPS and why the local development server is not a production deployment.
```
php -S 127.0.0.1:8137
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Only the matching-token request mutates state; session data is absent from public logs.

6. Role workshop · debug and verify
A token regenerated on every request can invalidate open forms; define lifecycle and retry behavior. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save session-threat model, tests and deployment checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Only the matching-token request mutates state; session data is absent from public logs.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Sessions and CSRF: A token regenerated on every request can invalidate open forms; define lifecycle and retry behavior.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: session-threat model, tests and deployment checklist
Only the matching-token request mutates state; session data is absent from public logs.

Interview: Work through this PHP Developer case: A POST without the session-bound CSRF token is denied even if the session cookie exists. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A session identifies an interaction; a state-changing browser form also needs protection against forged cross-site submissions. Tokens and cookie attributes address different threats. Expected evidence: Only the matching-token request mutates state; session data is absent from public logs. Diagnosis: A token regenerated on every request can invalidate open forms; define lifecycle and retry behavior. State the limits of the mental model: An ID badge does not prove that every instruction presented with it was intentionally sent by its owner.

Resume: Built session-threat model, tests and deployment checklist using PHP; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
PHP: a simple tutorial: https://www.php.net/manual/en/tutorial.php
MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
PHP: development web server: https://www.php.net/manual/en/features.commandline.webserver.php
curl: command reference: https://curl.se/docs/manpage.html
PHP: installation and configuration: https://www.php.net/manual/en/install.php
PHP: HTML output encoding: https://www.php.net/manual/en/function.htmlspecialchars.php
PHP: type declarations: https://www.php.net/manual/en/language.types.declarations.php
Composer: dependency management: https://getcomposer.org/doc/01-basic-usage.md
PHP: prepared statements: https://www.php.net/manual/en/pdo.prepared-statements.php
PHP: transactions and rollback: https://www.php.net/manual/en/pdo.transactions.php
PHP: password_hash: https://www.php.net/manual/en/function.password-hash.php
PHP: session security: https://www.php.net/manual/en/security.sessions.php
Laravel: routing and middleware: https://laravel.com/framework/docs/13.x/routing
Laravel: queues and retries: https://laravel.com/framework/docs/13.x/queues
