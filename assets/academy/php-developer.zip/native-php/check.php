<?php
declare(strict_types=1);
function check(bool $condition, string $message): void {
    if (!$condition) { throw new RuntimeException($message); }
}
function total(int $cents, int $quantity): int {
    if ($cents < 0 || $quantity < 0) { throw new InvalidArgumentException('Negative value'); }
    return $cents * $quantity;
}
function validQuantity(mixed $value): bool { return is_int($value) && $value >= 0; }
function route(string $method, string $path): int {
    if ($path !== '/health') { return 404; }
    return $method === 'GET' ? 200 : 405;
}
function tokenValid(string $expected, mixed $given): bool {
    return is_string($given) && $given !== '' && hash_equals($expected, $given);
}
$tests = [
 'values' => function (): void {
    check(total(125, 3) === 375, 'Wrong total');
    try { total(125, -1); throw new RuntimeException('Accepted negative'); }
    catch (InvalidArgumentException $expected) {}
 },
 'encoding' => function (): void {
    check(htmlspecialchars('<b>A</b>', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') === '&lt;b&gt;A&lt;/b&gt;', 'Encoding mismatch');
 },
 'validation' => function (): void {
    check(validQuantity(3) && !validQuantity(-1) && !validQuantity('3'), 'Boundary mismatch');
 },
 'database' => function (): void {
    $db = new PDO('sqlite::memory:', null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $db->exec('CREATE TABLE people (id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL)');
    $insert = $db->prepare('INSERT INTO people (name) VALUES (:name)');
    $insert->execute(['name' => "O'Reilly"]);
    check($db->query('SELECT name FROM people')->fetchColumn() === "O'Reilly", 'Value mismatch');
    $db->beginTransaction();
    try { $insert->execute(['name' => 'A']); $insert->execute(['name' => "O'Reilly"]); $db->commit(); }
    catch (PDOException $expected) { if ($db->inTransaction()) { $db->rollBack(); } }
    check((int)$db->query('SELECT COUNT(*) FROM people')->fetchColumn() === 1, 'Rollback mismatch');
 },
 'auth' => function (): void {
    $hash = password_hash('synthetic-only-password', PASSWORD_DEFAULT);
    check(password_verify('synthetic-only-password', $hash), 'Valid password rejected');
    check(!password_verify('wrong', $hash), 'Wrong password accepted');
    $canRead = fn(int $authenticatedUser, int $invoiceOwner): bool => $authenticatedUser === $invoiceOwner;
    check($canRead(7, 7) && !$canRead(7, 8), 'Authorization mismatch');
 },
 'routes' => function (): void { check(route('GET', '/health') === 200 && route('GET', '/missing') === 404 && route('POST', '/health') === 405, 'Route mismatch'); },
 'csrf' => function (): void {
    $expected = bin2hex(random_bytes(32));
    check(tokenValid($expected, $expected) && !tokenValid($expected, null) && !tokenValid($expected, 'wrong'), 'CSRF mismatch');
 },
 'queue' => function (): void {
    $db = new PDO('sqlite::memory:', null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $db->exec('CREATE TABLE ledger (job_key TEXT PRIMARY KEY, amount INTEGER NOT NULL)');
    $apply = function (string $key) use ($db): void {
       $db->beginTransaction();
       try {
          $q = $db->prepare('INSERT INTO ledger (job_key, amount) VALUES (:key, 100) ON CONFLICT(job_key) DO NOTHING');
          $q->execute(['key' => $key]); $db->commit();
       } catch (Throwable $error) { if ($db->inTransaction()) { $db->rollBack(); } throw $error; }
    };
    $apply('job-1'); $apply('job-1');
    check((int)$db->query('SELECT COUNT(*) FROM ledger')->fetchColumn() === 1, 'Duplicate applied');
    $apply('job-2');
    check((int)$db->query('SELECT COUNT(*) FROM ledger')->fetchColumn() === 2, 'Distinct key lost');
 }
];
$choice = $argv[1] ?? 'all';
if ($choice !== 'all' && !isset($tests[$choice])) { fwrite(STDERR, "Unknown fixture\n"); exit(2); }
foreach ($tests as $name => $test) { if ($choice === 'all' || $choice === $name) { $test(); echo "PASS $name\n"; } }
