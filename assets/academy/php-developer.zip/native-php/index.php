<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (!in_array($path, ['/', '/index.php'], true)) { http_response_code(404); echo json_encode(['error' => 'Not found']); }
else { echo json_encode(['status' => 'ok']); }
