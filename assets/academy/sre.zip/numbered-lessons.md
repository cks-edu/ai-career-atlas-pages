# Site Reliability Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Desired state: A controller compares the current system with a declared target and works to reconcile the difference.

SLI and SLO: A service-level indicator measures a user outcome; an objective sets an acceptable target over a defined window.

User-centered service indicators: An SLI measures a defined user outcome; an SLO sets its target over a window. Resource utilization helps diagnosis but is usually not the outcome promised to users.

### Desired state

A controller compares the current system with a declared target and works to reconcile the difference. In this role, work through: For 1000 valid requests and 5 service failures, availability is 99.5%. The practical workshop develops this into: Create a synthetic request log with status and latency. Define eligible requests, compute availability and explain whether client errors belong in the denominator for this service contract.

Mental model: A thermostat compares actual temperature with the set point.

Boundary: It cannot fix every cause: a missing image or insufficient resources still needs action.

Role application: Measure successful deliveries, not merely how busy the truck engine is.

An SLI measures a defined user outcome; an SLO sets its target over a window. Resource utilization helps diagnosis but is usually not the outcome promised to users.

Worked example: For 1000 valid requests and 5 service failures, availability is 99.5%.

Shared foundation example: One replica means the controller tries to keep one Pod running.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Kubernetes and Prometheus (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Site Reliability Engineer: For 1000 valid requests and 5 service failures, availability is 99.5%.

Predict the worked case

Read this case without running a tool: For 1000 valid requests and 5 service failures, availability is 99.5%. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in desired state.

Connect the concept to the role

Apply this rule: A controller compares the current system with a declared target and works to reconcile the difference. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: It cannot fix every cause: a missing image or insufficient resources still needs action.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies desired state to this case: For 1000 valid requests and 5 service failures, availability is 99.5%. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For 1000 valid requests and 5 service failures, availability is 99.5%. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Desired state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with desired state. Use the glossary below, then write your prediction for: For 1000 valid requests and 5 service failures, availability is 99.5%. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Site Reliability Engineer role interview. Explain desired state using this case: For 1000 valid requests and 5 service failures, availability is 99.5%. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate desired state to a system or workflow you know. Explain desired state using this case: For 1000 valid requests and 5 service failures, availability is 99.5%. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens when a Pod is deleted but its Deployment remains?

Interview: Explain desired state using this case: For 1000 valid requests and 5 service failures, availability is 99.5%. State the evidence, one alternative and where the mental model stops.

Quiz: After the User-centered service indicators rehearsal, check this foundation: A controller is told to run two replicas, but only one is ready. What does the declared target mean?

The controller attempts reconciliation; it is not a guarantee that both are healthy now.

Two healthy replicas must already exist.

The current replica count becomes the new desired target automatically.

Reference: The controller attempts reconciliation; it is not a guarantee that both are healthy now. — Desired and observed state differ during convergence or failure. Inspect readiness, events and constraints.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

### User-centered service indicators

An SLI measures a defined user outcome; an SLO sets its target over a window. Resource utilization helps diagnosis but is usually not the outcome promised to users. In this role, work through: For 1000 valid requests and 5 service failures, availability is 99.5%. The practical workshop develops this into: Create a synthetic request log with status and latency. Define eligible requests, compute availability and explain whether client errors belong in the denominator for this service contract.

Mental model: Measure successful deliveries, not merely how busy the truck engine is.

Boundary: Changing the denominator during an incident invalidates comparison; version the definition.

Worked example: For 1000 valid requests and 5 service failures, availability is 99.5%.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Kubernetes and Prometheus (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Site Reliability Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a synthetic request log with status and latency. Define eligible requests, compute availability and explain whether client errors belong in the denominator for this service contract.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

For 1000 valid requests and 5 service failures, availability is 99.5%. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a synthetic request log with status and latency. Define eligible requests, compute availability and explain whether client errors belong in the denominator for this service contract.

Expected: A reproducible 99.5% calculation and explicit eligibility rules.

Role workshop · debug and verify

Changing the denominator during an incident invalidates comparison; version the definition. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save SLI specification and calculation. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A reproducible 99.5% calculation and explicit eligibility rules.

Expected: A reproducible 99.5% calculation and explicit eligibility rules.

Troubleshoot: The role exercise differs from the prediction: Changing the denominator during an incident invalidates comparison; version the definition.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-beginner-2.md: SLI specification and calculation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with user-centered service indicators. Use the glossary below, then write your prediction for: For 1000 valid requests and 5 service failures, availability is 99.5%. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Site Reliability Engineer role interview. Explain user-centered service indicators using this case: For 1000 valid requests and 5 service failures, availability is 99.5%. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate user-centered service indicators to a system or workflow you know. Explain user-centered service indicators using this case: For 1000 valid requests and 5 service failures, availability is 99.5%. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Changing the denominator during an incident invalidates comparison; version the definition.

Interview: Explain user-centered service indicators using this case: For 1000 valid requests and 5 service failures, availability is 99.5%. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? For 1000 valid requests and 5 service failures, availability is 99.5%.

A reproducible 99.5% calculation and explicit eligibility rules.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A reproducible 99.5% calculation and explicit eligibility rules. — An SLI measures a defined user outcome; an SLO sets its target over a window. Resource utilization helps diagnosis but is usually not the outcome promised to users. A reproducible 99.5% calculation and explicit eligibility rules.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Readiness and routing: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.

Error budget: An error budget expresses the allowed unreliability implied by an objective and helps prioritize reliability versus change.

Budget burn and alert quality: An error budget is the allowed unreliability implied by an SLO. Burn rate compares actual error rate with the allowed rate; alert urgency depends on duration and user harm.

### Readiness and routing

Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. In this role, work through: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. The practical workshop develops this into: Calculate allowed and observed errors for two equal windows. Write a sustained-burn alert and a low-traffic caveat, then test the rule against a short spike and a sustained incident fixture.

Mental model: A shop can have lights on but still be closed to customers.

Boundary: A health endpoint can be too shallow; it must reflect the service contract.

Role application: A fuel gauge shows both remaining fuel and how quickly it is being consumed.

An error budget is the allowed unreliability implied by an SLO. Burn rate compares actual error rate with the allowed rate; alert urgency depends on duration and user harm.

Worked example: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate.

Shared foundation example: This container listens on 8080; the Service accepts 80 and forwards to 8080.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Kubernetes and Prometheus (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Site Reliability Engineer: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate.

Predict the worked case

Read this case without running a tool: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in readiness and routing.

Connect the concept to the role

Apply this rule: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A health endpoint can be too shallow; it must reflect the service contract.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies readiness and routing to this case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Readiness and routing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with readiness and routing. Use the glossary below, then write your prediction for: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Site Reliability Engineer role interview. Explain readiness and routing using this case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate readiness and routing to a system or workflow you know. Explain readiness and routing using this case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain why a Running Pod might still receive no traffic.

Interview: Explain readiness and routing using this case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. State the evidence, one alternative and where the mental model stops.

Quiz: After the Budget burn and alert quality rehearsal, check this foundation: A process listens on 8080. A Service accepts 80. Which target port should route to that listener?

80 because the Service port must equal the application port.

8080, matching the actual application listener.

443 because readiness always implies TLS.

Reference: 8080, matching the actual application listener. — Service and target ports can differ. Readiness must also reflect whether the workload can serve traffic.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

### Budget burn and alert quality

An error budget is the allowed unreliability implied by an SLO. Burn rate compares actual error rate with the allowed rate; alert urgency depends on duration and user harm. In this role, work through: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. The practical workshop develops this into: Calculate allowed and observed errors for two equal windows. Write a sustained-burn alert and a low-traffic caveat, then test the rule against a short spike and a sustained incident fixture.

Mental model: A fuel gauge shows both remaining fuel and how quickly it is being consumed.

Boundary: Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone.

Worked example: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Kubernetes and Prometheus (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Site Reliability Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Calculate allowed and observed errors for two equal windows. Write a sustained-burn alert and a low-traffic caveat, then test the rule against a short spike and a sustained incident fixture.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Calculate allowed and observed errors for two equal windows. Write a sustained-burn alert and a low-traffic caveat, then test the rule against a short spike and a sustained incident fixture.

Expected: The alert rationale distinguishes a transient spike from sustained impact.

Role workshop · debug and verify

Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save budget worksheet and alert test cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The alert rationale distinguishes a transient spike from sustained impact.

Expected: The alert rationale distinguishes a transient spike from sustained impact.

Troubleshoot: The role exercise differs from the prediction: Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-intermediate-2.md: budget worksheet and alert test cases; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with budget burn and alert quality. Use the glossary below, then write your prediction for: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Site Reliability Engineer role interview. Explain budget burn and alert quality using this case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate budget burn and alert quality to a system or workflow you know. Explain budget burn and alert quality using this case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone.

Interview: Explain budget burn and alert quality using this case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate.

Ignore the failing case and keep only the successful screenshot.

The alert rationale distinguishes a transient spike from sustained impact.

Treat any successful command as proof that all business and access rules passed.

Reference: The alert rationale distinguishes a transient spike from sustained impact. — An error budget is the allowed unreliability implied by an SLO. Burn rate compares actual error rate with the allowed rate; alert urgency depends on duration and user harm. The alert rationale distinguishes a transient spike from sustained impact.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Rollback and service objectives: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.

Incident command and learning: Restore service while preserving a timeline, clear ownership and evidence. Follow recovery with actions that reduce recurrence.

Incident command and recovery: Separate mitigation from causal analysis. Assign an incident lead, preserve timestamps and verify the original user operation before declaring recovery.

### Rollback and service objectives

A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. In this role, work through: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. The practical workshop develops this into: Rehearse the local rollout failure, keep a timeline, choose rollback and verify service. Write a blameless review with one prevention check and one detection improvement with owners.

Mental model: A reversible road detour with traffic counters at both ends.

Boundary: A rollback may not undo database changes; release safety includes schema compatibility.

Role application: An emergency team stabilizes the patient before investigating every contributing cause.

Separate mitigation from causal analysis. Assign an incident lead, preserve timestamps and verify the original user operation before declaring recovery.

Worked example: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions.

Shared foundation example: Change the image to a nonexistent tag, inspect events and undo the rollout.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Kubernetes and Prometheus (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Site Reliability Engineer: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions.

Predict the worked case

Read this case without running a tool: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in rollback and service objectives.

Connect the concept to the role

Apply this rule: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A rollback may not undo database changes; release safety includes schema compatibility.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies rollback and service objectives to this case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Rollback and service objectives; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rollback and service objectives. Use the glossary below, then write your prediction for: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Site Reliability Engineer role interview. Explain rollback and service objectives using this case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rollback and service objectives to a system or workflow you know. Explain rollback and service objectives using this case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks must pass after undoing a bad image?

Interview: Explain rollback and service objectives using this case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. State the evidence, one alternative and where the mental model stops.

Quiz: After the Incident command and recovery rehearsal, check this foundation: A rollout undo completes. What additional evidence establishes user recovery?

The deployment command exited zero, so no more checks are needed.

The old image tag exists in the registry.

A representative user operation succeeds and dependent state remains compatible.

Reference: A representative user operation succeeds and dependent state remains compatible. — Control-plane convergence does not verify the business path or reverse external state changes.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

### Incident command and recovery

Separate mitigation from causal analysis. Assign an incident lead, preserve timestamps and verify the original user operation before declaring recovery. In this role, work through: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. The practical workshop develops this into: Rehearse the local rollout failure, keep a timeline, choose rollback and verify service. Write a blameless review with one prevention check and one detection improvement with owners.

Mental model: An emergency team stabilizes the patient before investigating every contributing cause.

Boundary: A healthy dashboard without a working user request is insufficient recovery evidence.

Worked example: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Kubernetes and Prometheus (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Site Reliability Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Rehearse the local rollout failure, keep a timeline, choose rollback and verify service. Write a blameless review with one prevention check and one detection improvement with owners.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Rehearse a failed release

Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

Role workshop · predict

A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Rehearse the local rollout failure, keep a timeline, choose rollback and verify service. Write a blameless review with one prevention check and one detection improvement with owners.

Expected: A recovery proof and actionable follow-ups linked to observed evidence.

Role workshop · debug and verify

A healthy dashboard without a working user request is insufficient recovery evidence. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save incident timeline, postmortem and follow-up tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A recovery proof and actionable follow-ups linked to observed evidence.

Expected: A recovery proof and actionable follow-ups linked to observed evidence.

Troubleshoot: The role exercise differs from the prediction: A healthy dashboard without a working user request is insufficient recovery evidence.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-advanced-2.md: incident timeline, postmortem and follow-up tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with incident command and recovery. Use the glossary below, then write your prediction for: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Site Reliability Engineer role interview. Explain incident command and recovery using this case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate incident command and recovery to a system or workflow you know. Explain incident command and recovery using this case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A healthy dashboard without a working user request is insufficient recovery evidence.

Interview: Explain incident command and recovery using this case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A bad image is the trigger; missing release checks and weak alerting may be contributing conditions.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A recovery proof and actionable follow-ups linked to observed evidence.

Reference: A recovery proof and actionable follow-ups linked to observed evidence. — Separate mitigation from causal analysis. Assign an incident lead, preserve timestamps and verify the original user operation before declaring recovery. A recovery proof and actionable follow-ups linked to observed evidence.

Sources:

Google SRE book: https://sre.google/sre-book/table-of-contents/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/
