# Site Reliability Engineer

Software Engineering

Start with user-centered service indicators. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward incident timeline, postmortem and follow-up tests.

## beginner

Create a synthetic request log with status and latency. Define eligible requests, compute availability and explain whether client errors belong in the denominator for this service contract.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### User-centered service indicators
An SLI measures a defined user outcome; an SLO sets its target over a window. Resource utilization helps diagnosis but is usually not the outcome promised to users.
Mental model: Measure successful deliveries, not merely how busy the truck engine is.
Limit: Changing the denominator during an incident invalidates comparison; version the definition.
Example: For 1000 valid requests and 5 service failures, availability is 99.5%.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Changing the denominator during an incident invalidates comparison; version the definition.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
For 1000 valid requests and 5 service failures, availability is 99.5%. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a synthetic request log with status and latency. Define eligible requests, compute availability and explain whether client errors belong in the denominator for this service contract.
Expected: A reproducible 99.5% calculation and explicit eligibility rules.

6. Role workshop · debug and verify
Changing the denominator during an incident invalidates comparison; version the definition. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save SLI specification and calculation. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A reproducible 99.5% calculation and explicit eligibility rules.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
User-centered service indicators: Changing the denominator during an incident invalidates comparison; version the definition.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: SLI specification and calculation
A reproducible 99.5% calculation and explicit eligibility rules.

Interview: Work through this Site Reliability Engineer case: For 1000 valid requests and 5 service failures, availability is 99.5%. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An SLI measures a defined user outcome; an SLO sets its target over a window. Resource utilization helps diagnosis but is usually not the outcome promised to users. Expected evidence: A reproducible 99.5% calculation and explicit eligibility rules. Diagnosis: Changing the denominator during an incident invalidates comparison; version the definition. State the limits of the mental model: Measure successful deliveries, not merely how busy the truck engine is.

Resume: Built SLI specification and calculation using Kubernetes and Prometheus; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Calculate allowed and observed errors for two equal windows. Write a sustained-burn alert and a low-traffic caveat, then test the rule against a short spike and a sustained incident fixture.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Budget burn and alert quality
An error budget is the allowed unreliability implied by an SLO. Burn rate compares actual error rate with the allowed rate; alert urgency depends on duration and user harm.
Mental model: A fuel gauge shows both remaining fuel and how quickly it is being consumed.
Limit: Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone.
Example: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Calculate allowed and observed errors for two equal windows. Write a sustained-burn alert and a low-traffic caveat, then test the rule against a short spike and a sustained incident fixture.
Expected: The alert rationale distinguishes a transient spike from sustained impact.

6. Role workshop · debug and verify
Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save budget worksheet and alert test cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The alert rationale distinguishes a transient spike from sustained impact.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Budget burn and alert quality: Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: budget worksheet and alert test cases
The alert rationale distinguishes a transient spike from sustained impact.

Interview: Work through this Site Reliability Engineer case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An error budget is the allowed unreliability implied by an SLO. Burn rate compares actual error rate with the allowed rate; alert urgency depends on duration and user harm. Expected evidence: The alert rationale distinguishes a transient spike from sustained impact. Diagnosis: Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone. State the limits of the mental model: A fuel gauge shows both remaining fuel and how quickly it is being consumed.

Resume: Built budget worksheet and alert test cases using Kubernetes and Prometheus; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Rehearse the local rollout failure, keep a timeline, choose rollback and verify service. Write a blameless review with one prevention check and one detection improvement with owners.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Incident command and recovery
Separate mitigation from causal analysis. Assign an incident lead, preserve timestamps and verify the original user operation before declaring recovery.
Mental model: An emergency team stabilizes the patient before investigating every contributing cause.
Limit: A healthy dashboard without a working user request is insufficient recovery evidence.
Example: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A healthy dashboard without a working user request is insufficient recovery evidence.

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Role workshop · predict
A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Rehearse the local rollout failure, keep a timeline, choose rollback and verify service. Write a blameless review with one prevention check and one detection improvement with owners.
Expected: A recovery proof and actionable follow-ups linked to observed evidence.

6. Role workshop · debug and verify
A healthy dashboard without a working user request is insufficient recovery evidence. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save incident timeline, postmortem and follow-up tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A recovery proof and actionable follow-ups linked to observed evidence.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Incident command and recovery: A healthy dashboard without a working user request is insufficient recovery evidence.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: incident timeline, postmortem and follow-up tests
A recovery proof and actionable follow-ups linked to observed evidence.

Interview: Work through this Site Reliability Engineer case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Separate mitigation from causal analysis. Assign an incident lead, preserve timestamps and verify the original user operation before declaring recovery. Expected evidence: A recovery proof and actionable follow-ups linked to observed evidence. Diagnosis: A healthy dashboard without a working user request is insufficient recovery evidence. State the limits of the mental model: An emergency team stabilizes the patient before investigating every contributing cause.

Resume: Built incident timeline, postmortem and follow-up tests using Kubernetes and Prometheus; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Google SRE book: https://sre.google/sre-book/table-of-contents/
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
