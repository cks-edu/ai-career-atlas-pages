# Site Reliability Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
User-centered service indicators

An SLI measures a defined user outcome; an SLO sets its target over a window. Resource utilization helps diagnosis but is usually not the outcome promised to users.
Mental model: Measure successful deliveries, not merely how busy the truck engine is.
Case: For 1000 valid requests and 5 service failures, availability is 99.5%.
Task: Create a synthetic request log with status and latency. Define eligible requests, compute availability and explain whether client errors belong in the denominator for this service contract.
Acceptance: A reproducible 99.5% calculation and explicit eligibility rules.
Troubleshooting: Changing the denominator during an incident invalidates comparison; version the definition.
Deliverable: SLI specification and calculation

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Budget burn and alert quality

An error budget is the allowed unreliability implied by an SLO. Burn rate compares actual error rate with the allowed rate; alert urgency depends on duration and user harm.
Mental model: A fuel gauge shows both remaining fuel and how quickly it is being consumed.
Case: At a 99.9% SLO, 1% errors consume budget at 10 times the allowed rate.
Task: Calculate allowed and observed errors for two equal windows. Write a sustained-burn alert and a low-traffic caveat, then test the rule against a short spike and a sustained incident fixture.
Acceptance: The alert rationale distinguishes a transient spike from sustained impact.
Troubleshooting: Low request counts make ratios noisy; inspect counts and user impact instead of trusting a percentage alone.
Deliverable: budget worksheet and alert test cases

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Incident command and recovery

Separate mitigation from causal analysis. Assign an incident lead, preserve timestamps and verify the original user operation before declaring recovery.
Mental model: An emergency team stabilizes the patient before investigating every contributing cause.
Case: A bad image is the trigger; missing release checks and weak alerting may be contributing conditions.
Task: Rehearse the local rollout failure, keep a timeline, choose rollback and verify service. Write a blameless review with one prevention check and one detection improvement with owners.
Acceptance: A recovery proof and actionable follow-ups linked to observed evidence.
Troubleshooting: A healthy dashboard without a working user request is insufficient recovery evidence.
Deliverable: incident timeline, postmortem and follow-up tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
