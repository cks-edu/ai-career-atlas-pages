## advanced — Knowledge lifecycle tests

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Knowledge lifecycle tests
Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content.
Mental model: A map service needs road-closure updates as well as initial surveying.
Boundary: A successful retrieval pilot does not establish answer-generation correctness.
Worked example: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Governed enterprise knowledge lifecycle
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. Build a review register and a change-propagation demonstration: update one document, retire another and show search results reflect the approved version.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.
Worked example: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Recall: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. Identify one observation that would contradict your claim.

### Terms
Knowledge lifecycle tests: Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

2. Prepare the project inputs
Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Build a review register and a change-propagation demonstration: update one document, retire another and show search results reflect the approved version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
No such module fts5: use a Python build linked to SQLite with FTS5.
No results: inspect tenant, source text and literal query phrase.
Deletion leak: inspect caches and derived chunks as well as source records.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

### Portfolio
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current.
Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.
Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Build a review register and a change-propagation demonstration: update one document, retire another and show search results reflect the approved version.
An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.
Add access-aware retrieval and test a revoked audience permission.
Deliverables: Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo; Freshness/conflict review procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A reviewer must reproduce one result and identify which capabilities you implemented. An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.

### Interview
Explain your advanced solution for Enterprise AI knowledge architect. Use this scenario: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Review: Start with the task and permitted scope. Explain knowledge lifecycle tests: Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content. Show the input and observed output, then address Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo; Freshness/conflict review procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

