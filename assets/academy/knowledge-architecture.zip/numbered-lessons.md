# Enterprise AI knowledge architect — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Knowledge ownership: Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Knowledge ownership

Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface. In this role, work through: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A library distinguishes current policy books from historical commentary.

Boundary: A document title or internal location does not prove authority.

Worked example: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: SQLite FTS5 (Public domain · local); diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Enterprise AI knowledge architect: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid.

Predict the worked case

Read this case without running a tool: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in knowledge ownership.

Connect the concept to the role

Apply this rule: Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A document title or internal location does not prove authority.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies knowledge ownership to this case: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Knowledge ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with knowledge ownership. Use the glossary below, then write your prediction for: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Enterprise AI knowledge architect role interview. Explain knowledge ownership using this case: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate knowledge ownership to a system or workflow you know. Explain knowledge ownership using this case: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain knowledge ownership using this case: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid.

Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface. — Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface. A document title or internal location does not prove authority.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Diagnose: Two policies claim to be current

The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Three topics have unresolved authority conflicts; retrieval cannot decide which policy governs. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Assign an owner, resolve effective dates and retire or clearly scope conflicting versions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A library distinguishes current policy books from historical commentary.

Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid.

Worked example: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Assign an owner, resolve effective dates and retire or clearly scope conflicting versions.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: SQLite FTS5 (Public domain · local); diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Three topics have unresolved authority conflicts; retrieval cannot decide which policy governs. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Apply this toy-case rule manually: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A knowledge source needs an owner and a current version. Search quality depends on what information is available and authoritative.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Create an inventory for a 2024 handbook saying loans last 7 days and a 2026 policy saying 14 days. Give each a title, date, owner and status.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A document inventory and conflict-resolution note.

Preparation · Try step 2

Flag the conflict and write the question you would ask the policy owner.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A document inventory and conflict-resolution note.

Preparation · Try step 3

Describe how an outdated document would be labeled or excluded after the owner confirms the applicable rule.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A document inventory and conflict-resolution note.

Preparation · Explain and check your result

You do not assume newer always means authoritative; the responsible owner confirms scope and validity. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A document inventory and conflict-resolution note. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Apply this toy-case rule manually: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three topics have unresolved authority conflicts; retrieval cannot decide which policy governs. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three topics have unresolved authority conflicts; retrieval cannot decide which policy governs. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: two policies claim to be current. Use the glossary below, then write your prediction for: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Assign an owner, resolve effective dates and retire or clearly scope conflicting versions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Enterprise AI knowledge architect role interview. Explain diagnose: two policies claim to be current using this case: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Assign an owner, resolve effective dates and retire or clearly scope conflicting versions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: two policies claim to be current to a system or workflow you know. Explain diagnose: two policies claim to be current using this case: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Assign an owner, resolve effective dates and retire or clearly scope conflicting versions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Search for the same question under different dates and permissions after the correction. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: two policies claim to be current using this case: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Assign an owner, resolve effective dates and retire or clearly scope conflicting versions. State the evidence, one alternative and where the mental model stops.

Quiz: Two policies claim to be current: The knowledge workflow flags any topic with more than one conflicting active authoritative policy.

Change the acceptance rule after seeing an inconvenient result.

Assign an owner, resolve effective dates and retire or clearly scope conflicting versions.

Omit failed cases and report only the successful demonstrations.

Reference: Assign an owner, resolve effective dates and retire or clearly scope conflicting versions. — Assign an owner, resolve effective dates and retire or clearly scope conflicting versions. Search for the same question under different dates and permissions after the correction.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Taxonomy, ownership and content lifecycle skills; technical implementations add SQL, APIs and retrieval.

Terms:

Information structure: Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Information structure

Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content. In this role, work through: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Street names and house numbers make a city navigable.

Boundary: Taxonomies need maintenance and may reflect the organization's blind spots.

Worked example: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Taxonomy, ownership and content lifecycle skills; technical implementations add SQL, APIs and retrieval.

Tools for this exercise: Document or text editor

Course tool and framework map: SQLite FTS5 (Public domain · local); diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Enterprise AI knowledge architect: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments.

Predict the worked case

Read this case without running a tool: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in information structure.

Connect the concept to the role

Apply this rule: Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Taxonomies need maintenance and may reflect the organization's blind spots.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies information structure to this case: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Information structure; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with information structure. Use the glossary below, then write your prediction for: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Enterprise AI knowledge architect role interview. Explain information structure using this case: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate information structure to a system or workflow you know. Explain information structure using this case: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain information structure using this case: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments.

Treat a passing starter as proof of the whole role workflow.

Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content.

Ignore the failure because the tool produced an output.

Reference: Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content. — Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content. Taxonomies need maintenance and may reflect the organization's blind spots.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Integrate: Governed enterprise knowledge lifecycle

Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition. In this role, work through: Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Role application: Street names and house numbers make a city navigable.

Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments.

Worked example: Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.

Setup: Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQLite FTS5 (Public domain · local); diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed)

Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Design and demonstrate how knowledge owners keep an AI corpus authoritative and current.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

Prepare the project inputs

Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Deliverable: lesson-intermediate-2.md: Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: governed enterprise knowledge lifecycle. Use the glossary below, then write your prediction for: Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Enterprise AI knowledge architect role interview. Explain integrate: governed enterprise knowledge lifecycle using this case: Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: governed enterprise knowledge lifecycle to a system or workflow you know. Explain integrate: governed enterprise knowledge lifecycle using this case: Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. Identify one observation that would contradict your claim.

Interview: Explain integrate: governed enterprise knowledge lifecycle using this case: Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Governed enterprise knowledge lifecycle at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.

Reference: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. — Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Knowledge lifecycle tests: Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Knowledge lifecycle tests

Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content. In this role, work through: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A map service needs road-closure updates as well as initial surveying.

Boundary: A successful retrieval pilot does not establish answer-generation correctness.

Worked example: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: SQLite FTS5 (Public domain · local); diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Enterprise AI knowledge architect: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version.

Predict the worked case

Read this case without running a tool: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in knowledge lifecycle tests.

Connect the concept to the role

Apply this rule: Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A successful retrieval pilot does not establish answer-generation correctness.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies knowledge lifecycle tests to this case: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Knowledge lifecycle tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with knowledge lifecycle tests. Use the glossary below, then write your prediction for: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Enterprise AI knowledge architect role interview. Explain knowledge lifecycle tests using this case: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate knowledge lifecycle tests to a system or workflow you know. Explain knowledge lifecycle tests using this case: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain knowledge lifecycle tests using this case: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content.

Reference: Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content. — Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content. A successful retrieval pilot does not establish answer-generation correctness.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Defend: Governed enterprise knowledge lifecycle

Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. Build a review register and a change-propagation demonstration: update one document, retire another and show search results reflect the approved version. In this role, work through: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Role application: A map service needs road-closure updates as well as initial surveying.

Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version.

Worked example: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.

Setup: Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQLite FTS5 (Public domain · local); diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed)

Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

Design and demonstrate how knowledge owners keep an AI corpus authoritative and current.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

Prepare the project inputs

Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Build a review register and a change-propagation demonstration: update one document, retire another and show search results reflect the approved version.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A reviewer must reproduce one result and identify which capabilities you implemented. An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Deliverable: lesson-advanced-2.md: Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo; Freshness/conflict review procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: governed enterprise knowledge lifecycle. Use the glossary below, then write your prediction for: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Enterprise AI knowledge architect role interview. Explain defend: governed enterprise knowledge lifecycle using this case: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: governed enterprise knowledge lifecycle to a system or workflow you know. Explain defend: governed enterprise knowledge lifecycle using this case: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. Identify one observation that would contradict your claim.

Interview: Explain defend: governed enterprise knowledge lifecycle using this case: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Governed enterprise knowledge lifecycle at this level?

An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed. — An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed. Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.

Sources:

SQLite FTS5: https://www.sqlite.org/fts5.html

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

pgvector: https://github.com/pgvector/pgvector

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
