# Governed enterprise knowledge lifecycle

Career: Enterprise AI knowledge architect
Reviewed: 2026-10-22

Design and demonstrate how knowledge owners keep an AI corpus authoritative and current.

## Prerequisites
Taxonomy, ownership and content lifecycle skills; technical implementations add SQL, APIs and retrieval.

## Included starter versus your implementation
An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter.

```sh
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Build a review register and a change-propagation demonstration: update one document, retire another and show search results reflect the approved version.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Knowledge taxonomy and ownership register — artifact-1.md
2. Lifecycle architecture and working search demo — artifact-2.md
3. Freshness/conflict review procedure — artifact-3.md

## Troubleshooting
- No such module fts5: use a Python build linked to SQLite with FTS5.
- No results: inspect tenant, source text and literal query phrase.
- Deletion leak: inspect caches and derived chunks as well as source records.

## Extension
Add access-aware retrieval and test a revoked audience permission.

## Primary learning resources
- SQLite FTS5: https://www.sqlite.org/fts5.html — Public domain · local; Full-text retrieval with explicit tenant filtering.
- diagrams.net: https://www.drawio.com/docs/getting-started/ — Open source editor · browser/desktop; Architecture diagrams, process maps and trust boundaries.
- LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html — Open source · no account needed; Import CSV evidence, build review registers and calculate summaries.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
