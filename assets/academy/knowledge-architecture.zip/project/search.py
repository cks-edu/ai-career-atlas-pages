"""Local FTS5 retrieval with tenant scope applied before results leave the DB."""
import json, sqlite3
from pathlib import Path

def database():
    db=sqlite3.connect(':memory:')
    db.execute('CREATE VIRTUAL TABLE docs USING fts5(id UNINDEXED, tenant UNINDEXED, text)')
    rows=json.loads(Path('documents.json').read_text())
    db.executemany('INSERT INTO docs VALUES (:id,:tenant,:text)',rows)
    return db

def search(db,tenant,query):
    if not tenant or not query.strip(): return []
    # A literal phrase avoids interpreting user input as arbitrary FTS operators.
    phrase='"'+query.replace('"','""')+'"'
    return db.execute('SELECT id,text FROM docs WHERE docs MATCH ? AND tenant=? ORDER BY rank LIMIT 5',(phrase,tenant)).fetchall()

if __name__=='__main__':
    with database() as db: print(json.dumps(search(db,'alpha','travel'),indent=2))
