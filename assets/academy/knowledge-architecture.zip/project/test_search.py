import unittest
from search import database,search
class RetrievalTests(unittest.TestCase):
    def setUp(self): self.db=database()
    def tearDown(self): self.db.close()
    def test_scope(self): self.assertEqual([r[0] for r in search(self.db,'alpha','travel')],['a1'])
    def test_unknown_tenant(self): self.assertEqual(search(self.db,'unknown','travel'),[])
    def test_delete(self):
        self.db.execute('DELETE FROM docs WHERE id=?',('a1',))
        self.assertEqual(search(self.db,'alpha','travel'),[])
    def test_literal_input(self): self.assertEqual(search(self.db,'alpha','travel OR confidential'),[])
if __name__=='__main__': unittest.main()
