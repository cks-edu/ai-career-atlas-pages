# Governed enterprise knowledge lifecycle

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.

## Limitations and next iteration
Add access-aware retrieval and test a revoked audience permission.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
