# Enterprise AI knowledge architect

AI Engineering · Beginner → Intermediate → Advanced

Start with Knowledge ownership. A knowledge source needs an owner and a current version. Search quality depends on what information is available and authoritative. Then try Resolve a fictional policy conflict. The three levels build toward Governed enterprise knowledge lifecycle. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Knowledge ownership

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Knowledge ownership
Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface.
Mental model: A library distinguishes current policy books from historical commentary.
Boundary: A document title or internal location does not prove authority.
Worked example: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Two policies claim to be current
The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Three topics have unresolved authority conflicts; retrieval cannot decide which policy governs. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Assign an owner, resolve effective dates and retire or clearly scope conflicting versions.
Recall: Search for the same question under different dates and permissions after the correction. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Knowledge ownership: Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A knowledge source needs an owner and a current version. Search quality depends on what information is available and authoritative.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Create an inventory for a 2024 handbook saying loans last 7 days and a 2026 policy saying 14 days. Give each a title, date, owner and status.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A document inventory and conflict-resolution note.

3. Try step 2
Flag the conflict and write the question you would ask the policy owner.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A document inventory and conflict-resolution note.

4. Try step 3
Describe how an outdated document would be labeled or excluded after the owner confirms the applicable rule.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A document inventory and conflict-resolution note.

5. Explain and check your result
You do not assume newer always means authoritative; the responsible owner confirms scope and validity. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A document inventory and conflict-resolution note. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Apply this toy-case rule manually: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three topics have unresolved authority conflicts; retrieval cannot decide which policy governs. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Enterprise AI knowledge architect.
Create an inventory for a 2024 handbook saying loans last 7 days and a 2026 policy saying 14 days. Give each a title, date, owner and status.
Flag the conflict and write the question you would ask the policy owner.
Describe how an outdated document would be labeled or excluded after the owner confirms the applicable rule.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A document inventory and conflict-resolution note. Include beginner-worksheet.md and your completed Knowledge authority register and lifecycle plan.
Check: You do not assume newer always means authoritative; the responsible owner confirms scope and validity.

### Interview
Explain your beginner solution for Enterprise AI knowledge architect. Use this scenario: The knowledge workflow flags any topic with more than one conflicting active authoritative policy.
Review: Start with the task and permitted scope. Explain knowledge ownership: Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface. Show the input and observed output, then address Assign an owner, resolve effective dates and retire or clearly scope conflicting versions. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A document inventory and conflict-resolution note. Include beginner-worksheet.md and your completed Knowledge authority register and lifecycle plan.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Information structure

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Taxonomy, ownership and content lifecycle skills; technical implementations add SQL, APIs and retrieval.

### Information structure
Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content.
Mental model: Street names and house numbers make a city navigable.
Boundary: Taxonomies need maintenance and may reflect the organization's blind spots.
Worked example: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Governed enterprise knowledge lifecycle
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.
Worked example: Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Recall: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. Identify one observation that would contradict your claim.

### Terms
Information structure: Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

2. Prepare the project inputs
Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
No such module fts5: use a Python build linked to SQLite with FTS5.
No results: inspect tenant, source text and literal query phrase.
Deletion leak: inspect caches and derived chunks as well as source records.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

### Portfolio
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current.
Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.
Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.
Deliverables: Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Enterprise AI knowledge architect. Use this scenario: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Review: Start with the task and permitted scope. Explain information structure: Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content. Show the input and observed output, then address Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Knowledge lifecycle tests

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Knowledge lifecycle tests
Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content.
Mental model: A map service needs road-closure updates as well as initial surveying.
Boundary: A successful retrieval pilot does not establish answer-generation correctness.
Worked example: Retire policy v1, index v2 and verify a query returns v2 while an unauthorized user sees neither restricted version.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Governed enterprise knowledge lifecycle
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. Build a review register and a change-propagation demonstration: update one document, retire another and show search results reflect the approved version.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.
Worked example: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Recall: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. Identify one observation that would contradict your claim.

### Terms
Knowledge lifecycle tests: Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

2. Prepare the project inputs
Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Build a review register and a change-propagation demonstration: update one document, retire another and show search results reflect the approved version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
No such module fts5: use a Python build linked to SQLite with FTS5.
No results: inspect tenant, source text and literal query phrase.
Deletion leak: inspect caches and derived chunks as well as source records.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

### Portfolio
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current.
Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.
Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Build a review register and a change-propagation demonstration: update one document, retire another and show search results reflect the approved version.
An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.
Add access-aware retrieval and test a revoked audience permission.
Deliverables: Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo; Freshness/conflict review procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A reviewer must reproduce one result and identify which capabilities you implemented. An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.

### Interview
Explain your advanced solution for Enterprise AI knowledge architect. Use this scenario: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Review: Start with the task and permitted scope. Explain knowledge lifecycle tests: Test permission-aware retrieval, stale-source handling and updates with representative questions. Give source owners a way to correct or retire content. Show the input and observed output, then address Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo; Freshness/conflict review procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
SQLite FTS5 — Public domain · local
Full-text retrieval with explicit tenant filtering.
Alternative: PostgreSQL full-text search (open source); compare deployment effort, concurrency and language processing.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

diagrams.net — Open source editor · browser/desktop
Architecture diagrams, process maps and trust boundaries.
Alternative: Mermaid (open source) for text diagrams or Microsoft Visio (commercial); choose an editable format teammates can use.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
SQLite FTS5: https://www.sqlite.org/fts5.html
diagrams.net: https://www.drawio.com/docs/getting-started/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
pgvector: https://github.com/pgvector/pgvector
PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
