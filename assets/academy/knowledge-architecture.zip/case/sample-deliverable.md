# SAMPLE — Knowledge authority register and lifecycle plan
Role: Enterprise AI knowledge architect
Case: Two policies claim to be current
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The knowledge workflow flags any topic with more than one conflicting active authoritative policy.

## Evidence table
| Record | active_conflicts (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three topics have unresolved authority conflicts; retrieval cannot decide which policy governs.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Assign an owner, resolve effective dates and retire or clearly scope conflicting versions.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in enterprise ai knowledge architect.
Before release: Search for the same question under different dates and permissions after the correction.

## Design choice and trade-off
Carry authority, effective date and owner metadata into retrieval; expose unresolved conflicts.
Better embeddings cannot resolve an organizational authority dispute without source governance.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Knowledge governance map: Conflicts have an escalation and retirement process.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
