## intermediate — Information structure

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Taxonomy, ownership and content lifecycle skills; technical implementations add SQL, APIs and retrieval.

### Information structure
Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content.
Mental model: Street names and house numbers make a city navigable.
Boundary: Taxonomies need maintenance and may reflect the organization's blind spots.
Worked example: Attach product, jurisdiction and effective date to a policy passage, and link its exceptions rather than leaving isolated fragments.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Governed enterprise knowledge lifecycle
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.
Worked example: Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Recall: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. Identify one observation that would contradict your claim.

### Terms
Information structure: Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current. An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them. Local CPU baseline is small; PostgreSQL/pgvector and embeddings require separate setup and model/license choices.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ with SQLite FTS5 support; no model or external database is needed for the starter. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python search.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An in-memory SQLite FTS5 search with three fictional documents, scoped retrieval and deletion tests. You add ingestion, lifecycle metadata, vector retrieval and generation if the plan calls for them.

2. Prepare the project inputs
Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
No such module fts5: use a Python build linked to SQLite with FTS5.
No results: inspect tenant, source text and literal query phrase.
Deletion leak: inspect caches and derived chunks as well as source records.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The baseline database is in memory and closes on exit. Remove any optional database service only after exporting your evidence.

### Portfolio
Design and demonstrate how knowledge owners keep an AI corpus authoritative and current.
Create 30 fictional documents with owner, authority level, audience, review date and superseded-by fields. Include conflicting policies and expired sources.
Run the retrieval starter and add lifecycle metadata. Define which source wins in a conflict and which content must be withheld pending review.
Draw ingestion, validation, indexing, retrieval and retirement flows. Assign a responsible owner and measurable check at each transition.
Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority.
Deliverables: Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Enterprise AI knowledge architect. Use this scenario: An authoritative source is retired while a copied derivative remains searchable. Trace and remove the derivative or mark it invalid until reviewed.
Review: Start with the task and permitted scope. Explain information structure: Organize concepts, identifiers and relationships so users and retrieval systems can find the right context. Preserve meaning when splitting or linking content. Show the input and observed output, then address Report ownership coverage, stale documents, conflict resolution and update lag. Search relevance alone does not establish knowledge authority. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Knowledge taxonomy and ownership register; Lifecycle architecture and working search demo. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

