## beginner — Knowledge ownership

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Knowledge ownership
Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface.
Mental model: A library distinguishes current policy books from historical commentary.
Boundary: A document title or internal location does not prove authority.
Worked example: Two refund documents conflict; identify the current authoritative owner and version instead of indexing both as equally valid.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Two policies claim to be current
The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Three topics have unresolved authority conflicts; retrieval cannot decide which policy governs. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Assign an owner, resolve effective dates and retire or clearly scope conflicting versions.
Recall: Search for the same question under different dates and permissions after the correction. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Knowledge ownership: Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A knowledge source needs an owner and a current version. Search quality depends on what information is available and authoritative.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Create an inventory for a 2024 handbook saying loans last 7 days and a 2026 policy saying 14 days. Give each a title, date, owner and status.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A document inventory and conflict-resolution note.

3. Try step 2
Flag the conflict and write the question you would ask the policy owner.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A document inventory and conflict-resolution note.

4. Try step 3
Describe how an outdated document would be labeled or excluded after the owner confirms the applicable rule.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A document inventory and conflict-resolution note.

5. Explain and check your result
You do not assume newer always means authoritative; the responsible owner confirms scope and validity. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A document inventory and conflict-resolution note. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The knowledge workflow flags any topic with more than one conflicting active authoritative policy. Apply this toy-case rule manually: Review when active_conflicts >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three topics have unresolved authority conflicts; retrieval cannot decide which policy governs. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Enterprise AI knowledge architect.
Create an inventory for a 2024 handbook saying loans last 7 days and a 2026 policy saying 14 days. Give each a title, date, owner and status.
Flag the conflict and write the question you would ask the policy owner.
Describe how an outdated document would be labeled or excluded after the owner confirms the applicable rule.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A document inventory and conflict-resolution note. Include beginner-worksheet.md and your completed Knowledge authority register and lifecycle plan.
Check: You do not assume newer always means authoritative; the responsible owner confirms scope and validity.

### Interview
Explain your beginner solution for Enterprise AI knowledge architect. Use this scenario: The knowledge workflow flags any topic with more than one conflicting active authoritative policy.
Review: Start with the task and permitted scope. Explain knowledge ownership: Inventory sources by purpose, owner, freshness, authority and access. Decide which source should answer a question before building a search interface. Show the input and observed output, then address Assign an owner, resolve effective dates and retire or clearly scope conflicting versions. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A document inventory and conflict-resolution note. Include beginner-worksheet.md and your completed Knowledge authority register and lifecycle plan.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

