# Java Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Types and contracts: A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on.

Apply types and contracts in Java Developer: Use the concept to complete this role exercise: Run the Java title validator and explain types and exceptions

Value objects and exceptions: Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass.

### Values, types and expressions

Java variables have declared types. A type determines the values and operations permitted. Learn integer and decimal arithmetic before relying on the result of a calculation.

How it works
Dividing two int values performs integer division. Converting an operand to double changes the arithmetic. String equality compares content with equals rather than reference identity with ==.

Where the model stops
double is binary floating point and is not exact decimal accounting. Integer arithmetic can overflow.

Make one change
Calculate an average for three integer inputs. Test the empty-count case before division and compare integer and floating-point results.

Mental model: A typed variable is a labelled container; the label constrains what can be put inside.

Boundary: double is binary floating point and is not exact decimal accounting. Integer arithmetic can overflow.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
int total = 5, count = 2;
check(total / count == 2);
check(total / (double) count == 2.5);
String title = new String("Read");
check(title.equals("Read"));
 System.out.println("PASS: java-values");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/beginner/java-values. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Calculate an average for three integer inputs. Test the empty-count case before division and compare integer and floating-point results.

Terminal folder: course-labs/beginner/java-values

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. Dividing two int values performs integer division. Converting an operand to double changes the arithmetic. String equality compares content with equals rather than reference identity with ==.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/java-values. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Checks confirm integer division gives 2 and decimal division gives 2.5. Your zero-count input has an explicit policy.

Build your change

Calculate an average for three integer inputs. Test the empty-count case before division and compare integer and floating-point results.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Checks confirm integer division gives 2 and decimal division gives 2.5. Your zero-count input has an explicit policy.

Break, repair and explain

Deliberately violate this boundary: double is binary floating point and is not exact decimal accounting. Integer arithmetic can overflow. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Checks confirm integer division gives 2 and decimal division gives 2.5. Your zero-count input has an explicit policy.

Troubleshoot: My result does not match Values, types and expressions: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Dividing two int values performs integer division. Converting an operand to double changes the arithmetic. String equality compares content with equals rather than reference identity with ==. Then inspect this limit: double is binary floating point and is not exact decimal accounting. Integer arithmetic can overflow. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/java-values/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Values, types and expressions line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A typed variable is a labelled container; the label constrains what can be put inside.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: What is 5 / 2 when both operands are int? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: double is binary floating point and is not exact decimal accounting. Integer arithmetic can overflow. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What is 5 / 2 when both operands are int?

Interview: What is 5 / 2 when both operands are int? Defend your answer using your actual lab result and this boundary: double is binary floating point and is not exact decimal accounting. Integer arithmetic can overflow.

Quiz: What is 5 / 2 when both operands are int?

2.5

2

A String

Reference: 2 — Java integer division discards the fractional part toward zero. Cast before the division when a floating-point result is intended.

Sources:

dev.java: learn Java: https://dev.java/learn/

### Conditions and loops: make decisions explicit

A condition chooses a path; a loop repeats work. Use them to express a small business rule in a form you can trace by hand.

How it works
A for-each loop reads each element. The if condition includes only nonblank titles. isBlank treats whitespace-only text as blank; null must be handled before calling a method.

Where the model stops
This sample assumes the list itself is present. Decide null handling at the input boundary rather than scattering guesses through every loop.

Make one change
Collect the valid trimmed titles into a new list. Test an empty list and prove the original list is unchanged.

Mental model: A checklist applies the same decision to each item in a tray.

Boundary: This sample assumes the list itself is present. Decide null handling at the input boundary rather than scattering guesses through every loop.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
List<String> titles = Arrays.asList("Read", " ", null, "Build");
int valid = 0;
for (String title : titles) { if (title != null && !title.isBlank()) valid++; }
check(valid == 2);
 System.out.println("PASS: java-branches");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/beginner/java-branches. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Collect the valid trimmed titles into a new list. Test an empty list and prove the original list is unchanged.

Terminal folder: course-labs/beginner/java-branches

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. A for-each loop reads each element. The if condition includes only nonblank titles. isBlank treats whitespace-only text as blank; null must be handled before calling a method.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/java-branches. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Exactly two titles pass. Your output list contains Read and Build, with empty input returning an empty result.

Build your change

Collect the valid trimmed titles into a new list. Test an empty list and prove the original list is unchanged.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Exactly two titles pass. Your output list contains Read and Build, with empty input returning an empty result.

Break, repair and explain

Deliberately violate this boundary: This sample assumes the list itself is present. Decide null handling at the input boundary rather than scattering guesses through every loop. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Exactly two titles pass. Your output list contains Read and Build, with empty input returning an empty result.

Troubleshoot: My result does not match Conditions and loops: make decisions explicit: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: A for-each loop reads each element. The if condition includes only nonblank titles. isBlank treats whitespace-only text as blank; null must be handled before calling a method. Then inspect this limit: This sample assumes the list itself is present. Decide null handling at the input boundary rather than scattering guesses through every loop. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/java-branches/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Conditions and loops: make decisions explicit line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A checklist applies the same decision to each item in a tray.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: Why put title != null before !title.isBlank() with &&? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This sample assumes the list itself is present. Decide null handling at the input boundary rather than scattering guesses through every loop. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why put title != null before !title.isBlank() with &&?

Interview: Why put title != null before !title.isBlank() with &&? Defend your answer using your actual lab result and this boundary: This sample assumes the list itself is present. Decide null handling at the input boundary rather than scattering guesses through every loop.

Quiz: Why put title != null before !title.isBlank() with &&?

Short-circuit evaluation avoids calling a method on null.

It sorts the list.

It catches every exception.

Reference: Short-circuit evaluation avoids calling a method on null. — The right operand is evaluated only when the left is true. This prevents this specific null dereference.

Sources:

dev.java: learn Java: https://dev.java/learn/

### Methods: name a reusable rule

A method packages a behaviour behind a name and parameter list. Keep validation rules small so callers do not each implement a subtly different version.

How it works
The local class defines a static method that trims and rejects blank titles. Throwing IllegalArgumentException makes the rejected input visible to the caller. The result contains only validated data.

Where the model stops
A method name does not guarantee purity. Document whether it changes state or performs I/O.

Make one change
Add an 80-character limit and test 80, 81 and null. Give the method one responsibility instead of also saving to a file.

Mental model: A named recipe lets several cooks follow the same measured steps.

Boundary: A method name does not guarantee purity. Document whether it changes state or performs I/O.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
class Titles { static String clean(String value) {
 if (value == null || value.isBlank()) throw new IllegalArgumentException("Title required");
 return value.strip();
} }
check(Titles.clean(" Read ").equals("Read"));
boolean rejected = false;
try { Titles.clean(" "); } catch (IllegalArgumentException e) { rejected = true; }
check(rejected);
 System.out.println("PASS: java-methods");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/beginner/java-methods. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add an 80-character limit and test 80, 81 and null. Give the method one responsibility instead of also saving to a file.

Terminal folder: course-labs/beginner/java-methods

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. The local class defines a static method that trims and rejects blank titles. Throwing IllegalArgumentException makes the rejected input visible to the caller. The result contains only validated data.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/java-methods. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The clean value is Read and blank input is rejected. Your boundary tests distinguish the exact maximum.

Build your change

Add an 80-character limit and test 80, 81 and null. Give the method one responsibility instead of also saving to a file.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The clean value is Read and blank input is rejected. Your boundary tests distinguish the exact maximum.

Break, repair and explain

Deliberately violate this boundary: A method name does not guarantee purity. Document whether it changes state or performs I/O. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The clean value is Read and blank input is rejected. Your boundary tests distinguish the exact maximum.

Troubleshoot: My result does not match Methods: name a reusable rule: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The local class defines a static method that trims and rejects blank titles. Throwing IllegalArgumentException makes the rejected input visible to the caller. The result contains only validated data. Then inspect this limit: A method name does not guarantee purity. Document whether it changes state or performs I/O. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/java-methods/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Methods: name a reusable rule line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A named recipe lets several cooks follow the same measured steps.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: What is a good responsibility for this clean method? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A method name does not guarantee purity. Document whether it changes state or performs I/O. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What is a good responsibility for this clean method?

Interview: What is a good responsibility for this clean method? Defend your answer using your actual lab result and this boundary: A method name does not guarantee purity. Document whether it changes state or performs I/O.

Quiz: What is a good responsibility for this clean method?

Validate, email and deploy simultaneously.

Silently invent a title.

Return a validated title or an intentional error.

Reference: Return a validated title or an intentional error. — A clear contract makes a method easier to reuse and test. Side effects belong behind explicit separate boundaries.

Sources:

dev.java: learn Java: https://dev.java/learn/

### Objects: keep state and rules together

A class describes a kind of object. An object holds state and exposes operations. Encapsulation protects an invariant: a condition that should remain true after every allowed operation.

How it works
A private field prevents callers from assigning arbitrary values directly. The constructor checks the initial state, and a method changes completion deliberately.

Where the model stops
private is a language access rule, not encryption or a distributed security boundary.

Make one change
Add a reopen operation and a title accessor. Test the valid lifecycle and reject an invalid constructor input.

Mental model: A task is a small sealed record with a controlled switch, rather than public wires anyone can rearrange.

Boundary: private is a language access rule, not encryption or a distributed security boundary.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
class Task {
 private final String title; private boolean done;
 Task(String title) { if(title == null || title.isBlank()) throw new IllegalArgumentException(); this.title=title; }
 void complete() { done=true; }
 boolean isDone() { return done; }
}
Task task = new Task("Read"); check(!task.isDone()); task.complete(); check(task.isDone());
 System.out.println("PASS: java-objects");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/beginner/java-objects. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a reopen operation and a title accessor. Test the valid lifecycle and reject an invalid constructor input.

Terminal folder: course-labs/beginner/java-objects

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. A private field prevents callers from assigning arbitrary values directly. The constructor checks the initial state, and a method changes completion deliberately.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/java-objects. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The task moves from incomplete to complete. Your tests cover reopening without allowing an empty title.

Build your change

Add a reopen operation and a title accessor. Test the valid lifecycle and reject an invalid constructor input.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The task moves from incomplete to complete. Your tests cover reopening without allowing an empty title.

Break, repair and explain

Deliberately violate this boundary: private is a language access rule, not encryption or a distributed security boundary. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The task moves from incomplete to complete. Your tests cover reopening without allowing an empty title.

Troubleshoot: My result does not match Objects: keep state and rules together: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: A private field prevents callers from assigning arbitrary values directly. The constructor checks the initial state, and a method changes completion deliberately. Then inspect this limit: private is a language access rule, not encryption or a distributed security boundary. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/java-objects/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Objects: keep state and rules together line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A task is a small sealed record with a controlled switch, rather than public wires anyone can rearrange.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: What does encapsulation protect here? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: private is a language access rule, not encryption or a distributed security boundary. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What does encapsulation protect here?

Interview: What does encapsulation protect here? Defend your answer using your actual lab result and this boundary: private is a language access rule, not encryption or a distributed security boundary.

Quiz: What does encapsulation protect here?

All network traffic.

The object state through controlled operations.

The JVM from every crash.

Reference: The object state through controlled operations. — Encapsulation narrows how object state can change. It does not replace security controls or operational design.

Sources:

dev.java: learn Java: https://dev.java/learn/

### Collections: choose sequence or lookup

A List represents an ordered sequence. A Map associates a key with a value. Select the structure from the access pattern rather than using one collection everywhere.

How it works
A map key is unique. Putting another value under the same key replaces the previous value. get can return null for an absent key; containsKey distinguishes absence from a stored null.

Where the model stops
HashMap does not promise iteration order and is not safe for unsynchronised concurrent mutation.

Make one change
Write a lookup function returning Optional<String> for an absent task. Compare iteration order using LinkedHashMap and document why callers should not assume HashMap ordering.

Mental model: A list is a numbered queue; a map is a labelled drawer cabinet.

Boundary: HashMap does not promise iteration order and is not safe for unsynchronised concurrent mutation.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
Map<Integer,String> tasks = new HashMap<>();
tasks.put(1,"Draft"); tasks.put(1,"Read");
check(tasks.size()==1); check(tasks.get(1).equals("Read")); check(!tasks.containsKey(2));
List<String> ordered = List.of("First","Second"); check(ordered.get(0).equals("First"));
 System.out.println("PASS: java-collections");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/beginner/java-collections. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Write a lookup function returning Optional<String> for an absent task. Compare iteration order using LinkedHashMap and document why callers should not assume HashMap ordering.

Terminal folder: course-labs/beginner/java-collections

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. A map key is unique. Putting another value under the same key replaces the previous value. get can return null for an absent key; containsKey distinguishes absence from a stored null.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/java-collections. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The repeated key leaves one entry containing Read. Your missing lookup is explicit rather than dereferenced blindly.

Build your change

Write a lookup function returning Optional<String> for an absent task. Compare iteration order using LinkedHashMap and document why callers should not assume HashMap ordering.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The repeated key leaves one entry containing Read. Your missing lookup is explicit rather than dereferenced blindly.

Break, repair and explain

Deliberately violate this boundary: HashMap does not promise iteration order and is not safe for unsynchronised concurrent mutation. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The repeated key leaves one entry containing Read. Your missing lookup is explicit rather than dereferenced blindly.

Troubleshoot: My result does not match Collections: choose sequence or lookup: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: A map key is unique. Putting another value under the same key replaces the previous value. get can return null for an absent key; containsKey distinguishes absence from a stored null. Then inspect this limit: HashMap does not promise iteration order and is not safe for unsynchronised concurrent mutation. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/java-collections/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Collections: choose sequence or lookup line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A list is a numbered queue; a map is a labelled drawer cabinet.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: What happens when put uses an existing Map key? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: HashMap does not promise iteration order and is not safe for unsynchronised concurrent mutation. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What happens when put uses an existing Map key?

Interview: What happens when put uses an existing Map key? Defend your answer using your actual lab result and this boundary: HashMap does not promise iteration order and is not safe for unsynchronised concurrent mutation.

Quiz: What happens when put uses an existing Map key?

A second identical key is added.

The map sorts itself.

Its associated value is replaced.

Reference: Its associated value is replaced. — A Map associates at most one value with a key. Duplicate-key policy matters when importing or merging data.

Sources:

Java: collections framework: https://dev.java/learn/api/collections-framework/

### Types and contracts

A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on. In this role, work through: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. The practical workshop develops this into: Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.

Mental model: A labeled socket that accepts the correct plug.

Boundary: A correct type does not prove a meaningful value; an empty String is still a String.

Role application: A stamped ticket proves it passed the entry desk before other staff use it.

Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass.

Worked example: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.

Shared foundation example: title(" Learn ") returns "Learn"; title("") throws an error.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Java Developer: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.

Predict the worked case

Read this case without running a tool: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in types and contracts.

Connect the concept to the role

Apply this rule: A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A correct type does not prove a meaningful value; an empty String is still a String.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies types and contracts to this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Types and contracts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with types and contracts. Use the glossary below, then write your prediction for: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain types and contracts using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate types and contracts to a system or workflow you know. Explain types and contracts using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What must be checked beyond the String type?

Interview: Explain types and contracts using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops.

Quiz: After the Value objects and exceptions rehearsal, check this foundation: A value has the required integer type but is outside the allowed business range. What is missing?

A domain validation rule in addition to the type check.

A cast to another integer type regardless of range.

A longer variable name so the caller understands it.

Reference: A domain validation rule in addition to the type check. — Type correctness and business validity are different parts of a contract.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

### Value objects and exceptions

Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass. In this role, work through: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. The practical workshop develops this into: Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.

Mental model: A stamped ticket proves it passed the entry desk before other staff use it.

Boundary: If different handlers disagree, check for duplicated validation rather than changing each handler separately.

Worked example: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Java Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.

Trace the typed rule

Open TicketService.java and locate the title validator and main method.

Expected: You can predict normal, blank and oversized title outcomes.

Execute the level checks

Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.

```
java TicketService.java test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS java beginner

Inspect a failure

In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.

Expected: Your rejection case is exercised; explain what part of the contract changed.

Role workshop · predict

TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.

```
java TicketService.java test beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Three deterministic cases; no invalid title instance escapes construction.

Role workshop · debug and verify

If different handlers disagree, check for duplicated validation rather than changing each handler separately. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save value-type code and validation test table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Three deterministic cases; no invalid title instance escapes construction.

Expected: Three deterministic cases; no invalid title instance escapes construction.

Troubleshoot: The role exercise differs from the prediction: If different handlers disagree, check for duplicated validation rather than changing each handler separately.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: value-type code and validation test table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with value objects and exceptions. Use the glossary below, then write your prediction for: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain value objects and exceptions using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate value objects and exceptions to a system or workflow you know. Explain value objects and exceptions using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If different handlers disagree, check for duplicated validation rather than changing each handler separately.

Interview: Explain value objects and exceptions using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.

Three deterministic cases; no invalid title instance escapes construction.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Three deterministic cases; no invalid title instance escapes construction. — Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass. Three deterministic cases; no invalid title instance escapes construction.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Service boundary: An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport.

Apply service boundary in Java Developer: Use the concept to complete this role exercise: Trace HTTP handlers and separate service logic

Dependency boundaries in Java: Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port.

### Exceptions: catch at the right boundary

Exceptions separate normal results from failures. Catch a failure where you can recover or translate it; catching everything and continuing can hide corrupted assumptions.

How it works
Integer.parseInt reports invalid syntax with NumberFormatException. Translate that specific failure into a safe OptionalInt result. Other failures should not be silently treated as a missing number.

Where the model stops
OptionalInt expresses absence but does not describe the reason. Use a richer result when callers need distinct validation messages.

Make one change
Test overflow text and whitespace. Decide whether to trim at the boundary and show that the chosen policy is deliberate.

Mental model: An alarm belongs at the point where someone can act, not under a blanket.

Boundary: OptionalInt expresses absence but does not describe the reason. Use a richer result when callers need distinct validation messages.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
class Input { static OptionalInt id(String value) {
 try { int id=Integer.parseInt(value); return id>0?OptionalInt.of(id):OptionalInt.empty(); }
 catch (NumberFormatException e) { return OptionalInt.empty(); }
} }
check(Input.id("7").orElseThrow()==7); check(Input.id("x").isEmpty()); check(Input.id("0").isEmpty());
 System.out.println("PASS: java-exceptions");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/intermediate/java-exceptions. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Test overflow text and whitespace. Decide whether to trim at the boundary and show that the chosen policy is deliberate.

Terminal folder: course-labs/intermediate/java-exceptions

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. Integer.parseInt reports invalid syntax with NumberFormatException. Translate that specific failure into a safe OptionalInt result. Other failures should not be silently treated as a missing number.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/java-exceptions. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Positive 7 is accepted; x and 0 are absent. Your overflow case is handled without losing unrelated exceptions.

Build your change

Test overflow text and whitespace. Decide whether to trim at the boundary and show that the chosen policy is deliberate.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Positive 7 is accepted; x and 0 are absent. Your overflow case is handled without losing unrelated exceptions.

Break, repair and explain

Deliberately violate this boundary: OptionalInt expresses absence but does not describe the reason. Use a richer result when callers need distinct validation messages. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Positive 7 is accepted; x and 0 are absent. Your overflow case is handled without losing unrelated exceptions.

Troubleshoot: My result does not match Exceptions: catch at the right boundary: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Integer.parseInt reports invalid syntax with NumberFormatException. Translate that specific failure into a safe OptionalInt result. Other failures should not be silently treated as a missing number. Then inspect this limit: OptionalInt expresses absence but does not describe the reason. Use a richer result when callers need distinct validation messages. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/java-exceptions/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Exceptions: catch at the right boundary line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: An alarm belongs at the point where someone can act, not under a blanket.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: Why avoid catch(Exception) returning a success-shaped default? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: OptionalInt expresses absence but does not describe the reason. Use a richer result when callers need distinct validation messages. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why avoid catch(Exception) returning a success-shaped default?

Interview: Why avoid catch(Exception) returning a success-shaped default? Defend your answer using your actual lab result and this boundary: OptionalInt expresses absence but does not describe the reason. Use a richer result when callers need distinct validation messages.

Quiz: Why avoid catch(Exception) returning a success-shaped default?

It can hide failures unrelated to the expected input problem.

It makes Java asynchronous.

It is required by every method.

Reference: It can hide failures unrelated to the expected input problem. — Catch only what you can interpret or recover from. Returning a default for every failure can conceal defects.

Sources:

dev.java: learn Java: https://dev.java/learn/

### Generics: preserve element contracts

Generics let a collection carry an element type. A List<String> tells the compiler what its values should be and avoids repeated casts at ordinary call sites.

How it works
Generic type arguments provide compile-time checks. A copied list can preserve ordering while isolating structural edits from the original. Prefer typed APIs over raw List values.

Where the model stops
Generic type information is largely erased at runtime. External data still requires runtime validation.

Make one change
Uncomment the invalid add and capture the compiler diagnostic. Restore it, then show that copying a list does not deeply clone mutable objects inside it.

Mental model: A labelled tray keeps incompatible parts out before assembly.

Boundary: Generic type information is largely erased at runtime. External data still requires runtime validation.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
List<String> original = new ArrayList<>(List.of("Read","Build"));
List<String> copy = new ArrayList<>(original); copy.add("Test");
check(original.size()==2); check(copy.size()==3);
// original.add(7); // Uncomment: compilation must fail, then restore.

 System.out.println("PASS: java-generics");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/intermediate/java-generics. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Uncomment the invalid add and capture the compiler diagnostic. Restore it, then show that copying a list does not deeply clone mutable objects inside it.

Terminal folder: course-labs/intermediate/java-generics

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. Generic type arguments provide compile-time checks. A copied list can preserve ordering while isolating structural edits from the original. Prefer typed APIs over raw List values.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/java-generics. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The original remains length 2 and the copy is length 3. The deliberate incompatible add fails compilation.

Build your change

Uncomment the invalid add and capture the compiler diagnostic. Restore it, then show that copying a list does not deeply clone mutable objects inside it.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The original remains length 2 and the copy is length 3. The deliberate incompatible add fails compilation.

Break, repair and explain

Deliberately violate this boundary: Generic type information is largely erased at runtime. External data still requires runtime validation. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The original remains length 2 and the copy is length 3. The deliberate incompatible add fails compilation.

Troubleshoot: My result does not match Generics: preserve element contracts: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Generic type arguments provide compile-time checks. A copied list can preserve ordering while isolating structural edits from the original. Prefer typed APIs over raw List values. Then inspect this limit: Generic type information is largely erased at runtime. External data still requires runtime validation. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/java-generics/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Generics: preserve element contracts line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A labelled tray keeps incompatible parts out before assembly.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: Do generic declarations validate arbitrary network JSON at runtime? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Generic type information is largely erased at runtime. External data still requires runtime validation. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Do generic declarations validate arbitrary network JSON at runtime?

Interview: Do generic declarations validate arbitrary network JSON at runtime? Defend your answer using your actual lab result and this boundary: Generic type information is largely erased at runtime. External data still requires runtime validation.

Quiz: Do generic declarations validate arbitrary network JSON at runtime?

Yes, automatically.

No; parse and validate the external boundary.

Only with ArrayList.

Reference: No; parse and validate the external boundary. — Compile-time element contracts do not establish the shape of untrusted runtime input.

Sources:

Java: generics: https://dev.java/learn/generics/

### Streams: express a data transformation

A stream pipeline describes operations such as filtering and mapping. It is useful for a transformation with a clear input and output. Keep side effects out of intermediate steps.

How it works
filter keeps matching elements; map transforms them; a terminal operation triggers evaluation. The source list remains unchanged by this pure pipeline.

Where the model stops
A stream is single-use. Parallel streams do not automatically improve speed and can make side effects unsafe.

Make one change
Implement the same rule with a loop and compare behaviour on empty input and duplicates. Choose the version whose intent your reviewer can explain most clearly.

Mental model: A conveyor belt selects items, changes their labels and collects the result.

Boundary: A stream is single-use. Parallel streams do not automatically improve speed and can make side effects unsafe.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
List<String> input = List.of(" Read "," ","Build");
List<String> result = input.stream().map(String::strip).filter(s -> !s.isEmpty()).toList();
check(result.equals(List.of("Read","Build"))); check(input.get(0).equals(" Read "));
 System.out.println("PASS: java-streams");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/intermediate/java-streams. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Implement the same rule with a loop and compare behaviour on empty input and duplicates. Choose the version whose intent your reviewer can explain most clearly.

Terminal folder: course-labs/intermediate/java-streams

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. filter keeps matching elements; map transforms them; a terminal operation triggers evaluation. The source list remains unchanged by this pure pipeline.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/java-streams. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The result is Read, Build and the source remains unchanged. Your loop and stream agree on the stated cases.

Build your change

Implement the same rule with a loop and compare behaviour on empty input and duplicates. Choose the version whose intent your reviewer can explain most clearly.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The result is Read, Build and the source remains unchanged. Your loop and stream agree on the stated cases.

Break, repair and explain

Deliberately violate this boundary: A stream is single-use. Parallel streams do not automatically improve speed and can make side effects unsafe. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The result is Read, Build and the source remains unchanged. Your loop and stream agree on the stated cases.

Troubleshoot: My result does not match Streams: express a data transformation: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: filter keeps matching elements; map transforms them; a terminal operation triggers evaluation. The source list remains unchanged by this pure pipeline. Then inspect this limit: A stream is single-use. Parallel streams do not automatically improve speed and can make side effects unsafe. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/java-streams/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Streams: express a data transformation line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A conveyor belt selects items, changes their labels and collects the result.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: Which operation triggers evaluation of this pipeline? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A stream is single-use. Parallel streams do not automatically improve speed and can make side effects unsafe. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which operation triggers evaluation of this pipeline?

Interview: Which operation triggers evaluation of this pipeline? Defend your answer using your actual lab result and this boundary: A stream is single-use. Parallel streams do not automatically improve speed and can make side effects unsafe.

Quiz: Which operation triggers evaluation of this pipeline?

Creating the source List.

Writing filter alone.

The terminal toList operation.

Reference: The terminal toList operation. — Intermediate operations are lazy; the terminal operation consumes the stream.

Sources:

Java SE 21: Stream contract: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/stream/Stream.html

### Interfaces: replace a dependency in a test

An interface defines behaviour a collaborator must provide. Depending on that contract lets the application use a real storage adapter or a deterministic test double.

How it works
The service asks a repository to find a title. A lambda implements the small interface for a test. Keep the domain decision separate from connection setup and I/O.

Where the model stops
A fake repository does not validate SQL, transactions or network behaviour. Test the real adapter at its boundary too.

Make one change
Add a real file-backed adapter in a temporary directory and run the same contract cases against both adapters. Record which checks are unit and which exercise I/O.

Mental model: A standard socket lets the appliance change without rewiring the room.

Boundary: A fake repository does not validate SQL, transactions or network behaviour. Test the real adapter at its boundary too.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
interface Tasks { Optional<String> find(int id); }
class Service { private final Tasks tasks; Service(Tasks tasks){this.tasks=tasks;} String title(int id){return tasks.find(id).orElse("Missing");} }
Tasks fake = id -> id==1?Optional.of("Read"):Optional.empty();
Service service = new Service(fake); check(service.title(1).equals("Read")); check(service.title(2).equals("Missing"));
 System.out.println("PASS: java-interfaces");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/intermediate/java-interfaces. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a real file-backed adapter in a temporary directory and run the same contract cases against both adapters. Record which checks are unit and which exercise I/O.

Terminal folder: course-labs/intermediate/java-interfaces

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. The service asks a repository to find a title. A lambda implements the small interface for a test. Keep the domain decision separate from connection setup and I/O.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/java-interfaces. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The fake produces Read and Missing. Your adapter tests identify the additional file-format and missing-file cases.

Build your change

Add a real file-backed adapter in a temporary directory and run the same contract cases against both adapters. Record which checks are unit and which exercise I/O.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The fake produces Read and Missing. Your adapter tests identify the additional file-format and missing-file cases.

Break, repair and explain

Deliberately violate this boundary: A fake repository does not validate SQL, transactions or network behaviour. Test the real adapter at its boundary too. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The fake produces Read and Missing. Your adapter tests identify the additional file-format and missing-file cases.

Troubleshoot: My result does not match Interfaces: replace a dependency in a test: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The service asks a repository to find a title. A lambda implements the small interface for a test. Keep the domain decision separate from connection setup and I/O. Then inspect this limit: A fake repository does not validate SQL, transactions or network behaviour. Test the real adapter at its boundary too. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/java-interfaces/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Interfaces: replace a dependency in a test line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A standard socket lets the appliance change without rewiring the room.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: What does the fake repository test establish? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A fake repository does not validate SQL, transactions or network behaviour. Test the real adapter at its boundary too. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What does the fake repository test establish?

Interview: What does the fake repository test establish? Defend your answer using your actual lab result and this boundary: A fake repository does not validate SQL, transactions or network behaviour. Test the real adapter at its boundary too.

Quiz: What does the fake repository test establish?

That the production database works.

That the service behaves under the fake contract.

That all dependencies are secure.

Reference: That the service behaves under the fake contract. — A test double isolates behaviour. It cannot prove the real adapter satisfies its implementation guarantees.

Sources:

dev.java: learn Java: https://dev.java/learn/

### Resource ownership: close what you open

Files and network connections consume operating-system resources. A predictable ownership rule prevents leaks: the scope that acquires a resource should normally arrange its release.

How it works
try-with-resources closes AutoCloseable values when the block exits, including exceptional exits. The local test resource records that close ran after an injected failure.

Where the model stops
Closing one wrapper may have ownership implications for an underlying stream. Check the API contract before sharing resources across scopes.

Make one change
Write and read a temporary text file with try-with-resources. Inject a failure during processing and remove only your temporary fixture after the resource closes.

Mental model: Borrowed keys are returned when leaving the room, including during an emergency.

Boundary: Closing one wrapper may have ownership implications for an underlying stream. Check the API contract before sharing resources across scopes.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
class Resource implements AutoCloseable { boolean closed; public void close(){closed=true;} }
Resource resource = new Resource();
try (Resource opened = resource) { throw new IllegalStateException("Injected"); }
catch (IllegalStateException expected) { check(expected.getMessage().equals("Injected")); }
check(resource.closed);
 System.out.println("PASS: java-resources");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/intermediate/java-resources. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Write and read a temporary text file with try-with-resources. Inject a failure during processing and remove only your temporary fixture after the resource closes.

Terminal folder: course-labs/intermediate/java-resources

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. try-with-resources closes AutoCloseable values when the block exits, including exceptional exits. The local test resource records that close ran after an injected failure.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/java-resources. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: close runs on the exceptional path. Your real file test documents the content and cleanup result.

Build your change

Write and read a temporary text file with try-with-resources. Inject a failure during processing and remove only your temporary fixture after the resource closes.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. close runs on the exceptional path. Your real file test documents the content and cleanup result.

Break, repair and explain

Deliberately violate this boundary: Closing one wrapper may have ownership implications for an underlying stream. Check the API contract before sharing resources across scopes. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: close runs on the exceptional path. Your real file test documents the content and cleanup result.

Troubleshoot: My result does not match Resource ownership: close what you open: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: try-with-resources closes AutoCloseable values when the block exits, including exceptional exits. The local test resource records that close ran after an injected failure. Then inspect this limit: Closing one wrapper may have ownership implications for an underlying stream. Check the API contract before sharing resources across scopes. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/java-resources/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Resource ownership: close what you open line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Borrowed keys are returned when leaving the room, including during an emergency.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: When does try-with-resources attempt close? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Closing one wrapper may have ownership implications for an underlying stream. Check the API contract before sharing resources across scopes. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: When does try-with-resources attempt close?

Interview: When does try-with-resources attempt close? Defend your answer using your actual lab result and this boundary: Closing one wrapper may have ownership implications for an underlying stream. Check the API contract before sharing resources across scopes.

Quiz: When does try-with-resources attempt close?

Only after successful work.

Only when the file is full.

At scope exit, including an exception path.

Reference: At scope exit, including an exception path. — The resource scope arranges deterministic closure. Exceptions from work and close still need an intentional handling policy.

Sources:

Java: try-with-resources; tutorial baseline JDK 8: https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html

### Service boundary

An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport. In this role, work through: A failing repository should produce a controlled service failure rather than a false success count. The practical workshop develops this into: Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.

Mental model: A receptionist translates a visitor request for the right team.

Boundary: Framework annotations do not automatically enforce every business rule.

Role application: A receptionist, decision maker and records clerk each have a different responsibility.

Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port.

Worked example: A failing repository should produce a controlled service failure rather than a false success count.

Shared foundation example: POST /tickets receives text and creates a ticket; GET returns the count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Java Developer: A failing repository should produce a controlled service failure rather than a false success count.

Predict the worked case

Read this case without running a tool: A failing repository should produce a controlled service failure rather than a false success count. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in service boundary.

Connect the concept to the role

Apply this rule: An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Framework annotations do not automatically enforce every business rule.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies service boundary to this case: A failing repository should produce a controlled service failure rather than a false success count. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A failing repository should produce a controlled service failure rather than a false success count. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Service boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with service boundary. Use the glossary below, then write your prediction for: A failing repository should produce a controlled service failure rather than a false success count. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain service boundary using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate service boundary to a system or workflow you know. Explain service boundary using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Where should title validation live if two endpoints create tickets?

Interview: Explain service boundary using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops.

Quiz: After the Dependency boundaries in Java rehearsal, check this foundation: An HTTP handler validates JSON, but the same rule is needed by a batch job. Where should the shared business rule live?

Only in the HTTP status-code mapping.

In a testable domain operation called by both adapters.

In duplicated handler code maintained independently.

Reference: In a testable domain operation called by both adapters. — Transport adapters translate inputs and outputs; shared business behavior should have a clear reusable boundary.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

### Dependency boundaries in Java

Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port. In this role, work through: A failing repository should produce a controlled service failure rather than a false success count. The practical workshop develops this into: Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.

Mental model: A receptionist, decision maker and records clerk each have a different responsibility.

Boundary: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.

Worked example: A failing repository should produce a controlled service failure rather than a false success count.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Java Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.

Trace the typed rule

Open TicketService.java and locate the title validator and main method.

Expected: You can predict normal, blank and oversized title outcomes.

Execute the level checks

Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.

```
java TicketService.java test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS java intermediate

Inspect a failure

In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.

Expected: Your rejection case is exercised; explain what part of the contract changed.

Role workshop · predict

A failing repository should produce a controlled service failure rather than a false success count. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.

```
java TicketService.java test intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Business tests run without networking; repository failure does not report creation.

Role workshop · debug and verify

A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save service-boundary diagram and Java tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Business tests run without networking; repository failure does not report creation.

Expected: Business tests run without networking; repository failure does not report creation.

Troubleshoot: The role exercise differs from the prediction: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: service-boundary diagram and Java tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with dependency boundaries in java. Use the glossary below, then write your prediction for: A failing repository should produce a controlled service failure rather than a false success count. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain dependency boundaries in java using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate dependency boundaries in java to a system or workflow you know. Explain dependency boundaries in java using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.

Interview: Explain dependency boundaries in java using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A failing repository should produce a controlled service failure rather than a false success count.

Ignore the failing case and keep only the successful screenshot.

Business tests run without networking; repository failure does not report creation.

Treat any successful command as proof that all business and access rules passed.

Reference: Business tests run without networking; repository failure does not report creation. — Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port. Business tests run without networking; repository failure does not report creation.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Concurrency and evidence: Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy.

Apply concurrency and evidence in Java Developer: Use the concept to complete this role exercise: Test concurrent counter changes and explain transaction boundaries

Concurrent invariants: AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage.

### Immutable boundaries: copy mutable inputs

final prevents reassignment of a field, not mutation of the object referenced by that field. An immutable boundary must also decide how nested mutable values are owned.

How it works
List.copyOf makes an unmodifiable shallow snapshot and rejects null elements. A record that stores that snapshot avoids later structural edits through the caller original list.

Where the model stops
A shallow copy still shares each element. Mutable element objects require their own copying or ownership policy.

Make one change
Repeat with a mutable element class and demonstrate the shallow-copy limit. Propose an immutable element record and test both access paths.

Mental model: Sealing the folder label does not seal every page inside it.

Boundary: A shallow copy still shares each element. Mutable element objects require their own copying or ownership policy.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
record Batch(List<String> titles) { Batch { titles = List.copyOf(titles); } }
List<String> source = new ArrayList<>(List.of("Read")); Batch batch = new Batch(source);
source.add("Build"); check(batch.titles().size()==1);
boolean blocked=false; try{batch.titles().add("Oops");}catch(UnsupportedOperationException e){blocked=true;} check(blocked);
 System.out.println("PASS: java-immutability");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/advanced/java-immutability. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Repeat with a mutable element class and demonstrate the shallow-copy limit. Propose an immutable element record and test both access paths.

Terminal folder: course-labs/advanced/java-immutability

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. List.copyOf makes an unmodifiable shallow snapshot and rejects null elements. A record that stores that snapshot avoids later structural edits through the caller original list.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/java-immutability. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Structural changes through the original or returned list cannot change this batch. Your nested-object case identifies the remaining ownership boundary.

Build your change

Repeat with a mutable element class and demonstrate the shallow-copy limit. Propose an immutable element record and test both access paths.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Structural changes through the original or returned list cannot change this batch. Your nested-object case identifies the remaining ownership boundary.

Break, repair and explain

Deliberately violate this boundary: A shallow copy still shares each element. Mutable element objects require their own copying or ownership policy. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Structural changes through the original or returned list cannot change this batch. Your nested-object case identifies the remaining ownership boundary.

Troubleshoot: My result does not match Immutable boundaries: copy mutable inputs: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: List.copyOf makes an unmodifiable shallow snapshot and rejects null elements. A record that stores that snapshot avoids later structural edits through the caller original list. Then inspect this limit: A shallow copy still shares each element. Mutable element objects require their own copying or ownership policy. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/java-immutability/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Immutable boundaries: copy mutable inputs line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Sealing the folder label does not seal every page inside it.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: Does a final List field make its elements immutable? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A shallow copy still shares each element. Mutable element objects require their own copying or ownership policy. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does a final List field make its elements immutable?

Interview: Does a final List field make its elements immutable? Defend your answer using your actual lab result and this boundary: A shallow copy still shares each element. Mutable element objects require their own copying or ownership policy.

Quiz: Does a final List field make its elements immutable?

No.

Yes, recursively.

Only when named finalList.

Reference: No. — final fixes a reference; it does not recursively freeze the referenced object graph.

Sources:

dev.java: learn Java: https://dev.java/learn/

### Concurrency: preserve an atomic invariant

A read-modify-write sequence can race when threads access shared state. A thread-safe primitive makes one operation atomic; a larger multi-field invariant may still need a broader design.

How it works
AtomicInteger.incrementAndGet combines the increment into an atomic operation. Wait for every submitted task before checking the final value, and shut down the executor you created.

Where the model stops
An atomic counter does not make a whole order workflow transactional or bound every task queue automatically.

Make one change
Compare an intentionally unsynchronised counter over repeated trials without claiming a race must occur every run. Then model a two-field invariant that a single atomic counter cannot protect.

Mental model: One cashier increments the shared counter under a single controlled action.

Boundary: An atomic counter does not make a whole order workflow transactional or bound every task queue automatically.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
java.util.concurrent.atomic.AtomicInteger count = new java.util.concurrent.atomic.AtomicInteger();
ExecutorService pool = Executors.newFixedThreadPool(4);
try { List<Future<?>> jobs = new ArrayList<>();
 for(int i=0;i<100;i++) jobs.add(pool.submit(count::incrementAndGet));
 for(Future<?> job:jobs) job.get(); check(count.get()==100);
} finally { pool.shutdown(); check(pool.awaitTermination(5,TimeUnit.SECONDS)); }
 System.out.println("PASS: java-concurrency");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/advanced/java-concurrency. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Compare an intentionally unsynchronised counter over repeated trials without claiming a race must occur every run. Then model a two-field invariant that a single atomic counter cannot protect.

Terminal folder: course-labs/advanced/java-concurrency

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. AtomicInteger.incrementAndGet combines the increment into an atomic operation. Wait for every submitted task before checking the final value, and shut down the executor you created.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/java-concurrency. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The atomic counter reaches 100 after all tasks finish and the pool closes. Your discussion separates individual atomic operations from compound invariants.

Build your change

Compare an intentionally unsynchronised counter over repeated trials without claiming a race must occur every run. Then model a two-field invariant that a single atomic counter cannot protect.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The atomic counter reaches 100 after all tasks finish and the pool closes. Your discussion separates individual atomic operations from compound invariants.

Break, repair and explain

Deliberately violate this boundary: An atomic counter does not make a whole order workflow transactional or bound every task queue automatically. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The atomic counter reaches 100 after all tasks finish and the pool closes. Your discussion separates individual atomic operations from compound invariants.

Troubleshoot: My result does not match Concurrency: preserve an atomic invariant: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: AtomicInteger.incrementAndGet combines the increment into an atomic operation. Wait for every submitted task before checking the final value, and shut down the executor you created. Then inspect this limit: An atomic counter does not make a whole order workflow transactional or bound every task queue automatically. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/java-concurrency/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Concurrency: preserve an atomic invariant line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: One cashier increments the shared counter under a single controlled action.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: Does an atomic increment make two unrelated shared-field updates atomic together? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: An atomic counter does not make a whole order workflow transactional or bound every task queue automatically. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does an atomic increment make two unrelated shared-field updates atomic together?

Interview: Does an atomic increment make two unrelated shared-field updates atomic together? Defend your answer using your actual lab result and this boundary: An atomic counter does not make a whole order workflow transactional or bound every task queue automatically.

Quiz: Does an atomic increment make two unrelated shared-field updates atomic together?

Yes.

No, the compound invariant needs additional coordination.

Only with four threads.

Reference: No, the compound invariant needs additional coordination. — Atomicity has a scope. Two separate operations can still be observed or interleaved between updates.

Sources:

Java SE 21: concurrency utilities: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/package-summary.html

### Deadlines and interruption: cooperate with cancellation

A waiting caller and a running task have separate lifecycles. Requesting cancellation with interruption asks the task to stop; the task must observe interruption or use interruptible operations.

How it works
The worker blocks in sleep, an interruptible operation. When interrupted, it restores the interrupt status and exits. The test waits for an explicit stopped signal, not merely the caller cancellation result.

Where the model stops
Real libraries vary in interruption behaviour. A cancelled Future does not prove every remote side effect was undone.

Make one change
Add a caller deadline and document what operation receives the remaining time. Explain why swallowing InterruptedException and continuing would defeat the cooperative stop policy.

Mental model: A stop signal only works when the worker checks the signal or uses a tool that does.

Boundary: Real libraries vary in interruption behaviour. A cancelled Future does not prove every remote side effect was undone.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
ExecutorService pool=Executors.newSingleThreadExecutor();
CountDownLatch started=new CountDownLatch(1), stopped=new CountDownLatch(1);
try {
 Future<?> job=pool.submit(()->{started.countDown();try{Thread.sleep(10000);}catch(InterruptedException e){Thread.currentThread().interrupt();}finally{stopped.countDown();}});
 check(started.await(2,TimeUnit.SECONDS)); job.cancel(true); check(stopped.await(2,TimeUnit.SECONDS));
}finally{pool.shutdownNow();check(pool.awaitTermination(5,TimeUnit.SECONDS));}
 System.out.println("PASS: java-cancellation");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/advanced/java-cancellation. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a caller deadline and document what operation receives the remaining time. Explain why swallowing InterruptedException and continuing would defeat the cooperative stop policy.

Terminal folder: course-labs/advanced/java-cancellation

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. The worker blocks in sleep, an interruptible operation. When interrupted, it restores the interrupt status and exits. The test waits for an explicit stopped signal, not merely the caller cancellation result.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/java-cancellation. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The worker signals started, then stopped after interruption, and the executor terminates. Your design distinguishes caller timeout from worker termination.

Build your change

Add a caller deadline and document what operation receives the remaining time. Explain why swallowing InterruptedException and continuing would defeat the cooperative stop policy.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The worker signals started, then stopped after interruption, and the executor terminates. Your design distinguishes caller timeout from worker termination.

Break, repair and explain

Deliberately violate this boundary: Real libraries vary in interruption behaviour. A cancelled Future does not prove every remote side effect was undone. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The worker signals started, then stopped after interruption, and the executor terminates. Your design distinguishes caller timeout from worker termination.

Troubleshoot: My result does not match Deadlines and interruption: cooperate with cancellation: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The worker blocks in sleep, an interruptible operation. When interrupted, it restores the interrupt status and exits. The test waits for an explicit stopped signal, not merely the caller cancellation result. Then inspect this limit: Real libraries vary in interruption behaviour. A cancelled Future does not prove every remote side effect was undone. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/java-cancellation/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Deadlines and interruption: cooperate with cancellation line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A stop signal only works when the worker checks the signal or uses a tool that does.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: What does cancel(true) request for a running interruptible task? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Real libraries vary in interruption behaviour. A cancelled Future does not prove every remote side effect was undone. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What does cancel(true) request for a running interruptible task?

Interview: What does cancel(true) request for a running interruptible task? Defend your answer using your actual lab result and this boundary: Real libraries vary in interruption behaviour. A cancelled Future does not prove every remote side effect was undone.

Quiz: What does cancel(true) request for a running interruptible task?

A guaranteed remote rollback.

A JVM restart.

An interruption request that the task must handle.

Reference: An interruption request that the task must handle. — Cancellation and interruption are cooperative. Observe actual task termination and separately reconcile external effects.

Sources:

Java SE 21: concurrency utilities: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/concurrent/package-summary.html

### Decimal values: avoid hidden rounding policies

Money-like decimal values need an explicit precision and rounding policy. BigDecimal represents decimal arithmetic, but constructing it from a binary double can carry the double approximation.

How it works
Construct from a decimal string when that is the source of truth. compareTo compares numeric value; equals also considers scale. State which comparison the business rule intends.

Where the model stops
BigDecimal alone does not decide currency conversion, rounding, minor units or financial compliance.

Make one change
Divide 1 by 3 with a declared scale and rounding mode. Record the rounding boundary cases and keep currency-specific policy separate from the arithmetic type.

Mental model: Use the printed decimal amount as the measurement, rather than a rounded photograph of it.

Boundary: BigDecimal alone does not decide currency conversion, rounding, minor units or financial compliance.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
BigDecimal a=new BigDecimal("0.10"), b=new BigDecimal("0.20");
check(a.add(b).compareTo(new BigDecimal("0.30"))==0);
check(new BigDecimal("1.0").compareTo(new BigDecimal("1.00"))==0);
check(!new BigDecimal("1.0").equals(new BigDecimal("1.00")));
 System.out.println("PASS: java-decimals");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/advanced/java-decimals. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Divide 1 by 3 with a declared scale and rounding mode. Record the rounding boundary cases and keep currency-specific policy separate from the arithmetic type.

Terminal folder: course-labs/advanced/java-decimals

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. Construct from a decimal string when that is the source of truth. compareTo compares numeric value; equals also considers scale. State which comparison the business rule intends.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/java-decimals. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Decimal addition matches 0.30 numerically. Scale-sensitive equality differs from numeric comparison as shown.

Build your change

Divide 1 by 3 with a declared scale and rounding mode. Record the rounding boundary cases and keep currency-specific policy separate from the arithmetic type.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Decimal addition matches 0.30 numerically. Scale-sensitive equality differs from numeric comparison as shown.

Break, repair and explain

Deliberately violate this boundary: BigDecimal alone does not decide currency conversion, rounding, minor units or financial compliance. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Decimal addition matches 0.30 numerically. Scale-sensitive equality differs from numeric comparison as shown.

Troubleshoot: My result does not match Decimal values: avoid hidden rounding policies: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Construct from a decimal string when that is the source of truth. compareTo compares numeric value; equals also considers scale. State which comparison the business rule intends. Then inspect this limit: BigDecimal alone does not decide currency conversion, rounding, minor units or financial compliance. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/java-decimals/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Decimal values: avoid hidden rounding policies line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Use the printed decimal amount as the measurement, rather than a rounded photograph of it.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: Why can 1.0 and 1.00 compare numerically equal but not be equals? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: BigDecimal alone does not decide currency conversion, rounding, minor units or financial compliance. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Why can 1.0 and 1.00 compare numerically equal but not be equals?

Interview: Why can 1.0 and 1.00 compare numerically equal but not be equals? Defend your answer using your actual lab result and this boundary: BigDecimal alone does not decide currency conversion, rounding, minor units or financial compliance.

Quiz: Why can 1.0 and 1.00 compare numerically equal but not be equals?

BigDecimal equals also considers scale.

One is always a String.

Java chooses randomly.

Reference: BigDecimal equals also considers scale. — Scale is part of BigDecimal equality. Choose the comparison operation according to the application contract.

Sources:

Java SE 21: BigDecimal contract: https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/math/BigDecimal.html

### Release review: make supported claims traceable

A Java portfolio should explain its behaviour under normal, invalid and failure inputs. A build that compiles is only one part of that evidence. Name the runtime and the checks actually executed.

How it works
Represent required evidence categories explicitly. Reject incomplete reports rather than treating missing results as passes. Link the report to source, test output, environment and a rollback plan.

Where the model stops
This report check does not execute integration, performance or security tests; each needs its own recorded observation.

Make one change
Build a task service or CLI combining typed values, persistence, resource ownership and tests. Attach the actual output for each category, then rehearse a failed dependency and orderly shutdown.

Mental model: A release is a signed set of receipts, each linked to the specific test that produced it.

Boundary: This report check does not execute integration, performance or security tests; each needs its own recorded observation.

Worked example: import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
Set<String> required=Set.of("unit","integration","invalid-input","shutdown","recovery");
Map<String,Boolean> report=new HashMap<>();for(String name:required)report.put(name,true);
check(required.stream().allMatch(name->Boolean.TRUE.equals(report.get(name))));
report.remove("shutdown");check(!required.stream().allMatch(name->Boolean.TRUE.equals(report.get(name))));
 System.out.println("PASS: java-release-review");
 }
}


Setup: Download and extract java-developer.zip. A JDK 21+ distribution such as Eclipse Temurin / OpenJDK. Run java --version and javac --version. A JRE-only installation is not enough. No Maven or external dependency is required for these source-launchable examples. Open a terminal in course-labs/advanced/java-release-review. The supplied reference file is Main.java. Read it before running java Main.java. Keep a copy before editing.

Tools for this exercise: OpenJDK (JDK 21+) and a Java editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Build a task service or CLI combining typed values, persistence, resource ownership and tests. Attach the actual output for each category, then rehearse a failed dependency and orderly shutdown.

Terminal folder: course-labs/advanced/java-release-review

```
java Main.java
```

Predict before running

Read Main.java. Write the expected output and identify the state changed by this example. Represent required evidence categories explicitly. Reject incomplete reports rather than treating missing results as passes. Link the report to source, test output, environment and a rollback plan.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/java-release-review. This checks the reference behaviour only.

```
java Main.java
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The report rejects a missing shutdown result. Your final artifact contains reproducible setup, actual checks and a bounded claim about the supported environment.

Build your change

Build a task service or CLI combining typed values, persistence, resource ownership and tests. Attach the actual output for each category, then rehearse a failed dependency and orderly shutdown.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The report rejects a missing shutdown result. Your final artifact contains reproducible setup, actual checks and a bounded claim about the supported environment.

Break, repair and explain

Deliberately violate this boundary: This report check does not execute integration, performance or security tests; each needs its own recorded observation. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The report rejects a missing shutdown result. Your final artifact contains reproducible setup, actual checks and a bounded claim about the supported environment.

Troubleshoot: My result does not match Release review: make supported claims traceable: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Represent required evidence categories explicitly. Reject incomplete reports rather than treating missing results as passes. Link the report to source, test output, environment and a rollback plan. Then inspect this limit: This report check does not execute integration, performance or security tests; each needs its own recorded observation. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/java-release-review/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Release review: make supported claims traceable line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A release is a signed set of receipts, each linked to the specific test that produced it.

seeker: Prepare a coursework example for Java Developer. Answer this interview question before revealing the rubric: What extra evidence is needed beyond compilation? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This report check does not execute integration, performance or security tests; each needs its own recorded observation. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What extra evidence is needed beyond compilation?

Interview: What extra evidence is needed beyond compilation? Defend your answer using your actual lab result and this boundary: This report check does not execute integration, performance or security tests; each needs its own recorded observation.

Quiz: What extra evidence is needed beyond compilation?

Only the number of classes.

Observed behaviour, failure handling and reproducible test results.

A list of IDE plugins.

Reference: Observed behaviour, failure handling and reproducible test results. — Compilation checks syntax and types, while runtime, integration and operational claims require observed evidence.

Sources:

Java: learning and JDK tools: https://dev.java/learn/

### Concurrency and evidence

Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy. In this role, work through: After 100 concurrent creates, count must equal collection size and all IDs must be unique. The practical workshop develops this into: Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.

Mental model: Two clerks updating the same inventory ledger.

Boundary: An atomic counter protects one value, not a multi-record transaction.

Role application: Two ledgers must balance together even when two clerks work simultaneously.

AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage.

Worked example: After 100 concurrent creates, count must equal collection size and all IDs must be unique.

Shared foundation example: AtomicInteger increments are safe for this counter; ticket plus payment needs a wider transaction boundary.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Java Developer: After 100 concurrent creates, count must equal collection size and all IDs must be unique.

Predict the worked case

Read this case without running a tool: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in concurrency and evidence.

Connect the concept to the role

Apply this rule: Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An atomic counter protects one value, not a multi-record transaction.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies concurrency and evidence to this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Concurrency and evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with concurrency and evidence. Use the glossary below, then write your prediction for: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain concurrency and evidence using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate concurrency and evidence to a system or workflow you know. Explain concurrency and evidence using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is an atomic counter insufficient for an order and its payment?

Interview: Explain concurrency and evidence using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops.

Quiz: After the Concurrent invariants rehearsal, check this foundation: An atomic counter is correct under concurrency. Does that prove a separate multi-record operation is atomic?

Yes, because both use the same language runtime.

Yes, if each record increments a counter.

No; the multi-record invariant needs its own coordination boundary.

Reference: No; the multi-record invariant needs its own coordination boundary. — Safety of one atomic operation does not compose automatically into a transaction spanning multiple effects.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

### Concurrent invariants

AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage. In this role, work through: After 100 concurrent creates, count must equal collection size and all IDs must be unique. The practical workshop develops this into: Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.

Mental model: Two ledgers must balance together even when two clerks work simultaneously.

Boundary: Do not read the count before all futures complete; this can make a correct implementation appear racy.

Worked example: After 100 concurrent creates, count must equal collection size and all IDs must be unique.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Java Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.

Trace the typed rule

Open TicketService.java and locate the title validator and main method.

Expected: You can predict normal, blank and oversized title outcomes.

Execute the level checks

Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.

```
java TicketService.java test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS java advanced

Inspect a failure

In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.

Expected: Your rejection case is exercised; explain what part of the contract changed.

Role workshop · predict

After 100 concurrent creates, count must equal collection size and all IDs must be unique. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.

```
java TicketService.java test advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Role workshop · debug and verify

Do not read the count before all futures complete; this can make a correct implementation appear racy. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save concurrency test, invariant definition and persistence limitations. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Expected: 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Troubleshoot: The role exercise differs from the prediction: Do not read the count before all futures complete; this can make a correct implementation appear racy.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: concurrency test, invariant definition and persistence limitations; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with concurrent invariants. Use the glossary below, then write your prediction for: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain concurrent invariants using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate concurrent invariants to a system or workflow you know. Explain concurrent invariants using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not read the count before all futures complete; this can make a correct implementation appear racy.

Interview: Explain concurrent invariants using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? After 100 concurrent creates, count must equal collection size and all IDs must be unique.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Reference: 100 successful creates and 100 unique records; executor is shut down even on assertion failure. — AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage. 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html
