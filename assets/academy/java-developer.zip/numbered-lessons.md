# Java Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Types and contracts: A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on.

Apply types and contracts in Java Developer: Use the concept to complete this role exercise: Run the Java title validator and explain types and exceptions

Value objects and exceptions: Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass.

### Types and contracts

A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on. In this role, work through: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. The practical workshop develops this into: Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.

Mental model: A labeled socket that accepts the correct plug.

Boundary: A correct type does not prove a meaningful value; an empty String is still a String.

Role application: A stamped ticket proves it passed the entry desk before other staff use it.

Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass.

Worked example: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.

Shared foundation example: title(" Learn ") returns "Learn"; title("") throws an error.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Java Developer: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.

Predict the worked case

Read this case without running a tool: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in types and contracts.

Connect the concept to the role

Apply this rule: A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A correct type does not prove a meaningful value; an empty String is still a String.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies types and contracts to this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Types and contracts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with types and contracts. Use the glossary below, then write your prediction for: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain types and contracts using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate types and contracts to a system or workflow you know. Explain types and contracts using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What must be checked beyond the String type?

Interview: Explain types and contracts using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops.

Quiz: After the Value objects and exceptions rehearsal, check this foundation: A value has the required integer type but is outside the allowed business range. What is missing?

A domain validation rule in addition to the type check.

A cast to another integer type regardless of range.

A longer variable name so the caller understands it.

Reference: A domain validation rule in addition to the type check. — Type correctness and business validity are different parts of a contract.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

### Value objects and exceptions

Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass. In this role, work through: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. The practical workshop develops this into: Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.

Mental model: A stamped ticket proves it passed the entry desk before other staff use it.

Boundary: If different handlers disagree, check for duplicated validation rather than changing each handler separately.

Worked example: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Java Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.

Trace the typed rule

Open TicketService.java and locate the title validator and main method.

Expected: You can predict normal, blank and oversized title outcomes.

Execute the level checks

Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.

```
java TicketService.java test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS java beginner

Inspect a failure

In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.

Expected: Your rejection case is exercised; explain what part of the contract changed.

Role workshop · predict

TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.

```
java TicketService.java test beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Three deterministic cases; no invalid title instance escapes construction.

Role workshop · debug and verify

If different handlers disagree, check for duplicated validation rather than changing each handler separately. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save value-type code and validation test table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Three deterministic cases; no invalid title instance escapes construction.

Expected: Three deterministic cases; no invalid title instance escapes construction.

Troubleshoot: The role exercise differs from the prediction: If different handlers disagree, check for duplicated validation rather than changing each handler separately.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: value-type code and validation test table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with value objects and exceptions. Use the glossary below, then write your prediction for: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain value objects and exceptions using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate value objects and exceptions to a system or workflow you know. Explain value objects and exceptions using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If different handlers disagree, check for duplicated validation rather than changing each handler separately.

Interview: Explain value objects and exceptions using this case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.

Three deterministic cases; no invalid title instance escapes construction.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Three deterministic cases; no invalid title instance escapes construction. — Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass. Three deterministic cases; no invalid title instance escapes construction.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Service boundary: An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport.

Apply service boundary in Java Developer: Use the concept to complete this role exercise: Trace HTTP handlers and separate service logic

Dependency boundaries in Java: Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port.

### Service boundary

An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport. In this role, work through: A failing repository should produce a controlled service failure rather than a false success count. The practical workshop develops this into: Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.

Mental model: A receptionist translates a visitor request for the right team.

Boundary: Framework annotations do not automatically enforce every business rule.

Role application: A receptionist, decision maker and records clerk each have a different responsibility.

Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port.

Worked example: A failing repository should produce a controlled service failure rather than a false success count.

Shared foundation example: POST /tickets receives text and creates a ticket; GET returns the count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Java Developer: A failing repository should produce a controlled service failure rather than a false success count.

Predict the worked case

Read this case without running a tool: A failing repository should produce a controlled service failure rather than a false success count. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in service boundary.

Connect the concept to the role

Apply this rule: An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Framework annotations do not automatically enforce every business rule.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies service boundary to this case: A failing repository should produce a controlled service failure rather than a false success count. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A failing repository should produce a controlled service failure rather than a false success count. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Service boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with service boundary. Use the glossary below, then write your prediction for: A failing repository should produce a controlled service failure rather than a false success count. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain service boundary using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate service boundary to a system or workflow you know. Explain service boundary using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Where should title validation live if two endpoints create tickets?

Interview: Explain service boundary using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops.

Quiz: After the Dependency boundaries in Java rehearsal, check this foundation: An HTTP handler validates JSON, but the same rule is needed by a batch job. Where should the shared business rule live?

Only in the HTTP status-code mapping.

In a testable domain operation called by both adapters.

In duplicated handler code maintained independently.

Reference: In a testable domain operation called by both adapters. — Transport adapters translate inputs and outputs; shared business behavior should have a clear reusable boundary.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

### Dependency boundaries in Java

Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port. In this role, work through: A failing repository should produce a controlled service failure rather than a false success count. The practical workshop develops this into: Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.

Mental model: A receptionist, decision maker and records clerk each have a different responsibility.

Boundary: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.

Worked example: A failing repository should produce a controlled service failure rather than a false success count.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Java Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.

Trace the typed rule

Open TicketService.java and locate the title validator and main method.

Expected: You can predict normal, blank and oversized title outcomes.

Execute the level checks

Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.

```
java TicketService.java test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS java intermediate

Inspect a failure

In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.

Expected: Your rejection case is exercised; explain what part of the contract changed.

Role workshop · predict

A failing repository should produce a controlled service failure rather than a false success count. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.

```
java TicketService.java test intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Business tests run without networking; repository failure does not report creation.

Role workshop · debug and verify

A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save service-boundary diagram and Java tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Business tests run without networking; repository failure does not report creation.

Expected: Business tests run without networking; repository failure does not report creation.

Troubleshoot: The role exercise differs from the prediction: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: service-boundary diagram and Java tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with dependency boundaries in java. Use the glossary below, then write your prediction for: A failing repository should produce a controlled service failure rather than a false success count. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain dependency boundaries in java using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate dependency boundaries in java to a system or workflow you know. Explain dependency boundaries in java using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.

Interview: Explain dependency boundaries in java using this case: A failing repository should produce a controlled service failure rather than a false success count. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A failing repository should produce a controlled service failure rather than a false success count.

Ignore the failing case and keep only the successful screenshot.

Business tests run without networking; repository failure does not report creation.

Treat any successful command as proof that all business and access rules passed.

Reference: Business tests run without networking; repository failure does not report creation. — Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port. Business tests run without networking; repository failure does not report creation.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Concurrency and evidence: Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy.

Apply concurrency and evidence in Java Developer: Use the concept to complete this role exercise: Test concurrent counter changes and explain transaction boundaries

Concurrent invariants: AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage.

### Concurrency and evidence

Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy. In this role, work through: After 100 concurrent creates, count must equal collection size and all IDs must be unique. The practical workshop develops this into: Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.

Mental model: Two clerks updating the same inventory ledger.

Boundary: An atomic counter protects one value, not a multi-record transaction.

Role application: Two ledgers must balance together even when two clerks work simultaneously.

AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage.

Worked example: After 100 concurrent creates, count must equal collection size and all IDs must be unique.

Shared foundation example: AtomicInteger increments are safe for this counter; ticket plus payment needs a wider transaction boundary.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Java Developer: After 100 concurrent creates, count must equal collection size and all IDs must be unique.

Predict the worked case

Read this case without running a tool: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in concurrency and evidence.

Connect the concept to the role

Apply this rule: Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An atomic counter protects one value, not a multi-record transaction.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies concurrency and evidence to this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Concurrency and evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with concurrency and evidence. Use the glossary below, then write your prediction for: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain concurrency and evidence using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate concurrency and evidence to a system or workflow you know. Explain concurrency and evidence using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is an atomic counter insufficient for an order and its payment?

Interview: Explain concurrency and evidence using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops.

Quiz: After the Concurrent invariants rehearsal, check this foundation: An atomic counter is correct under concurrency. Does that prove a separate multi-record operation is atomic?

Yes, because both use the same language runtime.

Yes, if each record increments a counter.

No; the multi-record invariant needs its own coordination boundary.

Reference: No; the multi-record invariant needs its own coordination boundary. — Safety of one atomic operation does not compose automatically into a transaction spanning multiple effects.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

### Concurrent invariants

AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage. In this role, work through: After 100 concurrent creates, count must equal collection size and all IDs must be unique. The practical workshop develops this into: Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.

Mental model: Two ledgers must balance together even when two clerks work simultaneously.

Boundary: Do not read the count before all futures complete; this can make a correct implementation appear racy.

Worked example: After 100 concurrent creates, count must equal collection size and all IDs must be unique.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OpenJDK and Java HTTP server (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Java Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.

Trace the typed rule

Open TicketService.java and locate the title validator and main method.

Expected: You can predict normal, blank and oversized title outcomes.

Execute the level checks

Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.

```
java TicketService.java test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS java advanced

Inspect a failure

In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.

Expected: Your rejection case is exercised; explain what part of the contract changed.

Role workshop · predict

After 100 concurrent creates, count must equal collection size and all IDs must be unique. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.

```
java TicketService.java test advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Role workshop · debug and verify

Do not read the count before all futures complete; this can make a correct implementation appear racy. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save concurrency test, invariant definition and persistence limitations. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Expected: 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Troubleshoot: The role exercise differs from the prediction: Do not read the count before all futures complete; this can make a correct implementation appear racy.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: concurrency test, invariant definition and persistence limitations; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with concurrent invariants. Use the glossary below, then write your prediction for: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Developer role interview. Explain concurrent invariants using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate concurrent invariants to a system or workflow you know. Explain concurrent invariants using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not read the count before all futures complete; this can make a correct implementation appear racy.

Interview: Explain concurrent invariants using this case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? After 100 concurrent creates, count must equal collection size and all IDs must be unique.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Reference: 100 successful creates and 100 unique records; executor is shut down even on assertion failure. — AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage. 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Sources:

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html
