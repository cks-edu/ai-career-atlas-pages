# Java Developer

Software Engineering

Start with value objects and exceptions. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward concurrency test, invariant definition and persistence limitations.

## beginner

Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Types and contracts
A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on.
Mental model: A labeled socket that accepts the correct plug.
Limit: A correct type does not prove a meaningful value; an empty String is still a String.
Example: title(" Learn ") returns "Learn"; title("") throws an error.
Recall: What must be checked beyond the String type?

### Value objects and exceptions
Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass.
Mental model: A stamped ticket proves it passed the entry desk before other staff use it.
Limit: If different handlers disagree, check for duplicated validation rather than changing each handler separately.
Example: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If different handlers disagree, check for duplicated validation rather than changing each handler separately.

1. Trace the typed rule
Open TicketService.java and locate the title validator and main method.
Expected: You can predict normal, blank and oversized title outcomes.

2. Execute the level checks
Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.
```
java TicketService.java test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS java beginner

3. Inspect a failure
In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.
Expected: Your rejection case is exercised; explain what part of the contract changed.

4. Role workshop · predict
TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.
```
java TicketService.java test beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Three deterministic cases; no invalid title instance escapes construction.

6. Role workshop · debug and verify
If different handlers disagree, check for duplicated validation rather than changing each handler separately. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save value-type code and validation test table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Three deterministic cases; no invalid title instance escapes construction.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Value objects and exceptions: If different handlers disagree, check for duplicated validation rather than changing each handler separately.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: value-type code and validation test table
Three deterministic cases; no invalid title instance escapes construction.

Interview: Work through this Java Developer case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass. Expected evidence: Three deterministic cases; no invalid title instance escapes construction. Diagnosis: If different handlers disagree, check for duplicated validation rather than changing each handler separately. State the limits of the mental model: A stamped ticket proves it passed the entry desk before other staff use it.

Resume: Built value-type code and validation test table using OpenJDK and Java HTTP server; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Service boundary
An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport.
Mental model: A receptionist translates a visitor request for the right team.
Limit: Framework annotations do not automatically enforce every business rule.
Example: POST /tickets receives text and creates a ticket; GET returns the count.
Recall: Where should title validation live if two endpoints create tickets?

### Dependency boundaries in Java
Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port.
Mental model: A receptionist, decision maker and records clerk each have a different responsibility.
Limit: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.
Example: A failing repository should produce a controlled service failure rather than a false success count.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.

1. Trace the typed rule
Open TicketService.java and locate the title validator and main method.
Expected: You can predict normal, blank and oversized title outcomes.

2. Execute the level checks
Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.
```
java TicketService.java test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS java intermediate

3. Inspect a failure
In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.
Expected: Your rejection case is exercised; explain what part of the contract changed.

4. Role workshop · predict
A failing repository should produce a controlled service failure rather than a false success count. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.
```
java TicketService.java test intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Business tests run without networking; repository failure does not report creation.

6. Role workshop · debug and verify
A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save service-boundary diagram and Java tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Business tests run without networking; repository failure does not report creation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Dependency boundaries in Java: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: service-boundary diagram and Java tests
Business tests run without networking; repository failure does not report creation.

Interview: Work through this Java Developer case: A failing repository should produce a controlled service failure rather than a false success count. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port. Expected evidence: Business tests run without networking; repository failure does not report creation. Diagnosis: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor. State the limits of the mental model: A receptionist, decision maker and records clerk each have a different responsibility.

Resume: Built service-boundary diagram and Java tests using OpenJDK and Java HTTP server; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Concurrency and evidence
Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy.
Mental model: Two clerks updating the same inventory ledger.
Limit: An atomic counter protects one value, not a multi-record transaction.
Example: AtomicInteger increments are safe for this counter; ticket plus payment needs a wider transaction boundary.
Recall: Why is an atomic counter insufficient for an order and its payment?

### Concurrent invariants
AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage.
Mental model: Two ledgers must balance together even when two clerks work simultaneously.
Limit: Do not read the count before all futures complete; this can make a correct implementation appear racy.
Example: After 100 concurrent creates, count must equal collection size and all IDs must be unique.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not read the count before all futures complete; this can make a correct implementation appear racy.

1. Trace the typed rule
Open TicketService.java and locate the title validator and main method.
Expected: You can predict normal, blank and oversized title outcomes.

2. Execute the level checks
Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.
```
java TicketService.java test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS java advanced

3. Inspect a failure
In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.
Expected: Your rejection case is exercised; explain what part of the contract changed.

4. Role workshop · predict
After 100 concurrent creates, count must equal collection size and all IDs must be unique. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.
```
java TicketService.java test advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

6. Role workshop · debug and verify
Do not read the count before all futures complete; this can make a correct implementation appear racy. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save concurrency test, invariant definition and persistence limitations. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: 100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Concurrent invariants: Do not read the count before all futures complete; this can make a correct implementation appear racy.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: concurrency test, invariant definition and persistence limitations
100 successful creates and 100 unique records; executor is shut down even on assertion failure.

Interview: Work through this Java Developer case: After 100 concurrent creates, count must equal collection size and all IDs must be unique. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage. Expected evidence: 100 successful creates and 100 unique records; executor is shut down even on assertion failure. Diagnosis: Do not read the count before all futures complete; this can make a correct implementation appear racy. State the limits of the mental model: Two ledgers must balance together even when two clerks work simultaneously.

Resume: Built concurrency test, invariant definition and persistence limitations using OpenJDK and Java HTTP server; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
dev.java: learn Java: https://dev.java/learn/
Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/
Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html
