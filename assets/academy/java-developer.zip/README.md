# Java Developer

Software Engineering

Begin with types and contracts. Run the Java title validator and explain types and exceptions. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Run the Java title validator and explain types and exceptions

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies.

### Types and contracts
A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on.
Mental model: A labeled socket that accepts the correct plug.
Limit: A correct type does not prove a meaningful value; an empty String is still a String.
Example: title(" Learn ") returns "Learn"; title("") throws an error.
Recall: What must be checked beyond the String type?

### Apply types and contracts in Java Developer
Use the concept to complete this role exercise: Run the Java title validator and explain types and exceptions
Mental model: A labeled socket that accepts the correct plug.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: title(" Learn ") returns "Learn"; title("") throws an error. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Trace the typed rule
Open TicketService.java and locate the title validator and main method.
Expected: You can predict normal, blank and oversized title outcomes.

2. Execute the level checks
Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.
```
java TicketService.java test beginner
```
Expected: PASS java beginner

3. Inspect a failure
In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.
Expected: Your rejection case is exercised; explain what part of the contract changed.

4. Apply the role exercise
Run the Java title validator and explain types and exceptions
Expected: Save code or a decision record with examples, tests and limitations.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: java-developer-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Run the Java title validator and explain types and exceptions? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on. For this role, explicitly address: Run the Java title validator and explain types and exceptions.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Trace HTTP handlers and separate service logic

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies.

### Service boundary
An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport.
Mental model: A receptionist translates a visitor request for the right team.
Limit: Framework annotations do not automatically enforce every business rule.
Example: POST /tickets receives text and creates a ticket; GET returns the count.
Recall: Where should title validation live if two endpoints create tickets?

### Apply service boundary in Java Developer
Use the concept to complete this role exercise: Trace HTTP handlers and separate service logic
Mental model: A receptionist translates a visitor request for the right team.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: POST /tickets receives text and creates a ticket; GET returns the count. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Trace the typed rule
Open TicketService.java and locate the title validator and main method.
Expected: You can predict normal, blank and oversized title outcomes.

2. Execute the level checks
Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.
```
java TicketService.java test intermediate
```
Expected: PASS java intermediate

3. Inspect a failure
In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.
Expected: Your rejection case is exercised; explain what part of the contract changed.

4. Apply the role exercise
Trace HTTP handlers and separate service logic
Expected: Save code or a decision record with examples, tests and limitations.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: java-developer-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Trace HTTP handlers and separate service logic? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport. For this role, explicitly address: Trace HTTP handlers and separate service logic.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Test concurrent counter changes and explain transaction boundaries

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies.

### Concurrency and evidence
Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy.
Mental model: Two clerks updating the same inventory ledger.
Limit: An atomic counter protects one value, not a multi-record transaction.
Example: AtomicInteger increments are safe for this counter; ticket plus payment needs a wider transaction boundary.
Recall: Why is an atomic counter insufficient for an order and its payment?

### Apply concurrency and evidence in Java Developer
Use the concept to complete this role exercise: Test concurrent counter changes and explain transaction boundaries
Mental model: Two clerks updating the same inventory ledger.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: AtomicInteger increments are safe for this counter; ticket plus payment needs a wider transaction boundary. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Trace the typed rule
Open TicketService.java and locate the title validator and main method.
Expected: You can predict normal, blank and oversized title outcomes.

2. Execute the level checks
Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.
```
java TicketService.java test advanced
```
Expected: PASS java advanced

3. Inspect a failure
In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.
Expected: Your rejection case is exercised; explain what part of the contract changed.

4. Apply the role exercise
Test concurrent counter changes and explain transaction boundaries
Expected: Save code or a decision record with examples, tests and limitations.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: java-developer-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Test concurrent counter changes and explain transaction boundaries? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy. For this role, explicitly address: Test concurrent counter changes and explain transaction boundaries.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
dev.java: learn Java: https://dev.java/learn/
Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/
Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html
