import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
class Input { static OptionalInt id(String value) {
 try { int id=Integer.parseInt(value); return id>0?OptionalInt.of(id):OptionalInt.empty(); }
 catch (NumberFormatException e) { return OptionalInt.empty(); }
} }
check(Input.id("7").orElseThrow()==7); check(Input.id("x").isEmpty()); check(Input.id("0").isEmpty());
 System.out.println("PASS: java-exceptions");
 }
}
