import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
List<String> input = List.of(" Read "," ","Build");
List<String> result = input.stream().map(String::strip).filter(s -> !s.isEmpty()).toList();
check(result.equals(List.of("Read","Build"))); check(input.get(0).equals(" Read "));
 System.out.println("PASS: java-streams");
 }
}
