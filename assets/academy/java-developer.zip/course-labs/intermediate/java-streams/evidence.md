# Streams: express a data transformation

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/util/stream/Stream.html
