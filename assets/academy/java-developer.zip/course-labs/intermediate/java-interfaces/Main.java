import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
interface Tasks { Optional<String> find(int id); }
class Service { private final Tasks tasks; Service(Tasks tasks){this.tasks=tasks;} String title(int id){return tasks.find(id).orElse("Missing");} }
Tasks fake = id -> id==1?Optional.of("Read"):Optional.empty();
Service service = new Service(fake); check(service.title(1).equals("Read")); check(service.title(2).equals("Missing"));
 System.out.println("PASS: java-interfaces");
 }
}
