import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
List<String> original = new ArrayList<>(List.of("Read","Build"));
List<String> copy = new ArrayList<>(original); copy.add("Test");
check(original.size()==2); check(copy.size()==3);
// original.add(7); // Uncomment: compilation must fail, then restore.

 System.out.println("PASS: java-generics");
 }
}
