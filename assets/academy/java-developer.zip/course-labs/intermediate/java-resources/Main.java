import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
class Resource implements AutoCloseable { boolean closed; public void close(){closed=true;} }
Resource resource = new Resource();
try (Resource opened = resource) { throw new IllegalStateException("Injected"); }
catch (IllegalStateException expected) { check(expected.getMessage().equals("Injected")); }
check(resource.closed);
 System.out.println("PASS: java-resources");
 }
}
