# Resource ownership: close what you open

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html
