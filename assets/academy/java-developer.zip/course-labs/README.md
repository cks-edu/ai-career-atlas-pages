# Java Developer — core lessons

Start with Java values, control flow, methods, objects and collections. Continue to generics, streams and resource ownership, then concurrency, interruption and release evidence. The local examples require a JDK, not a paid IDE.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A tested Java task CLI or service with explicit validation, repository boundary, resource lifecycle and concurrency policy.
