import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
BigDecimal a=new BigDecimal("0.10"), b=new BigDecimal("0.20");
check(a.add(b).compareTo(new BigDecimal("0.30"))==0);
check(new BigDecimal("1.0").compareTo(new BigDecimal("1.00"))==0);
check(!new BigDecimal("1.0").equals(new BigDecimal("1.00")));
 System.out.println("PASS: java-decimals");
 }
}
