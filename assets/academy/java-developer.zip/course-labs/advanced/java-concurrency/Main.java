import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
java.util.concurrent.atomic.AtomicInteger count = new java.util.concurrent.atomic.AtomicInteger();
ExecutorService pool = Executors.newFixedThreadPool(4);
try { List<Future<?>> jobs = new ArrayList<>();
 for(int i=0;i<100;i++) jobs.add(pool.submit(count::incrementAndGet));
 for(Future<?> job:jobs) job.get(); check(count.get()==100);
} finally { pool.shutdown(); check(pool.awaitTermination(5,TimeUnit.SECONDS)); }
 System.out.println("PASS: java-concurrency");
 }
}
