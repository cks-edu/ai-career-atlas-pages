import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
ExecutorService pool=Executors.newSingleThreadExecutor();
CountDownLatch started=new CountDownLatch(1), stopped=new CountDownLatch(1);
try {
 Future<?> job=pool.submit(()->{started.countDown();try{Thread.sleep(10000);}catch(InterruptedException e){Thread.currentThread().interrupt();}finally{stopped.countDown();}});
 check(started.await(2,TimeUnit.SECONDS)); job.cancel(true); check(stopped.await(2,TimeUnit.SECONDS));
}finally{pool.shutdownNow();check(pool.awaitTermination(5,TimeUnit.SECONDS));}
 System.out.println("PASS: java-cancellation");
 }
}
