import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
record Batch(List<String> titles) { Batch { titles = List.copyOf(titles); } }
List<String> source = new ArrayList<>(List.of("Read")); Batch batch = new Batch(source);
source.add("Build"); check(batch.titles().size()==1);
boolean blocked=false; try{batch.titles().add("Oops");}catch(UnsupportedOperationException e){blocked=true;} check(blocked);
 System.out.println("PASS: java-immutability");
 }
}
