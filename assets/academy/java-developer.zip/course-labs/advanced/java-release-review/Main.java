import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
Set<String> required=Set.of("unit","integration","invalid-input","shutdown","recovery");
Map<String,Boolean> report=new HashMap<>();for(String name:required)report.put(name,true);
check(required.stream().allMatch(name->Boolean.TRUE.equals(report.get(name))));
report.remove("shutdown");check(!required.stream().allMatch(name->Boolean.TRUE.equals(report.get(name))));
 System.out.println("PASS: java-release-review");
 }
}
