import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
class Titles { static String clean(String value) {
 if (value == null || value.isBlank()) throw new IllegalArgumentException("Title required");
 return value.strip();
} }
check(Titles.clean(" Read ").equals("Read"));
boolean rejected = false;
try { Titles.clean(" "); } catch (IllegalArgumentException e) { rejected = true; }
check(rejected);
 System.out.println("PASS: java-methods");
 }
}
