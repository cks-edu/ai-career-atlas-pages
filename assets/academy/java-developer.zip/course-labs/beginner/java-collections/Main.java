import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
Map<Integer,String> tasks = new HashMap<>();
tasks.put(1,"Draft"); tasks.put(1,"Read");
check(tasks.size()==1); check(tasks.get(1).equals("Read")); check(!tasks.containsKey(2));
List<String> ordered = List.of("First","Second"); check(ordered.get(0).equals("First"));
 System.out.println("PASS: java-collections");
 }
}
