import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
int total = 5, count = 2;
check(total / count == 2);
check(total / (double) count == 2.5);
String title = new String("Read");
check(title.equals("Read"));
 System.out.println("PASS: java-values");
 }
}
