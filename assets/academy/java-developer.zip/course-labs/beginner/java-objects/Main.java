import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
class Task {
 private final String title; private boolean done;
 Task(String title) { if(title == null || title.isBlank()) throw new IllegalArgumentException(); this.title=title; }
 void complete() { done=true; }
 boolean isDone() { return done; }
}
Task task = new Task("Read"); check(!task.isDone()); task.complete(); check(task.isDone());
 System.out.println("PASS: java-objects");
 }
}
