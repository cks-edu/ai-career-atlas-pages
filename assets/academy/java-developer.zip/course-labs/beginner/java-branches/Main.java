import java.util.*;
import java.util.concurrent.*;
import java.math.BigDecimal;
public class Main {
 static void check(boolean ok) { if (!ok) throw new IllegalStateException("Check failed"); }
 public static void main(String[] args) throws Exception {
List<String> titles = Arrays.asList("Read", " ", null, "Build");
int valid = 0;
for (String title : titles) { if (title != null && !title.isBlank()) valid++; }
check(valid == 2);
 System.out.println("PASS: java-branches");
 }
}
