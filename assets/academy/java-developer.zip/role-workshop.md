# Java Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Value objects and exceptions

Represent validated business values at the boundary. A String type permits blanks, so validation belongs in a constructor or factory that callers cannot accidentally bypass.
Mental model: A stamped ticket proves it passed the entry desk before other staff use it.
Case: TicketTitle.of(" Learn ") should contain Learn; blank input should raise a named validation error.
Task: Extract the title rule from TicketService.java into a small immutable value type. Add normal, blank and overlong cases in the existing source-file test runner. Keep HTTP status mapping outside the value type.
Acceptance: Three deterministic cases; no invalid title instance escapes construction.
Troubleshooting: If different handlers disagree, check for duplicated validation rather than changing each handler separately.
Deliverable: value-type code and validation test table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Dependency boundaries in Java

Separate transport parsing, business decisions and persistence behind narrow interfaces. This allows a fake repository to test business rules without opening an HTTP port.
Mental model: A receptionist, decision maker and records clerk each have a different responsibility.
Case: A failing repository should produce a controlled service failure rather than a false success count.
Task: Create TicketRepository and TicketService classes, inject an in-memory implementation and a failing fake. Have the HTTP handler translate service outcomes to statuses. Test both fakes before running the server.
Acceptance: Business tests run without networking; repository failure does not report creation.
Troubleshooting: A fake that is never used suggests a hidden new Repository call inside the service; inject the dependency through its constructor.
Deliverable: service-boundary diagram and Java tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Concurrent invariants

AtomicInteger protects a single update, not a multi-field invariant. Updating a ticket count and a ticket collection requires a shared atomic boundary or transactional storage.
Mental model: Two ledgers must balance together even when two clerks work simultaneously.
Case: After 100 concurrent creates, count must equal collection size and all IDs must be unique.
Task: Replace the counter-only example with a synchronized in-memory repository. Use ExecutorService and wait for every task; capture exceptions. Assert unique IDs and matching counts, then explain how a database transaction changes the design.
Acceptance: 100 successful creates and 100 unique records; executor is shut down even on assertion failure.
Troubleshooting: Do not read the count before all futures complete; this can make a correct implementation appear racy.
Deliverable: concurrency test, invariant definition and persistence limitations

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
