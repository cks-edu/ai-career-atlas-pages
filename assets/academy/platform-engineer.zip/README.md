# Platform Engineer

Software Engineering

Begin with desired state. Publish a repeatable local service template. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Publish a repeatable local service template

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### Platform as an internal product
A platform provides supported ways for teams to build and operate software. Identify the developer task it should simplify.
Mental model: A workshop supplies safe benches, tools and instructions while teams choose what to build.
Limit: A platform is not valuable merely because it runs Kubernetes.
Example: Give a developer one documented way to start, inspect and remove the local service.
Recall: How would you measure whether the template actually reduces developer effort?

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course
kubectl --context kind-atlas-course create namespace atlas-lab
kubectl --context kind-atlas-course apply -f deployment.yaml
kubectl --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Apply the role exercise
Publish a repeatable local service template
Expected: Save architecture, diagnostic or CI evidence with the actual environment and untested parts clearly identified.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course. This deletes that local learning cluster and its lab data only.

Portfolio: platform-engineer-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Publish a repeatable local service template? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A controller compares the current system with a declared target and works to reconcile the difference. For this role, explicitly address: Publish a repeatable local service template.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Add resource requests, readiness and a developer troubleshooting page

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Golden path and escape hatch
A golden path is a supported default with clear boundaries. An escape hatch handles legitimate needs outside that default with explicit ownership.
Mental model: A marked hiking route has signposts and a process for approved detours.
Limit: Defaults cannot eliminate every team-specific requirement.
Example: Provide resource, readiness and telemetry defaults, then document how a team requests a different runtime.
Recall: What should remain mandatory even when a team takes an alternative path?

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course
kubectl --context kind-atlas-course create namespace atlas-lab
kubectl --context kind-atlas-course apply -f deployment.yaml
kubectl --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Apply the role exercise
Add resource requests, readiness and a developer troubleshooting page
Expected: Save architecture, diagnostic or CI evidence with the actual environment and untested parts clearly identified.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course. This deletes that local learning cluster and its lab data only.

Portfolio: platform-engineer-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Add resource requests, readiness and a developer troubleshooting page? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. For this role, explicitly address: Add resource requests, readiness and a developer troubleshooting page.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Design tenant boundaries, self-service guardrails and platform adoption metrics

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Multi-tenancy and platform reliability
Shared platforms need tenant isolation, capacity policies, upgrade plans and service objectives of their own.
Mental model: An apartment building shares utilities but separates rooms, meters and responsibilities.
Limit: Namespaces alone are not complete security isolation.
Example: Specify quota, identity, network boundaries and a test tenant for an upgrade rehearsal.
Recall: How would you stop one team's workload from consuming every shared resource?

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course
kubectl --context kind-atlas-course create namespace atlas-lab
kubectl --context kind-atlas-course apply -f deployment.yaml
kubectl --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --context kind-atlas-course -n atlas-lab get pods
kubectl --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Apply the role exercise
Design tenant boundaries, self-service guardrails and platform adoption metrics
Expected: Save architecture, diagnostic or CI evidence with the actual environment and untested parts clearly identified.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course. This deletes that local learning cluster and its lab data only.

Portfolio: platform-engineer-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Design tenant boundaries, self-service guardrails and platform adoption metrics? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. For this role, explicitly address: Design tenant boundaries, self-service guardrails and platform adoption metrics.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
Google SRE book: https://sre.google/sre-book/table-of-contents/
