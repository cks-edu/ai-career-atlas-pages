# Platform Engineer

Software Engineering

Start with developer experience as a product. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward tenant threat model and platform upgrade runbook.

## beginner

Use the kind template as a first golden path. Write a quick start, give it a clean-room walkthrough and record commands, time and every point of confusion.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### Developer experience as a product
A platform offers a supported path for a concrete developer task. Document inputs, defaults, ownership and escape routes rather than assuming every team benefits from Kubernetes.
Mental model: A well-run workshop gives visitors usable benches and instructions, not just a room full of tools.
Limit: A working author's machine is not onboarding evidence; repeat from an extracted clean pack.
Example: A new developer should start, inspect and stop one service without undocumented steps.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A working author's machine is not onboarding evidence; repeat from an extracted clean pack.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
A new developer should start, inspect and stop one service without undocumented steps. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use the kind template as a first golden path. Write a quick start, give it a clean-room walkthrough and record commands, time and every point of confusion.
Expected: A repeatable first service with explicit requirements and cleanup.

6. Role workshop · debug and verify
A working author's machine is not onboarding evidence; repeat from an extracted clean pack. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save golden-path quick start and friction log. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A repeatable first service with explicit requirements and cleanup.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Developer experience as a product: A working author's machine is not onboarding evidence; repeat from an extracted clean pack.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: golden-path quick start and friction log
A repeatable first service with explicit requirements and cleanup.

Interview: Work through this Platform Engineer case: A new developer should start, inspect and stop one service without undocumented steps. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A platform offers a supported path for a concrete developer task. Document inputs, defaults, ownership and escape routes rather than assuming every team benefits from Kubernetes. Expected evidence: A repeatable first service with explicit requirements and cleanup. Diagnosis: A working author's machine is not onboarding evidence; repeat from an extracted clean pack. State the limits of the mental model: A well-run workshop gives visitors usable benches and instructions, not just a room full of tools.

Resume: Built golden-path quick start and friction log using Kubernetes and kind; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

In the disposable namespace create a ResourceQuota, inspect current usage and try an over-budget workload. Capture the admission error, then reduce the request to fit and verify readiness.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Resource guardrails
Requests influence scheduling, limits bound runtime resources and quotas constrain namespace totals. Defaults need explanation and tests for both valid workloads and rejected configurations.
Mental model: An apartment has room capacity, appliance limits and a building-wide utility budget.
Limit: Quotas are not network or identity isolation; document those separately.
Example: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Quotas are not network or identity isolation; document those separately.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
In the disposable namespace create a ResourceQuota, inspect current usage and try an over-budget workload. Capture the admission error, then reduce the request to fit and verify readiness.
Expected: A clear rejection followed by a supported configuration that runs.

6. Role workshop · debug and verify
Quotas are not network or identity isolation; document those separately. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save quota manifest, error guide and resource request policy. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A clear rejection followed by a supported configuration that runs.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Resource guardrails: Quotas are not network or identity isolation; document those separately.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: quota manifest, error guide and resource request policy
A clear rejection followed by a supported configuration that runs.

Interview: Work through this Platform Engineer case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Requests influence scheduling, limits bound runtime resources and quotas constrain namespace totals. Defaults need explanation and tests for both valid workloads and rejected configurations. Expected evidence: A clear rejection followed by a supported configuration that runs. Diagnosis: Quotas are not network or identity isolation; document those separately. State the limits of the mental model: An apartment has room capacity, appliance limits and a building-wide utility budget.

Resume: Built quota manifest, error guide and resource request policy using Kubernetes and kind; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Design two test tenants, write an RBAC matrix and use kubectl auth can-i with authorized impersonation in a disposable cluster. Record network-policy enforcement prerequisites and an upgrade canary plan.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Tenant isolation and upgrade evidence
Namespaces organize workloads but do not alone establish strong isolation. Combine identity, policy enforcement, resource controls and a tested upgrade route appropriate to the threat model.
Mental model: Separate apartment numbers do not replace locks, meters and fire doors.
Limit: A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation.
Example: One team's service account must not list another team's secrets.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation.

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Role workshop · predict
One team's service account must not list another team's secrets. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Design two test tenants, write an RBAC matrix and use kubectl auth can-i with authorized impersonation in a disposable cluster. Record network-policy enforcement prerequisites and an upgrade canary plan.
Expected: Explicit allow/deny evidence and an honest list of controls not exercised by local kind.

6. Role workshop · debug and verify
A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save tenant threat model and platform upgrade runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Explicit allow/deny evidence and an honest list of controls not exercised by local kind.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Tenant isolation and upgrade evidence: A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: tenant threat model and platform upgrade runbook
Explicit allow/deny evidence and an honest list of controls not exercised by local kind.

Interview: Work through this Platform Engineer case: One team's service account must not list another team's secrets. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Namespaces organize workloads but do not alone establish strong isolation. Combine identity, policy enforcement, resource controls and a tested upgrade route appropriate to the threat model. Expected evidence: Explicit allow/deny evidence and an honest list of controls not exercised by local kind. Diagnosis: A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation. State the limits of the mental model: Separate apartment numbers do not replace locks, meters and fire doors.

Resume: Built tenant threat model and platform upgrade runbook using Kubernetes and kind; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
Google SRE book: https://sre.google/sre-book/table-of-contents/
Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/
