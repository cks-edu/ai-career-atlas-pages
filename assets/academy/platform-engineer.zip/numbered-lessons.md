# Platform Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Desired state: A controller compares the current system with a declared target and works to reconcile the difference.

Platform as an internal product: A platform provides supported ways for teams to build and operate software. Identify the developer task it should simplify.

Developer experience as a product: A platform offers a supported path for a concrete developer task. Document inputs, defaults, ownership and escape routes rather than assuming every team benefits from Kubernetes.

### Desired state

A controller compares the current system with a declared target and works to reconcile the difference. In this role, work through: A new developer should start, inspect and stop one service without undocumented steps. The practical workshop develops this into: Use the kind template as a first golden path. Write a quick start, give it a clean-room walkthrough and record commands, time and every point of confusion.

Mental model: A thermostat compares actual temperature with the set point.

Boundary: It cannot fix every cause: a missing image or insufficient resources still needs action.

Role application: A well-run workshop gives visitors usable benches and instructions, not just a room full of tools.

A platform offers a supported path for a concrete developer task. Document inputs, defaults, ownership and escape routes rather than assuming every team benefits from Kubernetes.

Worked example: A new developer should start, inspect and stop one service without undocumented steps.

Shared foundation example: One replica means the controller tries to keep one Pod running.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Kubernetes and kind (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Platform Engineer: A new developer should start, inspect and stop one service without undocumented steps.

Predict the worked case

Read this case without running a tool: A new developer should start, inspect and stop one service without undocumented steps. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in desired state.

Connect the concept to the role

Apply this rule: A controller compares the current system with a declared target and works to reconcile the difference. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: It cannot fix every cause: a missing image or insufficient resources still needs action.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies desired state to this case: A new developer should start, inspect and stop one service without undocumented steps. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A new developer should start, inspect and stop one service without undocumented steps. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Desired state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with desired state. Use the glossary below, then write your prediction for: A new developer should start, inspect and stop one service without undocumented steps. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Platform Engineer role interview. Explain desired state using this case: A new developer should start, inspect and stop one service without undocumented steps. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate desired state to a system or workflow you know. Explain desired state using this case: A new developer should start, inspect and stop one service without undocumented steps. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens when a Pod is deleted but its Deployment remains?

Interview: Explain desired state using this case: A new developer should start, inspect and stop one service without undocumented steps. State the evidence, one alternative and where the mental model stops.

Quiz: After the Developer experience as a product rehearsal, check this foundation: A controller is told to run two replicas, but only one is ready. What does the declared target mean?

The controller attempts reconciliation; it is not a guarantee that both are healthy now.

Two healthy replicas must already exist.

The current replica count becomes the new desired target automatically.

Reference: The controller attempts reconciliation; it is not a guarantee that both are healthy now. — Desired and observed state differ during convergence or failure. Inspect readiness, events and constraints.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Developer experience as a product

A platform offers a supported path for a concrete developer task. Document inputs, defaults, ownership and escape routes rather than assuming every team benefits from Kubernetes. In this role, work through: A new developer should start, inspect and stop one service without undocumented steps. The practical workshop develops this into: Use the kind template as a first golden path. Write a quick start, give it a clean-room walkthrough and record commands, time and every point of confusion.

Mental model: A well-run workshop gives visitors usable benches and instructions, not just a room full of tools.

Boundary: A working author's machine is not onboarding evidence; repeat from an extracted clean pack.

Worked example: A new developer should start, inspect and stop one service without undocumented steps.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Kubernetes and kind (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Platform Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Use the kind template as a first golden path. Write a quick start, give it a clean-room walkthrough and record commands, time and every point of confusion.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

A new developer should start, inspect and stop one service without undocumented steps. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Use the kind template as a first golden path. Write a quick start, give it a clean-room walkthrough and record commands, time and every point of confusion.

Expected: A repeatable first service with explicit requirements and cleanup.

Role workshop · debug and verify

A working author's machine is not onboarding evidence; repeat from an extracted clean pack. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save golden-path quick start and friction log. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A repeatable first service with explicit requirements and cleanup.

Expected: A repeatable first service with explicit requirements and cleanup.

Troubleshoot: The role exercise differs from the prediction: A working author's machine is not onboarding evidence; repeat from an extracted clean pack.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-beginner-2.md: golden-path quick start and friction log; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with developer experience as a product. Use the glossary below, then write your prediction for: A new developer should start, inspect and stop one service without undocumented steps. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Platform Engineer role interview. Explain developer experience as a product using this case: A new developer should start, inspect and stop one service without undocumented steps. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate developer experience as a product to a system or workflow you know. Explain developer experience as a product using this case: A new developer should start, inspect and stop one service without undocumented steps. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A working author's machine is not onboarding evidence; repeat from an extracted clean pack.

Interview: Explain developer experience as a product using this case: A new developer should start, inspect and stop one service without undocumented steps. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A new developer should start, inspect and stop one service without undocumented steps.

A repeatable first service with explicit requirements and cleanup.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A repeatable first service with explicit requirements and cleanup. — A platform offers a supported path for a concrete developer task. Document inputs, defaults, ownership and escape routes rather than assuming every team benefits from Kubernetes. A repeatable first service with explicit requirements and cleanup.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Readiness and routing: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.

Golden path and escape hatch: A golden path is a supported default with clear boundaries. An escape hatch handles legitimate needs outside that default with explicit ownership.

Resource guardrails: Requests influence scheduling, limits bound runtime resources and quotas constrain namespace totals. Defaults need explanation and tests for both valid workloads and rejected configurations.

### Readiness and routing

Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. In this role, work through: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. The practical workshop develops this into: In the disposable namespace create a ResourceQuota, inspect current usage and try an over-budget workload. Capture the admission error, then reduce the request to fit and verify readiness.

Mental model: A shop can have lights on but still be closed to customers.

Boundary: A health endpoint can be too shallow; it must reflect the service contract.

Role application: An apartment has room capacity, appliance limits and a building-wide utility budget.

Requests influence scheduling, limits bound runtime resources and quotas constrain namespace totals. Defaults need explanation and tests for both valid workloads and rejected configurations.

Worked example: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation.

Shared foundation example: This container listens on 8080; the Service accepts 80 and forwards to 8080.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Kubernetes and kind (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Platform Engineer: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation.

Predict the worked case

Read this case without running a tool: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in readiness and routing.

Connect the concept to the role

Apply this rule: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A health endpoint can be too shallow; it must reflect the service contract.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies readiness and routing to this case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Readiness and routing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with readiness and routing. Use the glossary below, then write your prediction for: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Platform Engineer role interview. Explain readiness and routing using this case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate readiness and routing to a system or workflow you know. Explain readiness and routing using this case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain why a Running Pod might still receive no traffic.

Interview: Explain readiness and routing using this case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. State the evidence, one alternative and where the mental model stops.

Quiz: After the Resource guardrails rehearsal, check this foundation: A process listens on 8080. A Service accepts 80. Which target port should route to that listener?

80 because the Service port must equal the application port.

8080, matching the actual application listener.

443 because readiness always implies TLS.

Reference: 8080, matching the actual application listener. — Service and target ports can differ. Readiness must also reflect whether the workload can serve traffic.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Resource guardrails

Requests influence scheduling, limits bound runtime resources and quotas constrain namespace totals. Defaults need explanation and tests for both valid workloads and rejected configurations. In this role, work through: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. The practical workshop develops this into: In the disposable namespace create a ResourceQuota, inspect current usage and try an over-budget workload. Capture the admission error, then reduce the request to fit and verify readiness.

Mental model: An apartment has room capacity, appliance limits and a building-wide utility budget.

Boundary: Quotas are not network or identity isolation; document those separately.

Worked example: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Kubernetes and kind (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Platform Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

In the disposable namespace create a ResourceQuota, inspect current usage and try an over-budget workload. Capture the admission error, then reduce the request to fit and verify readiness.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

In the disposable namespace create a ResourceQuota, inspect current usage and try an over-budget workload. Capture the admission error, then reduce the request to fit and verify readiness.

Expected: A clear rejection followed by a supported configuration that runs.

Role workshop · debug and verify

Quotas are not network or identity isolation; document those separately. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save quota manifest, error guide and resource request policy. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A clear rejection followed by a supported configuration that runs.

Expected: A clear rejection followed by a supported configuration that runs.

Troubleshoot: The role exercise differs from the prediction: Quotas are not network or identity isolation; document those separately.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-intermediate-2.md: quota manifest, error guide and resource request policy; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with resource guardrails. Use the glossary below, then write your prediction for: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Platform Engineer role interview. Explain resource guardrails using this case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate resource guardrails to a system or workflow you know. Explain resource guardrails using this case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Quotas are not network or identity isolation; document those separately.

Interview: Explain resource guardrails using this case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A namespace quota smaller than a new Pod's requested memory should reject the additional allocation.

Ignore the failing case and keep only the successful screenshot.

A clear rejection followed by a supported configuration that runs.

Treat any successful command as proof that all business and access rules passed.

Reference: A clear rejection followed by a supported configuration that runs. — Requests influence scheduling, limits bound runtime resources and quotas constrain namespace totals. Defaults need explanation and tests for both valid workloads and rejected configurations. A clear rejection followed by a supported configuration that runs.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Rollback and service objectives: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.

Multi-tenancy and platform reliability: Shared platforms need tenant isolation, capacity policies, upgrade plans and service objectives of their own.

Tenant isolation and upgrade evidence: Namespaces organize workloads but do not alone establish strong isolation. Combine identity, policy enforcement, resource controls and a tested upgrade route appropriate to the threat model.

### Rollback and service objectives

A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. In this role, work through: One team's service account must not list another team's secrets. The practical workshop develops this into: Design two test tenants, write an RBAC matrix and use kubectl auth can-i with authorized impersonation in a disposable cluster. Record network-policy enforcement prerequisites and an upgrade canary plan.

Mental model: A reversible road detour with traffic counters at both ends.

Boundary: A rollback may not undo database changes; release safety includes schema compatibility.

Role application: Separate apartment numbers do not replace locks, meters and fire doors.

Namespaces organize workloads but do not alone establish strong isolation. Combine identity, policy enforcement, resource controls and a tested upgrade route appropriate to the threat model.

Worked example: One team's service account must not list another team's secrets.

Shared foundation example: Change the image to a nonexistent tag, inspect events and undo the rollout.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Kubernetes and kind (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Platform Engineer: One team's service account must not list another team's secrets.

Predict the worked case

Read this case without running a tool: One team's service account must not list another team's secrets. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in rollback and service objectives.

Connect the concept to the role

Apply this rule: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A rollback may not undo database changes; release safety includes schema compatibility.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies rollback and service objectives to this case: One team's service account must not list another team's secrets. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: One team's service account must not list another team's secrets. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Rollback and service objectives; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rollback and service objectives. Use the glossary below, then write your prediction for: One team's service account must not list another team's secrets. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Platform Engineer role interview. Explain rollback and service objectives using this case: One team's service account must not list another team's secrets. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rollback and service objectives to a system or workflow you know. Explain rollback and service objectives using this case: One team's service account must not list another team's secrets. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks must pass after undoing a bad image?

Interview: Explain rollback and service objectives using this case: One team's service account must not list another team's secrets. State the evidence, one alternative and where the mental model stops.

Quiz: After the Tenant isolation and upgrade evidence rehearsal, check this foundation: A rollout undo completes. What additional evidence establishes user recovery?

The deployment command exited zero, so no more checks are needed.

The old image tag exists in the registry.

A representative user operation succeeds and dependent state remains compatible.

Reference: A representative user operation succeeds and dependent state remains compatible. — Control-plane convergence does not verify the business path or reverse external state changes.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Tenant isolation and upgrade evidence

Namespaces organize workloads but do not alone establish strong isolation. Combine identity, policy enforcement, resource controls and a tested upgrade route appropriate to the threat model. In this role, work through: One team's service account must not list another team's secrets. The practical workshop develops this into: Design two test tenants, write an RBAC matrix and use kubectl auth can-i with authorized impersonation in a disposable cluster. Record network-policy enforcement prerequisites and an upgrade canary plan.

Mental model: Separate apartment numbers do not replace locks, meters and fire doors.

Boundary: A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation.

Worked example: One team's service account must not list another team's secrets.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Kubernetes and kind (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Platform Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Design two test tenants, write an RBAC matrix and use kubectl auth can-i with authorized impersonation in a disposable cluster. Record network-policy enforcement prerequisites and an upgrade canary plan.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Rehearse a failed release

Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

Role workshop · predict

One team's service account must not list another team's secrets. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Design two test tenants, write an RBAC matrix and use kubectl auth can-i with authorized impersonation in a disposable cluster. Record network-policy enforcement prerequisites and an upgrade canary plan.

Expected: Explicit allow/deny evidence and an honest list of controls not exercised by local kind.

Role workshop · debug and verify

A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save tenant threat model and platform upgrade runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Explicit allow/deny evidence and an honest list of controls not exercised by local kind.

Expected: Explicit allow/deny evidence and an honest list of controls not exercised by local kind.

Troubleshoot: The role exercise differs from the prediction: A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-advanced-2.md: tenant threat model and platform upgrade runbook; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with tenant isolation and upgrade evidence. Use the glossary below, then write your prediction for: One team's service account must not list another team's secrets. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Platform Engineer role interview. Explain tenant isolation and upgrade evidence using this case: One team's service account must not list another team's secrets. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate tenant isolation and upgrade evidence to a system or workflow you know. Explain tenant isolation and upgrade evidence using this case: One team's service account must not list another team's secrets. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation.

Interview: Explain tenant isolation and upgrade evidence using this case: One team's service account must not list another team's secrets. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? One team's service account must not list another team's secrets.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Explicit allow/deny evidence and an honest list of controls not exercised by local kind.

Reference: Explicit allow/deny evidence and an honest list of controls not exercised by local kind. — Namespaces organize workloads but do not alone establish strong isolation. Combine identity, policy enforcement, resource controls and a tested upgrade route appropriate to the threat model. Explicit allow/deny evidence and an honest list of controls not exercised by local kind.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/
