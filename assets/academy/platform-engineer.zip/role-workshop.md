# Platform Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Developer experience as a product

A platform offers a supported path for a concrete developer task. Document inputs, defaults, ownership and escape routes rather than assuming every team benefits from Kubernetes.
Mental model: A well-run workshop gives visitors usable benches and instructions, not just a room full of tools.
Case: A new developer should start, inspect and stop one service without undocumented steps.
Task: Use the kind template as a first golden path. Write a quick start, give it a clean-room walkthrough and record commands, time and every point of confusion.
Acceptance: A repeatable first service with explicit requirements and cleanup.
Troubleshooting: A working author's machine is not onboarding evidence; repeat from an extracted clean pack.
Deliverable: golden-path quick start and friction log

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Resource guardrails

Requests influence scheduling, limits bound runtime resources and quotas constrain namespace totals. Defaults need explanation and tests for both valid workloads and rejected configurations.
Mental model: An apartment has room capacity, appliance limits and a building-wide utility budget.
Case: A namespace quota smaller than a new Pod's requested memory should reject the additional allocation.
Task: In the disposable namespace create a ResourceQuota, inspect current usage and try an over-budget workload. Capture the admission error, then reduce the request to fit and verify readiness.
Acceptance: A clear rejection followed by a supported configuration that runs.
Troubleshooting: Quotas are not network or identity isolation; document those separately.
Deliverable: quota manifest, error guide and resource request policy

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Tenant isolation and upgrade evidence

Namespaces organize workloads but do not alone establish strong isolation. Combine identity, policy enforcement, resource controls and a tested upgrade route appropriate to the threat model.
Mental model: Separate apartment numbers do not replace locks, meters and fire doors.
Case: One team's service account must not list another team's secrets.
Task: Design two test tenants, write an RBAC matrix and use kubectl auth can-i with authorized impersonation in a disposable cluster. Record network-policy enforcement prerequisites and an upgrade canary plan.
Acceptance: Explicit allow/deny evidence and an honest list of controls not exercised by local kind.
Troubleshooting: A NetworkPolicy object has no effect without an enforcing network plugin; verify support before claiming isolation.
Deliverable: tenant threat model and platform upgrade runbook

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
