# Application Security Engineer

Software Engineering

Begin with authentication and authorization. Test a read-versus-write permission matrix. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Test a read-versus-write permission matrix

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required.

### Authentication and authorization
Authentication establishes identity; authorization decides which action that identity may perform.
Mental model: An ID card tells who you are; the door policy says where you may enter.
Limit: A valid login does not authorize access to every record.
Example: Alice may read but not write; an unknown user is denied.
Recall: Where should an object ownership check happen?

### Apply authentication and authorization in Application Security Engineer
Use the concept to complete this role exercise: Test a read-versus-write permission matrix
Mental model: An ID card tells who you are; the door policy says where you may enter.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Alice may read but not write; an unknown user is denied. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py beginner
```
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Test a read-versus-write permission matrix
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: appsec-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Test a read-versus-write permission matrix? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Authentication establishes identity; authorization decides which action that identity may perform. For this role, explicitly address: Test a read-versus-write permission matrix.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Verify that SQL values are parameterized

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required.

### Code and data separation
Parameterized SQL keeps input values separate from SQL instructions.
Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.
Limit: Parameters protect values; dynamic table names still require explicit allowlists.
Example: The malicious-looking owner string is treated as a value and returns zero rows.
Recall: Why is escaping one example string weaker than using parameters?

### Apply code and data separation in Application Security Engineer
Use the concept to complete this role exercise: Verify that SQL values are parameterized
Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: The malicious-looking owner string is treated as a value and returns zero rows. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py intermediate
```
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Verify that SQL values are parameterized
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: appsec-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Verify that SQL values are parameterized? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Parameterized SQL keeps input values separate from SQL instructions. For this role, explicitly address: Verify that SQL values are parameterized.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Build an abuse-case regression suite and review object-level authorization

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required.

### Threat models and regression
State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.
Mental model: Mark doors and valuable rooms on a building map before choosing locks.
Limit: A threat model is a living hypothesis, not proof that the system is secure.
Example: Reader-write, unknown-read and unsupported-delete must all be denied.
Recall: How would a new export endpoint change the threat model?

### Apply threat models and regression in Application Security Engineer
Use the concept to complete this role exercise: Build an abuse-case regression suite and review object-level authorization
Mental model: Mark doors and valuable rooms on a building map before choosing locks.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Reader-write, unknown-read and unsupported-delete must all be denied. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py advanced
```
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Build an abuse-case regression suite and review object-level authorization
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: appsec-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Build an abuse-case regression suite and review object-level authorization? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. For this role, explicitly address: Build an abuse-case regression suite and review object-level authorization.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
