# Application Security Engineer

Software Engineering

Start with object-level authorization. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward export threat model and security regression suite.

## beginner

Extend access.py with owner fields and two users. Test own-read, other-read, own-write and unknown-user cases; assert denials before returning data. Inspect both status and response body for unintended disclosure.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Authentication and authorization
Authentication establishes identity; authorization decides which action that identity may perform.
Mental model: An ID card tells who you are; the door policy says where you may enter.
Limit: A valid login does not authorize access to every record.
Example: Alice may read but not write; an unknown user is denied.
Recall: Where should an object ownership check happen?

### Object-level authorization
Authentication identifies a caller; authorization must check the requested action on the specific object. A role check without ownership can expose another user's records.
Mental model: A library card lets you borrow your books, not open every patron's private file.
Limit: Hiding a button is not server authorization; test direct requests.
Example: Alice can read her ticket but must not read Bob's ticket by changing its ID.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Hiding a button is not server authorization; test direct requests.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Alice can read her ticket but must not read Bob's ticket by changing its ID. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Extend access.py with owner fields and two users. Test own-read, other-read, own-write and unknown-user cases; assert denials before returning data. Inspect both status and response body for unintended disclosure.
```
python3 access.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A complete matrix with no data returned on denied requests.

6. Role workshop · debug and verify
Hiding a button is not server authorization; test direct requests. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save authorization implementation and abuse-case tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A complete matrix with no data returned on denied requests.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Object-level authorization: Hiding a button is not server authorization; test direct requests.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: authorization implementation and abuse-case tests
A complete matrix with no data returned on denied requests.

Interview: Work through this Application Security Engineer case: Alice can read her ticket but must not read Bob's ticket by changing its ID. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Authentication identifies a caller; authorization must check the requested action on the specific object. A role check without ownership can expose another user's records. Expected evidence: A complete matrix with no data returned on denied requests. Diagnosis: Hiding a button is not server authorization; test direct requests. State the limits of the mental model: A library card lets you borrow your books, not open every patron's private file.

Resume: Built authorization implementation and abuse-case tests using OWASP guides and parameterized SQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Run the supplied SQL fixture, add another malicious-looking value and inspect parameter binding. For a dynamic sort field, use a fixed allowlist and reject an unknown identifier.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Code and data separation
Parameterized SQL keeps input values separate from SQL instructions.
Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.
Limit: Parameters protect values; dynamic table names still require explicit allowlists.
Example: The malicious-looking owner string is treated as a value and returns zero rows.
Recall: Why is escaping one example string weaker than using parameters?

### Injection boundaries
Parameterized SQL separates values from instructions. Dynamic identifiers and output contexts still require their own restrictions; one escaped sample does not prove safety.
Mental model: Values go into labeled boxes, not into the instruction manual.
Limit: SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers.
Example: An owner value containing quotes returns only matching literal data, not every row.
Recall: Explain the expected result before running the exercise, then diagnose this failure: SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
An owner value containing quotes returns only matching literal data, not every row. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run the supplied SQL fixture, add another malicious-looking value and inspect parameter binding. For a dynamic sort field, use a fixed allowlist and reject an unknown identifier.
```
python3 access.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Literal-value handling and rejected unapproved sort fields.

6. Role workshop · debug and verify
SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save injection tests and boundary review. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Literal-value handling and rejected unapproved sort fields.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Injection boundaries: SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: injection tests and boundary review
Literal-value handling and rejected unapproved sort fields.

Interview: Work through this Application Security Engineer case: An owner value containing quotes returns only matching literal data, not every row. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Parameterized SQL separates values from instructions. Dynamic identifiers and output contexts still require their own restrictions; one escaped sample does not prove safety. Expected evidence: Literal-value handling and rejected unapproved sort fields. Diagnosis: SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers. State the limits of the mental model: Values go into labeled boxes, not into the instruction manual.

Resume: Built injection tests and boundary review using OWASP guides and parameterized SQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Draw the export flow, define allowed population and test pagination/ownership, rate limits and sensitive logs. Write a release decision with unresolved risks and evidence.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Threat models and regression
State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.
Mental model: Mark doors and valuable rooms on a building map before choosing locks.
Limit: A threat model is a living hypothesis, not proof that the system is secure.
Example: Reader-write, unknown-read and unsupported-delete must all be denied.
Recall: How would a new export endpoint change the threat model?

### Threat modeling a new endpoint
Adding exports changes data volume, authorization and logging risks. Identify assets and abuse cases, then turn the highest-impact controls into regression tests.
Mental model: Adding a loading bay changes the security of a building even if its front door is secure.
Limit: A test of one record does not cover bulk queries; inspect the selection predicate.
Example: A bulk export could reveal records a user cannot read individually.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A test of one record does not cover bulk queries; inspect the selection predicate.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A bulk export could reveal records a user cannot read individually. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Draw the export flow, define allowed population and test pagination/ownership, rate limits and sensitive logs. Write a release decision with unresolved risks and evidence.
```
python3 access.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Export authorization is at least as strict as single-record access in the tested cases.

6. Role workshop · debug and verify
A test of one record does not cover bulk queries; inspect the selection predicate. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save export threat model and security regression suite. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Export authorization is at least as strict as single-record access in the tested cases.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Threat modeling a new endpoint: A test of one record does not cover bulk queries; inspect the selection predicate.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: export threat model and security regression suite
Export authorization is at least as strict as single-record access in the tested cases.

Interview: Work through this Application Security Engineer case: A bulk export could reveal records a user cannot read individually. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Adding exports changes data volume, authorization and logging risks. Identify assets and abuse cases, then turn the highest-impact controls into regression tests. Expected evidence: Export authorization is at least as strict as single-record access in the tested cases. Diagnosis: A test of one record does not cover bulk queries; inspect the selection predicate. State the limits of the mental model: Adding a loading bay changes the security of a building even if its front door is secure.

Resume: Built export threat model and security regression suite using OWASP guides and parameterized SQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
