# Application Security Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Authentication and authorization: Authentication establishes identity; authorization decides which action that identity may perform.

Apply authentication and authorization in Application Security Engineer: Use the concept to complete this role exercise: Test a read-versus-write permission matrix

Object-level authorization: Authentication identifies a caller; authorization must check the requested action on the specific object. A role check without ownership can expose another user's records.

### Authentication and authorization

Authentication establishes identity; authorization decides which action that identity may perform. In this role, work through: Alice can read her ticket but must not read Bob's ticket by changing its ID. The practical workshop develops this into: Extend access.py with owner fields and two users. Test own-read, other-read, own-write and unknown-user cases; assert denials before returning data. Inspect both status and response body for unintended disclosure.

Mental model: An ID card tells who you are; the door policy says where you may enter.

Boundary: A valid login does not authorize access to every record.

Role application: A library card lets you borrow your books, not open every patron's private file.

Authentication identifies a caller; authorization must check the requested action on the specific object. A role check without ownership can expose another user's records.

Worked example: Alice can read her ticket but must not read Bob's ticket by changing its ID.

Shared foundation example: Alice may read but not write; an unknown user is denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: OWASP guides and parameterized SQL (Open source resources); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Application Security Engineer: Alice can read her ticket but must not read Bob's ticket by changing its ID.

Predict the worked case

Read this case without running a tool: Alice can read her ticket but must not read Bob's ticket by changing its ID. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in authentication and authorization.

Connect the concept to the role

Apply this rule: Authentication establishes identity; authorization decides which action that identity may perform. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A valid login does not authorize access to every record.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies authentication and authorization to this case: Alice can read her ticket but must not read Bob's ticket by changing its ID. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Alice can read her ticket but must not read Bob's ticket by changing its ID. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Authentication and authorization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with authentication and authorization. Use the glossary below, then write your prediction for: Alice can read her ticket but must not read Bob's ticket by changing its ID. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Application Security Engineer role interview. Explain authentication and authorization using this case: Alice can read her ticket but must not read Bob's ticket by changing its ID. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate authentication and authorization to a system or workflow you know. Explain authentication and authorization using this case: Alice can read her ticket but must not read Bob's ticket by changing its ID. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Where should an object ownership check happen?

Interview: Explain authentication and authorization using this case: Alice can read her ticket but must not read Bob's ticket by changing its ID. State the evidence, one alternative and where the mental model stops.

Quiz: After the Object-level authorization rehearsal, check this foundation: A logged-in user requests another user’s private record. What must the service still check?

Whether this identity is permitted to perform this action on that record.

Only whether the session token has the correct syntax.

Only whether the record identifier exists.

Reference: Whether this identity is permitted to perform this action on that record. — Authentication establishes identity; authorization checks the action and resource.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Object-level authorization

Authentication identifies a caller; authorization must check the requested action on the specific object. A role check without ownership can expose another user's records. In this role, work through: Alice can read her ticket but must not read Bob's ticket by changing its ID. The practical workshop develops this into: Extend access.py with owner fields and two users. Test own-read, other-read, own-write and unknown-user cases; assert denials before returning data. Inspect both status and response body for unintended disclosure.

Mental model: A library card lets you borrow your books, not open every patron's private file.

Boundary: Hiding a button is not server authorization; test direct requests.

Worked example: Alice can read her ticket but must not read Bob's ticket by changing its ID.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OWASP guides and parameterized SQL (Open source resources); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Application Security Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Extend access.py with owner fields and two users. Test own-read, other-read, own-write and unknown-user cases; assert denials before returning data. Inspect both status and response body for unintended disclosure.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Alice can read her ticket but must not read Bob's ticket by changing its ID. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Extend access.py with owner fields and two users. Test own-read, other-read, own-write and unknown-user cases; assert denials before returning data. Inspect both status and response body for unintended disclosure.

```
python3 access.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A complete matrix with no data returned on denied requests.

Role workshop · debug and verify

Hiding a button is not server authorization; test direct requests. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save authorization implementation and abuse-case tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A complete matrix with no data returned on denied requests.

Expected: A complete matrix with no data returned on denied requests.

Troubleshoot: The role exercise differs from the prediction: Hiding a button is not server authorization; test direct requests.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: authorization implementation and abuse-case tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with object-level authorization. Use the glossary below, then write your prediction for: Alice can read her ticket but must not read Bob's ticket by changing its ID. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Application Security Engineer role interview. Explain object-level authorization using this case: Alice can read her ticket but must not read Bob's ticket by changing its ID. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate object-level authorization to a system or workflow you know. Explain object-level authorization using this case: Alice can read her ticket but must not read Bob's ticket by changing its ID. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Hiding a button is not server authorization; test direct requests.

Interview: Explain object-level authorization using this case: Alice can read her ticket but must not read Bob's ticket by changing its ID. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Alice can read her ticket but must not read Bob's ticket by changing its ID.

A complete matrix with no data returned on denied requests.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A complete matrix with no data returned on denied requests. — Authentication identifies a caller; authorization must check the requested action on the specific object. A role check without ownership can expose another user's records. A complete matrix with no data returned on denied requests.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Code and data separation: Parameterized SQL keeps input values separate from SQL instructions.

Apply code and data separation in Application Security Engineer: Use the concept to complete this role exercise: Verify that SQL values are parameterized

Injection boundaries: Parameterized SQL separates values from instructions. Dynamic identifiers and output contexts still require their own restrictions; one escaped sample does not prove safety.

### Code and data separation

Parameterized SQL keeps input values separate from SQL instructions. In this role, work through: An owner value containing quotes returns only matching literal data, not every row. The practical workshop develops this into: Run the supplied SQL fixture, add another malicious-looking value and inspect parameter binding. For a dynamic sort field, use a fixed allowlist and reject an unknown identifier.

Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.

Boundary: Parameters protect values; dynamic table names still require explicit allowlists.

Role application: Values go into labeled boxes, not into the instruction manual.

Parameterized SQL separates values from instructions. Dynamic identifiers and output contexts still require their own restrictions; one escaped sample does not prove safety.

Worked example: An owner value containing quotes returns only matching literal data, not every row.

Shared foundation example: The malicious-looking owner string is treated as a value and returns zero rows.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: OWASP guides and parameterized SQL (Open source resources); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Application Security Engineer: An owner value containing quotes returns only matching literal data, not every row.

Predict the worked case

Read this case without running a tool: An owner value containing quotes returns only matching literal data, not every row. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in code and data separation.

Connect the concept to the role

Apply this rule: Parameterized SQL keeps input values separate from SQL instructions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Parameters protect values; dynamic table names still require explicit allowlists.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies code and data separation to this case: An owner value containing quotes returns only matching literal data, not every row. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An owner value containing quotes returns only matching literal data, not every row. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Code and data separation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with code and data separation. Use the glossary below, then write your prediction for: An owner value containing quotes returns only matching literal data, not every row. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Application Security Engineer role interview. Explain code and data separation using this case: An owner value containing quotes returns only matching literal data, not every row. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate code and data separation to a system or workflow you know. Explain code and data separation using this case: An owner value containing quotes returns only matching literal data, not every row. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is escaping one example string weaker than using parameters?

Interview: Explain code and data separation using this case: An owner value containing quotes returns only matching literal data, not every row. State the evidence, one alternative and where the mental model stops.

Quiz: After the Injection boundaries rehearsal, check this foundation: A query binds a user value through a parameter. Can that same placeholder choose an arbitrary table name?

Yes, placeholders bind all SQL syntax.

No; structural identifiers need an allowlisted query design.

Yes, if the identifier arrives over HTTPS.

Reference: No; structural identifiers need an allowlisted query design. — Parameters bind values, not arbitrary SQL structure. Transport security does not change SQL semantics.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Injection boundaries

Parameterized SQL separates values from instructions. Dynamic identifiers and output contexts still require their own restrictions; one escaped sample does not prove safety. In this role, work through: An owner value containing quotes returns only matching literal data, not every row. The practical workshop develops this into: Run the supplied SQL fixture, add another malicious-looking value and inspect parameter binding. For a dynamic sort field, use a fixed allowlist and reject an unknown identifier.

Mental model: Values go into labeled boxes, not into the instruction manual.

Boundary: SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers.

Worked example: An owner value containing quotes returns only matching literal data, not every row.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OWASP guides and parameterized SQL (Open source resources); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Application Security Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run the supplied SQL fixture, add another malicious-looking value and inspect parameter binding. For a dynamic sort field, use a fixed allowlist and reject an unknown identifier.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

An owner value containing quotes returns only matching literal data, not every row. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run the supplied SQL fixture, add another malicious-looking value and inspect parameter binding. For a dynamic sort field, use a fixed allowlist and reject an unknown identifier.

```
python3 access.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Literal-value handling and rejected unapproved sort fields.

Role workshop · debug and verify

SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save injection tests and boundary review. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Literal-value handling and rejected unapproved sort fields.

Expected: Literal-value handling and rejected unapproved sort fields.

Troubleshoot: The role exercise differs from the prediction: SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: injection tests and boundary review; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with injection boundaries. Use the glossary below, then write your prediction for: An owner value containing quotes returns only matching literal data, not every row. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Application Security Engineer role interview. Explain injection boundaries using this case: An owner value containing quotes returns only matching literal data, not every row. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate injection boundaries to a system or workflow you know. Explain injection boundaries using this case: An owner value containing quotes returns only matching literal data, not every row. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers.

Interview: Explain injection boundaries using this case: An owner value containing quotes returns only matching literal data, not every row. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? An owner value containing quotes returns only matching literal data, not every row.

Ignore the failing case and keep only the successful screenshot.

Literal-value handling and rejected unapproved sort fields.

Treat any successful command as proof that all business and access rules passed.

Reference: Literal-value handling and rejected unapproved sort fields. — Parameterized SQL separates values from instructions. Dynamic identifiers and output contexts still require their own restrictions; one escaped sample does not prove safety. Literal-value handling and rejected unapproved sort fields.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Threat models and regression: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.

Apply threat models and regression in Application Security Engineer: Use the concept to complete this role exercise: Build an abuse-case regression suite and review object-level authorization

Threat modeling a new endpoint: Adding exports changes data volume, authorization and logging risks. Identify assets and abuse cases, then turn the highest-impact controls into regression tests.

### Threat models and regression

State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. In this role, work through: A bulk export could reveal records a user cannot read individually. The practical workshop develops this into: Draw the export flow, define allowed population and test pagination/ownership, rate limits and sensitive logs. Write a release decision with unresolved risks and evidence.

Mental model: Mark doors and valuable rooms on a building map before choosing locks.

Boundary: A threat model is a living hypothesis, not proof that the system is secure.

Role application: Adding a loading bay changes the security of a building even if its front door is secure.

Adding exports changes data volume, authorization and logging risks. Identify assets and abuse cases, then turn the highest-impact controls into regression tests.

Worked example: A bulk export could reveal records a user cannot read individually.

Shared foundation example: Reader-write, unknown-read and unsupported-delete must all be denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: OWASP guides and parameterized SQL (Open source resources); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Application Security Engineer: A bulk export could reveal records a user cannot read individually.

Predict the worked case

Read this case without running a tool: A bulk export could reveal records a user cannot read individually. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in threat models and regression.

Connect the concept to the role

Apply this rule: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A threat model is a living hypothesis, not proof that the system is secure.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies threat models and regression to this case: A bulk export could reveal records a user cannot read individually. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A bulk export could reveal records a user cannot read individually. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Threat models and regression; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with threat models and regression. Use the glossary below, then write your prediction for: A bulk export could reveal records a user cannot read individually. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Application Security Engineer role interview. Explain threat models and regression using this case: A bulk export could reveal records a user cannot read individually. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate threat models and regression to a system or workflow you know. Explain threat models and regression using this case: A bulk export could reveal records a user cannot read individually. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would a new export endpoint change the threat model?

Interview: Explain threat models and regression using this case: A bulk export could reveal records a user cannot read individually. State the evidence, one alternative and where the mental model stops.

Quiz: After the Threat modeling a new endpoint rehearsal, check this foundation: A denied action is fixed after a security defect. What helps detect its recurrence?

Document only the successful authorized path.

Remove the denied case because it now passes.

Add a repeatable negative test tied to the actor, action and trust boundary.

Reference: Add a repeatable negative test tied to the actor, action and trust boundary. — Regression checks preserve evidence for important misuse cases; the threat model explains why the control matters.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Threat modeling a new endpoint

Adding exports changes data volume, authorization and logging risks. Identify assets and abuse cases, then turn the highest-impact controls into regression tests. In this role, work through: A bulk export could reveal records a user cannot read individually. The practical workshop develops this into: Draw the export flow, define allowed population and test pagination/ownership, rate limits and sensitive logs. Write a release decision with unresolved risks and evidence.

Mental model: Adding a loading bay changes the security of a building even if its front door is secure.

Boundary: A test of one record does not cover bulk queries; inspect the selection predicate.

Worked example: A bulk export could reveal records a user cannot read individually.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OWASP guides and parameterized SQL (Open source resources); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Application Security Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Draw the export flow, define allowed population and test pagination/ownership, rate limits and sensitive logs. Write a release decision with unresolved risks and evidence.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A bulk export could reveal records a user cannot read individually. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Draw the export flow, define allowed population and test pagination/ownership, rate limits and sensitive logs. Write a release decision with unresolved risks and evidence.

```
python3 access.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Export authorization is at least as strict as single-record access in the tested cases.

Role workshop · debug and verify

A test of one record does not cover bulk queries; inspect the selection predicate. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save export threat model and security regression suite. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Export authorization is at least as strict as single-record access in the tested cases.

Expected: Export authorization is at least as strict as single-record access in the tested cases.

Troubleshoot: The role exercise differs from the prediction: A test of one record does not cover bulk queries; inspect the selection predicate.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: export threat model and security regression suite; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with threat modeling a new endpoint. Use the glossary below, then write your prediction for: A bulk export could reveal records a user cannot read individually. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Application Security Engineer role interview. Explain threat modeling a new endpoint using this case: A bulk export could reveal records a user cannot read individually. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate threat modeling a new endpoint to a system or workflow you know. Explain threat modeling a new endpoint using this case: A bulk export could reveal records a user cannot read individually. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A test of one record does not cover bulk queries; inspect the selection predicate.

Interview: Explain threat modeling a new endpoint using this case: A bulk export could reveal records a user cannot read individually. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A bulk export could reveal records a user cannot read individually.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Export authorization is at least as strict as single-record access in the tested cases.

Reference: Export authorization is at least as strict as single-record access in the tested cases. — Adding exports changes data volume, authorization and logging risks. Identify assets and abuse cases, then turn the highest-impact controls into regression tests. Export authorization is at least as strict as single-record access in the tested cases.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
