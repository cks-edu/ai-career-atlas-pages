# Application Security Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Object-level authorization

Authentication identifies a caller; authorization must check the requested action on the specific object. A role check without ownership can expose another user's records.
Mental model: A library card lets you borrow your books, not open every patron's private file.
Case: Alice can read her ticket but must not read Bob's ticket by changing its ID.
Task: Extend access.py with owner fields and two users. Test own-read, other-read, own-write and unknown-user cases; assert denials before returning data. Inspect both status and response body for unintended disclosure.
Acceptance: A complete matrix with no data returned on denied requests.
Troubleshooting: Hiding a button is not server authorization; test direct requests.
Deliverable: authorization implementation and abuse-case tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Injection boundaries

Parameterized SQL separates values from instructions. Dynamic identifiers and output contexts still require their own restrictions; one escaped sample does not prove safety.
Mental model: Values go into labeled boxes, not into the instruction manual.
Case: An owner value containing quotes returns only matching literal data, not every row.
Task: Run the supplied SQL fixture, add another malicious-looking value and inspect parameter binding. For a dynamic sort field, use a fixed allowlist and reject an unknown identifier.
Acceptance: Literal-value handling and rejected unapproved sort fields.
Troubleshooting: SQL parameters cannot stand in for arbitrary table names; redesign or allowlist identifiers.
Deliverable: injection tests and boundary review

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Threat modeling a new endpoint

Adding exports changes data volume, authorization and logging risks. Identify assets and abuse cases, then turn the highest-impact controls into regression tests.
Mental model: Adding a loading bay changes the security of a building even if its front door is secure.
Case: A bulk export could reveal records a user cannot read individually.
Task: Draw the export flow, define allowed population and test pagination/ownership, rate limits and sensitive logs. Write a release decision with unresolved risks and evidence.
Acceptance: Export authorization is at least as strict as single-record access in the tested cases.
Troubleshooting: A test of one record does not cover bulk queries; inspect the selection predicate.
Deliverable: export threat model and security regression suite

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
