## advanced — Operational decision support

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Operational decision support
Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences.
Mental model: A warning light assists a trained operator; it is not the entire control system.
Boundary: A portfolio prototype is not a validated industrial safety system.
Worked example: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Industrial condition-monitoring digital twin
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. Build a dashboard and an alert-to-inspection workflow. Document how a technician would validate an alert and how maintenance feedback changes the model.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Recall: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. Identify one observation that would contradict your claim.

### Terms
Operational decision support: Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Build a dashboard and an alert-to-inspection workflow. Document how a technician would validate an alert and how maintenance feedback changes the model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling.
Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Build a dashboard and an alert-to-inspection workflow. Document how a technician would validate an alert and how maintenance feedback changes the model.
Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.
Use a licensed public equipment dataset and assess the mismatch with the synthetic process.
Deliverables: Time-series pipeline and state model; Dashboard and fault scenarios; Digital-twin assumptions and inspection runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A reviewer must reproduce one result and identify which capabilities you implemented. Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.

### Interview
Explain your advanced solution for Industrial AI / digital twins. Use this scenario: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Review: Start with the task and permitted scope. Explain operational decision support: Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences. Show the input and observed output, then address Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Time-series pipeline and state model; Dashboard and fault scenarios; Digital-twin assumptions and inspection runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

