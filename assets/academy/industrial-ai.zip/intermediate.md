## intermediate — Sensor quality and temporal validation

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Time-series analysis and process knowledge; operational changes require plant-specific engineering review.

### Sensor quality and temporal validation
Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits.
Mental model: A machine's diary must be read in chronological order.
Boundary: Historical test periods may not cover unusual operating conditions.
Worked example: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Industrial condition-monitoring digital twin
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Recall: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. Identify one observation that would contradict your claim.

### Terms
Sensor quality and temporal validation: Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling.
Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.
Deliverables: Time-series pipeline and state model; Dashboard and fault scenarios. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Industrial AI / digital twins. Use this scenario: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Review: Start with the task and permitted scope. Explain sensor quality and temporal validation: Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits. Show the input and observed output, then address Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Time-series pipeline and state model; Dashboard and fault scenarios. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

