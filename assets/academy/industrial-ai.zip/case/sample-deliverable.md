# SAMPLE — Maintenance alert evaluation and operating-envelope note
Role: Industrial AI / digital twins
Case: Maintenance alerts arrive too late
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target.

## Evidence table
| Record | lead_time_shortfall (minutes) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 5 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 20 | review |
| case-5 | 40 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three warnings miss the required maintenance window; event detection alone is insufficient.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Evaluate event-level lead time and false alarms against the maintenance workflow.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in industrial ai / digital twins.
Before release: Replay temporal holdouts and changed operating regimes without controlling real equipment.

## Design choice and trade-off
Combine domain constraints, sensor validation and human decisions; separate prediction from physical control.
Earlier alerts may increase false alarms; the useful trade-off depends on maintenance cost and response time.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Predictive-maintenance demo: Report detection lead time and false alarms per operating hour.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
