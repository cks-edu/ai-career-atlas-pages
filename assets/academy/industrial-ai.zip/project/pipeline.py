"""Small real DuckDB ingestion and aggregation; usage has one seeded duplicate."""
import duckdb,json
from pathlib import Path

def run():
    db=duckdb.connect(':memory:')
    db.execute("CREATE TABLE raw AS SELECT * FROM read_csv_auto('usage.csv')")
    duplicates=db.execute('SELECT count(*)-count(DISTINCT request_id) FROM raw').fetchone()[0]
    # DISTINCT removes only exact duplicates; conflicting IDs fail closed.
    db.execute('CREATE TABLE clean AS SELECT DISTINCT * FROM raw')
    conflicts=db.execute('SELECT request_id FROM clean GROUP BY request_id HAVING count(*)>1').fetchall()
    if conflicts: raise ValueError('Conflicting request IDs require review: '+str(conflicts))
    result=db.execute('SELECT tenant,count(*) AS requests,sum(input_units+output_units) AS units FROM clean GROUP BY tenant ORDER BY tenant').fetchall()
    db.close()
    return {'duplicate_rows':duplicates,'tenants':[dict(zip(['tenant','requests','units'],r)) for r in result]}
if __name__=='__main__':
    result=run();Path('output').mkdir(exist_ok=True)
    Path('output/summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
