# Dashboard and fault scenarios

Project: Industrial condition-monitoring digital twin
Status: blank work product — not completed evidence

## Purpose and audience
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling.

## Required content
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.

## Failure evidence
Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
