import unittest
from pipeline import run
class PipelineTests(unittest.TestCase):
    def test_duplicate_and_totals(self):
        result=run();self.assertEqual(result['duplicate_rows'],1)
        self.assertEqual(result['tenants'],[{'tenant':'alpha','requests':2,'units':370},{'tenant':'beta','requests':1,'units':90}])
if __name__=='__main__': unittest.main()
