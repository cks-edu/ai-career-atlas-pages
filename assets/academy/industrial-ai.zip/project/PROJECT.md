# Industrial condition-monitoring digital twin

Career: Industrial AI / digital twins
Reviewed: 2026-10-22

Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling.

## Prerequisites
Time-series analysis and process knowledge; operational changes require plant-specific engineering review.

## Included starter versus your implementation
DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Build a dashboard and an alert-to-inspection workflow. Document how a technician would validate an alert and how maintenance feedback changes the model.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Time-series pipeline and state model — artifact-1.md
2. Dashboard and fault scenarios — artifact-2.md
3. Digital-twin assumptions and inspection runbook — artifact-3.md

## Troubleshooting
- Missing CSV: run from the extracted folder.
- Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
- Wrong totals: check units, duplicate joins and whether failures are included.

## Extension
Use a licensed public equipment dataset and assess the mismatch with the synthetic process.

## Primary learning resources
- DuckDB: https://duckdb.org/docs/stable/clients/python/overview — Open source · local; CSV ingestion, SQL transforms and reproducible analysis.
- scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html — Open source · CPU; Pipelines, baselines, data splits and statistical evaluation.
- Prometheus: https://prometheus.io/docs/introduction/overview/ — Open source; Metrics collection and alert evidence.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
