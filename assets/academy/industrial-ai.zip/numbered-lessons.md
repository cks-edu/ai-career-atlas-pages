# Industrial AI / digital twins — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Process context and time: Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Process context and time

Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event. In this role, work through: A maintenance flag written after failure is excluded from pre-failure prediction features. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A thermometer reading after the furnace shuts down cannot predict the earlier shutdown fairly.

Boundary: A data pattern does not establish a causal physical mechanism.

Worked example: A maintenance flag written after failure is excluded from pre-failure prediction features.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Prometheus (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Industrial AI / digital twins: A maintenance flag written after failure is excluded from pre-failure prediction features.

Predict the worked case

Read this case without running a tool: A maintenance flag written after failure is excluded from pre-failure prediction features. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in process context and time.

Connect the concept to the role

Apply this rule: Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A data pattern does not establish a causal physical mechanism.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies process context and time to this case: A maintenance flag written after failure is excluded from pre-failure prediction features. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A maintenance flag written after failure is excluded from pre-failure prediction features. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Process context and time; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with process context and time. Use the glossary below, then write your prediction for: A maintenance flag written after failure is excluded from pre-failure prediction features. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Industrial AI / digital twins role interview. Explain process context and time using this case: A maintenance flag written after failure is excluded from pre-failure prediction features. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate process context and time to a system or workflow you know. Explain process context and time using this case: A maintenance flag written after failure is excluded from pre-failure prediction features. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain process context and time using this case: A maintenance flag written after failure is excluded from pre-failure prediction features. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A maintenance flag written after failure is excluded from pre-failure prediction features.

Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event. — Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event. A data pattern does not establish a causal physical mechanism.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Prometheus: https://prometheus.io/docs/introduction/overview/

Siemens digital twin overview: https://www.siemens.com/en-us/company/digital-twin/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Prometheus: https://prometheus.io/docs/introduction/overview/

### Diagnose: Maintenance alerts arrive too late

For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Three warnings miss the required maintenance window; event detection alone is insufficient. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Evaluate event-level lead time and false alarms against the maintenance workflow. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A thermometer reading after the furnace shuts down cannot predict the earlier shutdown fairly.

A maintenance flag written after failure is excluded from pre-failure prediction features.

Worked example: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Evaluate event-level lead time and false alarms against the maintenance workflow.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Prometheus (Open source)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Three warnings miss the required maintenance window; event detection alone is insufficient. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Apply this toy-case rule manually: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Industrial data describes a physical process. A sensor threshold depends on the equipment and context, not just the numbers.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use fictional readings 20, 21, 22, 80 and 23 degrees Celsius from a simulated sensor.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated series and a triage note.

Preparation · Try step 2

Mark the unusual value and list possible causes: real change, sensor fault or data error.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated series and a triage note.

Preparation · Try step 3

Write what contextual evidence you would request and who would review the event before changing equipment settings.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated series and a triage note.

Preparation · Explain and check your result

You identify an anomaly without declaring its cause or recommending an unreviewed operational change. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: An annotated series and a triage note. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Apply this toy-case rule manually: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three warnings miss the required maintenance window; event detection alone is insufficient. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three warnings miss the required maintenance window; event detection alone is insufficient. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: maintenance alerts arrive too late. Use the glossary below, then write your prediction for: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Evaluate event-level lead time and false alarms against the maintenance workflow. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Industrial AI / digital twins role interview. Explain diagnose: maintenance alerts arrive too late using this case: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Evaluate event-level lead time and false alarms against the maintenance workflow. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: maintenance alerts arrive too late to a system or workflow you know. Explain diagnose: maintenance alerts arrive too late using this case: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Evaluate event-level lead time and false alarms against the maintenance workflow. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Replay temporal holdouts and changed operating regimes without controlling real equipment. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: maintenance alerts arrive too late using this case: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Evaluate event-level lead time and false alarms against the maintenance workflow. State the evidence, one alternative and where the mental model stops.

Quiz: Maintenance alerts arrive too late: For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target.

Change the acceptance rule after seeing an inconvenient result.

Evaluate event-level lead time and false alarms against the maintenance workflow.

Omit failed cases and report only the successful demonstrations.

Reference: Evaluate event-level lead time and false alarms against the maintenance workflow. — Evaluate event-level lead time and false alarms against the maintenance workflow. Replay temporal holdouts and changed operating regimes without controlling real equipment.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Prometheus: https://prometheus.io/docs/introduction/overview/

Siemens digital twin overview: https://www.siemens.com/en-us/company/digital-twin/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Prometheus: https://prometheus.io/docs/introduction/overview/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Time-series analysis and process knowledge; operational changes require plant-specific engineering review.

Terms:

Sensor quality and temporal validation: Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Sensor quality and temporal validation

Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits. In this role, work through: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A machine's diary must be read in chronological order.

Boundary: Historical test periods may not cover unusual operating conditions.

Worked example: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Time-series analysis and process knowledge; operational changes require plant-specific engineering review.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Prometheus (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Industrial AI / digital twins: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution.

Predict the worked case

Read this case without running a tool: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in sensor quality and temporal validation.

Connect the concept to the role

Apply this rule: Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Historical test periods may not cover unusual operating conditions.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies sensor quality and temporal validation to this case: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Sensor quality and temporal validation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with sensor quality and temporal validation. Use the glossary below, then write your prediction for: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Industrial AI / digital twins role interview. Explain sensor quality and temporal validation using this case: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate sensor quality and temporal validation to a system or workflow you know. Explain sensor quality and temporal validation using this case: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain sensor quality and temporal validation using this case: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution.

Treat a passing starter as proof of the whole role workflow.

Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits.

Ignore the failure because the tool produced an output.

Reference: Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits. — Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits. Historical test periods may not cover unusual operating conditions.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Prometheus: https://prometheus.io/docs/introduction/overview/

Siemens digital twin overview: https://www.siemens.com/en-us/company/digital-twin/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Prometheus: https://prometheus.io/docs/introduction/overview/

### Integrate: Industrial condition-monitoring digital twin

Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance. In this role, work through: Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A machine's diary must be read in chronological order.

Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution.

Worked example: Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Prometheus (Open source)

Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-intermediate-2.md: Time-series pipeline and state model; Dashboard and fault scenarios. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: industrial condition-monitoring digital twin. Use the glossary below, then write your prediction for: Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Industrial AI / digital twins role interview. Explain integrate: industrial condition-monitoring digital twin using this case: Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: industrial condition-monitoring digital twin to a system or workflow you know. Explain integrate: industrial condition-monitoring digital twin using this case: Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. Identify one observation that would contradict your claim.

Interview: Explain integrate: industrial condition-monitoring digital twin using this case: Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Industrial condition-monitoring digital twin at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.

Reference: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. — Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Prometheus: https://prometheus.io/docs/introduction/overview/

Siemens digital twin overview: https://www.siemens.com/en-us/company/digital-twin/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Prometheus: https://prometheus.io/docs/introduction/overview/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Operational decision support: Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Operational decision support

Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences. In this role, work through: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A warning light assists a trained operator; it is not the entire control system.

Boundary: A portfolio prototype is not a validated industrial safety system.

Worked example: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Prometheus (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Industrial AI / digital twins: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings.

Predict the worked case

Read this case without running a tool: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in operational decision support.

Connect the concept to the role

Apply this rule: Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A portfolio prototype is not a validated industrial safety system.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies operational decision support to this case: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Operational decision support; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with operational decision support. Use the glossary below, then write your prediction for: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Industrial AI / digital twins role interview. Explain operational decision support using this case: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate operational decision support to a system or workflow you know. Explain operational decision support using this case: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain operational decision support using this case: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences.

Reference: Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences. — Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences. A portfolio prototype is not a validated industrial safety system.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Prometheus: https://prometheus.io/docs/introduction/overview/

Siemens digital twin overview: https://www.siemens.com/en-us/company/digital-twin/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Prometheus: https://prometheus.io/docs/introduction/overview/

### Defend: Industrial condition-monitoring digital twin

Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. Build a dashboard and an alert-to-inspection workflow. Document how a technician would validate an alert and how maintenance feedback changes the model. In this role, work through: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A warning light assists a trained operator; it is not the entire control system.

A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings.

Worked example: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); Prometheus (Open source)

Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Build a dashboard and an alert-to-inspection workflow. Document how a technician would validate an alert and how maintenance feedback changes the model.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A reviewer must reproduce one result and identify which capabilities you implemented. Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-advanced-2.md: Time-series pipeline and state model; Dashboard and fault scenarios; Digital-twin assumptions and inspection runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: industrial condition-monitoring digital twin. Use the glossary below, then write your prediction for: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Industrial AI / digital twins role interview. Explain defend: industrial condition-monitoring digital twin using this case: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: industrial condition-monitoring digital twin to a system or workflow you know. Explain defend: industrial condition-monitoring digital twin using this case: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. Identify one observation that would contradict your claim.

Interview: Explain defend: industrial condition-monitoring digital twin using this case: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Industrial condition-monitoring digital twin at this level?

Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating. — Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating. Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

Prometheus: https://prometheus.io/docs/introduction/overview/

Siemens digital twin overview: https://www.siemens.com/en-us/company/digital-twin/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Prometheus: https://prometheus.io/docs/introduction/overview/
