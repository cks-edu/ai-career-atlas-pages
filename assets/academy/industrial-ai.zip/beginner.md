## beginner — Process context and time

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Process context and time
Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event.
Mental model: A thermometer reading after the furnace shuts down cannot predict the earlier shutdown fairly.
Boundary: A data pattern does not establish a causal physical mechanism.
Worked example: A maintenance flag written after failure is excluded from pre-failure prediction features.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Maintenance alerts arrive too late
For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Three warnings miss the required maintenance window; event detection alone is insufficient. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Evaluate event-level lead time and false alarms against the maintenance workflow.
Recall: Replay temporal holdouts and changed operating regimes without controlling real equipment. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Process context and time: Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Industrial data describes a physical process. A sensor threshold depends on the equipment and context, not just the numbers.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use fictional readings 20, 21, 22, 80 and 23 degrees Celsius from a simulated sensor.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated series and a triage note.

3. Try step 2
Mark the unusual value and list possible causes: real change, sensor fault or data error.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated series and a triage note.

4. Try step 3
Write what contextual evidence you would request and who would review the event before changing equipment settings.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated series and a triage note.

5. Explain and check your result
You identify an anomaly without declaring its cause or recommending an unreviewed operational change. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An annotated series and a triage note. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Apply this toy-case rule manually: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three warnings miss the required maintenance window; event detection alone is insufficient. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Industrial AI / digital twins.
Use fictional readings 20, 21, 22, 80 and 23 degrees Celsius from a simulated sensor.
Mark the unusual value and list possible causes: real change, sensor fault or data error.
Write what contextual evidence you would request and who would review the event before changing equipment settings.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An annotated series and a triage note. Include beginner-worksheet.md and your completed Maintenance alert evaluation and operating-envelope note.
Check: You identify an anomaly without declaring its cause or recommending an unreviewed operational change.

### Interview
Explain your beginner solution for Industrial AI / digital twins. Use this scenario: For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target.
Review: Start with the task and permitted scope. Explain process context and time: Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event. Show the input and observed output, then address Evaluate event-level lead time and false alarms against the maintenance workflow. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An annotated series and a triage note. Include beginner-worksheet.md and your completed Maintenance alert evaluation and operating-envelope note.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

