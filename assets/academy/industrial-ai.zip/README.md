# Industrial AI / digital twins

AI Engineering · Beginner → Intermediate → Advanced

Start with Process context and time. Industrial data describes a physical process. A sensor threshold depends on the equipment and context, not just the numbers. Then try Review a simulated temperature series. The three levels build toward Industrial condition-monitoring digital twin. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Process context and time

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Process context and time
Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event.
Mental model: A thermometer reading after the furnace shuts down cannot predict the earlier shutdown fairly.
Boundary: A data pattern does not establish a causal physical mechanism.
Worked example: A maintenance flag written after failure is excluded from pre-failure prediction features.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Maintenance alerts arrive too late
For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Three warnings miss the required maintenance window; event detection alone is insufficient. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Evaluate event-level lead time and false alarms against the maintenance workflow.
Recall: Replay temporal holdouts and changed operating regimes without controlling real equipment. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Process context and time: Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Industrial data describes a physical process. A sensor threshold depends on the equipment and context, not just the numbers.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use fictional readings 20, 21, 22, 80 and 23 degrees Celsius from a simulated sensor.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated series and a triage note.

3. Try step 2
Mark the unusual value and list possible causes: real change, sensor fault or data error.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated series and a triage note.

4. Try step 3
Write what contextual evidence you would request and who would review the event before changing equipment settings.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated series and a triage note.

5. Explain and check your result
You identify an anomaly without declaring its cause or recommending an unreviewed operational change. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An annotated series and a triage note. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Apply this toy-case rule manually: Review when lead_time_shortfall > 0 (minutes). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three warnings miss the required maintenance window; event detection alone is insufficient. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Industrial AI / digital twins.
Use fictional readings 20, 21, 22, 80 and 23 degrees Celsius from a simulated sensor.
Mark the unusual value and list possible causes: real change, sensor fault or data error.
Write what contextual evidence you would request and who would review the event before changing equipment settings.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An annotated series and a triage note. Include beginner-worksheet.md and your completed Maintenance alert evaluation and operating-envelope note.
Check: You identify an anomaly without declaring its cause or recommending an unreviewed operational change.

### Interview
Explain your beginner solution for Industrial AI / digital twins. Use this scenario: For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target.
Review: Start with the task and permitted scope. Explain process context and time: Understand the physical process, sensor units and event timing before modeling. Distinguish a predictive signal from a consequence recorded after the event. Show the input and observed output, then address Evaluate event-level lead time and false alarms against the maintenance workflow. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An annotated series and a triage note. Include beginner-worksheet.md and your completed Maintenance alert evaluation and operating-envelope note.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Sensor quality and temporal validation

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Time-series analysis and process knowledge; operational changes require plant-specific engineering review.

### Sensor quality and temporal validation
Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits.
Mental model: A machine's diary must be read in chronological order.
Boundary: Historical test periods may not cover unusual operating conditions.
Worked example: Train on earlier periods and evaluate later ones; report a sensor replacement that changes the measurement distribution.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Industrial condition-monitoring digital twin
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Recall: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. Identify one observation that would contradict your claim.

### Terms
Sensor quality and temporal validation: Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
For this synthetic process, a warning needs at least 30 minutes of useful lead time; measure the shortfall from that target. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling.
Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.
Deliverables: Time-series pipeline and state model; Dashboard and fault scenarios. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Industrial AI / digital twins. Use this scenario: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Review: Start with the task and permitted scope. Explain sensor quality and temporal validation: Inspect gaps, calibration changes and operating modes. Use time-aware evaluation and keep related equipment histories from leaking between splits. Show the input and observed output, then address Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Time-series pipeline and state model; Dashboard and fault scenarios. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Operational decision support

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Operational decision support
Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences.
Mental model: A warning light assists a trained operator; it is not the entire control system.
Boundary: A portfolio prototype is not a validated industrial safety system.
Worked example: A predictive alert creates an inspection recommendation with evidence and an owner, without directly changing a machine's control settings.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Industrial condition-monitoring digital twin
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. Build a dashboard and an alert-to-inspection workflow. Document how a technician would validate an alert and how maintenance feedback changes the model.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Recall: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. Identify one observation that would contradict your claim.

### Terms
Operational decision support: Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Build a dashboard and an alert-to-inspection workflow. Document how a technician would validate an alert and how maintenance feedback changes the model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a small equipment-state model and an anomaly workflow with explicit sensor-quality handling.
Generate synthetic temperature, vibration and load readings for several fictional machines with timestamps and maintenance events. Mark all data and outcomes as simulated.
Ingest readings into DuckDB with units, device IDs and quality flags. Reject impossible timestamps and keep missing readings distinct from normal values.
Create a simple state model or anomaly baseline conditioned on load. Split by time and machine so near-adjacent readings do not inflate performance.
Build a dashboard and an alert-to-inspection workflow. Document how a technician would validate an alert and how maintenance feedback changes the model.
Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy.
Use a licensed public equipment dataset and assess the mismatch with the synthetic process.
Deliverables: Time-series pipeline and state model; Dashboard and fault scenarios; Digital-twin assumptions and inspection runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A reviewer must reproduce one result and identify which capabilities you implemented. Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.

### Interview
Explain your advanced solution for Industrial AI / digital twins. Use this scenario: Freeze one sensor, introduce unit mismatch and simulate a load change. Separate sensor faults from equipment anomalies before escalating.
Review: Start with the task and permitted scope. Explain operational decision support: Connect predictions to a reviewed action, escalation and monitoring process. Assess false alarms and missed events in the context of operator workload and consequences. Show the input and observed output, then address Report false alerts, detection delay and missed simulated events. Synthetic performance cannot establish predictive-maintenance savings or physical accuracy. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Time-series pipeline and state model; Dashboard and fault scenarios; Digital-twin assumptions and inspection runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
DuckDB — Open source · local
CSV ingestion, SQL transforms and reproducible analysis.
Alternative: SQLite (public domain) for embedded transactional SQL or PostgreSQL (open source) for a shared service.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Prometheus — Open source
Metrics collection and alert evidence.
Alternative: VictoriaMetrics has open-source and commercial editions; a managed monitoring service has separate retention and cost terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
DuckDB: https://duckdb.org/docs/stable/clients/python/overview
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
Prometheus: https://prometheus.io/docs/introduction/overview/
Siemens digital twin overview: https://www.siemens.com/en-us/company/digital-twin/
scikit-learn: https://scikit-learn.org/stable/user_guide.html
Prometheus: https://prometheus.io/docs/introduction/overview/
