# SAMPLE — Interaction-state specification and usability findings
Role: AI UX / product designer
Case: Users cannot undo an AI edit
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface.

## Evidence table
| Record | unrecoverable_edits (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 1 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three tasks lack a usable recovery path after an incorrect suggestion.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Add reviewable suggestions, version history and an accessible undo interaction.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai ux / product designer.
Before release: Test keyboard and assistive-technology recovery with intentionally wrong outputs.

## Design choice and trade-off
Design correction and recovery alongside the happy path; distinguish suggestion from approved content.
Extra review controls can add friction, so measure task completion and error recovery together.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
AI review interface: Users distinguish model suggestions from verified facts.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
