# AI UX / product designer

AI Engineering · Beginner → Intermediate → Advanced

Start with Calibrated user expectations. Users need to understand what an AI answer is based on and when to question it. Design a way to inspect, correct and recover from uncertain output. Then try Sketch a source-aware answer. The three levels build toward Trustworthy AI review experience. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Calibrated user expectations

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Calibrated user expectations
Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results.
Mental model: A weather forecast shows probabilities and lets you choose whether to carry an umbrella.
Boundary: Interface wording cannot compensate for systematically misleading outputs.
Worked example: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Users cannot undo an AI edit
The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Three tasks lack a usable recovery path after an incorrect suggestion. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Add reviewable suggestions, version history and an accessible undo interaction.
Recall: Test keyboard and assistive-technology recovery with intentionally wrong outputs. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Calibrated user expectations: Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Users need to understand what an AI answer is based on and when to question it. Design a way to inspect, correct and recover from uncertain output.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional study assistant answer: “The library closes at 6 pm”, supported by a library rules page.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated screen sketch and a three-question research script.

3. Try step 2
Sketch where the source link, uncertainty message and “report a problem” action would appear.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated screen sketch and a three-question research script.

4. Try step 3
Write three neutral questions to test whether a learner understands the answer and its source; record assumptions separately from observed feedback.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated screen sketch and a three-question research script.

5. Explain and check your result
A user can inspect the source and report an error; the design does not present a source link as proof that every answer is correct. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An annotated screen sketch and a three-question research script. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Apply this toy-case rule manually: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three tasks lack a usable recovery path after an incorrect suggestion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI UX / product designer.
Use a fictional study assistant answer: “The library closes at 6 pm”, supported by a library rules page.
Sketch where the source link, uncertainty message and “report a problem” action would appear.
Write three neutral questions to test whether a learner understands the answer and its source; record assumptions separately from observed feedback.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An annotated screen sketch and a three-question research script. Include beginner-worksheet.md and your completed Interaction-state specification and usability findings.
Check: A user can inspect the source and report an error; the design does not present a source link as proof that every answer is correct.

### Interview
Explain your beginner solution for AI UX / product designer. Use this scenario: The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface.
Review: Start with the task and permitted scope. Explain calibrated user expectations: Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results. Show the input and observed output, then address Add reviewable suggestions, version history and an accessible undo interaction. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An annotated screen sketch and a three-question research script. Include beginner-worksheet.md and your completed Interaction-state specification and usability findings.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Repairable interactions

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Interaction design, research methods, prototyping and accessibility; learn AI uncertainty and model limitations.

### Repairable interactions
Design for ambiguous input, partial results, interruptions and errors. Preserve user effort and make recovery actions understandable and keyboard accessible.
Mental model: An undoable pencil sketch is easier to correct than permanent ink.
Boundary: Undo may not reverse an external side effect that has already occurred.
Worked example: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Trustworthy AI review experience
Design and test an AI interface that makes uncertainty, evidence and user control understandable. Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.
Recall: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. Identify one observation that would contradict your claim.

### Terms
Repairable interactions: Design for ambiguous input, partial results, interruptions and errors. Preserve user effort and make recovery actions understandable and keyboard accessible.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and test an AI interface that makes uncertainty, evidence and user control understandable. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

2. Prepare the project inputs
Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the supplied wireframe SVG as a starting board in Penpot. Design input, generating, evidence review, correction, error and undo states with consistent navigation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and test an AI interface that makes uncertainty, evidence and user control understandable.
Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.
Use the supplied wireframe SVG as a starting board in Penpot. Design input, generating, evidence review, correction, error and undo states with consistent navigation.
Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes.
Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.
Deliverables: Interactive prototype and design system excerpt; Usability evidence and iteration log. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI UX / product designer. Use this scenario: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.
Review: Start with the task and permitted scope. Explain repairable interactions: Design for ambiguous input, partial results, interruptions and errors. Preserve user effort and make recovery actions understandable and keyboard accessible. Show the input and observed output, then address Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Interactive prototype and design system excerpt; Usability evidence and iteration log. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Usability evidence

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Usability evidence
Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers.
Mental model: Watch someone find the exit rather than only asking whether the signs look attractive.
Boundary: A small convenience sample cannot represent every user or disability.
Worked example: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Trustworthy AI review experience
Design and test an AI interface that makes uncertainty, evidence and user control understandable. Run moderated task sessions with consenting peers. Record behavior rather than leading opinions; revise the prototype and show before/after decisions.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.
Recall: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. Identify one observation that would contradict your claim.

### Terms
Usability evidence: Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and test an AI interface that makes uncertainty, evidence and user control understandable. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

2. Prepare the project inputs
Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the supplied wireframe SVG as a starting board in Penpot. Design input, generating, evidence review, correction, error and undo states with consistent navigation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run moderated task sessions with consenting peers. Record behavior rather than leading opinions; revise the prototype and show before/after decisions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and test an AI interface that makes uncertainty, evidence and user control understandable.
Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.
Use the supplied wireframe SVG as a starting board in Penpot. Design input, generating, evidence review, correction, error and undo states with consistent navigation.
Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes.
Run moderated task sessions with consenting peers. Record behavior rather than leading opinions; revise the prototype and show before/after decisions.
Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.
Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.
Build one flow in HTML and test keyboard and screen-reader behavior against the design.
Deliverables: Interactive prototype and design system excerpt; Usability evidence and iteration log; Accessible interaction specification. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. A reviewer must reproduce one result and identify which capabilities you implemented. Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.

### Interview
Explain your advanced solution for AI UX / product designer. Use this scenario: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.
Review: Start with the task and permitted scope. Explain usability evidence: Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers. Show the input and observed output, then address Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Interactive prototype and design system excerpt; Usability evidence and iteration log; Accessible interaction specification. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Penpot — Open source · hosted account or self-hosting
Connect prototype boards and test interaction flows; Figma is an alternative.
Alternative: Figma (commercial hosted service with plan-specific access); paper prototypes are sufficient for the first exercise.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

W3C WAI checks — Public guidance
Manual accessibility checks; preliminary checks are not full conformance assessment.
Alternative: Use manual keyboard and assistive-technology checks alongside axe-core (open source); automated tests do not replace WAI guidance or user testing.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/
W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Figma learning resources: https://help.figma.com/
W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
