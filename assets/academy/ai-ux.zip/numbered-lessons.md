# AI UX / product designer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Calibrated user expectations: Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Calibrated user expectations

Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results. In this role, work through: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A weather forecast shows probabilities and lets you choose whether to carry an umbrella.

Boundary: Interface wording cannot compensate for systematically misleading outputs.

Worked example: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI UX / product designer: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished.

Predict the worked case

Read this case without running a tool: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in calibrated user expectations.

Connect the concept to the role

Apply this rule: Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Interface wording cannot compensate for systematically misleading outputs.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies calibrated user expectations to this case: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Calibrated user expectations; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with calibrated user expectations. Use the glossary below, then write your prediction for: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI UX / product designer role interview. Explain calibrated user expectations using this case: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate calibrated user expectations to a system or workflow you know. Explain calibrated user expectations using this case: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain calibrated user expectations using this case: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished.

Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results. — Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results. Interface wording cannot compensate for systematically misleading outputs.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Diagnose: Users cannot undo an AI edit

The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Three tasks lack a usable recovery path after an incorrect suggestion. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Add reviewable suggestions, version history and an accessible undo interaction. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A weather forecast shows probabilities and lets you choose whether to carry an umbrella.

A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished.

Worked example: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Add reviewable suggestions, version history and an accessible undo interaction.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Calc (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Three tasks lack a usable recovery path after an incorrect suggestion. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Apply this toy-case rule manually: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Users need to understand what an AI answer is based on and when to question it. Design a way to inspect, correct and recover from uncertain output.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use a fictional study assistant answer: “The library closes at 6 pm”, supported by a library rules page.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated screen sketch and a three-question research script.

Preparation · Try step 2

Sketch where the source link, uncertainty message and “report a problem” action would appear.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated screen sketch and a three-question research script.

Preparation · Try step 3

Write three neutral questions to test whether a learner understands the answer and its source; record assumptions separately from observed feedback.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated screen sketch and a three-question research script.

Preparation · Explain and check your result

A user can inspect the source and report an error; the design does not present a source link as proof that every answer is correct. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: An annotated screen sketch and a three-question research script. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Apply this toy-case rule manually: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three tasks lack a usable recovery path after an incorrect suggestion. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three tasks lack a usable recovery path after an incorrect suggestion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: users cannot undo an ai edit. Use the glossary below, then write your prediction for: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Add reviewable suggestions, version history and an accessible undo interaction. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI UX / product designer role interview. Explain diagnose: users cannot undo an ai edit using this case: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Add reviewable suggestions, version history and an accessible undo interaction. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: users cannot undo an ai edit to a system or workflow you know. Explain diagnose: users cannot undo an ai edit using this case: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Add reviewable suggestions, version history and an accessible undo interaction. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Test keyboard and assistive-technology recovery with intentionally wrong outputs. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: users cannot undo an ai edit using this case: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Add reviewable suggestions, version history and an accessible undo interaction. State the evidence, one alternative and where the mental model stops.

Quiz: Users cannot undo an AI edit: The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface.

Change the acceptance rule after seeing an inconvenient result.

Add reviewable suggestions, version history and an accessible undo interaction.

Omit failed cases and report only the successful demonstrations.

Reference: Add reviewable suggestions, version history and an accessible undo interaction. — Add reviewable suggestions, version history and an accessible undo interaction. Test keyboard and assistive-technology recovery with intentionally wrong outputs.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Interaction design, research methods, prototyping and accessibility; learn AI uncertainty and model limitations.

Terms:

Repairable interactions: Design for ambiguous input, partial results, interruptions and errors. Preserve user effort and make recovery actions understandable and keyboard accessible.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Repairable interactions

Design for ambiguous input, partial results, interruptions and errors. Preserve user effort and make recovery actions understandable and keyboard accessible. In this role, work through: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An undoable pencil sketch is easier to correct than permanent ink.

Boundary: Undo may not reverse an external side effect that has already occurred.

Worked example: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Interaction design, research methods, prototyping and accessibility; learn AI uncertainty and model limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI UX / product designer: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form.

Predict the worked case

Read this case without running a tool: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in repairable interactions.

Connect the concept to the role

Apply this rule: Design for ambiguous input, partial results, interruptions and errors. Preserve user effort and make recovery actions understandable and keyboard accessible. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Undo may not reverse an external side effect that has already occurred.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies repairable interactions to this case: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Repairable interactions; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with repairable interactions. Use the glossary below, then write your prediction for: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI UX / product designer role interview. Explain repairable interactions using this case: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate repairable interactions to a system or workflow you know. Explain repairable interactions using this case: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain repairable interactions using this case: After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form.

Treat a passing starter as proof of the whole role workflow.

Design for ambiguous input, partial results, interruptions and errors. Preserve user effort and make recovery actions understandable and keyboard accessible.

Ignore the failure because the tool produced an output.

Reference: Design for ambiguous input, partial results, interruptions and errors. Preserve user effort and make recovery actions understandable and keyboard accessible. — Design for ambiguous input, partial results, interruptions and errors. Preserve user effort and make recovery actions understandable and keyboard accessible. Undo may not reverse an external side effect that has already occurred.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Integrate: Trustworthy AI review experience

Design and test an AI interface that makes uncertainty, evidence and user control understandable. Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes. In this role, work through: Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: An undoable pencil sketch is easier to correct than permanent ink.

After a timeout, retain the user's prompt and offer retry or manual completion instead of clearing the form.

Worked example: Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Calc (Open source · no account needed)

Design and test an AI interface that makes uncertainty, evidence and user control understandable. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design and test an AI interface that makes uncertainty, evidence and user control understandable.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

Prepare the project inputs

Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use the supplied wireframe SVG as a starting board in Penpot. Design input, generating, evidence review, correction, error and undo states with consistent navigation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Interactive prototype and design system excerpt; Usability evidence and iteration log. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: trustworthy ai review experience. Use the glossary below, then write your prediction for: Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI UX / product designer role interview. Explain integrate: trustworthy ai review experience using this case: Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: trustworthy ai review experience to a system or workflow you know. Explain integrate: trustworthy ai review experience using this case: Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. Identify one observation that would contradict your claim.

Interview: Explain integrate: trustworthy ai review experience using this case: Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Trustworthy AI review experience at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.

Reference: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. — Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Usability evidence: Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Usability evidence

Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers. In this role, work through: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Watch someone find the exit rather than only asking whether the signs look attractive.

Boundary: A small convenience sample cannot represent every user or disability.

Worked example: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI UX / product designer: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft.

Predict the worked case

Read this case without running a tool: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in usability evidence.

Connect the concept to the role

Apply this rule: Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A small convenience sample cannot represent every user or disability.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies usability evidence to this case: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Usability evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with usability evidence. Use the glossary below, then write your prediction for: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI UX / product designer role interview. Explain usability evidence using this case: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate usability evidence to a system or workflow you know. Explain usability evidence using this case: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain usability evidence using this case: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers.

Reference: Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers. — Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers. A small convenience sample cannot represent every user or disability.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Defend: Trustworthy AI review experience

Design and test an AI interface that makes uncertainty, evidence and user control understandable. Run moderated task sessions with consenting peers. Record behavior rather than leading opinions; revise the prototype and show before/after decisions. In this role, work through: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: Watch someone find the exit rather than only asking whether the signs look attractive.

Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft.

Worked example: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Calc (Open source · no account needed)

Design and test an AI interface that makes uncertainty, evidence and user control understandable. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design and test an AI interface that makes uncertainty, evidence and user control understandable.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

Prepare the project inputs

Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use the supplied wireframe SVG as a starting board in Penpot. Design input, generating, evidence review, correction, error and undo states with consistent navigation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Run moderated task sessions with consenting peers. Record behavior rather than leading opinions; revise the prototype and show before/after decisions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. A reviewer must reproduce one result and identify which capabilities you implemented. Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Interactive prototype and design system excerpt; Usability evidence and iteration log; Accessible interaction specification. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: trustworthy ai review experience. Use the glossary below, then write your prediction for: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI UX / product designer role interview. Explain defend: trustworthy ai review experience using this case: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: trustworthy ai review experience to a system or workflow you know. Explain defend: trustworthy ai review experience using this case: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. Identify one observation that would contradict your claim.

Interview: Explain defend: trustworthy ai review experience using this case: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Trustworthy AI review experience at this level?

Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft. — Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft. Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Figma learning resources: https://help.figma.com/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
