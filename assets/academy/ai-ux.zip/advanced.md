## advanced — Usability evidence

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Usability evidence
Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers.
Mental model: Watch someone find the exit rather than only asking whether the signs look attractive.
Boundary: A small convenience sample cannot represent every user or disability.
Worked example: Ask a peer to identify an unsupported answer using the prototype; record whether they find the source and correct the draft.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Trustworthy AI review experience
Design and test an AI interface that makes uncertainty, evidence and user control understandable. Run moderated task sessions with consenting peers. Record behavior rather than leading opinions; revise the prototype and show before/after decisions.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.
Recall: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. Identify one observation that would contradict your claim.

### Terms
Usability evidence: Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and test an AI interface that makes uncertainty, evidence and user control understandable. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

2. Prepare the project inputs
Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the supplied wireframe SVG as a starting board in Penpot. Design input, generating, evidence review, correction, error and undo states with consistent navigation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run moderated task sessions with consenting peers. Record behavior rather than leading opinions; revise the prototype and show before/after decisions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and test an AI interface that makes uncertainty, evidence and user control understandable.
Choose a fictional document assistant. Define user goals and create eight tasks including an incorrect suggestion, missing evidence and a recoverable failure.
Use the supplied wireframe SVG as a starting board in Penpot. Design input, generating, evidence review, correction, error and undo states with consistent navigation.
Connect interactions and write plain-language labels explaining what was generated and what requires review. Add keyboard order, focus behavior and status announcements to the handoff notes.
Run moderated task sessions with consenting peers. Record behavior rather than leading opinions; revise the prototype and show before/after decisions.
Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.
Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.
Build one flow in HTML and test keyboard and screen-reader behavior against the design.
Deliverables: Interactive prototype and design system excerpt; Usability evidence and iteration log; Accessible interaction specification. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. A reviewer must reproduce one result and identify which capabilities you implemented. Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.

### Interview
Explain your advanced solution for AI UX / product designer. Use this scenario: Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.
Review: Start with the task and permitted scope. Explain usability evidence: Observe people attempting realistic tasks and distinguish success from their opinion of the interface. Record confusion, correction behavior and accessibility barriers. Show the input and observed output, then address Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Interactive prototype and design system excerpt; Usability evidence and iteration log; Accessible interaction specification. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

