## beginner — Calibrated user expectations

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Calibrated user expectations
Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results.
Mental model: A weather forecast shows probabilities and lets you choose whether to carry an umbrella.
Boundary: Interface wording cannot compensate for systematically misleading outputs.
Worked example: A draft summary includes a link to the source and an edit action; it is not labeled verified merely because generation finished.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Users cannot undo an AI edit
The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Three tasks lack a usable recovery path after an incorrect suggestion. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Add reviewable suggestions, version history and an accessible undo interaction.
Recall: Test keyboard and assistive-technology recovery with intentionally wrong outputs. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Calibrated user expectations: Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Users need to understand what an AI answer is based on and when to question it. Design a way to inspect, correct and recover from uncertain output.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional study assistant answer: “The library closes at 6 pm”, supported by a library rules page.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated screen sketch and a three-question research script.

3. Try step 2
Sketch where the source link, uncertainty message and “report a problem” action would appear.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated screen sketch and a three-question research script.

4. Try step 3
Write three neutral questions to test whether a learner understands the answer and its source; record assumptions separately from observed feedback.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated screen sketch and a three-question research script.

5. Explain and check your result
A user can inspect the source and report an error; the design does not present a source link as proof that every answer is correct. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An annotated screen sketch and a three-question research script. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface. Apply this toy-case rule manually: Review when unrecoverable_edits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three tasks lack a usable recovery path after an incorrect suggestion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI UX / product designer.
Use a fictional study assistant answer: “The library closes at 6 pm”, supported by a library rules page.
Sketch where the source link, uncertainty message and “report a problem” action would appear.
Write three neutral questions to test whether a learner understands the answer and its source; record assumptions separately from observed feedback.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An annotated screen sketch and a three-question research script. Include beginner-worksheet.md and your completed Interaction-state specification and usability findings.
Check: A user can inspect the source and report an error; the design does not present a source link as proof that every answer is correct.

### Interview
Explain your beginner solution for AI UX / product designer. Use this scenario: The usability pilot flags any task where an incorrect generated edit cannot be reversed through the interface.
Review: Start with the task and permitted scope. Explain calibrated user expectations: Explain what an AI feature can do and make uncertainty visible without overwhelming the user. Give users ways to inspect, correct or reject results. Show the input and observed output, then address Add reviewable suggestions, version history and an accessible undo interaction. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An annotated screen sketch and a three-question research script. Include beginner-worksheet.md and your completed Interaction-state specification and usability findings.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

