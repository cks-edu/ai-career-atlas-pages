# Interactive prototype and design system excerpt

Project: Trustworthy AI review experience
Status: blank work product — not completed evidence

## Purpose and audience
Design and test an AI interface that makes uncertainty, evidence and user control understandable.

## Required content
Use the supplied wireframe SVG as a starting board in Penpot. Design input, generating, evidence review, correction, error and undo states with consistent navigation.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.

## Failure evidence
Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
