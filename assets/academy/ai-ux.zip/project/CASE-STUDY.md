# Trustworthy AI review experience

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Design and test an AI interface that makes uncertainty, evidence and user control understandable.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Present a confident but wrong answer and observe whether the participant can locate evidence, reject it and recover. Test loading failure without losing the user’s draft.

## Limitations and next iteration
Build one flow in HTML and test keyboard and screen-reader behavior against the design.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
