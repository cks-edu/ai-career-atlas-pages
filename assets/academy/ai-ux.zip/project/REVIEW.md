# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Interactive prototype and design system excerpt.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report task completion, error recovery, evidence discovery and accessibility findings. A clickable prototype does not prove backend reliability.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
