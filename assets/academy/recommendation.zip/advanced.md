## advanced — Feedback and exposure bias

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Feedback and exposure bias
Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes.
Mental model: A restaurant cannot infer dislike for dishes never offered.
Boundary: Offline correction methods rely on assumptions and do not replace responsible online validation.
Worked example: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Leakage-resistant recommendation benchmark
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. Evaluate warm users, new users and new items separately. Add a fallback for missing metadata and log the reason for every recommendation.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Recall: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. Identify one observation that would contradict your claim.

### Terms
Feedback and exposure bias: Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Evaluate warm users, new users and new items separately. Add a fallback for missing metadata and log the reason for every recommendation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage.
Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Evaluate warm users, new users and new items separately. Add a fallback for missing metadata and log the reason for every recommendation.
Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.
Build a small review UI to inspect relevance and diversity trade-offs.
Deliverables: Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices; Candidate-generation and fallback design. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A reviewer must reproduce one result and identify which capabilities you implemented. Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.

### Interview
Explain your advanced solution for Recommendation / ranking engineer. Use this scenario: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Review: Start with the task and permitted scope. Explain feedback and exposure bias: Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes. Show the input and observed output, then address Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices; Candidate-generation and fallback design. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

