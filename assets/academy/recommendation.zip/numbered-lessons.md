# Recommendation / ranking engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Ranking rather than classification: A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

### Ranking rather than classification

A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization. In this role, work through: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A shop display chooses what appears at eye level, not just what is in stock.

Boundary: Offline relevance judgments may not reflect satisfaction or long-term value.

Worked example: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); pgvector (Open source · PostgreSQL extension); PyTorch (Open source · hardware dependent)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Recommendation / ranking engineer: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order.

Predict the worked case

Read this case without running a tool: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in ranking rather than classification.

Connect the concept to the role

Apply this rule: A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Offline relevance judgments may not reflect satisfaction or long-term value.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies ranking rather than classification to this case: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Ranking rather than classification; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with ranking rather than classification. Use the glossary below, then write your prediction for: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Recommendation / ranking engineer role interview. Explain ranking rather than classification using this case: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate ranking rather than classification to a system or workflow you know. Explain ranking rather than classification using this case: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain ranking rather than classification using this case: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? For a held-out query with two relevant items, inspect whether either appears in the top five and in what order.

A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization. — A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization. Offline relevance judgments may not reflect satisfaction or long-term value.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Diagnose: The candidate stage loses the answer

The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Two candidate sets fall below the stated recall requirement before reranking begins. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Improve candidate generation and evaluate it separately from the reranker. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A shop display chooses what appears at eye level, not just what is in stock.

For a held-out query with two relevant items, inspect whether either appears in the top five and in what order.

Worked example: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Improve candidate generation and evaluate it separately from the reranker.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: scikit-learn (Open source · CPU); pgvector (Open source · PostgreSQL extension); PyTorch (Open source · hardware dependent)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Two candidate sets fall below the stated recall requirement before reranking begins. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Apply this toy-case rule manually: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Precision asks how many returned items are useful. Recall asks how many of all useful items were found.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Suppose relevant books are A, C and E. A system recommends A, B and C.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Two ranked lists with worked precision and recall calculations.

Preparation · Try step 2

Count relevant returned books and calculate precision and recall.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Two ranked lists with worked precision and recall calculations.

Preparation · Try step 3

Replace C with D and recalculate; explain why a plausible-looking list may score worse.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Two ranked lists with worked precision and recall calculations.

Preparation · Explain and check your result

The first list scores 2/3 on both; the second scores 1/3 on both. These set-based metrics do not measure ordering quality. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: Two ranked lists with worked precision and recall calculations. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Apply this toy-case rule manually: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two candidate sets fall below the stated recall requirement before reranking begins. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two candidate sets fall below the stated recall requirement before reranking begins. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the candidate stage loses the answer. Use the glossary below, then write your prediction for: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Improve candidate generation and evaluate it separately from the reranker. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Recommendation / ranking engineer role interview. Explain diagnose: the candidate stage loses the answer using this case: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Improve candidate generation and evaluate it separately from the reranker. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the candidate stage loses the answer to a system or workflow you know. Explain diagnose: the candidate stage loses the answer using this case: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Improve candidate generation and evaluate it separately from the reranker. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure recall at fixed k on the same time-held-out user groups. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the candidate stage loses the answer using this case: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Improve candidate generation and evaluate it separately from the reranker. State the evidence, one alternative and where the mental model stops.

Quiz: The candidate stage loses the answer: The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal.

Change the acceptance rule after seeing an inconvenient result.

Improve candidate generation and evaluate it separately from the reranker.

Omit failed cases and report only the successful demonstrations.

Reference: Improve candidate generation and evaluate it separately from the reranker. — Improve candidate generation and evaluate it separately from the reranker. Measure recall at fixed k on the same time-held-out user groups.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Data pipelines, statistics, retrieval and online-serving fundamentals.

Terms:

Candidate generation and reranking: Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Candidate generation and reranking

Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item. In this role, work through: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A recruiter shortlists candidates before detailed interviews.

Boundary: Increasing candidate count can increase latency and cost.

Worked example: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Data pipelines, statistics, retrieval and online-serving fundamentals.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); pgvector (Open source · PostgreSQL extension); PyTorch (Open source · hardware dependent)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Recommendation / ranking engineer: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first.

Predict the worked case

Read this case without running a tool: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in candidate generation and reranking.

Connect the concept to the role

Apply this rule: Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Increasing candidate count can increase latency and cost.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies candidate generation and reranking to this case: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Candidate generation and reranking; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with candidate generation and reranking. Use the glossary below, then write your prediction for: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Recommendation / ranking engineer role interview. Explain candidate generation and reranking using this case: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate candidate generation and reranking to a system or workflow you know. Explain candidate generation and reranking using this case: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain candidate generation and reranking using this case: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first.

Treat a passing starter as proof of the whole role workflow.

Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item.

Ignore the failure because the tool produced an output.

Reference: Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item. — Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item. Increasing candidate count can increase latency and cost.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Integrate: Leakage-resistant recommendation benchmark

Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff. In this role, work through: Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: A recruiter shortlists candidates before detailed interviews.

A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first.

Worked example: Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); pgvector (Open source · PostgreSQL extension); PyTorch (Open source · hardware dependent)

Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-intermediate-2.md: Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: leakage-resistant recommendation benchmark. Use the glossary below, then write your prediction for: Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Recommendation / ranking engineer role interview. Explain integrate: leakage-resistant recommendation benchmark using this case: Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: leakage-resistant recommendation benchmark to a system or workflow you know. Explain integrate: leakage-resistant recommendation benchmark using this case: Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. Identify one observation that would contradict your claim.

Interview: Explain integrate: leakage-resistant recommendation benchmark using this case: Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Leakage-resistant recommendation benchmark at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.

Reference: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. — Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Feedback and exposure bias: Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Feedback and exposure bias

Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes. In this role, work through: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A restaurant cannot infer dislike for dishes never offered.

Boundary: Offline correction methods rely on assumptions and do not replace responsible online validation.

Worked example: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); pgvector (Open source · PostgreSQL extension); PyTorch (Open source · hardware dependent)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Recommendation / ranking engineer: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels.

Predict the worked case

Read this case without running a tool: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in feedback and exposure bias.

Connect the concept to the role

Apply this rule: Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Offline correction methods rely on assumptions and do not replace responsible online validation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies feedback and exposure bias to this case: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Feedback and exposure bias; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with feedback and exposure bias. Use the glossary below, then write your prediction for: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Recommendation / ranking engineer role interview. Explain feedback and exposure bias using this case: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate feedback and exposure bias to a system or workflow you know. Explain feedback and exposure bias using this case: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain feedback and exposure bias using this case: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes.

Reference: Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes. — Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes. Offline correction methods rely on assumptions and do not replace responsible online validation.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Defend: Leakage-resistant recommendation benchmark

Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. Evaluate warm users, new users and new items separately. Add a fallback for missing metadata and log the reason for every recommendation. In this role, work through: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: A restaurant cannot infer dislike for dishes never offered.

A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels.

Worked example: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); pgvector (Open source · PostgreSQL extension); PyTorch (Open source · hardware dependent)

Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Evaluate warm users, new users and new items separately. Add a fallback for missing metadata and log the reason for every recommendation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A reviewer must reproduce one result and identify which capabilities you implemented. Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-advanced-2.md: Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices; Candidate-generation and fallback design. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: leakage-resistant recommendation benchmark. Use the glossary below, then write your prediction for: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Recommendation / ranking engineer role interview. Explain defend: leakage-resistant recommendation benchmark using this case: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: leakage-resistant recommendation benchmark to a system or workflow you know. Explain defend: leakage-resistant recommendation benchmark using this case: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. Identify one observation that would contradict your claim.

Interview: Explain defend: leakage-resistant recommendation benchmark using this case: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Leakage-resistant recommendation benchmark at this level?

Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback. — Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback. Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

pgvector: https://github.com/pgvector/pgvector

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
