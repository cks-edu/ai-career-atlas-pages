# Recommendation / ranking engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Ranking rather than classification. Precision asks how many returned items are useful. Recall asks how many of all useful items were found. Then try Score a tiny recommendation list. The three levels build toward Leakage-resistant recommendation benchmark. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Ranking rather than classification

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Ranking rather than classification
A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization.
Mental model: A shop display chooses what appears at eye level, not just what is in stock.
Boundary: Offline relevance judgments may not reflect satisfaction or long-term value.
Worked example: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The candidate stage loses the answer
The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Two candidate sets fall below the stated recall requirement before reranking begins. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Improve candidate generation and evaluate it separately from the reranker.
Recall: Measure recall at fixed k on the same time-held-out user groups. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Ranking rather than classification: A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Precision asks how many returned items are useful. Recall asks how many of all useful items were found.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Suppose relevant books are A, C and E. A system recommends A, B and C.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two ranked lists with worked precision and recall calculations.

3. Try step 2
Count relevant returned books and calculate precision and recall.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two ranked lists with worked precision and recall calculations.

4. Try step 3
Replace C with D and recalculate; explain why a plausible-looking list may score worse.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two ranked lists with worked precision and recall calculations.

5. Explain and check your result
The first list scores 2/3 on both; the second scores 1/3 on both. These set-based metrics do not measure ordering quality. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Two ranked lists with worked precision and recall calculations. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Apply this toy-case rule manually: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two candidate sets fall below the stated recall requirement before reranking begins. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Recommendation / ranking engineer.
Suppose relevant books are A, C and E. A system recommends A, B and C.
Count relevant returned books and calculate precision and recall.
Replace C with D and recalculate; explain why a plausible-looking list may score worse.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Two ranked lists with worked precision and recall calculations. Include beginner-worksheet.md and your completed Retrieval-versus-ranking error analysis.
Check: The first list scores 2/3 on both; the second scores 1/3 on both. These set-based metrics do not measure ordering quality.

### Interview
Explain your beginner solution for Recommendation / ranking engineer. Use this scenario: The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal.
Review: Start with the task and permitted scope. Explain ranking rather than classification: A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization. Show the input and observed output, then address Improve candidate generation and evaluate it separately from the reranker. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Two ranked lists with worked precision and recall calculations. Include beginner-worksheet.md and your completed Retrieval-versus-ranking error analysis.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Candidate generation and reranking

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Data pipelines, statistics, retrieval and online-serving fundamentals.

### Candidate generation and reranking
Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item.
Mental model: A recruiter shortlists candidates before detailed interviews.
Boundary: Increasing candidate count can increase latency and cost.
Worked example: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Leakage-resistant recommendation benchmark
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Recall: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. Identify one observation that would contradict your claim.

### Terms
Candidate generation and reranking: Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage.
Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.
Deliverables: Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Recommendation / ranking engineer. Use this scenario: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Review: Start with the task and permitted scope. Explain candidate generation and reranking: Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item. Show the input and observed output, then address Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Feedback and exposure bias

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Feedback and exposure bias
Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes.
Mental model: A restaurant cannot infer dislike for dishes never offered.
Boundary: Offline correction methods rely on assumptions and do not replace responsible online validation.
Worked example: A top-ranked item gets more clicks partly because it is visible. Record position and exposure before using clicks as training labels.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Leakage-resistant recommendation benchmark
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. Evaluate warm users, new users and new items separately. Add a fallback for missing metadata and log the reason for every recommendation.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Recall: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. Identify one observation that would contradict your claim.

### Terms
Feedback and exposure bias: Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Evaluate warm users, new users and new items separately. Add a fallback for missing metadata and log the reason for every recommendation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage.
Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Evaluate warm users, new users and new items separately. Add a fallback for missing metadata and log the reason for every recommendation.
Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.
Build a small review UI to inspect relevance and diversity trade-offs.
Deliverables: Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices; Candidate-generation and fallback design. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A reviewer must reproduce one result and identify which capabilities you implemented. Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.

### Interview
Explain your advanced solution for Recommendation / ranking engineer. Use this scenario: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Review: Start with the task and permitted scope. Explain feedback and exposure bias: Observed clicks depend on what was shown and where it was placed. Keep exposure records and avoid treating unseen items as confirmed dislikes. Show the input and observed output, then address Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices; Candidate-generation and fallback design. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

pgvector — Open source · PostgreSQL extension
Vector retrieval comparison; requires a PostgreSQL installation.
Alternative: OpenSearch (open source) or a commercial managed vector service; compare filters, indexing and operating cost.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
pgvector: https://github.com/pgvector/pgvector
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
scikit-learn: https://scikit-learn.org/stable/user_guide.html
pgvector: https://github.com/pgvector/pgvector
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
