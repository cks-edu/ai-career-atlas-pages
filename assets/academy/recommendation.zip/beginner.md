## beginner — Ranking rather than classification

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Ranking rather than classification
A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization.
Mental model: A shop display chooses what appears at eye level, not just what is in stock.
Boundary: Offline relevance judgments may not reflect satisfaction or long-term value.
Worked example: For a held-out query with two relevant items, inspect whether either appears in the top five and in what order.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The candidate stage loses the answer
The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Two candidate sets fall below the stated recall requirement before reranking begins. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Improve candidate generation and evaluate it separately from the reranker.
Recall: Measure recall at fixed k on the same time-held-out user groups. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Ranking rather than classification: A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Precision asks how many returned items are useful. Recall asks how many of all useful items were found.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Suppose relevant books are A, C and E. A system recommends A, B and C.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two ranked lists with worked precision and recall calculations.

3. Try step 2
Count relevant returned books and calculate precision and recall.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two ranked lists with worked precision and recall calculations.

4. Try step 3
Replace C with D and recalculate; explain why a plausible-looking list may score worse.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two ranked lists with worked precision and recall calculations.

5. Explain and check your result
The first list scores 2/3 on both; the second scores 1/3 on both. These set-based metrics do not measure ordering quality. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Two ranked lists with worked precision and recall calculations. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Apply this toy-case rule manually: Review when missing_relevant >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two candidate sets fall below the stated recall requirement before reranking begins. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Recommendation / ranking engineer.
Suppose relevant books are A, C and E. A system recommends A, B and C.
Count relevant returned books and calculate precision and recall.
Replace C with D and recalculate; explain why a plausible-looking list may score worse.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Two ranked lists with worked precision and recall calculations. Include beginner-worksheet.md and your completed Retrieval-versus-ranking error analysis.
Check: The first list scores 2/3 on both; the second scores 1/3 on both. These set-based metrics do not measure ordering quality.

### Interview
Explain your beginner solution for Recommendation / ranking engineer. Use this scenario: The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal.
Review: Start with the task and permitted scope. Explain ranking rather than classification: A recommender orders candidates for a user or context. Evaluate the top results and include a simple popularity baseline before adding personalization. Show the input and observed output, then address Improve candidate generation and evaluate it separately from the reranker. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Two ranked lists with worked precision and recall calculations. Include beginner-worksheet.md and your completed Retrieval-versus-ranking error analysis.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

