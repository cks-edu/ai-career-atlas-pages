# Baseline/ranker comparison with cold-start slices

Project: Leakage-resistant recommendation benchmark
Status: blank work product — not completed evidence

## Purpose and audience
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage.

## Required content
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.

## Failure evidence
Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
