# Leakage-resistant recommendation benchmark

Career: Recommendation / ranking engineer
Reviewed: 2026-10-22

Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage.

## Prerequisites
Data pipelines, statistics, retrieval and online-serving fundamentals.

## Included starter versus your implementation
A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Evaluate warm users, new users and new items separately. Add a fallback for missing metadata and log the reason for every recommendation.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Recommender code and temporal data manifest — artifact-1.md
2. Baseline/ranker comparison with cold-start slices — artifact-2.md
3. Candidate-generation and fallback design — artifact-3.md

## Troubleshooting
- Poor metrics: inspect class balance and split construction before tuning.
- Too-good metrics: check duplicate groups and target-derived features.
- Changed results: compare package versions, seeds and preprocessing.

## Extension
Build a small review UI to inspect relevance and diversity trade-offs.

## Primary learning resources
- scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html — Open source · CPU; Pipelines, baselines, data splits and statistical evaluation.
- pgvector: https://github.com/pgvector/pgvector — Open source · PostgreSQL extension; Vector retrieval comparison; requires a PostgreSQL installation.
- PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html — Open source · hardware dependent; Tensor operations, training and hardware-aware profiling.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
