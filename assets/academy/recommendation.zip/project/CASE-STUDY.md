# Leakage-resistant recommendation benchmark

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.

## Limitations and next iteration
Build a small review UI to inspect relevance and diversity trade-offs.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
