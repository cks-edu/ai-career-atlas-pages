# SAMPLE — Retrieval-versus-ranking error analysis
Role: Recommendation / ranking engineer
Case: The candidate stage loses the answer
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal.

## Evidence table
| Record | missing_relevant (out of ten) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 6 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two candidate sets fall below the stated recall requirement before reranking begins.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Improve candidate generation and evaluate it separately from the reranker.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in recommendation / ranking engineer.
Before release: Measure recall at fixed k on the same time-held-out user groups.

## Design choice and trade-off
Separate candidate recall, rank quality and exposure effects; log the stage that removed useful items.
More candidates can improve recall while increasing reranking cost and latency.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Content recommender: Evaluate cold-start users without using future interactions.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
