## intermediate — Candidate generation and reranking

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Data pipelines, statistics, retrieval and online-serving fundamentals.

### Candidate generation and reranking
Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item.
Mental model: A recruiter shortlists candidates before detailed interviews.
Boundary: Increasing candidate count can increase latency and cost.
Worked example: A relevant item absent from the shortlist cannot be rescued by a perfect reranker; measure candidate recall first.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Leakage-resistant recommendation benchmark
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Recall: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. Identify one observation that would contradict your claim.

### Terms
Candidate generation and reranking: Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The search pilot flags candidate sets with fewer than eight of ten labeled relevant items. Use missing items as the signal. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build and evaluate a small item recommender that handles cold starts and avoids future-information leakage.
Use a licensed interaction dataset with user, item and time fields. Define a temporal cutoff and a documented candidate set; do not use random row splitting for a future-recommendation claim.
Implement popularity and recent-popularity baselines. Save the exact candidate set and exclude previously consumed items where the task requires it.
Build item-content retrieval using TF-IDF or embeddings, then add a learned ranker using only information available before the cutoff.
Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit.
Deliverables: Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Recommendation / ranking engineer. Use this scenario: Insert an item available only after the cutoff and prove it cannot enter training or candidates. Remove metadata for a cold-start item and exercise fallback.
Review: Start with the task and permitted scope. Explain candidate generation and reranking: Use a fast retrieval stage to find plausible items, then a richer scorer on that smaller set. Diagnose which stage lost a relevant item. Show the input and observed output, then address Report Recall@K, NDCG@K, coverage and latency with the candidate protocol. Offline gains do not establish online user benefit. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Recommender code and temporal data manifest; Baseline/ranker comparison with cold-start slices. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

