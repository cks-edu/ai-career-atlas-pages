# Interruptible voice booking assistant

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

## Limitations and next iteration
Compare a streaming ASR service with the batch baseline, documenting billing, data retention and supported language differences before uploading audio.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
