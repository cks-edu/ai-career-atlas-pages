# Per-clip transcript and latency scorecard

Project: Interruptible voice booking assistant
Status: blank work product — not completed evidence

## Purpose and audience
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.

## Required content
Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.

## Failure evidence
While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
