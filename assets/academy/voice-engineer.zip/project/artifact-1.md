# Audio pipeline and consent/provenance register

Project: Interruptible voice booking assistant
Status: blank work product — not completed evidence

## Purpose and audience
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.

## Required content
Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.

## Failure evidence
While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
