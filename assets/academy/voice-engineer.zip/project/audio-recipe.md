# Add audio after the text flow works

Install FFmpeg from its official distribution. In your virtual environment install `openai-whisper` and `jiwer`. Supply a licensed/self-recorded `input.wav`; these commands do not generate audio or consent.

```sh
python -m pip install openai-whisper jiwer
ffmpeg -i input.wav -ac 1 -ar 16000 -c:a pcm_s16le normalized.wav
whisper normalized.wav --model tiny --output_dir output --output_format json
```

Retain the original and the normalization settings. Add the returned transcript to the versioned conversation state; do not implement interruption by merely replacing text on screen.
