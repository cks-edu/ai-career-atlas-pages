# State machine and interruption demo

Project: Interruptible voice booking assistant
Status: blank work product — not completed evidence

## Purpose and audience
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.

## Required content
Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.

## Failure evidence
While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
