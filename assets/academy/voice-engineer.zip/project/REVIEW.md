# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Audio pipeline and consent/provenance register.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
