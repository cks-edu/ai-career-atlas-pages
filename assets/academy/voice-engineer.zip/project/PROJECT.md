# Interruptible voice booking assistant

Career: Conversational / voice AI engineer
Reviewed: 2026-10-22

Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.

## Prerequisites
Streaming systems, audio basics, concurrency and latency measurement.

## Included starter versus your implementation
FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

## Portfolio deliverables
1. Audio pipeline and consent/provenance register — artifact-1.md
2. State machine and interruption demo — artifact-2.md
3. Per-clip transcript and latency scorecard — artifact-3.md

## Troubleshooting
- Port occupied: select an unused local port and update client URLs.
- 422 response: inspect the request JSON and schema.
- Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.

## Extension
Compare a streaming ASR service with the batch baseline, documenting billing, data retention and supported language differences before uploading audio.

## Primary learning resources
- FastAPI: https://fastapi.tiangolo.com/tutorial/ — Open source · local; Typed API, validation and local service tests.
- Whisper: https://github.com/openai/whisper — Open source code/weights · compute required; Batch speech transcription; requires FFmpeg and model downloads.
- FFmpeg: https://ffmpeg.org/ffmpeg.html — Open source · build licenses vary; Audio conversion without overwriting originals.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
