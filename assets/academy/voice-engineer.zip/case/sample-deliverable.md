# SAMPLE — Voice timing trace and repair dialogue
Role: Conversational / voice AI engineer
Case: Barge-in arrives after stale audio
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The prototype declares a failure if cancelled speech keeps playing for more than 250 ms.

## Evidence table
| Record | stale_playback (milliseconds) | Decision |
|---|---:|---|
| case-1 | 80 | within_demo_bound |
| case-2 | 250 | within_demo_bound |
| case-3 | 260 | review |
| case-4 | 620 | review |
| case-5 | 90 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two interrupted calls play stale audio beyond the declared bound.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Cancel the active playback generation and flush its buffer on confirmed interruption.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in conversational / voice ai engineer.
Before release: Test interruption during synthesis and playback while preserving confirmed appointment fields.

## Design choice and trade-off
Track each audio generation separately; distinguish transcript revisions from confirmed dialogue state.
Aggressive interruption improves responsiveness but may react to noise; evaluate false interruptions alongside latency.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Voice appointment prototype: Dates and names are explicitly confirmed and interruptions work.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
