# Conversational / voice AI engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Audio pipeline budgets: A voice application captures sound, detects speech, transcribes it, chooses a response and produces audio. Measure each stage because delays accumulate and transcription can change intent.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Audio pipeline budgets

A voice application captures sound, detects speech, transcribes it, chooses a response and produces audio. Measure each stage because delays accumulate and transcription can change intent. In this role, work through: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A relay team can lose time at any handoff.

Boundary: Text-only tests do not measure microphone, noise or playback behavior.

Worked example: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Conversational / voice AI engineer: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer.

Predict the worked case

Read this case without running a tool: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in audio pipeline budgets.

Connect the concept to the role

Apply this rule: A voice application captures sound, detects speech, transcribes it, chooses a response and produces audio. Measure each stage because delays accumulate and transcription can change intent. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Text-only tests do not measure microphone, noise or playback behavior.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies audio pipeline budgets to this case: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Audio pipeline budgets; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with audio pipeline budgets. Use the glossary below, then write your prediction for: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversational / voice AI engineer role interview. Explain audio pipeline budgets using this case: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate audio pipeline budgets to a system or workflow you know. Explain audio pipeline budgets using this case: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain audio pipeline budgets using this case: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer.

A voice application captures sound, detects speech, transcribes it, chooses a response and produces audio. Measure each stage because delays accumulate and transcription can change intent.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: A voice application captures sound, detects speech, transcribes it, chooses a response and produces audio. Measure each stage because delays accumulate and transcription can change intent. — A voice application captures sound, detects speech, transcribes it, chooses a response and produces audio. Measure each stage because delays accumulate and transcription can change intent. Text-only tests do not measure microphone, noise or playback behavior.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

OpenTelemetry: https://opentelemetry.io/docs/

### Diagnose: Barge-in arrives after stale audio

The prototype declares a failure if cancelled speech keeps playing for more than 250 ms. Two interrupted calls play stale audio beyond the declared bound. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Cancel the active playback generation and flush its buffer on confirmed interruption. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A relay team can lose time at any handoff.

Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer.

Worked example: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Cancel the active playback generation and flush its buffer on confirmed interruption.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: FastAPI (Open source · local); Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The prototype declares a failure if cancelled speech keeps playing for more than 250 ms. Two interrupted calls play stale audio beyond the declared bound. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The prototype declares a failure if cancelled speech keeps playing for more than 250 ms. Apply this toy-case rule manually: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A voice assistant records sound, converts speech to text, prepares a reply and plays audio. Time until the reply starts is different from the total call duration.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Draw: speech ends → transcription ready → reply ready → playback begins.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled timing diagram and an interruption-handling note.

Preparation · Try step 2

Use fictional times after speech ends: 0 ms, 300 ms, 900 ms and 1100 ms. A millisecond (ms) is one thousandth of a second. Calculate the time spent between each event.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled timing diagram and an interruption-handling note.

Preparation · Try step 3

Add a branch for a user who starts speaking again while the reply is playing.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled timing diagram and an interruption-handling note.

Preparation · Explain and check your result

The reply starts after 1100 ms; the diagram does not describe that number as the length of the whole conversation. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A labeled timing diagram and an interruption-handling note. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The prototype declares a failure if cancelled speech keeps playing for more than 250 ms. Apply this toy-case rule manually: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two interrupted calls play stale audio beyond the declared bound. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two interrupted calls play stale audio beyond the declared bound. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: barge-in arrives after stale audio. Use the glossary below, then write your prediction for: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Cancel the active playback generation and flush its buffer on confirmed interruption. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversational / voice AI engineer role interview. Explain diagnose: barge-in arrives after stale audio using this case: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Cancel the active playback generation and flush its buffer on confirmed interruption. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: barge-in arrives after stale audio to a system or workflow you know. Explain diagnose: barge-in arrives after stale audio using this case: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Cancel the active playback generation and flush its buffer on confirmed interruption. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Test interruption during synthesis and playback while preserving confirmed appointment fields. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: barge-in arrives after stale audio using this case: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Cancel the active playback generation and flush its buffer on confirmed interruption. State the evidence, one alternative and where the mental model stops.

Quiz: Barge-in arrives after stale audio: The prototype declares a failure if cancelled speech keeps playing for more than 250 ms.

Change the acceptance rule after seeing an inconvenient result.

Cancel the active playback generation and flush its buffer on confirmed interruption.

Omit failed cases and report only the successful demonstrations.

Reference: Cancel the active playback generation and flush its buffer on confirmed interruption. — Cancel the active playback generation and flush its buffer on confirmed interruption. Test interruption during synthesis and playback while preserving confirmed appointment fields.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

OpenTelemetry: https://opentelemetry.io/docs/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Streaming systems, audio basics, concurrency and latency measurement.

Terms:

Turn taking and interruption: Track whether the person or system currently has the turn. When a user interrupts, stop obsolete playback and prevent an old generated response from taking over the new turn.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Turn taking and interruption

Track whether the person or system currently has the turn. When a user interrupts, stop obsolete playback and prevent an old generated response from taking over the new turn. In this role, work through: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A considerate conversation partner stops speaking when someone corrects them.

Boundary: Speech detection can misclassify background noise; test false interruptions.

Worked example: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Streaming systems, audio basics, concurrency and latency measurement.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Conversational / voice AI engineer: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action.

Predict the worked case

Read this case without running a tool: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in turn taking and interruption.

Connect the concept to the role

Apply this rule: Track whether the person or system currently has the turn. When a user interrupts, stop obsolete playback and prevent an old generated response from taking over the new turn. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Speech detection can misclassify background noise; test false interruptions.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies turn taking and interruption to this case: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Turn taking and interruption; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with turn taking and interruption. Use the glossary below, then write your prediction for: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversational / voice AI engineer role interview. Explain turn taking and interruption using this case: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate turn taking and interruption to a system or workflow you know. Explain turn taking and interruption using this case: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain turn taking and interruption using this case: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action.

Treat a passing starter as proof of the whole role workflow.

Track whether the person or system currently has the turn. When a user interrupts, stop obsolete playback and prevent an old generated response from taking over the new turn.

Ignore the failure because the tool produced an output.

Reference: Track whether the person or system currently has the turn. When a user interrupts, stop obsolete playback and prevent an old generated response from taking over the new turn. — Track whether the person or system currently has the turn. When a user interrupts, stop obsolete playback and prevent an old generated response from taking over the new turn. Speech detection can misclassify background noise; test false interruptions.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

OpenTelemetry: https://opentelemetry.io/docs/

### Integrate: Interruptible voice booking assistant

Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts. In this role, work through: Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A considerate conversation partner stops speaking when someone corrects them.

User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action.

Worked example: Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary)

Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The prototype declares a failure if cancelled speech keeps playing for more than 250 ms. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-intermediate-2.md: Audio pipeline and consent/provenance register; State machine and interruption demo. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: interruptible voice booking assistant. Use the glossary below, then write your prediction for: Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversational / voice AI engineer role interview. Explain integrate: interruptible voice booking assistant using this case: Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: interruptible voice booking assistant to a system or workflow you know. Explain integrate: interruptible voice booking assistant using this case: Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. Identify one observation that would contradict your claim.

Interview: Explain integrate: interruptible voice booking assistant using this case: Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Interruptible voice booking assistant at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.

Reference: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. — Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

OpenTelemetry: https://opentelemetry.io/docs/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Conversation recovery: Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

ASR: Automatic speech recognition: converting speech audio into text.

### Conversation recovery

Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy. In this role, work through: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Ask someone to repeat an unclear address instead of guessing where to send a parcel.

Boundary: Perfect transcription does not guarantee a safe action or useful dialogue.

Worked example: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Conversational / voice AI engineer: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it.

Predict the worked case

Read this case without running a tool: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in conversation recovery.

Connect the concept to the role

Apply this rule: Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Perfect transcription does not guarantee a safe action or useful dialogue.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies conversation recovery to this case: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Conversation recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with conversation recovery. Use the glossary below, then write your prediction for: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversational / voice AI engineer role interview. Explain conversation recovery using this case: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate conversation recovery to a system or workflow you know. Explain conversation recovery using this case: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain conversation recovery using this case: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy.

Reference: Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy. — Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy. Perfect transcription does not guarantee a safe action or useful dialogue.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

OpenTelemetry: https://opentelemetry.io/docs/

### Defend: Interruptible voice booking assistant

Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes. In this role, work through: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: Ask someone to repeat an unclear address instead of guessing where to send a parcel.

The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it.

Worked example: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary)

Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. A reviewer must reproduce one result and identify which capabilities you implemented. While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-advanced-2.md: Audio pipeline and consent/provenance register; State machine and interruption demo; Per-clip transcript and latency scorecard. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: interruptible voice booking assistant. Use the glossary below, then write your prediction for: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Conversational / voice AI engineer role interview. Explain defend: interruptible voice booking assistant using this case: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: interruptible voice booking assistant to a system or workflow you know. Explain defend: interruptible voice booking assistant using this case: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. Identify one observation that would contradict your claim.

Interview: Explain defend: interruptible voice booking assistant using this case: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Interruptible voice booking assistant at this level?

While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking. — While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking. Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

OpenTelemetry: https://opentelemetry.io/docs/
