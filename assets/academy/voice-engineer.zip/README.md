# Conversational / voice AI engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Audio pipeline budgets. A voice assistant records sound, converts speech to text, prepares a reply and plays audio. Time until the reply starts is different from the total call duration. Then try Trace a fictional voice request. The three levels build toward Interruptible voice booking assistant. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Audio pipeline budgets

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Audio pipeline budgets
A voice application captures sound, detects speech, transcribes it, chooses a response and produces audio. Measure each stage because delays accumulate and transcription can change intent.
Mental model: A relay team can lose time at any handoff.
Boundary: Text-only tests do not measure microphone, noise or playback behavior.
Worked example: Record capture-to-transcript and transcript-to-first-audio separately; a slow recognizer cannot be fixed by shortening only the generated answer.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Barge-in arrives after stale audio
The prototype declares a failure if cancelled speech keeps playing for more than 250 ms. Two interrupted calls play stale audio beyond the declared bound. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Cancel the active playback generation and flush its buffer on confirmed interruption.
Recall: Test interruption during synthesis and playback while preserving confirmed appointment fields. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Audio pipeline budgets: A voice application captures sound, detects speech, transcribes it, chooses a response and produces audio. Measure each stage because delays accumulate and transcription can change intent.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A voice assistant records sound, converts speech to text, prepares a reply and plays audio. Time until the reply starts is different from the total call duration.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Draw: speech ends → transcription ready → reply ready → playback begins.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled timing diagram and an interruption-handling note.

3. Try step 2
Use fictional times after speech ends: 0 ms, 300 ms, 900 ms and 1100 ms. A millisecond (ms) is one thousandth of a second. Calculate the time spent between each event.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled timing diagram and an interruption-handling note.

4. Try step 3
Add a branch for a user who starts speaking again while the reply is playing.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled timing diagram and an interruption-handling note.

5. Explain and check your result
The reply starts after 1100 ms; the diagram does not describe that number as the length of the whole conversation. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A labeled timing diagram and an interruption-handling note. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The prototype declares a failure if cancelled speech keeps playing for more than 250 ms. Apply this toy-case rule manually: Review when stale_playback > 250 (milliseconds). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two interrupted calls play stale audio beyond the declared bound. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Conversational / voice AI engineer.
Draw: speech ends → transcription ready → reply ready → playback begins.
Use fictional times after speech ends: 0 ms, 300 ms, 900 ms and 1100 ms. A millisecond (ms) is one thousandth of a second. Calculate the time spent between each event.
Add a branch for a user who starts speaking again while the reply is playing.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A labeled timing diagram and an interruption-handling note. Include beginner-worksheet.md and your completed Voice timing trace and repair dialogue.
Check: The reply starts after 1100 ms; the diagram does not describe that number as the length of the whole conversation.

### Interview
Explain your beginner solution for Conversational / voice AI engineer. Use this scenario: The prototype declares a failure if cancelled speech keeps playing for more than 250 ms.
Review: Start with the task and permitted scope. Explain audio pipeline budgets: A voice application captures sound, detects speech, transcribes it, chooses a response and produces audio. Measure each stage because delays accumulate and transcription can change intent. Show the input and observed output, then address Cancel the active playback generation and flush its buffer on confirmed interruption. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A labeled timing diagram and an interruption-handling note. Include beginner-worksheet.md and your completed Voice timing trace and repair dialogue.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Turn taking and interruption

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Streaming systems, audio basics, concurrency and latency measurement.

### Turn taking and interruption
Track whether the person or system currently has the turn. When a user interrupts, stop obsolete playback and prevent an old generated response from taking over the new turn.
Mental model: A considerate conversation partner stops speaking when someone corrects them.
Boundary: Speech detection can misclassify background noise; test false interruptions.
Worked example: User says cancel while a reply plays. Record the interruption, stop playback and require confirmation before any still-pending action.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Interruptible voice booking assistant
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.
Recall: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. Identify one observation that would contradict your claim.

### Terms
Turn taking and interruption: Track whether the person or system currently has the turn. When a user interrupts, stop obsolete playback and prevent an old generated response from taking over the new turn.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The prototype declares a failure if cancelled speech keeps playing for more than 250 ms. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.
Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.
Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.
Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.
Deliverables: Audio pipeline and consent/provenance register; State machine and interruption demo. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Conversational / voice AI engineer. Use this scenario: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.
Review: Start with the task and permitted scope. Explain turn taking and interruption: Track whether the person or system currently has the turn. When a user interrupts, stop obsolete playback and prevent an old generated response from taking over the new turn. Show the input and observed output, then address Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Audio pipeline and consent/provenance register; State machine and interruption demo. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Conversation recovery

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Conversation recovery
Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy.
Mental model: Ask someone to repeat an unclear address instead of guessing where to send a parcel.
Boundary: Perfect transcription does not guarantee a safe action or useful dialogue.
Worked example: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Interruptible voice booking assistant
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.
Recall: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. Identify one observation that would contradict your claim.

### Terms
Conversation recovery: Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ASR: Automatic speech recognition: converting speech audio into text.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.
Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.
Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.
Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.
Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes.
While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.
Compare a streaming ASR service with the batch baseline, documenting billing, data retention and supported language differences before uploading audio.
Deliverables: Audio pipeline and consent/provenance register; State machine and interruption demo; Per-clip transcript and latency scorecard. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. A reviewer must reproduce one result and identify which capabilities you implemented. While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

### Interview
Explain your advanced solution for Conversational / voice AI engineer. Use this scenario: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.
Review: Start with the task and permitted scope. Explain conversation recovery: Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy. Show the input and observed output, then address Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Audio pipeline and consent/provenance register; State machine and interruption demo; Per-clip transcript and latency scorecard. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
FastAPI — Open source · local
Typed API, validation and local service tests.
Alternative: Django REST Framework (open source); compare validation, async support and existing team skills.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Whisper — Open source code/weights · compute required
Batch speech transcription; requires FFmpeg and model downloads.
Alternative: A commercial speech API or another openly licensed ASR model; inspect language coverage, privacy and model terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

FFmpeg — Open source · build licenses vary
Audio conversion without overwriting originals.
Alternative: GStreamer (open source); compare pipeline needs and the exact codec/plugin licenses.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
FastAPI: https://fastapi.tiangolo.com/tutorial/
Whisper: https://github.com/openai/whisper
FFmpeg: https://ffmpeg.org/ffmpeg.html
Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction
Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
OpenTelemetry: https://opentelemetry.io/docs/
