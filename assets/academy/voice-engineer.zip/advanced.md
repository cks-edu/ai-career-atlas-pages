## advanced — Conversation recovery

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Conversation recovery
Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy.
Mental model: Ask someone to repeat an unclear address instead of guessing where to send a parcel.
Boundary: Perfect transcription does not guarantee a safe action or useful dialogue.
Worked example: The recognizer confuses fifteen with fifty. Repeat the amount and ask for confirmation before saving it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Interruptible voice booking assistant
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.
Recall: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. Identify one observation that would contradict your claim.

### Terms
Conversation recovery: Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ASR: Automatic speech recognition: converting speech audio into text.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build a voice assistant that collects a fictional booking request and stops speaking when the user corrects it.
Record twelve consented or self-recorded clips covering silence, noise, accents and corrected dates. Keep transcripts, license/consent notes and expected slots; use fictional names.
Run the API starter and add a session state with versioned date, time and party-size slots. Create a text-only interaction first and test corrections before adding audio.
Use FFmpeg to normalize a copy of each recording to mono 16 kHz PCM; retain the original. Transcribe with the official Whisper package and save hypotheses alongside reference transcripts.
Add a browser microphone interface with a visible recording control. Route recognized text through the slot flow; use browser speech synthesis for a local demo and cancel old speech whenever the session revision changes.
While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.
Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors.
Compare a streaming ASR service with the batch baseline, documenting billing, data retention and supported language differences before uploading audio.
Deliverables: Audio pipeline and consent/provenance register; State machine and interruption demo; Per-clip transcript and latency scorecard. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. A reviewer must reproduce one result and identify which capabilities you implemented. While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.

### Interview
Explain your advanced solution for Conversational / voice AI engineer. Use this scenario: While the assistant reads back a time, submit a corrected date. Cancel the old utterance, invalidate the stale response and request confirmation of the updated complete booking.
Review: Start with the task and permitted scope. Explain conversation recovery: Design clarification and human handoff for uncertain transcription, repeated errors and unavailable tools. Evaluate task completion and repair burden as well as word accuracy. Show the input and observed output, then address Measure word error rate, slot accuracy, correction success, end-of-turn delay and cancellation delay. Separate transcription errors from conversation-state errors. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Audio pipeline and consent/provenance register; State machine and interruption demo; Per-clip transcript and latency scorecard. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

