# Proof-of-value plan and cost workbook

Project: Discovery-to-proof-of-value engagement
Status: blank work product — not completed evidence

## Purpose and audience
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities.

## Required content
Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.

## Failure evidence
The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
