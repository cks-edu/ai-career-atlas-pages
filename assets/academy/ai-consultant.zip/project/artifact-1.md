# Discovery and solution proposal

Project: Discovery-to-proof-of-value engagement
Status: blank work product — not completed evidence

## Purpose and audience
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities.

## Required content
Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.

## Failure evidence
The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
