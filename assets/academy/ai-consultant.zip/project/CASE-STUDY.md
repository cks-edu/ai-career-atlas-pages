# Discovery-to-proof-of-value engagement

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.

## Limitations and next iteration
Implement one agreed test in a sandbox and replace estimated outcomes with measured evidence.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
