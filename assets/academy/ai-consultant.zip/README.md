# AI solutions consultant / sales engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Customer fit and constraints. A consultation should establish whether AI fits the problem. A useful recommendation can be to improve a process without AI. Then try Write a discovery and fit note. The three levels build toward Discovery-to-proof-of-value engagement. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Customer fit and constraints

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Customer fit and constraints
Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes.
Mental model: A good tailor measures the wearer before selecting the pattern.
Boundary: A persuasive demo is not proof that the solution fits the customer's environment.
Worked example: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The demo promises unsupported capability
The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Three proposals promise outcomes that the demonstration has not established. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise scope, mark assumptions and agree customer acceptance criteria before commitment.
Recall: Implementation owners can trace each promised capability to evidence and prerequisites. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Customer fit and constraints: Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A consultation should establish whether AI fits the problem. A useful recommendation can be to improve a process without AI.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional shop asking for AI to answer stock questions, but whose inventory spreadsheet is often out of date.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery script and a one-page fit recommendation.

3. Try step 2
Write questions about data accuracy, task volume, budget, approval and customer impact.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery script and a one-page fit recommendation.

4. Try step 3
Recommend a first step and state what must be true before an AI pilot would be worthwhile.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery script and a one-page fit recommendation.

5. Explain and check your result
The recommendation addresses unreliable inventory data rather than promising that a model will fix missing facts. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A discovery script and a one-page fit recommendation. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Apply this toy-case rule manually: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three proposals promise outcomes that the demonstration has not established. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI solutions consultant / sales engineer.
Use a fictional shop asking for AI to answer stock questions, but whose inventory spreadsheet is often out of date.
Write questions about data accuracy, task volume, budget, approval and customer impact.
Recommend a first step and state what must be true before an AI pilot would be worthwhile.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A discovery script and a one-page fit recommendation. Include beginner-worksheet.md and your completed Discovery brief and proof-of-value proposal.
Check: The recommendation addresses unreliable inventory data rather than promising that a model will fix missing facts.

### Interview
Explain your beginner solution for AI solutions consultant / sales engineer. Use this scenario: The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency.
Review: Start with the task and permitted scope. Explain customer fit and constraints: Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes. Show the input and observed output, then address Revise scope, mark assumptions and agree customer acceptance criteria before commitment. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A discovery script and a one-page fit recommendation. Include beginner-worksheet.md and your completed Discovery brief and proof-of-value proposal.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Solution and cost assumptions

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Discovery, demonstrations and commercial communication; sales-engineer roles often require API and architecture skills.

### Solution and cost assumptions
Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable.
Mental model: A building quote includes plumbing and maintenance, not only the facade.
Boundary: Prices and access terms change and require a current quote.
Worked example: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Discovery-to-proof-of-value engagement
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Recall: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. Identify one observation that would contradict your claim.

### Terms
Solution and cost assumptions: Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable.
API: Application programming interface: the agreed way one program requests work or data from another.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities.
Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.
Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.
Deliverables: Discovery and solution proposal; Proof-of-value plan and cost workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI solutions consultant / sales engineer. Use this scenario: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Review: Start with the task and permitted scope. Explain solution and cost assumptions: Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable. Show the input and observed output, then address Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Discovery and solution proposal; Proof-of-value plan and cost workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Proof-of-value handover

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Proof-of-value handover
Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign.
Mental model: A test drive ends with an inspection report, not just a sales photograph.
Boundary: Sales targets must not substitute for evidence or qualified risk review.
Worked example: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Discovery-to-proof-of-value engagement
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Prepare a demonstration storyboard, implementation plan and handover package. Rehearse objections about quality, privacy, integration and ongoing ownership.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Recall: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. Identify one observation that would contradict your claim.

### Terms
Proof-of-value handover: Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Prepare a demonstration storyboard, implementation plan and handover package. Rehearse objections about quality, privacy, integration and ongoing ownership.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities.
Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.
Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Prepare a demonstration storyboard, implementation plan and handover package. Rehearse objections about quality, privacy, integration and ongoing ownership.
The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.
Implement one agreed test in a sandbox and replace estimated outcomes with measured evidence.
Deliverables: Discovery and solution proposal; Proof-of-value plan and cost workbook; Demo narrative and handover checklist. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A reviewer must reproduce one result and identify which capabilities you implemented. The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.

### Interview
Explain your advanced solution for AI solutions consultant / sales engineer. Use this scenario: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Review: Start with the task and permitted scope. Explain proof-of-value handover: Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign. Show the input and observed output, then address Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Discovery and solution proposal; Proof-of-value plan and cost workbook; Demo narrative and handover checklist. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
diagrams.net — Open source editor · browser/desktop
Architecture diagrams, process maps and trust boundaries.
Alternative: Mermaid (open source) for text diagrams or Microsoft Visio (commercial); choose an editable format teammates can use.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

NIST AI RMF — Public framework · not a certification
Organize governance questions and evidence; project recommendations are editorial.
Alternative: OECD AI Principles provide another public perspective; frameworks complement one another and are not automatic certifications.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
diagrams.net: https://www.drawio.com/docs/getting-started/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework
Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html
Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
