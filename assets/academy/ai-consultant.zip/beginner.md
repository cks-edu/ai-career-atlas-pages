## beginner — Customer fit and constraints

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Customer fit and constraints
Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes.
Mental model: A good tailor measures the wearer before selecting the pattern.
Boundary: A persuasive demo is not proof that the solution fits the customer's environment.
Worked example: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The demo promises unsupported capability
The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Three proposals promise outcomes that the demonstration has not established. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise scope, mark assumptions and agree customer acceptance criteria before commitment.
Recall: Implementation owners can trace each promised capability to evidence and prerequisites. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Customer fit and constraints: Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A consultation should establish whether AI fits the problem. A useful recommendation can be to improve a process without AI.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional shop asking for AI to answer stock questions, but whose inventory spreadsheet is often out of date.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery script and a one-page fit recommendation.

3. Try step 2
Write questions about data accuracy, task volume, budget, approval and customer impact.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery script and a one-page fit recommendation.

4. Try step 3
Recommend a first step and state what must be true before an AI pilot would be worthwhile.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery script and a one-page fit recommendation.

5. Explain and check your result
The recommendation addresses unreliable inventory data rather than promising that a model will fix missing facts. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A discovery script and a one-page fit recommendation. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Apply this toy-case rule manually: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three proposals promise outcomes that the demonstration has not established. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI solutions consultant / sales engineer.
Use a fictional shop asking for AI to answer stock questions, but whose inventory spreadsheet is often out of date.
Write questions about data accuracy, task volume, budget, approval and customer impact.
Recommend a first step and state what must be true before an AI pilot would be worthwhile.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A discovery script and a one-page fit recommendation. Include beginner-worksheet.md and your completed Discovery brief and proof-of-value proposal.
Check: The recommendation addresses unreliable inventory data rather than promising that a model will fix missing facts.

### Interview
Explain your beginner solution for AI solutions consultant / sales engineer. Use this scenario: The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency.
Review: Start with the task and permitted scope. Explain customer fit and constraints: Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes. Show the input and observed output, then address Revise scope, mark assumptions and agree customer acceptance criteria before commitment. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A discovery script and a one-page fit recommendation. Include beginner-worksheet.md and your completed Discovery brief and proof-of-value proposal.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

