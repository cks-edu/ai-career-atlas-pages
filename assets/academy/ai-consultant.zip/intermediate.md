## intermediate — Solution and cost assumptions

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Discovery, demonstrations and commercial communication; sales-engineer roles often require API and architecture skills.

### Solution and cost assumptions
Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable.
Mental model: A building quote includes plumbing and maintenance, not only the facade.
Boundary: Prices and access terms change and require a current quote.
Worked example: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Discovery-to-proof-of-value engagement
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Recall: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. Identify one observation that would contradict your claim.

### Terms
Solution and cost assumptions: Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable.
API: Application programming interface: the agreed way one program requests work or data from another.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities.
Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.
Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.
Deliverables: Discovery and solution proposal; Proof-of-value plan and cost workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI solutions consultant / sales engineer. Use this scenario: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Review: Start with the task and permitted scope. Explain solution and cost assumptions: Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable. Show the input and observed output, then address Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Discovery and solution proposal; Proof-of-value plan and cost workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

