# AI solutions consultant / sales engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Customer fit and constraints: Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Customer fit and constraints

Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes. In this role, work through: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A good tailor measures the wearer before selecting the pattern.

Boundary: A persuasive demo is not proof that the solution fits the customer's environment.

Worked example: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI solutions consultant / sales engineer: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal.

Predict the worked case

Read this case without running a tool: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in customer fit and constraints.

Connect the concept to the role

Apply this rule: Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A persuasive demo is not proof that the solution fits the customer's environment.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies customer fit and constraints to this case: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Customer fit and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with customer fit and constraints. Use the glossary below, then write your prediction for: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions consultant / sales engineer role interview. Explain customer fit and constraints using this case: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate customer fit and constraints to a system or workflow you know. Explain customer fit and constraints using this case: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain customer fit and constraints using this case: A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal.

Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes. — Understand the customer's problem, existing alternatives, data and decision makers before recommending a product. Define a bounded proof of value with measurable outcomes. A persuasive demo is not proof that the solution fits the customer's environment.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Diagnose: The demo promises unsupported capability

The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Three proposals promise outcomes that the demonstration has not established. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise scope, mark assumptions and agree customer acceptance criteria before commitment. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A good tailor measures the wearer before selecting the pattern.

A customer wants an assistant but lacks an approved knowledge source; make source preparation part of the proposal.

Worked example: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise scope, mark assumptions and agree customer acceptance criteria before commitment.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Three proposals promise outcomes that the demonstration has not established. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Apply this toy-case rule manually: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A consultation should establish whether AI fits the problem. A useful recommendation can be to improve a process without AI.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use a fictional shop asking for AI to answer stock questions, but whose inventory spreadsheet is often out of date.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery script and a one-page fit recommendation.

Preparation · Try step 2

Write questions about data accuracy, task volume, budget, approval and customer impact.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery script and a one-page fit recommendation.

Preparation · Try step 3

Recommend a first step and state what must be true before an AI pilot would be worthwhile.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery script and a one-page fit recommendation.

Preparation · Explain and check your result

The recommendation addresses unreliable inventory data rather than promising that a model will fix missing facts. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A discovery script and a one-page fit recommendation. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Apply this toy-case rule manually: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three proposals promise outcomes that the demonstration has not established. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three proposals promise outcomes that the demonstration has not established. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the demo promises unsupported capability. Use the glossary below, then write your prediction for: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise scope, mark assumptions and agree customer acceptance criteria before commitment. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions consultant / sales engineer role interview. Explain diagnose: the demo promises unsupported capability using this case: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise scope, mark assumptions and agree customer acceptance criteria before commitment. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the demo promises unsupported capability to a system or workflow you know. Explain diagnose: the demo promises unsupported capability using this case: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise scope, mark assumptions and agree customer acceptance criteria before commitment. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Implementation owners can trace each promised capability to evidence and prerequisites. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the demo promises unsupported capability using this case: Review when unsupported_promises >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise scope, mark assumptions and agree customer acceptance criteria before commitment. State the evidence, one alternative and where the mental model stops.

Quiz: The demo promises unsupported capability: The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency.

Change the acceptance rule after seeing an inconvenient result.

Revise scope, mark assumptions and agree customer acceptance criteria before commitment.

Omit failed cases and report only the successful demonstrations.

Reference: Revise scope, mark assumptions and agree customer acceptance criteria before commitment. — Revise scope, mark assumptions and agree customer acceptance criteria before commitment. Implementation owners can trace each promised capability to evidence and prerequisites.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Discovery, demonstrations and commercial communication; sales-engineer roles often require API and architecture skills.

Terms:

Solution and cost assumptions: Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable.

API: Application programming interface: the agreed way one program requests work or data from another.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Solution and cost assumptions

Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable. In this role, work through: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A building quote includes plumbing and maintenance, not only the facade.

Boundary: Prices and access terms change and require a current quote.

Worked example: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Discovery, demonstrations and commercial communication; sales-engineer roles often require API and architecture skills.

Tools for this exercise: Document or text editor

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI solutions consultant / sales engineer: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim.

Predict the worked case

Read this case without running a tool: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in solution and cost assumptions.

Connect the concept to the role

Apply this rule: Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Prices and access terms change and require a current quote.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies solution and cost assumptions to this case: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Solution and cost assumptions; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with solution and cost assumptions. Use the glossary below, then write your prediction for: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions consultant / sales engineer role interview. Explain solution and cost assumptions using this case: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate solution and cost assumptions to a system or workflow you know. Explain solution and cost assumptions using this case: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain solution and cost assumptions using this case: Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim.

Treat a passing starter as proof of the whole role workflow.

Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable.

Ignore the failure because the tool produced an output.

Reference: Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable. — Map requirements to components and record licensing, integration, operating and review costs. Compare a credible alternative rather than presenting one vendor as inevitable. Prices and access terms change and require a current quote.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Integrate: Discovery-to-proof-of-value engagement

Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used. In this role, work through: Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A building quote includes plumbing and maintenance, not only the facade.

Estimate a pilot using declared request volume and review effort, with a sensitivity table rather than a guaranteed savings claim.

Worked example: Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Discovery and solution proposal; Proof-of-value plan and cost workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: discovery-to-proof-of-value engagement. Use the glossary below, then write your prediction for: Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions consultant / sales engineer role interview. Explain integrate: discovery-to-proof-of-value engagement using this case: Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: discovery-to-proof-of-value engagement to a system or workflow you know. Explain integrate: discovery-to-proof-of-value engagement using this case: Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. Identify one observation that would contradict your claim.

Interview: Explain integrate: discovery-to-proof-of-value engagement using this case: Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Discovery-to-proof-of-value engagement at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.

Reference: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. — Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Proof-of-value handover: Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Proof-of-value handover

Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign. In this role, work through: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A test drive ends with an inspection report, not just a sales photograph.

Boundary: Sales targets must not substitute for evidence or qualified risk review.

Worked example: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI solutions consultant / sales engineer: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success.

Predict the worked case

Read this case without running a tool: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in proof-of-value handover.

Connect the concept to the role

Apply this rule: Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Sales targets must not substitute for evidence or qualified risk review.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies proof-of-value handover to this case: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Proof-of-value handover; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with proof-of-value handover. Use the glossary below, then write your prediction for: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions consultant / sales engineer role interview. Explain proof-of-value handover using this case: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate proof-of-value handover to a system or workflow you know. Explain proof-of-value handover using this case: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain proof-of-value handover using this case: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign.

Reference: Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign. — Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign. Sales targets must not substitute for evidence or qualified risk review.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Defend: Discovery-to-proof-of-value engagement

Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Prepare a demonstration storyboard, implementation plan and handover package. Rehearse objections about quality, privacy, integration and ongoing ownership. In this role, work through: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A test drive ends with an inspection report, not just a sales photograph.

The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success.

Worked example: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Prepare a demonstration storyboard, implementation plan and handover package. Rehearse objections about quality, privacy, integration and ongoing ownership.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A reviewer must reproduce one result and identify which capabilities you implemented. The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Discovery and solution proposal; Proof-of-value plan and cost workbook; Demo narrative and handover checklist. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: discovery-to-proof-of-value engagement. Use the glossary below, then write your prediction for: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions consultant / sales engineer role interview. Explain defend: discovery-to-proof-of-value engagement using this case: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: discovery-to-proof-of-value engagement to a system or workflow you know. Explain defend: discovery-to-proof-of-value engagement using this case: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. Identify one observation that would contradict your claim.

Interview: Explain defend: discovery-to-proof-of-value engagement using this case: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Discovery-to-proof-of-value engagement at this level?

The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions. — The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions. Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
