# SAMPLE — Discovery brief and proof-of-value proposal
Role: AI solutions consultant / sales engineer
Case: The demo promises unsupported capability
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The proof-of-value proposal must contain zero material capability claims lacking demo evidence or an explicit dependency.

## Evidence table
| Record | unsupported_promises (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three proposals promise outcomes that the demonstration has not established.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Revise scope, mark assumptions and agree customer acceptance criteria before commitment.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai solutions consultant / sales engineer.
Before release: Implementation owners can trace each promised capability to evidence and prerequisites.

## Design choice and trade-off
Qualify use-case fit before showing features; separate observed behavior from roadmap promises.
A narrower credible proposal may lose superficial breadth but prevents an unimplementable handoff.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
AI discovery and demo kit: Demo claims are supported by observable behavior.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
