## advanced — Proof-of-value handover

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Proof-of-value handover
Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign.
Mental model: A test drive ends with an inspection report, not just a sales photograph.
Boundary: Sales targets must not substitute for evidence or qualified risk review.
Worked example: The pilot meets latency but fails source accuracy; recommend a limited redesign instead of declaring overall success.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Discovery-to-proof-of-value engagement
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Prepare a demonstration storyboard, implementation plan and handover package. Rehearse objections about quality, privacy, integration and ongoing ownership.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Recall: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. Identify one observation that would contradict your claim.

### Terms
Proof-of-value handover: Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Prepare a demonstration storyboard, implementation plan and handover package. Rehearse objections about quality, privacy, integration and ongoing ownership.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a client-facing proposal that connects a bounded AI use case to evidence, scope and delivery responsibilities.
Use a fictional customer with one operational problem. Write discovery questions about workflow, baseline, constraints, data access and decision ownership.
Create a discovery brief and options matrix including a non-AI option. Separate confirmed needs from assumptions and identify a sponsor plus domain reviewer.
Design a proof-of-value with acceptance metrics, exclusions, data requirements and stop conditions. Build a cost/effort model in Calc and cite dated vendor prices if used.
Prepare a demonstration storyboard, implementation plan and handover package. Rehearse objections about quality, privacy, integration and ongoing ownership.
The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real.
Implement one agreed test in a sandbox and replace estimated outcomes with measured evidence.
Deliverables: Discovery and solution proposal; Proof-of-value plan and cost workbook; Demo narrative and handover checklist. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A reviewer must reproduce one result and identify which capabilities you implemented. The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.

### Interview
Explain your advanced solution for AI solutions consultant / sales engineer. Use this scenario: The customer asks to expand from a low-risk internal pilot to a sensitive external workflow. Record the scope change, new evidence needs and revised commercial assumptions.
Review: Start with the task and permitted scope. Explain proof-of-value handover: Evaluate the agreed acceptance criteria and report failures openly. Hand over responsibilities, rollout prerequisites and reasons to stop or redesign. Show the input and observed output, then address Have a peer check that every promised outcome has a test, owner and dependency. Do not present a hypothetical customer, contract or ROI as real. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Discovery and solution proposal; Proof-of-value plan and cost workbook; Demo narrative and handover checklist. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

