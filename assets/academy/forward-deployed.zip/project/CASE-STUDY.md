# Customer-specific document reconciliation pilot

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.

## Limitations and next iteration
Add an integration contract and a rollback procedure for a sandbox downstream system.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
