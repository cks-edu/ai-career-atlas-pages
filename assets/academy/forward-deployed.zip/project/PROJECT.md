# Customer-specific document reconciliation pilot

Career: Forward-deployed AI engineer
Reviewed: 2026-10-22

Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team.

## Prerequisites
Strong software delivery, stakeholder communication and willingness to work within customer environments; travel may apply.

## Included starter versus your implementation
DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Wrap the reconciliation job in a small API or scheduled local script. Add a request/run ID, row counts and rejected-record report; prepare a deployment options memo covering customer network and retention constraints.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Customer discovery and constraints brief — artifact-1.md
2. Reproducible reconciliation pipeline — artifact-2.md
3. Pilot readout with architecture decision record — artifact-3.md

## Troubleshooting
- Missing CSV: run from the extracted folder.
- Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
- Wrong totals: check units, duplicate joins and whether failures are included.

## Extension
Add an integration contract and a rollback procedure for a sandbox downstream system.

## Primary learning resources
- DuckDB: https://duckdb.org/docs/stable/clients/python/overview — Open source · local; CSV ingestion, SQL transforms and reproducible analysis.
- FastAPI: https://fastapi.tiangolo.com/tutorial/ — Open source · local; Typed API, validation and local service tests.
- OpenTelemetry: https://opentelemetry.io/docs/ — Open source; Request traces and dependency-level diagnostics.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
