# Customer discovery and constraints brief

Project: Customer-specific document reconciliation pilot
Status: blank work product — not completed evidence

## Purpose and audience
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team.

## Required content
Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.

## Failure evidence
Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
