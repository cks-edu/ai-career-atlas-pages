# SAMPLE — Pilot acceptance memo and handover plan
Role: Forward-deployed AI engineer
Case: A demo that misses the customer
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The customer pilot allows at most two failed critical tasks in a ten-task acceptance session.

## Evidence table
| Record | critical_failures (out of ten) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 6 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two sessions exceed the customer-defined failure allowance despite a successful sales demo.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in forward-deployed ai engineer.
Before release: Repeat the same representative tasks with the customer owner before expanding access.

## Design choice and trade-off
Build around the customer workflow and integration boundary; make acceptance criteria jointly reviewable.
Narrowing a pilot limits breadth but creates more credible delivery evidence than a polished unrestricted demo.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Customer support pilot: Show time saved, wrong-answer cases and escalation behavior.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
