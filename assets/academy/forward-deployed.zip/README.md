# Forward-deployed AI engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Discovery before integration. Customer discovery means learning the actual problem before building a solution. A useful pilot has a small scope and a measurable outcome. Then try Write a mock customer brief. The three levels build toward Customer-specific document reconciliation pilot. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Discovery before integration

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Discovery before integration
Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution.
Mental model: Survey the building before designing its new wiring.
Boundary: Stakeholder enthusiasm is not evidence of feasibility or user value.
Worked example: For support triage, measure manual routing time and error categories before choosing a model or connector.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A demo that misses the customer
The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Two sessions exceed the customer-defined failure allowance despite a successful sales demo. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate.
Recall: Repeat the same representative tasks with the customer owner before expanding access. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Discovery before integration: Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Customer discovery means learning the actual problem before building a solution. A useful pilot has a small scope and a measurable outcome.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional support team that spends 20 minutes finding answers in internal manuals.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery question list and a bounded pilot brief.

3. Try step 2
Write five questions about the task, users, data permissions, current tools and who approves a pilot.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery question list and a bounded pilot brief.

4. Try step 3
Draft a one-page proposal to help staff find passages, with human review and no automatic customer replies.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery question list and a bounded pilot brief.

5. Explain and check your result
The brief identifies the user, a baseline, an owner, success evidence and something the pilot will not do. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A discovery question list and a bounded pilot brief. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Apply this toy-case rule manually: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two sessions exceed the customer-defined failure allowance despite a successful sales demo. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Forward-deployed AI engineer.
Use a fictional support team that spends 20 minutes finding answers in internal manuals.
Write five questions about the task, users, data permissions, current tools and who approves a pilot.
Draft a one-page proposal to help staff find passages, with human review and no automatic customer replies.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A discovery question list and a bounded pilot brief. Include beginner-worksheet.md and your completed Pilot acceptance memo and handover plan.
Check: The brief identifies the user, a baseline, an owner, success evidence and something the pilot will not do.

### Interview
Explain your beginner solution for Forward-deployed AI engineer. Use this scenario: The customer pilot allows at most two failed critical tasks in a ten-task acceptance session.
Review: Start with the task and permitted scope. Explain discovery before integration: Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution. Show the input and observed output, then address Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A discovery question list and a bounded pilot brief. Include beginner-worksheet.md and your completed Pilot acceptance memo and handover plan.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Customer data contracts

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong software delivery, stakeholder communication and willingness to work within customer environments; travel may apply.

### Customer data contracts
Agree on fields, stable identifiers, freshness and access responsibilities at each boundary. Treat unexpected customer data as an integration problem to diagnose, not silently coerce.
Mental model: Two teams need the same address format to exchange parcels.
Boundary: A schema contract does not establish permission to reuse the data.
Worked example: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Customer-specific document reconciliation pilot
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.
Recall: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. Identify one observation that would contradict your claim.

### Terms
Customer data contracts: Agree on fields, stable identifiers, freshness and access responsibilities at each boundary. Treat unexpected customer data as an integration problem to diagnose, not silently coerce.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team.
Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.
Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.
Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.
Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.
Deliverables: Customer discovery and constraints brief; Reproducible reconciliation pipeline. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Forward-deployed AI engineer. Use this scenario: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.
Review: Start with the task and permitted scope. Explain customer data contracts: Agree on fields, stable identifiers, freshness and access responsibilities at each boundary. Treat unexpected customer data as an integration problem to diagnose, not silently coerce. Show the input and observed output, then address Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Customer discovery and constraints brief; Reproducible reconciliation pipeline. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Bounded pilot handover

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Bounded pilot handover
Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback.
Mental model: A test flight needs a logbook and a crew for the next flight.
Boundary: A successful small pilot may not scale to another team or workload.
Worked example: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Customer-specific document reconciliation pilot
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. Wrap the reconciliation job in a small API or scheduled local script. Add a request/run ID, row counts and rejected-record report; prepare a deployment options memo covering customer network and retention constraints.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.
Recall: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. Identify one observation that would contradict your claim.

### Terms
Bounded pilot handover: Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback.
API: Application programming interface: the agreed way one program requests work or data from another.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Wrap the reconciliation job in a small API or scheduled local script. Add a request/run ID, row counts and rejected-record report; prepare a deployment options memo covering customer network and retention constraints.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team.
Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.
Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.
Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.
Wrap the reconciliation job in a small API or scheduled local script. Add a request/run ID, row counts and rejected-record report; prepare a deployment options memo covering customer network and retention constraints.
Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.
Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.
Add an integration contract and a rollback procedure for a sandbox downstream system.
Deliverables: Customer discovery and constraints brief; Reproducible reconciliation pipeline; Pilot readout with architecture decision record. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. A reviewer must reproduce one result and identify which capabilities you implemented. Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.

### Interview
Explain your advanced solution for Forward-deployed AI engineer. Use this scenario: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.
Review: Start with the task and permitted scope. Explain bounded pilot handover: Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback. Show the input and observed output, then address Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Customer discovery and constraints brief; Reproducible reconciliation pipeline; Pilot readout with architecture decision record. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
DuckDB — Open source · local
CSV ingestion, SQL transforms and reproducible analysis.
Alternative: SQLite (public domain) for embedded transactional SQL or PostgreSQL (open source) for a shared service.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

FastAPI — Open source · local
Typed API, validation and local service tests.
Alternative: Django REST Framework (open source); compare validation, async support and existing team skills.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

OpenTelemetry — Open source
Request traces and dependency-level diagnostics.
Alternative: Vendor-specific SDKs are alternatives, but assess portability and data export before adopting one.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
DuckDB: https://duckdb.org/docs/stable/clients/python/overview
FastAPI: https://fastapi.tiangolo.com/tutorial/
OpenTelemetry: https://opentelemetry.io/docs/
Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html
OpenTelemetry: https://opentelemetry.io/docs/
