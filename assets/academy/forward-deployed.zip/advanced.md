## advanced — Bounded pilot handover

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Bounded pilot handover
Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback.
Mental model: A test flight needs a logbook and a crew for the next flight.
Boundary: A successful small pilot may not scale to another team or workload.
Worked example: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Customer-specific document reconciliation pilot
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. Wrap the reconciliation job in a small API or scheduled local script. Add a request/run ID, row counts and rejected-record report; prepare a deployment options memo covering customer network and retention constraints.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.
Recall: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. Identify one observation that would contradict your claim.

### Terms
Bounded pilot handover: Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback.
API: Application programming interface: the agreed way one program requests work or data from another.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Wrap the reconciliation job in a small API or scheduled local script. Add a request/run ID, row counts and rejected-record report; prepare a deployment options memo covering customer network and retention constraints.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team.
Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.
Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.
Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.
Wrap the reconciliation job in a small API or scheduled local script. Add a request/run ID, row counts and rejected-record report; prepare a deployment options memo covering customer network and retention constraints.
Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.
Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.
Add an integration contract and a rollback procedure for a sandbox downstream system.
Deliverables: Customer discovery and constraints brief; Reproducible reconciliation pipeline; Pilot readout with architecture decision record. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. A reviewer must reproduce one result and identify which capabilities you implemented. Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.

### Interview
Explain your advanced solution for Forward-deployed AI engineer. Use this scenario: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.
Review: Start with the task and permitted scope. Explain bounded pilot handover: Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback. Show the input and observed output, then address Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Customer discovery and constraints brief; Reproducible reconciliation pipeline; Pilot readout with architecture decision record. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

