## beginner — Discovery before integration

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Discovery before integration
Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution.
Mental model: Survey the building before designing its new wiring.
Boundary: Stakeholder enthusiasm is not evidence of feasibility or user value.
Worked example: For support triage, measure manual routing time and error categories before choosing a model or connector.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A demo that misses the customer
The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Two sessions exceed the customer-defined failure allowance despite a successful sales demo. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate.
Recall: Repeat the same representative tasks with the customer owner before expanding access. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Discovery before integration: Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Customer discovery means learning the actual problem before building a solution. A useful pilot has a small scope and a measurable outcome.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional support team that spends 20 minutes finding answers in internal manuals.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery question list and a bounded pilot brief.

3. Try step 2
Write five questions about the task, users, data permissions, current tools and who approves a pilot.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery question list and a bounded pilot brief.

4. Try step 3
Draft a one-page proposal to help staff find passages, with human review and no automatic customer replies.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery question list and a bounded pilot brief.

5. Explain and check your result
The brief identifies the user, a baseline, an owner, success evidence and something the pilot will not do. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A discovery question list and a bounded pilot brief. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Apply this toy-case rule manually: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two sessions exceed the customer-defined failure allowance despite a successful sales demo. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Forward-deployed AI engineer.
Use a fictional support team that spends 20 minutes finding answers in internal manuals.
Write five questions about the task, users, data permissions, current tools and who approves a pilot.
Draft a one-page proposal to help staff find passages, with human review and no automatic customer replies.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A discovery question list and a bounded pilot brief. Include beginner-worksheet.md and your completed Pilot acceptance memo and handover plan.
Check: The brief identifies the user, a baseline, an owner, success evidence and something the pilot will not do.

### Interview
Explain your beginner solution for Forward-deployed AI engineer. Use this scenario: The customer pilot allows at most two failed critical tasks in a ten-task acceptance session.
Review: Start with the task and permitted scope. Explain discovery before integration: Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution. Show the input and observed output, then address Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A discovery question list and a bounded pilot brief. Include beginner-worksheet.md and your completed Pilot acceptance memo and handover plan.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

