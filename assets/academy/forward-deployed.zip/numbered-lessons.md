# Forward-deployed AI engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Discovery before integration: Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

### Discovery before integration

Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution. In this role, work through: For support triage, measure manual routing time and error categories before choosing a model or connector. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Survey the building before designing its new wiring.

Boundary: Stakeholder enthusiasm is not evidence of feasibility or user value.

Worked example: For support triage, measure manual routing time and error categories before choosing a model or connector.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); FastAPI (Open source · local); OpenTelemetry (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Forward-deployed AI engineer: For support triage, measure manual routing time and error categories before choosing a model or connector.

Predict the worked case

Read this case without running a tool: For support triage, measure manual routing time and error categories before choosing a model or connector. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in discovery before integration.

Connect the concept to the role

Apply this rule: Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Stakeholder enthusiasm is not evidence of feasibility or user value.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies discovery before integration to this case: For support triage, measure manual routing time and error categories before choosing a model or connector. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For support triage, measure manual routing time and error categories before choosing a model or connector. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Discovery before integration; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with discovery before integration. Use the glossary below, then write your prediction for: For support triage, measure manual routing time and error categories before choosing a model or connector. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Forward-deployed AI engineer role interview. Explain discovery before integration using this case: For support triage, measure manual routing time and error categories before choosing a model or connector. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate discovery before integration to a system or workflow you know. Explain discovery before integration using this case: For support triage, measure manual routing time and error categories before choosing a model or connector. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain discovery before integration using this case: For support triage, measure manual routing time and error categories before choosing a model or connector. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? For support triage, measure manual routing time and error categories before choosing a model or connector.

Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution. — Identify one costly user task, its current workflow and a measurable acceptance condition. Confirm the data and permissions available before promising an AI solution. Stakeholder enthusiasm is not evidence of feasibility or user value.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FastAPI: https://fastapi.tiangolo.com/tutorial/

OpenTelemetry: https://opentelemetry.io/docs/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

OpenTelemetry: https://opentelemetry.io/docs/

### Diagnose: A demo that misses the customer

The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Two sessions exceed the customer-defined failure allowance despite a successful sales demo. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Survey the building before designing its new wiring.

For support triage, measure manual routing time and error categories before choosing a model or connector.

Worked example: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: DuckDB (Open source · local); FastAPI (Open source · local); OpenTelemetry (Open source)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Two sessions exceed the customer-defined failure allowance despite a successful sales demo. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Apply this toy-case rule manually: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Customer discovery means learning the actual problem before building a solution. A useful pilot has a small scope and a measurable outcome.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use a fictional support team that spends 20 minutes finding answers in internal manuals.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery question list and a bounded pilot brief.

Preparation · Try step 2

Write five questions about the task, users, data permissions, current tools and who approves a pilot.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery question list and a bounded pilot brief.

Preparation · Try step 3

Draft a one-page proposal to help staff find passages, with human review and no automatic customer replies.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A discovery question list and a bounded pilot brief.

Preparation · Explain and check your result

The brief identifies the user, a baseline, an owner, success evidence and something the pilot will not do. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A discovery question list and a bounded pilot brief. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Apply this toy-case rule manually: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two sessions exceed the customer-defined failure allowance despite a successful sales demo. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two sessions exceed the customer-defined failure allowance despite a successful sales demo. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a demo that misses the customer. Use the glossary below, then write your prediction for: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Forward-deployed AI engineer role interview. Explain diagnose: a demo that misses the customer using this case: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a demo that misses the customer to a system or workflow you know. Explain diagnose: a demo that misses the customer using this case: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Repeat the same representative tasks with the customer owner before expanding access. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a demo that misses the customer using this case: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate. State the evidence, one alternative and where the mental model stops.

Quiz: A demo that misses the customer: The customer pilot allows at most two failed critical tasks in a ten-task acceptance session.

Change the acceptance rule after seeing an inconvenient result.

Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate.

Omit failed cases and report only the successful demonstrations.

Reference: Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate. — Reproduce failed customer workflows, narrow pilot scope and agree a revised acceptance gate. Repeat the same representative tasks with the customer owner before expanding access.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FastAPI: https://fastapi.tiangolo.com/tutorial/

OpenTelemetry: https://opentelemetry.io/docs/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

OpenTelemetry: https://opentelemetry.io/docs/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong software delivery, stakeholder communication and willingness to work within customer environments; travel may apply.

Terms:

Customer data contracts: Agree on fields, stable identifiers, freshness and access responsibilities at each boundary. Treat unexpected customer data as an integration problem to diagnose, not silently coerce.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Customer data contracts

Agree on fields, stable identifiers, freshness and access responsibilities at each boundary. Treat unexpected customer data as an integration problem to diagnose, not silently coerce. In this role, work through: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Two teams need the same address format to exchange parcels.

Boundary: A schema contract does not establish permission to reuse the data.

Worked example: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong software delivery, stakeholder communication and willingness to work within customer environments; travel may apply.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); FastAPI (Open source · local); OpenTelemetry (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Forward-deployed AI engineer: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order.

Predict the worked case

Read this case without running a tool: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in customer data contracts.

Connect the concept to the role

Apply this rule: Agree on fields, stable identifiers, freshness and access responsibilities at each boundary. Treat unexpected customer data as an integration problem to diagnose, not silently coerce. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A schema contract does not establish permission to reuse the data.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies customer data contracts to this case: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Customer data contracts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with customer data contracts. Use the glossary below, then write your prediction for: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Forward-deployed AI engineer role interview. Explain customer data contracts using this case: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate customer data contracts to a system or workflow you know. Explain customer data contracts using this case: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain customer data contracts using this case: A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order.

Treat a passing starter as proof of the whole role workflow.

Agree on fields, stable identifiers, freshness and access responsibilities at each boundary. Treat unexpected customer data as an integration problem to diagnose, not silently coerce.

Ignore the failure because the tool produced an output.

Reference: Agree on fields, stable identifiers, freshness and access responsibilities at each boundary. Treat unexpected customer data as an integration problem to diagnose, not silently coerce. — Agree on fields, stable identifiers, freshness and access responsibilities at each boundary. Treat unexpected customer data as an integration problem to diagnose, not silently coerce. A schema contract does not establish permission to reuse the data.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FastAPI: https://fastapi.tiangolo.com/tutorial/

OpenTelemetry: https://opentelemetry.io/docs/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

OpenTelemetry: https://opentelemetry.io/docs/

### Integrate: Customer-specific document reconciliation pilot

Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row. In this role, work through: Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: Two teams need the same address format to exchange parcels.

A source renames customer_id to account_id; reject the incompatible batch and record the schema version instead of joining on row order.

Worked example: Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); FastAPI (Open source · local); OpenTelemetry (Open source)

Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The customer pilot allows at most two failed critical tasks in a ten-task acceptance session. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-intermediate-2.md: Customer discovery and constraints brief; Reproducible reconciliation pipeline. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: customer-specific document reconciliation pilot. Use the glossary below, then write your prediction for: Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Forward-deployed AI engineer role interview. Explain integrate: customer-specific document reconciliation pilot using this case: Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: customer-specific document reconciliation pilot to a system or workflow you know. Explain integrate: customer-specific document reconciliation pilot using this case: Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. Identify one observation that would contradict your claim.

Interview: Explain integrate: customer-specific document reconciliation pilot using this case: Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Customer-specific document reconciliation pilot at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.

Reference: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. — Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FastAPI: https://fastapi.tiangolo.com/tutorial/

OpenTelemetry: https://opentelemetry.io/docs/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

OpenTelemetry: https://opentelemetry.io/docs/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Bounded pilot handover: Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback.

API: Application programming interface: the agreed way one program requests work or data from another.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Bounded pilot handover

Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback. In this role, work through: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A test flight needs a logbook and a crew for the next flight.

Boundary: A successful small pilot may not scale to another team or workload.

Worked example: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); FastAPI (Open source · local); OpenTelemetry (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Forward-deployed AI engineer: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch.

Predict the worked case

Read this case without running a tool: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in bounded pilot handover.

Connect the concept to the role

Apply this rule: Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A successful small pilot may not scale to another team or workload.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies bounded pilot handover to this case: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Bounded pilot handover; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with bounded pilot handover. Use the glossary below, then write your prediction for: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Forward-deployed AI engineer role interview. Explain bounded pilot handover using this case: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate bounded pilot handover to a system or workflow you know. Explain bounded pilot handover using this case: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain bounded pilot handover using this case: Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback.

Reference: Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback. — Make a pilot reproducible with ownership, operating instructions and explicit limitations. Separate observed benefit from assumptions and define conditions for expansion or rollback. A successful small pilot may not scale to another team or workload.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FastAPI: https://fastapi.tiangolo.com/tutorial/

OpenTelemetry: https://opentelemetry.io/docs/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

OpenTelemetry: https://opentelemetry.io/docs/

### Defend: Customer-specific document reconciliation pilot

Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. Wrap the reconciliation job in a small API or scheduled local script. Add a request/run ID, row counts and rejected-record report; prepare a deployment options memo covering customer network and retention constraints. In this role, work through: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A test flight needs a logbook and a crew for the next flight.

Hand over a runbook containing data refresh, failed-job replay and the owner who can pause dispatch.

Worked example: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); FastAPI (Open source · local); OpenTelemetry (Open source)

Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Deliver a bounded pilot that reconciles inconsistent customer records and explains deployment choices to a fictional operations team.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create three CSV extracts with mismatched IDs, duplicate rows and different status conventions. Define a mapping table and an escalation owner for unresolved matches.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the DuckDB starter, then stage each source into its own table. Preserve raw columns and source-row identifiers; never overwrite the original exports.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build matching rules in increasing order of uncertainty: exact ID, approved alias, then manual review. Save a match explanation and confidence category for each output row.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Wrap the reconciliation job in a small API or scheduled local script. Add a request/run ID, row counts and rejected-record report; prepare a deployment options memo covering customer network and retention constraints.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. A reviewer must reproduce one result and identify which capabilities you implemented. Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-advanced-2.md: Customer discovery and constraints brief; Reproducible reconciliation pipeline; Pilot readout with architecture decision record. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: customer-specific document reconciliation pilot. Use the glossary below, then write your prediction for: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Forward-deployed AI engineer role interview. Explain defend: customer-specific document reconciliation pilot using this case: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: customer-specific document reconciliation pilot to a system or workflow you know. Explain defend: customer-specific document reconciliation pilot using this case: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write. Identify one observation that would contradict your claim.

Interview: Explain defend: customer-specific document reconciliation pilot using this case: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Customer-specific document reconciliation pilot at this level?

Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records. — Change an upstream column name and replay the same file twice. Fail schema validation clearly and prove the second ingest does not duplicate accepted records. Measure exact-match precision on a manually adjudicated set, unresolved rate, rerun consistency and processing time. Require approval before any downstream write.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

FastAPI: https://fastapi.tiangolo.com/tutorial/

OpenTelemetry: https://opentelemetry.io/docs/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

OpenTelemetry: https://opentelemetry.io/docs/
