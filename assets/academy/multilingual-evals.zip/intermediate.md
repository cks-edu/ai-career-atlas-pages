## intermediate — Comparable evaluation tasks

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Language competence and evaluation design; scripting is useful but human judgment is essential.

### Comparable evaluation tasks
Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations.
Mental model: Equivalent exams can use different examples while testing the same skill.
Boundary: Directly comparing aggregate scores can hide differences in task difficulty.
Worked example: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Cross-language model comparison study
Build a multilingual evaluation where language-specific failures remain visible. Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Recall: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. Identify one observation that would contradict your claim.

### Terms
Comparable evaluation tasks: Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a multilingual evaluation where language-specific failures remain visible. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The pilot flags more than two critical failures per ten tasks in each represented dialect. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a multilingual evaluation where language-specific failures remain visible.
Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.
Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.
Deliverables: Multilingual task set and provenance; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Multilingual & low-resource-language evaluation. Use this scenario: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Review: Start with the task and permitted scope. Explain comparable evaluation tasks: Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations. Show the input and observed output, then address Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Multilingual task set and provenance; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

