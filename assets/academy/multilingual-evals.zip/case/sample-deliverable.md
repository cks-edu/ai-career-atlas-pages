# SAMPLE — Multilingual evaluation and coverage report
Role: Multilingual & low-resource-language evaluation
Case: A language average omits dialect failures
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The pilot flags more than two critical failures per ten tasks in each represented dialect.

## Evidence table
| Record | dialect_failures (out of ten tasks) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 6 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two dialect slices fail the declared gate while the pooled language score looks acceptable.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Add locally grounded tasks and qualified raters for the failing slices.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in multilingual & low-resource-language evaluation.
Before release: Use new tasks, report sample sizes and keep disagreement and unrepresented populations explicit.

## Design choice and trade-off
Define dialect and task coverage before sampling; avoid assuming translated English tasks cover local needs.
More slices need more evaluation effort; small samples cannot justify broad population claims.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Low-resource task bank: Sources, dialect scope and rubric are documented.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
