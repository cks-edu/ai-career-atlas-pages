## advanced — Disaggregated reporting

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Disaggregated reporting
Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps.
Mental model: A dashboard shows each district's water quality, not only a citywide average.
Boundary: Sparse results are signals for investigation, not precise population estimates.
Worked example: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Cross-language model comparison study
Build a multilingual evaluation where language-specific failures remain visible. Produce per-language and per-task reports with sample counts and uncertainty. Inspect whether translated benchmarks miss culturally or linguistically specific cases.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Recall: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. Identify one observation that would contradict your claim.

### Terms
Disaggregated reporting: Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a multilingual evaluation where language-specific failures remain visible. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Produce per-language and per-task reports with sample counts and uncertainty. Inspect whether translated benchmarks miss culturally or linguistically specific cases.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a multilingual evaluation where language-specific failures remain visible.
Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.
Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Produce per-language and per-task reports with sample counts and uncertainty. Inspect whether translated benchmarks miss culturally or linguistically specific cases.
Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.
Recruit additional qualified reviewers for a new language and document what must change in the rubric.
Deliverables: Multilingual task set and provenance; Rubric/adjudication records; Disaggregated comparison and limitations report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A reviewer must reproduce one result and identify which capabilities you implemented. Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.

### Interview
Explain your advanced solution for Multilingual & low-resource-language evaluation. Use this scenario: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Review: Start with the task and permitted scope. Explain disaggregated reporting: Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps. Show the input and observed output, then address Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Multilingual task set and provenance; Rubric/adjudication records; Disaggregated comparison and limitations report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

