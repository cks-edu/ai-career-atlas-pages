# Multilingual & low-resource-language evaluation — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Language populations: Define locales, scripts, domains and tasks rather than treating a language as one homogeneous population. Recruit or consult reviewers with relevant competence.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Language populations

Define locales, scripts, domains and tasks rather than treating a language as one homogeneous population. Recruit or consult reviewers with relevant competence. In this role, work through: Separate formal and conversational examples for the chosen locale and record which varieties are not represented. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A map of a country needs regions, not just its capital.

Boundary: A small bilingual sample cannot support claims about all speakers.

Worked example: Separate formal and conversational examples for the chosen locale and record which varieties are not represented.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); Python (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Multilingual & low-resource-language evaluation: Separate formal and conversational examples for the chosen locale and record which varieties are not represented.

Predict the worked case

Read this case without running a tool: Separate formal and conversational examples for the chosen locale and record which varieties are not represented. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in language populations.

Connect the concept to the role

Apply this rule: Define locales, scripts, domains and tasks rather than treating a language as one homogeneous population. Recruit or consult reviewers with relevant competence. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A small bilingual sample cannot support claims about all speakers.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies language populations to this case: Separate formal and conversational examples for the chosen locale and record which varieties are not represented. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Separate formal and conversational examples for the chosen locale and record which varieties are not represented. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Language populations; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with language populations. Use the glossary below, then write your prediction for: Separate formal and conversational examples for the chosen locale and record which varieties are not represented. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multilingual & low-resource-language evaluation role interview. Explain language populations using this case: Separate formal and conversational examples for the chosen locale and record which varieties are not represented. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate language populations to a system or workflow you know. Explain language populations using this case: Separate formal and conversational examples for the chosen locale and record which varieties are not represented. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain language populations using this case: Separate formal and conversational examples for the chosen locale and record which varieties are not represented. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Separate formal and conversational examples for the chosen locale and record which varieties are not represented.

Define locales, scripts, domains and tasks rather than treating a language as one homogeneous population. Recruit or consult reviewers with relevant competence.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define locales, scripts, domains and tasks rather than treating a language as one homogeneous population. Recruit or consult reviewers with relevant competence. — Define locales, scripts, domains and tasks rather than treating a language as one homogeneous population. Recruit or consult reviewers with relevant competence. A small bilingual sample cannot support claims about all speakers.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Python: https://docs.python.org/3/library/venv.html

Label Studio: https://labelstud.io/guide/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Diagnose: A language average omits dialect failures

The pilot flags more than two critical failures per ten tasks in each represented dialect. Two dialect slices fail the declared gate while the pooled language score looks acceptable. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Add locally grounded tasks and qualified raters for the failing slices. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A map of a country needs regions, not just its capital.

Separate formal and conversational examples for the chosen locale and record which varieties are not represented.

Worked example: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Add locally grounded tasks and qualified raters for the failing slices.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); Python (Open source · local)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The pilot flags more than two critical failures per ten tasks in each represented dialect. Two dialect slices fail the declared gate while the pooled language score looks acceptable. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot flags more than two critical failures per ten tasks in each represented dialect. Apply this toy-case rule manually: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A language name does not capture every dialect, register or user group. Evaluation coverage should say exactly which contexts were tested.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Choose a language you know and a fictional appointment-reminder assistant. Specify audience, region, tone and channel.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A coverage table and a reviewer plan.

Preparation · Try step 2

Write three test situations, including an ambiguous date and a formal versus informal message.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A coverage table and a reviewer plan.

Preparation · Try step 3

List missing dialects or contexts and who could review them competently.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A coverage table and a reviewer plan.

Preparation · Explain and check your result

The plan does not claim coverage of an entire language from three examples; untested groups are explicit. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A coverage table and a reviewer plan. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot flags more than two critical failures per ten tasks in each represented dialect. Apply this toy-case rule manually: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two dialect slices fail the declared gate while the pooled language score looks acceptable. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two dialect slices fail the declared gate while the pooled language score looks acceptable. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a language average omits dialect failures. Use the glossary below, then write your prediction for: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Add locally grounded tasks and qualified raters for the failing slices. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multilingual & low-resource-language evaluation role interview. Explain diagnose: a language average omits dialect failures using this case: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Add locally grounded tasks and qualified raters for the failing slices. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a language average omits dialect failures to a system or workflow you know. Explain diagnose: a language average omits dialect failures using this case: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Add locally grounded tasks and qualified raters for the failing slices. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Use new tasks, report sample sizes and keep disagreement and unrepresented populations explicit. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a language average omits dialect failures using this case: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Add locally grounded tasks and qualified raters for the failing slices. State the evidence, one alternative and where the mental model stops.

Quiz: A language average omits dialect failures: The pilot flags more than two critical failures per ten tasks in each represented dialect.

Change the acceptance rule after seeing an inconvenient result.

Add locally grounded tasks and qualified raters for the failing slices.

Omit failed cases and report only the successful demonstrations.

Reference: Add locally grounded tasks and qualified raters for the failing slices. — Add locally grounded tasks and qualified raters for the failing slices. Use new tasks, report sample sizes and keep disagreement and unrepresented populations explicit.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Python: https://docs.python.org/3/library/venv.html

Label Studio: https://labelstud.io/guide/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Language competence and evaluation design; scripting is useful but human judgment is essential.

Terms:

Comparable evaluation tasks: Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Comparable evaluation tasks

Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations. In this role, work through: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Equivalent exams can use different examples while testing the same skill.

Boundary: Directly comparing aggregate scores can hide differences in task difficulty.

Worked example: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Language competence and evaluation design; scripting is useful but human judgment is essential.

Tools for this exercise: Document or text editor

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); Python (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Multilingual & low-resource-language evaluation: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity.

Predict the worked case

Read this case without running a tool: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in comparable evaluation tasks.

Connect the concept to the role

Apply this rule: Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Directly comparing aggregate scores can hide differences in task difficulty.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies comparable evaluation tasks to this case: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Comparable evaluation tasks; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with comparable evaluation tasks. Use the glossary below, then write your prediction for: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multilingual & low-resource-language evaluation role interview. Explain comparable evaluation tasks using this case: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate comparable evaluation tasks to a system or workflow you know. Explain comparable evaluation tasks using this case: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain comparable evaluation tasks using this case: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity.

Treat a passing starter as proof of the whole role workflow.

Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations.

Ignore the failure because the tool produced an output.

Reference: Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations. — Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations. Directly comparing aggregate scores can hide differences in task difficulty.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Python: https://docs.python.org/3/library/venv.html

Label Studio: https://labelstud.io/guide/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Integrate: Cross-language model comparison study

Build a multilingual evaluation where language-specific failures remain visible. Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence. In this role, work through: Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: Equivalent exams can use different examples while testing the same skill.

A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity.

Worked example: Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); Python (Open source · local)

Build a multilingual evaluation where language-specific failures remain visible. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Build a multilingual evaluation where language-specific failures remain visible.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

Prepare the project inputs

Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The pilot flags more than two critical failures per ten tasks in each represented dialect. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Multilingual task set and provenance; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: cross-language model comparison study. Use the glossary below, then write your prediction for: Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multilingual & low-resource-language evaluation role interview. Explain integrate: cross-language model comparison study using this case: Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: cross-language model comparison study to a system or workflow you know. Explain integrate: cross-language model comparison study using this case: Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. Identify one observation that would contradict your claim.

Interview: Explain integrate: cross-language model comparison study using this case: Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Cross-language model comparison study at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.

Reference: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. — Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Python: https://docs.python.org/3/library/venv.html

Label Studio: https://labelstud.io/guide/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Disaggregated reporting: Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Disaggregated reporting

Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps. In this role, work through: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A dashboard shows each district's water quality, not only a citywide average.

Boundary: Sparse results are signals for investigation, not precise population estimates.

Worked example: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); Python (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Multilingual & low-resource-language evaluation: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence.

Predict the worked case

Read this case without running a tool: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in disaggregated reporting.

Connect the concept to the role

Apply this rule: Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Sparse results are signals for investigation, not precise population estimates.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies disaggregated reporting to this case: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Disaggregated reporting; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with disaggregated reporting. Use the glossary below, then write your prediction for: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multilingual & low-resource-language evaluation role interview. Explain disaggregated reporting using this case: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate disaggregated reporting to a system or workflow you know. Explain disaggregated reporting using this case: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain disaggregated reporting using this case: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps.

Reference: Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps. — Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps. Sparse results are signals for investigation, not precise population estimates.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Python: https://docs.python.org/3/library/venv.html

Label Studio: https://labelstud.io/guide/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Defend: Cross-language model comparison study

Build a multilingual evaluation where language-specific failures remain visible. Produce per-language and per-task reports with sample counts and uncertainty. Inspect whether translated benchmarks miss culturally or linguistically specific cases. In this role, work through: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A dashboard shows each district's water quality, not only a citywide average.

A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence.

Worked example: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); Python (Open source · local)

Build a multilingual evaluation where language-specific failures remain visible. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Build a multilingual evaluation where language-specific failures remain visible.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

Prepare the project inputs

Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Produce per-language and per-task reports with sample counts and uncertainty. Inspect whether translated benchmarks miss culturally or linguistically specific cases.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A reviewer must reproduce one result and identify which capabilities you implemented. Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Multilingual task set and provenance; Rubric/adjudication records; Disaggregated comparison and limitations report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: cross-language model comparison study. Use the glossary below, then write your prediction for: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Multilingual & low-resource-language evaluation role interview. Explain defend: cross-language model comparison study using this case: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: cross-language model comparison study to a system or workflow you know. Explain defend: cross-language model comparison study using this case: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. Identify one observation that would contradict your claim.

Interview: Explain defend: cross-language model comparison study using this case: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Cross-language model comparison study at this level?

Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score. — Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score. Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Python: https://docs.python.org/3/library/venv.html

Label Studio: https://labelstud.io/guide/

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
