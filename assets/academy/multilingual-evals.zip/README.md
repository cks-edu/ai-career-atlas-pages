# Multilingual & low-resource-language evaluation

AI Engineering · Beginner → Intermediate → Advanced

Start with Language populations. A language name does not capture every dialect, register or user group. Evaluation coverage should say exactly which contexts were tested. Then try Draft a language coverage plan. The three levels build toward Cross-language model comparison study. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Language populations

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Language populations
Define locales, scripts, domains and tasks rather than treating a language as one homogeneous population. Recruit or consult reviewers with relevant competence.
Mental model: A map of a country needs regions, not just its capital.
Boundary: A small bilingual sample cannot support claims about all speakers.
Worked example: Separate formal and conversational examples for the chosen locale and record which varieties are not represented.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A language average omits dialect failures
The pilot flags more than two critical failures per ten tasks in each represented dialect. Two dialect slices fail the declared gate while the pooled language score looks acceptable. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Add locally grounded tasks and qualified raters for the failing slices.
Recall: Use new tasks, report sample sizes and keep disagreement and unrepresented populations explicit. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Language populations: Define locales, scripts, domains and tasks rather than treating a language as one homogeneous population. Recruit or consult reviewers with relevant competence.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A language name does not capture every dialect, register or user group. Evaluation coverage should say exactly which contexts were tested.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose a language you know and a fictional appointment-reminder assistant. Specify audience, region, tone and channel.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A coverage table and a reviewer plan.

3. Try step 2
Write three test situations, including an ambiguous date and a formal versus informal message.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A coverage table and a reviewer plan.

4. Try step 3
List missing dialects or contexts and who could review them competently.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A coverage table and a reviewer plan.

5. Explain and check your result
The plan does not claim coverage of an entire language from three examples; untested groups are explicit. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A coverage table and a reviewer plan. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot flags more than two critical failures per ten tasks in each represented dialect. Apply this toy-case rule manually: Review when dialect_failures >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two dialect slices fail the declared gate while the pooled language score looks acceptable. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Multilingual & low-resource-language evaluation.
Choose a language you know and a fictional appointment-reminder assistant. Specify audience, region, tone and channel.
Write three test situations, including an ambiguous date and a formal versus informal message.
List missing dialects or contexts and who could review them competently.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A coverage table and a reviewer plan. Include beginner-worksheet.md and your completed Multilingual evaluation and coverage report.
Check: The plan does not claim coverage of an entire language from three examples; untested groups are explicit.

### Interview
Explain your beginner solution for Multilingual & low-resource-language evaluation. Use this scenario: The pilot flags more than two critical failures per ten tasks in each represented dialect.
Review: Start with the task and permitted scope. Explain language populations: Define locales, scripts, domains and tasks rather than treating a language as one homogeneous population. Recruit or consult reviewers with relevant competence. Show the input and observed output, then address Add locally grounded tasks and qualified raters for the failing slices. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A coverage table and a reviewer plan. Include beginner-worksheet.md and your completed Multilingual evaluation and coverage report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Comparable evaluation tasks

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Language competence and evaluation design; scripting is useful but human judgment is essential.

### Comparable evaluation tasks
Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations.
Mental model: Equivalent exams can use different examples while testing the same skill.
Boundary: Directly comparing aggregate scores can hide differences in task difficulty.
Worked example: A date-format question uses locally meaningful conventions, while the rubric still checks whether the answer resolves ambiguity.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Cross-language model comparison study
Build a multilingual evaluation where language-specific failures remain visible. Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Recall: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. Identify one observation that would contradict your claim.

### Terms
Comparable evaluation tasks: Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a multilingual evaluation where language-specific failures remain visible. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The pilot flags more than two critical failures per ten tasks in each represented dialect. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a multilingual evaluation where language-specific failures remain visible.
Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.
Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.
Deliverables: Multilingual task set and provenance; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Multilingual & low-resource-language evaluation. Use this scenario: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Review: Start with the task and permitted scope. Explain comparable evaluation tasks: Create culturally appropriate tasks with consistent intent and scoring, not only literal translations. Review ambiguity and preserve locale-specific expectations. Show the input and observed output, then address Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Multilingual task set and provenance; Rubric/adjudication records. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Disaggregated reporting

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Disaggregated reporting
Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps.
Mental model: A dashboard shows each district's water quality, not only a citywide average.
Boundary: Sparse results are signals for investigation, not precise population estimates.
Worked example: A model improves overall but fails a low-resource slice with only eight examples; report the observed failures and gather more evidence.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Cross-language model comparison study
Build a multilingual evaluation where language-specific failures remain visible. Produce per-language and per-task reports with sample counts and uncertainty. Inspect whether translated benchmarks miss culturally or linguistically specific cases.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Recall: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. Identify one observation that would contradict your claim.

### Terms
Disaggregated reporting: Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a multilingual evaluation where language-specific failures remain visible. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Produce per-language and per-task reports with sample counts and uncertainty. Inspect whether translated benchmarks miss culturally or linguistically specific cases.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a multilingual evaluation where language-specific failures remain visible.
Create parallel and locally authored tasks in two languages with qualified reviewers. Record whether each item is translated, adapted or independently written.
Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.
Collect outputs from two candidates under equivalent settings. Blind reviewers, retain disagreements and adjudicate with source-language evidence.
Produce per-language and per-task reports with sample counts and uncertainty. Inspect whether translated benchmarks miss culturally or linguistically specific cases.
Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.
Recruit additional qualified reviewers for a new language and document what must change in the rubric.
Deliverables: Multilingual task set and provenance; Rubric/adjudication records; Disaggregated comparison and limitations report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A reviewer must reproduce one result and identify which capabilities you implemented. Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.

### Interview
Explain your advanced solution for Multilingual & low-resource-language evaluation. Use this scenario: Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.
Review: Start with the task and permitted scope. Explain disaggregated reporting: Report counts, uncertainty and failure types by locale and task. Keep reviewer disagreement visible and prioritize harmful or systematic gaps. Show the input and observed output, then address Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Multilingual task set and provenance; Rubric/adjudication records; Disaggregated comparison and limitations report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Label Studio — Open source Community · commercial editions optional
Configure annotation tasks and export reviewer judgments.
Alternative: A reviewed CSV workbook for small batches, or a commercial annotation platform; access, adjudication and export matter more than brand.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Python — Open source · local
Isolated environments and reproducible scripts.
Alternative: A spreadsheet for manual evidence exercises, or another supported programming language for implementation; reproduce the same acceptance checks.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Label Studio: https://labelstud.io/guide/quick_start
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Python: https://docs.python.org/3/library/venv.html
Label Studio: https://labelstud.io/guide/
Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
