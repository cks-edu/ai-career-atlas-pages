# Multilingual task set and provenance

Project: Cross-language model comparison study
Status: blank work product — not completed evidence

## Purpose and audience
Build a multilingual evaluation where language-specific failures remain visible.

## Required content
Write a shared rubric plus language-specific notes and critical-error examples. Import stable task IDs into Label Studio or Calc.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.

## Failure evidence
Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
