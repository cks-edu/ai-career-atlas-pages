# Cross-language model comparison study

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a multilingual evaluation where language-specific failures remain visible.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Include code-switching, negation and an unsupported low-resource expression. Allow a reviewer to mark insufficient expertise instead of forcing a confident score.

## Limitations and next iteration
Recruit additional qualified reviewers for a new language and document what must change in the rubric.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
