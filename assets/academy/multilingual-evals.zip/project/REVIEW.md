# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Multilingual task set and provenance.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report critical errors, agreement and task success separately by language. Do not hide a weak language behind a pooled average.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
