# Embedded / IoT Engineer

Software Engineering

Start with hysteresis and sensor validity. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward hardware validation plan and measured evidence bundle.

## beginner

Run sensor.c, add boundary values and an invalid-reading sentinel, then implement a documented fault state. Assert every transition. Include repeated invalid readings and recovery to a valid sensor value.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State machines
A state machine defines allowed states and how events change them.
Mental model: Traffic lights change according to explicit rules.
Limit: Real timing, interrupts and hardware noise require additional engineering.
Example: A fan turns on at 30, stays on at 28 and turns off at 25.
Recall: What state would you use when a sensor reading is unavailable?

### Hysteresis and sensor validity
Hysteresis uses different on/off thresholds to avoid rapid switching near one value. Invalid sensor readings need an explicit fault policy rather than being treated as ordinary temperature.
Mental model: A thermostat leaves a gap between turning heat on and off so it does not chatter.
Limit: Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior.
Example: 24,30,28,25 produces fan states 0,1,1,0.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
24,30,28,25 produces fan states 0,1,1,0. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run sensor.c, add boundary values and an invalid-reading sentinel, then implement a documented fault state. Assert every transition. Include repeated invalid readings and recovery to a valid sensor value.
```
cc -Wall -Wextra sensor.c -o sensor
./sensor
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Stable hysteresis and a visible fault outcome.

6. Role workshop · debug and verify
Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save state machine and host tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Stable hysteresis and a visible fault outcome.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Hysteresis and sensor validity: Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: state machine and host tests
Stable hysteresis and a visible fault outcome.

Interview: Work through this Embedded / IoT Engineer case: 24,30,28,25 produces fan states 0,1,1,0. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Hysteresis uses different on/off thresholds to avoid rapid switching near one value. Invalid sensor readings need an explicit fault policy rather than being treated as ordinary temperature. Expected evidence: Stable hysteresis and a visible fault outcome. Diagnosis: Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior. State the limits of the mental model: A thermostat leaves a gap between turning heat on and off so it does not chatter.

Resume: Built state machine and host tests using C, Zephyr and a host compiler; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Add a simulated monotonic tick and a last-success timestamp. Test on-time, late and missing readings, then define the hardware watchdog integration and timing measurements still required.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Memory and ownership
Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.
Mental model: A borrowed library book must not be used after it is returned.
Limit: Languages enforce different parts of this discipline; concurrency adds other hazards.
Example: A fixed array of four readings is traversed with indices zero through three.
Recall: Why is index four invalid in a four-element array?

### Timing and watchdog design
A watchdog can detect missed progress, but feeding it unconditionally can conceal a stuck task. Define deadlines and evidence of useful work before hardware testing.
Mental model: A supervisor checks completed work, not merely whether someone waves.
Limit: Host sleep timings do not prove real-time deadlines on the target board.
Example: A stalled sensor task must not indefinitely report healthy progress.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Host sleep timings do not prove real-time deadlines on the target board.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
A stalled sensor task must not indefinitely report healthy progress. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add a simulated monotonic tick and a last-success timestamp. Test on-time, late and missing readings, then define the hardware watchdog integration and timing measurements still required.
```
cc -Wall -Wextra sensor.c -o sensor
./sensor
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Deterministic timeout behavior in simulation with hardware limitations stated.

6. Role workshop · debug and verify
Host sleep timings do not prove real-time deadlines on the target board. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save watchdog model and target test plan. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Deterministic timeout behavior in simulation with hardware limitations stated.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Timing and watchdog design: Host sleep timings do not prove real-time deadlines on the target board.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: watchdog model and target test plan
Deterministic timeout behavior in simulation with hardware limitations stated.

Interview: Work through this Embedded / IoT Engineer case: A stalled sensor task must not indefinitely report healthy progress. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A watchdog can detect missed progress, but feeding it unconditionally can conceal a stuck task. Define deadlines and evidence of useful work before hardware testing. Expected evidence: Deterministic timeout behavior in simulation with hardware limitations stated. Diagnosis: Host sleep timings do not prove real-time deadlines on the target board. State the limits of the mental model: A supervisor checks completed work, not merely whether someone waves.

Resume: Built watchdog model and target test plan using C, Zephyr and a host compiler; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write a board-specific test matrix with voltage, clock, memory and watchdog observations. Run only available authorized hardware cases and preserve logs; label remaining cases unexecuted.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Determinism and timing
A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.
Mental model: A rehearsal follows a script; a live performance adds timing constraints.
Limit: A host simulation does not validate hardware or real-time deadlines.
Example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.
Recall: What measurements would be required on actual hardware?

### Hardware validation boundaries
Host tests verify logic while real boards add electrical, timing and resource constraints. Use a hardware-in-the-loop plan with controlled fault injection and recovery expectations.
Mental model: A flight simulator tests procedures but cannot certify the aircraft's wiring.
Limit: Never claim safety certification from a small lab or a passing host test.
Example: A disconnected sensor and a reboot during an update require different recovery checks.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Never claim safety certification from a small lab or a passing host test.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
A disconnected sensor and a reboot during an update require different recovery checks. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a board-specific test matrix with voltage, clock, memory and watchdog observations. Run only available authorized hardware cases and preserve logs; label remaining cases unexecuted.
```
cc -Wall -Wextra sensor.c -o sensor
./sensor
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A clear boundary between simulated and measured device behavior.

6. Role workshop · debug and verify
Never claim safety certification from a small lab or a passing host test. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save hardware validation plan and measured evidence bundle. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A clear boundary between simulated and measured device behavior.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Hardware validation boundaries: Never claim safety certification from a small lab or a passing host test.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: hardware validation plan and measured evidence bundle
A clear boundary between simulated and measured device behavior.

Interview: Work through this Embedded / IoT Engineer case: A disconnected sensor and a reboot during an update require different recovery checks. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Host tests verify logic while real boards add electrical, timing and resource constraints. Use a hardware-in-the-loop plan with controlled fault injection and recovery expectations. Expected evidence: A clear boundary between simulated and measured device behavior. Diagnosis: Never claim safety certification from a small lab or a passing host test. State the limits of the mental model: A flight simulator tests procedures but cannot certify the aircraft's wiring.

Resume: Built hardware validation plan and measured evidence bundle using C, Zephyr and a host compiler; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html
The Rust Programming Language: https://doc.rust-lang.org/book/
Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html
