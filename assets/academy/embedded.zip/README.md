# Embedded / IoT Engineer

Software Engineering

Begin with state machines. Run the fan state-machine simulation. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Run the fan state-machine simulation

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware.

### State machines
A state machine defines allowed states and how events change them.
Mental model: Traffic lights change according to explicit rules.
Limit: Real timing, interrupts and hardware noise require additional engineering.
Example: A fan turns on at 30, stays on at 28 and turns off at 25.
Recall: What state would you use when a sensor reading is unavailable?

### Apply state machines in Embedded / IoT Engineer
Use the concept to complete this role exercise: Run the fan state-machine simulation
Mental model: Traffic lights change according to explicit rules.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: A fan turns on at 30, stays on at 28 and turns off at 25. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Apply the role exercise
Run the fan state-machine simulation
Expected: Save the code, test cases and a distinction between simulated and hardware/device evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: embedded-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Run the fan state-machine simulation? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A state machine defines allowed states and how events change them. For this role, explicitly address: Run the fan state-machine simulation.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Add an explicit sensor-failure state and test boundaries

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware.

### Memory and ownership
Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.
Mental model: A borrowed library book must not be used after it is returned.
Limit: Languages enforce different parts of this discipline; concurrency adds other hazards.
Example: A fixed array of four readings is traversed with indices zero through three.
Recall: Why is index four invalid in a four-element array?

### Apply memory and ownership in Embedded / IoT Engineer
Use the concept to complete this role exercise: Add an explicit sensor-failure state and test boundaries
Mental model: A borrowed library book must not be used after it is returned.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: A fixed array of four readings is traversed with indices zero through three. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Apply the role exercise
Add an explicit sensor-failure state and test boundaries
Expected: Save the code, test cases and a distinction between simulated and hardware/device evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: embedded-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Add an explicit sensor-failure state and test boundaries? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. For this role, explicitly address: Add an explicit sensor-failure state and test boundaries.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Plan watchdog, timing and hardware-in-the-loop validation without claiming host tests prove hardware safety

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware.

### Determinism and timing
A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.
Mental model: A rehearsal follows a script; a live performance adds timing constraints.
Limit: A host simulation does not validate hardware or real-time deadlines.
Example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.
Recall: What measurements would be required on actual hardware?

### Apply determinism and timing in Embedded / IoT Engineer
Use the concept to complete this role exercise: Plan watchdog, timing and hardware-in-the-loop validation without claiming host tests prove hardware safety
Mental model: A rehearsal follows a script; a live performance adds timing constraints.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Apply the role exercise
Plan watchdog, timing and hardware-in-the-loop validation without claiming host tests prove hardware safety
Expected: Save the code, test cases and a distinction between simulated and hardware/device evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: embedded-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Plan watchdog, timing and hardware-in-the-loop validation without claiming host tests prove hardware safety? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. For this role, explicitly address: Plan watchdog, timing and hardware-in-the-loop validation without claiming host tests prove hardware safety.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html
The Rust Programming Language: https://doc.rust-lang.org/book/
Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html
