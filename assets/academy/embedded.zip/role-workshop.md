# Embedded / IoT Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Hysteresis and sensor validity

Hysteresis uses different on/off thresholds to avoid rapid switching near one value. Invalid sensor readings need an explicit fault policy rather than being treated as ordinary temperature.
Mental model: A thermostat leaves a gap between turning heat on and off so it does not chatter.
Case: 24,30,28,25 produces fan states 0,1,1,0.
Task: Run sensor.c, add boundary values and an invalid-reading sentinel, then implement a documented fault state. Assert every transition. Include repeated invalid readings and recovery to a valid sensor value.
Acceptance: Stable hysteresis and a visible fault outcome.
Troubleshooting: Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior.
Deliverable: state machine and host tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Timing and watchdog design

A watchdog can detect missed progress, but feeding it unconditionally can conceal a stuck task. Define deadlines and evidence of useful work before hardware testing.
Mental model: A supervisor checks completed work, not merely whether someone waves.
Case: A stalled sensor task must not indefinitely report healthy progress.
Task: Add a simulated monotonic tick and a last-success timestamp. Test on-time, late and missing readings, then define the hardware watchdog integration and timing measurements still required.
Acceptance: Deterministic timeout behavior in simulation with hardware limitations stated.
Troubleshooting: Host sleep timings do not prove real-time deadlines on the target board.
Deliverable: watchdog model and target test plan

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Hardware validation boundaries

Host tests verify logic while real boards add electrical, timing and resource constraints. Use a hardware-in-the-loop plan with controlled fault injection and recovery expectations.
Mental model: A flight simulator tests procedures but cannot certify the aircraft's wiring.
Case: A disconnected sensor and a reboot during an update require different recovery checks.
Task: Write a board-specific test matrix with voltage, clock, memory and watchdog observations. Run only available authorized hardware cases and preserve logs; label remaining cases unexecuted.
Acceptance: A clear boundary between simulated and measured device behavior.
Troubleshooting: Never claim safety certification from a small lab or a passing host test.
Deliverable: hardware validation plan and measured evidence bundle

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
