#include <stdio.h>
#include <assert.h>
/* Host simulation, not a real interrupt or hardware driver. */
int next(int on, int value) { if(value>=30)return 1; if(value<=25)return 0; return on; }
int main(void){int values[]={24,30,28,25};int expected[]={0,1,1,0};int on=0;for(int i=0;i<4;i++){on=next(on,values[i]);assert(on==expected[i]);printf("temperature=%d fan=%d\n",values[i],on);}puts("PASS systems: hysteresis");return 0;}
