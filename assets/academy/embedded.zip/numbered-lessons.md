# Embedded / IoT Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

State machines: A state machine defines allowed states and how events change them.

Apply state machines in Embedded / IoT Engineer: Use the concept to complete this role exercise: Run the fan state-machine simulation

Hysteresis and sensor validity: Hysteresis uses different on/off thresholds to avoid rapid switching near one value. Invalid sensor readings need an explicit fault policy rather than being treated as ordinary temperature.

### State machines

A state machine defines allowed states and how events change them. In this role, work through: 24,30,28,25 produces fan states 0,1,1,0. The practical workshop develops this into: Run sensor.c, add boundary values and an invalid-reading sentinel, then implement a documented fault state. Assert every transition. Include repeated invalid readings and recovery to a valid sensor value.

Mental model: Traffic lights change according to explicit rules.

Boundary: Real timing, interrupts and hardware noise require additional engineering.

Role application: A thermostat leaves a gap between turning heat on and off so it does not chatter.

Hysteresis uses different on/off thresholds to avoid rapid switching near one value. Invalid sensor readings need an explicit fault policy rather than being treated as ordinary temperature.

Worked example: 24,30,28,25 produces fan states 0,1,1,0.

Shared foundation example: A fan turns on at 30, stays on at 28 and turns off at 25.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: C, Zephyr and a host compiler (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Embedded / IoT Engineer: 24,30,28,25 produces fan states 0,1,1,0.

Predict the worked case

Read this case without running a tool: 24,30,28,25 produces fan states 0,1,1,0. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state machines.

Connect the concept to the role

Apply this rule: A state machine defines allowed states and how events change them. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Real timing, interrupts and hardware noise require additional engineering.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state machines to this case: 24,30,28,25 produces fan states 0,1,1,0. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: 24,30,28,25 produces fan states 0,1,1,0. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for State machines; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state machines. Use the glossary below, then write your prediction for: 24,30,28,25 produces fan states 0,1,1,0. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Embedded / IoT Engineer role interview. Explain state machines using this case: 24,30,28,25 produces fan states 0,1,1,0. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state machines to a system or workflow you know. Explain state machines using this case: 24,30,28,25 produces fan states 0,1,1,0. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What state would you use when a sensor reading is unavailable?

Interview: Explain state machines using this case: 24,30,28,25 produces fan states 0,1,1,0. State the evidence, one alternative and where the mental model stops.

Quiz: After the Hysteresis and sensor validity rehearsal, check this foundation: An event is valid only in one workflow state. How should it be handled in another state?

Apply the declared transition policy, including rejection or no-op where defined.

Always jump to the final state to complete the flow.

Ignore the current state and repeat the last action.

Reference: Apply the declared transition policy, including rejection or no-op where defined. — A transition depends on the current state and event, not only the event name.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

### Hysteresis and sensor validity

Hysteresis uses different on/off thresholds to avoid rapid switching near one value. Invalid sensor readings need an explicit fault policy rather than being treated as ordinary temperature. In this role, work through: 24,30,28,25 produces fan states 0,1,1,0. The practical workshop develops this into: Run sensor.c, add boundary values and an invalid-reading sentinel, then implement a documented fault state. Assert every transition. Include repeated invalid readings and recovery to a valid sensor value.

Mental model: A thermostat leaves a gap between turning heat on and off so it does not chatter.

Boundary: Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior.

Worked example: 24,30,28,25 produces fan states 0,1,1,0.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: C, Zephyr and a host compiler (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Embedded / IoT Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run sensor.c, add boundary values and an invalid-reading sentinel, then implement a documented fault state. Assert every transition. Include repeated invalid readings and recovery to a valid sensor value.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

24,30,28,25 produces fan states 0,1,1,0. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run sensor.c, add boundary values and an invalid-reading sentinel, then implement a documented fault state. Assert every transition. Include repeated invalid readings and recovery to a valid sensor value.

```
cc -Wall -Wextra sensor.c -o sensor
./sensor
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Stable hysteresis and a visible fault outcome.

Role workshop · debug and verify

Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save state machine and host tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Stable hysteresis and a visible fault outcome.

Expected: Stable hysteresis and a visible fault outcome.

Troubleshoot: The role exercise differs from the prediction: Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: state machine and host tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with hysteresis and sensor validity. Use the glossary below, then write your prediction for: 24,30,28,25 produces fan states 0,1,1,0. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Embedded / IoT Engineer role interview. Explain hysteresis and sensor validity using this case: 24,30,28,25 produces fan states 0,1,1,0. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate hysteresis and sensor validity to a system or workflow you know. Explain hysteresis and sensor validity using this case: 24,30,28,25 produces fan states 0,1,1,0. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Filtering out invalid readings without changing state can hide a failed sensor; specify the safe behavior.

Interview: Explain hysteresis and sensor validity using this case: 24,30,28,25 produces fan states 0,1,1,0. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? 24,30,28,25 produces fan states 0,1,1,0.

Stable hysteresis and a visible fault outcome.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Stable hysteresis and a visible fault outcome. — Hysteresis uses different on/off thresholds to avoid rapid switching near one value. Invalid sensor readings need an explicit fault policy rather than being treated as ordinary temperature. Stable hysteresis and a visible fault outcome.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Memory and ownership: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.

Apply memory and ownership in Embedded / IoT Engineer: Use the concept to complete this role exercise: Add an explicit sensor-failure state and test boundaries

Timing and watchdog design: A watchdog can detect missed progress, but feeding it unconditionally can conceal a stuck task. Define deadlines and evidence of useful work before hardware testing.

### Memory and ownership

Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. In this role, work through: A stalled sensor task must not indefinitely report healthy progress. The practical workshop develops this into: Add a simulated monotonic tick and a last-success timestamp. Test on-time, late and missing readings, then define the hardware watchdog integration and timing measurements still required.

Mental model: A borrowed library book must not be used after it is returned.

Boundary: Languages enforce different parts of this discipline; concurrency adds other hazards.

Role application: A supervisor checks completed work, not merely whether someone waves.

A watchdog can detect missed progress, but feeding it unconditionally can conceal a stuck task. Define deadlines and evidence of useful work before hardware testing.

Worked example: A stalled sensor task must not indefinitely report healthy progress.

Shared foundation example: A fixed array of four readings is traversed with indices zero through three.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: C, Zephyr and a host compiler (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Embedded / IoT Engineer: A stalled sensor task must not indefinitely report healthy progress.

Predict the worked case

Read this case without running a tool: A stalled sensor task must not indefinitely report healthy progress. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in memory and ownership.

Connect the concept to the role

Apply this rule: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Languages enforce different parts of this discipline; concurrency adds other hazards.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies memory and ownership to this case: A stalled sensor task must not indefinitely report healthy progress. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A stalled sensor task must not indefinitely report healthy progress. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Memory and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with memory and ownership. Use the glossary below, then write your prediction for: A stalled sensor task must not indefinitely report healthy progress. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Embedded / IoT Engineer role interview. Explain memory and ownership using this case: A stalled sensor task must not indefinitely report healthy progress. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate memory and ownership to a system or workflow you know. Explain memory and ownership using this case: A stalled sensor task must not indefinitely report healthy progress. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is index four invalid in a four-element array?

Interview: Explain memory and ownership using this case: A stalled sensor task must not indefinitely report healthy progress. State the evidence, one alternative and where the mental model stops.

Quiz: After the Timing and watchdog design rehearsal, check this foundation: A buffer has capacity four and zero-based indices. Which index range is valid?

1 through 4 inclusive.

0 through 3 inclusive.

0 through 4 inclusive.

Reference: 0 through 3 inclusive. — Capacity is the number of elements; the last valid zero-based index is capacity minus one. Lifetime checks are separate.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

### Timing and watchdog design

A watchdog can detect missed progress, but feeding it unconditionally can conceal a stuck task. Define deadlines and evidence of useful work before hardware testing. In this role, work through: A stalled sensor task must not indefinitely report healthy progress. The practical workshop develops this into: Add a simulated monotonic tick and a last-success timestamp. Test on-time, late and missing readings, then define the hardware watchdog integration and timing measurements still required.

Mental model: A supervisor checks completed work, not merely whether someone waves.

Boundary: Host sleep timings do not prove real-time deadlines on the target board.

Worked example: A stalled sensor task must not indefinitely report healthy progress.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: C, Zephyr and a host compiler (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Embedded / IoT Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add a simulated monotonic tick and a last-success timestamp. Test on-time, late and missing readings, then define the hardware watchdog integration and timing measurements still required.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

A stalled sensor task must not indefinitely report healthy progress. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add a simulated monotonic tick and a last-success timestamp. Test on-time, late and missing readings, then define the hardware watchdog integration and timing measurements still required.

```
cc -Wall -Wextra sensor.c -o sensor
./sensor
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Deterministic timeout behavior in simulation with hardware limitations stated.

Role workshop · debug and verify

Host sleep timings do not prove real-time deadlines on the target board. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save watchdog model and target test plan. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Deterministic timeout behavior in simulation with hardware limitations stated.

Expected: Deterministic timeout behavior in simulation with hardware limitations stated.

Troubleshoot: The role exercise differs from the prediction: Host sleep timings do not prove real-time deadlines on the target board.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: watchdog model and target test plan; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with timing and watchdog design. Use the glossary below, then write your prediction for: A stalled sensor task must not indefinitely report healthy progress. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Embedded / IoT Engineer role interview. Explain timing and watchdog design using this case: A stalled sensor task must not indefinitely report healthy progress. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate timing and watchdog design to a system or workflow you know. Explain timing and watchdog design using this case: A stalled sensor task must not indefinitely report healthy progress. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Host sleep timings do not prove real-time deadlines on the target board.

Interview: Explain timing and watchdog design using this case: A stalled sensor task must not indefinitely report healthy progress. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A stalled sensor task must not indefinitely report healthy progress.

Ignore the failing case and keep only the successful screenshot.

Deterministic timeout behavior in simulation with hardware limitations stated.

Treat any successful command as proof that all business and access rules passed.

Reference: Deterministic timeout behavior in simulation with hardware limitations stated. — A watchdog can detect missed progress, but feeding it unconditionally can conceal a stuck task. Define deadlines and evidence of useful work before hardware testing. Deterministic timeout behavior in simulation with hardware limitations stated.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Determinism and timing: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.

Apply determinism and timing in Embedded / IoT Engineer: Use the concept to complete this role exercise: Plan watchdog, timing and hardware-in-the-loop validation without claiming host tests prove hardware safety

Hardware validation boundaries: Host tests verify logic while real boards add electrical, timing and resource constraints. Use a hardware-in-the-loop plan with controlled fault injection and recovery expectations.

### Determinism and timing

A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. In this role, work through: A disconnected sensor and a reboot during an update require different recovery checks. The practical workshop develops this into: Write a board-specific test matrix with voltage, clock, memory and watchdog observations. Run only available authorized hardware cases and preserve logs; label remaining cases unexecuted.

Mental model: A rehearsal follows a script; a live performance adds timing constraints.

Boundary: A host simulation does not validate hardware or real-time deadlines.

Role application: A flight simulator tests procedures but cannot certify the aircraft's wiring.

Host tests verify logic while real boards add electrical, timing and resource constraints. Use a hardware-in-the-loop plan with controlled fault injection and recovery expectations.

Worked example: A disconnected sensor and a reboot during an update require different recovery checks.

Shared foundation example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: C, Zephyr and a host compiler (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Embedded / IoT Engineer: A disconnected sensor and a reboot during an update require different recovery checks.

Predict the worked case

Read this case without running a tool: A disconnected sensor and a reboot during an update require different recovery checks. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in determinism and timing.

Connect the concept to the role

Apply this rule: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A host simulation does not validate hardware or real-time deadlines.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies determinism and timing to this case: A disconnected sensor and a reboot during an update require different recovery checks. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A disconnected sensor and a reboot during an update require different recovery checks. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Determinism and timing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with determinism and timing. Use the glossary below, then write your prediction for: A disconnected sensor and a reboot during an update require different recovery checks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Embedded / IoT Engineer role interview. Explain determinism and timing using this case: A disconnected sensor and a reboot during an update require different recovery checks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate determinism and timing to a system or workflow you know. Explain determinism and timing using this case: A disconnected sensor and a reboot during an update require different recovery checks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What measurements would be required on actual hardware?

Interview: Explain determinism and timing using this case: A disconnected sensor and a reboot during an update require different recovery checks. State the evidence, one alternative and where the mental model stops.

Quiz: After the Hardware validation boundaries rehearsal, check this foundation: A replay produces the expected output every time. What is still needed for a real-time deadline claim?

No further evidence if results are deterministic.

Only a larger input file.

Measured timing under the intended resource and load conditions.

Reference: Measured timing under the intended resource and load conditions. — Repeatable results do not establish latency or worst-case timing on the target system.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

### Hardware validation boundaries

Host tests verify logic while real boards add electrical, timing and resource constraints. Use a hardware-in-the-loop plan with controlled fault injection and recovery expectations. In this role, work through: A disconnected sensor and a reboot during an update require different recovery checks. The practical workshop develops this into: Write a board-specific test matrix with voltage, clock, memory and watchdog observations. Run only available authorized hardware cases and preserve logs; label remaining cases unexecuted.

Mental model: A flight simulator tests procedures but cannot certify the aircraft's wiring.

Boundary: Never claim safety certification from a small lab or a passing host test.

Worked example: A disconnected sensor and a reboot during an update require different recovery checks.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: C, Zephyr and a host compiler (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Embedded / IoT Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a board-specific test matrix with voltage, clock, memory and watchdog observations. Run only available authorized hardware cases and preserve logs; label remaining cases unexecuted.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

A disconnected sensor and a reboot during an update require different recovery checks. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a board-specific test matrix with voltage, clock, memory and watchdog observations. Run only available authorized hardware cases and preserve logs; label remaining cases unexecuted.

```
cc -Wall -Wextra sensor.c -o sensor
./sensor
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A clear boundary between simulated and measured device behavior.

Role workshop · debug and verify

Never claim safety certification from a small lab or a passing host test. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save hardware validation plan and measured evidence bundle. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A clear boundary between simulated and measured device behavior.

Expected: A clear boundary between simulated and measured device behavior.

Troubleshoot: The role exercise differs from the prediction: Never claim safety certification from a small lab or a passing host test.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: hardware validation plan and measured evidence bundle; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with hardware validation boundaries. Use the glossary below, then write your prediction for: A disconnected sensor and a reboot during an update require different recovery checks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Embedded / IoT Engineer role interview. Explain hardware validation boundaries using this case: A disconnected sensor and a reboot during an update require different recovery checks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate hardware validation boundaries to a system or workflow you know. Explain hardware validation boundaries using this case: A disconnected sensor and a reboot during an update require different recovery checks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Never claim safety certification from a small lab or a passing host test.

Interview: Explain hardware validation boundaries using this case: A disconnected sensor and a reboot during an update require different recovery checks. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A disconnected sensor and a reboot during an update require different recovery checks.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A clear boundary between simulated and measured device behavior.

Reference: A clear boundary between simulated and measured device behavior. — Host tests verify logic while real boards add electrical, timing and resource constraints. Use a hardware-in-the-loop plan with controlled fault injection and recovery expectations. A clear boundary between simulated and measured device behavior.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html
