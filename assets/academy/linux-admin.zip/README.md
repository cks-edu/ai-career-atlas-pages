# Linux Administrator

Software Engineering

Start with users, processes and permissions. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward backup script, restore proof and retention design.

## beginner

In a disposable folder run id, pwd, ls -l and ps for your own processes. Create a test file, change only its mode and describe owner/group/other bits.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Layered diagnosis
Check local process, address resolution, connection and application response separately.
Mental model: Follow a letter from address book to road to reception desk.
Limit: Layers interact; one successful check does not establish every other layer.
Example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path.
Recall: Why is a 404 different from connection refused?

### Users, processes and permissions
Linux separates user identity, process execution and file permissions. Read the actual owner and mode before changing access; broad writable permissions often hide the real ownership issue.
Mental model: A room has an owner, a lock and people currently working inside it.
Limit: Avoid chmod 777 as diagnosis; verify the required actor and operation first.
Example: A lab file with mode 600 is accessible to its owner but not arbitrary other users.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Avoid chmod 777 as diagnosis; verify the required actor and operation first.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A lab file with mode 600 is accessible to its owner but not arbitrary other users. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
In a disposable folder run id, pwd, ls -l and ps for your own processes. Create a test file, change only its mode and describe owner/group/other bits.
```
id
pwd
ls -l
ps -u "$(id -u)"
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A permission table tied to the observed user and file.

6. Role workshop · debug and verify
Avoid chmod 777 as diagnosis; verify the required actor and operation first. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save permissions worksheet and command transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A permission table tied to the observed user and file.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Users, processes and permissions: Avoid chmod 777 as diagnosis; verify the required actor and operation first.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: permissions worksheet and command transcript
A permission table tied to the observed user and file.

Interview: Work through this Linux Administrator case: A lab file with mode 600 is accessible to its owner but not arbitrary other users. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Linux separates user identity, process execution and file permissions. Read the actual owner and mode before changing access; broad writable permissions often hide the real ownership issue. Expected evidence: A permission table tied to the observed user and file. Diagnosis: Avoid chmod 777 as diagnosis; verify the required actor and operation first. State the limits of the mental model: A room has an owner, a lock and people currently working inside it.

Resume: Built permissions worksheet and command transcript using Linux, systemd and shell tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

On a disposable Linux VM inspect a sample service with systemctl status and journalctl -u. Create a lab unit for a harmless command, deliberately use a wrong path, inspect the error, repair and restart it.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Least privilege and change scope
Use only the rights required for the task and record exactly what you intend to change.
Mental model: Borrow a key to one room rather than the master key.
Limit: Permissions cannot replace backups or ownership of a change.
Example: Run the loopback diagnostic without changing DNS or firewall settings.
Recall: What information should a change ticket contain before modifying a network setting?

### systemd service diagnosis
A service can fail because of its executable, working directory, environment or permissions. Read unit configuration and logs before restarting repeatedly.
Mental model: A worker cannot do the job if the address, tools or instructions are wrong.
Limit: If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit.
Example: A nonexistent ExecStart path produces a different failure from an application returning an error.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A nonexistent ExecStart path produces a different failure from an application returning an error. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
On a disposable Linux VM inspect a sample service with systemctl status and journalctl -u. Create a lab unit for a harmless command, deliberately use a wrong path, inspect the error, repair and restart it.
```
systemctl status atlas-lab.service
journalctl -u atlas-lab.service --no-pager -n 30
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: The first failure is explained and the repaired unit becomes active or exits successfully according to its type.

6. Role workshop · debug and verify
If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save unit file and failure/recovery log. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The first failure is explained and the repaired unit becomes active or exits successfully according to its type.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
systemd service diagnosis: If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: unit file and failure/recovery log
The first failure is explained and the repaired unit becomes active or exits successfully according to its type.

Interview: Work through this Linux Administrator case: A nonexistent ExecStart path produces a different failure from an application returning an error. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A service can fail because of its executable, working directory, environment or permissions. Read unit configuration and logs before restarting repeatedly. Expected evidence: The first failure is explained and the repaired unit becomes active or exits successfully according to its type. Diagnosis: If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit. State the limits of the mental model: A worker cannot do the job if the address, tools or instructions are wrong.

Resume: Built unit file and failure/recovery log using Linux, systemd and shell tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Create synthetic files, record hashes and modes, archive the directory, restore into a new directory and compare. Include a missing-file case and a documented schedule/retention proposal.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Recovery evidence
A recovery is complete when the original user operation works and important side effects have been checked.
Mental model: Repair a tap, then test water flow and inspect for leaks.
Limit: One successful retry does not establish long-term reliability.
Example: After correcting a path, record HTTP status, timestamp and the user-visible result.
Recall: What would you record for the next person handling the incident?

### Backup and recovery boundaries
A file backup must preserve required metadata and be restored somewhere independent before replacing live data. Define the recovery target and what the backup excludes.
Mental model: A photocopy can preserve text while losing the filing labels and access restrictions.
Limit: A successful archive command does not prove a usable restore; test extraction and ownership assumptions.
Example: Restore a lab directory into a new path and compare checksums and permissions.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful archive command does not prove a usable restore; test extraction and ownership assumptions.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Restore a lab directory into a new path and compare checksums and permissions. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create synthetic files, record hashes and modes, archive the directory, restore into a new directory and compare. Include a missing-file case and a documented schedule/retention proposal.
```
tar -tf lab-backup.tar
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Restored contents and required metadata match; source remains untouched.

6. Role workshop · debug and verify
A successful archive command does not prove a usable restore; test extraction and ownership assumptions. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save backup script, restore proof and retention design. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Restored contents and required metadata match; source remains untouched.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Backup and recovery boundaries: A successful archive command does not prove a usable restore; test extraction and ownership assumptions.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: backup script, restore proof and retention design
Restored contents and required metadata match; source remains untouched.

Interview: Work through this Linux Administrator case: Restore a lab directory into a new path and compare checksums and permissions. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A file backup must preserve required metadata and be restored somewhere independent before replacing live data. Define the recovery target and what the backup excludes. Expected evidence: Restored contents and required metadata match; source remains untouched. Diagnosis: A successful archive command does not prove a usable restore; test extraction and ownership assumptions. State the limits of the mental model: A photocopy can preserve text while losing the filing labels and access restrictions.

Resume: Built backup script, restore proof and retention design using Linux, systemd and shell tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html
Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting
Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
