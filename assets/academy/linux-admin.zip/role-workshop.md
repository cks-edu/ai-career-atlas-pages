# Linux Administrator — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Users, processes and permissions

Linux separates user identity, process execution and file permissions. Read the actual owner and mode before changing access; broad writable permissions often hide the real ownership issue.
Mental model: A room has an owner, a lock and people currently working inside it.
Case: A lab file with mode 600 is accessible to its owner but not arbitrary other users.
Task: In a disposable folder run id, pwd, ls -l and ps for your own processes. Create a test file, change only its mode and describe owner/group/other bits.
Acceptance: A permission table tied to the observed user and file.
Troubleshooting: Avoid chmod 777 as diagnosis; verify the required actor and operation first.
Deliverable: permissions worksheet and command transcript

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
systemd service diagnosis

A service can fail because of its executable, working directory, environment or permissions. Read unit configuration and logs before restarting repeatedly.
Mental model: A worker cannot do the job if the address, tools or instructions are wrong.
Case: A nonexistent ExecStart path produces a different failure from an application returning an error.
Task: On a disposable Linux VM inspect a sample service with systemctl status and journalctl -u. Create a lab unit for a harmless command, deliberately use a wrong path, inspect the error, repair and restart it.
Acceptance: The first failure is explained and the repaired unit becomes active or exits successfully according to its type.
Troubleshooting: If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit.
Deliverable: unit file and failure/recovery log

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Backup and recovery boundaries

A file backup must preserve required metadata and be restored somewhere independent before replacing live data. Define the recovery target and what the backup excludes.
Mental model: A photocopy can preserve text while losing the filing labels and access restrictions.
Case: Restore a lab directory into a new path and compare checksums and permissions.
Task: Create synthetic files, record hashes and modes, archive the directory, restore into a new directory and compare. Include a missing-file case and a documented schedule/retention proposal.
Acceptance: Restored contents and required metadata match; source remains untouched.
Troubleshooting: A successful archive command does not prove a usable restore; test extraction and ownership assumptions.
Deliverable: backup script, restore proof and retention design

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
