# Linux Administrator — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Layered diagnosis: Check local process, address resolution, connection and application response separately.

Apply layered diagnosis in Linux Administrator: Use the concept to complete this role exercise: Inspect process, user and file ownership in a disposable environment

Users, processes and permissions: Linux separates user identity, process execution and file permissions. Read the actual owner and mode before changing access; broad writable permissions often hide the real ownership issue.

### Layered diagnosis

Check local process, address resolution, connection and application response separately. In this role, work through: A lab file with mode 600 is accessible to its owner but not arbitrary other users. The practical workshop develops this into: In a disposable folder run id, pwd, ls -l and ps for your own processes. Create a test file, change only its mode and describe owner/group/other bits.

Mental model: Follow a letter from address book to road to reception desk.

Boundary: Layers interact; one successful check does not establish every other layer.

Role application: A room has an owner, a lock and people currently working inside it.

Linux separates user identity, process execution and file permissions. Read the actual owner and mode before changing access; broad writable permissions often hide the real ownership issue.

Worked example: A lab file with mode 600 is accessible to its owner but not arbitrary other users.

Shared foundation example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Linux, systemd and shell tools (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Linux Administrator: A lab file with mode 600 is accessible to its owner but not arbitrary other users.

Predict the worked case

Read this case without running a tool: A lab file with mode 600 is accessible to its owner but not arbitrary other users. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in layered diagnosis.

Connect the concept to the role

Apply this rule: Check local process, address resolution, connection and application response separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Layers interact; one successful check does not establish every other layer.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies layered diagnosis to this case: A lab file with mode 600 is accessible to its owner but not arbitrary other users. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A lab file with mode 600 is accessible to its owner but not arbitrary other users. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Layered diagnosis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with layered diagnosis. Use the glossary below, then write your prediction for: A lab file with mode 600 is accessible to its owner but not arbitrary other users. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Linux Administrator role interview. Explain layered diagnosis using this case: A lab file with mode 600 is accessible to its owner but not arbitrary other users. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate layered diagnosis to a system or workflow you know. Explain layered diagnosis using this case: A lab file with mode 600 is accessible to its owner but not arbitrary other users. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is a 404 different from connection refused?

Interview: Explain layered diagnosis using this case: A lab file with mode 600 is accessible to its owner but not arbitrary other users. State the evidence, one alternative and where the mental model stops.

Quiz: After the Users, processes and permissions rehearsal, check this foundation: A request returns HTTP 500 rather than connection refused. Which next step best follows the evidence?

Inspect application and upstream error evidence for that request.

Assume DNS failed before any server response.

Immediately rewrite the local firewall policy.

Reference: Inspect application and upstream error evidence for that request. — An HTTP response points beyond the basic connection boundary; identify its origin before diagnosing the application.

Sources:

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Users, processes and permissions

Linux separates user identity, process execution and file permissions. Read the actual owner and mode before changing access; broad writable permissions often hide the real ownership issue. In this role, work through: A lab file with mode 600 is accessible to its owner but not arbitrary other users. The practical workshop develops this into: In a disposable folder run id, pwd, ls -l and ps for your own processes. Create a test file, change only its mode and describe owner/group/other bits.

Mental model: A room has an owner, a lock and people currently working inside it.

Boundary: Avoid chmod 777 as diagnosis; verify the required actor and operation first.

Worked example: A lab file with mode 600 is accessible to its owner but not arbitrary other users.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Linux, systemd and shell tools (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Linux Administrator workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

In a disposable folder run id, pwd, ls -l and ps for your own processes. Create a test file, change only its mode and describe owner/group/other bits.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A lab file with mode 600 is accessible to its owner but not arbitrary other users. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

In a disposable folder run id, pwd, ls -l and ps for your own processes. Create a test file, change only its mode and describe owner/group/other bits.

```
id
pwd
ls -l
ps -u "$(id -u)"
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A permission table tied to the observed user and file.

Role workshop · debug and verify

Avoid chmod 777 as diagnosis; verify the required actor and operation first. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save permissions worksheet and command transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A permission table tied to the observed user and file.

Expected: A permission table tied to the observed user and file.

Troubleshoot: The role exercise differs from the prediction: Avoid chmod 777 as diagnosis; verify the required actor and operation first.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: permissions worksheet and command transcript; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with users, processes and permissions. Use the glossary below, then write your prediction for: A lab file with mode 600 is accessible to its owner but not arbitrary other users. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Linux Administrator role interview. Explain users, processes and permissions using this case: A lab file with mode 600 is accessible to its owner but not arbitrary other users. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate users, processes and permissions to a system or workflow you know. Explain users, processes and permissions using this case: A lab file with mode 600 is accessible to its owner but not arbitrary other users. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Avoid chmod 777 as diagnosis; verify the required actor and operation first.

Interview: Explain users, processes and permissions using this case: A lab file with mode 600 is accessible to its owner but not arbitrary other users. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A lab file with mode 600 is accessible to its owner but not arbitrary other users.

A permission table tied to the observed user and file.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A permission table tied to the observed user and file. — Linux separates user identity, process execution and file permissions. Read the actual owner and mode before changing access; broad writable permissions often hide the real ownership issue. A permission table tied to the observed user and file.

Sources:

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Least privilege and change scope: Use only the rights required for the task and record exactly what you intend to change.

Apply least privilege and change scope in Linux Administrator: Use the concept to complete this role exercise: Trace a failed service with status and journal evidence

systemd service diagnosis: A service can fail because of its executable, working directory, environment or permissions. Read unit configuration and logs before restarting repeatedly.

### Least privilege and change scope

Use only the rights required for the task and record exactly what you intend to change. In this role, work through: A nonexistent ExecStart path produces a different failure from an application returning an error. The practical workshop develops this into: On a disposable Linux VM inspect a sample service with systemctl status and journalctl -u. Create a lab unit for a harmless command, deliberately use a wrong path, inspect the error, repair and restart it.

Mental model: Borrow a key to one room rather than the master key.

Boundary: Permissions cannot replace backups or ownership of a change.

Role application: A worker cannot do the job if the address, tools or instructions are wrong.

A service can fail because of its executable, working directory, environment or permissions. Read unit configuration and logs before restarting repeatedly.

Worked example: A nonexistent ExecStart path produces a different failure from an application returning an error.

Shared foundation example: Run the loopback diagnostic without changing DNS or firewall settings.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Linux, systemd and shell tools (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Linux Administrator: A nonexistent ExecStart path produces a different failure from an application returning an error.

Predict the worked case

Read this case without running a tool: A nonexistent ExecStart path produces a different failure from an application returning an error. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in least privilege and change scope.

Connect the concept to the role

Apply this rule: Use only the rights required for the task and record exactly what you intend to change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Permissions cannot replace backups or ownership of a change.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies least privilege and change scope to this case: A nonexistent ExecStart path produces a different failure from an application returning an error. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A nonexistent ExecStart path produces a different failure from an application returning an error. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Least privilege and change scope; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with least privilege and change scope. Use the glossary below, then write your prediction for: A nonexistent ExecStart path produces a different failure from an application returning an error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Linux Administrator role interview. Explain least privilege and change scope using this case: A nonexistent ExecStart path produces a different failure from an application returning an error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate least privilege and change scope to a system or workflow you know. Explain least privilege and change scope using this case: A nonexistent ExecStart path produces a different failure from an application returning an error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What information should a change ticket contain before modifying a network setting?

Interview: Explain least privilege and change scope using this case: A nonexistent ExecStart path produces a different failure from an application returning an error. State the evidence, one alternative and where the mental model stops.

Quiz: After the systemd service diagnosis rehearsal, check this foundation: A diagnostic only needs to read a local log. Which access is appropriate?

Permanent administrator rights for convenience.

The narrow read permission required for that log.

Write access to every service configuration.

Reference: The narrow read permission required for that log. — Match permissions to the task. Extra privileges add risk without evidence that they are required.

Sources:

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### systemd service diagnosis

A service can fail because of its executable, working directory, environment or permissions. Read unit configuration and logs before restarting repeatedly. In this role, work through: A nonexistent ExecStart path produces a different failure from an application returning an error. The practical workshop develops this into: On a disposable Linux VM inspect a sample service with systemctl status and journalctl -u. Create a lab unit for a harmless command, deliberately use a wrong path, inspect the error, repair and restart it.

Mental model: A worker cannot do the job if the address, tools or instructions are wrong.

Boundary: If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit.

Worked example: A nonexistent ExecStart path produces a different failure from an application returning an error.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Linux, systemd and shell tools (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Linux Administrator workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

On a disposable Linux VM inspect a sample service with systemctl status and journalctl -u. Create a lab unit for a harmless command, deliberately use a wrong path, inspect the error, repair and restart it.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A nonexistent ExecStart path produces a different failure from an application returning an error. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

On a disposable Linux VM inspect a sample service with systemctl status and journalctl -u. Create a lab unit for a harmless command, deliberately use a wrong path, inspect the error, repair and restart it.

```
systemctl status atlas-lab.service
journalctl -u atlas-lab.service --no-pager -n 30
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: The first failure is explained and the repaired unit becomes active or exits successfully according to its type.

Role workshop · debug and verify

If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save unit file and failure/recovery log. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The first failure is explained and the repaired unit becomes active or exits successfully according to its type.

Expected: The first failure is explained and the repaired unit becomes active or exits successfully according to its type.

Troubleshoot: The role exercise differs from the prediction: If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: unit file and failure/recovery log; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with systemd service diagnosis. Use the glossary below, then write your prediction for: A nonexistent ExecStart path produces a different failure from an application returning an error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Linux Administrator role interview. Explain systemd service diagnosis using this case: A nonexistent ExecStart path produces a different failure from an application returning an error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate systemd service diagnosis to a system or workflow you know. Explain systemd service diagnosis using this case: A nonexistent ExecStart path produces a different failure from an application returning an error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If systemd is unavailable in the environment, use a Linux VM; do not claim a macOS process check tested a unit.

Interview: Explain systemd service diagnosis using this case: A nonexistent ExecStart path produces a different failure from an application returning an error. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A nonexistent ExecStart path produces a different failure from an application returning an error.

Ignore the failing case and keep only the successful screenshot.

The first failure is explained and the repaired unit becomes active or exits successfully according to its type.

Treat any successful command as proof that all business and access rules passed.

Reference: The first failure is explained and the repaired unit becomes active or exits successfully according to its type. — A service can fail because of its executable, working directory, environment or permissions. Read unit configuration and logs before restarting repeatedly. The first failure is explained and the repaired unit becomes active or exits successfully according to its type.

Sources:

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Recovery evidence: A recovery is complete when the original user operation works and important side effects have been checked.

Apply recovery evidence in Linux Administrator: Use the concept to complete this role exercise: Write a backup verification and least-privilege change plan

Backup and recovery boundaries: A file backup must preserve required metadata and be restored somewhere independent before replacing live data. Define the recovery target and what the backup excludes.

### Recovery evidence

A recovery is complete when the original user operation works and important side effects have been checked. In this role, work through: Restore a lab directory into a new path and compare checksums and permissions. The practical workshop develops this into: Create synthetic files, record hashes and modes, archive the directory, restore into a new directory and compare. Include a missing-file case and a documented schedule/retention proposal.

Mental model: Repair a tap, then test water flow and inspect for leaks.

Boundary: One successful retry does not establish long-term reliability.

Role application: A photocopy can preserve text while losing the filing labels and access restrictions.

A file backup must preserve required metadata and be restored somewhere independent before replacing live data. Define the recovery target and what the backup excludes.

Worked example: Restore a lab directory into a new path and compare checksums and permissions.

Shared foundation example: After correcting a path, record HTTP status, timestamp and the user-visible result.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Linux, systemd and shell tools (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Linux Administrator: Restore a lab directory into a new path and compare checksums and permissions.

Predict the worked case

Read this case without running a tool: Restore a lab directory into a new path and compare checksums and permissions. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in recovery evidence.

Connect the concept to the role

Apply this rule: A recovery is complete when the original user operation works and important side effects have been checked. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: One successful retry does not establish long-term reliability.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies recovery evidence to this case: Restore a lab directory into a new path and compare checksums and permissions. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Restore a lab directory into a new path and compare checksums and permissions. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Recovery evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with recovery evidence. Use the glossary below, then write your prediction for: Restore a lab directory into a new path and compare checksums and permissions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Linux Administrator role interview. Explain recovery evidence using this case: Restore a lab directory into a new path and compare checksums and permissions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate recovery evidence to a system or workflow you know. Explain recovery evidence using this case: Restore a lab directory into a new path and compare checksums and permissions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would you record for the next person handling the incident?

Interview: Explain recovery evidence using this case: Restore a lab directory into a new path and compare checksums and permissions. State the evidence, one alternative and where the mental model stops.

Quiz: After the Backup and recovery boundaries rehearsal, check this foundation: A repair command succeeds after an outage. Which check most directly tests recovery?

Confirm that a process exists.

Confirm the runbook file was opened.

Repeat the original user operation and inspect important side effects.

Reference: Repeat the original user operation and inspect important side effects. — Recovery must be measured at the affected operation, not inferred solely from a successful repair command.

Sources:

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Backup and recovery boundaries

A file backup must preserve required metadata and be restored somewhere independent before replacing live data. Define the recovery target and what the backup excludes. In this role, work through: Restore a lab directory into a new path and compare checksums and permissions. The practical workshop develops this into: Create synthetic files, record hashes and modes, archive the directory, restore into a new directory and compare. Include a missing-file case and a documented schedule/retention proposal.

Mental model: A photocopy can preserve text while losing the filing labels and access restrictions.

Boundary: A successful archive command does not prove a usable restore; test extraction and ownership assumptions.

Worked example: Restore a lab directory into a new path and compare checksums and permissions.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Linux, systemd and shell tools (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Linux Administrator workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create synthetic files, record hashes and modes, archive the directory, restore into a new directory and compare. Include a missing-file case and a documented schedule/retention proposal.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Restore a lab directory into a new path and compare checksums and permissions. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create synthetic files, record hashes and modes, archive the directory, restore into a new directory and compare. Include a missing-file case and a documented schedule/retention proposal.

```
tar -tf lab-backup.tar
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Restored contents and required metadata match; source remains untouched.

Role workshop · debug and verify

A successful archive command does not prove a usable restore; test extraction and ownership assumptions. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save backup script, restore proof and retention design. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Restored contents and required metadata match; source remains untouched.

Expected: Restored contents and required metadata match; source remains untouched.

Troubleshoot: The role exercise differs from the prediction: A successful archive command does not prove a usable restore; test extraction and ownership assumptions.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: backup script, restore proof and retention design; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with backup and recovery boundaries. Use the glossary below, then write your prediction for: Restore a lab directory into a new path and compare checksums and permissions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Linux Administrator role interview. Explain backup and recovery boundaries using this case: Restore a lab directory into a new path and compare checksums and permissions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate backup and recovery boundaries to a system or workflow you know. Explain backup and recovery boundaries using this case: Restore a lab directory into a new path and compare checksums and permissions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful archive command does not prove a usable restore; test extraction and ownership assumptions.

Interview: Explain backup and recovery boundaries using this case: Restore a lab directory into a new path and compare checksums and permissions. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Restore a lab directory into a new path and compare checksums and permissions.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Restored contents and required metadata match; source remains untouched.

Reference: Restored contents and required metadata match; source remains untouched. — A file backup must preserve required metadata and be restored somewhere independent before replacing live data. Define the recovery target and what the backup excludes. Restored contents and required metadata match; source remains untouched.

Sources:

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
