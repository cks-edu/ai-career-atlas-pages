# Build / Release Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Desired state: A controller compares the current system with a declared target and works to reconcile the difference.

Apply desired state in Build / Release Engineer: Use the concept to complete this role exercise: Define an isolated build with a versioned artifact

Release identity and manifests: A release is a set of versioned artifacts and configuration, not only a branch name. Record exact revisions and dependencies so a release can be reproduced and audited.

### Desired state

A controller compares the current system with a declared target and works to reconcile the difference. In this role, work through: A tested application digest and a migration version must appear in the same release record. The practical workshop develops this into: Create a manifest for the local app with source revision, artifact hash, configuration keys and test evidence. Rebuild and compare what changed. Explain any hash difference and whether the inputs were actually identical.

Mental model: A thermostat compares actual temperature with the set point.

Boundary: It cannot fix every cause: a missing image or insufficient resources still needs action.

Role application: A shipping manifest names every parcel and its serial number.

A release is a set of versioned artifacts and configuration, not only a branch name. Record exact revisions and dependencies so a release can be reproduced and audited.

Worked example: A tested application digest and a migration version must appear in the same release record.

Shared foundation example: One replica means the controller tries to keep one Pod running.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: GitHub Actions, artifact registries and containers (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Build / Release Engineer: A tested application digest and a migration version must appear in the same release record.

Predict the worked case

Read this case without running a tool: A tested application digest and a migration version must appear in the same release record. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in desired state.

Connect the concept to the role

Apply this rule: A controller compares the current system with a declared target and works to reconcile the difference. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: It cannot fix every cause: a missing image or insufficient resources still needs action.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies desired state to this case: A tested application digest and a migration version must appear in the same release record. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A tested application digest and a migration version must appear in the same release record. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Desired state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with desired state. Use the glossary below, then write your prediction for: A tested application digest and a migration version must appear in the same release record. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Build / Release Engineer role interview. Explain desired state using this case: A tested application digest and a migration version must appear in the same release record. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate desired state to a system or workflow you know. Explain desired state using this case: A tested application digest and a migration version must appear in the same release record. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens when a Pod is deleted but its Deployment remains?

Interview: Explain desired state using this case: A tested application digest and a migration version must appear in the same release record. State the evidence, one alternative and where the mental model stops.

Quiz: After the Release identity and manifests rehearsal, check this foundation: A controller is told to run two replicas, but only one is ready. What does the declared target mean?

The controller attempts reconciliation; it is not a guarantee that both are healthy now.

Two healthy replicas must already exist.

The current replica count becomes the new desired target automatically.

Reference: The controller attempts reconciliation; it is not a guarantee that both are healthy now. — Desired and observed state differ during convergence or failure. Inspect readiness, events and constraints.

Sources:

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Release identity and manifests

A release is a set of versioned artifacts and configuration, not only a branch name. Record exact revisions and dependencies so a release can be reproduced and audited. In this role, work through: A tested application digest and a migration version must appear in the same release record. The practical workshop develops this into: Create a manifest for the local app with source revision, artifact hash, configuration keys and test evidence. Rebuild and compare what changed. Explain any hash difference and whether the inputs were actually identical.

Mental model: A shipping manifest names every parcel and its serial number.

Boundary: A mutable tag cannot prove which bytes were released.

Worked example: A tested application digest and a migration version must appear in the same release record.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: GitHub Actions, artifact registries and containers (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Build / Release Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a manifest for the local app with source revision, artifact hash, configuration keys and test evidence. Rebuild and compare what changed. Explain any hash difference and whether the inputs were actually identical.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

A tested application digest and a migration version must appear in the same release record. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a manifest for the local app with source revision, artifact hash, configuration keys and test evidence. Rebuild and compare what changed. Explain any hash difference and whether the inputs were actually identical.

Expected: A traceable release identity with no secrets in the manifest.

Role workshop · debug and verify

A mutable tag cannot prove which bytes were released. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save release-manifest.json and build evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A traceable release identity with no secrets in the manifest.

Expected: A traceable release identity with no secrets in the manifest.

Troubleshoot: The role exercise differs from the prediction: A mutable tag cannot prove which bytes were released.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-beginner-2.md: release-manifest.json and build evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with release identity and manifests. Use the glossary below, then write your prediction for: A tested application digest and a migration version must appear in the same release record. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Build / Release Engineer role interview. Explain release identity and manifests using this case: A tested application digest and a migration version must appear in the same release record. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate release identity and manifests to a system or workflow you know. Explain release identity and manifests using this case: A tested application digest and a migration version must appear in the same release record. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A mutable tag cannot prove which bytes were released.

Interview: Explain release identity and manifests using this case: A tested application digest and a migration version must appear in the same release record. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A tested application digest and a migration version must appear in the same release record.

A traceable release identity with no secrets in the manifest.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A traceable release identity with no secrets in the manifest. — A release is a set of versioned artifacts and configuration, not only a branch name. Record exact revisions and dependencies so a release can be reproduced and audited. A traceable release identity with no secrets in the manifest.

Sources:

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Readiness and routing: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.

Apply readiness and routing in Build / Release Engineer: Use the concept to complete this role exercise: Separate test, package, approval and deploy stages

Promotion and environment parity: Promote the tested artifact while reviewing environment differences separately. Credentials, endpoints and feature flags can change behavior without changing code.

### Readiness and routing

Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. In this role, work through: A staging artifact pointed at the wrong database is not a safe production release. The practical workshop develops this into: Create test/release configuration fixtures and a diff allowlist. Flag unexpected endpoint or privilege differences and make the promotion checklist block unresolved items.

Mental model: A shop can have lights on but still be closed to customers.

Boundary: A health endpoint can be too shallow; it must reflect the service contract.

Role application: The same machine behaves differently when connected to different utilities.

Promote the tested artifact while reviewing environment differences separately. Credentials, endpoints and feature flags can change behavior without changing code.

Worked example: A staging artifact pointed at the wrong database is not a safe production release.

Shared foundation example: This container listens on 8080; the Service accepts 80 and forwards to 8080.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: GitHub Actions, artifact registries and containers (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Build / Release Engineer: A staging artifact pointed at the wrong database is not a safe production release.

Predict the worked case

Read this case without running a tool: A staging artifact pointed at the wrong database is not a safe production release. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in readiness and routing.

Connect the concept to the role

Apply this rule: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A health endpoint can be too shallow; it must reflect the service contract.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies readiness and routing to this case: A staging artifact pointed at the wrong database is not a safe production release. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A staging artifact pointed at the wrong database is not a safe production release. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Readiness and routing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with readiness and routing. Use the glossary below, then write your prediction for: A staging artifact pointed at the wrong database is not a safe production release. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Build / Release Engineer role interview. Explain readiness and routing using this case: A staging artifact pointed at the wrong database is not a safe production release. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate readiness and routing to a system or workflow you know. Explain readiness and routing using this case: A staging artifact pointed at the wrong database is not a safe production release. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain why a Running Pod might still receive no traffic.

Interview: Explain readiness and routing using this case: A staging artifact pointed at the wrong database is not a safe production release. State the evidence, one alternative and where the mental model stops.

Quiz: After the Promotion and environment parity rehearsal, check this foundation: A process listens on 8080. A Service accepts 80. Which target port should route to that listener?

80 because the Service port must equal the application port.

8080, matching the actual application listener.

443 because readiness always implies TLS.

Reference: 8080, matching the actual application listener. — Service and target ports can differ. Readiness must also reflect whether the workload can serve traffic.

Sources:

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Promotion and environment parity

Promote the tested artifact while reviewing environment differences separately. Credentials, endpoints and feature flags can change behavior without changing code. In this role, work through: A staging artifact pointed at the wrong database is not a safe production release. The practical workshop develops this into: Create test/release configuration fixtures and a diff allowlist. Flag unexpected endpoint or privilege differences and make the promotion checklist block unresolved items.

Mental model: The same machine behaves differently when connected to different utilities.

Boundary: Copying an entire environment file can expose credentials and wrong endpoints; compare keys and ownership instead.

Worked example: A staging artifact pointed at the wrong database is not a safe production release.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: GitHub Actions, artifact registries and containers (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Build / Release Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create test/release configuration fixtures and a diff allowlist. Flag unexpected endpoint or privilege differences and make the promotion checklist block unresolved items.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

A staging artifact pointed at the wrong database is not a safe production release. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create test/release configuration fixtures and a diff allowlist. Flag unexpected endpoint or privilege differences and make the promotion checklist block unresolved items.

Expected: Only justified differences pass review.

Role workshop · debug and verify

Copying an entire environment file can expose credentials and wrong endpoints; compare keys and ownership instead. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save promotion gate and configuration review. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Only justified differences pass review.

Expected: Only justified differences pass review.

Troubleshoot: The role exercise differs from the prediction: Copying an entire environment file can expose credentials and wrong endpoints; compare keys and ownership instead.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-intermediate-2.md: promotion gate and configuration review; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with promotion and environment parity. Use the glossary below, then write your prediction for: A staging artifact pointed at the wrong database is not a safe production release. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Build / Release Engineer role interview. Explain promotion and environment parity using this case: A staging artifact pointed at the wrong database is not a safe production release. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate promotion and environment parity to a system or workflow you know. Explain promotion and environment parity using this case: A staging artifact pointed at the wrong database is not a safe production release. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Copying an entire environment file can expose credentials and wrong endpoints; compare keys and ownership instead.

Interview: Explain promotion and environment parity using this case: A staging artifact pointed at the wrong database is not a safe production release. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A staging artifact pointed at the wrong database is not a safe production release.

Ignore the failing case and keep only the successful screenshot.

Only justified differences pass review.

Treat any successful command as proof that all business and access rules passed.

Reference: Only justified differences pass review. — Promote the tested artifact while reviewing environment differences separately. Credentials, endpoints and feature flags can change behavior without changing code. Only justified differences pass review.

Sources:

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Rollback and service objectives: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.

Apply rollback and service objectives in Build / Release Engineer: Use the concept to complete this role exercise: Design provenance checks, rollback and compromised-runner recovery

Rollback and forward-fix decisions: Rollback is appropriate only when the previous artifact remains compatible with current data and external effects. Otherwise a forward fix may be safer.

### Rollback and service objectives

A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. In this role, work through: A destructive schema migration can make the old application unable to start. The practical workshop develops this into: Rehearse the bad-image local rollout, then analyze a separate incompatible-schema scenario. Write decision criteria, approval owner, verification and communication steps for each.

Mental model: A reversible road detour with traffic counters at both ends.

Boundary: A rollback may not undo database changes; release safety includes schema compatibility.

Role application: Reversing a vehicle does not undo cargo already unloaded.

Rollback is appropriate only when the previous artifact remains compatible with current data and external effects. Otherwise a forward fix may be safer.

Worked example: A destructive schema migration can make the old application unable to start.

Shared foundation example: Change the image to a nonexistent tag, inspect events and undo the rollout.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: GitHub Actions, artifact registries and containers (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Build / Release Engineer: A destructive schema migration can make the old application unable to start.

Predict the worked case

Read this case without running a tool: A destructive schema migration can make the old application unable to start. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in rollback and service objectives.

Connect the concept to the role

Apply this rule: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A rollback may not undo database changes; release safety includes schema compatibility.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies rollback and service objectives to this case: A destructive schema migration can make the old application unable to start. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A destructive schema migration can make the old application unable to start. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Rollback and service objectives; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rollback and service objectives. Use the glossary below, then write your prediction for: A destructive schema migration can make the old application unable to start. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Build / Release Engineer role interview. Explain rollback and service objectives using this case: A destructive schema migration can make the old application unable to start. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rollback and service objectives to a system or workflow you know. Explain rollback and service objectives using this case: A destructive schema migration can make the old application unable to start. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks must pass after undoing a bad image?

Interview: Explain rollback and service objectives using this case: A destructive schema migration can make the old application unable to start. State the evidence, one alternative and where the mental model stops.

Quiz: After the Rollback and forward-fix decisions rehearsal, check this foundation: A rollout undo completes. What additional evidence establishes user recovery?

The deployment command exited zero, so no more checks are needed.

The old image tag exists in the registry.

A representative user operation succeeds and dependent state remains compatible.

Reference: A representative user operation succeeds and dependent state remains compatible. — Control-plane convergence does not verify the business path or reverse external state changes.

Sources:

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Rollback and forward-fix decisions

Rollback is appropriate only when the previous artifact remains compatible with current data and external effects. Otherwise a forward fix may be safer. In this role, work through: A destructive schema migration can make the old application unable to start. The practical workshop develops this into: Rehearse the bad-image local rollout, then analyze a separate incompatible-schema scenario. Write decision criteria, approval owner, verification and communication steps for each.

Mental model: Reversing a vehicle does not undo cargo already unloaded.

Boundary: Do not label an application undo as complete recovery until the user operation and data are verified.

Worked example: A destructive schema migration can make the old application unable to start.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: GitHub Actions, artifact registries and containers (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Build / Release Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Rehearse the bad-image local rollout, then analyze a separate incompatible-schema scenario. Write decision criteria, approval owner, verification and communication steps for each.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Rehearse a failed release

Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

Role workshop · predict

A destructive schema migration can make the old application unable to start. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Rehearse the bad-image local rollout, then analyze a separate incompatible-schema scenario. Write decision criteria, approval owner, verification and communication steps for each.

Expected: A tested code rollback and a distinct data recovery plan.

Role workshop · debug and verify

Do not label an application undo as complete recovery until the user operation and data are verified. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save release incident runbook and decision table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A tested code rollback and a distinct data recovery plan.

Expected: A tested code rollback and a distinct data recovery plan.

Troubleshoot: The role exercise differs from the prediction: Do not label an application undo as complete recovery until the user operation and data are verified.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-advanced-2.md: release incident runbook and decision table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rollback and forward-fix decisions. Use the glossary below, then write your prediction for: A destructive schema migration can make the old application unable to start. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Build / Release Engineer role interview. Explain rollback and forward-fix decisions using this case: A destructive schema migration can make the old application unable to start. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rollback and forward-fix decisions to a system or workflow you know. Explain rollback and forward-fix decisions using this case: A destructive schema migration can make the old application unable to start. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not label an application undo as complete recovery until the user operation and data are verified.

Interview: Explain rollback and forward-fix decisions using this case: A destructive schema migration can make the old application unable to start. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A destructive schema migration can make the old application unable to start.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A tested code rollback and a distinct data recovery plan.

Reference: A tested code rollback and a distinct data recovery plan. — Rollback is appropriate only when the previous artifact remains compatible with current data and external effects. Otherwise a forward fix may be safer. A tested code rollback and a distinct data recovery plan.

Sources:

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/
