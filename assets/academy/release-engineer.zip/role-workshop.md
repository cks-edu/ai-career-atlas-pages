# Build / Release Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Release identity and manifests

A release is a set of versioned artifacts and configuration, not only a branch name. Record exact revisions and dependencies so a release can be reproduced and audited.
Mental model: A shipping manifest names every parcel and its serial number.
Case: A tested application digest and a migration version must appear in the same release record.
Task: Create a manifest for the local app with source revision, artifact hash, configuration keys and test evidence. Rebuild and compare what changed. Explain any hash difference and whether the inputs were actually identical.
Acceptance: A traceable release identity with no secrets in the manifest.
Troubleshooting: A mutable tag cannot prove which bytes were released.
Deliverable: release-manifest.json and build evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Promotion and environment parity

Promote the tested artifact while reviewing environment differences separately. Credentials, endpoints and feature flags can change behavior without changing code.
Mental model: The same machine behaves differently when connected to different utilities.
Case: A staging artifact pointed at the wrong database is not a safe production release.
Task: Create test/release configuration fixtures and a diff allowlist. Flag unexpected endpoint or privilege differences and make the promotion checklist block unresolved items.
Acceptance: Only justified differences pass review.
Troubleshooting: Copying an entire environment file can expose credentials and wrong endpoints; compare keys and ownership instead.
Deliverable: promotion gate and configuration review

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Rollback and forward-fix decisions

Rollback is appropriate only when the previous artifact remains compatible with current data and external effects. Otherwise a forward fix may be safer.
Mental model: Reversing a vehicle does not undo cargo already unloaded.
Case: A destructive schema migration can make the old application unable to start.
Task: Rehearse the bad-image local rollout, then analyze a separate incompatible-schema scenario. Write decision criteria, approval owner, verification and communication steps for each.
Acceptance: A tested code rollback and a distinct data recovery plan.
Troubleshooting: Do not label an application undo as complete recovery until the user operation and data are verified.
Deliverable: release incident runbook and decision table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
