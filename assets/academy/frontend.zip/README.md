# Complete frontend course practice pack

Start in **course-labs/README.md** for the new beginner-to-advanced course. Browser foundations use course-labs/web; the typed React project uses course-labs/react-app. Numbered offline lessons are in course-labs/lessons and numbered-lessons.md. No paid account is needed for the local reference labs.

The original applied workshops below remain available for review. Their commands and files are separate from the new course-labs folders.

---

# Frontend Developer

Software Engineering

Start with semantic forms and feedback. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward dom-security.md with before/after DOM evidence and an automated assertion.

## beginner

Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Request and response
A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.
Mental model: A service counter: the request is your order and the response is the result.
Limit: Networks can time out; sending an order does not prove it was fulfilled.
Example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.
Recall: Draw the request and response for adding one task.

### Semantic forms and feedback
HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails.
Mental model: A form is a conversation: name the question, accept the reply, then acknowledge it.
Limit: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.
Example: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.
```
node app.mjs
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

6. Role workshop · debug and verify
If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save form-audit.md with HTML diff, keyboard sequence and two observed outcomes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Semantic forms and feedback: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: form-audit.md with HTML diff, keyboard sequence and two observed outcomes
Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Interview: Work through this Frontend Developer case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails. Expected evidence: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse. Diagnosis: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree. State the limits of the mental model: A form is a conversation: name the question, accept the reply, then acknowledge it.

Resume: Built form-audit.md with HTML diff, keyboard sequence and two observed outcomes using Browser DevTools and HTML/CSS/JavaScript; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Validation at a boundary
Check input before storing or using it. Client checks help people; the server must also enforce the rule.
Mental model: A gate with a checklist before a parcel enters a warehouse.
Limit: Valid input can still be unauthorized; validation is not access control.
Example: A blank title receives 400 and does not change task count.
Recall: Why must the server reject invalid input even if the form already checks it?

### Rendering server state
The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch.
Mental model: A receipt confirms a purchase; clicking Buy is only an attempt.
Limit: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.
Example: A 400 response displays the server error without adding a phantom task.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A 400 response displays the server error without adding a phantom task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.
```
node app.mjs test intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: No extra list item after failure; a recoverable message; the button works after recovery.

6. Role workshop · debug and verify
A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save ui-states.md and a four-state screenshot set. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: No extra list item after failure; a recoverable message; the button works after recovery.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Rendering server state: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: ui-states.md and a four-state screenshot set
No extra list item after failure; a recoverable message; the button works after recovery.

Interview: Work through this Frontend Developer case: A 400 response displays the server error without adding a phantom task. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch. Expected evidence: No extra list item after failure; a recoverable message; the button works after recovery. Diagnosis: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures. State the limits of the mental model: A receipt confirms a purchase; clicking Buy is only an attempt.

Resume: Built ui-states.md and a four-state screenshot set using Browser DevTools and HTML/CSS/JavaScript; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State and recovery
State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.
Mental model: A whiteboard versus a saved notebook.
Limit: A database also fails; persistence needs backups and tested recovery.
Example: Restart this lab server: the task list becomes empty. Explain why before adding a database.
Recall: Name two things required before calling this service production ready.

### Safe DOM updates
Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item.
Mental model: A display case shows a label; it does not execute the instructions printed on that label.
Limit: If markup becomes elements, trace every insertion sink rather than only escaping one test string.
Example: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If markup becomes elements, trace every insertion sink rather than only escaping one test string.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.
```
node app.mjs test advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Two text items with stable IDs; no img element created from the title; no lost input focus.

6. Role workshop · debug and verify
If markup becomes elements, trace every insertion sink rather than only escaping one test string. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save dom-security.md with before/after DOM evidence and an automated assertion. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Two text items with stable IDs; no img element created from the title; no lost input focus.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Safe DOM updates: If markup becomes elements, trace every insertion sink rather than only escaping one test string.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: dom-security.md with before/after DOM evidence and an automated assertion
Two text items with stable IDs; no img element created from the title; no lost input focus.

Interview: Work through this Frontend Developer case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item. Expected evidence: Two text items with stable IDs; no img element created from the title; no lost input focus. Diagnosis: If markup becomes elements, trace every insertion sink rather than only escaping one test string. State the limits of the mental model: A display case shows a label; it does not execute the instructions printed on that label.

Resume: Built dom-security.md with before/after DOM evidence and an automated assertion using Browser DevTools and HTML/CSS/JavaScript; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
