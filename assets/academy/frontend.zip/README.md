# Frontend Developer

Software Engineering

Begin with request and response. Build a labeled task form navigable with Tab. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Build a labeled task form navigable with Tab

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference.

### Request and response
A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.
Mental model: A service counter: the request is your order and the response is the result.
Limit: Networks can time out; sending an order does not prove it was fulfilled.
Example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.
Recall: Draw the request and response for adding one task.

### Apply request and response in Frontend Developer
Use the concept to complete this role exercise: Build a labeled task form navigable with Tab
Mental model: A service counter: the request is your order and the response is the result.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Apply the role exercise
Build a labeled task form navigable with Tab
Expected: Save a changed artifact and an evidence table; a command passing alone does not complete this step.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: frontend-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Build a labeled task form navigable with Tab? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. For this role, explicitly address: Build a labeled task form navigable with Tab.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Show loading, empty and error states without losing typed input

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference.

### Validation at a boundary
Check input before storing or using it. Client checks help people; the server must also enforce the rule.
Mental model: A gate with a checklist before a parcel enters a warehouse.
Limit: Valid input can still be unauthorized; validation is not access control.
Example: A blank title receives 400 and does not change task count.
Recall: Why must the server reject invalid input even if the form already checks it?

### Apply validation at a boundary in Frontend Developer
Use the concept to complete this role exercise: Show loading, empty and error states without losing typed input
Mental model: A gate with a checklist before a parcel enters a warehouse.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: A blank title receives 400 and does not change task count. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Apply the role exercise
Show loading, empty and error states without losing typed input
Expected: Save a changed artifact and an evidence table; a command passing alone does not complete this step.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: frontend-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Show loading, empty and error states without losing typed input? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Check input before storing or using it. Client checks help people; the server must also enforce the rule. For this role, explicitly address: Show loading, empty and error states without losing typed input.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Audit keyboard focus, slow responses and repeated submission

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference.

### State and recovery
State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.
Mental model: A whiteboard versus a saved notebook.
Limit: A database also fails; persistence needs backups and tested recovery.
Example: Restart this lab server: the task list becomes empty. Explain why before adding a database.
Recall: Name two things required before calling this service production ready.

### Apply state and recovery in Frontend Developer
Use the concept to complete this role exercise: Audit keyboard focus, slow responses and repeated submission
Mental model: A whiteboard versus a saved notebook.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Restart this lab server: the task list becomes empty. Explain why before adding a database. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Apply the role exercise
Audit keyboard focus, slow responses and repeated submission
Expected: Save a changed artifact and an evidence table; a command passing alone does not complete this step.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: frontend-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Audit keyboard focus, slow responses and repeated submission? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. For this role, explicitly address: Audit keyboard focus, slow responses and repeated submission.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
