# Frontend Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Request and response: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.

Apply request and response in Frontend Developer: Use the concept to complete this role exercise: Build a labeled task form navigable with Tab

Semantic forms and feedback: HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails.

### HTML, CSS & JavaScript basics

Original topic: Semantic forms and feedback

HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails. In this role, work through: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. The practical workshop develops this into: Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.

Mental model: A form is a conversation: name the question, accept the reply, then acknowledge it.

Boundary: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.

Subtopic: HTML gives content a structure

An element has a meaning and may contain text or other elements. A tag such as <h1> opens an element; </h1> closes it. Use a heading for a heading and a button for an action. Begin in core/index.html in the downloaded pack; it runs in a browser without installation.

Picture it: The outline of a document, before its visual design.

```
<main>
  <h1>My study tasks</h1>
  <p>Add one small task below.</p>
</main>
```

Try: Open core/index.html. Change the heading and add a paragraph inside main. Reload the page.

Expected: Both changes appear; the heading remains the page’s main heading.

Quick check: Why use h1 instead of a large styled paragraph?

Reasoning: It expresses heading structure, independently of its appearance.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

Subtopic: Labels connect a question to an input

The label’s for value must match the input’s id. Clicking the label then targets its control. A placeholder is not a replacement for a persistent label.

Picture it: A name tag attached to the right control.

```
<label for="task">Task title</label>
<input id="task" name="title">
<button type="submit">Add task</button>
```

Try: In core/index.html, click Task title, then use Tab to reach Add task. Temporarily change for="task" to for="missing" and compare. Restore it.

Expected: The matching label focuses the input. The mismatched label loses that association.

Quick check: Which attribute joins the label to its input?

Reasoning: The label’s for points to the input’s id.

Reference: https://www.w3.org/WAI/tutorials/forms/labels/

Subtopic: CSS controls space: the box model

A box has content, padding, border and margin. With border-box, a declared width includes padding and border. Margin remains outside. In the example, input selects elements and the braces contain property: value declarations.

Picture it: A parcel: contents, inner cushioning, wrapping and space around it.

```
input {
  box-sizing: border-box;
  width: 100%;
  padding: 12px;
  border: 1px solid #aab8c5;
}
form { max-width: 360px; }
```

Try: Use browser DevTools to change input padding from 12px to 24px. Compare border-box with content-box.

Expected: Border-box keeps the declared outer border width; content-box adds padding and border beyond the content width.

Quick check: Is margin included in border-box width?

Reasoning: No. Margin is outside the border.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model

Subtopic: JavaScript handles the form event

Listen for submit on the form. Prevent the default navigation, trim the input, then update a status message. Load this script after the form exists. Here const names a value, trim() removes surrounding spaces, and the handler function runs when submission occurs.

Picture it: An event is a signal; the handler decides how to respond.

```
form.addEventListener("submit", event => {
  event.preventDefault();
  const title = input.value.trim();
  status.textContent = title ? `Added: ${title}` : "Enter a task title.";
});
```

Try: Read the existing handler in core/index.html. Submit spaces, then Read docs. Change the success message and repeat.

Expected: Spaces show an error; a nonempty title gives feedback without reloading the page.

Quick check: Why listen for submit rather than only a button click?

Reasoning: Submit handles form submission, including keyboard activation.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events

Subtopic: Make the layout work on a small screen

Use flexible widths and a viewport meta tag. A media query can change layout when space is limited. Test the content at narrow widths instead of assuming a phone model.

Picture it: The same content rearranged to fit a smaller desk.

```
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  main { max-width: 640px; margin: auto; padding: 20px; }
  input { width: 100%; box-sizing: border-box; }
</style>
```

Try: Resize core/index.html to about 320px wide using responsive browser tools. Increase the title length and check again.

Expected: The input fits its container and text wraps without horizontal page scrolling.

Quick check: Does a viewport tag alone make every fixed-width layout responsive?

Reasoning: No. Layout sizes and content must also adapt.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

Worked example: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Frontend Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.

```
node app.mjs
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Role workshop · debug and verify

If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save form-audit.md with HTML diff, keyboard sequence and two observed outcomes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Expected: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Troubleshoot: The role exercise differs from the prediction: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: form-audit.md with HTML diff, keyboard sequence and two observed outcomes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with semantic forms and feedback. Use the glossary below, then write your prediction for: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain semantic forms and feedback using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate semantic forms and feedback to a system or workflow you know. Explain semantic forms and feedback using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.

Interview: Explain semantic forms and feedback using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.

Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse. — HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails. Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: HTML gives content a structure: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

Frontend reference: Labels connect a question to an input: https://www.w3.org/WAI/tutorials/forms/labels/

Frontend reference: CSS controls space: the box model: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model

Frontend reference: JavaScript handles the form event: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events

Frontend reference: Make the layout work on a small screen: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

### Request and response

A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. In this role, work through: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. The practical workshop develops this into: Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.

Mental model: A service counter: the request is your order and the response is the result.

Boundary: Networks can time out; sending an order does not prove it was fulfilled.

Role application: A form is a conversation: name the question, accept the reply, then acknowledge it.

HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails.

Subtopic: A request has a method and a target

The browser asks for a resource. GET usually reads; POST sends data for processing. A URL identifies the target. A request may also have headers and a body.

Picture it: Address + action + optional contents on an envelope.

```
GET /api/tasks HTTP/1.1
Host: localhost

# A separate request to add a task:
POST /api/tasks HTTP/1.1
Content-Type: application/json

{"title":"Read docs"}
```

Try: Draw the two messages. Underline each method and target. Label the JSON as the body, not part of the URL. These are message examples, not terminal commands.

Expected: GET and POST share a target but ask for different actions.

Quick check: Does the URL alone describe the entire request?

Reasoning: No. The method, headers and any body also affect its meaning.

Reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

Subtopic: A response is evidence, not a guarantee

A response includes a status and content. A 404 is an HTTP response: some HTTP component answered. A timeout gives no HTTP status and leaves the operation outcome uncertain.

Picture it: A written reply differs from hearing nothing back.

```
HTTP/1.1 404 Not Found
Content-Type: application/json

{"error":"Unknown route"}
```

Try: Compare this reply with a request that times out. Write what you know and what remains unknown in each case.

Expected: 404: investigate the route or responding component. Timeout: investigate transport and whether the operation happened.

Quick check: Does a timeout prove that nothing was created?

Reasoning: No. The server may have processed the request before the response was lost.

Reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status

Worked example: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.

Shared foundation example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Frontend Developer: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.

Predict the worked case

Read this case without running a tool: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in request and response.

Connect the concept to the role

Apply this rule: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Networks can time out; sending an order does not prove it was fulfilled.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies request and response to this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Request and response; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with request and response. Use the glossary below, then write your prediction for: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain request and response using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate request and response to a system or workflow you know. Explain request and response using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Draw the request and response for adding one task.

Interview: Explain request and response using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops.

Quiz: After the Semantic forms and feedback rehearsal, check this foundation: A request returns HTTP 404. Which boundary has evidence of working?

An HTTP server returned a response; inspect the route next.

The request never reached any HTTP server.

The server has confirmed that the resource exists.

Reference: An HTTP server returned a response; inspect the route next. — 404 is an HTTP response, not a transport timeout. It does not prove which component generated it or that the business operation succeeded.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: A request has a method and a target: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

Frontend reference: A response is evidence, not a guarantee: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Validation at a boundary: Check input before storing or using it. Client checks help people; the server must also enforce the rule.

Apply validation at a boundary in Frontend Developer: Use the concept to complete this role exercise: Show loading, empty and error states without losing typed input

Rendering server state: The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch.

### Validation at a boundary

Check input before storing or using it. Client checks help people; the server must also enforce the rule. In this role, work through: A 400 response displays the server error without adding a phantom task. The practical workshop develops this into: Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.

Mental model: A gate with a checklist before a parcel enters a warehouse.

Boundary: Valid input can still be unauthorized; validation is not access control.

Role application: A receipt confirms a purchase; clicking Buy is only an attempt.

The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch.

Subtopic: Separate user input from the displayed result

Read a value, validate it, then update the display. A browser check improves feedback; it cannot replace validation at a server boundary.

Picture it: A draft form and an accepted record are different states.

```
const title = input.value.trim();
if (!title) {
  status.textContent = "Enter a task title.";
  return;
}
const item = document.createElement("li");
item.textContent = title;
list.append(item);
```

Try: In core/index.html, add a list with id="tasks" and select it as list. Add valid input as a new li; reject empty input before appending.

Expected: Rejected input adds no item. Each accepted submission adds one item.

Quick check: Does successful browser validation prove a remote service accepted the task?

Reasoning: No. Remote acceptance needs its own response and validation.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting

Worked example: A 400 response displays the server error without adding a phantom task.

Shared foundation example: A blank title receives 400 and does not change task count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Frontend Developer: A 400 response displays the server error without adding a phantom task.

Predict the worked case

Read this case without running a tool: A 400 response displays the server error without adding a phantom task. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in validation at a boundary.

Connect the concept to the role

Apply this rule: Check input before storing or using it. Client checks help people; the server must also enforce the rule. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Valid input can still be unauthorized; validation is not access control.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies validation at a boundary to this case: A 400 response displays the server error without adding a phantom task. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A 400 response displays the server error without adding a phantom task. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Validation at a boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with validation at a boundary. Use the glossary below, then write your prediction for: A 400 response displays the server error without adding a phantom task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain validation at a boundary using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate validation at a boundary to a system or workflow you know. Explain validation at a boundary using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the server reject invalid input even if the form already checks it?

Interview: Explain validation at a boundary using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops.

Quiz: After the Rendering server state rehearsal, check this foundation: A browser rejects a blank field. A second client calls the API directly. Where must the same business rule be enforced?

Only in the browser to avoid duplicate logic.

At the server boundary before state changes.

Only after storing the input, in the dashboard.

Reference: At the server boundary before state changes. — Client checks improve feedback; the server must protect its contract for every caller.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: Separate user input from the displayed result: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting

### Rendering server state

The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch. In this role, work through: A 400 response displays the server error without adding a phantom task. The practical workshop develops this into: Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.

Mental model: A receipt confirms a purchase; clicking Buy is only an attempt.

Boundary: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.

Subtopic: Check HTTP status before using response data

fetch resolves when an HTTP response arrives, even for statuses such as 404. Check response.ok before processing success data. JSON parsing can fail separately.

Picture it: Receiving a parcel does not mean it contains the requested item.

```
async function loadTasks() {
  const response = await fetch("/api/tasks");
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}
```

Try: Use the original local server lab in this pack, not a file:// page. Compare a valid route with a nonexistent route in browser Network tools.

Expected: The missing route follows the error path rather than being treated as a successful task list.

Quick check: Does fetch reject automatically for every 404?

Reasoning: No. Check the response status yourself.

Reference: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

Subtopic: Represent loading, success and failure explicitly

Before awaiting a request, display a loading state. Replace it with a result or a readable error. Preserve useful user input when a request fails.

Picture it: A receipt desk can say waiting, completed or needs attention.

```
status.textContent = "Loading…";
try {
  const tasks = await loadTasks();
  status.textContent = `${tasks.length} tasks loaded`;
} catch (error) {
  status.textContent = "Could not load tasks. Try again.";
}
```

Try: Use loadTasks from the previous subtopic. In DevTools, test a slow connection and then offline mode against the local lab.

Expected: Loading is visible while waiting. Failure replaces it with feedback; it never leaves an endless success-looking state.

Quick check: Why keep loading and empty-result states separate?

Reasoning: No tasks is a successful result; waiting has no result yet.

Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Using_promises

Worked example: A 400 response displays the server error without adding a phantom task.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Frontend Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

A 400 response displays the server error without adding a phantom task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.

```
node app.mjs test intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: No extra list item after failure; a recoverable message; the button works after recovery.

Role workshop · debug and verify

A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save ui-states.md and a four-state screenshot set. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: No extra list item after failure; a recoverable message; the button works after recovery.

Expected: No extra list item after failure; a recoverable message; the button works after recovery.

Troubleshoot: The role exercise differs from the prediction: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: ui-states.md and a four-state screenshot set; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rendering server state. Use the glossary below, then write your prediction for: A 400 response displays the server error without adding a phantom task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain rendering server state using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rendering server state to a system or workflow you know. Explain rendering server state using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.

Interview: Explain rendering server state using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A 400 response displays the server error without adding a phantom task.

Ignore the failing case and keep only the successful screenshot.

No extra list item after failure; a recoverable message; the button works after recovery.

Treat any successful command as proof that all business and access rules passed.

Reference: No extra list item after failure; a recoverable message; the button works after recovery. — The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch. No extra list item after failure; a recoverable message; the button works after recovery.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: Check HTTP status before using response data: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

Frontend reference: Represent loading, success and failure explicitly: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Using_promises

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

State and recovery: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.

Apply state and recovery in Frontend Developer: Use the concept to complete this role exercise: Audit keyboard focus, slow responses and repeated submission

Safe DOM updates: Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item.

### State and recovery

State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. In this role, work through: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. The practical workshop develops this into: Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.

Mental model: A whiteboard versus a saved notebook.

Boundary: A database also fails; persistence needs backups and tested recovery.

Role application: A display case shows a label; it does not execute the instructions printed on that label.

Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item.

Subtopic: Cancel obsolete work and identify the current request

AbortController can cancel a fetch. Cancellation alone is not a complete stale-result policy: use a request identifier so only the latest operation updates the UI.

Picture it: An old order slip must not replace the newest one.

```
let latest = 0;
let controller;
async function refresh() {
  const requestId = ++latest;
  controller?.abort();
  controller = new AbortController();
  const response = await fetch("/api/tasks", { signal: controller.signal });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const tasks = await response.json();
  if (requestId !== latest) return;
  // Render tasks here. Handle AbortError in the caller.
}
```

Try: In an authorized local lab, trigger two refreshes with different delays. Catch AbortError as cancellation, and handle other failures visibly.

Expected: An obsolete response never replaces the latest result; expected cancellation is not shown as a service failure.

Quick check: Is aborting a request proof that a server-side change was undone?

Reasoning: No. Client cancellation is not a transaction rollback.

Reference: https://developer.mozilla.org/en-US/docs/Web/API/AbortController

Worked example: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.

Shared foundation example: Restart this lab server: the task list becomes empty. Explain why before adding a database.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Frontend Developer: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.

Predict the worked case

Read this case without running a tool: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state and recovery.

Connect the concept to the role

Apply this rule: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A database also fails; persistence needs backups and tested recovery.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state and recovery to this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for State and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state and recovery. Use the glossary below, then write your prediction for: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain state and recovery using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state and recovery to a system or workflow you know. Explain state and recovery using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Name two things required before calling this service production ready.

Interview: Explain state and recovery using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops.

Quiz: After the Safe DOM updates rehearsal, check this foundation: A successful operation exists only in process memory. The process restarts. What can you promise?

The success response guarantees recovery after restart.

A retry will always reconstruct the original state.

Nothing about retention without a persistence and recovery design.

Reference: Nothing about retention without a persistence and recovery design. — An acknowledgment is not a storage guarantee. Identify the persistence boundary and verify restoration.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: Cancel obsolete work and identify the current request: https://developer.mozilla.org/en-US/docs/Web/API/AbortController

### Safe DOM updates

Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item. In this role, work through: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. The practical workshop develops this into: Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.

Mental model: A display case shows a label; it does not execute the instructions printed on that label.

Boundary: If markup becomes elements, trace every insertion sink rather than only escaping one test string.

Subtopic: Render untrusted text as text

textContent inserts text rather than parsing it as markup. Do not replace it with innerHTML for user-controlled strings. Other contexts, such as URLs, still need their own validation.

Picture it: Display a printed instruction without carrying it out.

```
const item = document.createElement("li");
item.textContent = "<strong>Read docs</strong>";
document.querySelector("#tasks").append(item);
```

Try: Add this to your local list exercise. Compare the literal text with trusted, authored HTML elsewhere in the document. Do not test against a third-party site.

Expected: The angle-bracket string appears literally; it does not become a bold element.

Quick check: Does textContent automatically make a user-supplied link destination safe?

Reasoning: No. URL destinations are a separate context that requires validation.

Reference: https://developer.mozilla.org/en-US/docs/Web/API/Node/textContent

Worked example: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Frontend Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.

```
node app.mjs test advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Two text items with stable IDs; no img element created from the title; no lost input focus.

Role workshop · debug and verify

If markup becomes elements, trace every insertion sink rather than only escaping one test string. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save dom-security.md with before/after DOM evidence and an automated assertion. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Two text items with stable IDs; no img element created from the title; no lost input focus.

Expected: Two text items with stable IDs; no img element created from the title; no lost input focus.

Troubleshoot: The role exercise differs from the prediction: If markup becomes elements, trace every insertion sink rather than only escaping one test string.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: dom-security.md with before/after DOM evidence and an automated assertion; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with safe dom updates. Use the glossary below, then write your prediction for: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain safe dom updates using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate safe dom updates to a system or workflow you know. Explain safe dom updates using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If markup becomes elements, trace every insertion sink rather than only escaping one test string.

Interview: Explain safe dom updates using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Two text items with stable IDs; no img element created from the title; no lost input focus.

Reference: Two text items with stable IDs; no img element created from the title; no lost input focus. — Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item. Two text items with stable IDs; no img element created from the title; no lost input focus.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: Render untrusted text as text: https://developer.mozilla.org/en-US/docs/Web/API/Node/textContent
