# Frontend Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Request and response: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.

Apply request and response in Frontend Developer: Use the concept to complete this role exercise: Build a labeled task form navigable with Tab

Semantic forms and feedback: HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails.

### What a frontend developer builds

A frontend is the part of a website people read and interact with in a browser. Start by separating content, presentation and behaviour.

Browser and server
A browser requests files and interprets them. A server sends files or application responses. Opening a local HTML file needs no server, but later network exercises use a local HTTP server. A URL identifies a location; a file path identifies where a file lives. Neither is the same thing as a programming language.

HTML, CSS and JavaScript
HTML names the content: heading, paragraph, link and form. CSS describes presentation: space, colour and layout. JavaScript runs instructions and handles events. They cooperate, but each can be tested separately. A page should still communicate its essential content before extra interaction is added.

Inspect before changing
Open the Elements panel in browser DevTools to inspect the document, then Console to see script messages. A change made only in Elements usually disappears on reload. Edit your saved source file when you want a lasting change. Keep an untouched reference copy so you can compare results.

Worked code:
<h1>My learning journal</h1>
<p>I am learning the web.</p>
<style>h1 { color: #245b52; }</style>
<script>console.log("Page loaded");</script>

The h1 is a meaningful heading, not a font-size instruction.
The CSS rule targets the heading. The script writes to Console, not the page.

Mental model: A small shop: HTML arranges the goods, CSS presents them, and JavaScript responds to the customer.

Boundary: A browser can change a screen without changing server data. A useful interface still needs reliable services, accessibility and clear feedback.

Worked example: <h1>My learning journal</h1>
<p>I am learning the web.</p>
<style>h1 { color: #245b52; }</style>
<script>console.log("Page loaded");</script>

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: Browser DevTools; VS Code or VSCodium

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the What a frontend developer builds lab. Extract the course ZIP and open course-labs/web/index.html. Find the page heading and then open DevTools.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Extract the course ZIP and open course-labs/web/index.html. Find the page heading and then open DevTools.

Expected: A heading and a task form appear; Console is available.

Step 2

Change the heading in Elements, reload, then change it in index.html and reload again.

Expected: Only the source-file change survives reload.

Step 3

Temporarily remove the stylesheet link. Restore it after comparing the page.

Expected: The content remains present while its appearance changes.

Expected: Explain which file controls structure, styling and interaction, using one observed change for each.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: Explain which file controls structure, styling and interaction, using one observed change for each. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/web-foundations.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining browser and server in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: A heading and a task form appear; Console is available.

seeker: Build interview evidence for what a frontend developer builds. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect what a frontend developer builds to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A browser can change a screen without changing server data. A useful interface still needs reliable services, accessibility and clear feedback.

Recall: You edit a heading only in DevTools Elements, then reload. Why is it gone?

Interview: Explain what a frontend developer builds using your own artifact. Defend the rule behind this scenario: You edit a heading only in DevTools Elements, then reload. Why is it gone? Then explain one failure case and this limitation: A browser can change a screen without changing server data. A useful interface still needs reliable services, accessibility and clear feedback.

Quiz: You edit a heading only in DevTools Elements, then reload. Why is it gone?

The saved HTML file was not changed.

CSS deleted the server file.

A heading requires JavaScript storage.

Reference: The saved HTML file was not changed. — DevTools edits inspect the current document; save the source to make the change persistent.

Sources:

Your first website · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website

HTML syntax · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

DOM scripting · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting

### Files, paths and your first debugging routine

A website is a set of related files. Learn to find a file, link it correctly and use an error message instead of guessing.

Create a predictable folder
Use index.html for the page, styles.css for styles and app.js for behaviour. The extension tells tools the file type. An editor must save plain text, not a rich-text document with a hidden .txt extension. Keep assets in a clearly named subfolder and use consistent lowercase names.

Resolve relative paths
A path such as ./styles.css starts in the current document folder. ../ moves up one level. A leading / starts at the origin root when served over HTTP; it may break a project hosted under a repository subpath. Read the actual requested URL in Network before changing a path.

Make one change at a time
First reproduce the symptom. Then inspect Console for script errors and Network for missing files. Read the filename and line number. Correct one cause, reload and confirm the expected result. If a stylesheet is missing, changing a JavaScript function will not repair its path.

Worked code:
<link rel="stylesheet" href="./styles.css">
<script src="./app.js" defer></script>

defer allows the external script to run after HTML parsing.
A missing path is visible in Network when the page is served over HTTP.

Mental model: A folder is a labelled shelf; a relative path tells you how to reach another shelf from the current one.

Boundary: Local case-insensitive filenames can hide mistakes that appear on a case-sensitive host. A local file page also differs from an HTTP origin.

Worked example: <link rel="stylesheet" href="./styles.css">
<script src="./app.js" defer></script>

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: Editor, browser Console and Network panel

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Files, paths and your first debugging routine lab. In course-labs/web, rename styles.css to theme.css without editing the link. Reload.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

In course-labs/web, rename styles.css to theme.css without editing the link. Reload.

Expected: The layout loses styling; the file request or Console identifies a missing file.

Step 2

Change href to ./theme.css and reload.

Expected: Styling returns with the corrected filename.

Step 3

Restore the original filename and link. Record symptom, evidence and correction in notes.md.

Expected: The starter works again and the debugging record names the actual cause.

Expected: A three-line debugging record and working relative stylesheet/script paths.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A three-line debugging record and working relative stylesheet/script paths. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/files-and-debugging.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining create a predictable folder in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The layout loses styling; the file request or Console identifies a missing file.

seeker: Build interview evidence for files, paths and your first debugging routine. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect files, paths and your first debugging routine to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Local case-insensitive filenames can hide mistakes that appear on a case-sensitive host. A local file page also differs from an HTTP origin.

Recall: Your page works at the host root but its stylesheet fails under /my-course/. What should you inspect first?

Interview: Explain files, paths and your first debugging routine using your own artifact. Defend the rule behind this scenario: Your page works at the host root but its stylesheet fails under /my-course/. What should you inspect first? Then explain one failure case and this limitation: Local case-insensitive filenames can hide mistakes that appear on a case-sensitive host. A local file page also differs from an HTTP origin.

Quiz: Your page works at the host root but its stylesheet fails under /my-course/. What should you inspect first?

The CSS font size.

The resolved stylesheet URL and its path.

The JavaScript variable names.

Reference: The resolved stylesheet URL and its path. — Path resolution changes with the hosting base. Network evidence identifies the missing resource.

Sources:

Your first website · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website

Modules · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

HTTP overview · official reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

### What HTML is: elements and the document

HTML means HyperText Markup Language. It marks the structure and meaning of content; it does not describe an algorithm.

Tags, elements and nesting
An element is the complete structure, such as <p>Hello</p>. Opening and closing tags surround its content. Nest elements so the inner one closes first. Some elements, including img and input, are void elements with no closing tag. Indentation helps humans see nesting but does not create the structure.

The document skeleton
The doctype asks for modern standards behaviour. html is the root; lang describes the document language. head contains metadata such as title and character encoding. body contains the visible content. The browser tab uses title; the visible page heading is a separate h1 element.

Headings and paragraphs
Use headings to organise sections and p for paragraphs. Do not choose h4 simply because it looks smaller: CSS controls appearance. A clear main heading and logical section headings help readers and assistive technology understand the document. Escape angle brackets when you want to display markup as text.

Worked code:
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>My journal</title></head>
<body>
  <h1>Learning journal</h1>
  <h2>Today</h2>
  <p>I created my first document.</p>
</body>
</html>

title is tab metadata; h1 is visible content.
The paragraph belongs inside body. Matching closing tags make the nesting explicit.

Mental model: A document outline with labelled containers, rather than a picture made of large and small text.

Boundary: Valid-looking HTML can still express the wrong meaning. Browser error recovery is not a substitute for writing a deliberate document.

Worked example: <!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>My journal</title></head>
<body>
  <h1>Learning journal</h1>
  <h2>Today</h2>
  <p>I created my first document.</p>
</body>
</html>

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: HTML, editor and browser Elements panel

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the What HTML is: elements and the document lab. Create first-page.html beside the starter and type the complete example. Open it in a browser.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Create first-page.html beside the starter and type the complete example. Open it in a browser.

Expected: The tab says My journal and the page says Learning journal.

Step 2

Add a second h2 section with two paragraphs. Inspect the document in Elements.

Expected: Both sections are siblings under body.

Step 3

Display the text <p> using &lt;p&gt;, then explain why raw markup is interpreted differently.

Expected: The angle brackets are visible as text.

Expected: A complete HTML document with correct metadata, two sections and a literal markup example.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A complete HTML document with correct metadata, two sections and a literal markup example. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/html-document.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining tags, elements and nesting in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The tab says My journal and the page says Learning journal.

seeker: Build interview evidence for what html is: elements and the document. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect what html is: elements and the document to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Valid-looking HTML can still express the wrong meaning. Browser error recovery is not a substitute for writing a deliberate document.

Recall: Which element changes the browser tab label?

Interview: Explain what html is: elements and the document using your own artifact. Defend the rule behind this scenario: Which element changes the browser tab label? Then explain one failure case and this limitation: Valid-looking HTML can still express the wrong meaning. Browser error recovery is not a substitute for writing a deliberate document.

Quiz: Which element changes the browser tab label?

h1

title

main

Reference: title — title is document metadata in head; h1 names the visible main heading.

Sources:

HTML syntax · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

Elements · official reference: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements

Your first website · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website

### Attributes, links and file navigation

Attributes add information to an element. Use them to identify controls, link documents and describe resources.

Attribute syntax
Write attributes inside the opening tag as name="value". Quote values consistently. id should be unique within a document; class can be shared by several elements. Boolean attributes such as required are true when present: required="false" still means the attribute is present.

Hyperlinks versus actions
An anchor with href navigates to a destination. A button performs an action such as submitting a form. Link text should describe the destination instead of saying click here. A fragment such as #contact refers to an element whose id is contact.

Paths and navigation
Link two local pages using relative paths. External links need a complete URL including its scheme. Avoid forcing a new tab without a reason. Test each link after moving the project into a subfolder; an accidental root-relative path can appear correct only on your own machine.

Worked code:
<nav aria-label="Main">
  <a href="./about.html">About this journal</a>
  <a href="#contact">Contact</a>
</nav>
<section id="contact"><h2>Contact</h2></section>

The fragment and id match exactly.
aria-label distinguishes navigation regions; it does not replace meaningful link text.

Mental model: A tag names an object; its attributes are the labelled fields describing that object.

Boundary: An id identifies an element in a document; it does not make content private or validate a URL.

Worked example: <nav aria-label="Main">
  <a href="./about.html">About this journal</a>
  <a href="#contact">Contact</a>
</nav>
<section id="contact"><h2>Contact</h2></section>

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: HTML attributes and browser navigation

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Attributes, links and file navigation lab. Create about.html with a heading and a link back to index.html.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Create about.html with a heading and a link back to index.html.

Expected: Both documents can be opened independently.

Step 2

Add a relative About link and a #contact link to the main page. Activate both.

Expected: About changes the document; Contact moves within the same one.

Step 3

Change the fragment temporarily to #missing, observe the failure and restore it.

Expected: The repaired link targets the intended section.

Expected: Two connected pages and one tested in-page link, with no duplicated ids.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: Two connected pages and one tested in-page link, with no duplicated ids. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/html-attributes.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining attribute syntax in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Both documents can be opened independently.

seeker: Build interview evidence for attributes, links and file navigation. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect attributes, links and file navigation to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: An id identifies an element in a document; it does not make content private or validate a URL.

Recall: Which control should navigate to an About page?

Interview: Explain attributes, links and file navigation using your own artifact. Defend the rule behind this scenario: Which control should navigate to an About page? Then explain one failure case and this limitation: An id identifies an element in a document; it does not make content private or validate a URL.

Quiz: Which control should navigate to an About page?

A div with a click handler.

A form input.

An anchor with an href.

Reference: An anchor with an href. — A real link provides navigation semantics and expected browser behaviour.

Sources:

Links · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Creating_links

Elements · official reference: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements

HTML syntax · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

### Semantic sections, lists and readable content

Semantic HTML expresses the job of a piece of content. Build a page that makes sense before styling it.

Page landmarks
Use main for the principal content, nav for a significant navigation area and header/footer for introductory or concluding content in their context. A section groups related content, usually with a heading. A div is useful when no semantic element describes a purely visual grouping.

Lists and emphasis
Use ul when item order does not matter and ol for a sequence. Each item is an li. strong indicates importance and em indicates emphasis; CSS can change their appearance. Do not simulate a list by typing bullet characters and inserting line breaks.

Content before decoration
Write meaningful headings and concise text. Link labels should remain understandable outside their surrounding sentence. Test the unstyled page: if relationships disappear, some meaning may be stored only in colour or position. Put those relationships into the document as well.

Worked code:
<main>
  <h1>My study plan</h1>
  <section>
    <h2>Today’s steps</h2>
    <ol><li>Read</li><li>Practise</li><li>Check</li></ol>
  </section>
</main>

ol carries sequence; CSS-generated numbers alone would not create that structure.
The section heading explains what the group contains.

Mental model: A book has a title, chapters and navigation; it is not one long pile of boxes.

Boundary: Using main or nav does not automatically make every interaction accessible. Labels, keyboard behaviour and content still need testing.

Worked example: <main>
  <h1>My study plan</h1>
  <section>
    <h2>Today’s steps</h2>
    <ol><li>Read</li><li>Practise</li><li>Check</li></ol>
  </section>
</main>

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: Semantic HTML and accessibility tree

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Semantic sections, lists and readable content lab. Replace a group of plain divs in a copy of the starter with main, section and a logical heading.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Replace a group of plain divs in a copy of the starter with main, section and a logical heading.

Expected: Elements reveals meaningful page regions.

Step 2

Add an ordered practice sequence and an unordered tools list.

Expected: The browser presents two distinct list types.

Step 3

Disable CSS and read the page in order. Correct any heading that depends only on size.

Expected: The page remains understandable without styling.

Expected: An unstyled-readable document outline with landmarks and both list types.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: An unstyled-readable document outline with landmarks and both list types. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/semantic-content.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining page landmarks in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Elements reveals meaningful page regions.

seeker: Build interview evidence for semantic sections, lists and readable content. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect semantic sections, lists and readable content to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Using main or nav does not automatically make every interaction accessible. Labels, keyboard behaviour and content still need testing.

Recall: A set of installation steps must happen in sequence. Which structure communicates this?

Interview: Explain semantic sections, lists and readable content using your own artifact. Defend the rule behind this scenario: A set of installation steps must happen in sequence. Which structure communicates this? Then explain one failure case and this limitation: Using main or nav does not automatically make every interaction accessible. Labels, keyboard behaviour and content still need testing.

Quiz: A set of installation steps must happen in sequence. Which structure communicates this?

ol containing li elements.

Several paragraphs with spaces.

A large heading for every line.

Reference: ol containing li elements. — An ordered list represents a meaningful sequence independently of its styling.

Sources:

Elements · official reference: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements

W3C accessibility tutorials · official reference: https://www.w3.org/WAI/tutorials/

HTML syntax · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

### Images, alternative text and resource sizing

An image is a resource with a purpose. Its text alternative and dimensions are part of the content design.

Source and text alternative
src identifies the image resource. alt supplies a text alternative. Describe the relevant information in an informative image; use alt="" for a purely decorative image that adds no information. For an image acting as a link, communicate the link purpose. Do not omit alt merely because an image is decorative.

Dimensions and responsive sizing
Intrinsic width and height help reserve space before loading. CSS max-width:100% allows an image to shrink within its container; height:auto preserves its aspect ratio. This does not reduce the file size sent over the network. Larger projects use appropriately sized sources and modern formats.

Captions and failure cases
Use figure and figcaption when a visible caption belongs with an illustration. A caption and alt may do different jobs. Test a deliberately wrong source path and check whether the remaining text communicates the essential information. Avoid putting important instructions only inside an image.

Worked code:
<figure>
  <img src="./layout.svg" alt="Header above a two-column content area" width="480" height="240">
  <figcaption>Our planned desktop layout.</figcaption>
</figure>
<style>img { max-width: 100%; height: auto; }</style>

The dimensions reserve a 2:1 area; the CSS can shrink it.
The alt describes the information, not the filename layout.svg.

Mental model: Alternative text is the useful message a reader needs when the picture cannot be seen.

Boundary: A filename is rarely an adequate description. Alternative text depends on the surrounding task, not just the pixels.

Worked example: <figure>
  <img src="./layout.svg" alt="Header above a two-column content area" width="480" height="240">
  <figcaption>Our planned desktop layout.</figcaption>
</figure>
<style>img { max-width: 100%; height: auto; }</style>

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: HTML img/figure and DevTools responsive view

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Images, alternative text and resource sizing lab. Use course-labs/web/layout.svg in a figure and add a purpose-specific alt.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Use course-labs/web/layout.svg in a figure and add a purpose-specific alt.

Expected: The diagram and caption appear together.

Step 2

Resize the page to 320px and verify the image fits.

Expected: The aspect ratio is preserved without page overflow.

Step 3

Break the src temporarily. Read the alternative and decide whether it preserves the diagram’s important message.

Expected: The repaired resource and useful alternative are both present.

Expected: An informative figure that fits a narrow screen and remains meaningful if the resource fails.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: An informative figure that fits a narrow screen and remains meaningful if the resource fails. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/images-and-media.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining source and text alternative in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The diagram and caption appear together.

seeker: Build interview evidence for images, alternative text and resource sizing. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect images, alternative text and resource sizing to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A filename is rarely an adequate description. Alternative text depends on the surrounding task, not just the pixels.

Recall: Which CSS makes a wide image fit its container while preserving shape?

Interview: Explain images, alternative text and resource sizing using your own artifact. Defend the rule behind this scenario: Which CSS makes a wide image fit its container while preserving shape? Then explain one failure case and this limitation: A filename is rarely an adequate description. Alternative text depends on the surrounding task, not just the pixels.

Quiz: Which CSS makes a wide image fit its container while preserving shape?

width:2000px

max-width:100%; height:auto

height:10px; width:100%

Reference: max-width:100%; height:auto — The maximum limits width while automatic height preserves the image aspect ratio.

Sources:

Images · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/HTML_images

Responsive · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

W3C accessibility tutorials · official reference: https://www.w3.org/WAI/tutorials/

### Forms, labels, input types and validation

A form gathers related values and submits them. Learn its built-in behaviour before writing custom JavaScript.

Labels and field names
A visible label with for="email" connects to an input with id="email". The id creates the association; name identifies the field in submitted form data. Placeholder text is a hint, not a replacement for a persistent label. Use fieldset and legend to name a related group, such as radio choices.

Types and constraints
Choose email, number or another input type that fits the value. required rejects an empty value; minlength and maxlength constrain text length. Type-specific checks do not prove a value is real or permitted by the business. Explain constraints before submission and keep error feedback near the field.

Submission and buttons
A button inside a form defaults to submit unless you give another type. Use type="button" for unrelated actions. Native submission can be triggered from the keyboard, so later JavaScript should listen to submit on the form rather than only to a button click. Never put real personal data in a learning form.

Worked code:
<form>
  <label for="email">Practice email</label>
  <input id="email" name="email" type="email" required>
  <button type="submit">Continue</button>
</form>

id joins the label; name is the submitted key.
No action is supplied in this teaching fragment. Use synthetic input, not personal information.

Mental model: A form is a questionnaire with named fields and one submission decision.

Boundary: Browser validation improves feedback. A server must independently validate data from every client.

Worked example: <form>
  <label for="email">Practice email</label>
  <input id="email" name="email" type="email" required>
  <button type="submit">Continue</button>
</form>

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: HTML forms, constraint validation and keyboard

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Forms, labels, input types and validation lab. Add a labelled email field to a separate local practice page. Click its label and use Tab.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add a labelled email field to a separate local practice page. Click its label and use Tab.

Expected: Clicking the label focuses the control; keyboard focus reaches submit.

Step 2

Try submitting an empty value, invalid text and learner@example.test.

Expected: The first two fail native constraints; the syntactically valid address can submit.

Step 3

Prevent real navigation by using the starter’s submit handler when integrating the field. Explain why a server still validates.

Expected: The page gives feedback without claiming the address exists.

Expected: A keyboard-usable labelled form and evidence for empty, malformed and valid-looking values.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A keyboard-usable labelled form and evidence for empty, malformed and valid-looking values. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/html-forms.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining labels and field names in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Clicking the label focuses the control; keyboard focus reaches submit.

seeker: Build interview evidence for forms, labels, input types and validation. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect forms, labels, input types and validation to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Browser validation improves feedback. A server must independently validate data from every client.

Recall: What connects a visible label to its input?

Interview: Explain forms, labels, input types and validation using your own artifact. Defend the rule behind this scenario: What connects a visible label to its input? Then explain one failure case and this limitation: Browser validation improves feedback. A server must independently validate data from every client.

Quiz: What connects a visible label to its input?

Matching class names.

A matching placeholder.

The label’s for and the input’s id.

Reference: The label’s for and the input’s id. — The for/id association identifies the labelled control; name serves a different purpose.

Sources:

Forms · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms

Labels · official reference: https://www.w3.org/WAI/tutorials/forms/labels/

Events · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events

### Tables, accessible data and the HTML checkpoint

Tables represent relationships between rows and columns. Use them for data, not for arranging a page.

Cells and headers
table contains rows, tr contains cells, th identifies a header and td identifies data. A caption names the table. For a simple table, scope="col" or scope="row" expresses which cells a header describes. Do not communicate headers only with bold styling.

Choose the right structure
A timetable or comparison matrix belongs in a table. A navigation bar or two-column page belongs in CSS layout. On a narrow screen, keep data relationships intact; a labelled horizontal scroll area can be preferable to shrinking text until it is unreadable.

Checkpoint: explain your document
Combine what you know into a study page: title and language metadata, landmarks, headings, links, an image, a labelled form and a small data table. Read it with CSS removed and navigate with the keyboard. Record the structure you chose and one alternative you rejected.

Worked code:
<table>
  <caption>Weekly practice</caption>
  <tr><th scope="col">Day</th><th scope="col">Minutes</th></tr>
  <tr><th scope="row">Monday</th><td>30</td></tr>
</table>

caption names the dataset.
scope declares header direction; it does not choose a visual layout.

Mental model: A spreadsheet with named row and column axes.

Boundary: A table that looks aligned can still have unclear header relationships. Complex tables may need a simpler presentation.

Worked example: <table>
  <caption>Weekly practice</caption>
  <tr><th scope="col">Day</th><th scope="col">Minutes</th></tr>
  <tr><th scope="row">Monday</th><td>30</td></tr>
</table>

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: HTML table and browser accessibility inspector

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Tables, accessible data and the HTML checkpoint lab. Add a three-row practice table to your journal with caption and headers.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add a three-row practice table to your journal with caption and headers.

Expected: Each number has an identifiable day and unit.

Step 2

Complete the HTML checkpoint page using your previous exercises.

Expected: All required structures are in saved source files.

Step 3

Use Tab, disable styles and inspect the accessibility tree. Document one repair.

Expected: The page order, labels and table relationships stay meaningful.

Expected: An HTML-only learning journal and a written structural/accessibility review.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: An HTML-only learning journal and a written structural/accessibility review. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/html-tables.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining cells and headers in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Each number has an identifiable day and unit.

seeker: Build interview evidence for tables, accessible data and the html checkpoint. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect tables, accessible data and the html checkpoint to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A table that looks aligned can still have unclear header relationships. Complex tables may need a simpler presentation.

Recall: What should you use for a two-column page layout?

Interview: Explain tables, accessible data and the html checkpoint using your own artifact. Defend the rule behind this scenario: What should you use for a two-column page layout? Then explain one failure case and this limitation: A table that looks aligned can still have unclear header relationships. Complex tables may need a simpler presentation.

Quiz: What should you use for a two-column page layout?

A table with empty spacer cells.

CSS layout around semantic content.

Repeated spaces in HTML.

Reference: CSS layout around semantic content. — Tables describe data relationships; CSS is the appropriate layout tool.

Sources:

Tables · official reference: https://www.w3.org/WAI/tutorials/tables/

Elements · official reference: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements

W3C accessibility tutorials · official reference: https://www.w3.org/WAI/tutorials/

### What CSS is: rules, selectors and declarations

CSS means Cascading Style Sheets. It describes how elements are presented while HTML retains their meaning.

Read a rule
A CSS rule has a selector and a block of declarations. Each declaration has a property and value separated by a colon. Semicolons separate declarations. h1 selects heading elements; .notice selects a class. The same class can be reused on several elements without duplicating id values.

Connect an external sheet
Use link rel="stylesheet" in head to load a CSS file. A shared stylesheet lets multiple pages reuse design rules. Keep HTML meaningful without the stylesheet. If no rule appears to work, inspect the resource path and whether the selector matches before changing values randomly.

Inspect matched styles
DevTools Styles shows matched rules and crossed-out declarations. Temporarily edit a value to test an idea, then save the confirmed change in the source. Start with a few readable rules; a large stylesheet copied without understanding creates more debugging work.

Worked code:
/* styles.css */
h1 { color: #245b52; }
.notice { padding: 1rem; background: #eef5f1; }

h1 is a type selector and .notice is a class selector.
padding is a property; 1rem is its value.

Mental model: A reusable set of presentation instructions attached to selected parts of a document.

Boundary: A selector matching an element does not guarantee its declaration wins. The cascade decides between competing declarations.

Worked example: /* styles.css */
h1 { color: #245b52; }
.notice { padding: 1rem; background: #eef5f1; }

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: CSS and DevTools Styles

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the What CSS is: rules, selectors and declarations lab. Link a new CSS file from your journal and add the example rules.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Link a new CSS file from your journal and add the example rules.

Expected: The heading colour changes and classed notices have internal space.

Step 2

Add class="notice" to two paragraphs, then inspect both.

Expected: Both match the same reusable rule.

Step 3

Misspell the class on one paragraph, diagnose in Styles and repair.

Expected: The repaired element matches the intended rule.

Expected: A separate stylesheet and a saved explanation of selector, property and value.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A separate stylesheet and a saved explanation of selector, property and value. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/css-start.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining read a rule in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The heading colour changes and classed notices have internal space.

seeker: Build interview evidence for what css is: rules, selectors and declarations. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect what css is: rules, selectors and declarations to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A selector matching an element does not guarantee its declaration wins. The cascade decides between competing declarations.

Recall: In .notice { padding: 1rem; }, which part selects elements?

Interview: Explain what css is: rules, selectors and declarations using your own artifact. Defend the rule behind this scenario: In .notice { padding: 1rem; }, which part selects elements? Then explain one failure case and this limitation: A selector matching an element does not guarantee its declaration wins. The cascade decides between competing declarations.

Quiz: In .notice { padding: 1rem; }, which part selects elements?

.notice

padding

1rem

Reference: .notice — The class selector chooses elements; the declaration supplies presentation.

Sources:

CSS foundations · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics

Cascade · official reference: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Introduction

Elements · official reference: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements

### Cascade, specificity and inheritance

Why is this paragraph green when its parent is blue? Follow one small example to learn how the browser chooses a style, then prove it in DevTools.

Start with the element, then its parent
Imagine a paragraph inside a blue parent. The paragraph can use its own colour, or inherit the parent’s colour. “Inherit” means receiving a value from the parent; it does not mean copying every style.
Remember: A child’s own colour comes before an inherited colour.
color usually passes down: With no color declaration of its own, a paragraph normally uses its parent’s computed colour.
margin does not pass down by default: Giving the parent margin: 24px does not give each child a 24px margin. A child can still have its own margin, including a browser default.
A direct rule changes the result: If p sets color: navy, the paragraph uses navy instead of inheriting the parent’s colour. The parent and child are different elements.
Predict it: body is blue and p sets color: navy. What colour is the paragraph?
Reference answer: Navy. The paragraph has its own color declaration, so it does not use the inherited blue value. The parent selector’s specificity does not change that.

When two rules match, which one wins?
Both p and .note match our paragraph. Each supplies a different color value. In this example, .note wins because a class selector has more specificity than a type selector. “Specificity” means selector weight.
Remember: For this example: .note beats p. Being later is not enough.
Type selector · p: Matches every paragraph. It supplies navy in our example.
Class selector · .note: Matches elements with class="note". It supplies darkgreen and has greater specificity than p.
ID selector · #intro: A matching ID selector would outweigh either simple selector here. Prefer reusable classes; a heavier selector is not automatically a better design.
Example:
.note { color: darkgreen; }
p { color: navy; } /* later, but less specific */
Predict it: move p below .note, as above. Does the paragraph turn navy?
Reference answer: No. It stays dark green. Source order breaks a tie only after the earlier cascade decisions are equal. With two otherwise equal .note rules here, the later one would win.

Find the reason in DevTools
A page looks wrong? Inspect the element before changing CSS. Your browser can show which declaration sets its colour, which declarations lost, and whether a value came from its parent.
Remember: Find the declaration that actually sets the value. Change that cause.
Inspect the paragraph: Right-click it and choose Inspect. Confirm that you selected the p element with class="note".
Look in Styles or Rules: Filter for color. Find the active .note declaration; p’s navy declaration should be overridden, usually shown crossed out.
Check Computed, then test one change: Computed shows the final colour, often as rgb(0, 100, 0) for darkgreen. Disable .note’s color to get navy; disable p’s color too to reveal the inherited body colour.
Explain it: turning off .note changes the paragraph to navy. Is navy inherited from body?
Reference answer: No. The p rule now sets navy directly on the paragraph. Only after both child color declarations are disabled does body’s blue pass down. Avoid adding !important just to hide a conflict you have not diagnosed.

HTML:
<p class="note">
  My first CSS experiment
</p>

Worked code:
/* styles.css */
body { color: blue; }
p { color: navy; }
.note { color: darkgreen; }

The paragraph is dark green: .note beats p for color in this example. The body colour is a fallback, not a competing colour declaration on the paragraph.
The HTML and CSS snippets belong in separate files. Keep index.html linked to styles.css, as in the previous lesson.

Mental model: Ask two questions for each property: does this element have a value of its own? If not, does this property normally inherit from its parent? The cascade chooses between competing declarations; inheritance supplies a default for inherited properties.

Boundary: This example uses normal author styles in one unlayered stylesheet, without animations, transitions or scoped rules. In other cases, origin, importance and layers come before specificity; scoping proximity can break a specificity tie before source order.

Worked example: /* styles.css */
body { color: blue; }
p { color: navy; }
.note { color: darkgreen; }

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: Browser DevTools: Elements/Inspector, Styles/Rules and Computed

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Cascade, specificity and inheritance lab. In course-labs/web, keep a copy of index.html and styles.css. Add the paragraph from the example inside body and the three CSS rules at the end of styles.css. Open index.html in a browser and inspect the paragraph. Check for other matching color rules; isolate this example in a new linked HTML/CSS pair if needed.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

In course-labs/web, keep a copy of index.html and styles.css. Add the paragraph from the example inside body and the three CSS rules at the end of styles.css. Open index.html in a browser and inspect the paragraph. Check for other matching color rules; isolate this example in a new linked HTML/CSS pair if needed.

Expected: The paragraph is dark green. In DevTools, .note sets color and the p colour is overridden.

Step 2

In DevTools Styles, turn off only the .note color declaration. Then turn off the p color declaration too. After each change, write your prediction before checking Computed color. Reload to restore your saved stylesheet.

Expected: With .note color off, the paragraph is navy. With both child color declarations off, it inherits blue from body. Reload restores dark green.

Step 3

In your saved stylesheet, add .note { color: purple; } after the existing .note rule. Reload, inspect, then swap the two .note rules and reload again. Save your observations and restore the original rules.

Expected: Purple wins while its otherwise equal rule is last. After swapping, darkgreen wins. These edits change source order, not specificity.

Expected: A colour prediction and DevTools evidence for all three states, plus a source-order comparison. Name the winning declaration or inherited value in each case.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A colour prediction and DevTools evidence for all three states, plus a source-order comparison. Name the winning declaration or inherited value in each case. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/css-cascade.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining start with the element, then its parent in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The paragraph is dark green. In DevTools, .note sets color and the p colour is overridden.

seeker: Build interview evidence for cascade, specificity and inheritance. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect cascade, specificity and inheritance to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: This example uses normal author styles in one unlayered stylesheet, without animations, transitions or scoped rules. In other cases, origin, importance and layers come before specificity; scoping proximity can break a specificity tie before source order.

Recall: A child has its own winning color declaration. Does changing its parent’s color necessarily change the child?

Interview: Explain cascade, specificity and inheritance using your own artifact. Defend the rule behind this scenario: A child has its own winning color declaration. Does changing its parent’s color necessarily change the child? Then explain one failure case and this limitation: This example uses normal author styles in one unlayered stylesheet, without animations, transitions or scoped rules. In other cases, origin, importance and layers come before specificity; scoping proximity can break a specificity tie before source order.

Quiz: A child has its own winning color declaration. Does changing its parent’s color necessarily change the child?

Yes, inheritance always overrides children.

No, the child’s own winning declaration takes precedence over inheritance.

Only if the parent is a div.

Reference: No, the child’s own winning declaration takes precedence over inheritance. — Inheritance supplies values where applicable; it does not override an element’s own winning declaration.

Sources:

Cascade · official reference: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Introduction

Inheritance · official reference: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Inheritance

Specificity · official reference: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Specificity

CSS foundations · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics

Box · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model

### Box model, spacing and sizing

Every layout problem starts with boxes. Distinguish content size, internal space, borders and external separation.

Four layers
Content is the inner area. Padding separates content from the border. Border surrounds both. Margin separates the border from other boxes. Background usually paints through padding to the border. Use DevTools’ box diagram to identify which layer produced an unexpected gap.

Choose box sizing deliberately
With content-box, width describes content only; padding and border add to the outer width. With border-box, they fit inside the declared width. Margin stays outside in both models. A percentage width depends on its containing block, so fixed padding can create unexpected overflow.

Use constraints instead of arbitrary dimensions
Prefer a flexible width with a readable max-width for text and min-height only when needed. A fixed height can clip translated or enlarged text. Test long content, larger text and a narrow viewport before deciding a dimension is safe.

Worked code:
.panel {
  box-sizing: border-box;
  width: 300px;
  padding: 20px;
  border: 2px solid #245b52;
  margin: 16px;
}

With border-box, the border-edge width is 300px.
The content width is 256px; horizontal margins add another 32px outside.

Mental model: A package with contents, cushioning, wrapping and space around it.

Boundary: The model describes individual boxes. Layout algorithms, intrinsic sizes and margin collapse also affect their placement.

Worked example: .panel {
  box-sizing: border-box;
  width: 300px;
  padding: 20px;
  border: 2px solid #245b52;
  margin: 16px;
}

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: CSS box model and measurement tools

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Box model, spacing and sizing lab. Apply the panel rule to a paragraph and inspect its box diagram.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Apply the panel rule to a paragraph and inspect its box diagram.

Expected: Content is 256px wide when the stated sizes apply.

Step 2

Switch to content-box and measure the border edge.

Expected: It grows to 344px before margins.

Step 3

Replace width with width:100%; max-width:300px and test in a narrow parent.

Expected: The box fits its parent with border-box; margin still requires separate consideration.

Expected: Measured widths for both sizing modes and a flexible corrected rule.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: Measured widths for both sizing modes and a flexible corrected rule. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/css-box.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining four layers in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Content is 256px wide when the stated sizes apply.

seeker: Build interview evidence for box model, spacing and sizing. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect box model, spacing and sizing to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: The model describes individual boxes. Layout algorithms, intrinsic sizes and margin collapse also affect their placement.

Recall: A 300px border-box has 20px padding and 2px border on each side. What is its content width?

Interview: Explain box model, spacing and sizing using your own artifact. Defend the rule behind this scenario: A 300px border-box has 20px padding and 2px border on each side. What is its content width? Then explain one failure case and this limitation: The model describes individual boxes. Layout algorithms, intrinsic sizes and margin collapse also affect their placement.

Quiz: A 300px border-box has 20px padding and 2px border on each side. What is its content width?

300px

344px

256px

Reference: 256px — Subtract 40px padding and 4px border from the declared 300px.

Sources:

Box · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model

Values · official reference: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Values_and_Units

Responsive · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

### Typography, colour, units and focus styles

Readable presentation is functional. Use relative sizes, visible focus and sufficient contrast instead of relying on decoration.

Relative lengths
rem is relative to the root font size; em depends on the relevant font size and can compound. Percentages depend on the property and context. Use unitless line-height so it scales with text. Avoid setting tiny fixed text sizes to fit more information into a component.

Colour with meaning beyond colour
Use text labels as well as colour for errors and status. Check foreground/background contrast with an appropriate tool. Define reusable custom properties for colour and spacing. A custom property stores a value for substitution; it does not automatically enforce contrast or validate a design.

Keyboard focus is essential
Keyboard users need to see where focus is. Use :focus-visible for a clear outline and keep interactive targets practical to activate. Do not remove the browser outline without an effective replacement. Test links and controls on both light and coloured surfaces.

Worked code:
:root { --ink: #203448; --accent: #245b52; }
body { color: var(--ink); font-size: 1rem; line-height: 1.6; }
a:focus-visible, button:focus-visible {
  outline: 3px solid var(--accent); outline-offset: 3px;
}

Custom properties let related rules share a value.
A unitless line-height scales with the element’s font size.

Mental model: A typographic scale is a shared measuring ruler for a page.

Boundary: A unit or colour choice alone does not establish accessibility. Check the rendered content, contrast and user settings.

Worked example: :root { --ink: #203448; --accent: #245b52; }
body { color: var(--ink); font-size: 1rem; line-height: 1.6; }
a:focus-visible, button:focus-visible {
  outline: 3px solid var(--accent); outline-offset: 3px;
}

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: CSS custom properties, contrast checker and keyboard

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Typography, colour, units and focus styles lab. Add the typography rules and compare paragraph readability at two text sizes.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add the typography rules and compare paragraph readability at two text sizes.

Expected: Line spacing scales rather than clipping text.

Step 2

Use Tab through links and the form. Record the focus outline on each surface.

Expected: Focus remains visibly identifiable.

Step 3

Add an error message with both text and colour. Turn the screen to grayscale or ignore colour.

Expected: The error remains understandable through its wording.

Expected: A small reusable style palette and keyboard/contrast observations.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A small reusable style palette and keyboard/contrast observations. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/css-type.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining relative lengths in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Line spacing scales rather than clipping text.

seeker: Build interview evidence for typography, colour, units and focus styles. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect typography, colour, units and focus styles to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A unit or colour choice alone does not establish accessibility. Check the rendered content, contrast and user settings.

Recall: Why should an error include text rather than red colour alone?

Interview: Explain typography, colour, units and focus styles using your own artifact. Defend the rule behind this scenario: Why should an error include text rather than red colour alone? Then explain one failure case and this limitation: A unit or colour choice alone does not establish accessibility. Check the rendered content, contrast and user settings.

Quiz: Why should an error include text rather than red colour alone?

CSS cannot render red reliably.

Meaning must remain available without distinguishing that colour.

Red always means success.

Reference: Meaning must remain available without distinguishing that colour. — People may perceive colour differently; text supplies an independent cue.

Sources:

Values · official reference: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Values_and_Units

W3C accessibility tutorials · official reference: https://www.w3.org/WAI/tutorials/

CSS foundations · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics

### Flexbox: arrange a row or column

Flexbox distributes items along one main axis. Use it for a toolbar, navigation row or a stack of aligned controls.

Container and axes
display:flex makes direct children flex items. flex-direction chooses the main axis. justify-content distributes along that axis; align-items works across it. Do not memorise left and right: direction and writing mode can change how axes map to the screen.

Flexible items
gap creates space between items. flex-wrap allows additional lines. The flex shorthand controls growth, shrinkage and basis. Items can still overflow because of intrinsic minimum sizes or unbreakable content. Inspect the actual item constraints before forcing a fixed width.

Preserve meaningful order
Visual reordering does not necessarily change DOM reading or keyboard order. Keep source order meaningful and use layout to present it. Test long translated labels and zoom; a toolbar should wrap rather than hide the action a learner needs.

Worked code:
.toolbar { display: flex; flex-wrap: wrap; gap: .75rem; align-items: center; }
.toolbar input { flex: 1 1 12rem; min-width: 0; }
.toolbar button { flex: 0 0 auto; }

The input can grow and shrink from a 12rem basis.
Wrapping handles narrow space without changing document order.

Mental model: Items share a flexible line that can grow, shrink or wrap.

Boundary: Flexbox is primarily one-dimensional. For coordinated rows and columns, Grid may describe the layout more clearly.

Worked example: .toolbar { display: flex; flex-wrap: wrap; gap: .75rem; align-items: center; }
.toolbar input { flex: 1 1 12rem; min-width: 0; }
.toolbar button { flex: 0 0 auto; }

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: CSS Flexbox and DevTools layout overlay

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Flexbox: arrange a row or column lab. Wrap a labelled input and button in a toolbar and apply the rule.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Wrap a labelled input and button in a toolbar and apply the rule.

Expected: Controls align when space permits.

Step 2

Narrow the viewport and replace the button text with a longer label.

Expected: Items wrap without disappearing.

Step 3

Switch flex-direction to column and explain which alignment now affects which axis.

Expected: Your explanation follows axes rather than fixed screen directions.

Expected: A responsive toolbar tested with long text and both axis directions.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A responsive toolbar tested with long text and both axis directions. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/css-flex.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining container and axes in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Controls align when space permits.

seeker: Build interview evidence for flexbox: arrange a row or column. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect flexbox: arrange a row or column to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Flexbox is primarily one-dimensional. For coordinated rows and columns, Grid may describe the layout more clearly.

Recall: What changes when flex-direction changes from row to column?

Interview: Explain flexbox: arrange a row or column using your own artifact. Defend the rule behind this scenario: What changes when flex-direction changes from row to column? Then explain one failure case and this limitation: Flexbox is primarily one-dimensional. For coordinated rows and columns, Grid may describe the layout more clearly.

Quiz: What changes when flex-direction changes from row to column?

The main axis.

The HTML source order.

The meaning of every button.

Reference: The main axis. — Flex direction changes the layout axis; source order and semantics remain separate.

Sources:

Flex · official reference: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Flexible_box_layout/Basic_concepts

Responsive · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

Box · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model

### Grid, normal flow and positioning

Use normal document flow by default. Add Grid for two-dimensional layout and positioning only when it serves a clear purpose.

Grid tracks
display:grid creates a grid container. grid-template-columns defines columns; fr distributes available space. gap separates tracks. minmax(0,1fr) lets a flexible track shrink below its content-based automatic minimum when appropriate. Keep code and long URLs from forcing the entire page wider.

Normal flow first
Block content normally follows previous content. Padding and gap usually solve spacing needs. position:relative keeps the element in flow while allowing an offset; absolute removes it from normal flow and uses a containing block. Do not use absolute coordinates for an entire document layout.

Sticky and responsive behaviour
Sticky positioning can keep navigation available within its scroll constraints. It needs a relevant inset such as top and can be affected by scrolling ancestors. Check whether it covers content at zoom. On phones, a collapsible outline can be more useful than a permanently narrow reading column.

Worked code:
.workspace { display: grid; grid-template-columns: 14rem minmax(0, 1fr); gap: 1rem; }
@media (max-width: 45rem) {
  .workspace { grid-template-columns: 1fr; }
}

A media query changes the grid rather than shrinking every font.
The HTML remains in meaningful order for the single-column layout.

Mental model: Grid lays out a set of tracks; positioning moves a box according to a separate reference.

Boundary: An attractive desktop grid is not automatically a usable mobile layout. Positioned content can overlap when text grows.

Worked example: .workspace { display: grid; grid-template-columns: 14rem minmax(0, 1fr); gap: 1rem; }
@media (max-width: 45rem) {
  .workspace { grid-template-columns: 1fr; }
}

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: CSS Grid, positioning and responsive inspector

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Grid, normal flow and positioning lab. Create a navigation aside and a main reading region using the workspace rule.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Create a navigation aside and a main reading region using the workspace rule.

Expected: They form two columns when enough room exists.

Step 2

Test at 320px and at 200% zoom with a long URL.

Expected: Content remains available in one column; long text does not widen the page.

Step 3

Temporarily absolutely position the main region and increase its text. Explain the overlap, then restore Grid.

Expected: The restored layout responds to content height.

Expected: A two-to-one-column layout and a documented positioning failure.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A two-to-one-column layout and a documented positioning failure. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/css-grid.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining grid tracks in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: They form two columns when enough room exists.

seeker: Build interview evidence for grid, normal flow and positioning. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect grid, normal flow and positioning to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: An attractive desktop grid is not automatically a usable mobile layout. Positioned content can overlap when text grows.

Recall: Why does absolute positioning often fail for an entire article layout?

Interview: Explain grid, normal flow and positioning using your own artifact. Defend the rule behind this scenario: Why does absolute positioning often fail for an entire article layout? Then explain one failure case and this limitation: An attractive desktop grid is not automatically a usable mobile layout. Positioned content can overlap when text grows.

Quiz: Why does absolute positioning often fail for an entire article layout?

It automatically changes semantics.

It removes boxes from normal flow, so growing content can overlap.

It cannot use pixels.

Reference: It removes boxes from normal flow, so growing content can overlap. — Out-of-flow positioning does not reserve normal layout space for changing content.

Sources:

Grid · official reference: https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Grid_layout/Basic_concepts

Position · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Positioning

Responsive · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

### Responsive design and the CSS checkpoint

Responsive design adapts content to available space and user settings. Build a useful small layout first, then enhance it.

Start with flexible content
Add the viewport meta tag, flexible containers and images that fit. Begin with a single readable column. Add a media query when the content has enough room for another arrangement. Avoid naming breakpoints after a particular phone; test the point where your layout actually stops working.

Test difficult content
Use a long heading, a long unbroken token and larger text. Check horizontal scrolling and clipped controls. Prefer wrapping and min-width:0 where the layout requires shrinking. Preserve useful code scrolling inside the code block rather than allowing the whole page to overflow.

Checkpoint: a responsive journal
Style your HTML checkpoint with typography, spacing, Flexbox controls and a Grid content region. Keep focus visible. If you add motion, respect prefers-reduced-motion and keep the interface understandable without animation. Save evidence at narrow and wide sizes.

Worked code:
main { width: min(100% - 2rem, 70rem); margin-inline: auto; }
pre { overflow: auto; max-width: 100%; }
@media (prefers-reduced-motion: reduce) {
  .animated { transition: none; animation: none; }
}

The main region leaves a flexible gutter without a fixed mobile width.
The code block handles its own overflow.

Mental model: The same tools arranged on desks of different sizes.

Boundary: A breakpoint is a design choice, not a guarantee about a device. Touch, keyboard, zoom and motion preferences vary independently.

Worked example: main { width: min(100% - 2rem, 70rem); margin-inline: auto; }
pre { overflow: auto; max-width: 100%; }
@media (prefers-reduced-motion: reduce) {
  .animated { transition: none; animation: none; }
}

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: Responsive DevTools, CSS media queries and reduced-motion setting

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Responsive design and the CSS checkpoint lab. Apply your stylesheet to the HTML journal and include the viewport meta tag.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Apply your stylesheet to the HTML journal and include the viewport meta tag.

Expected: The page uses the actual device viewport.

Step 2

Test at 320px, 768px and a wide desktop; test 200% zoom and long content.

Expected: Essential content and controls remain readable and reachable.

Step 3

Write a CSS checkpoint report with two screenshots and one repaired issue.

Expected: The report explains an observed layout decision, not just a claim that it is responsive.

Expected: A responsive journal with keyboard, zoom and overflow evidence.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A responsive journal with keyboard, zoom and overflow evidence. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/css-responsive.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining start with flexible content in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The page uses the actual device viewport.

seeker: Build interview evidence for responsive design and the css checkpoint. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect responsive design and the css checkpoint to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A breakpoint is a design choice, not a guarantee about a device. Touch, keyboard, zoom and motion preferences vary independently.

Recall: When should you add a layout breakpoint?

Interview: Explain responsive design and the css checkpoint using your own artifact. Defend the rule behind this scenario: When should you add a layout breakpoint? Then explain one failure case and this limitation: A breakpoint is a design choice, not a guarantee about a device. Touch, keyboard, zoom and motion preferences vary independently.

Quiz: When should you add a layout breakpoint?

Whenever content needs a different arrangement to remain usable.

Only at one popular phone width.

Every 10 pixels regardless of content.

Reference: Whenever content needs a different arrangement to remain usable. — Breakpoints should follow layout needs rather than a guessed device list.

Sources:

Responsive · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

W3C accessibility tutorials · official reference: https://www.w3.org/WAI/tutorials/

CSS foundations · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics

### What JavaScript is: values, variables and types

JavaScript runs instructions. Start with values and expressions in the Console before changing a page.

Values and declarations
Strings hold text, numbers support numeric operations and booleans represent true or false. null and undefined describe different absence cases. const prevents rebinding the variable; let allows reassignment. Use meaningful names and declare values before using them.

Conversion is a decision
The + operator can add numbers or concatenate strings. Convert user input deliberately with Number and reject inappropriate or non-finite values. Number("") produces zero, which may not be a valid answer to your form. Check empty text before treating it as a number.

Observe intermediate results
console.log lets you inspect values without building a UI. typeof helps inspect many primitive values, but has historical edge cases, including typeof null. Predict a result, run the expression and explain any difference. An unexpected value is evidence to investigate.

Worked code:
const text = "12";
const quantity = Number(text);
let total = quantity + 3;
console.log(text + 3, total); // "123", 15
console.log(typeof quantity); // "number"

The string plus a number concatenates in this example.
const protects the binding, not the contents of an object stored in it.

Mental model: A variable is a named reference to a value; the value has a type.

Boundary: A variable name does not enforce a business rule. Browser input values are strings even when they look like numbers.

Worked example: const text = "12";
const quantity = Number(text);
let total = quantity + 3;
console.log(text + 3, total); // "123", 15
console.log(typeof quantity); // "number"

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: JavaScript Console and debugger

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the What JavaScript is: values, variables and types lab. Open Console on your local starter and run the example one statement at a time.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Open Console on your local starter and run the example one statement at a time.

Expected: The string and numeric results differ as predicted.

Step 2

Try Number("") and Number("twelve"). Check Number.isFinite for each result.

Expected: Empty text becomes zero; invalid numeric text becomes NaN.

Step 3

Write a conversion function that rejects trimmed empty text before conversion.

Expected: Blank input is rejected instead of silently becoming a valid quantity.

Expected: A prediction table for string/number conversion and a blank-input guard.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A prediction table for string/number conversion and a blank-input guard. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/js-values.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining values and declarations in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The string and numeric results differ as predicted.

seeker: Build interview evidence for what javascript is: values, variables and types. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect what javascript is: values, variables and types to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A variable name does not enforce a business rule. Browser input values are strings even when they look like numbers.

Recall: An input contains the string "12". What does value + 3 produce before conversion?

Interview: Explain what javascript is: values, variables and types using your own artifact. Defend the rule behind this scenario: An input contains the string "12". What does value + 3 produce before conversion? Then explain one failure case and this limitation: A variable name does not enforce a business rule. Browser input values are strings even when they look like numbers.

Quiz: An input contains the string "12". What does value + 3 produce before conversion?

15

"123"

A guaranteed TypeError

Reference: "123" — With a string operand, this + expression concatenates. Convert deliberately for arithmetic.

Sources:

JavaScript values and types · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types

Control · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling

Functions · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

### Operators, comparisons and decisions

A program chooses behaviour using conditions. Make the rule explicit and test its boundaries.

Equality and logical operators
Use === and !== for equality without type coercion. && and || short-circuit and return operand values, not always booleans. ! negates truthiness. Zero, empty text, null, undefined and NaN are falsy, so a truthiness test may reject a valid zero.

Branches and boundary cases
if executes a block when its condition is truthy; else handles the other case. Use braces for clarity. Write the intended valid range first, then test just below, at and just above each boundary. Avoid overlapping branches that hide an allowed state.

Default values
The nullish operator ?? supplies a fallback for null or undefined while preserving zero and empty text. || supplies a fallback for every falsy value. Choose based on meaning, not the shortest expression. Missing and intentionally empty can be different product states.

Worked code:
function labelMinutes(value) {
  if (!Number.isFinite(value) || value < 0) return "Invalid";
  if (value === 0) return "Rest day";
  return `${value} minutes`;
}
console.log(labelMinutes(0));

Zero is a valid explicit branch, not treated as missing.
Invalid values are rejected before the success branches.

Mental model: A decision gate with a stated condition, rather than a guess about what looks true.

Boundary: A boolean check only enforces the rule you wrote. It cannot infer missing product requirements.

Worked example: function labelMinutes(value) {
  if (!Number.isFinite(value) || value < 0) return "Invalid";
  if (value === 0) return "Rest day";
  return `${value} minutes`;
}
console.log(labelMinutes(0));

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: JavaScript comparisons and Console

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Operators, comparisons and decisions lab. Run the example with -1, 0, 1 and NaN. Predict each result first.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Run the example with -1, 0, 1 and NaN. Predict each result first.

Expected: Only zero gives Rest day; invalid values are rejected.

Step 2

Compare 0 || 25 with 0 ?? 25 in Console.

Expected: The first produces 25; the second preserves 0.

Step 3

Change the rule to a maximum of 120 minutes and test 119, 120 and 121.

Expected: The new upper boundary is enforced deliberately.

Expected: A boundary table and explicit branch rules for allowed study minutes.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A boundary table and explicit branch rules for allowed study minutes. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/js-conditions.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining equality and logical operators in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Only zero gives Rest day; invalid values are rejected.

seeker: Build interview evidence for operators, comparisons and decisions. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect operators, comparisons and decisions to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A boolean check only enforces the rule you wrote. It cannot infer missing product requirements.

Recall: Zero is valid, but null means missing. Which fallback preserves zero?

Interview: Explain operators, comparisons and decisions using your own artifact. Defend the rule behind this scenario: Zero is valid, but null means missing. Which fallback preserves zero? Then explain one failure case and this limitation: A boolean check only enforces the rule you wrote. It cannot infer missing product requirements.

Quiz: Zero is valid, but null means missing. Which fallback preserves zero?

value || 25

Boolean(value) || 25

value ?? 25

Reference: value ?? 25 — Nullish coalescing falls back only for null or undefined.

Sources:

Control · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling

JavaScript values and types · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types

Functions · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

### Functions, parameters, return values and scope

A function groups a named operation. Give it clear inputs and return a result that another part of the program can use.

Call versus define
A function definition describes work; calling it performs the work. Parameters are local names in the definition and arguments are the supplied values. return ends that call and supplies a result. Logging a value is not the same as returning it to the caller.

Local scope
let and const are block-scoped. Names defined inside a function are not automatically available outside it. An inner function can use outer variables through a closure. Avoid accidental globals: they couple unrelated code and make tests depend on execution order.

Small pure calculations
For a total calculation, accept quantities and prices as arguments, reject invalid input and return the number. Keep DOM updates in a separate function. Then you can check the calculation without constructing a page. Name the units, such as integer cents, to avoid ambiguity.

Worked code:
function totalCents(priceCents, quantity) {
  if (!Number.isInteger(quantity) || quantity < 0) throw new Error("Invalid quantity");
  return priceCents * quantity;
}
const total = totalCents(125, 3);
console.log(total); // 375

Arguments 125 and 3 bind to the two parameters for this call.
The returned result is stored in total; console.log only displays it.

Mental model: A small workshop with an entrance for inputs and an exit for a result.

Boundary: A function can also change outside state. Prefer explicit inputs and outputs for calculations so they are easier to test.

Worked example: function totalCents(priceCents, quantity) {
  if (!Number.isInteger(quantity) || quantity < 0) throw new Error("Invalid quantity");
  return priceCents * quantity;
}
const total = totalCents(125, 3);
console.log(total); // 375

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: JavaScript functions, scope and Console

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Functions, parameters, return values and scope lab. Define totalCents in Console or a saved script and call it with 125, 3.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Define totalCents in Console or a saved script and call it with 125, 3.

Expected: The return value is 375.

Step 2

Call it with quantities 0 and -1 and record the different outcomes.

Expected: Zero returns 0; negative quantity throws.

Step 3

Add a guard for a nonnegative integer price and test it independently.

Expected: Both input contracts are enforced without touching the DOM.

Expected: A reusable total function and tests for both input boundaries.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A reusable total function and tests for both input boundaries. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/js-functions.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining call versus define in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The return value is 375.

seeker: Build interview evidence for functions, parameters, return values and scope. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect functions, parameters, return values and scope to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A function can also change outside state. Prefer explicit inputs and outputs for calculations so they are easier to test.

Recall: A function only calls console.log(5) and has no return statement. What does the call return?

Interview: Explain functions, parameters, return values and scope using your own artifact. Defend the rule behind this scenario: A function only calls console.log(5) and has no return statement. What does the call return? Then explain one failure case and this limitation: A function can also change outside state. Prefer explicit inputs and outputs for calculations so they are easier to test.

Quiz: A function only calls console.log(5) and has no return statement. What does the call return?

5

undefined

The console panel

Reference: undefined — Logging is an effect; without an explicit returned value the call returns undefined.

Sources:

Functions · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

Control · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling

JavaScript values and types · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types

### Arrays, loops and transformations

An array keeps an ordered collection. Learn to visit, transform and select items without confusing indices with values.

Visit items
Use array[index] to read a position and length to inspect the item count. for...of visits values. A traditional for loop is useful when the index matters. Stop conditions must eventually become false; an accidental endless loop can freeze the main browser thread.

Map and filter
map creates an array of transformed results; filter creates an array of items that pass a condition. Neither is a substitute for deciding a clear rule. The callback receives each item. Do not mutate the original item accidentally if other code relies on it remaining unchanged.

Choose the right operation
find returns the first match or undefined. some asks whether a match exists. reduce combines values into an accumulator, but a straightforward loop may be clearer for a beginner. Test an empty array as well as the normal case. Name results according to their meaning.

Worked code:
const minutes = [10, 25, 40];
const longSessions = minutes.filter(n => n >= 25);
const labels = longSessions.map(n => `${n} min`);
for (const label of labels) console.log(label);

filter keeps 25 and 40 without changing minutes.
map returns text labels; for...of visits each label.

Mental model: A numbered shelf whose first slot is numbered zero.

Boundary: An array’s index is a position, not necessarily a stable identity for an item that can move.

Worked example: const minutes = [10, 25, 40];
const longSessions = minutes.filter(n => n >= 25);
const labels = longSessions.map(n => `${n} min`);
for (const label of labels) console.log(label);

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: JavaScript arrays and loops

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Arrays, loops and transformations lab. Run the example and inspect all three arrays.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Run the example and inspect all three arrays.

Expected: The original stays [10,25,40]; labels contains two strings.

Step 2

Repeat with an empty input array.

Expected: The operations return empty arrays without an exception.

Step 3

Write a function that returns only session lengths between 1 and 120. Test boundary values.

Expected: Invalid durations are excluded using your stated rule.

Expected: A collection-transform function with empty and boundary examples.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A collection-transform function with empty and boundary examples. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/js-arrays.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining visit items in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The original stays [10,25,40]; labels contains two strings.

seeker: Build interview evidence for arrays, loops and transformations. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect arrays, loops and transformations to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: An array’s index is a position, not necessarily a stable identity for an item that can move.

Recall: Which operation creates an array containing only items that pass a condition?

Interview: Explain arrays, loops and transformations using your own artifact. Defend the rule behind this scenario: Which operation creates an array containing only items that pass a condition? Then explain one failure case and this limitation: An array’s index is a position, not necessarily a stable identity for an item that can move.

Quiz: Which operation creates an array containing only items that pass a condition?

filter

find

console.log

Reference: filter — filter produces the matching collection; find produces at most one item.

Sources:

Arrays · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Indexed_collections

Loops · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Loops_and_iteration

Functions · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

### Objects, identity, destructuring and immutable updates

An object groups named properties. Use objects for records and stable ids for items whose positions can change.

Properties and identity
Read a property with dot notation or a bracket key. Arrays of objects model lists of related records. Give each record an id that does not depend on its current position. When a list is filtered or sorted, the item should remain the same logical item.

References and copying
Two variables can refer to the same object. Changing a property through one reference affects the shared object. Spread syntax creates a new outer object. If a nested property contains another object, that nested value is still a reference unless explicitly copied.

Destructure and update clearly
Destructuring extracts named values. To update one task in an array, map each task and return a new object for the matching id. Keep unchanged objects for the others. This makes before/after comparisons and UI state updates easier to reason about.

Worked code:
const tasks = [{ id: "a", title: "Read", done: false }];
const updated = tasks.map(task =>
  task.id === "a" ? { ...task, done: true } : task
);
const { title } = updated[0];
console.log(title, tasks[0].done, updated[0].done);

The old task stays false because the matching object is copied.
The id remains stable while a field changes.

Mental model: A record with labelled fields rather than a shelf position.

Boundary: Spreading an object makes a shallow copy. Nested objects may still be shared.

Worked example: const tasks = [{ id: "a", title: "Read", done: false }];
const updated = tasks.map(task =>
  task.id === "a" ? { ...task, done: true } : task
);
const { title } = updated[0];
console.log(title, tasks[0].done, updated[0].done);

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: JavaScript objects, spread and array map

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Objects, identity, destructuring and immutable updates lab. Run the example and compare the old and new done fields.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Run the example and compare the old and new done fields.

Expected: The original is false and the updated value is true.

Step 2

Add a second task and update only id a.

Expected: The second task keeps its original values.

Step 3

Add a nested settings object and demonstrate why a shallow copy shares it. Then copy the nested object when updating.

Expected: Your notes distinguish outer copying from deep independence.

Expected: A stable-id update function and a shallow-copy counterexample.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A stable-id update function and a shallow-copy counterexample. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/js-objects.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining properties and identity in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The original is false and the updated value is true.

seeker: Build interview evidence for objects, identity, destructuring and immutable updates. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect objects, identity, destructuring and immutable updates to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Spreading an object makes a shallow copy. Nested objects may still be shared.

Recall: What does {...task} guarantee?

Interview: Explain objects, identity, destructuring and immutable updates using your own artifact. Defend the rule behind this scenario: What does {...task} guarantee? Then explain one failure case and this limitation: Spreading an object makes a shallow copy. Nested objects may still be shared.

Quiz: What does {...task} guarantee?

Every nested object is recursively copied.

A new outer object with copied property values.

The original object can no longer change.

Reference: A new outer object with copied property values. — Spread is shallow; object-valued properties can still point at shared nested objects.

Sources:

Objects · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_objects

Arrays · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Indexed_collections

Functions · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

### Errors, debugger and the JavaScript checkpoint

Debugging means explaining an observed failure with evidence. Learn syntax errors, runtime errors and incorrect results separately.

Identify the failure category
A syntax error prevents code from being parsed. A runtime error occurs while executing, such as reading an unavailable property. A logic defect produces an incorrect answer without necessarily throwing. Read the first relevant error and its source location before following secondary symptoms.

Pause and inspect
Set a breakpoint on a line in DevTools Sources. Reproduce the action, inspect local values, and step through the next statements. Compare actual values to a prediction. Avoid adding logging that exposes real secrets or personal data; learning fixtures use synthetic records.

Turn a repair into a check
A good bug report records input, expected result, actual result and the smallest correction. Keep a repeatable check for the boundary that failed. Complete the language checkpoint by combining a guarded function, an array transformation and a stable-id object update.

Worked code:
function acceptedMinutes(raw) {
  const text = raw.trim();
  const value = Number(text);
  if (!text || !Number.isFinite(value) || value < 0) throw new Error("Invalid minutes");
  return value;
}

The empty-text guard prevents Number("") from accepting a blank as zero.
Test the function’s contract, not whether Console printed something.

Mental model: A detective’s notebook: reproduce, observe, form a hypothesis and test one change.

Boundary: A program that runs without exceptions can still implement the wrong rule. Tests need meaningful expected outcomes.

Worked example: function acceptedMinutes(raw) {
  const text = raw.trim();
  const value = Number(text);
  if (!text || !Number.isFinite(value) || value < 0) throw new Error("Invalid minutes");
  return value;
}

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: Browser debugger and assertions

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Errors, debugger and the JavaScript checkpoint lab. Use a deliberately broken version that omits !text. Reproduce the blank-input defect.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Use a deliberately broken version that omits !text. Reproduce the blank-input defect.

Expected: Blank input is incorrectly accepted as 0.

Step 2

Pause inside the function and inspect text and value; add the guard and rerun.

Expected: The evidence explains why the correction works.

Step 3

Record blank, zero, positive and invalid-text checks in your journal.

Expected: All four cases have explicit expectations and observed results.

Expected: A minimal bug report, corrected validation and the language checkpoint functions.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A minimal bug report, corrected validation and the language checkpoint functions. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/js-errors.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining identify the failure category in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Blank input is incorrectly accepted as 0.

seeker: Build interview evidence for errors, debugger and the javascript checkpoint. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect errors, debugger and the javascript checkpoint to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A program that runs without exceptions can still implement the wrong rule. Tests need meaningful expected outcomes.

Recall: A function returns the wrong total but throws no exception. Is it correct?

Interview: Explain errors, debugger and the javascript checkpoint using your own artifact. Defend the rule behind this scenario: A function returns the wrong total but throws no exception. Is it correct? Then explain one failure case and this limitation: A program that runs without exceptions can still implement the wrong rule. Tests need meaningful expected outcomes.

Quiz: A function returns the wrong total but throws no exception. Is it correct?

Yes, no exception means success.

Only if Console is empty.

No; compare the result against the intended rule.

Reference: No; compare the result against the intended rule. — Logic errors need behavioural assertions, not just an absence of runtime errors.

Sources:

Control · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling

JavaScript values and types · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types

Functions · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

### DOM, events and safe page updates

The DOM is the browser’s object representation of the document. JavaScript can select nodes, react to events and change content.

Select after the element exists
querySelector returns the first matching element or null. An external script with defer runs after parsing, so it can find the form. Check the selector and timing when a node is missing. Avoid silently assuming every query succeeded in a reusable component.

Listen to the meaningful event
Use addEventListener to register a handler. submit handles form submission, including keyboard use. preventDefault stops the form’s default navigation when you deliberately handle it in JavaScript. It does not validate the value; write that rule explicitly.

Create text safely
Create an li, set its textContent and append it to the list. A user-controlled string should remain text rather than being parsed as HTML. Associate feedback with a status region and preserve usable focus. A successful local update is a local result, not a saved server record.

Worked code:
const form = document.querySelector("#taskForm");
const input = document.querySelector("#task");
const list = document.querySelector("#tasks");
form.addEventListener("submit", event => {
  event.preventDefault();
  const title = input.value.trim();
  if (!title) return;
  const item = document.createElement("li");
  item.textContent = title;
  list.append(item);
});

The form, input and list ids exist in the downloaded web starter.
textContent keeps angle-bracket input literal.

Mental model: A live tree whose nodes can be inspected and changed.

Boundary: Updating the DOM changes this browser view. It does not automatically persist data or prove server acceptance.

Worked example: const form = document.querySelector("#taskForm");
const input = document.querySelector("#task");
const list = document.querySelector("#tasks");
form.addEventListener("submit", event => {
  event.preventDefault();
  const title = input.value.trim();
  if (!title) return;
  const item = document.createElement("li");
  item.textContent = title;
  list.append(item);
});

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: DOM APIs, submit events and accessibility inspector

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the DOM, events and safe page updates lab. In a copy of course-labs/web, replace app.js with the example. Submit using Enter.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

In a copy of course-labs/web, replace app.js with the example. Submit using Enter.

Expected: A nonempty title creates one list item without navigation.

Step 2

Try spaces and the text <b>Read</b>.

Expected: Spaces add nothing and the angle brackets remain literal.

Step 3

Add an accessible status message for rejection/success and keep focus in the input.

Expected: Keyboard users can understand the result and add another task.

Expected: A keyboard-usable task form with safe DOM updates and visible feedback.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A keyboard-usable task form with safe DOM updates and visible feedback. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/dom-events.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining select after the element exists in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: A nonempty title creates one list item without navigation.

seeker: Build interview evidence for dom, events and safe page updates. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect dom, events and safe page updates to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Updating the DOM changes this browser view. It does not automatically persist data or prove server acceptance.

Recall: Which method should display an untrusted task title as literal text?

Interview: Explain dom, events and safe page updates using your own artifact. Defend the rule behind this scenario: Which method should display an untrusted task title as literal text? Then explain one failure case and this limitation: Updating the DOM changes this browser view. It does not automatically persist data or prove server acceptance.

Quiz: Which method should display an untrusted task title as literal text?

innerHTML

textContent

document.write

Reference: textContent — textContent treats the value as text rather than interpreting markup.

Sources:

DOM scripting · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting

Events · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events

Security · official reference: https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html

### Browser storage, JSON and recovery

Keep a small local learning list across reloads, while being honest about where the data lives and how it can fail.

Serialise deliberately
localStorage stores strings. JSON.stringify converts a supported value into JSON text; JSON.parse reads it back and may throw on invalid text. Parsed data still needs shape validation before the UI trusts it. Dates and class instances do not automatically regain their original behaviour.

Separate state from rendering
Keep the tasks array as the source of truth. Load it once, validate it, then render. Save after accepted changes. Do not treat whatever happens to be in the DOM as your only record. Include stable ids so saved items retain identity after reordering.

Handle unavailable data
Wrap storage access and parsing in error handling. Distinguish no saved data from corrupted data. Offer a fresh empty state or an export without quietly claiming persistence succeeded. Use the local HTTP lab for consistent origin behaviour; file-URL storage behaviour is not a portable contract.

Worked code:
function loadTitles() {
  try {
    const raw = localStorage.getItem("practice-titles-v1");
    const value = raw === null ? [] : JSON.parse(raw);
    if (!Array.isArray(value) || !value.every(x => typeof x === "string")) throw new Error("Invalid shape");
    return { titles: value, error: null };
  } catch { return { titles: [], error: "Saved data is unavailable" }; }
}

Parsing succeeds only for valid JSON; the array/string checks validate its shape.
The error is returned explicitly instead of claiming an empty list was successfully restored.

Mental model: A notebook kept by one browser for one origin.

Boundary: localStorage is not an account, a backup service or a secure store for secrets. Browser clearing, quota limits and origin changes affect it.

Worked example: function loadTitles() {
  try {
    const raw = localStorage.getItem("practice-titles-v1");
    const value = raw === null ? [] : JSON.parse(raw);
    if (!Array.isArray(value) || !value.every(x => typeof x === "string")) throw new Error("Invalid shape");
    return { titles: value, error: null };
  } catch { return { titles: [], error: "Saved data is unavailable" }; }
}

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: localStorage, JSON and DevTools Application panel

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Browser storage, JSON and recovery lab. Start the supplied local server from course-labs, open /web/ and save a synthetic title list under practice-titles-v1.

Terminal folder: course-labs

```
python3 serve.py
# Windows alternative: py serve.py
```

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Start the supplied local server from course-labs, open /web/ and save a synthetic title list under practice-titles-v1.

Expected: Reloading the same origin can read that list.

Step 2

Set that key to malformed JSON in DevTools and call loadTitles.

Expected: An explicit recovery result is returned without crashing the whole page.

Step 3

Handle a failing setItem call in your save function and show a persistence warning.

Expected: The current session stays usable while the limitation is visible.

Expected: A local-only task list with valid, missing and corrupt-data recovery cases.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A local-only task list with valid, missing and corrupt-data recovery cases. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/browser-storage.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining serialise deliberately in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Reloading the same origin can read that list.

seeker: Build interview evidence for browser storage, json and recovery. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect browser storage, json and recovery to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: localStorage is not an account, a backup service or a secure store for secrets. Browser clearing, quota limits and origin changes affect it.

Recall: JSON.parse returns an object successfully. Is it safe to assume it contains your task schema?

Interview: Explain browser storage, json and recovery using your own artifact. Defend the rule behind this scenario: JSON.parse returns an object successfully. Is it safe to assume it contains your task schema? Then explain one failure case and this limitation: localStorage is not an account, a backup service or a secure store for secrets. Browser clearing, quota limits and origin changes affect it.

Quiz: JSON.parse returns an object successfully. Is it safe to assume it contains your task schema?

Yes, parsing validates business fields.

Only when the file is small.

No; validate the parsed shape and values.

Reference: No; validate the parsed shape and values. — Parsing establishes JSON syntax, not the required application contract.

Sources:

Storage · official reference: https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage

Objects · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_objects

Control · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling

### Beginner project: a responsive learning journal

Bring HTML, CSS and JavaScript together in one small product. Build from requirements instead of copying a finished screenshot.

Define the user task
A learner should add a study task, see it listed, mark it complete and understand rejected input. Write acceptance examples before implementation: blank title, a normal title, literal markup and keyboard submission. Keep the scope small enough to explain every line.

Build in layers
Begin with semantic HTML that can be read without CSS. Add responsive styling and visible focus. Then connect a state array to DOM rendering. Add optional local persistence only after the normal and invalid-input paths work. Keep the reusable validation function separate from event handling.

Review and present
Test at narrow and wide widths, with keyboard only and with storage failure simulated. Save screenshots and a short bug diary. A portfolio README should explain the user problem, setup, decisions, checks and limitations. Describe this as your learning project rather than employment experience.

Worked code:
// Acceptance table (write expected results before building)
// "   "       -> zero tasks, visible error
// "Read CSS"  -> one task with a stable id
// "<b>x</b>"  -> literal text, no HTML element
// reload       -> restored state or an explicit storage warning

These are observable product requirements, not commands.
A checkbox labelled complete records user intent; do not mark work done merely because a page opened.

Mental model: A vertical slice: one user task carried from input through validation to useful feedback.

Boundary: This project is a browser-only learning artifact. It does not implement accounts, collaborative editing or guaranteed storage.

Worked example: // Acceptance table (write expected results before building)
// "   "       -> zero tasks, visible error
// "Read CSS"  -> one task with a stable id
// "<b>x</b>"  -> literal text, no HTML element
// reload       -> restored state or an explicit storage warning

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: HTML, CSS, JavaScript, Git; optional localStorage

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Beginner project: a responsive learning journal lab. Copy course-labs/web into your own journal folder. Write the acceptance table and replace its reference behaviour with your own implementation.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Copy course-labs/web into your own journal folder. Write the acceptance table and replace its reference behaviour with your own implementation.

Expected: Your repository contains your changes and the original requirements.

Step 2

Add task completion and a filter using stable ids; keep old tasks unchanged when updating one.

Expected: All, active and completed views reflect the same underlying state.

Step 3

Open course-labs/web/checks.html and read all four results. Add checks for your changed behaviour and complete manual keyboard/viewport tests.

Expected: Reference checks pass; your evidence separately covers your implementation changes.

Expected: A responsive journal, source repository, acceptance matrix, screenshots and README with limitations.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A responsive journal, source repository, acceptance matrix, screenshots and README with limitations. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/beginner-project.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining define the user task in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Your repository contains your changes and the original requirements.

seeker: Build interview evidence for beginner project: a responsive learning journal. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect beginner project: a responsive learning journal to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: This project is a browser-only learning artifact. It does not implement accounts, collaborative editing or guaranteed storage.

Recall: What is strongest portfolio evidence for this project?

Interview: Explain beginner project: a responsive learning journal using your own artifact. Defend the rule behind this scenario: What is strongest portfolio evidence for this project? Then explain one failure case and this limitation: This project is a browser-only learning artifact. It does not implement accounts, collaborative editing or guaranteed storage.

Quiz: What is strongest portfolio evidence for this project?

A screenshot alone.

A repository with setup, meaningful checks and an explanation of tradeoffs.

A claim that the app is production-certified.

Reference: A repository with setup, meaningful checks and an explanation of tradeoffs. — A reviewer needs reproducible behaviour and reasoning, not just an attractive image.

Sources:

Your first website · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website

W3C accessibility tutorials · official reference: https://www.w3.org/WAI/tutorials/

Git changes and commits · official reference: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository

### Request and response

A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. In this role, work through: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. The practical workshop develops this into: Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.

Mental model: A service counter: the request is your order and the response is the result.

Boundary: Networks can time out; sending an order does not prove it was fulfilled.

Role application: A form is a conversation: name the question, accept the reply, then acknowledge it.

HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails.

Subtopic: A request has a method and a target

The browser asks for a resource. GET usually reads; POST sends data for processing. A URL identifies the target. A request may also have headers and a body.

Picture it: Address + action + optional contents on an envelope.

```
GET /api/tasks HTTP/1.1
Host: localhost

# A separate request to add a task:
POST /api/tasks HTTP/1.1
Content-Type: application/json

{"title":"Read docs"}
```

Try: Draw the two messages. Underline each method and target. Label the JSON as the body, not part of the URL. These are message examples, not terminal commands.

Expected: GET and POST share a target but ask for different actions.

Quick check: Does the URL alone describe the entire request?

Reasoning: No. The method, headers and any body also affect its meaning.

Reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

Subtopic: A response is evidence, not a guarantee

A response includes a status and content. A 404 is an HTTP response: some HTTP component answered. A timeout gives no HTTP status and leaves the operation outcome uncertain.

Picture it: A written reply differs from hearing nothing back.

```
HTTP/1.1 404 Not Found
Content-Type: application/json

{"error":"Unknown route"}
```

Try: Compare this reply with a request that times out. Write what you know and what remains unknown in each case.

Expected: 404: investigate the route or responding component. Timeout: investigate transport and whether the operation happened.

Quick check: Does a timeout prove that nothing was created?

Reasoning: No. The server may have processed the request before the response was lost.

Reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status

Worked example: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.

Shared foundation example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Frontend Developer: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.

Predict the worked case

Read this case without running a tool: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in request and response.

Connect the concept to the role

Apply this rule: A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Networks can time out; sending an order does not prove it was fulfilled.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies request and response to this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Request and response; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with request and response. Use the glossary below, then write your prediction for: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain request and response using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate request and response to a system or workflow you know. Explain request and response using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Draw the request and response for adding one task.

Interview: Explain request and response using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops.

Quiz: After the Semantic forms and feedback rehearsal, check this foundation: A request returns HTTP 404. Which boundary has evidence of working?

An HTTP server returned a response; inspect the route next.

The request never reached any HTTP server.

The server has confirmed that the resource exists.

Reference: An HTTP server returned a response; inspect the route next. — 404 is an HTTP response, not a transport timeout. It does not prove which component generated it or that the business operation succeeded.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: A request has a method and a target: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

Frontend reference: A response is evidence, not a guarantee: https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status

### HTML, CSS & JavaScript applied review

Original topic: Semantic forms and feedback

HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails. In this role, work through: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. The practical workshop develops this into: Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.

Mental model: A form is a conversation: name the question, accept the reply, then acknowledge it.

Boundary: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.

Subtopic: HTML gives content a structure

An element has a meaning and may contain text or other elements. A tag such as <h1> opens an element; </h1> closes it. Use a heading for a heading and a button for an action. Begin in core/index.html in the downloaded pack; it runs in a browser without installation.

Picture it: The outline of a document, before its visual design.

```
<main>
  <h1>My study tasks</h1>
  <p>Add one small task below.</p>
</main>
```

Try: Open core/index.html. Change the heading and add a paragraph inside main. Reload the page.

Expected: Both changes appear; the heading remains the page’s main heading.

Quick check: Why use h1 instead of a large styled paragraph?

Reasoning: It expresses heading structure, independently of its appearance.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

Subtopic: Labels connect a question to an input

The label’s for value must match the input’s id. Clicking the label then targets its control. A placeholder is not a replacement for a persistent label.

Picture it: A name tag attached to the right control.

```
<label for="task">Task title</label>
<input id="task" name="title">
<button type="submit">Add task</button>
```

Try: In core/index.html, click Task title, then use Tab to reach Add task. Temporarily change for="task" to for="missing" and compare. Restore it.

Expected: The matching label focuses the input. The mismatched label loses that association.

Quick check: Which attribute joins the label to its input?

Reasoning: The label’s for points to the input’s id.

Reference: https://www.w3.org/WAI/tutorials/forms/labels/

Subtopic: CSS controls space: the box model

A box has content, padding, border and margin. With border-box, a declared width includes padding and border. Margin remains outside. In the example, input selects elements and the braces contain property: value declarations.

Picture it: A parcel: contents, inner cushioning, wrapping and space around it.

```
input {
  box-sizing: border-box;
  width: 100%;
  padding: 12px;
  border: 1px solid #aab8c5;
}
form { max-width: 360px; }
```

Try: Use browser DevTools to change input padding from 12px to 24px. Compare border-box with content-box.

Expected: Border-box keeps the declared outer border width; content-box adds padding and border beyond the content width.

Quick check: Is margin included in border-box width?

Reasoning: No. Margin is outside the border.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model

Subtopic: JavaScript handles the form event

Listen for submit on the form. Prevent the default navigation, trim the input, then update a status message. Load this script after the form exists. Here const names a value, trim() removes surrounding spaces, and the handler function runs when submission occurs.

Picture it: An event is a signal; the handler decides how to respond.

```
form.addEventListener("submit", event => {
  event.preventDefault();
  const title = input.value.trim();
  status.textContent = title ? `Added: ${title}` : "Enter a task title.";
});
```

Try: Read the existing handler in core/index.html. Submit spaces, then Read docs. Change the success message and repeat.

Expected: Spaces show an error; a nonempty title gives feedback without reloading the page.

Quick check: Why listen for submit rather than only a button click?

Reasoning: Submit handles form submission, including keyboard activation.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events

Subtopic: Make the layout work on a small screen

Use flexible widths and a viewport meta tag. A media query can change layout when space is limited. Test the content at narrow widths instead of assuming a phone model.

Picture it: The same content rearranged to fit a smaller desk.

```
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  main { max-width: 640px; margin: auto; padding: 20px; }
  input { width: 100%; box-sizing: border-box; }
</style>
```

Try: Resize core/index.html to about 320px wide using responsive browser tools. Increase the title length and check again.

Expected: The input fits its container and text wraps without horizontal page scrolling.

Quick check: Does a viewport tag alone make every fixed-width layout responsive?

Reasoning: No. Layout sizes and content must also adapt.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

Worked example: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Frontend Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.

```
node app.mjs
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Role workshop · debug and verify

If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save form-audit.md with HTML diff, keyboard sequence and two observed outcomes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Expected: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Troubleshoot: The role exercise differs from the prediction: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: form-audit.md with HTML diff, keyboard sequence and two observed outcomes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with semantic forms and feedback. Use the glossary below, then write your prediction for: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain semantic forms and feedback using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate semantic forms and feedback to a system or workflow you know. Explain semantic forms and feedback using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.

Interview: Explain semantic forms and feedback using this case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.

Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse. — HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails. Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: HTML gives content a structure: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

Frontend reference: Labels connect a question to an input: https://www.w3.org/WAI/tutorials/forms/labels/

Frontend reference: CSS controls space: the box model: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model

Frontend reference: JavaScript handles the form event: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events

Frontend reference: Make the layout work on a small screen: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Validation at a boundary: Check input before storing or using it. Client checks help people; the server must also enforce the rule.

Apply validation at a boundary in Frontend Developer: Use the concept to complete this role exercise: Show loading, empty and error states without losing typed input

Rendering server state: The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch.

### Modules, npm and a reproducible development setup

A module exposes a deliberate public interface. A package manager installs dependencies; a build tool transforms and serves source files.

ES modules
Use export to expose a function and import to consume it. Browser module scripts use type="module" and should be served over HTTP. Relative imports need correct paths. A module’s top-level scope is separate from other modules, which reduces accidental global coupling.

Node, npm and Vite
Node runs JavaScript outside the browser. npm installs packages and runs scripts from package.json. Vite provides a development server and production build; it is not a production API server. Use a supported Node LTS version that meets the current Vite requirement. Check node -v and npm -v before installation.

Lock dependencies
The supplied react-app project declares exact direct dependency versions and includes a lockfile. npm ci installs from that lockfile and fails if it disagrees with package.json. Commit reviewed updates together with their lockfile changes. A tool warning should be investigated rather than suppressed without explanation.

Worked code:
// math.js
export function double(value) { return value * 2; }
// main.js
import { double } from "./math.js";
console.log(double(4));

A named export and import agree on the public function name.
The supplied project can be rebuilt from its committed lockfile.

Mental model: Modules are rooms with named doors; a lockfile records the exact supplies used to build them.

Boundary: Installing a package does not make its code safe or necessary. Review dependencies and keep secrets out of client bundles.

Worked example: // math.js
export function double(value) { return value * 2; }
// main.js
import { double } from "./math.js";
console.log(double(4));

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: Node.js LTS, npm, ES modules and Vite

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Modules, npm and a reproducible development setup lab. Extract the ZIP, open course-labs/react-app, verify a supported Node LTS and run npm ci.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Extract the ZIP, open course-labs/react-app, verify a supported Node LTS and run npm ci.

Expected: Dependencies install from the included lockfile.

Step 2

Run npm run dev -- --host 127.0.0.1 and open the printed local URL. Then run npm run build in another terminal.

Expected: The development UI loads and the production output appears in dist.

Step 3

Move a pure calculation into a named module and import it from its test.

Expected: The build and test resolve the explicit module interface.

Expected: A working development environment and a tested named module.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A working development environment and a tested named module. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/modules-tooling.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining es modules in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Dependencies install from the included lockfile.

seeker: Build interview evidence for modules, npm and a reproducible development setup. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect modules, npm and a reproducible development setup to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Installing a package does not make its code safe or necessary. Review dependencies and keep secrets out of client bundles.

Recall: Which file captures resolved dependency versions for reproducible npm installs?

Interview: Explain modules, npm and a reproducible development setup using your own artifact. Defend the rule behind this scenario: Which file captures resolved dependency versions for reproducible npm installs? Then explain one failure case and this limitation: Installing a package does not make its code safe or necessary. Review dependencies and keep secrets out of client bundles.

Quiz: Which file captures resolved dependency versions for reproducible npm installs?

A screenshot of node_modules.

package-lock.json.

The browser history.

Reference: package-lock.json. — The lockfile captures the resolved dependency graph; npm ci consumes it.

Sources:

Modules · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

Node.js introduction · official reference: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

Vite guide · official reference: https://vite.dev/guide/

### Event loop, promises and async/await

Asynchronous work finishes later. Structure the result and failure paths without blocking the main thread.

Promise states
A promise represents an eventual fulfilment or rejection. .then handles a fulfilled value and .catch handles rejection. Promise callbacks run after the current synchronous execution finishes. Do not assume that starting two operations makes their completion order predictable.

Await and errors
An async function returns a promise. await pauses that function until its awaited value settles; it does not pause the whole browser. Use try/catch around awaited work when this function owns the recovery decision. A rejected promise that is never observed can become an unhandled rejection.

Concurrency deliberately
awaiting independent operations one after another adds their waiting times. Promise.all can wait for independent work together, but rejects when one input rejects. Decide whether partial results are useful before choosing a combinator. Always make loading and failure visible to the user.

Worked code:
async function example() {
  console.log("A");
  await Promise.resolve();
  console.log("C");
}
example();
console.log("B"); // A, B, C

The code before await runs synchronously.
The continuation runs after the current synchronous stack.

Mental model: Place an order, continue other work, then handle its eventual result.

Boundary: async does not make CPU-heavy code run on another thread. A long synchronous loop still blocks interaction.

Worked example: async function example() {
  console.log("A");
  await Promise.resolve();
  console.log("C");
}
example();
console.log("B"); // A, B, C

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: Promises, async/await and Console

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Event loop, promises and async/await lab. Predict and run the example in Console.

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Predict and run the example in Console.

Expected: The order is A, B, C.

Step 2

Await a rejected promise inside try/catch and return a recovery message.

Expected: The failure takes the catch path rather than becoming a fake success.

Step 3

Compare sequential and concurrent synthetic delays, recording start/end times.

Expected: Independent concurrent waits overlap; CPU work is still on the main thread.

Expected: An execution-order trace and a function with explicit asynchronous failure handling.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: An execution-order trace and a function with explicit asynchronous failure handling. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/async-promises.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining promise states in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The order is A, B, C.

seeker: Build interview evidence for event loop, promises and async/await. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect event loop, promises and async/await to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: async does not make CPU-heavy code run on another thread. A long synchronous loop still blocks interaction.

Recall: Does marking a heavy loop async automatically move it to a background thread?

Interview: Explain event loop, promises and async/await using your own artifact. Defend the rule behind this scenario: Does marking a heavy loop async automatically move it to a background thread? Then explain one failure case and this limitation: async does not make CPU-heavy code run on another thread. A long synchronous loop still blocks interaction.

Quiz: Does marking a heavy loop async automatically move it to a background thread?

Yes.

Only in a click handler.

No.

Reference: No. — async changes promise control flow, not the thread executing synchronous work.

Sources:

Promises · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Using_promises

Functions · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

Workers · official reference: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers

### Fetch, HTTP status, JSON and request states

Fetching data crosses a boundary. Treat transport, HTTP status, parsing and application validation as separate checks.

Read the response contract
fetch returns a promise for a Response. A 404 normally resolves with a response rather than rejecting automatically. Check response.ok or the expected status before treating it as success. Network failures and some browser policy failures follow a different path.

Parse and validate
response.json() is asynchronous and can fail for invalid JSON. Once parsed, verify the shape needed by your UI. An array of task records should have allowed fields and value types. Do not show an object as trusted merely because it came from an API.

Represent all visible states
Start with loading; then distinguish success with data, success with no items, and failure. Provide a retry action when appropriate. Keep useful input intact on failure. Avoid showing raw server traces to users; preserve diagnostic details in an appropriate development log.

Worked code:
async function getTasks() {
  const response = await fetch("/api/tasks");
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const data = await response.json();
  if (!Array.isArray(data) || !data.every(t => typeof t.id === "string" && typeof t.title === "string")) {
    throw new Error("Invalid task data");
  }
  return data;
}

Status, JSON parsing and shape validation can fail independently.
The local API serves synthetic data only.

Mental model: Receiving a parcel, checking its delivery status, opening it and checking its contents are separate steps.

Boundary: A successful status does not prove the response matches your schema. Client checks do not replace server validation.

Worked example: async function getTasks() {
  const response = await fetch("/api/tasks");
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const data = await response.json();
  if (!Array.isArray(data) || !data.every(t => typeof t.id === "string" && typeof t.title === "string")) {
    throw new Error("Invalid task data");
  }
  return data;
}

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: Fetch, HTTP, JSON and Network panel

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Fetch, HTTP status, JSON and request states lab. From course-labs run python3 serve.py, open /web/ and call getTasks in its Console.

Terminal folder: course-labs

```
python3 serve.py
# Windows alternative: py serve.py
```

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

From course-labs run python3 serve.py, open /web/ and call getTasks in its Console.

Expected: /api/tasks returns the documented two task records.

Step 2

Try /api/missing, /api/broken and /api/empty using the same checks.

Expected: 404 and malformed JSON fail; an empty array is a successful empty result.

Step 3

Add loading, empty and error states to the journal. Use DevTools offline mode to test retry.

Expected: The UI never mistakes missing data or failure for a completed load.

Expected: A data loader and a state table covering success, empty, HTTP failure and parsing failure.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A data loader and a state table covering success, empty, HTTP failure and parsing failure. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/fetch-data.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining read the response contract in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: /api/tasks returns the documented two task records.

seeker: Build interview evidence for fetch, http status, json and request states. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect fetch, http status, json and request states to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A successful status does not prove the response matches your schema. Client checks do not replace server validation.

Recall: fetch receives HTTP 404. What should your loader do?

Interview: Explain fetch, http status, json and request states using your own artifact. Defend the rule behind this scenario: fetch receives HTTP 404. What should your loader do? Then explain one failure case and this limitation: A successful status does not prove the response matches your schema. Client checks do not replace server validation.

Quiz: fetch receives HTTP 404. What should your loader do?

Check the status explicitly before processing success data.

Assume fetch always rejects on 404.

Treat the body as a successful task list.

Reference: Check the status explicitly before processing success data. — HTTP errors normally still produce a Response; the application checks the status.

Sources:

Fetch · official reference: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

HTTP overview · official reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

Promises · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Using_promises

### Cancellation, stale responses and retry boundaries

A slow old request must not overwrite a newer user choice. Model request identity as well as cancellation.

Identify current work
Assign an increasing request number before starting a read. After awaiting its result, compare it with the current number before rendering. This protects against out-of-order completion even if cancellation does not stop every stage of processing.

Cancel and classify
AbortController supplies a signal to fetch. Abort an obsolete request and treat its expected AbortError separately from a genuine loading failure. Cleanup is also needed when a component stops using the request. Keep cancellation logic tied to the owner of the work.

Retries are a product decision
A failed read is often safe to retry, but a timed-out write might already have happened. Bound retries, respect server guidance and avoid a retry storm. For writes, ask whether a stable operation identifier or another server-supported idempotency contract exists.

Worked code:
let latest = 0;
let controller;
async function refreshTasks() {
  const id = ++latest;
  controller?.abort();
  controller = new AbortController();
  try {
    const r = await fetch("/api/tasks", { signal: controller.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const tasks = await r.json();
    if (id === latest) console.log("Current result", tasks);
  } catch (error) {
    if (error.name !== "AbortError" && id === latest) console.error(error);
  }
}

The id guard applies to success and failure.
A production loader also validates the response schema as in the previous lesson.

Mental model: Only the newest order slip may update the current display.

Boundary: Aborting a browser request is not a server rollback. Retrying a write may duplicate an effect unless the server contract handles it.

Worked example: let latest = 0;
let controller;
async function refreshTasks() {
  const id = ++latest;
  controller?.abort();
  controller = new AbortController();
  try {
    const r = await fetch("/api/tasks", { signal: controller.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const tasks = await r.json();
    if (id === latest) console.log("Current result", tasks);
  } catch (error) {
    if (error.name !== "AbortError" && id === latest) console.error(error);
  }
}

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: AbortController, request ids and Network throttling

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Cancellation, stale responses and retry boundaries lab. Use the local API with /api/tasks?delay=800, then trigger a faster refresh with delay=50.

Terminal folder: course-labs

```
python3 serve.py
# Windows alternative: py serve.py
```

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Use the local API with /api/tasks?delay=800, then trigger a faster refresh with delay=50.

Expected: Only the currently owned request should update your result region.

Step 2

Abort a pending read and inspect Network plus your visible status.

Expected: Expected cancellation does not become a misleading service error.

Step 3

Write a policy for retrying GET versus an uncertain POST.

Expected: The policy distinguishes a repeatable read from a possibly duplicated write.

Expected: A stale-response reproduction, corrected loader and documented retry policy.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A stale-response reproduction, corrected loader and documented retry policy. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/request-races.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining identify current work in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Only the currently owned request should update your result region.

seeker: Build interview evidence for cancellation, stale responses and retry boundaries. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect cancellation, stale responses and retry boundaries to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Aborting a browser request is not a server rollback. Retrying a write may duplicate an effect unless the server contract handles it.

Recall: A client aborts a POST after sending it. What is known about the server effect?

Interview: Explain cancellation, stale responses and retry boundaries using your own artifact. Defend the rule behind this scenario: A client aborts a POST after sending it. What is known about the server effect? Then explain one failure case and this limitation: Aborting a browser request is not a server rollback. Retrying a write may duplicate an effect unless the server contract handles it.

Quiz: A client aborts a POST after sending it. What is known about the server effect?

It was certainly rolled back.

Its outcome may be unknown without server evidence.

It must have run twice.

Reference: Its outcome may be unknown without server evidence. — Client cancellation does not prove whether the server committed an effect.

Sources:

Abort · official reference: https://developer.mozilla.org/en-US/docs/Web/API/AbortController

Fetch · official reference: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

HTTP overview · official reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

### TypeScript: annotations, inference and object types

TypeScript checks JavaScript before execution. Use it to describe the values your functions and components expect.

Inference and annotations
TypeScript infers many types from initial values. Add annotations where they clarify a public function or data contract. string and number name primitive types. Avoid any as an escape from understanding an error: it disables useful checking for the affected value.

Describe records
A type alias can name a task shape with required and optional properties. A union such as "todo" | "done" permits specific alternatives. Optional properties may be undefined and need handling. Keep units and domain constraints explicit; number alone does not mean positive integer cents.

Compile separately
Vite transforms TypeScript for development, but transformation alone is not full type checking. The supplied build script runs tsc before Vite. Fix the reported type error, then run tests; successful compilation still does not prove the behaviour is correct.

Worked code:
type Task = { id: string; title: string; done: boolean };
function activeCount(tasks: Task[]): number {
  return tasks.filter(task => !task.done).length;
}
// activeCount([{ id: "a", title: "Read", done: "no" }]); // type error

The function contract accepts an array of Task records.
A string cannot stand in for the declared boolean field.

Mental model: A checked design drawing; the browser still runs the resulting JavaScript.

Boundary: Types are erased at runtime. A typed assertion does not validate an API response or user input.

Worked example: type Task = { id: string; title: string; done: boolean };
function activeCount(tasks: Task[]): number {
  return tasks.filter(task => !task.done).length;
}
// activeCount([{ id: "a", title: "Read", done: "no" }]); // type error

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: TypeScript compiler and editor language service

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the TypeScript: annotations, inference and object types lab. In course-labs/react-app create src/types-practice.ts with the example. Run npm run typecheck.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

In course-labs/react-app create src/types-practice.ts with the example. Run npm run typecheck.

Expected: The valid declarations compile.

Step 2

Uncomment the invalid call and inspect the error, then repair the value.

Expected: The string/boolean mismatch is caught before execution.

Step 3

Add optional dueDate and handle its absence without a non-null assertion.

Expected: Both absent and present values are handled explicitly.

Expected: A typed task contract, one demonstrated compiler error and its correction.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A typed task contract, one demonstrated compiler error and its correction. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/ts-basics.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining inference and annotations in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The valid declarations compile.

seeker: Build interview evidence for typescript: annotations, inference and object types. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect typescript: annotations, inference and object types to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Types are erased at runtime. A typed assertion does not validate an API response or user input.

Recall: What does TypeScript guarantee about JSON received at runtime?

Interview: Explain typescript: annotations, inference and object types using your own artifact. Defend the rule behind this scenario: What does TypeScript guarantee about JSON received at runtime? Then explain one failure case and this limitation: Types are erased at runtime. A typed assertion does not validate an API response or user input.

Quiz: What does TypeScript guarantee about JSON received at runtime?

It always matches a declared interface.

It cannot contain null.

Nothing without runtime validation.

Reference: Nothing without runtime validation. — Static declarations are erased and do not inspect external JSON.

Sources:

TypeScript everyday types · official reference: https://www.typescriptlang.org/docs/handbook/2/everyday-types.html

TypeScript narrowing · official reference: https://www.typescriptlang.org/docs/handbook/2/narrowing.html

Vite guide · official reference: https://vite.dev/guide/

### Unknown data, narrowing and discriminated unions

Represent states so invalid combinations are difficult to express. Narrow unknown values before using them.

Unknown at the boundary
Use unknown for a value whose shape has not been established. Check typeof, null, arrays and required properties before accessing them. An assertion such as as Task[] only tells the compiler to trust you; it performs no runtime validation.

Discriminate states
A union with a literal kind field can represent loading, success and error. TypeScript narrows the available fields after checking kind. This is clearer than unrelated booleans that allow impossible combinations such as loading and failed and successful simultaneously.

Exhaustiveness
A switch over all variants makes state handling visible. A never check can expose a newly added case that a renderer forgot. Keep user-facing error text separate from sensitive diagnostics. Model the distinction between an empty successful result and no result yet.

Worked code:
type LoadState =
  | { kind: "loading" }
  | { kind: "ready"; titles: string[] }
  | { kind: "error"; message: string };
function label(state: LoadState): string {
  if (state.kind === "ready") return `${state.titles.length} tasks`;
  if (state.kind === "error") return state.message;
  return "Loading…";
}

titles is only accessed after ready narrows the union.
A ready state with an empty array is not the loading state.

Mental model: Check a labelled package before deciding which contents it contains.

Boundary: A type predicate is code you must implement correctly. Declaring it does not make a weak validator trustworthy.

Worked example: type LoadState =
  | { kind: "loading" }
  | { kind: "ready"; titles: string[] }
  | { kind: "error"; message: string };
function label(state: LoadState): string {
  if (state.kind === "ready") return `${state.titles.length} tasks`;
  if (state.kind === "error") return state.message;
  return "Loading…";
}

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: TypeScript unknown, guards and discriminated unions

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Unknown data, narrowing and discriminated unions lab. Add the union and label function to types-practice.ts. Typecheck all variants.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add the union and label function to types-practice.ts. Typecheck all variants.

Expected: Every valid variant produces a string.

Step 2

Try accessing state.titles before checking kind, then repair it.

Expected: The compiler catches the unsafe access.

Step 3

Write a runtime guard for an unknown array of title strings and test null, an object and a valid array.

Expected: Only the intended shape passes the guard.

Expected: An explicit loading-state union and tested unknown-input guard.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: An explicit loading-state union and tested unknown-input guard. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/ts-unions.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining unknown at the boundary in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Every valid variant produces a string.

seeker: Build interview evidence for unknown data, narrowing and discriminated unions. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect unknown data, narrowing and discriminated unions to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A type predicate is code you must implement correctly. Declaring it does not make a weak validator trustworthy.

Recall: Which operation validates external data at runtime?

Interview: Explain unknown data, narrowing and discriminated unions using your own artifact. Defend the rule behind this scenario: Which operation validates external data at runtime? Then explain one failure case and this limitation: A type predicate is code you must implement correctly. Declaring it does not make a weak validator trustworthy.

Quiz: Which operation validates external data at runtime?

A correctly implemented field/type check.

Writing as Task[].

Importing a type alias.

Reference: A correctly implemented field/type check. — Runtime checks inspect actual values; type assertions and imports do not.

Sources:

TypeScript narrowing · official reference: https://www.typescriptlang.org/docs/handbook/2/narrowing.html

TypeScript everyday types · official reference: https://www.typescriptlang.org/docs/handbook/2/everyday-types.html

Fetch · official reference: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

### Generics and reusable typed functions

A generic expresses a relationship between input and output types without throwing that relationship away.

Preserve a relationship
A function returning the first element should return the same item type as its input array. A generic T describes that relationship. Include undefined for an empty array. Returning any would hide mistakes rather than preserving information.

Constrain only what you need
A reusable function can require an id field without requiring every Task property. A constraint describes the minimum capability the implementation uses. Avoid adding properties to a constraint simply because one caller happens to have them.

Use type utilities deliberately
ReadonlyArray communicates that a function should not mutate its input through that parameter. Pick and Partial can derive related shapes, but they do not enforce permissions or validate updates at runtime. Keep an explicit domain operation when only selected transitions are legal.

Worked code:
function first<T>(items: readonly T[]): T | undefined {
  return items[0];
}
const title = first(["Read", "Build"]);
const missing = first<number>([]);

T follows the element type through the return value.
The empty case remains visible as undefined.

Mental model: A reusable container whose label says what kind of item it currently holds.

Boundary: More type parameters do not automatically make a design better. A simple concrete type is often easier to read.

Worked example: function first<T>(items: readonly T[]): T | undefined {
  return items[0];
}
const title = first(["Read", "Build"]);
const missing = first<number>([]);

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: TypeScript generics, constraints and tests

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Generics and reusable typed functions lab. Add first to a module in react-app and typecheck string and number callers.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add first to a module in react-app and typecheck string and number callers.

Expected: Each result preserves the respective type plus undefined.

Step 2

Write an empty-array test instead of asserting the result is always present.

Expected: The test records the undefined boundary.

Step 3

Write byId<T extends {id:string}> and test found/missing ids.

Expected: Callers keep their full item type without any.

Expected: Two reusable typed functions with explicit missing-item tests.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: Two reusable typed functions with explicit missing-item tests. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/ts-generics.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining preserve a relationship in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Each result preserves the respective type plus undefined.

seeker: Build interview evidence for generics and reusable typed functions. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect generics and reusable typed functions to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: More type parameters do not automatically make a design better. A simple concrete type is often easier to read.

Recall: Why return T | undefined from first<T>(items)?

Interview: Explain generics and reusable typed functions using your own artifact. Defend the rule behind this scenario: Why return T | undefined from first<T>(items)? Then explain one failure case and this limitation: More type parameters do not automatically make a design better. A simple concrete type is often easier to read.

Quiz: Why return T | undefined from first<T>(items)?

Every array always contains undefined.

An empty input has no first element.

Generics cannot return T.

Reference: An empty input has no first element. — The signature must include the real empty-input possibility.

Sources:

TypeScript generics · official reference: https://www.typescriptlang.org/docs/handbook/2/generics.html

TypeScript everyday types · official reference: https://www.typescriptlang.org/docs/handbook/2/everyday-types.html

Arrays · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Indexed_collections

### React, JSX and component composition

React describes an interface using components. Learn it after you can build and debug a small page with the browser platform.

Components return UI
A function component returns a description of the UI. Capitalised names such as TaskList refer to components; lowercase names such as button refer to built-in elements. Keep rendering pure: calculate the description without issuing a request or changing storage during the render itself.

Read JSX
JSX looks similar to HTML but is JavaScript syntax transformed by tooling. Use className for CSS classes and braces for expressions. Return one enclosing root or a fragment. Text expressions are rendered as text; do not opt into raw HTML for untrusted content.

Compose small responsibilities
Extract a component when it gives a useful name to a responsibility or supports meaningful reuse. A heading component need not own the whole application’s state. Keep the page structure understandable and test the user-visible behaviour rather than component count.

Worked code:
function Welcome({ name }: { name: string }) {
  return <section><h2>Hello, {name}</h2><p>Choose a task to practise.</p></section>;
}
export default function App() {
  return <main><h1>Study journal</h1><Welcome name="Learner" /></main>;
}

The prop is typed and read inside the component.
The main/h1/h2 elements retain their HTML meanings.

Mental model: A tree of reusable interface functions composed into a page.

Boundary: A component is not automatically a service boundary. React does not replace HTML semantics, CSS or network contracts.

Worked example: function Welcome({ name }: { name: string }) {
  return <section><h2>Hello, {name}</h2><p>Choose a task to practise.</p></section>;
}
export default function App() {
  return <main><h1>Study journal</h1><Welcome name="Learner" /></main>;
}

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: React, JSX, TypeScript and Vite

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the React, JSX and component composition lab. Run the supplied react-app and replace App.tsx in a copy with the example.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Run the supplied react-app and replace App.tsx in a copy with the example.

Expected: The page displays the composed greeting.

Step 2

Change the prop and add a second Welcome instance.

Expected: Each instance receives its own supplied data.

Step 3

Run npm run build and correct a deliberately unclosed JSX tag.

Expected: The tooling catches the syntax error; the repaired build succeeds.

Expected: A small component tree with meaningful HTML and a reproducible build.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A small component tree with meaningful HTML and a reproducible build. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/react-components.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining components return ui in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The page displays the composed greeting.

seeker: Build interview evidence for react, jsx and component composition. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect react, jsx and component composition to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A component is not automatically a service boundary. React does not replace HTML semantics, CSS or network contracts.

Recall: What distinguishes <Welcome /> from <section> in JSX?

Interview: Explain react, jsx and component composition using your own artifact. Defend the rule behind this scenario: What distinguishes <Welcome /> from <section> in JSX? Then explain one failure case and this limitation: A component is not automatically a service boundary. React does not replace HTML semantics, CSS or network contracts.

Quiz: What distinguishes <Welcome /> from <section> in JSX?

Welcome names a component; section is a built-in element.

Welcome is always rendered on a server.

section cannot contain text.

Reference: Welcome names a component; section is a built-in element. — Capitalised component names refer to JavaScript component values.

Sources:

React Quick Start · official reference: https://react.dev/learn

TypeScript everyday types · official reference: https://www.typescriptlang.org/docs/handbook/2/everyday-types.html

Vite guide · official reference: https://vite.dev/guide/

### Props, conditional rendering and stable keys

Pass data down through props and describe repeated UI from arrays. Keep item identity stable across changes.

Props are inputs
Treat props as read-only. A parent supplies values and callbacks; the child describes their presentation. Conditional expressions can choose loading, empty or populated UI. Be careful when rendering a number with &&: zero may appear as text rather than disappearing.

Map records to UI
Use map to turn an array into elements. Give each sibling a key derived from stable data identity. Random keys change on every render, and index keys can associate state with the wrong row when items are inserted, removed or reordered.

Handle empty and long content
An empty list should explain that there are no tasks instead of looking broken. Use semantic list elements. Test duplicate titles with different ids so you do not accidentally treat the title as the unique identity. Long text must wrap without hiding actions.

Worked code:
type Task = { id: string; title: string };
function TaskList({ tasks }: { tasks: Task[] }) {
  if (tasks.length === 0) return <p>No tasks yet.</p>;
  return <ul>{tasks.map(task => <li key={task.id}>{task.title}</li>)}</ul>;
}

The data id is stable even when the array is reordered.
The empty state is an intentional success state.

Mental model: Each rendered row carries its own identity badge, even when its position changes.

Boundary: A key identifies siblings to React. It is not a DOM id, a security token or a prop automatically passed to the child.

Worked example: type Task = { id: string; title: string };
function TaskList({ tasks }: { tasks: Task[] }) {
  if (tasks.length === 0) return <p>No tasks yet.</p>;
  return <ul>{tasks.map(task => <li key={task.id}>{task.title}</li>)}</ul>;
}

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: React props, lists and keys

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Props, conditional rendering and stable keys lab. Add TaskList to App.tsx and pass two records with distinct ids.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add TaskList to App.tsx and pass two records with distinct ids.

Expected: Both titles appear in a semantic list.

Step 2

Pass an empty array and then duplicate titles with distinct ids.

Expected: The empty message works and identity does not depend on title.

Step 3

Add an input to each row, reorder the records and compare stable keys with index keys. Restore stable keys.

Expected: Your notes explain which row retains its intended state.

Expected: A typed list component and an identity/reordering experiment.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A typed list component and an identity/reordering experiment. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/react-props-lists.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining props are inputs in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Both titles appear in a semantic list.

seeker: Build interview evidence for props, conditional rendering and stable keys. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect props, conditional rendering and stable keys to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A key identifies siblings to React. It is not a DOM id, a security token or a prop automatically passed to the child.

Recall: Which key is appropriate for a reorderable task list?

Interview: Explain props, conditional rendering and stable keys using your own artifact. Defend the rule behind this scenario: Which key is appropriate for a reorderable task list? Then explain one failure case and this limitation: A key identifies siblings to React. It is not a DOM id, a security token or a prop automatically passed to the child.

Quiz: Which key is appropriate for a reorderable task list?

Math.random() during render.

A stable unique task id.

The current array index regardless of changes.

Reference: A stable unique task id. — Stable data identity lets React match the same item across renders.

Sources:

Keys · official reference: https://react.dev/learn/rendering-lists

React Quick Start · official reference: https://react.dev/learn

State · official reference: https://react.dev/learn/managing-state

### Events, useState and immutable updates

State is data React retains between renders. Update it through its setter so the UI can reflect the new value.

State and handlers
useState returns a current value and a setter. Call hooks at the top level of a component or custom hook, not inside arbitrary conditions. Pass a function to onClick; do not call the handler while rendering. Keep user actions in event handlers.

Previous-state updates
When the next state depends on the previous state, use a functional update such as setCount(c => c + 1). Multiple updates may be batched. Reading the same old count several times is not the same as applying successive transformations to the queued value.

Replace objects and arrays
Do not mutate a state array with push and expect React to detect every intended update. Return a new array using spread, map or filter, and copy the changed object. Keep ids stable. Derived values such as activeCount can be calculated from tasks rather than stored separately.

Worked code:
import { useState } from "react";
function Counter() {
  const [count, setCount] = useState(0);
  return <button onClick={() => setCount(c => c + 1)}>Sessions: {count}</button>;
}

The arrow is passed as the event handler.
The functional updater receives the pending previous value.

Mental model: Each render is a snapshot; event handlers see the snapshot from which they were created.

Boundary: A state setter schedules an update. It does not mutate the current render’s local variable immediately.

Worked example: import { useState } from "react";
function Counter() {
  const [count, setCount] = useState(0);
  return <button onClick={() => setCount(c => c + 1)}>Sessions: {count}</button>;
}

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: React useState and browser React DevTools

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Events, useState and immutable updates lab. Add Counter and activate it by mouse and keyboard.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add Counter and activate it by mouse and keyboard.

Expected: Each activation adds one session.

Step 2

Queue two functional increments in one handler and compare with two setCount(count + 1) calls.

Expected: The snapshot/updater difference is observable.

Step 3

Add a task toggle using map and an object copy instead of mutation.

Expected: Only the selected task changes while original references remain explainable.

Expected: A stateful interaction and an immutable task update with a written snapshot explanation.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A stateful interaction and an immutable task update with a written snapshot explanation. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/react-state.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining state and handlers in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Each activation adds one session.

seeker: Build interview evidence for events, usestate and immutable updates. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect events, usestate and immutable updates to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A state setter schedules an update. It does not mutate the current render’s local variable immediately.

Recall: Why use setCount(c => c + 1) for an update based on the previous count?

Interview: Explain events, usestate and immutable updates using your own artifact. Defend the rule behind this scenario: Why use setCount(c => c + 1) for an update based on the previous count? Then explain one failure case and this limitation: A state setter schedules an update. It does not mutate the current render’s local variable immediately.

Quiz: Why use setCount(c => c + 1) for an update based on the previous count?

It transforms the queued previous value.

It writes directly to the DOM.

It prevents all future renders.

Reference: It transforms the queued previous value. — The updater handles the pending previous state rather than relying on a stale snapshot.

Sources:

State · official reference: https://react.dev/learn/managing-state

React Quick Start · official reference: https://react.dev/learn

Objects · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_objects

### Controlled forms and accessible validation

A controlled input gets its displayed value from state. Keep form behaviour and error feedback usable from the keyboard.

Control a field
Supply value and onChange together so edits update state. Keep the input consistently controlled rather than switching between undefined and a string. Use a visible label with matching htmlFor/id. React’s JSX names differ slightly from HTML attributes but the resulting association has the same purpose.

Validate on a meaningful action
Handle onSubmit on the form, prevent default navigation and validate a trimmed value. Explain constraints and preserve the user’s input after a failure. A disabled submit button alone may conceal why the action is unavailable. Provide actionable feedback.

Connect errors
Use aria-describedby to connect help/error text where appropriate, and aria-invalid when a field is invalid. Announce changing status without repeatedly interrupting typing. Move focus only when it helps the user understand the result; do not unexpectedly reset the whole form.

Worked code:
const [title, setTitle] = useState("");
const [error, setError] = useState("");
function submit(event: React.FormEvent) {
  event.preventDefault();
  if (!title.trim()) { setError("Enter a task title."); return; }
  setError(""); // add the validated title using your task-state operation
}
// <input id="title" value={title} onChange={e => setTitle(e.target.value)} />

This is a component fragment: keep the hooks inside a component.
Use the supplied App.tsx for the complete labelled form and status structure.

Mental model: The state is the record; the input displays and edits that record.

Boundary: Client validation is not authorisation or server validation. Do not confuse a local acceptance message with a remote save.

Worked example: const [title, setTitle] = useState("");
const [error, setError] = useState("");
function submit(event: React.FormEvent) {
  event.preventDefault();
  if (!title.trim()) { setError("Enter a task title."); return; }
  setError(""); // add the validated title using your task-state operation
}
// <input id="title" value={title} onChange={e => setTitle(e.target.value)} />

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: React controlled inputs, HTML forms and accessibility tools

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Controlled forms and accessible validation lab. Inspect the supplied App.tsx form and identify its state, label and submit handler.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Inspect the supplied App.tsx form and identify its state, label and submit handler.

Expected: You can trace input to validation to state update.

Step 2

Add a maximum title length and a specific error message without clearing invalid input.

Expected: Overlong input is preserved with an explanation.

Step 3

Test Enter submission, empty input, focus order and error announcement.

Expected: All cases work without relying on pointer-only actions.

Expected: An accessible controlled form with normal and rejected-input evidence.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: An accessible controlled form with normal and rejected-input evidence. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/react-forms.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining control a field in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: You can trace input to validation to state update.

seeker: Build interview evidence for controlled forms and accessible validation. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect controlled forms and accessible validation to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Client validation is not authorisation or server validation. Do not confuse a local acceptance message with a remote save.

Recall: Which event best handles both clicking submit and keyboard form submission?

Interview: Explain controlled forms and accessible validation using your own artifact. Defend the rule behind this scenario: Which event best handles both clicking submit and keyboard form submission? Then explain one failure case and this limitation: Client validation is not authorisation or server validation. Do not confuse a local acceptance message with a remote save.

Quiz: Which event best handles both clicking submit and keyboard form submission?

onMouseDown on a div.

onSubmit on the form.

onHover on the button.

Reference: onSubmit on the form. — Form submission is the meaningful action and includes keyboard activation.

Sources:

React Quick Start · official reference: https://react.dev/learn

Labels · official reference: https://www.w3.org/WAI/tutorials/forms/labels/

Forms · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms

### Effects, dependencies, refs and cleanup

An Effect synchronises a component with something outside React. Do not use one merely to recalculate a value you can derive during rendering.

Choose an Effect deliberately
Calculating a filtered task list belongs in rendering. Sending a form belongs in its event handler. A subscription or timer tied to the component’s presence can belong in an Effect. Keep its dependencies aligned with the reactive values it reads rather than disabling the dependency warning.

Cleanup mirrors setup
If setup registers an event listener, cleanup removes that listener. If it starts a timer, cleanup clears it. React development behaviour may exercise setup and cleanup to reveal unsafe assumptions. Design the operation so repeated mount/cleanup does not leak resources.

Refs are a different tool
A ref can hold a DOM node or mutable value that does not itself drive rendering. Updating a ref does not rerender the component. Use state for data that must update the visible UI and refs for imperative focus or an external handle. Avoid storing the same visible value in both.

Worked code:
useEffect(() => {
  const onOnline = () => setMessage("Connection available");
  window.addEventListener("online", onOnline);
  return () => window.removeEventListener("online", onOnline);
}, []);

The same function reference is registered and removed.
This fragment assumes setMessage is a stable useState setter in the component.

Mental model: Connect an external resource when needed; disconnect the exact resource you connected.

Boundary: An empty dependency array does not prove an Effect is universally run once. Development checks and remounting can repeat setup.

Worked example: useEffect(() => {
  const onOnline = () => setMessage("Connection available");
  window.addEventListener("online", onOnline);
  return () => window.removeEventListener("online", onOnline);
}, []);

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: React useEffect/useRef and development checks

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Effects, dependencies, refs and cleanup lab. Add a connection-status Effect and remove/re-add its component.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add a connection-status Effect and remove/re-add its component.

Expected: There is one owned listener while mounted.

Step 2

Add a timer with mirrored clearInterval cleanup; inspect repeated mounts.

Expected: Unmounting stops the old timer.

Step 3

Replace a redundant filteredTasks Effect with a derived render value.

Expected: The UI remains correct with one source of truth.

Expected: A resource-owning Effect with cleanup and a removed redundant Effect.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A resource-owning Effect with cleanup and a removed redundant Effect. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/react-effects.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining choose an effect deliberately in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: There is one owned listener while mounted.

seeker: Build interview evidence for effects, dependencies, refs and cleanup. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect effects, dependencies, refs and cleanup to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: An empty dependency array does not prove an Effect is universally run once. Development checks and remounting can repeat setup.

Recall: Where should a task list filtered from current props normally be calculated?

Interview: Explain effects, dependencies, refs and cleanup using your own artifact. Defend the rule behind this scenario: Where should a task list filtered from current props normally be calculated? Then explain one failure case and this limitation: An empty dependency array does not prove an Effect is universally run once. Development checks and remounting can repeat setup.

Quiz: Where should a task list filtered from current props normally be calculated?

In render, as a derived value.

In an Effect that copies it into extra state.

In localStorage on every keystroke.

Reference: In render, as a derived value. — A derived value usually does not need an additional synchronisation cycle and stored duplicate.

Sources:

Effects · official reference: https://react.dev/learn/synchronizing-with-effects

State · official reference: https://react.dev/learn/managing-state

React Quick Start · official reference: https://react.dev/learn

### Reducers, shared state and component boundaries

As transitions grow, name them explicitly. Put state at the nearest owner that needs to coordinate it.

Lift state to its owner
When siblings need coordinated task/filter state, place it in their common parent and pass values and callbacks. Avoid keeping independent copies that drift apart. Keep local details, such as whether one disclosure is open, local when no other component needs them.

Reducers describe transitions
A reducer receives state and an action and returns the next state without side effects. Name actions according to domain intent. Test the pure reducer directly. Keep network calls and storage writes outside the reducer; their results can become later actions.

Use context when it solves distribution
Context can avoid passing a shared value through many intermediary components. Separate frequently changing values from unrelated ones when needed. Do not introduce a global state library for every small form. First document ownership, update frequency and who needs to subscribe.

Worked code:
type Action = { type: "toggle"; id: string };
function reducer(tasks: Task[], action: Action): Task[] {
  return tasks.map(t => t.id === action.id ? { ...t, done: !t.done } : t);
}
// const [tasks, dispatch] = useReducer(reducer, initialTasks);

The reducer returns a new array and changes only the matched item.
An unknown id leaves the logical data unchanged.

Mental model: A transition table: current state plus an action gives the next state.

Boundary: Context distributes a value; it is not automatically a cache, database or performance optimisation.

Worked example: type Action = { type: "toggle"; id: string };
function reducer(tasks: Task[], action: Action): Task[] {
  return tasks.map(t => t.id === action.id ? { ...t, done: !t.done } : t);
}
// const [tasks, dispatch] = useReducer(reducer, initialTasks);

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: React useReducer/context and pure tests

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Reducers, shared state and component boundaries lab. Extract task toggling into a typed reducer and test it with two records.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Extract task toggling into a typed reducer and test it with two records.

Expected: Only the target record changes.

Step 2

Test an unknown id and verify the input objects were not mutated.

Expected: The contract has a defined no-match behaviour.

Step 3

Draw which component owns tasks, filter and form text. Explain any context you introduce.

Expected: Every state value has one clear owner.

Expected: A tested reducer and a component/state ownership diagram.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A tested reducer and a component/state ownership diagram. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/react-state-design.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining lift state to its owner in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Only the target record changes.

seeker: Build interview evidence for reducers, shared state and component boundaries. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect reducers, shared state and component boundaries to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Context distributes a value; it is not automatically a cache, database or performance optimisation.

Recall: What belongs inside a reducer?

Interview: Explain reducers, shared state and component boundaries using your own artifact. Defend the rule behind this scenario: What belongs inside a reducer? Then explain one failure case and this limitation: Context distributes a value; it is not automatically a cache, database or performance optimisation.

Quiz: What belongs inside a reducer?

A network POST request.

A storage write.

A pure state transition.

Reference: A pure state transition. — A reducer computes next state; effects and external operations have separate ownership.

Sources:

Reducer · official reference: https://react.dev/learn/extracting-state-logic-into-a-reducer

State · official reference: https://react.dev/learn/managing-state

Objects · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_objects

### URL state, navigation and shareable screens

A useful application lets a learner reload, share a link and use Back without losing the meaning of the current screen.

Decide what belongs in the URL
A selected course, search term or filter may belong in a query or path. Private draft text and secrets do not. Parse allowed values and provide safe defaults. URLSearchParams handles encoding; do not build query strings by concatenating unescaped user values.

History and reload
pushState creates a history entry and replaceState updates the current one. Listen to popstate when implementing manual history navigation. A hash route can work on static hosting without path rewrites. A path router needs a host fallback or real server routes.

Test navigation as a flow
Check first visit, direct deep link, reload, Back and Forward. Restore the selected filter from the URL before rendering. Keep navigation elements as real links when appropriate and move focus predictably after a screen transition. A URL that looks correct while showing stale content is still a bug.

Worked code:
const params = new URLSearchParams(location.search);
const raw = params.get("filter");
const filter = ["all", "active", "done"].includes(raw ?? "") ? raw : "all";
const next = new URL(location.href);
next.searchParams.set("filter", "active");
history.pushState(null, "", next);

This fragment changes history; the application still needs to update its rendered state.
Only allowlisted filter values influence the view.

Mental model: The URL is a bookmarkable address for a view, not a temporary decoration.

Boundary: Client routing does not create server routes or access control. A deep link must also be supported by the host.

Worked example: const params = new URLSearchParams(location.search);
const raw = params.get("filter");
const filter = ["all", "active", "done"].includes(raw ?? "") ? raw : "all";
const next = new URL(location.href);
next.searchParams.set("filter", "active");
history.pushState(null, "", next);

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: URLSearchParams, History API; optional React Router alternative

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the URL state, navigation and shareable screens lab. Add all/active/done URL filters to the journal.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add all/active/done URL filters to the journal.

Expected: Each view has a shareable query.

Step 2

Reload a done link and test Back/Forward after changing filters.

Expected: The visible filter agrees with the URL at each step.

Step 3

Try an invalid filter and deploy under a subpath.

Expected: The safe default and asset paths still work.

Expected: A navigation test matrix and shareable filter links.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A navigation test matrix and shareable filter links. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/routing-url.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining decide what belongs in the url in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Each view has a shareable query.

seeker: Build interview evidence for url state, navigation and shareable screens. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect url state, navigation and shareable screens to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Client routing does not create server routes or access control. A deep link must also be supported by the host.

Recall: What else is required after manual history.pushState changes a URL?

Interview: Explain url state, navigation and shareable screens using your own artifact. Defend the rule behind this scenario: What else is required after manual history.pushState changes a URL? Then explain one failure case and this limitation: Client routing does not create server routes or access control. A deep link must also be supported by the host.

Quiz: What else is required after manual history.pushState changes a URL?

Nothing; the browser rewrites every component.

Update application state/rendering and handle history navigation.

Store the URL as an API password.

Reference: Update application state/rendering and handle history navigation. — History mutation and UI rendering are separate responsibilities.

Sources:

Modules · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

HTTP overview · official reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

Deploy · official reference: https://vite.dev/guide/static-deploy.html

### Unit tests, assertions and meaningful boundaries

A useful test compares observable behaviour with an independently stated expectation. Start with pure rules.

Arrange, act, assert
Arrange the input, call the operation and assert its result. Test both accepted and rejected inputs. Name the business case in the test so a failure explains what changed. Avoid reproducing the implementation line for line: the expectation should come from the contract.

Choose useful cases
For a title validator, test spaces, an accepted title, overlong input and boundary length. For a reducer, test target identity and input immutability. An empty array often exposes a missed assumption. A test that only checks the output exists is weak evidence.

Run and repair
The supplied project uses Node’s built-in test runner for its pure domain module. Read a failing assertion’s expected and actual values. Correct either a genuine defect or an incorrect requirement, explaining which changed. Do not simply loosen the test until the build turns green.

Worked code:
import test from "node:test";
import assert from "node:assert/strict";
import { titleResult } from "../src/domain.mjs";
test("blank titles are rejected", () => {
  assert.equal(titleResult("   ").ok, false);
});

The expectation comes from the form rule.
Node tests run outside the browser and do not prove keyboard behaviour.

Mental model: A repeatable experiment with a known input and a falsifiable prediction.

Boundary: A passing reference test validates the reference behaviour it checks. It does not automatically validate your new feature.

Worked example: import test from "node:test";
import assert from "node:assert/strict";
import { titleResult } from "../src/domain.mjs";
test("blank titles are rejected", () => {
  assert.equal(titleResult("   ").ok, false);
});

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: Node test runner; Vitest/Jest as alternative test frameworks

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Unit tests, assertions and meaningful boundaries lab. In course-labs/react-app run npm test and read test/domain.test.mjs.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

In course-labs/react-app run npm test and read test/domain.test.mjs.

Expected: Normal, rejected and immutable-update checks pass.

Step 2

Remove the trim guard in a copy and rerun the tests.

Expected: The blank-title test fails for a meaningful reason.

Step 3

Restore the guard and add a new boundary test for the maximum length.

Expected: Your new test fails before its required behaviour is fixed and passes afterward.

Expected: A regression test with a demonstrated fail/repair/pass cycle.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A regression test with a demonstrated fail/repair/pass cycle. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/unit-testing.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining arrange, act, assert in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Normal, rejected and immutable-update checks pass.

seeker: Build interview evidence for unit tests, assertions and meaningful boundaries. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect unit tests, assertions and meaningful boundaries to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A passing reference test validates the reference behaviour it checks. It does not automatically validate your new feature.

Recall: Which test is stronger for a blank-title rule?

Interview: Explain unit tests, assertions and meaningful boundaries using your own artifact. Defend the rule behind this scenario: Which test is stronger for a blank-title rule? Then explain one failure case and this limitation: A passing reference test validates the reference behaviour it checks. It does not automatically validate your new feature.

Quiz: Which test is stronger for a blank-title rule?

The function exists.

The source has five lines.

Whitespace-only input produces an explicit rejection.

Reference: Whitespace-only input produces an explicit rejection. — The third assertion checks the stated behaviour rather than implementation shape.

Sources:

Node.js introduction · official reference: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

Testing · official reference: https://testing-library.com/docs/react-testing-library/intro/

Functions · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

### Component tests and browser acceptance tests

Test interactions at the level where they matter. A domain test cannot prove a label is connected or a button is reachable.

Component behaviour
React Testing Library queries elements by roles, names and labels. This encourages tests that resemble how users locate controls. Simulate the meaningful interaction, then assert the resulting content or state. Avoid asserting internal hook order or arbitrary CSS class names.

Real browser flows
Playwright can open the built application, submit a form and inspect the visible result. Use resilient role/name locators and assertions that wait for a condition. Avoid fixed sleeps to hide races. Include empty input, keyboard submission and literal markup as acceptance cases.

Separate reference and learner evidence
The pack includes acceptance-tests.md with test examples and setup commands. Install optional test tooling in your own copy if needed. Record which runner, browser and version you actually executed. Manual keyboard/zoom checks remain part of the portfolio evidence, even when automated tests pass.

Worked code:
// Playwright example after installing @playwright/test and its Chromium browser
test("adds a task using Enter", async ({ page }) => {
  await page.goto("http://127.0.0.1:5173");
  await page.getByLabel("Task title").fill("Read CSS");
  await page.getByLabel("Task title").press("Enter");
  await expect(page.getByRole("listitem")).toContainText("Read CSS");
});

Imports and runner setup are in acceptance-tests.md.
The assertion observes a user-visible item, not a private component variable.

Mental model: Different test layers observe different boundaries of the same user task.

Boundary: A DOM simulator is not a real browser, and automation cannot replace every accessibility or usability review.

Worked example: // Playwright example after installing @playwright/test and its Chromium browser
test("adds a task using Enter", async ({ page }) => {
  await page.goto("http://127.0.0.1:5173");
  await page.getByLabel("Task title").fill("Read CSS");
  await page.getByLabel("Task title").press("Enter");
  await expect(page.getByRole("listitem")).toContainText("Read CSS");
});

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: React Testing Library and Playwright; browser manual checks

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Component tests and browser acceptance tests lab. Read the complete setup in acceptance-tests.md and choose component or browser testing for one stated boundary.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Read the complete setup in acceptance-tests.md and choose component or browser testing for one stated boundary.

Expected: The test plan explains why that layer is appropriate.

Step 2

Implement an empty-input and successful-submission test using roles/labels.

Expected: Each test has a distinct expected outcome.

Step 3

Run the chosen tests, then manually check keyboard focus and zoom; record the actual environments.

Expected: The report separates executed checks from planned ones.

Expected: An executed interaction test and a manual accessibility checklist with results.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: An executed interaction test and a manual accessibility checklist with results. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/component-e2e.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining component behaviour in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The test plan explains why that layer is appropriate.

seeker: Build interview evidence for component tests and browser acceptance tests. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect component tests and browser acceptance tests to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A DOM simulator is not a real browser, and automation cannot replace every accessibility or usability review.

Recall: What does a pure validator unit test fail to establish?

Interview: Explain component tests and browser acceptance tests using your own artifact. Defend the rule behind this scenario: What does a pure validator unit test fail to establish? Then explain one failure case and this limitation: A DOM simulator is not a real browser, and automation cannot replace every accessibility or usability review.

Quiz: What does a pure validator unit test fail to establish?

Whether blank input is rejected by the function.

Whether a rendered form has a usable accessible label and focus order.

Whether a return value equals the expected number.

Reference: Whether a rendered form has a usable accessible label and focus order. — DOM and browser behaviour must be observed at their own boundaries.

Sources:

Testing · official reference: https://testing-library.com/docs/react-testing-library/intro/

Playwright · official reference: https://playwright.dev/docs/intro

W3C accessibility tutorials · official reference: https://www.w3.org/WAI/tutorials/

### Git, code review and the intermediate project

Make a change another developer can understand, reproduce and review. Your portfolio should show decisions as well as code.

Local version control
git status shows pending changes; git diff shows their content. Stage only the intended files and inspect the staged diff before committing. Keep generated dependencies, credentials and local personal data out of the repository. Commit the lockfile, not node_modules.

Review a complete change
Explain the user problem, the new behaviour, relevant tests and material limitations. Keep unrelated formatting out of a behaviour change. A reviewer should be able to run the project from the README and understand one meaningful failure case without reading the conversation that led to it.

Intermediate project
Build the typed React learning journal with task creation, filtering, a loading-state model and URL-restored navigation. Reuse the pure domain rules, add interaction evidence and document client-only storage limitations. Include a component diagram and one bug you reproduced and fixed.

Worked code:
git status
git diff
git add src/App.tsx test/domain.test.mjs
git diff --staged
git commit -m "Reject blank study tasks with visible feedback"

Run these inside your own initialized learning repository.
Staging explicit files reduces accidental inclusion of unrelated material.

Mental model: A sequence of small, explained snapshots with checks attached.

Boundary: A clean Git history does not prove correctness. Review needs requirements, test evidence and an understandable change.

Worked example: git status
git diff
git add src/App.tsx test/domain.test.mjs
git diff --staged
git commit -m "Reject blank study tasks with visible feedback"

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: Git, GitHub/GitLab alternatives, npm and React

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Git, code review and the intermediate project lab. Initialise a repository for your copy of react-app and add a .gitignore for node_modules and dist.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Initialise a repository for your copy of react-app and add a .gitignore for node_modules and dist.

Expected: Only source, lockfile, tests and documentation are tracked.

Step 2

Implement one task/filter requirement with its test, inspect and commit the diff.

Expected: The commit explains one coherent behaviour change.

Step 3

Write a review-ready README and a short change description, then run tests/typecheck/build from a clean dependency install.

Expected: A reviewer has reproducible setup and evidence.

Expected: A typed React portfolio application, reproducible repository and review description.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A typed React portfolio application, reproducible repository and review description. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/git-review.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining local version control in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Only source, lockfile, tests and documentation are tracked.

seeker: Build interview evidence for git, code review and the intermediate project. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect git, code review and the intermediate project to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A clean Git history does not prove correctness. Review needs requirements, test evidence and an understandable change.

Recall: What belongs in a useful change description?

Interview: Explain git, code review and the intermediate project using your own artifact. Defend the rule behind this scenario: What belongs in a useful change description? Then explain one failure case and this limitation: A clean Git history does not prove correctness. Review needs requirements, test evidence and an understandable change.

Quiz: What belongs in a useful change description?

Only the number of edited files.

The problem, resulting behaviour and relevant validation.

A guarantee that no future bug is possible.

Reference: The problem, resulting behaviour and relevant validation. — Reviewers need the user outcome and evidence to assess the change.

Sources:

Git changes and commits · official reference: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository

Vite guide · official reference: https://vite.dev/guide/

Testing · official reference: https://testing-library.com/docs/react-testing-library/intro/

### Validation at a boundary

Check input before storing or using it. Client checks help people; the server must also enforce the rule. In this role, work through: A 400 response displays the server error without adding a phantom task. The practical workshop develops this into: Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.

Mental model: A gate with a checklist before a parcel enters a warehouse.

Boundary: Valid input can still be unauthorized; validation is not access control.

Role application: A receipt confirms a purchase; clicking Buy is only an attempt.

The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch.

Subtopic: Separate user input from the displayed result

Read a value, validate it, then update the display. A browser check improves feedback; it cannot replace validation at a server boundary.

Picture it: A draft form and an accepted record are different states.

```
const title = input.value.trim();
if (!title) {
  status.textContent = "Enter a task title.";
  return;
}
const item = document.createElement("li");
item.textContent = title;
list.append(item);
```

Try: In core/index.html, add a list with id="tasks" and select it as list. Add valid input as a new li; reject empty input before appending.

Expected: Rejected input adds no item. Each accepted submission adds one item.

Quick check: Does successful browser validation prove a remote service accepted the task?

Reasoning: No. Remote acceptance needs its own response and validation.

Reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting

Worked example: A 400 response displays the server error without adding a phantom task.

Shared foundation example: A blank title receives 400 and does not change task count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Frontend Developer: A 400 response displays the server error without adding a phantom task.

Predict the worked case

Read this case without running a tool: A 400 response displays the server error without adding a phantom task. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in validation at a boundary.

Connect the concept to the role

Apply this rule: Check input before storing or using it. Client checks help people; the server must also enforce the rule. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Valid input can still be unauthorized; validation is not access control.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies validation at a boundary to this case: A 400 response displays the server error without adding a phantom task. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A 400 response displays the server error without adding a phantom task. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Validation at a boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with validation at a boundary. Use the glossary below, then write your prediction for: A 400 response displays the server error without adding a phantom task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain validation at a boundary using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate validation at a boundary to a system or workflow you know. Explain validation at a boundary using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the server reject invalid input even if the form already checks it?

Interview: Explain validation at a boundary using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops.

Quiz: After the Rendering server state rehearsal, check this foundation: A browser rejects a blank field. A second client calls the API directly. Where must the same business rule be enforced?

Only in the browser to avoid duplicate logic.

At the server boundary before state changes.

Only after storing the input, in the dashboard.

Reference: At the server boundary before state changes. — Client checks improve feedback; the server must protect its contract for every caller.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: Separate user input from the displayed result: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting

### Rendering server state

The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch. In this role, work through: A 400 response displays the server error without adding a phantom task. The practical workshop develops this into: Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.

Mental model: A receipt confirms a purchase; clicking Buy is only an attempt.

Boundary: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.

Subtopic: Check HTTP status before using response data

fetch resolves when an HTTP response arrives, even for statuses such as 404. Check response.ok before processing success data. JSON parsing can fail separately.

Picture it: Receiving a parcel does not mean it contains the requested item.

```
async function loadTasks() {
  const response = await fetch("/api/tasks");
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}
```

Try: Use the original local server lab in this pack, not a file:// page. Compare a valid route with a nonexistent route in browser Network tools.

Expected: The missing route follows the error path rather than being treated as a successful task list.

Quick check: Does fetch reject automatically for every 404?

Reasoning: No. Check the response status yourself.

Reference: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

Subtopic: Represent loading, success and failure explicitly

Before awaiting a request, display a loading state. Replace it with a result or a readable error. Preserve useful user input when a request fails.

Picture it: A receipt desk can say waiting, completed or needs attention.

```
status.textContent = "Loading…";
try {
  const tasks = await loadTasks();
  status.textContent = `${tasks.length} tasks loaded`;
} catch (error) {
  status.textContent = "Could not load tasks. Try again.";
}
```

Try: Use loadTasks from the previous subtopic. In DevTools, test a slow connection and then offline mode against the local lab.

Expected: Loading is visible while waiting. Failure replaces it with feedback; it never leaves an endless success-looking state.

Quick check: Why keep loading and empty-result states separate?

Reasoning: No tasks is a successful result; waiting has no result yet.

Reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Using_promises

Worked example: A 400 response displays the server error without adding a phantom task.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Frontend Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

A 400 response displays the server error without adding a phantom task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.

```
node app.mjs test intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: No extra list item after failure; a recoverable message; the button works after recovery.

Role workshop · debug and verify

A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save ui-states.md and a four-state screenshot set. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: No extra list item after failure; a recoverable message; the button works after recovery.

Expected: No extra list item after failure; a recoverable message; the button works after recovery.

Troubleshoot: The role exercise differs from the prediction: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: ui-states.md and a four-state screenshot set; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rendering server state. Use the glossary below, then write your prediction for: A 400 response displays the server error without adding a phantom task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain rendering server state using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rendering server state to a system or workflow you know. Explain rendering server state using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.

Interview: Explain rendering server state using this case: A 400 response displays the server error without adding a phantom task. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A 400 response displays the server error without adding a phantom task.

Ignore the failing case and keep only the successful screenshot.

No extra list item after failure; a recoverable message; the button works after recovery.

Treat any successful command as proof that all business and access rules passed.

Reference: No extra list item after failure; a recoverable message; the button works after recovery. — The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch. No extra list item after failure; a recoverable message; the button works after recovery.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: Check HTTP status before using response data: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

Frontend reference: Represent loading, success and failure explicitly: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Using_promises

### Streaming UI: requests own their state

Streaming answers arrive in pieces. If a second request starts before the first ends, late chunks from the old request can overwrite the new answer. Give each request an ID, and let the UI accept chunks only for the active request.

Keep activeId, text and status in one reducer. Starting a request clears the previous draft. A chunk from any other ID leaves the state unchanged. A real DOM view renders this state; the local sandbox tests the reducer only.

Ignoring a late chunk does not cancel the server’s inference or billing. Pair UI ownership with AbortController and an appropriate server cancellation policy.

Mental model: User submit → new request ID → stream chunks → rendered draft. Picture the boundary as a checked gate between stages.

Boundary: Ignoring a late chunk does not cancel the server’s inference or billing. Pair UI ownership with AbortController and an appropriate server cancellation policy.

Worked example: function streamState(state, event) {
  if (event.type === 'START') return {activeId:event.id,text:'',status:'streaming'};
  if (event.id !== state.activeId || state.status !== 'streaming') return state;
  if (event.type === 'CHUNK') return {...state,text:state.text + event.text};
  if (event.type === 'DONE') return {...state,status:'done'};
  return state;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract frontend.zip, install Node.js LTS, then open production-ai/02-01-stream-request-state.

Tools for this exercise: JavaScript · local isolated workbench; Fetch / Streams API, WAI / WCAG as documented optional extensions

Course tool and framework map: Fetch / Streams API (Open web standard · local); WAI / WCAG (Open accessibility standard)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement streamState. Replay START a, START b, CHUNK a, CHUNK b and DONE b. Then connect this reducer to your own DOM outside the isolated sandbox.

Terminal folder: production-ai/02-01-stream-request-state

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Keep activeId, text and status in one reducer. Starting a request clears the previous draft. A chunk from any other ID leaves the state unchanged. A real DOM view renders this state; the local sandbox tests the reducer only.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement streamState. Replay START a, START b, CHUNK a, CHUNK b and DONE b. Then connect this reducer to your own DOM outside the isolated sandbox.

Expected: A new request clears the old answer

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Stale chunks cannot overwrite state; Only active chunks append before completion

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A new request clears the old answer; Stale chunks cannot overwrite state; Only active chunks append before completion. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Reject stale request IDs in the reducer. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/02-01-stream-request-state/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: User submit → new request ID → stream chunks → rendered draft. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Two streams overlap. How do you prevent an old answer from changing the new one? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Only the active request may change its draft. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Two streams overlap. How do you prevent an old answer from changing the new one?

Interview: Two streams overlap. How do you prevent an old answer from changing the new one? Explain the decision, a failing case and a production limitation.

Quiz: Two streams overlap. How do you prevent an old answer from changing the new one?

Increase the font size.

Append all chunks in arrival order.

Bind updates to the active request ID.

Reference: Bind updates to the active request ID. — The reducer must enforce ownership. Arrival order alone does not identify the user’s current request.

Sources:

MDN: using Fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

MDN: using readable streams: https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Using_readable_streams

### A network chunk is not a message

A transport can split a logical message across reads or deliver several messages in one read. Never call JSON.parse on every raw chunk and assume it contains exactly one object. Buffer text until the agreed delimiter appears.

This exercise uses newline-delimited JSON, not the full Server-Sent Events protocol. Keep the incomplete tail between reads and parse only complete nonempty lines. In a real UTF-8 stream, use a streaming TextDecoder so multi-byte characters can cross byte chunks.

Production parsers also need size limits, protocol errors and an explicit end-of-stream policy. NDJSON framing is not interchangeable with SSE data fields.

Mental model: Byte reads → streaming decode → text buffer → complete records. Picture the boundary as a checked gate between stages.

Boundary: Production parsers also need size limits, protocol errors and an explicit end-of-stream policy. NDJSON framing is not interchangeable with SSE data fields.

Worked example: function readLines(remainder, chunk) {
  const lines = (remainder + chunk).split('\n');
  const tail = lines.pop();
  return {items:lines.filter(x => x.trim()).map(x => JSON.parse(x)),remainder:tail};
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract frontend.zip, install Node.js LTS, then open production-ai/02-02-stream-framing.

Tools for this exercise: JavaScript · local isolated workbench; Fetch / Streams API, WAI / WCAG as documented optional extensions

Course tool and framework map: Fetch / Streams API (Open web standard · local); WAI / WCAG (Open accessibility standard)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement the NDJSON buffer, test every possible split in a short record, and document an end-of-stream error policy.

Terminal folder: production-ai/02-02-stream-framing

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This exercise uses newline-delimited JSON, not the full Server-Sent Events protocol. Keep the incomplete tail between reads and parse only complete nonempty lines. In a real UTF-8 stream, use a streaming TextDecoder so multi-byte characters can cross byte chunks.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement the NDJSON buffer, test every possible split in a short record, and document an end-of-stream error policy.

Expected: One complete line parses

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Split records retain the tail; Several records and blank lines work

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: One complete line parses; Split records retain the tail; Several records and blank lines work. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Parse complete newline-delimited records and retain the tail. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/02-02-stream-framing/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Byte reads → streaming decode → text buffer → complete records. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A read contains half a JSON object. What should the stream parser do? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Transport reads do not define application message boundaries. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A read contains half a JSON object. What should the stream parser do?

Interview: A read contains half a JSON object. What should the stream parser do? Explain the decision, a failing case and a production limitation.

Quiz: A read contains half a JSON object. What should the stream parser do?

Buffer it until the record delimiter arrives.

Invent the missing fields.

Treat the truncated object as the final answer.

Reference: Buffer it until the record delimiter arrives. — Separate transport framing from logical records. The receiver must retain incomplete text without claiming completion.

Sources:

MDN: using readable streams: https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Using_readable_streams

### Cancellation and honest partial answers

Stopping a stream is a state change, not proof that the server completed the task. Keep the received draft as partial and prevent later completion events from changing a cancelled request into success. Give the user a clear retry action.

CANCEL changes streaming to cancelled and preserves the draft. DONE changes only a streaming request to complete. In an actual fetch, AbortController interrupts client-side consumption; separately check how the backend cancels its work.

Client abort does not guarantee that remote work stopped or that a billable operation was undone. Never label a partial answer complete.

Mental model: Stop action → cancelled state → abort signal → user decision. Picture the boundary as a checked gate between stages.

Boundary: Client abort does not guarantee that remote work stopped or that a billable operation was undone. Never label a partial answer complete.

Worked example: function cancelState(state, event) {
  if (state.status !== 'streaming') return state;
  if (event === 'CANCEL') return {...state,status:'cancelled'};
  if (event === 'DONE') return {...state,status:'complete'};
  return state;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract frontend.zip, install Node.js LTS, then open production-ai/02-03-stream-cancellation.

Tools for this exercise: JavaScript · local isolated workbench; Fetch / Streams API, WAI / WCAG as documented optional extensions

Course tool and framework map: Fetch / Streams API (Open web standard · local); WAI / WCAG (Open accessibility standard)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement cancelState and a late-DONE test. Build a small DOM demo with a Stop button, partial label and AbortController using the official Fetch guide.

Terminal folder: production-ai/02-03-stream-cancellation

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

CANCEL changes streaming to cancelled and preserves the draft. DONE changes only a streaming request to complete. In an actual fetch, AbortController interrupts client-side consumption; separately check how the backend cancels its work.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement cancelState and a late-DONE test. Build a small DOM demo with a Stop button, partial label and AbortController using the official Fetch guide.

Expected: Cancel preserves the partial answer

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Late completion is ignored; Normal completion and unknown events differ

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Cancel preserves the partial answer; Late completion is ignored; Normal completion and unknown events differ. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Accept DONE only from streaming state. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/02-03-stream-cancellation/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Stop action → cancelled state → abort signal → user decision. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. The browser aborts a stream. What may the UI truthfully claim? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A received completion event cannot resurrect a cancelled run. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: The browser aborts a stream. What may the UI truthfully claim?

Interview: The browser aborts a stream. What may the UI truthfully claim? Explain the decision, a failing case and a production limitation.

Quiz: The browser aborts a stream. What may the UI truthfully claim?

The server never ran.

The local request was stopped; remote completion may need checking.

The answer is complete.

Reference: The local request was stopped; remote completion may need checking. — Cancellation has a scope. Preserve that distinction when reporting status or retrying an operation.

Sources:

MDN: using Fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

### Accessible status without announcing every token

A streaming page needs accessible feedback, but announcing every token can make it unusable. Keep the answer readable and announce meaningful status transitions: started, finished, stopped or failed. Avoid moving keyboard focus whenever a chunk arrives.

Produce a short status message when the status changes. Ordinary text chunks leave the status message unchanged. A DOM implementation can put that message in a polite live region and keep the stream text outside it.

A string function is not an accessibility audit. Check keyboard control, focus, screen readers, contrast and reduced motion in the complete interface.

Mental model: Status transition → concise live message → learner reads the answer. Picture the boundary as a checked gate between stages.

Boundary: A string function is not an accessibility audit. Check keyboard control, focus, screen readers, contrast and reduced motion in the complete interface.

Worked example: function statusMessage(previous, current) {
  if (previous === current) return '';
  return {streaming:'Answer started.',complete:'Answer ready.',cancelled:'Answer stopped; partial text remains.',error:'Answer failed; try again.'}[current] || '';
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract frontend.zip, install Node.js LTS, then open production-ai/02-04-stream-accessibility.

Tools for this exercise: JavaScript · local isolated workbench; Fetch / Streams API, WAI / WCAG as documented optional extensions

Course tool and framework map: Fetch / Streams API (Open web standard · local); WAI / WCAG (Open accessibility standard)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement statusMessage. Add a polite live status and a keyboard-operable Stop button to a separate local page, then record a manual keyboard and screen-reader check.

Terminal folder: production-ai/02-04-stream-accessibility

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Produce a short status message when the status changes. Ordinary text chunks leave the status message unchanged. A DOM implementation can put that message in a polite live region and keep the stream text outside it.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement statusMessage. Add a polite live status and a keyboard-operable Stop button to a separate local page, then record a manual keyboard and screen-reader check.

Expected: Starting is announced

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Chunks do not repeat the announcement; Completion and error are clear

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Starting is announced; Chunks do not repeat the announcement; Completion and error are clear. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Announce meaningful transitions and keep focus stable. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/02-04-stream-accessibility/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Status transition → concise live message → learner reads the answer. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. How should an accessible interface report incoming answer tokens? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: New answer text is not automatically a new announcement. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: How should an accessible interface report incoming answer tokens?

Interview: How should an accessible interface report incoming answer tokens? Explain the decision, a failing case and a production limitation.

Quiz: How should an accessible interface report incoming answer tokens?

Move focus to each token.

Put the whole answer in an assertive live region.

Keep text readable and announce meaningful status changes.

Reference: Keep text readable and announce meaningful status changes. — Status messages support orientation without taking over the learner’s reading or keyboard position.

Sources:

W3C: status messages: https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

State and recovery: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.

Apply state and recovery in Frontend Developer: Use the concept to complete this role exercise: Audit keyboard focus, slow responses and repeated submission

Safe DOM updates: Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item.

### Accessibility: semantics, focus and complete user journeys

Accessibility is a property of a complete interaction, not a score added after styling. Audit the journey from input through feedback and recovery.

Prefer native behaviour
Use buttons for actions, links for navigation and labelled native controls for input. Add ARIA only where it accurately describes behaviour you actually implement. ARIA does not create keyboard behaviour. A custom widget can require a substantial interaction contract that a native element already provides.

Manage focus predictably
A dialog should have a meaningful name, keep keyboard interaction within the active modal context and restore focus when closed. Test Escape where dismissal is appropriate. A route transition should not leave focus in removed content. Do not move focus on every keystroke or merely to draw attention.

Audit a full flow
Test adding an invalid task, correcting it, filtering results and returning from a dialog. Inspect names, roles and relationships. Check keyboard order, zoom, contrast and status announcements. Record the actual browser and assistive technology used; do not claim a screen-reader test if you only inspected markup.

Worked code:
<dialog aria-labelledby="helpTitle">
  <h2 id="helpTitle">Task help</h2>
  <p>Write one concrete study action.</p>
  <button type="button">Close help</button>
</dialog>
<!-- Use showModal(), wire Close, and restore the invoking control. -->

The dialog name comes from a visible heading.
The fragment needs opening/closing handlers; semantics alone are not the whole interaction.

Mental model: Follow one user through the entire task instead of inspecting isolated controls.

Boundary: Automated scanners find some defects. A passing scan is not a conformance certificate or a replacement for human testing.

Worked example: <dialog aria-labelledby="helpTitle">
  <h2 id="helpTitle">Task help</h2>
  <p>Write one concrete study action.</p>
  <button type="button">Close help</button>
</dialog>
<!-- Use showModal(), wire Close, and restore the invoking control. -->

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: Browser accessibility tree, keyboard, optional axe; screen reader where available

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Accessibility: semantics, focus and complete user journeys lab. Add a native help dialog to your app with an explicit Close control and focus restoration.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add a native help dialog to your app with an explicit Close control and focus restoration.

Expected: Opening and closing it preserves a predictable task flow.

Step 2

Complete the full flow using only Tab, Shift+Tab, Enter and Escape; test 200% zoom.

Expected: Controls remain reachable and the focus indicator remains visible.

Step 3

Record scanner findings separately from manual findings and repair one confirmed issue.

Expected: Your accessibility report states evidence and testing limits precisely.

Expected: A journey-based accessibility report with before/after evidence and tested focus recovery.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A journey-based accessibility report with before/after evidence and tested focus recovery. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/accessibility-audit.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining prefer native behaviour in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Opening and closing it preserves a predictable task flow.

seeker: Build interview evidence for accessibility: semantics, focus and complete user journeys. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect accessibility: semantics, focus and complete user journeys to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Automated scanners find some defects. A passing scan is not a conformance certificate or a replacement for human testing.

Recall: Does adding role="button" to a div automatically supply complete button keyboard behaviour?

Interview: Explain accessibility: semantics, focus and complete user journeys using your own artifact. Defend the rule behind this scenario: Does adding role="button" to a div automatically supply complete button keyboard behaviour? Then explain one failure case and this limitation: Automated scanners find some defects. A passing scan is not a conformance certificate or a replacement for human testing.

Quiz: Does adding role="button" to a div automatically supply complete button keyboard behaviour?

Yes.

Only on mobile.

No.

Reference: No. — Roles expose semantics; the required behaviour must still be implemented. Prefer a native button.

Sources:

W3C accessibility tutorials · official reference: https://www.w3.org/WAI/tutorials/

Labels · official reference: https://www.w3.org/WAI/tutorials/forms/labels/

Testing · official reference: https://testing-library.com/docs/react-testing-library/intro/

### XSS, safe rendering and trust boundaries

Treat user input, API data and browser storage as untrusted until validated for the specific place they are used.

Understand the sink
A sink is where a value is used. textContent displays text, whereas innerHTML parses markup. React text expressions normally render text, but raw-HTML escape hatches change the risk. Avoid parsing user content as HTML unless a carefully reviewed sanitisation design is actually required.

Validate for context
A user-provided link needs a permitted scheme and product policy, not just escaped quotes. An API identifier needs its own format and authorisation checks. Keep secrets on the server: anything built into a public JavaScript bundle can be inspected by the user. Do not store real credentials in a learning fixture.

Prove a regression safely
Use synthetic literal markup on your own local app. Verify that it appears as text and does not become a new DOM element. Add a negative test for the previously unsafe sink. Document the actor, input, boundary and effect rather than claiming the whole application is secure after one repair.

Worked code:
const value = "<strong>Untrusted title</strong>";
const row = document.createElement("li");
row.textContent = value;
// For a link destination, apply a separate URL policy:
const url = new URL("https://example.test/guide");
if (url.protocol !== "https:") throw new Error("Unsupported URL");

The angle-bracket title stays text.
An HTTPS check is only one policy condition; it does not establish that a destination is trusted.

Mental model: A value crossing a boundary needs rules for its destination, not a single universal safe stamp.

Boundary: Text escaping does not make every URL, CSS value or HTML fragment safe. Browser-only checks cannot authorise server actions.

Worked example: const value = "<strong>Untrusted title</strong>";
const row = document.createElement("li");
row.textContent = value;
// For a link destination, apply a separate URL policy:
const url = new URL("https://example.test/guide");
if (url.protocol !== "https:") throw new Error("Unsupported URL");

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: DOM inspection, OWASP guidance and regression tests

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the XSS, safe rendering and trust boundaries lab. Trace input, storage and API values to every rendering sink in your app.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Trace input, storage and API values to every rendering sink in your app.

Expected: The report lists text, HTML and URL contexts separately.

Step 2

Submit literal markup to the local task form and inspect the DOM.

Expected: The title remains text; no strong element is created from it.

Step 3

Add a regression test and remove one unnecessary raw-HTML sink.

Expected: The negative case remains checked after the repair.

Expected: A small frontend threat model and a safe-rendering regression test.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A small frontend threat model and a safe-rendering regression test. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/frontend-security.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining understand the sink in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The report lists text, HTML and URL contexts separately.

seeker: Build interview evidence for xss, safe rendering and trust boundaries. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect xss, safe rendering and trust boundaries to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Text escaping does not make every URL, CSS value or HTML fragment safe. Browser-only checks cannot authorise server actions.

Recall: Does HTML-escaping a javascript: URL make it an acceptable link destination?

Interview: Explain xss, safe rendering and trust boundaries using your own artifact. Defend the rule behind this scenario: Does HTML-escaping a javascript: URL make it an acceptable link destination? Then explain one failure case and this limitation: Text escaping does not make every URL, CSS value or HTML fragment safe. Browser-only checks cannot authorise server actions.

Quiz: Does HTML-escaping a javascript: URL make it an acceptable link destination?

Yes, escaping validates its scheme.

No; URL policy is a separate context-specific check.

Only if the title is short.

Reference: No; URL policy is a separate context-specific check. — Escaping markup does not replace validating the destination scheme and product policy.

Sources:

Security · official reference: https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html

DOM scripting · official reference: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting

Content Security Policy · official reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CSP

### CSP, CORS, authentication and client configuration

Browser policies and server security controls solve different problems. Learn which boundary owns each decision.

CORS is not authorisation
The same-origin policy limits what scripts can read across origins. CORS lets a server opt into specified cross-origin reads. It does not authenticate a user or prevent every cross-origin request from being sent. Fix a real origin contract instead of disabling browser protections.

CSP constrains resource execution
Content Security Policy can restrict scripts and other resources. It is defence in depth, not a substitute for safe sinks. A strict policy often needs external scripts or managed nonces/hashes rather than broad unsafe-inline. Test in report-only mode where supported before enforcing a new production header.

Identity remains server-owned
A hidden button is not access control. The API checks who is calling and what they can do. Cookie sessions and bearer tokens have different XSS/CSRF tradeoffs. Public environment variables in a client build are configuration, not secrets. Use an established identity design and a server-owned authorisation boundary.

Worked code:
# Illustrative HTTP response header for a simple self-hosted static app
Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'
# Review required resources and deployment support before enforcing.

This is a response-header example, not a terminal command.
An app with inline scripts needs an appropriate policy migration; do not copy a breaking header blindly.

Mental model: Different checkpoints inspect different documents; passing one checkpoint does not grant every permission.

Boundary: This lesson uses a local policy analysis. It does not implement a production identity service or prove a deployment secure.

Worked example: # Illustrative HTTP response header for a simple self-hosted static app
Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'
# Review required resources and deployment support before enforcing.

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: Network panel, HTTP headers and deployment configuration

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the CSP, CORS, authentication and client configuration lab. Draw browser, static host, API and identity boundaries for your project.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Draw browser, static host, API and identity boundaries for your project.

Expected: Each authentication/authorisation decision has an owner.

Step 2

Inspect the local API response and compare same-origin reads with an intentionally different origin.

Expected: Your diagnosis distinguishes policy failures from HTTP application errors.

Step 3

Write a CSP rollout and client-secret review for your host; mark unexecuted changes as proposed.

Expected: The report identifies supported controls and a verification/rollback plan.

Expected: A browser/server boundary diagram and reviewed client configuration policy.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A browser/server boundary diagram and reviewed client configuration policy. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/browser-boundaries.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining cors is not authorisation in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Each authentication/authorisation decision has an owner.

seeker: Build interview evidence for csp, cors, authentication and client configuration. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect csp, cors, authentication and client configuration to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: This lesson uses a local policy analysis. It does not implement a production identity service or prove a deployment secure.

Recall: An API allows your origin with CORS. Does that authorise a user to delete a record?

Interview: Explain csp, cors, authentication and client configuration using your own artifact. Defend the rule behind this scenario: An API allows your origin with CORS. Does that authorise a user to delete a record? Then explain one failure case and this limitation: This lesson uses a local policy analysis. It does not implement a production identity service or prove a deployment secure.

Quiz: An API allows your origin with CORS. Does that authorise a user to delete a record?

Yes, origin and user permission are identical.

Only when using React.

No; the API still needs authentication and authorisation.

Reference: No; the API still needs authentication and authorisation. — CORS controls browser cross-origin reading, not user permissions.

Sources:

Content Security Policy · official reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CSP

HTTP overview · official reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

Security · official reference: https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html

### Measure loading, responsiveness and layout stability

Improve a measured bottleneck. Separate controlled lab observations from what real learners experience on varied devices and connections.

Choose a user outcome
Identify the screen and interaction that feels slow. Current Core Web Vitals cover loading through LCP, interaction responsiveness through INP and unexpected layout shifts through CLS. Record the device, network, route and build version. Different metrics describe different problems.

Inspect work before optimising
Use Network to inspect transferred assets and Performance to inspect long tasks and rendering. A large image may delay content; a long synchronous calculation may block interaction; missing dimensions may move controls. Do not assume every slow interaction needs React memoisation.

Compare responsibly
Repeat under the same conditions and compare the relevant trace segment. Field data should be evaluated over an appropriate population, including mobile, rather than one cherry-picked session. Publish measured results with their method and avoid presenting a lab result as a production percentile.

Worked code:
performance.mark("filter-start");
const visible = tasks.filter(task => !task.done);
performance.mark("filter-end");
performance.measure("filter-calculation", "filter-start", "filter-end");
// This measures the calculation, not the complete input-to-paint interaction.

The mark labels delimit only the work inside them.
Use the browser trace to inspect rendering and interaction beyond the function.

Mental model: A performance investigation is a before/after experiment under stated conditions.

Boundary: One fast desktop run is not a global user experience measurement. A score is a diagnostic signal, not the whole product outcome.

Worked example: performance.mark("filter-start");
const visible = tasks.filter(task => !task.done);
performance.mark("filter-end");
performance.measure("filter-calculation", "filter-start", "filter-end");
// This measures the calculation, not the complete input-to-paint interaction.

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: Chrome/Firefox performance tools; Web Vitals methodology

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Measure loading, responsiveness and layout stability lab. Build your app and capture a baseline trace for loading and filtering with a large synthetic list.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Build your app and capture a baseline trace for loading and filtering with a large synthetic list.

Expected: The trace identifies the tested route and environment.

Step 2

Find one actual bottleneck and propose the smallest relevant change.

Expected: Your hypothesis connects a resource or task to a user-visible delay.

Step 3

Repeat the same experiment after the change and report both results.

Expected: The comparison includes method and limitations, even if the change did not help.

Expected: A reproducible performance report with traces and one evidence-based improvement.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A reproducible performance report with traces and one evidence-based improvement. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/measure-performance.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining choose a user outcome in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The trace identifies the tested route and environment.

seeker: Build interview evidence for measure loading, responsiveness and layout stability. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect measure loading, responsiveness and layout stability to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: One fast desktop run is not a global user experience measurement. A score is a diagnostic signal, not the whole product outcome.

Recall: A calculation measure improves. Does that prove the full interaction is now fast?

Interview: Explain measure loading, responsiveness and layout stability using your own artifact. Defend the rule behind this scenario: A calculation measure improves. Does that prove the full interaction is now fast? Then explain one failure case and this limitation: One fast desktop run is not a global user experience measurement. A score is a diagnostic signal, not the whole product outcome.

Quiz: A calculation measure improves. Does that prove the full interaction is now fast?

No; rendering and other work also contribute.

Yes, all browser work is included automatically.

Only if the variable name is short.

Reference: No; rendering and other work also contribute. — A narrow measurement must not be presented as an end-to-end responsiveness result.

Sources:

Perf · official reference: https://web.dev/articles/vitals

Workers · official reference: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers

Imagesperf · official reference: https://web.dev/learn/performance/image-performance

### Images, code splitting and expensive work

Send only what the current task needs and keep long work from blocking interaction. Optimise after measuring.

Image delivery
Provide appropriate intrinsic dimensions and compressed sources. srcset and sizes help the browser choose a suitable image resource. Lazy loading suits some offscreen images, but can hurt an image needed for the initial view. Test actual requested sizes in Network instead of trusting the CSS dimensions.

Split optional code
A dynamic import can load an optional feature on demand. Show a meaningful loading or failure state. Check the production output because development serving is different from a built bundle. Keep a rollback strategy when a new HTML entry refers to assets that an old cache cannot find.

Move appropriate work
A web worker can perform suitable CPU work off the main thread and communicate by messages. It cannot directly manipulate the document DOM. Validate message shapes and terminate workers when the owner no longer needs them. For small work, avoiding unnecessary computation may be simpler than introducing a worker.

Worked code:
async function openOptionalReport() {
  try {
    const { buildReport } = await import("./report.js");
    return buildReport();
  } catch {
    return "Report unavailable. Try again.";
  }
}

Create report.js with a named buildReport export before using this fragment.
The error path is part of the feature, not an afterthought.

Mental model: Deliver the first useful box now; bring optional tools when they are needed.

Boundary: Lazy loading can delay essential content. Moving work to a worker adds communication and data-transfer costs.

Worked example: async function openOptionalReport() {
  try {
    const { buildReport } = await import("./report.js");
    return buildReport();
  } catch {
    return "Report unavailable. Try again.";
  }
}

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: Dynamic import, responsive images, web workers and build inspection

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Images, code splitting and expensive work lab. Add an optional report module to react-app and load it only through an explicit action.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Add an optional report module to react-app and load it only through an explicit action.

Expected: The initial route does not need to execute that feature.

Step 2

Build and inspect the emitted assets/Network requests; test a failed optional load.

Expected: The user receives useful failure feedback rather than a blank panel.

Step 3

Compare a large calculation on the main thread with the supplied worker example.

Expected: Your trace reports responsiveness and messaging overhead separately.

Expected: A measured optional feature and a documented image/CPU optimisation decision.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A measured optional feature and a documented image/CPU optimisation decision. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/assets-and-work.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining image delivery in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The initial route does not need to execute that feature.

seeker: Build interview evidence for images, code splitting and expensive work. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect images, code splitting and expensive work to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Lazy loading can delay essential content. Moving work to a worker adds communication and data-transfer costs.

Recall: Can a web worker directly update document.querySelector("h1") in the page?

Interview: Explain images, code splitting and expensive work using your own artifact. Defend the rule behind this scenario: Can a web worker directly update document.querySelector("h1") in the page? Then explain one failure case and this limitation: Lazy loading can delay essential content. Moving work to a worker adds communication and data-transfer costs.

Quiz: Can a web worker directly update document.querySelector("h1") in the page?

Yes, workers share the page DOM.

No; send a message and let the main thread update the DOM.

Only with a longer timeout.

Reference: No; send a message and let the main thread update the DOM. — Workers have a separate execution context without direct access to the page DOM.

Sources:

Imagesperf · official reference: https://web.dev/learn/performance/image-performance

Workers · official reference: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers

Vite guide · official reference: https://vite.dev/guide/

### Offline behaviour, caches and update recovery

An offline-capable interface must explain which content is available and how updates are handled.

Understand service-worker ownership
A service worker can intercept requests within its scope and use caches. It runs in a separate worker context and has its own lifecycle. Register it only from an appropriate secure context, including supported local development exceptions. Scope and update behaviour matter as much as the fetch handler.

Choose a strategy by resource
Versioned static assets can use a different strategy from changing API data. A stale cached response can look like a successful fresh load, so state freshness honestly. Avoid caching authenticated data by default. Decide what should happen when the network and cache both miss.

Test upgrades and rollback
A new release must not strand clients with HTML pointing to unavailable old assets. Test first install, offline revisit, a new version and recovery from a bad cache. The pack includes an isolated optional offline-demo folder; it does not register a worker on the main course website.

Worked code:
// In the isolated offline-demo only:
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(() => {
    document.querySelector("#status").textContent = "Offline setup unavailable";
  });
}

Registration is scoped to the demo folder.
Use DevTools Application to inspect and unregister only the demo’s worker.

Mental model: A local shelf of saved resources with an explicit replacement policy.

Boundary: A cache is not the source of truth for every resource. Sensitive or user-specific responses need a deliberate policy.

Worked example: // In the isolated offline-demo only:
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(() => {
    document.querySelector("#status").textContent = "Offline setup unavailable";
  });
}

Setup: Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Tools for this exercise: Service workers, Cache Storage and browser Application panel

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Offline behaviour, caches and update recovery lab. Serve course-labs locally and open /offline-demo/. Inspect the registered worker scope.

Terminal folder: course-labs

```
python3 serve.py
# Windows alternative: py serve.py
```

Prepare your local workspace

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Serve course-labs locally and open /offline-demo/. Inspect the registered worker scope.

Expected: Only the demo folder is controlled.

Step 2

Load once online, then revisit offline and inspect the visible cached-content message.

Expected: The demo works for its declared cached shell and explains the limit.

Step 3

Change the cache version in your copy, test an update and unregister the demo after finishing.

Expected: You have update evidence and a cleanly removable local experiment.

Expected: An offline/update test matrix and a documented resource-cache policy.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in web. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: An offline/update test matrix and a documented resource-cache policy. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/offline-cache.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining understand service-worker ownership in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Only the demo folder is controlled.

seeker: Build interview evidence for offline behaviour, caches and update recovery. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect offline behaviour, caches and update recovery to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A cache is not the source of truth for every resource. Sensitive or user-specific responses need a deliberate policy.

Recall: Should every authenticated API response be cached automatically for offline use?

Interview: Explain offline behaviour, caches and update recovery using your own artifact. Defend the rule behind this scenario: Should every authenticated API response be cached automatically for offline use? Then explain one failure case and this limitation: A cache is not the source of truth for every resource. Sensitive or user-specific responses need a deliberate policy.

Quiz: Should every authenticated API response be cached automatically for offline use?

No; privacy, freshness and authorisation need a deliberate policy.

Yes, any response is a public static asset.

Only if the cache name is short.

Reference: No; privacy, freshness and authorisation need a deliberate policy. — User-specific data requires explicit privacy and lifecycle decisions.

Sources:

Progressive web apps · official reference: https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps

Workers · official reference: https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers

HTTP overview · official reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

### Architecture, domain boundaries and design systems

Organise a frontend around understandable responsibilities. Design for change without adding layers that solve no current problem.

Separate domain and presentation
Pure validation and task transitions can live outside React. Components translate user actions into those operations and present their results. An API adapter handles transport and parsing. This separation lets tests target a business rule without booting the whole interface.

Create a small design system
Define shared tokens for space, typography, colour and focus. Build a component when it has a clear repeated responsibility and interaction contract. A reusable button includes keyboard/focus/loading/disabled behaviour, not merely rounded corners. Keep component examples and accessibility checks close to the source.

Record a decision
An architecture decision record states context, options, choice, consequences and a revisit trigger. Compare a local state solution with a shared store based on actual ownership and update needs. Name measurable symptoms that would justify a later change rather than promising an architecture that scales infinitely.

Worked code:
src/
  domain.mjs        # validation and state transitions
  api.ts            # transport, parsing and boundary validation
  components/       # accessible presentation and interactions
  App.tsx           # composition and state ownership
  tokens.css        # shared visual decisions

This structure is a starting point, not a mandatory enterprise template.
Keep dependencies directed so pure domain rules do not import UI code.

Mental model: A map showing who owns each rule, state value and dependency.

Boundary: Folder names do not enforce an architecture. Imports, contracts and tests reveal the actual boundaries.

Worked example: src/
  domain.mjs        # validation and state transitions
  api.ts            # transport, parsing and boundary validation
  components/       # accessible presentation and interactions
  App.tsx           # composition and state ownership
  tokens.css        # shared visual decisions

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: Module dependency review, component examples; Storybook as an optional alternative

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Architecture, domain boundaries and design systems lab. Draw imports and state ownership for your intermediate app before restructuring.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Draw imports and state ownership for your intermediate app before restructuring.

Expected: The current coupling is visible.

Step 2

Extract one domain rule and one repeated accessible control with tests.

Expected: The change reduces a concrete duplication or testing difficulty.

Step 3

Write an ADR comparing two designs and record the tradeoff and revisit trigger.

Expected: A reviewer can understand why your chosen boundary exists.

Expected: An architecture diagram, tested boundary refactor and one decision record.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: An architecture diagram, tested boundary refactor and one decision record. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/frontend-architecture.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining separate domain and presentation in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The current coupling is visible.

seeker: Build interview evidence for architecture, domain boundaries and design systems. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect architecture, domain boundaries and design systems to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Folder names do not enforce an architecture. Imports, contracts and tests reveal the actual boundaries.

Recall: Which is strongest evidence that domain logic is separate from UI?

Interview: Explain architecture, domain boundaries and design systems using your own artifact. Defend the rule behind this scenario: Which is strongest evidence that domain logic is separate from UI? Then explain one failure case and this limitation: Folder names do not enforce an architecture. Imports, contracts and tests reveal the actual boundaries.

Quiz: Which is strongest evidence that domain logic is separate from UI?

A folder named enterprise.

A colourful architecture diagram alone.

Domain rules can be tested without importing React or the DOM.

Reference: Domain rules can be tested without importing React or the DOM. — The actual dependency boundary is more informative than naming.

Sources:

Modules · official reference: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

State · official reference: https://react.dev/learn/managing-state

Testing · official reference: https://testing-library.com/docs/react-testing-library/intro/

### Client rendering, server rendering and hydration

Choose where initial HTML is produced based on content, interaction, hosting and operational constraints.

Compare delivery modes
Client rendering builds much of the UI after JavaScript loads. Static generation produces HTML ahead of requests. Server rendering produces HTML at request time or through a cache. A real framework may combine these approaches per route. Evaluate first content, interaction, freshness and hosting together.

Hydration needs agreement
Hydration connects client behaviour to pre-rendered HTML. Server and initial client output should agree. Random values, local time differences and browser-only storage reads during initial rendering can create mismatches. Move browser-specific synchronisation to the appropriate client lifecycle rather than hiding the warning.

Make a bounded comparison
The supplied Vite starter is a client app; it is not an SSR framework. For this lesson compare the same small component rendered with React server APIs in a separate Node script, then document what a production framework would additionally own. Do not deploy a teaching script as an unreviewed production server.

Worked code:
// server-render.mjs — a local comparison, not a production server
import React from "react";
import { renderToString } from "react-dom/server";
const view = React.createElement("h1", null, "Study journal");
console.log(renderToString(view));

Run inside react-app where React dependencies are installed.
This script produces HTML text; it does not implement routing, data loading or hydration.

Mental model: A page can arrive already assembled, be assembled in the browser, or combine both approaches.

Boundary: SSR is not automatically faster or cheaper. It introduces server work, caching and hydration constraints.

Worked example: // server-render.mjs — a local comparison, not a production server
import React from "react";
import { renderToString } from "react-dom/server";
const view = React.createElement("h1", null, "Study journal");
console.log(renderToString(view));

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: React server APIs; Next.js/Nuxt/Astro as framework alternatives to investigate

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Client rendering, server rendering and hydration lab. Save server-render.mjs inside your react-app copy and run node server-render.mjs.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Save server-render.mjs inside your react-app copy and run node server-render.mjs.

Expected: The terminal receives an h1 HTML string.

Step 2

Compare that output with the built client app’s initial HTML and later DOM.

Expected: Your report distinguishes initial delivery from client execution.

Step 3

Write a decision for a public article site versus a private task dashboard, including hosting and freshness.

Expected: The choice includes tradeoffs rather than a claim that one mode always wins.

Expected: A local rendering comparison and a route-specific delivery decision.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A local rendering comparison and a route-specific delivery decision. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/rendering-strategies.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining compare delivery modes in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The terminal receives an h1 HTML string.

seeker: Build interview evidence for client rendering, server rendering and hydration. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect client rendering, server rendering and hydration to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: SSR is not automatically faster or cheaper. It introduces server work, caching and hydration constraints.

Recall: What is a common cause of hydration mismatch?

Interview: Explain client rendering, server rendering and hydration using your own artifact. Defend the rule behind this scenario: What is a common cause of hydration mismatch? Then explain one failure case and this limitation: SSR is not automatically faster or cheaper. It introduces server work, caching and hydration constraints.

Quiz: What is a common cause of hydration mismatch?

Matching deterministic initial output.

Different server and initial-client content, such as an uncontrolled random value.

Using semantic HTML.

Reference: Different server and initial-client content, such as an uncontrolled random value. — Hydration expects the initial client description to match the delivered markup.

Sources:

Render · official reference: https://react.dev/reference/react-dom/server

React Quick Start · official reference: https://react.dev/learn

Vite guide · official reference: https://vite.dev/guide/

### CI pipelines, quality gates and dependency review

A release pipeline should reproduce the checks a reviewer relies on, then publish a known build artifact.

Reproduce the environment
Use a supported runtime and the committed dependency lockfile. A clean npm ci followed by tests, typecheck and production build catches failures hidden by a developer’s old node_modules. Keep build logs and record the source revision with the artifact.

Run meaningful gates
Use pure tests for domain rules and selected interaction tests for critical flows. Include accessibility and bundle checks where justified. Do not make arbitrary coverage percentages the sole quality measure. Treat dependency updates as reviewed changes with compatibility and security checks.

Limit pipeline permissions
Read-only checks should not receive deployment credentials. Publishing needs narrowly scoped permissions and a clear target. Avoid passing secrets to untrusted contribution code. The supplied ci-example.yml is a teaching file copied into your own repository only after reviewing its triggers and permissions.

Worked code:
# Core validation commands inside react-app
npm ci
npm test
npm run typecheck
npm run build
# Publish the resulting dist/ artifact only after these pass.

CI should use the same documented commands as local verification.
The pack’s YAML example runs checks; it does not secretly publish a site.

Mental model: A sequence of evidence gates attached to one exact source revision.

Boundary: A green pipeline only proves the checks it ran. It does not establish every browser/device behaviour or authorise a risky release.

Worked example: # Core validation commands inside react-app
npm ci
npm test
npm run typecheck
npm run build
# Publish the resulting dist/ artifact only after these pass.

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: GitHub Actions; GitLab CI/Azure Pipelines alternatives, npm lockfile

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the CI pipelines, quality gates and dependency review lab. Run all four commands from a fresh install and record the source revision.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Run all four commands from a fresh install and record the source revision.

Expected: The build can be reproduced from the repository.

Step 2

Copy ci-example.yml into your own repository workflow folder after reviewing it. Trigger it with a small test change.

Expected: The workflow reports the same quality gates.

Step 3

Introduce a deliberate failing test on a temporary learning branch and verify the gate blocks a successful validation result. Restore it.

Expected: Your evidence demonstrates the gate, not just its configuration.

Expected: A reviewed validation workflow and a demonstrated failure/recovery run.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A reviewed validation workflow and a demonstrated failure/recovery run. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/ci-release.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining reproduce the environment in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The build can be reproduced from the repository.

seeker: Build interview evidence for ci pipelines, quality gates and dependency review. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect ci pipelines, quality gates and dependency review to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A green pipeline only proves the checks it ran. It does not establish every browser/device behaviour or authorise a risky release.

Recall: Which artifact should a deployment publish?

Interview: Explain ci pipelines, quality gates and dependency review using your own artifact. Defend the rule behind this scenario: Which artifact should a deployment publish? Then explain one failure case and this limitation: A green pipeline only proves the checks it ran. It does not establish every browser/device behaviour or authorise a risky release.

Quiz: Which artifact should a deployment publish?

Whatever happens to be in a developer’s old folder.

The build produced from the exact validated revision.

The complete node_modules directory.

Reference: The build produced from the exact validated revision. — The deployed artifact must be tied to the evidence-producing source and build.

Sources:

Actions · official reference: https://docs.github.com/en/actions/automating-builds-and-tests

Git changes and commits · official reference: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository

Vite guide · official reference: https://vite.dev/guide/

### Deploy, verify, observe and roll back

Deployment is not finished when a command exits. Verify the user journey on the public build and prepare recovery.

Build for the hosting path
A site under a repository subpath needs matching asset URLs. The supplied Vite config uses a relative base for the static app. A client path router needs a server fallback; query/hash navigation can be simpler on static hosting. Test a direct link and reload, not only the root page.

Verify the actual release
Preview dist locally first, then publish only intended public assets using your host’s documented workflow. Check asset requests, a task submission, keyboard focus, a deep link and error feedback on the live site. Avoid putting learning notes or personal files into the public package.

Observe and recover
Record the deployed revision and a short smoke-check result. For a defect, preserve evidence, assess impact and roll back to a previously validated artifact if that is the chosen recovery. Client-side error reporting needs privacy-conscious collection and careful handling of source maps. Do not log typed personal data.

Worked code:
npm run build
npm run preview -- --host 127.0.0.1
# Open the printed URL and verify the built app before publication.
# Record: source revision, deployed URL, smoke checks, rollback artifact.

Preview serves the production output locally.
Your chosen host’s publication steps remain an explicit reviewed action.

Mental model: A release is a reversible change with an observable success condition.

Boundary: Static hosting serves client assets. It does not automatically supply a secure backend, account system or server-side environment variables.

Worked example: npm run build
npm run preview -- --host 127.0.0.1
# Open the printed URL and verify the built app before publication.
# Record: source revision, deployed URL, smoke checks, rollback artifact.

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: Vite production build/preview; GitHub Pages, Cloudflare Pages or Netlify alternatives

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Deploy, verify, observe and roll back lab. Build and preview the app, then test direct filter links and reload under a subpath.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Build and preview the app, then test direct filter links and reload under a subpath.

Expected: The built assets and selected view resolve correctly.

Step 2

Publish your learning artifact using the official static-host guide and run the smoke checklist.

Expected: The live site matches the validated build and expected user flow.

Step 3

Write a rollback runbook and rehearse restoring a previous local build before attempting any real incident response.

Expected: The runbook names the artifact, verification and stop conditions.

Expected: A public or locally previewed portfolio release with smoke evidence and a rollback runbook.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A public or locally previewed portfolio release with smoke evidence and a rollback runbook. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/deploy-observe.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining build for the hosting path in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: The built assets and selected view resolve correctly.

seeker: Build interview evidence for deploy, verify, observe and roll back. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect deploy, verify, observe and roll back to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: Static hosting serves client assets. It does not automatically supply a secure backend, account system or server-side environment variables.

Recall: A deploy command succeeds. What is still required?

Interview: Explain deploy, verify, observe and roll back using your own artifact. Defend the rule behind this scenario: A deploy command succeeds. What is still required? Then explain one failure case and this limitation: Static hosting serves client assets. It does not automatically supply a secure backend, account system or server-side environment variables.

Quiz: A deploy command succeeds. What is still required?

Nothing; every route is guaranteed.

Delete the previous artifact immediately.

Verify the live user flow and asset/deep-link behaviour.

Reference: Verify the live user flow and asset/deep-link behaviour. — Publication success does not establish application behaviour on the deployed host.

Sources:

Deploy · official reference: https://vite.dev/guide/static-deploy.html

Actions · official reference: https://docs.github.com/en/actions/automating-builds-and-tests

HTTP overview · official reference: https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

### Capstone: a reliable learning workspace

Build a coherent frontend that demonstrates the whole course: clear content, accessible interactions, validated state and evidence for failure recovery.

Scope and architecture
The product has task creation, completion, filters in the URL, a learning-resource view, explicit async request states and optional local persistence. Draw browser, API and storage boundaries. Use synthetic API records and state clearly whether the project is local-only or connected to a real backend.

Failure and quality matrix
Cover blank and overlong titles, literal markup, corrupt storage, HTTP errors, malformed data, offline reads, stale request races and a failed optional feature load. Add pure tests plus selected interaction tests. Check keyboard focus, labels, contrast, zoom and long content. Measure one real performance bottleneck before changing it.

Portfolio and interview
Deliver source, lockfile, setup, architecture, acceptance matrix, screenshots, trace evidence, a threat model and release/rollback notes. Write a short account of one defect: symptom, evidence, cause, repair and regression test. For interviews explain why you chose each boundary and which uncertainty remains.

Worked code:
Portfolio checklist
[ ] Reproducible setup and dependency lockfile
[ ] Accessible task journey and responsive layout
[ ] Typed external-data boundary and explicit failure states
[ ] Tests tied to requirements, with a demonstrated failing case
[ ] Performance comparison, threat model and rollback notes
[ ] Honest scope and limitations

Every tick must point to an artifact or observed result.
Do not claim an optional test or cloud service was executed unless your report includes its actual result.

Mental model: A complete thin product, with each boundary tested at the level where it can fail.

Boundary: A portfolio capstone demonstrates your work and reasoning. It is not a professional certification or proof of production operations experience.

Worked example: Portfolio checklist
[ ] Reproducible setup and dependency lockfile
[ ] Accessible task journey and responsive layout
[ ] Typed external-data boundary and explicit failure states
[ ] Tests tied to requirements, with a demonstrated failing case
[ ] Performance comparison, threat model and rollback notes
[ ] Honest scope and limitations

Setup: Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Tools for this exercise: The complete course toolchain, documentation and review checklist

Course tool and framework map: 

Local frontend teaching lab using synthetic data. Execute only the setup and commands stated for this lesson. Code fragments are labelled as examples, not complete production systems.

Complete the Capstone: a reliable learning workspace lab. Fork your intermediate project copy and write the capstone acceptance matrix before coding.

Terminal folder: course-labs/react-app

```
node -v
npm -v
npm ci
npm run dev -- --host 127.0.0.1
```

Prepare your local workspace

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

Expected: The stated local file or development page opens. Keep a reference copy before editing.

Step 1

Fork your intermediate project copy and write the capstone acceptance matrix before coding.

Expected: Each requirement has an observable success/failure result and test owner.

Step 2

Implement the missing boundaries, reproduce three failures and add targeted regression checks.

Expected: The report links each repair to its evidence.

Step 3

Run clean-install checks, review the portfolio package and rehearse a 10-minute design/interview walkthrough.

Expected: A reviewer can reproduce the build and follow the major decisions.

Expected: A complete frontend portfolio package and a recorded or written design walkthrough.

Troubleshoot: My result differs from this lesson’s expected result: Reproduce the exact stated input in react-app. Check Console and Network for the first relevant error, verify the file path and setup, then compare your changed code with the annotated example. Expected evidence: A complete frontend portfolio package and a recorded or written design walkthrough. Change one cause at a time and record the correction.

Cleanup: Save your source and evidence. Stop only the local development server you started with Ctrl+C. The offline-demo lesson also explains removing its own demo service worker. No cloud resources are created by the reference pack.

Deliverable: course-labs/evidence/production-capstone.md plus your changed source: include input, prediction, observed result, one failed case, repair and links to the stated references.

new: Start by explaining scope and architecture in your own words. Read the worked example line by line, then follow the local setup and the first lab step. Do not skip the expected result: Each requirement has an observable success/failure result and test owner.

seeker: Build interview evidence for capstone: a reliable learning workspace. Complete the lab, keep the before/after artifact and answer the scenario quiz before looking at its explanation. On your résumé describe the actual learning project and its checks, not invented employment experience.

switcher: Connect capstone: a reliable learning workspace to a boundary or workflow you know. Compare the assumptions, then execute the local lab rather than assuming prior tool experience proves this behaviour. Record the tradeoff: A portfolio capstone demonstrates your work and reasoning. It is not a professional certification or proof of production operations experience.

Recall: An interviewer asks why your architecture is reliable. Which response is strongest?

Interview: Explain capstone: a reliable learning workspace using your own artifact. Defend the rule behind this scenario: An interviewer asks why your architecture is reliable. Which response is strongest? Then explain one failure case and this limitation: A portfolio capstone demonstrates your work and reasoning. It is not a professional certification or proof of production operations experience.

Quiz: An interviewer asks why your architecture is reliable. Which response is strongest?

Name many popular libraries.

Show failure cases, ownership, tests and recovery evidence, with remaining limitations.

Say the framework prevents all bugs.

Reference: Show failure cases, ownership, tests and recovery evidence, with remaining limitations. — Reliability reasoning depends on explicit boundaries and observed behaviour, not a tool list.

Sources:

W3C accessibility tutorials · official reference: https://www.w3.org/WAI/tutorials/

Testing · official reference: https://testing-library.com/docs/react-testing-library/intro/

Security · official reference: https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html

Perf · official reference: https://web.dev/articles/vitals

Deploy · official reference: https://vite.dev/guide/static-deploy.html

### State and recovery

State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. In this role, work through: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. The practical workshop develops this into: Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.

Mental model: A whiteboard versus a saved notebook.

Boundary: A database also fails; persistence needs backups and tested recovery.

Role application: A display case shows a label; it does not execute the instructions printed on that label.

Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item.

Subtopic: Cancel obsolete work and identify the current request

AbortController can cancel a fetch. Cancellation alone is not a complete stale-result policy: use a request identifier so only the latest operation updates the UI.

Picture it: An old order slip must not replace the newest one.

```
let latest = 0;
let controller;
async function refresh() {
  const requestId = ++latest;
  controller?.abort();
  controller = new AbortController();
  const response = await fetch("/api/tasks", { signal: controller.signal });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const tasks = await response.json();
  if (requestId !== latest) return;
  // Render tasks here. Handle AbortError in the caller.
}
```

Try: In an authorized local lab, trigger two refreshes with different delays. Catch AbortError as cancellation, and handle other failures visibly.

Expected: An obsolete response never replaces the latest result; expected cancellation is not shown as a service failure.

Quick check: Is aborting a request proof that a server-side change was undone?

Reasoning: No. Client cancellation is not a transaction rollback.

Reference: https://developer.mozilla.org/en-US/docs/Web/API/AbortController

Worked example: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.

Shared foundation example: Restart this lab server: the task list becomes empty. Explain why before adding a database.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Frontend Developer: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.

Predict the worked case

Read this case without running a tool: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state and recovery.

Connect the concept to the role

Apply this rule: State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A database also fails; persistence needs backups and tested recovery.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state and recovery to this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for State and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state and recovery. Use the glossary below, then write your prediction for: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain state and recovery using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state and recovery to a system or workflow you know. Explain state and recovery using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Name two things required before calling this service production ready.

Interview: Explain state and recovery using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops.

Quiz: After the Safe DOM updates rehearsal, check this foundation: A successful operation exists only in process memory. The process restarts. What can you promise?

The success response guarantees recovery after restart.

A retry will always reconstruct the original state.

Nothing about retention without a persistence and recovery design.

Reference: Nothing about retention without a persistence and recovery design. — An acknowledgment is not a storage guarantee. Identify the persistence boundary and verify restoration.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: Cancel obsolete work and identify the current request: https://developer.mozilla.org/en-US/docs/Web/API/AbortController

### Safe DOM updates

Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item. In this role, work through: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. The practical workshop develops this into: Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.

Mental model: A display case shows a label; it does not execute the instructions printed on that label.

Boundary: If markup becomes elements, trace every insertion sink rather than only escaping one test string.

Subtopic: Render untrusted text as text

textContent inserts text rather than parsing it as markup. Do not replace it with innerHTML for user-controlled strings. Other contexts, such as URLs, still need their own validation.

Picture it: Display a printed instruction without carrying it out.

```
const item = document.createElement("li");
item.textContent = "<strong>Read docs</strong>";
document.querySelector("#tasks").append(item);
```

Try: Add this to your local list exercise. Compare the literal text with trusted, authored HTML elsewhere in the document. Do not test against a third-party site.

Expected: The angle-bracket string appears literally; it does not become a bold element.

Quick check: Does textContent automatically make a user-supplied link destination safe?

Reasoning: No. URL destinations are a separate context that requires validation.

Reference: https://developer.mozilla.org/en-US/docs/Web/API/Node/textContent

Worked example: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Browser DevTools and HTML/CSS/JavaScript (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Frontend Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.

```
node app.mjs test advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Two text items with stable IDs; no img element created from the title; no lost input focus.

Role workshop · debug and verify

If markup becomes elements, trace every insertion sink rather than only escaping one test string. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save dom-security.md with before/after DOM evidence and an automated assertion. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Two text items with stable IDs; no img element created from the title; no lost input focus.

Expected: Two text items with stable IDs; no img element created from the title; no lost input focus.

Troubleshoot: The role exercise differs from the prediction: If markup becomes elements, trace every insertion sink rather than only escaping one test string.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: dom-security.md with before/after DOM evidence and an automated assertion; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with safe dom updates. Use the glossary below, then write your prediction for: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Frontend Developer role interview. Explain safe dom updates using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate safe dom updates to a system or workflow you know. Explain safe dom updates using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If markup becomes elements, trace every insertion sink rather than only escaping one test string.

Interview: Explain safe dom updates using this case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Two text items with stable IDs; no img element created from the title; no lost input focus.

Reference: Two text items with stable IDs; no img element created from the title; no lost input focus. — Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item. Two text items with stable IDs; no img element created from the title; no lost input focus.

Sources:

MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Frontend reference: Render untrusted text as text: https://developer.mozilla.org/en-US/docs/Web/API/Node/textContent
