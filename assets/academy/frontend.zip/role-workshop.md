# Frontend Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Semantic forms and feedback

HTML gives controls meaning before CSS changes appearance. A visible label, a named input and a status message let people understand both the action and its result. Keep typed input when submission fails.
Mental model: A form is a conversation: name the question, accept the reply, then acknowledge it.
Case: Submit spaces, then Read docs, using only Tab and Enter. The first attempt must explain the error; the second creates one task.
Task: Open index.html in the pack. Associate a label with the input using for/id, place errors next to it and announce completion with a polite live region. Record focus before and after both submissions.
Acceptance: Blank input adds zero tasks; Read docs adds one; focus remains usable without a mouse.
Troubleshooting: If the browser reloads on submission, inspect the submit handler and preventDefault before making the request. Check accessible names in the browser accessibility tree.
Deliverable: form-audit.md with HTML diff, keyboard sequence and two observed outcomes

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Rendering server state

The server response is the authority for saved tasks. Render explicit loading, success, empty and failure states; do not treat every completed fetch as success because HTTP errors still resolve fetch.
Mental model: A receipt confirms a purchase; clicking Buy is only an attempt.
Case: A 400 response displays the server error without adding a phantom task.
Task: Add a response.ok check to the form handler. Disable duplicate submissions while awaiting a response and re-enable in finally. Stop the server, attempt submission, restart it and retry.
Acceptance: No extra list item after failure; a recoverable message; the button works after recovery.
Troubleshooting: A permanently disabled button usually means the error path never resets pending state. Inspect finally and test both HTTP and network failures.
Deliverable: ui-states.md and a four-state screenshot set

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Safe DOM updates

Treat user titles as text rather than HTML. Preserve keyboard focus when updating a list and provide stable identity so updates do not silently affect the wrong item.
Mental model: A display case shows a label; it does not execute the instructions printed on that label.
Case: The title <img src=x onerror=alert(1)> must appear as text with no image or script execution.
Task: Find the list-rendering code. Replace any title interpolation into innerHTML with textContent. Add the example title, then a second normal title. Inspect the DOM and test keyboard access after rerender.
Acceptance: Two text items with stable IDs; no img element created from the title; no lost input focus.
Troubleshooting: If markup becomes elements, trace every insertion sink rather than only escaping one test string.
Deliverable: dom-security.md with before/after DOM evidence and an automated assertion

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
