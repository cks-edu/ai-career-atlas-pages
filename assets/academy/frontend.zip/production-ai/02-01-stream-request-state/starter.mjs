function streamState(state, event) {
  if (event.type === 'CHUNK') return {...state,text:state.text + event.text};
  return state;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const s=streamState({text:'old'},{type:'START',id:'b'}); assert(s.activeId==='b' && s.text==='' && s.status==='streaming');
console.log("PASS: A new request clears the old answer");
}
{
const s={activeId:'b',text:'new',status:'streaming'}; assert(streamState(s,{type:'CHUNK',id:'a',text:'old'}).text==='new');
console.log("PASS: Stale chunks cannot overwrite state");
}
{
let s={activeId:'b',text:'Hi',status:'streaming'}; s=streamState(s,{type:'CHUNK',id:'b',text:'!'}); assert(s.text==='Hi!'); s=streamState(s,{type:'DONE',id:'b'}); assert(streamState(s,{type:'CHUNK',id:'b',text:'late'}).text==='Hi!');
console.log("PASS: Only active chunks append before completion");
}
