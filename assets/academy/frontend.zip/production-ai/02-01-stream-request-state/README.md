# Streaming UI: requests own their state

Streaming answers arrive in pieces. If a second request starts before the first ends, late chunks from the old request can overwrite the new answer. Give each request an ID, and let the UI accept chunks only for the active request.

Keep activeId, text and status in one reducer. Starting a request clears the previous draft. A chunk from any other ID leaves the state unchanged. A real DOM view renders this state; the local sandbox tests the reducer only.

Task: Implement streamState. Replay START a, START b, CHUNK a, CHUNK b and DONE b. Then connect this reducer to your own DOM outside the isolated sandbox.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: User submit → new request ID → stream chunks → rendered draft.
State: activeId, text and status belong to one request.
Boundary: Only the active request may change its draft.
Failure: An old request appends text after the user submits again.
Control: Reject stale request IDs in the reducer.
Observability: Record request IDs and cancellation outcomes, not prompt contents.
Blast radius: One displayed answer; reused global state can affect multiple views.
Trade-off: Discarding stale data protects coherence but may waste un-cancelled work.

Limit: Ignoring a late chunk does not cancel the server’s inference or billing. Pair UI ownership with AbortController and an appropriate server cancellation policy.

Sources:
https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Using_readable_streams
