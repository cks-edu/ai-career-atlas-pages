function statusMessage(previous, current) {
  if (previous === current) return '';
  return {streaming:'Answer started.',complete:'Answer ready.',cancelled:'Answer stopped; partial text remains.',error:'Answer failed; try again.'}[current] || '';
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(statusMessage('idle','streaming')==='Answer started.');
console.log("PASS: Starting is announced");
}
{
assert(statusMessage('streaming','streaming')==='');
console.log("PASS: Chunks do not repeat the announcement");
}
{
assert(statusMessage('streaming','complete')==='Answer ready.'); assert(statusMessage('streaming','error').includes('failed')); assert(statusMessage('idle','unknown')==='');
console.log("PASS: Completion and error are clear");
}
