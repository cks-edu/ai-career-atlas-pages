# Accessible status without announcing every token

A streaming page needs accessible feedback, but announcing every token can make it unusable. Keep the answer readable and announce meaningful status transitions: started, finished, stopped or failed. Avoid moving keyboard focus whenever a chunk arrives.

Produce a short status message when the status changes. Ordinary text chunks leave the status message unchanged. A DOM implementation can put that message in a polite live region and keep the stream text outside it.

Task: Implement statusMessage. Add a polite live status and a keyboard-operable Stop button to a separate local page, then record a manual keyboard and screen-reader check.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Status transition → concise live message → learner reads the answer.
State: Previous and current status determine an announcement.
Boundary: New answer text is not automatically a new announcement.
Failure: Every token interrupts the screen reader.
Control: Announce meaningful transitions and keep focus stable.
Observability: Test the actual announcement sequence with assistive technology.
Blast radius: This interaction; a global live region can interrupt unrelated work.
Trade-off: Less chatter improves reading but important errors must remain discoverable.

Limit: A string function is not an accessibility audit. Check keyboard control, focus, screen readers, contrast and reduced motion in the complete interface.

Sources:
https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html
