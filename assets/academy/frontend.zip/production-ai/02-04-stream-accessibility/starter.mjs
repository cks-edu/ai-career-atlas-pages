function statusMessage(previous,current) { return "New token received."; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(statusMessage('idle','streaming')==='Answer started.');
console.log("PASS: Starting is announced");
}
{
assert(statusMessage('streaming','streaming')==='');
console.log("PASS: Chunks do not repeat the announcement");
}
{
assert(statusMessage('streaming','complete')==='Answer ready.'); assert(statusMessage('streaming','error').includes('failed')); assert(statusMessage('idle','unknown')==='');
console.log("PASS: Completion and error are clear");
}
