function readLines(remainder, chunk) {
  const lines = (remainder + chunk).split('\n');
  const tail = lines.pop();
  return {items:lines.filter(x => x.trim()).map(x => JSON.parse(x)),remainder:tail};
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(readLines('', '{"x":1}\n').items[0].x===1);
console.log("PASS: One complete line parses");
}
{
const a=readLines('', '{"x":'); assert(a.items.length===0); const b=readLines(a.remainder,'2}\n'); assert(b.items[0].x===2 && b.remainder==='');
console.log("PASS: Split records retain the tail");
}
{
const r=readLines('', '{"x":1}\n\n{"x":2}\npartial'); assert(r.items.length===2 && r.remainder==='partial');
console.log("PASS: Several records and blank lines work");
}
