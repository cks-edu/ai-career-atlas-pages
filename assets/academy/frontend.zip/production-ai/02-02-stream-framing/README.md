# A network chunk is not a message

A transport can split a logical message across reads or deliver several messages in one read. Never call JSON.parse on every raw chunk and assume it contains exactly one object. Buffer text until the agreed delimiter appears.

This exercise uses newline-delimited JSON, not the full Server-Sent Events protocol. Keep the incomplete tail between reads and parse only complete nonempty lines. In a real UTF-8 stream, use a streaming TextDecoder so multi-byte characters can cross byte chunks.

Task: Implement the NDJSON buffer, test every possible split in a short record, and document an end-of-stream error policy.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Byte reads → streaming decode → text buffer → complete records.
State: The remainder stores an unfinished line.
Boundary: Transport reads do not define application message boundaries.
Failure: One JSON object is split in the middle of a field.
Control: Parse complete newline-delimited records and retain the tail.
Observability: Measure parse errors, buffer size and last complete record.
Blast radius: One stream; unlimited buffering can exhaust the tab.
Trade-off: Buffering handles partial records but needs a maximum size.

Limit: Production parsers also need size limits, protocol errors and an explicit end-of-stream policy. NDJSON framing is not interchangeable with SSE data fields.

Sources:
https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Using_readable_streams
