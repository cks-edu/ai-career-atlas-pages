function cancelState(state, event) {
  if (state.status !== 'streaming') return state;
  if (event === 'CANCEL') return {...state,status:'cancelled'};
  if (event === 'DONE') return {...state,status:'complete'};
  return state;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const r=cancelState({status:'streaming',text:'part'},'CANCEL'); assert(r.status==='cancelled' && r.text==='part');
console.log("PASS: Cancel preserves the partial answer");
}
{
assert(cancelState({status:'cancelled',text:'part'},'DONE').status==='cancelled');
console.log("PASS: Late completion is ignored");
}
{
assert(cancelState({status:'streaming'},'DONE').status==='complete'); assert(cancelState({status:'streaming'},'OTHER').status==='streaming');
console.log("PASS: Normal completion and unknown events differ");
}
