# Cancellation and honest partial answers

Stopping a stream is a state change, not proof that the server completed the task. Keep the received draft as partial and prevent later completion events from changing a cancelled request into success. Give the user a clear retry action.

CANCEL changes streaming to cancelled and preserves the draft. DONE changes only a streaming request to complete. In an actual fetch, AbortController interrupts client-side consumption; separately check how the backend cancels its work.

Task: Implement cancelState and a late-DONE test. Build a small DOM demo with a Stop button, partial label and AbortController using the official Fetch guide.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Stop action → cancelled state → abort signal → user decision.
State: Draft content survives; status records cancelled rather than done.
Boundary: A received completion event cannot resurrect a cancelled run.
Failure: A late DONE event labels an incomplete answer successful.
Control: Accept DONE only from streaming state.
Observability: Record stop reason, partial length and server cancellation outcome.
Blast radius: The current request; retries can duplicate side effects elsewhere.
Trade-off: Preserving a draft helps recovery but must visibly remain partial.

Limit: Client abort does not guarantee that remote work stopped or that a billable operation was undone. Never label a partial answer complete.

Sources:
https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
