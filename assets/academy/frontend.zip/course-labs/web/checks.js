const labTestForm=document.querySelector('#taskForm'),labTestInput=document.querySelector('#task'),labTestList=document.querySelector('#tasks');
let labTestPasses=0,labTestFailures=0;
function labTestCase(name,check){const item=document.createElement('li');try{check();item.textContent='PASS '+name;labTestPasses++}catch(error){item.textContent='FAIL '+name+': '+error.message;labTestFailures++}document.querySelector('#results').append(item)}
function labTestAssert(value,message){if(!value)throw Error(message)}
function labTestSubmit(value){labTestInput.value=value;labTestForm.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}))}
labTestCase('blank input adds no item',()=>{labTestSubmit('   ');labTestAssert(labTestList.children.length===0,'Blank title was accepted')});
labTestCase('valid input adds one trimmed title',()=>{labTestSubmit('  Read CSS  ');labTestAssert(labTestList.children.length===1&&labTestList.textContent.trim()==='Read CSS','Expected one trimmed title')});
labTestCase('markup remains literal text',()=>{labTestSubmit('<b>Read</b>');labTestAssert(labTestList.children.length===2&&labTestList.children[1].textContent==='<b>Read</b>'&&!labTestList.querySelector('b'),'Markup was parsed or lost')});
labTestCase('overlong input is rejected',()=>{labTestSubmit('x'.repeat(81));labTestAssert(labTestList.children.length===2,'Overlong input was accepted')});
document.querySelector('#checkSummary').textContent=`${labTestPasses} passed; ${labTestFailures} failed. Repeat keyboard, focus and viewport checks manually.`;
