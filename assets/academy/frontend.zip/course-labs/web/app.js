const form=document.querySelector('#taskForm');
const input=document.querySelector('#task');
const list=document.querySelector('#tasks');
const status=document.querySelector('#status');
let nextId=0;
form.addEventListener('submit',event=>{
  event.preventDefault();
  const title=input.value.trim();
  if(!title||title.length>80){status.textContent='Enter a task title of 1–80 characters.';input.setAttribute('aria-invalid','true');return;}
  input.removeAttribute('aria-invalid');
  const item=document.createElement('li');
  const label=document.createElement('label');
  const check=document.createElement('input');check.type='checkbox';check.id='practice-task-'+(++nextId);
  label.append(check,document.createTextNode(title));item.append(label);list.append(item);
  status.textContent=`Added: ${title}`;input.value='';input.focus();
});
