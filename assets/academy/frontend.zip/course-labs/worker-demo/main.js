let count=0,worker;
document.querySelector('#count').addEventListener('click',()=>document.querySelector('#count').textContent=`Interaction count: ${++count}`);
document.querySelector('#run').addEventListener('click',()=>{worker?.terminate();worker=new Worker('./worker.js');document.querySelector('#result').textContent='Calculating…';worker.onmessage=event=>{document.querySelector('#result').textContent=`Result: ${event.data}`;worker.terminate()};worker.onerror=()=>{document.querySelector('#result').textContent='Worker failed';worker.terminate()};worker.postMessage(10000000)});
window.addEventListener('pagehide',()=>worker?.terminate());
