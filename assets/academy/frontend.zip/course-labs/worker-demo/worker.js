self.onmessage=event=>{const n=event.data;if(!Number.isInteger(n)||n<0||n>10000000)throw Error('Invalid bound');let sum=0;for(let i=0;i<n;i++)sum+=i;self.postMessage(sum)};
