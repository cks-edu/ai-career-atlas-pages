"""Local-only synthetic API and static files. Run from this course-labs folder."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import json, time
ROOT=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(ROOT),**kwargs)
    def do_GET(self):
        parsed=urlsplit(self.path)
        if parsed.path.startswith('/api/'):
            try:delay=min(2,max(0,float(parse_qs(parsed.query).get('delay',['0'])[0])/1000))
            except ValueError:delay=0
            time.sleep(delay)
            routes={'/api/tasks':(200,[{'id':'a','title':'Read HTML'},{'id':'b','title':'Practise CSS'}]),'/api/empty':(200,[]),'/api/broken':(200,None)}
            status,data=routes.get(parsed.path,(404,{'error':'Unknown route'}))
            body=b'{not valid json' if parsed.path=='/api/broken' else json.dumps(data).encode()
            self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.end_headers()
            try:self.wfile.write(body)
            except (BrokenPipeError,ConnectionResetError):pass
        else:super().do_GET()
if __name__=='__main__':
    print('Local course lab: http://127.0.0.1:8877/web/ (Ctrl+C stops it)',flush=True)
    ThreadingHTTPServer(('127.0.0.1',8877),Handler).serve_forever()
