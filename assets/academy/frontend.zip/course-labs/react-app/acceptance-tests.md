# Interaction tests and manual acceptance

The reference dependency graph does not install every optional test framework. Choose a runner in your own working copy and commit the reviewed dependency/lockfile change. The Node tests already run with `npm test`.

## Optional Playwright

```sh
npm install --save-dev @playwright/test
npx playwright install chromium
```

Create `e2e/tasks.spec.ts`:

```ts
import {test, expect} from '@playwright/test';
test('adds a task using Enter', async ({page}) => {
  await page.goto('http://127.0.0.1:5173');
  await page.getByLabel('Task title').fill('Read CSS');
  await page.getByLabel('Task title').press('Enter');
  await expect(page.getByRole('listitem')).toContainText('Read CSS');
});
test('rejects whitespace', async ({page}) => {
  await page.goto('http://127.0.0.1:5173');
  await page.getByLabel('Task title').fill('   ');
  await page.getByRole('button', {name:'Add task', exact:true}).click();
  await expect(page.getByRole('listitem')).toHaveCount(0);
  await expect(page.locator('#status')).toContainText('1–80');
});
```

With the development server running on the stated port, run `npx playwright test e2e`. If Vite selected another port, use it in the tests. Browser downloads may be large. Add cases for literal markup, completion filters, reload and Back/Forward. Prefer locators based on accessible roles/names. Do not hide races with fixed sleeps.

## Optional component tests

React Testing Library provides render and screen queries. It needs a compatible test runner and DOM environment; it is not a runner itself. Follow the linked official setup for the runner you choose. Query a field with `getByLabelText('Task title')`, perform a submit interaction and assert a user-visible result. Do not copy a fragment without its runner/environment setup.

## Manual checks

Record actual results for keyboard-only input/submission, visible focus, label association, meaningful errors, literal markup, long text, 320px width, 200% zoom, sample-load failure and URL/history navigation. Automated scanning and tests cover different subsets of this flow.
