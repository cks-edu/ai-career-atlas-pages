import {useEffect,useRef,useState} from 'react';
import type {FormEvent} from 'react';
import {titleResult,toggleTask,visibleTasks,isTaskResponse} from './domain.mjs';
type Task={id:string;title:string;done:boolean};
type Filter='all'|'active'|'done';
type Load={kind:'idle'}|{kind:'loading'}|{kind:'ready';count:number}|{kind:'error';message:string};
function readFilter():Filter{const value=new URLSearchParams(location.search).get('filter');return value==='active'||value==='done'?value:'all'}
export default function App(){
  const [tasks,setTasks]=useState<Task[]>([]),[title,setTitle]=useState(''),[message,setMessage]=useState(''),[invalid,setInvalid]=useState(false);
  const [filter,setFilter]=useState<Filter>(readFilter),[load,setLoad]=useState<Load>({kind:'idle'});
  const input=useRef<HTMLInputElement>(null),request=useRef<AbortController|null>(null),latest=useRef(0);
  useEffect(()=>{const back=()=>setFilter(readFilter());window.addEventListener('popstate',back);return()=>{window.removeEventListener('popstate',back);latest.current++;request.current?.abort()}},[]);
  function submit(event:FormEvent){event.preventDefault();const result=titleResult(title);if(!result.ok){setInvalid(true);setMessage(result.error);return}setTasks(old=>[...old,{id:crypto.randomUUID(),title:result.value,done:false}]);setTitle('');setInvalid(false);setMessage(`Added: ${result.value}`);input.current?.focus()}
  function choose(value:Filter){const url=new URL(location.href);url.searchParams.set('filter',value);history.pushState(null,'',url);setFilter(value)}
  async function loadSamples(){const id=++latest.current;request.current?.abort();const controller=new AbortController();request.current=controller;setLoad({kind:'loading'});try{const response=await fetch('./tasks.json',{signal:controller.signal});if(!response.ok)throw Error('Request failed');const data:unknown=await response.json();if(!isTaskResponse(data))throw Error('Invalid task data');if(id!==latest.current)return;setTasks(data.map(t=>({...t,done:false})));setLoad({kind:'ready',count:data.length})}catch(error){if(id===latest.current&&!(error instanceof DOMException&&error.name==='AbortError'))setLoad({kind:'error',message:'Could not load samples. Your existing tasks are unchanged.'})}}
  return <main><header><p>Frontend reference lab · synthetic data only</p><h1>My learning workspace</h1></header><p>This reference keeps tasks in the current session. Storage is a learner extension.</p>
    <form onSubmit={submit}><label htmlFor="title">Task title</label><p id="title-help">Use 1–80 characters.</p><div className="toolbar"><input ref={input} id="title" value={title} onChange={event=>setTitle(event.target.value)} aria-describedby="title-help status" aria-invalid={invalid}/><button type="submit">Add task</button></div></form>
    <p id="status" role="status">{message}</p><nav aria-label="Task filters">{(['all','active','done'] as Filter[]).map(value=><button key={value} type="button" aria-pressed={filter===value} onClick={()=>choose(value)}>{value}</button>)}</nav>
    {visibleTasks(tasks,filter).length?<ul aria-label="Study tasks">{visibleTasks(tasks,filter).map(task=><li key={task.id}><label><input type="checkbox" checked={task.done} onChange={()=>setTasks(old=>toggleTask(old,task.id))}/>{task.title}</label></li>)}</ul>:<p>No tasks in this view.</p>}
    <button type="button" onClick={loadSamples}>Replace with sample tasks</button><p role="status">{load.kind==='loading'?'Loading samples…':load.kind==='ready'?`${load.count} samples loaded`:load.kind==='error'?load.message:''}</p>
  </main>;
}
