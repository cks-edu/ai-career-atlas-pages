/** @typedef {{id:string,title:string,done:boolean}} Task */
/** @param {unknown} raw @returns {{ok:true,value:string}|{ok:false,error:string}} */
export function titleResult(raw){
  if(typeof raw!=='string')return {ok:false,error:'Enter a task title.'};
  const value=raw.trim();
  if(!value||value.length>80)return {ok:false,error:'Use 1–80 characters.'};
  return {ok:true,value};
}
/** @param {Task[]} tasks @param {string} id @returns {Task[]} */
export function toggleTask(tasks,id){return tasks.map(t=>t.id===id?{...t,done:!t.done}:t)}
/** @param {Task[]} tasks @param {'all'|'active'|'done'} filter @returns {Task[]} */
export function visibleTasks(tasks,filter){return tasks.filter(t=>filter==='all'||(filter==='done'?t.done:!t.done))}
/** @param {unknown} raw @returns {raw is {id:string,title:string}[]} */
export function isTaskResponse(raw){return Array.isArray(raw)&&raw.every(t=>t&&typeof t.id==='string'&&typeof t.title==='string')&&new Set(raw.map(t=>t.id)).size===raw.length}
