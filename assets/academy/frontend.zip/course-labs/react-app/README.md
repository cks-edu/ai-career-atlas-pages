# Typed learning workspace

Reference project for the course. Work in your own copy. It has task creation, validation, immutable completion, URL filters and explicitly requested sample loading. State lasts only for the current page session; persistence is a learner extension.

## Setup

Use a currently supported Node.js LTS that satisfies Node >=22.12.0. The exact Vite runtime requirement is also documented by Vite. Check `node -v` and `npm -v`.

From this `react-app` folder:

```sh
npm ci
npm test
npm run typecheck
npm run dev -- --host 127.0.0.1
```

`npm ci` installs the committed dependency graph. It needs internet for the first dependency download. `npm test` runs pure domain checks with Node. `typecheck` checks TypeScript separately from code transformation. `dev` prints a local URL, normally port 5173; open the printed address and stop the server with Ctrl+C.

In another terminal in the same folder:

```sh
npm run build
npm run preview -- --host 127.0.0.1
```

The build runs type checking and emits `dist/`. Preview serves that production output locally. It is not a public deployment or production API. Read the deployment lesson before publishing.

## Source map

- `src/domain.mjs`: pure, typed-by-JSDoc rules used by the UI and tests.
- `src/App.tsx`: accessible form, task state, filters and sample loading.
- `src/styles.css`: responsive reference styles.
- `public/tasks.json`: synthetic read-only sample data.
- `test/domain.test.mjs`: accepted/rejected input, immutability and response-shape checks.
- `acceptance-tests.md`: optional interaction test setup and manual checklist.

## Troubleshooting

- `npm ci` fails: verify the runtime, network and that you are in the folder containing both package files. Do not delete the lockfile to silence a mismatch.
- A port is busy: use Vite's printed alternate port or stop only your own prior server.
- A type error appears: inspect the first source location; Vite serving does not replace `typecheck`.
- Sample loading fails: inspect Network and the built `tasks.json` path. Existing tasks stay unchanged on failure.
- A filter survives reload but tasks do not: this reference persists the view in the URL, not the data. The storage lesson explains the separate extension.

Do not claim a test was executed merely because its example appears in the workbook. Record your actual commands, browser and results.
