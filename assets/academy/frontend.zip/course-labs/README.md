# Frontend course labs

Start with the numbered lesson on the website. The `lessons/` folders contain the same teaching, worked code, lab tasks and quiz reference answers offline. Make a working copy before editing. Use synthetic data only.

## Beginner browser lab

Open `web/index.html` for HTML, CSS and basic form exercises. Edit `web/styles.css` and `web/app.js` in a plain-text editor. No paid account or install is needed for those exercises.

Open `web/checks.html` to run four browser reference checks against the same `app.js`: blank input, trimmed title, literal markup and overlong input. It works as a local file or through the local server. These checks do not replace manual keyboard/focus tests or assertions for your extensions.

HTTP, module and storage exercises use a consistent local origin. From **this folder** run:

```sh
python3 serve.py
# Windows with Python launcher: py serve.py
```

Open `http://127.0.0.1:8877/web/`. Stop with Ctrl+C. If the port is occupied, stop only your own prior lab process or change the port in your copy and use the corresponding URL. Do not expose this teaching server publicly.

The synthetic API has `/api/tasks`, `/api/empty`, `/api/broken` and unknown routes returning 404. Add `?delay=800` to simulate an 800ms response delay. Delays are capped at two seconds. This is a read-only local fixture, not a production backend.

## Intermediate / advanced React lab

See `react-app/README.md`. It includes exact dependencies and a lockfile. Install a supported Node LTS satisfying the package's requirements. There is no API token or inference-server bill. Downloads and local execution use your internet connection and device.

## Optional offline demo

With the Python lab server running, open `/offline-demo/`. Its service worker controls only that demo folder. Load and reload it online before testing offline. In DevTools Application, inspect that worker and the `frontend-offline-demo-*` cache. After finishing, unregister **that demo worker only** and remove only its demo cache. Do not clear unrelated browsing data.

## CPU work demo

The `worker-demo/` uses a worker to sum a fixed synthetic sequence. Serve it over HTTP, compare responsiveness with your own main-thread version and inspect the Performance trace. It makes no network request other than loading its own worker.

## Evidence

Create `evidence/<lesson-slug>.md` with prediction, exact input, observed output, a failed case, repair and sources. A passing reference check does not validate every modification you make. Include your own new assertions and manual checks.

These labs teach the stated syllabus. They do not provide identity infrastructure, server authorisation or a professional certification.
