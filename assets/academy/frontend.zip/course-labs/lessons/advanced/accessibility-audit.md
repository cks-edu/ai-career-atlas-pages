# Accessibility: semantics, focus and complete user journeys

Accessibility is a property of a complete interaction, not a score added after styling. Audit the journey from input through feedback and recovery.

Prefer native behaviour
Use buttons for actions, links for navigation and labelled native controls for input. Add ARIA only where it accurately describes behaviour you actually implement. ARIA does not create keyboard behaviour. A custom widget can require a substantial interaction contract that a native element already provides.

Manage focus predictably
A dialog should have a meaningful name, keep keyboard interaction within the active modal context and restore focus when closed. Test Escape where dismissal is appropriate. A route transition should not leave focus in removed content. Do not move focus on every keystroke or merely to draw attention.

Audit a full flow
Test adding an invalid task, correcting it, filtering results and returning from a dialog. Inspect names, roles and relationships. Check keyboard order, zoom, contrast and status announcements. Record the actual browser and assistive technology used; do not claim a screen-reader test if you only inspected markup.

## Mental model

Follow one user through the entire task instead of inspecting isolated controls.

Limit: Automated scanners find some defects. A passing scan is not a conformance certificate or a replacement for human testing.

## Worked example

```
<dialog aria-labelledby="helpTitle">
  <h2 id="helpTitle">Task help</h2>
  <p>Write one concrete study action.</p>
  <button type="button">Close help</button>
</dialog>
<!-- Use showModal(), wire Close, and restore the invoking control. -->
```

The dialog name comes from a visible heading.

The fragment needs opening/closing handlers; semantics alone are not the whole interaction.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Add a native help dialog to your app with an explicit Close control and focus restoration.

Expected: Opening and closing it preserves a predictable task flow.

2. Complete the full flow using only Tab, Shift+Tab, Enter and Escape; test 200% zoom.

Expected: Controls remain reachable and the focus indicator remains visible.

3. Record scanner findings separately from manual findings and repair one confirmed issue.

Expected: Your accessibility report states evidence and testing limits precisely.

## Outcome

A journey-based accessibility report with before/after evidence and tested focus recovery.

## Check

Does adding role="button" to a div automatically supply complete button keyboard behaviour?

Yes.

Only on mobile.

No.

Reference answer: No.

Roles expose semantics; the required behaviour must still be implemented. Prefer a native button.

## Sources

https://www.w3.org/WAI/tutorials/

https://www.w3.org/WAI/tutorials/forms/labels/

https://testing-library.com/docs/react-testing-library/intro/