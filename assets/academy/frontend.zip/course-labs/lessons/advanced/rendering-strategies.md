# Client rendering, server rendering and hydration

Choose where initial HTML is produced based on content, interaction, hosting and operational constraints.

Compare delivery modes

Client rendering builds much of the UI after JavaScript loads. Static generation produces HTML ahead of requests. Server rendering produces HTML at request time or through a cache. A real framework may combine these approaches per route. Evaluate first content, interaction, freshness and hosting together.

Hydration needs agreement

Hydration connects client behaviour to pre-rendered HTML. Server and initial client output should agree. Random values, local time differences and browser-only storage reads during initial rendering can create mismatches. Move browser-specific synchronisation to the appropriate client lifecycle rather than hiding the warning.

Make a bounded comparison

The supplied Vite starter is a client app; it is not an SSR framework. For this lesson compare the same small component rendered with React server APIs in a separate Node script, then document what a production framework would additionally own. Do not deploy a teaching script as an unreviewed production server.

## Mental model

A page can arrive already assembled, be assembled in the browser, or combine both approaches.

Limit: SSR is not automatically faster or cheaper. It introduces server work, caching and hydration constraints.

## Worked example

```
// server-render.mjs — a local comparison, not a production server
import React from "react";
import { renderToString } from "react-dom/server";
const view = React.createElement("h1", null, "Study journal");
console.log(renderToString(view));
```

Run inside react-app where React dependencies are installed.

This script produces HTML text; it does not implement routing, data loading or hydration.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Save server-render.mjs inside your react-app copy and run node server-render.mjs.

Expected: The terminal receives an h1 HTML string.

2. Compare that output with the built client app’s initial HTML and later DOM.

Expected: Your report distinguishes initial delivery from client execution.

3. Write a decision for a public article site versus a private task dashboard, including hosting and freshness.

Expected: The choice includes tradeoffs rather than a claim that one mode always wins.

## Outcome

A local rendering comparison and a route-specific delivery decision.

## Check

What is a common cause of hydration mismatch?

Matching deterministic initial output.

Different server and initial-client content, such as an uncontrolled random value.

Using semantic HTML.

Reference answer: Different server and initial-client content, such as an uncontrolled random value.

Hydration expects the initial client description to match the delivered markup.

## Sources

https://react.dev/reference/react-dom/server

https://react.dev/learn

https://vite.dev/guide/