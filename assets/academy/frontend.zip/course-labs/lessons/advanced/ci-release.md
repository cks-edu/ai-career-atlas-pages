# CI pipelines, quality gates and dependency review

A release pipeline should reproduce the checks a reviewer relies on, then publish a known build artifact.

Reproduce the environment
Use a supported runtime and the committed dependency lockfile. A clean npm ci followed by tests, typecheck and production build catches failures hidden by a developer’s old node_modules. Keep build logs and record the source revision with the artifact.

Run meaningful gates
Use pure tests for domain rules and selected interaction tests for critical flows. Include accessibility and bundle checks where justified. Do not make arbitrary coverage percentages the sole quality measure. Treat dependency updates as reviewed changes with compatibility and security checks.

Limit pipeline permissions
Read-only checks should not receive deployment credentials. Publishing needs narrowly scoped permissions and a clear target. Avoid passing secrets to untrusted contribution code. The supplied ci-example.yml is a teaching file copied into your own repository only after reviewing its triggers and permissions.

## Mental model

A sequence of evidence gates attached to one exact source revision.

Limit: A green pipeline only proves the checks it ran. It does not establish every browser/device behaviour or authorise a risky release.

## Worked example

```
# Core validation commands inside react-app
npm ci
npm test
npm run typecheck
npm run build
# Publish the resulting dist/ artifact only after these pass.
```

CI should use the same documented commands as local verification.

The pack’s YAML example runs checks; it does not secretly publish a site.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Run all four commands from a fresh install and record the source revision.

Expected: The build can be reproduced from the repository.

2. Copy ci-example.yml into your own repository workflow folder after reviewing it. Trigger it with a small test change.

Expected: The workflow reports the same quality gates.

3. Introduce a deliberate failing test on a temporary learning branch and verify the gate blocks a successful validation result. Restore it.

Expected: Your evidence demonstrates the gate, not just its configuration.

## Outcome

A reviewed validation workflow and a demonstrated failure/recovery run.

## Check

Which artifact should a deployment publish?

Whatever happens to be in a developer’s old folder.

The build produced from the exact validated revision.

The complete node_modules directory.

Reference answer: The build produced from the exact validated revision.

The deployed artifact must be tied to the evidence-producing source and build.

## Sources

https://docs.github.com/en/actions/automating-builds-and-tests

https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository

https://vite.dev/guide/