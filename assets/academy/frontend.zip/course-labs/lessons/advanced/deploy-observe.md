# Deploy, verify, observe and roll back

Deployment is not finished when a command exits. Verify the user journey on the public build and prepare recovery.

Build for the hosting path

A site under a repository subpath needs matching asset URLs. The supplied Vite config uses a relative base for the static app. A client path router needs a server fallback; query/hash navigation can be simpler on static hosting. Test a direct link and reload, not only the root page.

Verify the actual release

Preview dist locally first, then publish only intended public assets using your host’s documented workflow. Check asset requests, a task submission, keyboard focus, a deep link and error feedback on the live site. Avoid putting learning notes or personal files into the public package.

Observe and recover

Record the deployed revision and a short smoke-check result. For a defect, preserve evidence, assess impact and roll back to a previously validated artifact if that is the chosen recovery. Client-side error reporting needs privacy-conscious collection and careful handling of source maps. Do not log typed personal data.

## Mental model

A release is a reversible change with an observable success condition.

Limit: Static hosting serves client assets. It does not automatically supply a secure backend, account system or server-side environment variables.

## Worked example

```
npm run build
npm run preview -- --host 127.0.0.1
# Open the printed URL and verify the built app before publication.
# Record: source revision, deployed URL, smoke checks, rollback artifact.
```

Preview serves the production output locally.

Your chosen host’s publication steps remain an explicit reviewed action.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Build and preview the app, then test direct filter links and reload under a subpath.

Expected: The built assets and selected view resolve correctly.

2. Publish your learning artifact using the official static-host guide and run the smoke checklist.

Expected: The live site matches the validated build and expected user flow.

3. Write a rollback runbook and rehearse restoring a previous local build before attempting any real incident response.

Expected: The runbook names the artifact, verification and stop conditions.

## Outcome

A public or locally previewed portfolio release with smoke evidence and a rollback runbook.

## Check

A deploy command succeeds. What is still required?

Nothing; every route is guaranteed.

Delete the previous artifact immediately.

Verify the live user flow and asset/deep-link behaviour.

Reference answer: Verify the live user flow and asset/deep-link behaviour.

Publication success does not establish application behaviour on the deployed host.

## Sources

https://vite.dev/guide/static-deploy.html

https://docs.github.com/en/actions/automating-builds-and-tests

https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview