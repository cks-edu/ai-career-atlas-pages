# Measure loading, responsiveness and layout stability

Improve a measured bottleneck. Separate controlled lab observations from what real learners experience on varied devices and connections.

Choose a user outcome

Identify the screen and interaction that feels slow. Current Core Web Vitals cover loading through LCP, interaction responsiveness through INP and unexpected layout shifts through CLS. Record the device, network, route and build version. Different metrics describe different problems.

Inspect work before optimising

Use Network to inspect transferred assets and Performance to inspect long tasks and rendering. A large image may delay content; a long synchronous calculation may block interaction; missing dimensions may move controls. Do not assume every slow interaction needs React memoisation.

Compare responsibly

Repeat under the same conditions and compare the relevant trace segment. Field data should be evaluated over an appropriate population, including mobile, rather than one cherry-picked session. Publish measured results with their method and avoid presenting a lab result as a production percentile.

## Mental model

A performance investigation is a before/after experiment under stated conditions.

Limit: One fast desktop run is not a global user experience measurement. A score is a diagnostic signal, not the whole product outcome.

## Worked example

```
performance.mark("filter-start");
const visible = tasks.filter(task => !task.done);
performance.mark("filter-end");
performance.measure("filter-calculation", "filter-start", "filter-end");
// This measures the calculation, not the complete input-to-paint interaction.
```

The mark labels delimit only the work inside them.

Use the browser trace to inspect rendering and interaction beyond the function.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Build your app and capture a baseline trace for loading and filtering with a large synthetic list.

Expected: The trace identifies the tested route and environment.

2. Find one actual bottleneck and propose the smallest relevant change.

Expected: Your hypothesis connects a resource or task to a user-visible delay.

3. Repeat the same experiment after the change and report both results.

Expected: The comparison includes method and limitations, even if the change did not help.

## Outcome

A reproducible performance report with traces and one evidence-based improvement.

## Check

A calculation measure improves. Does that prove the full interaction is now fast?

No; rendering and other work also contribute.

Yes, all browser work is included automatically.

Only if the variable name is short.

Reference answer: No; rendering and other work also contribute.

A narrow measurement must not be presented as an end-to-end responsiveness result.

## Sources

https://web.dev/articles/vitals

https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers

https://web.dev/learn/performance/image-performance