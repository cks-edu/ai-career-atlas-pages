# CSP, CORS, authentication and client configuration

Browser policies and server security controls solve different problems. Learn which boundary owns each decision.

CORS is not authorisation

The same-origin policy limits what scripts can read across origins. CORS lets a server opt into specified cross-origin reads. It does not authenticate a user or prevent every cross-origin request from being sent. Fix a real origin contract instead of disabling browser protections.

CSP constrains resource execution

Content Security Policy can restrict scripts and other resources. It is defence in depth, not a substitute for safe sinks. A strict policy often needs external scripts or managed nonces/hashes rather than broad unsafe-inline. Test in report-only mode where supported before enforcing a new production header.

Identity remains server-owned

A hidden button is not access control. The API checks who is calling and what they can do. Cookie sessions and bearer tokens have different XSS/CSRF tradeoffs. Public environment variables in a client build are configuration, not secrets. Use an established identity design and a server-owned authorisation boundary.

## Mental model

Different checkpoints inspect different documents; passing one checkpoint does not grant every permission.

Limit: This lesson uses a local policy analysis. It does not implement a production identity service or prove a deployment secure.

## Worked example

```
# Illustrative HTTP response header for a simple self-hosted static app
Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'
# Review required resources and deployment support before enforcing.
```

This is a response-header example, not a terminal command.

An app with inline scripts needs an appropriate policy migration; do not copy a breaking header blindly.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Draw browser, static host, API and identity boundaries for your project.

Expected: Each authentication/authorisation decision has an owner.

2. Inspect the local API response and compare same-origin reads with an intentionally different origin.

Expected: Your diagnosis distinguishes policy failures from HTTP application errors.

3. Write a CSP rollout and client-secret review for your host; mark unexecuted changes as proposed.

Expected: The report identifies supported controls and a verification/rollback plan.

## Outcome

A browser/server boundary diagram and reviewed client configuration policy.

## Check

An API allows your origin with CORS. Does that authorise a user to delete a record?

Yes, origin and user permission are identical.

Only when using React.

No; the API still needs authentication and authorisation.

Reference answer: No; the API still needs authentication and authorisation.

CORS controls browser cross-origin reading, not user permissions.

## Sources

https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CSP

https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html