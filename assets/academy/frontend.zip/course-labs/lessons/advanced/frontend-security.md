# XSS, safe rendering and trust boundaries

Treat user input, API data and browser storage as untrusted until validated for the specific place they are used.

Understand the sink
A sink is where a value is used. textContent displays text, whereas innerHTML parses markup. React text expressions normally render text, but raw-HTML escape hatches change the risk. Avoid parsing user content as HTML unless a carefully reviewed sanitisation design is actually required.

Validate for context
A user-provided link needs a permitted scheme and product policy, not just escaped quotes. An API identifier needs its own format and authorisation checks. Keep secrets on the server: anything built into a public JavaScript bundle can be inspected by the user. Do not store real credentials in a learning fixture.

Prove a regression safely
Use synthetic literal markup on your own local app. Verify that it appears as text and does not become a new DOM element. Add a negative test for the previously unsafe sink. Document the actor, input, boundary and effect rather than claiming the whole application is secure after one repair.

## Mental model

A value crossing a boundary needs rules for its destination, not a single universal safe stamp.

Limit: Text escaping does not make every URL, CSS value or HTML fragment safe. Browser-only checks cannot authorise server actions.

## Worked example

```
const value = "<strong>Untrusted title</strong>";
const row = document.createElement("li");
row.textContent = value;
// For a link destination, apply a separate URL policy:
const url = new URL("https://example.test/guide");
if (url.protocol !== "https:") throw new Error("Unsupported URL");
```

The angle-bracket title stays text.

An HTTPS check is only one policy condition; it does not establish that a destination is trusted.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Trace input, storage and API values to every rendering sink in your app.

Expected: The report lists text, HTML and URL contexts separately.

2. Submit literal markup to the local task form and inspect the DOM.

Expected: The title remains text; no strong element is created from it.

3. Add a regression test and remove one unnecessary raw-HTML sink.

Expected: The negative case remains checked after the repair.

## Outcome

A small frontend threat model and a safe-rendering regression test.

## Check

Does HTML-escaping a javascript: URL make it an acceptable link destination?

Yes, escaping validates its scheme.

No; URL policy is a separate context-specific check.

Only if the title is short.

Reference answer: No; URL policy is a separate context-specific check.

Escaping markup does not replace validating the destination scheme and product policy.

## Sources

https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting

https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/CSP