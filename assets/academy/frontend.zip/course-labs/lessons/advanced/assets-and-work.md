# Images, code splitting and expensive work

Send only what the current task needs and keep long work from blocking interaction. Optimise after measuring.

Image delivery
Provide appropriate intrinsic dimensions and compressed sources. srcset and sizes help the browser choose a suitable image resource. Lazy loading suits some offscreen images, but can hurt an image needed for the initial view. Test actual requested sizes in Network instead of trusting the CSS dimensions.

Split optional code
A dynamic import can load an optional feature on demand. Show a meaningful loading or failure state. Check the production output because development serving is different from a built bundle. Keep a rollback strategy when a new HTML entry refers to assets that an old cache cannot find.

Move appropriate work
A web worker can perform suitable CPU work off the main thread and communicate by messages. It cannot directly manipulate the document DOM. Validate message shapes and terminate workers when the owner no longer needs them. For small work, avoiding unnecessary computation may be simpler than introducing a worker.

## Mental model

Deliver the first useful box now; bring optional tools when they are needed.

Limit: Lazy loading can delay essential content. Moving work to a worker adds communication and data-transfer costs.

## Worked example

```
async function openOptionalReport() {
  try {
    const { buildReport } = await import("./report.js");
    return buildReport();
  } catch {
    return "Report unavailable. Try again.";
  }
}
```

Create report.js with a named buildReport export before using this fragment.

The error path is part of the feature, not an afterthought.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Add an optional report module to react-app and load it only through an explicit action.

Expected: The initial route does not need to execute that feature.

2. Build and inspect the emitted assets/Network requests; test a failed optional load.

Expected: The user receives useful failure feedback rather than a blank panel.

3. Compare a large calculation on the main thread with the supplied worker example.

Expected: Your trace reports responsiveness and messaging overhead separately.

## Outcome

A measured optional feature and a documented image/CPU optimisation decision.

## Check

Can a web worker directly update document.querySelector("h1") in the page?

Yes, workers share the page DOM.

No; send a message and let the main thread update the DOM.

Only with a longer timeout.

Reference answer: No; send a message and let the main thread update the DOM.

Workers have a separate execution context without direct access to the page DOM.

## Sources

https://web.dev/learn/performance/image-performance

https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers

https://vite.dev/guide/