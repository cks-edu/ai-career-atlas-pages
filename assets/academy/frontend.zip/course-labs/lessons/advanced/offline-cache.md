# Offline behaviour, caches and update recovery

An offline-capable interface must explain which content is available and how updates are handled.

Understand service-worker ownership
A service worker can intercept requests within its scope and use caches. It runs in a separate worker context and has its own lifecycle. Register it only from an appropriate secure context, including supported local development exceptions. Scope and update behaviour matter as much as the fetch handler.

Choose a strategy by resource
Versioned static assets can use a different strategy from changing API data. A stale cached response can look like a successful fresh load, so state freshness honestly. Avoid caching authenticated data by default. Decide what should happen when the network and cache both miss.

Test upgrades and rollback
A new release must not strand clients with HTML pointing to unavailable old assets. Test first install, offline revisit, a new version and recovery from a bad cache. The pack includes an isolated optional offline-demo folder; it does not register a worker on the main course website.

## Mental model

A local shelf of saved resources with an explicit replacement policy.

Limit: A cache is not the source of truth for every resource. Sensitive or user-specific responses need a deliberate policy.

## Worked example

```
// In the isolated offline-demo only:
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("./sw.js").catch(() => {
    document.querySelector("#status").textContent = "Offline setup unavailable";
  });
}
```

Registration is scoped to the demo folder.

Use DevTools Application to inspect and unregister only the demo’s worker.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Serve course-labs locally and open /offline-demo/. Inspect the registered worker scope.

Expected: Only the demo folder is controlled.

2. Load once online, then revisit offline and inspect the visible cached-content message.

Expected: The demo works for its declared cached shell and explains the limit.

3. Change the cache version in your copy, test an update and unregister the demo after finishing.

Expected: You have update evidence and a cleanly removable local experiment.

## Outcome

An offline/update test matrix and a documented resource-cache policy.

## Check

Should every authenticated API response be cached automatically for offline use?

No; privacy, freshness and authorisation need a deliberate policy.

Yes, any response is a public static asset.

Only if the cache name is short.

Reference answer: No; privacy, freshness and authorisation need a deliberate policy.

User-specific data requires explicit privacy and lifecycle decisions.

## Sources

https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps

https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers

https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview