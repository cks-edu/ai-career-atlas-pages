# Capstone: a reliable learning workspace

Build a coherent frontend that demonstrates the whole course: clear content, accessible interactions, validated state and evidence for failure recovery.

Scope and architecture

The product has task creation, completion, filters in the URL, a learning-resource view, explicit async request states and optional local persistence. Draw browser, API and storage boundaries. Use synthetic API records and state clearly whether the project is local-only or connected to a real backend.

Failure and quality matrix

Cover blank and overlong titles, literal markup, corrupt storage, HTTP errors, malformed data, offline reads, stale request races and a failed optional feature load. Add pure tests plus selected interaction tests. Check keyboard focus, labels, contrast, zoom and long content. Measure one real performance bottleneck before changing it.

Portfolio and interview

Deliver source, lockfile, setup, architecture, acceptance matrix, screenshots, trace evidence, a threat model and release/rollback notes. Write a short account of one defect: symptom, evidence, cause, repair and regression test. For interviews explain why you chose each boundary and which uncertainty remains.

## Mental model

A complete thin product, with each boundary tested at the level where it can fail.

Limit: A portfolio capstone demonstrates your work and reasoning. It is not a professional certification or proof of production operations experience.

## Worked example

```
Portfolio checklist
[ ] Reproducible setup and dependency lockfile
[ ] Accessible task journey and responsive layout
[ ] Typed external-data boundary and explicit failure states
[ ] Tests tied to requirements, with a demonstrated failing case
[ ] Performance comparison, threat model and rollback notes
[ ] Honest scope and limitations
```

Every tick must point to an artifact or observed result.

Do not claim an optional test or cloud service was executed unless your report includes its actual result.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Fork your intermediate project copy and write the capstone acceptance matrix before coding.

Expected: Each requirement has an observable success/failure result and test owner.

2. Implement the missing boundaries, reproduce three failures and add targeted regression checks.

Expected: The report links each repair to its evidence.

3. Run clean-install checks, review the portfolio package and rehearse a 10-minute design/interview walkthrough.

Expected: A reviewer can reproduce the build and follow the major decisions.

## Outcome

A complete frontend portfolio package and a recorded or written design walkthrough.

## Check

An interviewer asks why your architecture is reliable. Which response is strongest?

Name many popular libraries.

Show failure cases, ownership, tests and recovery evidence, with remaining limitations.

Say the framework prevents all bugs.

Reference answer: Show failure cases, ownership, tests and recovery evidence, with remaining limitations.

Reliability reasoning depends on explicit boundaries and observed behaviour, not a tool list.

## Sources

https://www.w3.org/WAI/tutorials/

https://testing-library.com/docs/react-testing-library/intro/

https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html

https://web.dev/articles/vitals

https://vite.dev/guide/static-deploy.html