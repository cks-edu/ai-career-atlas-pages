# Architecture, domain boundaries and design systems

Organise a frontend around understandable responsibilities. Design for change without adding layers that solve no current problem.

Separate domain and presentation

Pure validation and task transitions can live outside React. Components translate user actions into those operations and present their results. An API adapter handles transport and parsing. This separation lets tests target a business rule without booting the whole interface.

Create a small design system

Define shared tokens for space, typography, colour and focus. Build a component when it has a clear repeated responsibility and interaction contract. A reusable button includes keyboard/focus/loading/disabled behaviour, not merely rounded corners. Keep component examples and accessibility checks close to the source.

Record a decision

An architecture decision record states context, options, choice, consequences and a revisit trigger. Compare a local state solution with a shared store based on actual ownership and update needs. Name measurable symptoms that would justify a later change rather than promising an architecture that scales infinitely.

## Mental model

A map showing who owns each rule, state value and dependency.

Limit: Folder names do not enforce an architecture. Imports, contracts and tests reveal the actual boundaries.

## Worked example

```
src/
  domain.mjs        # validation and state transitions
  api.ts            # transport, parsing and boundary validation
  components/       # accessible presentation and interactions
  App.tsx           # composition and state ownership
  tokens.css        # shared visual decisions
```

This structure is a starting point, not a mandatory enterprise template.

Keep dependencies directed so pure domain rules do not import UI code.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Draw imports and state ownership for your intermediate app before restructuring.

Expected: The current coupling is visible.

2. Extract one domain rule and one repeated accessible control with tests.

Expected: The change reduces a concrete duplication or testing difficulty.

3. Write an ADR comparing two designs and record the tradeoff and revisit trigger.

Expected: A reviewer can understand why your chosen boundary exists.

## Outcome

An architecture diagram, tested boundary refactor and one decision record.

## Check

Which is strongest evidence that domain logic is separate from UI?

A folder named enterprise.

A colourful architecture diagram alone.

Domain rules can be tested without importing React or the DOM.

Reference answer: Domain rules can be tested without importing React or the DOM.

The actual dependency boundary is more informative than naming.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

https://react.dev/learn/managing-state

https://testing-library.com/docs/react-testing-library/intro/