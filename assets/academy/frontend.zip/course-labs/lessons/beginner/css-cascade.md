# Cascade, specificity and inheritance

When styles compete, the browser follows rules. Learn to inspect those rules rather than adding !important everywhere.

Inheritance is selective

Some properties, such as color, normally inherit from the parent; others, such as margin, generally do not. A child may receive an inherited colour when it has no winning declaration of its own. Inheritance is not the same as a selector directly targeting all descendants.

Compare selectors in context

For otherwise comparable rules, id selectors outrank class selectors, which outrank type selectors. Equal-specificity rules can be decided by later source order. Compare selectors only after checking other cascade factors. Prefer simple class-based rules so future changes remain understandable.

Debug the winner

Select the element and inspect its computed style. Find the winning declaration and the rules it displaced. Correct the responsible selector or structure. Adding a more forceful rule without understanding the conflict may fix one page and break another.

## Mental model

A decision process for competing instructions, with inherited defaults for some properties.

Limit: Specificity is one stage of the cascade. Origin, importance and cascade layers can be considered before it.

## Worked example

```
body { color: #243746; }
p { color: navy; }
.note { color: darkgreen; }
/* <p class="note"> inherits no colour here: its own rule wins. */
```

The class rule wins over the type rule in this otherwise comparable example.

Changing body colour does not override an explicit winning colour on the paragraph.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Apply the rules to a paragraph with class note. Predict the colour before inspection.

Expected: The paragraph is dark green.

2. Remove the class rule, then the p rule. Inspect after each change.

Expected: The type rule wins next, then the inherited body colour applies.

3. Add two equal class rules with different colours and reverse their order.

Expected: Later source order decides these equal, otherwise comparable rules.

## Outcome

Three observed cascade cases and the winning declaration for each.

## Check

A child has its own winning color declaration. Does changing its parent’s color necessarily change the child?

Yes, inheritance always overrides children.

No, the child’s own winning declaration takes precedence over inheritance.

Only if the parent is a div.

Reference answer: No, the child’s own winning declaration takes precedence over inheritance.

Inheritance supplies values where applicable; it does not override an element’s own winning declaration.

## Sources

https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Introduction

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model