# Cascade, specificity and inheritance

Why is this paragraph green when its parent is blue? Follow one small example to learn how the browser chooses a style, then prove it in DevTools.

Start with the element, then its parent
Imagine a paragraph inside a blue parent. The paragraph can use its own colour, or inherit the parent’s colour. “Inherit” means receiving a value from the parent; it does not mean copying every style.
Remember: A child’s own colour comes before an inherited colour.
color usually passes down: With no color declaration of its own, a paragraph normally uses its parent’s computed colour.
margin does not pass down by default: Giving the parent margin: 24px does not give each child a 24px margin. A child can still have its own margin, including a browser default.
A direct rule changes the result: If p sets color: navy, the paragraph uses navy instead of inheriting the parent’s colour. The parent and child are different elements.
Predict it: body is blue and p sets color: navy. What colour is the paragraph?
Reference answer: Navy. The paragraph has its own color declaration, so it does not use the inherited blue value. The parent selector’s specificity does not change that.

When two rules match, which one wins?
Both p and .note match our paragraph. Each supplies a different color value. In this example, .note wins because a class selector has more specificity than a type selector. “Specificity” means selector weight.
Remember: For this example: .note beats p. Being later is not enough.
Type selector · p: Matches every paragraph. It supplies navy in our example.
Class selector · .note: Matches elements with class="note". It supplies darkgreen and has greater specificity than p.
ID selector · #intro: A matching ID selector would outweigh either simple selector here. Prefer reusable classes; a heavier selector is not automatically a better design.
Example:
.note { color: darkgreen; }
p { color: navy; } /* later, but less specific */
Predict it: move p below .note, as above. Does the paragraph turn navy?
Reference answer: No. It stays dark green. Source order breaks a tie only after the earlier cascade decisions are equal. With two otherwise equal .note rules here, the later one would win.

Find the reason in DevTools
A page looks wrong? Inspect the element before changing CSS. Your browser can show which declaration sets its colour, which declarations lost, and whether a value came from its parent.
Remember: Find the declaration that actually sets the value. Change that cause.
Inspect the paragraph: Right-click it and choose Inspect. Confirm that you selected the p element with class="note".
Look in Styles or Rules: Filter for color. Find the active .note declaration; p’s navy declaration should be overridden, usually shown crossed out.
Check Computed, then test one change: Computed shows the final colour, often as rgb(0, 100, 0) for darkgreen. Disable .note’s color to get navy; disable p’s color too to reveal the inherited body colour.
Explain it: turning off .note changes the paragraph to navy. Is navy inherited from body?
Reference answer: No. The p rule now sets navy directly on the paragraph. Only after both child color declarations are disabled does body’s blue pass down. Avoid adding !important just to hide a conflict you have not diagnosed.

## HTML

```html
<p class="note">
  My first CSS experiment
</p>
```

## Mental model

Ask two questions for each property: does this element have a value of its own? If not, does this property normally inherit from its parent? The cascade chooses between competing declarations; inheritance supplies a default for inherited properties.

Limit: This example uses normal author styles in one unlayered stylesheet, without animations, transitions or scoped rules. In other cases, origin, importance and layers come before specificity; scoping proximity can break a specificity tie before source order.

## Worked example

```
/* styles.css */
body { color: blue; }
p { color: navy; }
.note { color: darkgreen; }
```

The paragraph is dark green: .note beats p for color in this example. The body colour is a fallback, not a competing colour declaration on the paragraph.

The HTML and CSS snippets belong in separate files. Keep index.html linked to styles.css, as in the previous lesson.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. In course-labs/web, keep a copy of index.html and styles.css. Add the paragraph from the example inside body and the three CSS rules at the end of styles.css. Open index.html in a browser and inspect the paragraph. Check for other matching color rules; isolate this example in a new linked HTML/CSS pair if needed.

Expected: The paragraph is dark green. In DevTools, .note sets color and the p colour is overridden.

2. In DevTools Styles, turn off only the .note color declaration. Then turn off the p color declaration too. After each change, write your prediction before checking Computed color. Reload to restore your saved stylesheet.

Expected: With .note color off, the paragraph is navy. With both child color declarations off, it inherits blue from body. Reload restores dark green.

3. In your saved stylesheet, add .note { color: purple; } after the existing .note rule. Reload, inspect, then swap the two .note rules and reload again. Save your observations and restore the original rules.

Expected: Purple wins while its otherwise equal rule is last. After swapping, darkgreen wins. These edits change source order, not specificity.

## Ready-to-run colour experiment

Open course-labs/web/cascade.html in your browser. Predict each result, toggle the two rules, then inspect the isolated paragraph. Use Reset experiment to restore both declarations. This file works locally without an account.

## Outcome

A colour prediction and DevTools evidence for all three states, plus a source-order comparison. Name the winning declaration or inherited value in each case.

## Check

A child has its own winning color declaration. Does changing its parent’s color necessarily change the child?

Yes, inheritance always overrides children.

No, the child’s own winning declaration takes precedence over inheritance.

Only if the parent is a div.

Reference answer: No, the child’s own winning declaration takes precedence over inheritance.

Inheritance supplies values where applicable; it does not override an element’s own winning declaration.

## Sources

https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Introduction

https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Inheritance

https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Specificity

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model