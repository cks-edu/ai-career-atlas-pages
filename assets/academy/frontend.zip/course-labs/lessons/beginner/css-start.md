# What CSS is: rules, selectors and declarations

CSS means Cascading Style Sheets. It describes how elements are presented while HTML retains their meaning.

Read a rule
A CSS rule has a selector and a block of declarations. Each declaration has a property and value separated by a colon. Semicolons separate declarations. h1 selects heading elements; .notice selects a class. The same class can be reused on several elements without duplicating id values.

Connect an external sheet
Use link rel="stylesheet" in head to load a CSS file. A shared stylesheet lets multiple pages reuse design rules. Keep HTML meaningful without the stylesheet. If no rule appears to work, inspect the resource path and whether the selector matches before changing values randomly.

Inspect matched styles
DevTools Styles shows matched rules and crossed-out declarations. Temporarily edit a value to test an idea, then save the confirmed change in the source. Start with a few readable rules; a large stylesheet copied without understanding creates more debugging work.

## Mental model

A reusable set of presentation instructions attached to selected parts of a document.

Limit: A selector matching an element does not guarantee its declaration wins. The cascade decides between competing declarations.

## Worked example

```
/* styles.css */
h1 { color: #245b52; }
.notice { padding: 1rem; background: #eef5f1; }
```

h1 is a type selector and .notice is a class selector.

padding is a property; 1rem is its value.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Link a new CSS file from your journal and add the example rules.

Expected: The heading colour changes and classed notices have internal space.

2. Add class="notice" to two paragraphs, then inspect both.

Expected: Both match the same reusable rule.

3. Misspell the class on one paragraph, diagnose in Styles and repair.

Expected: The repaired element matches the intended rule.

## Outcome

A separate stylesheet and a saved explanation of selector, property and value.

## Check

In .notice { padding: 1rem; }, which part selects elements?

.notice

padding

1rem

Reference answer: .notice

The class selector chooses elements; the declaration supplies presentation.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics

https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Cascade/Introduction

https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements