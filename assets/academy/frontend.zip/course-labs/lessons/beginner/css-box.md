# Box model, spacing and sizing

Every layout problem starts with boxes. Distinguish content size, internal space, borders and external separation.

Four layers

Content is the inner area. Padding separates content from the border. Border surrounds both. Margin separates the border from other boxes. Background usually paints through padding to the border. Use DevTools’ box diagram to identify which layer produced an unexpected gap.

Choose box sizing deliberately

With content-box, width describes content only; padding and border add to the outer width. With border-box, they fit inside the declared width. Margin stays outside in both models. A percentage width depends on its containing block, so fixed padding can create unexpected overflow.

Use constraints instead of arbitrary dimensions

Prefer a flexible width with a readable max-width for text and min-height only when needed. A fixed height can clip translated or enlarged text. Test long content, larger text and a narrow viewport before deciding a dimension is safe.

## Mental model

A package with contents, cushioning, wrapping and space around it.

Limit: The model describes individual boxes. Layout algorithms, intrinsic sizes and margin collapse also affect their placement.

## Worked example

```
.panel {
  box-sizing: border-box;
  width: 300px;
  padding: 20px;
  border: 2px solid #245b52;
  margin: 16px;
}
```

With border-box, the border-edge width is 300px.

The content width is 256px; horizontal margins add another 32px outside.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Apply the panel rule to a paragraph and inspect its box diagram.

Expected: Content is 256px wide when the stated sizes apply.

2. Switch to content-box and measure the border edge.

Expected: It grows to 344px before margins.

3. Replace width with width:100%; max-width:300px and test in a narrow parent.

Expected: The box fits its parent with border-box; margin still requires separate consideration.

## Outcome

Measured widths for both sizing modes and a flexible corrected rule.

## Check

A 300px border-box has 20px padding and 2px border on each side. What is its content width?

300px

344px

256px

Reference answer: 256px

Subtract 40px padding and 4px border from the declared 300px.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model

https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Values_and_Units

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design