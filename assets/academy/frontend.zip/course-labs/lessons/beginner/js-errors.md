# Errors, debugger and the JavaScript checkpoint

Debugging means explaining an observed failure with evidence. Learn syntax errors, runtime errors and incorrect results separately.

Identify the failure category
A syntax error prevents code from being parsed. A runtime error occurs while executing, such as reading an unavailable property. A logic defect produces an incorrect answer without necessarily throwing. Read the first relevant error and its source location before following secondary symptoms.

Pause and inspect
Set a breakpoint on a line in DevTools Sources. Reproduce the action, inspect local values, and step through the next statements. Compare actual values to a prediction. Avoid adding logging that exposes real secrets or personal data; learning fixtures use synthetic records.

Turn a repair into a check
A good bug report records input, expected result, actual result and the smallest correction. Keep a repeatable check for the boundary that failed. Complete the language checkpoint by combining a guarded function, an array transformation and a stable-id object update.

## Mental model

A detective’s notebook: reproduce, observe, form a hypothesis and test one change.

Limit: A program that runs without exceptions can still implement the wrong rule. Tests need meaningful expected outcomes.

## Worked example

```
function acceptedMinutes(raw) {
  const text = raw.trim();
  const value = Number(text);
  if (!text || !Number.isFinite(value) || value < 0) throw new Error("Invalid minutes");
  return value;
}
```

The empty-text guard prevents Number("") from accepting a blank as zero.

Test the function’s contract, not whether Console printed something.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Use a deliberately broken version that omits !text. Reproduce the blank-input defect.

Expected: Blank input is incorrectly accepted as 0.

2. Pause inside the function and inspect text and value; add the guard and rerun.

Expected: The evidence explains why the correction works.

3. Record blank, zero, positive and invalid-text checks in your journal.

Expected: All four cases have explicit expectations and observed results.

## Outcome

A minimal bug report, corrected validation and the language checkpoint functions.

## Check

A function returns the wrong total but throws no exception. Is it correct?

Yes, no exception means success.

Only if Console is empty.

No; compare the result against the intended rule.

Reference answer: No; compare the result against the intended rule.

Logic errors need behavioural assertions, not just an absence of runtime errors.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions