# What HTML is: elements and the document

HTML means HyperText Markup Language. It marks the structure and meaning of content; it does not describe an algorithm.

Tags, elements and nesting
An element is the complete structure, such as <p>Hello</p>. Opening and closing tags surround its content. Nest elements so the inner one closes first. Some elements, including img and input, are void elements with no closing tag. Indentation helps humans see nesting but does not create the structure.

The document skeleton
The doctype asks for modern standards behaviour. html is the root; lang describes the document language. head contains metadata such as title and character encoding. body contains the visible content. The browser tab uses title; the visible page heading is a separate h1 element.

Headings and paragraphs
Use headings to organise sections and p for paragraphs. Do not choose h4 simply because it looks smaller: CSS controls appearance. A clear main heading and logical section headings help readers and assistive technology understand the document. Escape angle brackets when you want to display markup as text.

## Mental model

A document outline with labelled containers, rather than a picture made of large and small text.

Limit: Valid-looking HTML can still express the wrong meaning. Browser error recovery is not a substitute for writing a deliberate document.

## Worked example

```
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>My journal</title></head>
<body>
  <h1>Learning journal</h1>
  <h2>Today</h2>
  <p>I created my first document.</p>
</body>
</html>
```

title is tab metadata; h1 is visible content.

The paragraph belongs inside body. Matching closing tags make the nesting explicit.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Create first-page.html beside the starter and type the complete example. Open it in a browser.

Expected: The tab says My journal and the page says Learning journal.

2. Add a second h2 section with two paragraphs. Inspect the document in Elements.

Expected: Both sections are siblings under body.

3. Display the text <p> using &lt;p&gt;, then explain why raw markup is interpreted differently.

Expected: The angle brackets are visible as text.

## Outcome

A complete HTML document with correct metadata, two sections and a literal markup example.

## Check

Which element changes the browser tab label?

h1

title

main

Reference answer: title

title is document metadata in head; h1 names the visible main heading.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements

https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website