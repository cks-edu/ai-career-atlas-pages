# Images, alternative text and resource sizing

An image is a resource with a purpose. Its text alternative and dimensions are part of the content design.

Source and text alternative
src identifies the image resource. alt supplies a text alternative. Describe the relevant information in an informative image; use alt="" for a purely decorative image that adds no information. For an image acting as a link, communicate the link purpose. Do not omit alt merely because an image is decorative.

Dimensions and responsive sizing
Intrinsic width and height help reserve space before loading. CSS max-width:100% allows an image to shrink within its container; height:auto preserves its aspect ratio. This does not reduce the file size sent over the network. Larger projects use appropriately sized sources and modern formats.

Captions and failure cases
Use figure and figcaption when a visible caption belongs with an illustration. A caption and alt may do different jobs. Test a deliberately wrong source path and check whether the remaining text communicates the essential information. Avoid putting important instructions only inside an image.

## Mental model

Alternative text is the useful message a reader needs when the picture cannot be seen.

Limit: A filename is rarely an adequate description. Alternative text depends on the surrounding task, not just the pixels.

## Worked example

```
<figure>
  <img src="./layout.svg" alt="Header above a two-column content area" width="480" height="240">
  <figcaption>Our planned desktop layout.</figcaption>
</figure>
<style>img { max-width: 100%; height: auto; }</style>
```

The dimensions reserve a 2:1 area; the CSS can shrink it.

The alt describes the information, not the filename layout.svg.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Use course-labs/web/layout.svg in a figure and add a purpose-specific alt.

Expected: The diagram and caption appear together.

2. Resize the page to 320px and verify the image fits.

Expected: The aspect ratio is preserved without page overflow.

3. Break the src temporarily. Read the alternative and decide whether it preserves the diagram’s important message.

Expected: The repaired resource and useful alternative are both present.

## Outcome

An informative figure that fits a narrow screen and remains meaningful if the resource fails.

## Check

Which CSS makes a wide image fit its container while preserving shape?

width:2000px

max-width:100%; height:auto

height:10px; width:100%

Reference answer: max-width:100%; height:auto

The maximum limits width while automatic height preserves the image aspect ratio.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/HTML_images

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

https://www.w3.org/WAI/tutorials/