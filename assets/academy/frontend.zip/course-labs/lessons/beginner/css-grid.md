# Grid, normal flow and positioning

Use normal document flow by default. Add Grid for two-dimensional layout and positioning only when it serves a clear purpose.

Grid tracks

display:grid creates a grid container. grid-template-columns defines columns; fr distributes available space. gap separates tracks. minmax(0,1fr) lets a flexible track shrink below its content-based automatic minimum when appropriate. Keep code and long URLs from forcing the entire page wider.

Normal flow first

Block content normally follows previous content. Padding and gap usually solve spacing needs. position:relative keeps the element in flow while allowing an offset; absolute removes it from normal flow and uses a containing block. Do not use absolute coordinates for an entire document layout.

Sticky and responsive behaviour

Sticky positioning can keep navigation available within its scroll constraints. It needs a relevant inset such as top and can be affected by scrolling ancestors. Check whether it covers content at zoom. On phones, a collapsible outline can be more useful than a permanently narrow reading column.

## Mental model

Grid lays out a set of tracks; positioning moves a box according to a separate reference.

Limit: An attractive desktop grid is not automatically a usable mobile layout. Positioned content can overlap when text grows.

## Worked example

```
.workspace { display: grid; grid-template-columns: 14rem minmax(0, 1fr); gap: 1rem; }
@media (max-width: 45rem) {
  .workspace { grid-template-columns: 1fr; }
}
```

A media query changes the grid rather than shrinking every font.

The HTML remains in meaningful order for the single-column layout.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Create a navigation aside and a main reading region using the workspace rule.

Expected: They form two columns when enough room exists.

2. Test at 320px and at 200% zoom with a long URL.

Expected: Content remains available in one column; long text does not widen the page.

3. Temporarily absolutely position the main region and increase its text. Explain the overlap, then restore Grid.

Expected: The restored layout responds to content height.

## Outcome

A two-to-one-column layout and a documented positioning failure.

## Check

Why does absolute positioning often fail for an entire article layout?

It automatically changes semantics.

It removes boxes from normal flow, so growing content can overlap.

It cannot use pixels.

Reference answer: It removes boxes from normal flow, so growing content can overlap.

Out-of-flow positioning does not reserve normal layout space for changing content.

## Sources

https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Grid_layout/Basic_concepts

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Positioning

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design