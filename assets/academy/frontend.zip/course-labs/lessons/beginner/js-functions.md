# Functions, parameters, return values and scope

A function groups a named operation. Give it clear inputs and return a result that another part of the program can use.

Call versus define
A function definition describes work; calling it performs the work. Parameters are local names in the definition and arguments are the supplied values. return ends that call and supplies a result. Logging a value is not the same as returning it to the caller.

Local scope
let and const are block-scoped. Names defined inside a function are not automatically available outside it. An inner function can use outer variables through a closure. Avoid accidental globals: they couple unrelated code and make tests depend on execution order.

Small pure calculations
For a total calculation, accept quantities and prices as arguments, reject invalid input and return the number. Keep DOM updates in a separate function. Then you can check the calculation without constructing a page. Name the units, such as integer cents, to avoid ambiguity.

## Mental model

A small workshop with an entrance for inputs and an exit for a result.

Limit: A function can also change outside state. Prefer explicit inputs and outputs for calculations so they are easier to test.

## Worked example

```
function totalCents(priceCents, quantity) {
  if (!Number.isInteger(quantity) || quantity < 0) throw new Error("Invalid quantity");
  return priceCents * quantity;
}
const total = totalCents(125, 3);
console.log(total); // 375
```

Arguments 125 and 3 bind to the two parameters for this call.

The returned result is stored in total; console.log only displays it.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Define totalCents in Console or a saved script and call it with 125, 3.

Expected: The return value is 375.

2. Call it with quantities 0 and -1 and record the different outcomes.

Expected: Zero returns 0; negative quantity throws.

3. Add a guard for a nonnegative integer price and test it independently.

Expected: Both input contracts are enforced without touching the DOM.

## Outcome

A reusable total function and tests for both input boundaries.

## Check

A function only calls console.log(5) and has no return statement. What does the call return?

5

undefined

The console panel

Reference answer: undefined

Logging is an effect; without an explicit returned value the call returns undefined.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types