# Attributes, links and file navigation

Attributes add information to an element. Use them to identify controls, link documents and describe resources.

Attribute syntax

Write attributes inside the opening tag as name="value". Quote values consistently. id should be unique within a document; class can be shared by several elements. Boolean attributes such as required are true when present: required="false" still means the attribute is present.

Hyperlinks versus actions

An anchor with href navigates to a destination. A button performs an action such as submitting a form. Link text should describe the destination instead of saying click here. A fragment such as #contact refers to an element whose id is contact.

Paths and navigation

Link two local pages using relative paths. External links need a complete URL including its scheme. Avoid forcing a new tab without a reason. Test each link after moving the project into a subfolder; an accidental root-relative path can appear correct only on your own machine.

## Mental model

A tag names an object; its attributes are the labelled fields describing that object.

Limit: An id identifies an element in a document; it does not make content private or validate a URL.

## Worked example

```
<nav aria-label="Main">
  <a href="./about.html">About this journal</a>
  <a href="#contact">Contact</a>
</nav>
<section id="contact"><h2>Contact</h2></section>
```

The fragment and id match exactly.

aria-label distinguishes navigation regions; it does not replace meaningful link text.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Create about.html with a heading and a link back to index.html.

Expected: Both documents can be opened independently.

2. Add a relative About link and a #contact link to the main page. Activate both.

Expected: About changes the document; Contact moves within the same one.

3. Change the fragment temporarily to #missing, observe the failure and restore it.

Expected: The repaired link targets the intended section.

## Outcome

Two connected pages and one tested in-page link, with no duplicated ids.

## Check

Which control should navigate to an About page?

A div with a click handler.

A form input.

An anchor with an href.

Reference answer: An anchor with an href.

A real link provides navigation semantics and expected browser behaviour.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Creating_links

https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax