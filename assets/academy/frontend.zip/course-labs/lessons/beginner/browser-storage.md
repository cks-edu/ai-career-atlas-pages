# Browser storage, JSON and recovery

Keep a small local learning list across reloads, while being honest about where the data lives and how it can fail.

Serialise deliberately

localStorage stores strings. JSON.stringify converts a supported value into JSON text; JSON.parse reads it back and may throw on invalid text. Parsed data still needs shape validation before the UI trusts it. Dates and class instances do not automatically regain their original behaviour.

Separate state from rendering

Keep the tasks array as the source of truth. Load it once, validate it, then render. Save after accepted changes. Do not treat whatever happens to be in the DOM as your only record. Include stable ids so saved items retain identity after reordering.

Handle unavailable data

Wrap storage access and parsing in error handling. Distinguish no saved data from corrupted data. Offer a fresh empty state or an export without quietly claiming persistence succeeded. Use the local HTTP lab for consistent origin behaviour; file-URL storage behaviour is not a portable contract.

## Mental model

A notebook kept by one browser for one origin.

Limit: localStorage is not an account, a backup service or a secure store for secrets. Browser clearing, quota limits and origin changes affect it.

## Worked example

```
function loadTitles() {
  try {
    const raw = localStorage.getItem("practice-titles-v1");
    const value = raw === null ? [] : JSON.parse(raw);
    if (!Array.isArray(value) || !value.every(x => typeof x === "string")) throw new Error("Invalid shape");
    return { titles: value, error: null };
  } catch { return { titles: [], error: "Saved data is unavailable" }; }
}
```

Parsing succeeds only for valid JSON; the array/string checks validate its shape.

The error is returned explicitly instead of claiming an empty list was successfully restored.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Start the supplied local server from course-labs, open /web/ and save a synthetic title list under practice-titles-v1.

Expected: Reloading the same origin can read that list.

2. Set that key to malformed JSON in DevTools and call loadTitles.

Expected: An explicit recovery result is returned without crashing the whole page.

3. Handle a failing setItem call in your save function and show a persistence warning.

Expected: The current session stays usable while the limitation is visible.

## Outcome

A local-only task list with valid, missing and corrupt-data recovery cases.

## Check

JSON.parse returns an object successfully. Is it safe to assume it contains your task schema?

Yes, parsing validates business fields.

Only when the file is small.

No; validate the parsed shape and values.

Reference answer: No; validate the parsed shape and values.

Parsing establishes JSON syntax, not the required application contract.

## Sources

https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_objects

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling