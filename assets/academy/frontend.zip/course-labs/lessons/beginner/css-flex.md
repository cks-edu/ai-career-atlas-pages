# Flexbox: arrange a row or column

Flexbox distributes items along one main axis. Use it for a toolbar, navigation row or a stack of aligned controls.

Container and axes

display:flex makes direct children flex items. flex-direction chooses the main axis. justify-content distributes along that axis; align-items works across it. Do not memorise left and right: direction and writing mode can change how axes map to the screen.

Flexible items

gap creates space between items. flex-wrap allows additional lines. The flex shorthand controls growth, shrinkage and basis. Items can still overflow because of intrinsic minimum sizes or unbreakable content. Inspect the actual item constraints before forcing a fixed width.

Preserve meaningful order

Visual reordering does not necessarily change DOM reading or keyboard order. Keep source order meaningful and use layout to present it. Test long translated labels and zoom; a toolbar should wrap rather than hide the action a learner needs.

## Mental model

Items share a flexible line that can grow, shrink or wrap.

Limit: Flexbox is primarily one-dimensional. For coordinated rows and columns, Grid may describe the layout more clearly.

## Worked example

```
.toolbar { display: flex; flex-wrap: wrap; gap: .75rem; align-items: center; }
.toolbar input { flex: 1 1 12rem; min-width: 0; }
.toolbar button { flex: 0 0 auto; }
```

The input can grow and shrink from a 12rem basis.

Wrapping handles narrow space without changing document order.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Wrap a labelled input and button in a toolbar and apply the rule.

Expected: Controls align when space permits.

2. Narrow the viewport and replace the button text with a longer label.

Expected: Items wrap without disappearing.

3. Switch flex-direction to column and explain which alignment now affects which axis.

Expected: Your explanation follows axes rather than fixed screen directions.

## Outcome

A responsive toolbar tested with long text and both axis directions.

## Check

What changes when flex-direction changes from row to column?

The main axis.

The HTML source order.

The meaning of every button.

Reference answer: The main axis.

Flex direction changes the layout axis; source order and semantics remain separate.

## Sources

https://developer.mozilla.org/en-US/docs/Web/CSS/Guides/Flexible_box_layout/Basic_concepts

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics/Box_model