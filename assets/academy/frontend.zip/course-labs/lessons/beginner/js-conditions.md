# Operators, comparisons and decisions

A program chooses behaviour using conditions. Make the rule explicit and test its boundaries.

Equality and logical operators

Use === and !== for equality without type coercion. && and || short-circuit and return operand values, not always booleans. ! negates truthiness. Zero, empty text, null, undefined and NaN are falsy, so a truthiness test may reject a valid zero.

Branches and boundary cases

if executes a block when its condition is truthy; else handles the other case. Use braces for clarity. Write the intended valid range first, then test just below, at and just above each boundary. Avoid overlapping branches that hide an allowed state.

Default values

The nullish operator ?? supplies a fallback for null or undefined while preserving zero and empty text. || supplies a fallback for every falsy value. Choose based on meaning, not the shortest expression. Missing and intentionally empty can be different product states.

## Mental model

A decision gate with a stated condition, rather than a guess about what looks true.

Limit: A boolean check only enforces the rule you wrote. It cannot infer missing product requirements.

## Worked example

```
function labelMinutes(value) {
  if (!Number.isFinite(value) || value < 0) return "Invalid";
  if (value === 0) return "Rest day";
  return `${value} minutes`;
}
console.log(labelMinutes(0));
```

Zero is a valid explicit branch, not treated as missing.

Invalid values are rejected before the success branches.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Run the example with -1, 0, 1 and NaN. Predict each result first.

Expected: Only zero gives Rest day; invalid values are rejected.

2. Compare 0 || 25 with 0 ?? 25 in Console.

Expected: The first produces 25; the second preserves 0.

3. Change the rule to a maximum of 120 minutes and test 119, 120 and 121.

Expected: The new upper boundary is enforced deliberately.

## Outcome

A boundary table and explicit branch rules for allowed study minutes.

## Check

Zero is valid, but null means missing. Which fallback preserves zero?

value || 25

Boolean(value) || 25

value ?? 25

Reference answer: value ?? 25

Nullish coalescing falls back only for null or undefined.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions