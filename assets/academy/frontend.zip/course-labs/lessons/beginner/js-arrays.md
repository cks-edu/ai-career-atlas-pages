# Arrays, loops and transformations

An array keeps an ordered collection. Learn to visit, transform and select items without confusing indices with values.

Visit items
Use array[index] to read a position and length to inspect the item count. for...of visits values. A traditional for loop is useful when the index matters. Stop conditions must eventually become false; an accidental endless loop can freeze the main browser thread.

Map and filter
map creates an array of transformed results; filter creates an array of items that pass a condition. Neither is a substitute for deciding a clear rule. The callback receives each item. Do not mutate the original item accidentally if other code relies on it remaining unchanged.

Choose the right operation
find returns the first match or undefined. some asks whether a match exists. reduce combines values into an accumulator, but a straightforward loop may be clearer for a beginner. Test an empty array as well as the normal case. Name results according to their meaning.

## Mental model

A numbered shelf whose first slot is numbered zero.

Limit: An array’s index is a position, not necessarily a stable identity for an item that can move.

## Worked example

```
const minutes = [10, 25, 40];
const longSessions = minutes.filter(n => n >= 25);
const labels = longSessions.map(n => `${n} min`);
for (const label of labels) console.log(label);
```

filter keeps 25 and 40 without changing minutes.

map returns text labels; for...of visits each label.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Run the example and inspect all three arrays.

Expected: The original stays [10,25,40]; labels contains two strings.

2. Repeat with an empty input array.

Expected: The operations return empty arrays without an exception.

3. Write a function that returns only session lengths between 1 and 120. Test boundary values.

Expected: Invalid durations are excluded using your stated rule.

## Outcome

A collection-transform function with empty and boundary examples.

## Check

Which operation creates an array containing only items that pass a condition?

filter

find

console.log

Reference answer: filter

filter produces the matching collection; find produces at most one item.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Indexed_collections

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Loops_and_iteration

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions