# Semantic sections, lists and readable content

Semantic HTML expresses the job of a piece of content. Build a page that makes sense before styling it.

Page landmarks

Use main for the principal content, nav for a significant navigation area and header/footer for introductory or concluding content in their context. A section groups related content, usually with a heading. A div is useful when no semantic element describes a purely visual grouping.

Lists and emphasis

Use ul when item order does not matter and ol for a sequence. Each item is an li. strong indicates importance and em indicates emphasis; CSS can change their appearance. Do not simulate a list by typing bullet characters and inserting line breaks.

Content before decoration

Write meaningful headings and concise text. Link labels should remain understandable outside their surrounding sentence. Test the unstyled page: if relationships disappear, some meaning may be stored only in colour or position. Put those relationships into the document as well.

## Mental model

A book has a title, chapters and navigation; it is not one long pile of boxes.

Limit: Using main or nav does not automatically make every interaction accessible. Labels, keyboard behaviour and content still need testing.

## Worked example

```
<main>
  <h1>My study plan</h1>
  <section>
    <h2>Today’s steps</h2>
    <ol><li>Read</li><li>Practise</li><li>Check</li></ol>
  </section>
</main>
```

ol carries sequence; CSS-generated numbers alone would not create that structure.

The section heading explains what the group contains.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Replace a group of plain divs in a copy of the starter with main, section and a logical heading.

Expected: Elements reveals meaningful page regions.

2. Add an ordered practice sequence and an unordered tools list.

Expected: The browser presents two distinct list types.

3. Disable CSS and read the page in order. Correct any heading that depends only on size.

Expected: The page remains understandable without styling.

## Outcome

An unstyled-readable document outline with landmarks and both list types.

## Check

A set of installation steps must happen in sequence. Which structure communicates this?

ol containing li elements.

Several paragraphs with spaces.

A large heading for every line.

Reference answer: ol containing li elements.

An ordered list represents a meaningful sequence independently of its styling.

## Sources

https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements

https://www.w3.org/WAI/tutorials/

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax