# Typography, colour, units and focus styles

Readable presentation is functional. Use relative sizes, visible focus and sufficient contrast instead of relying on decoration.

Relative lengths
rem is relative to the root font size; em depends on the relevant font size and can compound. Percentages depend on the property and context. Use unitless line-height so it scales with text. Avoid setting tiny fixed text sizes to fit more information into a component.

Colour with meaning beyond colour
Use text labels as well as colour for errors and status. Check foreground/background contrast with an appropriate tool. Define reusable custom properties for colour and spacing. A custom property stores a value for substitution; it does not automatically enforce contrast or validate a design.

Keyboard focus is essential
Keyboard users need to see where focus is. Use :focus-visible for a clear outline and keep interactive targets practical to activate. Do not remove the browser outline without an effective replacement. Test links and controls on both light and coloured surfaces.

## Mental model

A typographic scale is a shared measuring ruler for a page.

Limit: A unit or colour choice alone does not establish accessibility. Check the rendered content, contrast and user settings.

## Worked example

```
:root { --ink: #203448; --accent: #245b52; }
body { color: var(--ink); font-size: 1rem; line-height: 1.6; }
a:focus-visible, button:focus-visible {
  outline: 3px solid var(--accent); outline-offset: 3px;
}
```

Custom properties let related rules share a value.

A unitless line-height scales with the element’s font size.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Add the typography rules and compare paragraph readability at two text sizes.

Expected: Line spacing scales rather than clipping text.

2. Use Tab through links and the form. Record the focus outline on each surface.

Expected: Focus remains visibly identifiable.

3. Add an error message with both text and colour. Turn the screen to grayscale or ignore colour.

Expected: The error remains understandable through its wording.

## Outcome

A small reusable style palette and keyboard/contrast observations.

## Check

Why should an error include text rather than red colour alone?

CSS cannot render red reliably.

Meaning must remain available without distinguishing that colour.

Red always means success.

Reference answer: Meaning must remain available without distinguishing that colour.

People may perceive colour differently; text supplies an independent cue.

## Sources

https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Values_and_Units

https://www.w3.org/WAI/tutorials/

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics