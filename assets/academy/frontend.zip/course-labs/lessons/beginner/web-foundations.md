# What a frontend developer builds

A frontend is the part of a website people read and interact with in a browser. Start by separating content, presentation and behaviour.

Browser and server
A browser requests files and interprets them. A server sends files or application responses. Opening a local HTML file needs no server, but later network exercises use a local HTTP server. A URL identifies a location; a file path identifies where a file lives. Neither is the same thing as a programming language.

HTML, CSS and JavaScript
HTML names the content: heading, paragraph, link and form. CSS describes presentation: space, colour and layout. JavaScript runs instructions and handles events. They cooperate, but each can be tested separately. A page should still communicate its essential content before extra interaction is added.

Inspect before changing
Open the Elements panel in browser DevTools to inspect the document, then Console to see script messages. A change made only in Elements usually disappears on reload. Edit your saved source file when you want a lasting change. Keep an untouched reference copy so you can compare results.

## Mental model

A small shop: HTML arranges the goods, CSS presents them, and JavaScript responds to the customer.

Limit: A browser can change a screen without changing server data. A useful interface still needs reliable services, accessibility and clear feedback.

## Worked example

```
<h1>My learning journal</h1>
<p>I am learning the web.</p>
<style>h1 { color: #245b52; }</style>
<script>console.log("Page loaded");</script>
```

The h1 is a meaningful heading, not a font-size instruction.

The CSS rule targets the heading. The script writes to Console, not the page.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Extract the course ZIP and open course-labs/web/index.html. Find the page heading and then open DevTools.

Expected: A heading and a task form appear; Console is available.

2. Change the heading in Elements, reload, then change it in index.html and reload again.

Expected: Only the source-file change survives reload.

3. Temporarily remove the stylesheet link. Restore it after comparing the page.

Expected: The content remains present while its appearance changes.

## Outcome

Explain which file controls structure, styling and interaction, using one observed change for each.

## Check

You edit a heading only in DevTools Elements, then reload. Why is it gone?

The saved HTML file was not changed.

CSS deleted the server file.

A heading requires JavaScript storage.

Reference answer: The saved HTML file was not changed.

DevTools edits inspect the current document; save the source to make the change persistent.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Structuring_content/Basic_HTML_syntax

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting