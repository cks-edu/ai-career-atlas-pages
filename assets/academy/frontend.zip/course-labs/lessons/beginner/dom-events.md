# DOM, events and safe page updates

The DOM is the browser’s object representation of the document. JavaScript can select nodes, react to events and change content.

Select after the element exists
querySelector returns the first matching element or null. An external script with defer runs after parsing, so it can find the form. Check the selector and timing when a node is missing. Avoid silently assuming every query succeeded in a reusable component.

Listen to the meaningful event
Use addEventListener to register a handler. submit handles form submission, including keyboard use. preventDefault stops the form’s default navigation when you deliberately handle it in JavaScript. It does not validate the value; write that rule explicitly.

Create text safely
Create an li, set its textContent and append it to the list. A user-controlled string should remain text rather than being parsed as HTML. Associate feedback with a status region and preserve usable focus. A successful local update is a local result, not a saved server record.

## Mental model

A live tree whose nodes can be inspected and changed.

Limit: Updating the DOM changes this browser view. It does not automatically persist data or prove server acceptance.

## Worked example

```
const form = document.querySelector("#taskForm");
const input = document.querySelector("#task");
const list = document.querySelector("#tasks");
form.addEventListener("submit", event => {
  event.preventDefault();
  const title = input.value.trim();
  if (!title) return;
  const item = document.createElement("li");
  item.textContent = title;
  list.append(item);
});
```

The form, input and list ids exist in the downloaded web starter.

textContent keeps angle-bracket input literal.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. In a copy of course-labs/web, replace app.js with the example. Submit using Enter.

Expected: A nonempty title creates one list item without navigation.

2. Try spaces and the text <b>Read</b>.

Expected: Spaces add nothing and the angle brackets remain literal.

3. Add an accessible status message for rejection/success and keep focus in the input.

Expected: Keyboard users can understand the result and add another task.

## Outcome

A keyboard-usable task form with safe DOM updates and visible feedback.

## Check

Which method should display an untrusted task title as literal text?

innerHTML

textContent

document.write

Reference answer: textContent

textContent treats the value as text rather than interpreting markup.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/DOM_scripting

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events

https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html