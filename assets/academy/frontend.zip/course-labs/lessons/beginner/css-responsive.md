# Responsive design and the CSS checkpoint

Responsive design adapts content to available space and user settings. Build a useful small layout first, then enhance it.

Start with flexible content
Add the viewport meta tag, flexible containers and images that fit. Begin with a single readable column. Add a media query when the content has enough room for another arrangement. Avoid naming breakpoints after a particular phone; test the point where your layout actually stops working.

Test difficult content
Use a long heading, a long unbroken token and larger text. Check horizontal scrolling and clipped controls. Prefer wrapping and min-width:0 where the layout requires shrinking. Preserve useful code scrolling inside the code block rather than allowing the whole page to overflow.

Checkpoint: a responsive journal
Style your HTML checkpoint with typography, spacing, Flexbox controls and a Grid content region. Keep focus visible. If you add motion, respect prefers-reduced-motion and keep the interface understandable without animation. Save evidence at narrow and wide sizes.

## Mental model

The same tools arranged on desks of different sizes.

Limit: A breakpoint is a design choice, not a guarantee about a device. Touch, keyboard, zoom and motion preferences vary independently.

## Worked example

```
main { width: min(100% - 2rem, 70rem); margin-inline: auto; }
pre { overflow: auto; max-width: 100%; }
@media (prefers-reduced-motion: reduce) {
  .animated { transition: none; animation: none; }
}
```

The main region leaves a flexible gutter without a fixed mobile width.

The code block handles its own overflow.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Apply your stylesheet to the HTML journal and include the viewport meta tag.

Expected: The page uses the actual device viewport.

2. Test at 320px, 768px and a wide desktop; test 200% zoom and long content.

Expected: Essential content and controls remain readable and reachable.

3. Write a CSS checkpoint report with two screenshots and one repaired issue.

Expected: The report explains an observed layout decision, not just a claim that it is responsive.

## Outcome

A responsive journal with keyboard, zoom and overflow evidence.

## Check

When should you add a layout breakpoint?

Whenever content needs a different arrangement to remain usable.

Only at one popular phone width.

Every 10 pixels regardless of content.

Reference answer: Whenever content needs a different arrangement to remain usable.

Breakpoints should follow layout needs rather than a guessed device list.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design

https://www.w3.org/WAI/tutorials/

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Styling_basics