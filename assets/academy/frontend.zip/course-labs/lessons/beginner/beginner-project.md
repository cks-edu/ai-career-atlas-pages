# Beginner project: a responsive learning journal

Bring HTML, CSS and JavaScript together in one small product. Build from requirements instead of copying a finished screenshot.

Define the user task
A learner should add a study task, see it listed, mark it complete and understand rejected input. Write acceptance examples before implementation: blank title, a normal title, literal markup and keyboard submission. Keep the scope small enough to explain every line.

Build in layers
Begin with semantic HTML that can be read without CSS. Add responsive styling and visible focus. Then connect a state array to DOM rendering. Add optional local persistence only after the normal and invalid-input paths work. Keep the reusable validation function separate from event handling.

Review and present
Test at narrow and wide widths, with keyboard only and with storage failure simulated. Save screenshots and a short bug diary. A portfolio README should explain the user problem, setup, decisions, checks and limitations. Describe this as your learning project rather than employment experience.

## Mental model

A vertical slice: one user task carried from input through validation to useful feedback.

Limit: This project is a browser-only learning artifact. It does not implement accounts, collaborative editing or guaranteed storage.

## Worked example

```
// Acceptance table (write expected results before building)
// "   "       -> zero tasks, visible error
// "Read CSS"  -> one task with a stable id
// "<b>x</b>"  -> literal text, no HTML element
// reload       -> restored state or an explicit storage warning
```

These are observable product requirements, not commands.

A checkbox labelled complete records user intent; do not mark work done merely because a page opened.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Copy course-labs/web into your own journal folder. Write the acceptance table and replace its reference behaviour with your own implementation.

Expected: Your repository contains your changes and the original requirements.

2. Add task completion and a filter using stable ids; keep old tasks unchanged when updating one.

Expected: All, active and completed views reflect the same underlying state.

3. Open course-labs/web/checks.html and read all four results. Add checks for your changed behaviour and complete manual keyboard/viewport tests.

Expected: Reference checks pass; your evidence separately covers your implementation changes.

## Outcome

A responsive journal, source repository, acceptance matrix, screenshots and README with limitations.

## Check

What is strongest portfolio evidence for this project?

A screenshot alone.

A repository with setup, meaningful checks and an explanation of tradeoffs.

A claim that the app is production-certified.

Reference answer: A repository with setup, meaningful checks and an explanation of tradeoffs.

A reviewer needs reproducible behaviour and reasoning, not just an attractive image.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website

https://www.w3.org/WAI/tutorials/

https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository