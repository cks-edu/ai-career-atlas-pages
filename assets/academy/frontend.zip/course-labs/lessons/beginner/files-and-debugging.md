# Files, paths and your first debugging routine

A website is a set of related files. Learn to find a file, link it correctly and use an error message instead of guessing.

Create a predictable folder

Use index.html for the page, styles.css for styles and app.js for behaviour. The extension tells tools the file type. An editor must save plain text, not a rich-text document with a hidden .txt extension. Keep assets in a clearly named subfolder and use consistent lowercase names.

Resolve relative paths

A path such as ./styles.css starts in the current document folder. ../ moves up one level. A leading / starts at the origin root when served over HTTP; it may break a project hosted under a repository subpath. Read the actual requested URL in Network before changing a path.

Make one change at a time

First reproduce the symptom. Then inspect Console for script errors and Network for missing files. Read the filename and line number. Correct one cause, reload and confirm the expected result. If a stylesheet is missing, changing a JavaScript function will not repair its path.

## Mental model

A folder is a labelled shelf; a relative path tells you how to reach another shelf from the current one.

Limit: Local case-insensitive filenames can hide mistakes that appear on a case-sensitive host. A local file page also differs from an HTTP origin.

## Worked example

```
<link rel="stylesheet" href="./styles.css">
<script src="./app.js" defer></script>
```

defer allows the external script to run after HTML parsing.

A missing path is visible in Network when the page is served over HTTP.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. In course-labs/web, rename styles.css to theme.css without editing the link. Reload.

Expected: The layout loses styling; the file request or Console identifies a missing file.

2. Change href to ./theme.css and reload.

Expected: Styling returns with the corrected filename.

3. Restore the original filename and link. Record symptom, evidence and correction in notes.md.

Expected: The starter works again and the debugging record names the actual cause.

## Outcome

A three-line debugging record and working relative stylesheet/script paths.

## Check

Your page works at the host root but its stylesheet fails under /my-course/. What should you inspect first?

The CSS font size.

The resolved stylesheet URL and its path.

The JavaScript variable names.

Reference answer: The resolved stylesheet URL and its path.

Path resolution changes with the hosting base. Network evidence identifies the missing resource.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Getting_started/Your_first_website

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview