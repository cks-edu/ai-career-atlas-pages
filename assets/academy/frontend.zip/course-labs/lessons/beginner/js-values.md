# What JavaScript is: values, variables and types

JavaScript runs instructions. Start with values and expressions in the Console before changing a page.

Values and declarations
Strings hold text, numbers support numeric operations and booleans represent true or false. null and undefined describe different absence cases. const prevents rebinding the variable; let allows reassignment. Use meaningful names and declare values before using them.

Conversion is a decision
The + operator can add numbers or concatenate strings. Convert user input deliberately with Number and reject inappropriate or non-finite values. Number("") produces zero, which may not be a valid answer to your form. Check empty text before treating it as a number.

Observe intermediate results
console.log lets you inspect values without building a UI. typeof helps inspect many primitive values, but has historical edge cases, including typeof null. Predict a result, run the expression and explain any difference. An unexpected value is evidence to investigate.

## Mental model

A variable is a named reference to a value; the value has a type.

Limit: A variable name does not enforce a business rule. Browser input values are strings even when they look like numbers.

## Worked example

```
const text = "12";
const quantity = Number(text);
let total = quantity + 3;
console.log(text + 3, total); // "123", 15
console.log(typeof quantity); // "number"
```

The string plus a number concatenates in this example.

const protects the binding, not the contents of an object stored in it.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Open Console on your local starter and run the example one statement at a time.

Expected: The string and numeric results differ as predicted.

2. Try Number("") and Number("twelve"). Check Number.isFinite for each result.

Expected: Empty text becomes zero; invalid numeric text becomes NaN.

3. Write a conversion function that rejects trimmed empty text before conversion.

Expected: Blank input is rejected instead of silently becoming a valid quantity.

## Outcome

A prediction table for string/number conversion and a blank-input guard.

## Check

An input contains the string "12". What does value + 3 produce before conversion?

15

"123"

A guaranteed TypeError

Reference answer: "123"

With a string operand, this + expression concatenates. Convert deliberately for arithmetic.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Grammar_and_types

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Control_flow_and_error_handling

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions