# Objects, identity, destructuring and immutable updates

An object groups named properties. Use objects for records and stable ids for items whose positions can change.

Properties and identity

Read a property with dot notation or a bracket key. Arrays of objects model lists of related records. Give each record an id that does not depend on its current position. When a list is filtered or sorted, the item should remain the same logical item.

References and copying

Two variables can refer to the same object. Changing a property through one reference affects the shared object. Spread syntax creates a new outer object. If a nested property contains another object, that nested value is still a reference unless explicitly copied.

Destructure and update clearly

Destructuring extracts named values. To update one task in an array, map each task and return a new object for the matching id. Keep unchanged objects for the others. This makes before/after comparisons and UI state updates easier to reason about.

## Mental model

A record with labelled fields rather than a shelf position.

Limit: Spreading an object makes a shallow copy. Nested objects may still be shared.

## Worked example

```
const tasks = [{ id: "a", title: "Read", done: false }];
const updated = tasks.map(task =>
  task.id === "a" ? { ...task, done: true } : task
);
const { title } = updated[0];
console.log(title, tasks[0].done, updated[0].done);
```

The old task stays false because the matching object is copied.

The id remains stable while a field changes.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Run the example and compare the old and new done fields.

Expected: The original is false and the updated value is true.

2. Add a second task and update only id a.

Expected: The second task keeps its original values.

3. Add a nested settings object and demonstrate why a shallow copy shares it. Then copy the nested object when updating.

Expected: Your notes distinguish outer copying from deep independence.

## Outcome

A stable-id update function and a shallow-copy counterexample.

## Check

What does {...task} guarantee?

Every nested object is recursively copied.

A new outer object with copied property values.

The original object can no longer change.

Reference answer: A new outer object with copied property values.

Spread is shallow; object-valued properties can still point at shared nested objects.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_objects

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Indexed_collections

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions