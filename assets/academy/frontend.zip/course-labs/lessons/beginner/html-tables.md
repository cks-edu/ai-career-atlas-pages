# Tables, accessible data and the HTML checkpoint

Tables represent relationships between rows and columns. Use them for data, not for arranging a page.

Cells and headers
table contains rows, tr contains cells, th identifies a header and td identifies data. A caption names the table. For a simple table, scope="col" or scope="row" expresses which cells a header describes. Do not communicate headers only with bold styling.

Choose the right structure
A timetable or comparison matrix belongs in a table. A navigation bar or two-column page belongs in CSS layout. On a narrow screen, keep data relationships intact; a labelled horizontal scroll area can be preferable to shrinking text until it is unreadable.

Checkpoint: explain your document
Combine what you know into a study page: title and language metadata, landmarks, headings, links, an image, a labelled form and a small data table. Read it with CSS removed and navigate with the keyboard. Record the structure you chose and one alternative you rejected.

## Mental model

A spreadsheet with named row and column axes.

Limit: A table that looks aligned can still have unclear header relationships. Complex tables may need a simpler presentation.

## Worked example

```
<table>
  <caption>Weekly practice</caption>
  <tr><th scope="col">Day</th><th scope="col">Minutes</th></tr>
  <tr><th scope="row">Monday</th><td>30</td></tr>
</table>
```

caption names the dataset.

scope declares header direction; it does not choose a visual layout.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Add a three-row practice table to your journal with caption and headers.

Expected: Each number has an identifiable day and unit.

2. Complete the HTML checkpoint page using your previous exercises.

Expected: All required structures are in saved source files.

3. Use Tab, disable styles and inspect the accessibility tree. Document one repair.

Expected: The page order, labels and table relationships stay meaningful.

## Outcome

An HTML-only learning journal and a written structural/accessibility review.

## Check

What should you use for a two-column page layout?

A table with empty spacer cells.

CSS layout around semantic content.

Repeated spaces in HTML.

Reference answer: CSS layout around semantic content.

Tables describe data relationships; CSS is the appropriate layout tool.

## Sources

https://www.w3.org/WAI/tutorials/tables/

https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements

https://www.w3.org/WAI/tutorials/