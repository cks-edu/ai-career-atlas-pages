# Forms, labels, input types and validation

A form gathers related values and submits them. Learn its built-in behaviour before writing custom JavaScript.

Labels and field names

A visible label with for="email" connects to an input with id="email". The id creates the association; name identifies the field in submitted form data. Placeholder text is a hint, not a replacement for a persistent label. Use fieldset and legend to name a related group, such as radio choices.

Types and constraints

Choose email, number or another input type that fits the value. required rejects an empty value; minlength and maxlength constrain text length. Type-specific checks do not prove a value is real or permitted by the business. Explain constraints before submission and keep error feedback near the field.

Submission and buttons

A button inside a form defaults to submit unless you give another type. Use type="button" for unrelated actions. Native submission can be triggered from the keyboard, so later JavaScript should listen to submit on the form rather than only to a button click. Never put real personal data in a learning form.

## Mental model

A form is a questionnaire with named fields and one submission decision.

Limit: Browser validation improves feedback. A server must independently validate data from every client.

## Worked example

```
<form>
  <label for="email">Practice email</label>
  <input id="email" name="email" type="email" required>
  <button type="submit">Continue</button>
</form>
```

id joins the label; name is the submitted key.

No action is supplied in this teaching fragment. Use synthetic input, not personal information.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Add a labelled email field to a separate local practice page. Click its label and use Tab.

Expected: Clicking the label focuses the control; keyboard focus reaches submit.

2. Try submitting an empty value, invalid text and learner@example.test.

Expected: The first two fail native constraints; the syntactically valid address can submit.

3. Prevent real navigation by using the starter’s submit handler when integrating the field. Explain why a server still validates.

Expected: The page gives feedback without claiming the address exists.

## Outcome

A keyboard-usable labelled form and evidence for empty, malformed and valid-looking values.

## Check

What connects a visible label to its input?

Matching class names.

A matching placeholder.

The label’s for and the input’s id.

Reference answer: The label’s for and the input’s id.

The for/id association identifies the labelled control; name serves a different purpose.

## Sources

https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms

https://www.w3.org/WAI/tutorials/forms/labels/

https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/Scripting/Events