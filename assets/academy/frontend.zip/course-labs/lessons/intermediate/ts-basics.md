# TypeScript: annotations, inference and object types

TypeScript checks JavaScript before execution. Use it to describe the values your functions and components expect.

Inference and annotations
TypeScript infers many types from initial values. Add annotations where they clarify a public function or data contract. string and number name primitive types. Avoid any as an escape from understanding an error: it disables useful checking for the affected value.

Describe records
A type alias can name a task shape with required and optional properties. A union such as "todo" | "done" permits specific alternatives. Optional properties may be undefined and need handling. Keep units and domain constraints explicit; number alone does not mean positive integer cents.

Compile separately
Vite transforms TypeScript for development, but transformation alone is not full type checking. The supplied build script runs tsc before Vite. Fix the reported type error, then run tests; successful compilation still does not prove the behaviour is correct.

## Mental model

A checked design drawing; the browser still runs the resulting JavaScript.

Limit: Types are erased at runtime. A typed assertion does not validate an API response or user input.

## Worked example

```
type Task = { id: string; title: string; done: boolean };
function activeCount(tasks: Task[]): number {
  return tasks.filter(task => !task.done).length;
}
// activeCount([{ id: "a", title: "Read", done: "no" }]); // type error
```

The function contract accepts an array of Task records.

A string cannot stand in for the declared boolean field.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. In course-labs/react-app create src/types-practice.ts with the example. Run npm run typecheck.

Expected: The valid declarations compile.

2. Uncomment the invalid call and inspect the error, then repair the value.

Expected: The string/boolean mismatch is caught before execution.

3. Add optional dueDate and handle its absence without a non-null assertion.

Expected: Both absent and present values are handled explicitly.

## Outcome

A typed task contract, one demonstrated compiler error and its correction.

## Check

What does TypeScript guarantee about JSON received at runtime?

It always matches a declared interface.

It cannot contain null.

Nothing without runtime validation.

Reference answer: Nothing without runtime validation.

Static declarations are erased and do not inspect external JSON.

## Sources

https://www.typescriptlang.org/docs/handbook/2/everyday-types.html

https://www.typescriptlang.org/docs/handbook/2/narrowing.html

https://vite.dev/guide/