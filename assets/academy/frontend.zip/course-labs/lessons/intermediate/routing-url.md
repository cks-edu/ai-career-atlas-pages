# URL state, navigation and shareable screens

A useful application lets a learner reload, share a link and use Back without losing the meaning of the current screen.

Decide what belongs in the URL
A selected course, search term or filter may belong in a query or path. Private draft text and secrets do not. Parse allowed values and provide safe defaults. URLSearchParams handles encoding; do not build query strings by concatenating unescaped user values.

History and reload
pushState creates a history entry and replaceState updates the current one. Listen to popstate when implementing manual history navigation. A hash route can work on static hosting without path rewrites. A path router needs a host fallback or real server routes.

Test navigation as a flow
Check first visit, direct deep link, reload, Back and Forward. Restore the selected filter from the URL before rendering. Keep navigation elements as real links when appropriate and move focus predictably after a screen transition. A URL that looks correct while showing stale content is still a bug.

## Mental model

The URL is a bookmarkable address for a view, not a temporary decoration.

Limit: Client routing does not create server routes or access control. A deep link must also be supported by the host.

## Worked example

```
const params = new URLSearchParams(location.search);
const raw = params.get("filter");
const filter = ["all", "active", "done"].includes(raw ?? "") ? raw : "all";
const next = new URL(location.href);
next.searchParams.set("filter", "active");
history.pushState(null, "", next);
```

This fragment changes history; the application still needs to update its rendered state.

Only allowlisted filter values influence the view.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Add all/active/done URL filters to the journal.

Expected: Each view has a shareable query.

2. Reload a done link and test Back/Forward after changing filters.

Expected: The visible filter agrees with the URL at each step.

3. Try an invalid filter and deploy under a subpath.

Expected: The safe default and asset paths still work.

## Outcome

A navigation test matrix and shareable filter links.

## Check

What else is required after manual history.pushState changes a URL?

Nothing; the browser rewrites every component.

Update application state/rendering and handle history navigation.

Store the URL as an API password.

Reference answer: Update application state/rendering and handle history navigation.

History mutation and UI rendering are separate responsibilities.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

https://vite.dev/guide/static-deploy.html