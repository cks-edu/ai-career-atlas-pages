# Event loop, promises and async/await

Asynchronous work finishes later. Structure the result and failure paths without blocking the main thread.

Promise states
A promise represents an eventual fulfilment or rejection. .then handles a fulfilled value and .catch handles rejection. Promise callbacks run after the current synchronous execution finishes. Do not assume that starting two operations makes their completion order predictable.

Await and errors
An async function returns a promise. await pauses that function until its awaited value settles; it does not pause the whole browser. Use try/catch around awaited work when this function owns the recovery decision. A rejected promise that is never observed can become an unhandled rejection.

Concurrency deliberately
awaiting independent operations one after another adds their waiting times. Promise.all can wait for independent work together, but rejects when one input rejects. Decide whether partial results are useful before choosing a combinator. Always make loading and failure visible to the user.

## Mental model

Place an order, continue other work, then handle its eventual result.

Limit: async does not make CPU-heavy code run on another thread. A long synchronous loop still blocks interaction.

## Worked example

```
async function example() {
  console.log("A");
  await Promise.resolve();
  console.log("C");
}
example();
console.log("B"); // A, B, C
```

The code before await runs synchronously.

The continuation runs after the current synchronous stack.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Predict and run the example in Console.

Expected: The order is A, B, C.

2. Await a rejected promise inside try/catch and return a recovery message.

Expected: The failure takes the catch path rather than becoming a fake success.

3. Compare sequential and concurrent synthetic delays, recording start/end times.

Expected: Independent concurrent waits overlap; CPU work is still on the main thread.

## Outcome

An execution-order trace and a function with explicit asynchronous failure handling.

## Check

Does marking a heavy loop async automatically move it to a background thread?

Yes.

Only in a click handler.

No.

Reference answer: No.

async changes promise control flow, not the thread executing synchronous work.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Using_promises

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions

https://developer.mozilla.org/en-US/docs/Web/API/Web_Workers_API/Using_web_workers