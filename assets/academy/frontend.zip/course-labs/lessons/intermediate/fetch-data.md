# Fetch, HTTP status, JSON and request states

Fetching data crosses a boundary. Treat transport, HTTP status, parsing and application validation as separate checks.

Read the response contract
fetch returns a promise for a Response. A 404 normally resolves with a response rather than rejecting automatically. Check response.ok or the expected status before treating it as success. Network failures and some browser policy failures follow a different path.

Parse and validate
response.json() is asynchronous and can fail for invalid JSON. Once parsed, verify the shape needed by your UI. An array of task records should have allowed fields and value types. Do not show an object as trusted merely because it came from an API.

Represent all visible states
Start with loading; then distinguish success with data, success with no items, and failure. Provide a retry action when appropriate. Keep useful input intact on failure. Avoid showing raw server traces to users; preserve diagnostic details in an appropriate development log.

## Mental model

Receiving a parcel, checking its delivery status, opening it and checking its contents are separate steps.

Limit: A successful status does not prove the response matches your schema. Client checks do not replace server validation.

## Worked example

```
async function getTasks() {
  const response = await fetch("/api/tasks");
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const data = await response.json();
  if (!Array.isArray(data) || !data.every(t => typeof t.id === "string" && typeof t.title === "string")) {
    throw new Error("Invalid task data");
  }
  return data;
}
```

Status, JSON parsing and shape validation can fail independently.

The local API serves synthetic data only.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. From course-labs run python3 serve.py, open /web/ and call getTasks in its Console.

Expected: /api/tasks returns the documented two task records.

2. Try /api/missing, /api/broken and /api/empty using the same checks.

Expected: 404 and malformed JSON fail; an empty array is a successful empty result.

3. Add loading, empty and error states to the journal. Use DevTools offline mode to test retry.

Expected: The UI never mistakes missing data or failure for a completed load.

## Outcome

A data loader and a state table covering success, empty, HTTP failure and parsing failure.

## Check

fetch receives HTTP 404. What should your loader do?

Check the status explicitly before processing success data.

Assume fetch always rejects on 404.

Treat the body as a successful task list.

Reference answer: Check the status explicitly before processing success data.

HTTP errors normally still produce a Response; the application checks the status.

## Sources

https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Using_promises