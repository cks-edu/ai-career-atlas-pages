# Unknown data, narrowing and discriminated unions

Represent states so invalid combinations are difficult to express. Narrow unknown values before using them.

Unknown at the boundary

Use unknown for a value whose shape has not been established. Check typeof, null, arrays and required properties before accessing them. An assertion such as as Task[] only tells the compiler to trust you; it performs no runtime validation.

Discriminate states

A union with a literal kind field can represent loading, success and error. TypeScript narrows the available fields after checking kind. This is clearer than unrelated booleans that allow impossible combinations such as loading and failed and successful simultaneously.

Exhaustiveness

A switch over all variants makes state handling visible. A never check can expose a newly added case that a renderer forgot. Keep user-facing error text separate from sensitive diagnostics. Model the distinction between an empty successful result and no result yet.

## Mental model

Check a labelled package before deciding which contents it contains.

Limit: A type predicate is code you must implement correctly. Declaring it does not make a weak validator trustworthy.

## Worked example

```
type LoadState =
  | { kind: "loading" }
  | { kind: "ready"; titles: string[] }
  | { kind: "error"; message: string };
function label(state: LoadState): string {
  if (state.kind === "ready") return `${state.titles.length} tasks`;
  if (state.kind === "error") return state.message;
  return "Loading…";
}
```

titles is only accessed after ready narrows the union.

A ready state with an empty array is not the loading state.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Add the union and label function to types-practice.ts. Typecheck all variants.

Expected: Every valid variant produces a string.

2. Try accessing state.titles before checking kind, then repair it.

Expected: The compiler catches the unsafe access.

3. Write a runtime guard for an unknown array of title strings and test null, an object and a valid array.

Expected: Only the intended shape passes the guard.

## Outcome

An explicit loading-state union and tested unknown-input guard.

## Check

Which operation validates external data at runtime?

A correctly implemented field/type check.

Writing as Task[].

Importing a type alias.

Reference answer: A correctly implemented field/type check.

Runtime checks inspect actual values; type assertions and imports do not.

## Sources

https://www.typescriptlang.org/docs/handbook/2/narrowing.html

https://www.typescriptlang.org/docs/handbook/2/everyday-types.html

https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch