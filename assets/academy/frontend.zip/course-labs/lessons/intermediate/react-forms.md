# Controlled forms and accessible validation

A controlled input gets its displayed value from state. Keep form behaviour and error feedback usable from the keyboard.

Control a field

Supply value and onChange together so edits update state. Keep the input consistently controlled rather than switching between undefined and a string. Use a visible label with matching htmlFor/id. React’s JSX names differ slightly from HTML attributes but the resulting association has the same purpose.

Validate on a meaningful action

Handle onSubmit on the form, prevent default navigation and validate a trimmed value. Explain constraints and preserve the user’s input after a failure. A disabled submit button alone may conceal why the action is unavailable. Provide actionable feedback.

Connect errors

Use aria-describedby to connect help/error text where appropriate, and aria-invalid when a field is invalid. Announce changing status without repeatedly interrupting typing. Move focus only when it helps the user understand the result; do not unexpectedly reset the whole form.

## Mental model

The state is the record; the input displays and edits that record.

Limit: Client validation is not authorisation or server validation. Do not confuse a local acceptance message with a remote save.

## Worked example

```
const [title, setTitle] = useState("");
const [error, setError] = useState("");
function submit(event: React.FormEvent) {
  event.preventDefault();
  if (!title.trim()) { setError("Enter a task title."); return; }
  setError(""); // add the validated title using your task-state operation
}
// <input id="title" value={title} onChange={e => setTitle(e.target.value)} />
```

This is a component fragment: keep the hooks inside a component.

Use the supplied App.tsx for the complete labelled form and status structure.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Inspect the supplied App.tsx form and identify its state, label and submit handler.

Expected: You can trace input to validation to state update.

2. Add a maximum title length and a specific error message without clearing invalid input.

Expected: Overlong input is preserved with an explanation.

3. Test Enter submission, empty input, focus order and error announcement.

Expected: All cases work without relying on pointer-only actions.

## Outcome

An accessible controlled form with normal and rejected-input evidence.

## Check

Which event best handles both clicking submit and keyboard form submission?

onMouseDown on a div.

onSubmit on the form.

onHover on the button.

Reference answer: onSubmit on the form.

Form submission is the meaningful action and includes keyboard activation.

## Sources

https://react.dev/learn

https://www.w3.org/WAI/tutorials/forms/labels/

https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms