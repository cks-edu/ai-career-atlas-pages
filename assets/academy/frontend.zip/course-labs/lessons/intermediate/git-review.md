# Git, code review and the intermediate project

Make a change another developer can understand, reproduce and review. Your portfolio should show decisions as well as code.

Local version control
git status shows pending changes; git diff shows their content. Stage only the intended files and inspect the staged diff before committing. Keep generated dependencies, credentials and local personal data out of the repository. Commit the lockfile, not node_modules.

Review a complete change
Explain the user problem, the new behaviour, relevant tests and material limitations. Keep unrelated formatting out of a behaviour change. A reviewer should be able to run the project from the README and understand one meaningful failure case without reading the conversation that led to it.

Intermediate project
Build the typed React learning journal with task creation, filtering, a loading-state model and URL-restored navigation. Reuse the pure domain rules, add interaction evidence and document client-only storage limitations. Include a component diagram and one bug you reproduced and fixed.

## Mental model

A sequence of small, explained snapshots with checks attached.

Limit: A clean Git history does not prove correctness. Review needs requirements, test evidence and an understandable change.

## Worked example

```
git status
git diff
git add src/App.tsx test/domain.test.mjs
git diff --staged
git commit -m "Reject blank study tasks with visible feedback"
```

Run these inside your own initialized learning repository.

Staging explicit files reduces accidental inclusion of unrelated material.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Initialise a repository for your copy of react-app and add a .gitignore for node_modules and dist.

Expected: Only source, lockfile, tests and documentation are tracked.

2. Implement one task/filter requirement with its test, inspect and commit the diff.

Expected: The commit explains one coherent behaviour change.

3. Write a review-ready README and a short change description, then run tests/typecheck/build from a clean dependency install.

Expected: A reviewer has reproducible setup and evidence.

## Outcome

A typed React portfolio application, reproducible repository and review description.

## Check

What belongs in a useful change description?

Only the number of edited files.

The problem, resulting behaviour and relevant validation.

A guarantee that no future bug is possible.

Reference answer: The problem, resulting behaviour and relevant validation.

Reviewers need the user outcome and evidence to assess the change.

## Sources

https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository

https://vite.dev/guide/

https://testing-library.com/docs/react-testing-library/intro/