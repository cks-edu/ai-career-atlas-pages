# Generics and reusable typed functions

A generic expresses a relationship between input and output types without throwing that relationship away.

Preserve a relationship

A function returning the first element should return the same item type as its input array. A generic T describes that relationship. Include undefined for an empty array. Returning any would hide mistakes rather than preserving information.

Constrain only what you need

A reusable function can require an id field without requiring every Task property. A constraint describes the minimum capability the implementation uses. Avoid adding properties to a constraint simply because one caller happens to have them.

Use type utilities deliberately

ReadonlyArray communicates that a function should not mutate its input through that parameter. Pick and Partial can derive related shapes, but they do not enforce permissions or validate updates at runtime. Keep an explicit domain operation when only selected transitions are legal.

## Mental model

A reusable container whose label says what kind of item it currently holds.

Limit: More type parameters do not automatically make a design better. A simple concrete type is often easier to read.

## Worked example

```
function first<T>(items: readonly T[]): T | undefined {
  return items[0];
}
const title = first(["Read", "Build"]);
const missing = first<number>([]);
```

T follows the element type through the return value.

The empty case remains visible as undefined.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Add first to a module in react-app and typecheck string and number callers.

Expected: Each result preserves the respective type plus undefined.

2. Write an empty-array test instead of asserting the result is always present.

Expected: The test records the undefined boundary.

3. Write byId<T extends {id:string}> and test found/missing ids.

Expected: Callers keep their full item type without any.

## Outcome

Two reusable typed functions with explicit missing-item tests.

## Check

Why return T | undefined from first<T>(items)?

Every array always contains undefined.

An empty input has no first element.

Generics cannot return T.

Reference answer: An empty input has no first element.

The signature must include the real empty-input possibility.

## Sources

https://www.typescriptlang.org/docs/handbook/2/generics.html

https://www.typescriptlang.org/docs/handbook/2/everyday-types.html

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Indexed_collections