# Cancellation, stale responses and retry boundaries

A slow old request must not overwrite a newer user choice. Model request identity as well as cancellation.

Identify current work
Assign an increasing request number before starting a read. After awaiting its result, compare it with the current number before rendering. This protects against out-of-order completion even if cancellation does not stop every stage of processing.

Cancel and classify
AbortController supplies a signal to fetch. Abort an obsolete request and treat its expected AbortError separately from a genuine loading failure. Cleanup is also needed when a component stops using the request. Keep cancellation logic tied to the owner of the work.

Retries are a product decision
A failed read is often safe to retry, but a timed-out write might already have happened. Bound retries, respect server guidance and avoid a retry storm. For writes, ask whether a stable operation identifier or another server-supported idempotency contract exists.

## Mental model

Only the newest order slip may update the current display.

Limit: Aborting a browser request is not a server rollback. Retrying a write may duplicate an effect unless the server contract handles it.

## Worked example

```
let latest = 0;
let controller;
async function refreshTasks() {
  const id = ++latest;
  controller?.abort();
  controller = new AbortController();
  try {
    const r = await fetch("/api/tasks", { signal: controller.signal });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const tasks = await r.json();
    if (id === latest) console.log("Current result", tasks);
  } catch (error) {
    if (error.name !== "AbortError" && id === latest) console.error(error);
  }
}
```

The id guard applies to success and failure.

A production loader also validates the response schema as in the previous lesson.

## Lab

Download and extract frontend.zip. Work in course-labs/web using a plain-text editor and a current browser. For HTML/CSS exercises open index.html directly. For fetch, modules and storage exercises open a terminal in course-labs, run python3 serve.py (Windows: py serve.py), then open http://127.0.0.1:8877/web/. Stop that local server with Ctrl+C when finished.

1. Use the local API with /api/tasks?delay=800, then trigger a faster refresh with delay=50.

Expected: Only the currently owned request should update your result region.

2. Abort a pending read and inspect Network plus your visible status.

Expected: Expected cancellation does not become a misleading service error.

3. Write a policy for retrying GET versus an uncertain POST.

Expected: The policy distinguishes a repeatable read from a possibly duplicated write.

## Outcome

A stale-response reproduction, corrected loader and documented retry policy.

## Check

A client aborts a POST after sending it. What is known about the server effect?

It was certainly rolled back.

Its outcome may be unknown without server evidence.

It must have run twice.

Reference answer: Its outcome may be unknown without server evidence.

Client cancellation does not prove whether the server committed an effect.

## Sources

https://developer.mozilla.org/en-US/docs/Web/API/AbortController

https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Overview