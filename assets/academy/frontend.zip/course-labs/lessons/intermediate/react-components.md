# React, JSX and component composition

React describes an interface using components. Learn it after you can build and debug a small page with the browser platform.

Components return UI

A function component returns a description of the UI. Capitalised names such as TaskList refer to components; lowercase names such as button refer to built-in elements. Keep rendering pure: calculate the description without issuing a request or changing storage during the render itself.

Read JSX

JSX looks similar to HTML but is JavaScript syntax transformed by tooling. Use className for CSS classes and braces for expressions. Return one enclosing root or a fragment. Text expressions are rendered as text; do not opt into raw HTML for untrusted content.

Compose small responsibilities

Extract a component when it gives a useful name to a responsibility or supports meaningful reuse. A heading component need not own the whole application’s state. Keep the page structure understandable and test the user-visible behaviour rather than component count.

## Mental model

A tree of reusable interface functions composed into a page.

Limit: A component is not automatically a service boundary. React does not replace HTML semantics, CSS or network contracts.

## Worked example

```
function Welcome({ name }: { name: string }) {
  return <section><h2>Hello, {name}</h2><p>Choose a task to practise.</p></section>;
}
export default function App() {
  return <main><h1>Study journal</h1><Welcome name="Learner" /></main>;
}
```

The prop is typed and read inside the component.

The main/h1/h2 elements retain their HTML meanings.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Run the supplied react-app and replace App.tsx in a copy with the example.

Expected: The page displays the composed greeting.

2. Change the prop and add a second Welcome instance.

Expected: Each instance receives its own supplied data.

3. Run npm run build and correct a deliberately unclosed JSX tag.

Expected: The tooling catches the syntax error; the repaired build succeeds.

## Outcome

A small component tree with meaningful HTML and a reproducible build.

## Check

What distinguishes <Welcome /> from <section> in JSX?

Welcome names a component; section is a built-in element.

Welcome is always rendered on a server.

section cannot contain text.

Reference answer: Welcome names a component; section is a built-in element.

Capitalised component names refer to JavaScript component values.

## Sources

https://react.dev/learn

https://www.typescriptlang.org/docs/handbook/2/everyday-types.html

https://vite.dev/guide/