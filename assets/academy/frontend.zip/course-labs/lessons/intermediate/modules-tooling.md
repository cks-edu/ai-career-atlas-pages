# Modules, npm and a reproducible development setup

A module exposes a deliberate public interface. A package manager installs dependencies; a build tool transforms and serves source files.

ES modules
Use export to expose a function and import to consume it. Browser module scripts use type="module" and should be served over HTTP. Relative imports need correct paths. A module’s top-level scope is separate from other modules, which reduces accidental global coupling.

Node, npm and Vite
Node runs JavaScript outside the browser. npm installs packages and runs scripts from package.json. Vite provides a development server and production build; it is not a production API server. Use a supported Node LTS version that meets the current Vite requirement. Check node -v and npm -v before installation.

Lock dependencies
The supplied react-app project declares exact direct dependency versions and includes a lockfile. npm ci installs from that lockfile and fails if it disagrees with package.json. Commit reviewed updates together with their lockfile changes. A tool warning should be investigated rather than suppressed without explanation.

## Mental model

Modules are rooms with named doors; a lockfile records the exact supplies used to build them.

Limit: Installing a package does not make its code safe or necessary. Review dependencies and keep secrets out of client bundles.

## Worked example

```
// math.js
export function double(value) { return value * 2; }
// main.js
import { double } from "./math.js";
console.log(double(4));
```

A named export and import agree on the public function name.

The supplied project can be rebuilt from its committed lockfile.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Extract the ZIP, open course-labs/react-app, verify a supported Node LTS and run npm ci.

Expected: Dependencies install from the included lockfile.

2. Run npm run dev -- --host 127.0.0.1 and open the printed local URL. Then run npm run build in another terminal.

Expected: The development UI loads and the production output appears in dist.

3. Move a pure calculation into a named module and import it from its test.

Expected: The build and test resolve the explicit module interface.

## Outcome

A working development environment and a tested named module.

## Check

Which file captures resolved dependency versions for reproducible npm installs?

A screenshot of node_modules.

package-lock.json.

The browser history.

Reference answer: package-lock.json.

The lockfile captures the resolved dependency graph; npm ci consumes it.

## Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules

https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

https://vite.dev/guide/