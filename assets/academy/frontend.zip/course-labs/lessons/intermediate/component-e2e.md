# Component tests and browser acceptance tests

Test interactions at the level where they matter. A domain test cannot prove a label is connected or a button is reachable.

Component behaviour
React Testing Library queries elements by roles, names and labels. This encourages tests that resemble how users locate controls. Simulate the meaningful interaction, then assert the resulting content or state. Avoid asserting internal hook order or arbitrary CSS class names.

Real browser flows
Playwright can open the built application, submit a form and inspect the visible result. Use resilient role/name locators and assertions that wait for a condition. Avoid fixed sleeps to hide races. Include empty input, keyboard submission and literal markup as acceptance cases.

Separate reference and learner evidence
The pack includes acceptance-tests.md with test examples and setup commands. Install optional test tooling in your own copy if needed. Record which runner, browser and version you actually executed. Manual keyboard/zoom checks remain part of the portfolio evidence, even when automated tests pass.

## Mental model

Different test layers observe different boundaries of the same user task.

Limit: A DOM simulator is not a real browser, and automation cannot replace every accessibility or usability review.

## Worked example

```
// Playwright example after installing @playwright/test and its Chromium browser
test("adds a task using Enter", async ({ page }) => {
  await page.goto("http://127.0.0.1:5173");
  await page.getByLabel("Task title").fill("Read CSS");
  await page.getByLabel("Task title").press("Enter");
  await expect(page.getByRole("listitem")).toContainText("Read CSS");
});
```

Imports and runner setup are in acceptance-tests.md.

The assertion observes a user-visible item, not a private component variable.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Read the complete setup in acceptance-tests.md and choose component or browser testing for one stated boundary.

Expected: The test plan explains why that layer is appropriate.

2. Implement an empty-input and successful-submission test using roles/labels.

Expected: Each test has a distinct expected outcome.

3. Run the chosen tests, then manually check keyboard focus and zoom; record the actual environments.

Expected: The report separates executed checks from planned ones.

## Outcome

An executed interaction test and a manual accessibility checklist with results.

## Check

What does a pure validator unit test fail to establish?

Whether blank input is rejected by the function.

Whether a rendered form has a usable accessible label and focus order.

Whether a return value equals the expected number.

Reference answer: Whether a rendered form has a usable accessible label and focus order.

DOM and browser behaviour must be observed at their own boundaries.

## Sources

https://testing-library.com/docs/react-testing-library/intro/

https://playwright.dev/docs/intro

https://www.w3.org/WAI/tutorials/