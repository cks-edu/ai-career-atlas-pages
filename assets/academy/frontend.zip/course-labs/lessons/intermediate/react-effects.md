# Effects, dependencies, refs and cleanup

An Effect synchronises a component with something outside React. Do not use one merely to recalculate a value you can derive during rendering.

Choose an Effect deliberately

Calculating a filtered task list belongs in rendering. Sending a form belongs in its event handler. A subscription or timer tied to the component’s presence can belong in an Effect. Keep its dependencies aligned with the reactive values it reads rather than disabling the dependency warning.

Cleanup mirrors setup

If setup registers an event listener, cleanup removes that listener. If it starts a timer, cleanup clears it. React development behaviour may exercise setup and cleanup to reveal unsafe assumptions. Design the operation so repeated mount/cleanup does not leak resources.

Refs are a different tool

A ref can hold a DOM node or mutable value that does not itself drive rendering. Updating a ref does not rerender the component. Use state for data that must update the visible UI and refs for imperative focus or an external handle. Avoid storing the same visible value in both.

## Mental model

Connect an external resource when needed; disconnect the exact resource you connected.

Limit: An empty dependency array does not prove an Effect is universally run once. Development checks and remounting can repeat setup.

## Worked example

```
useEffect(() => {
  const onOnline = () => setMessage("Connection available");
  window.addEventListener("online", onOnline);
  return () => window.removeEventListener("online", onOnline);
}, []);
```

The same function reference is registered and removed.

This fragment assumes setMessage is a stable useState setter in the component.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Add a connection-status Effect and remove/re-add its component.

Expected: There is one owned listener while mounted.

2. Add a timer with mirrored clearInterval cleanup; inspect repeated mounts.

Expected: Unmounting stops the old timer.

3. Replace a redundant filteredTasks Effect with a derived render value.

Expected: The UI remains correct with one source of truth.

## Outcome

A resource-owning Effect with cleanup and a removed redundant Effect.

## Check

Where should a task list filtered from current props normally be calculated?

In render, as a derived value.

In an Effect that copies it into extra state.

In localStorage on every keystroke.

Reference answer: In render, as a derived value.

A derived value usually does not need an additional synchronisation cycle and stored duplicate.

## Sources

https://react.dev/learn/synchronizing-with-effects

https://react.dev/learn/managing-state

https://react.dev/learn