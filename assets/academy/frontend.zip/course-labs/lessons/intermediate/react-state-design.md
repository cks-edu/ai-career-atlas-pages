# Reducers, shared state and component boundaries

As transitions grow, name them explicitly. Put state at the nearest owner that needs to coordinate it.

Lift state to its owner
When siblings need coordinated task/filter state, place it in their common parent and pass values and callbacks. Avoid keeping independent copies that drift apart. Keep local details, such as whether one disclosure is open, local when no other component needs them.

Reducers describe transitions
A reducer receives state and an action and returns the next state without side effects. Name actions according to domain intent. Test the pure reducer directly. Keep network calls and storage writes outside the reducer; their results can become later actions.

Use context when it solves distribution
Context can avoid passing a shared value through many intermediary components. Separate frequently changing values from unrelated ones when needed. Do not introduce a global state library for every small form. First document ownership, update frequency and who needs to subscribe.

## Mental model

A transition table: current state plus an action gives the next state.

Limit: Context distributes a value; it is not automatically a cache, database or performance optimisation.

## Worked example

```
type Action = { type: "toggle"; id: string };
function reducer(tasks: Task[], action: Action): Task[] {
  return tasks.map(t => t.id === action.id ? { ...t, done: !t.done } : t);
}
// const [tasks, dispatch] = useReducer(reducer, initialTasks);
```

The reducer returns a new array and changes only the matched item.

An unknown id leaves the logical data unchanged.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Extract task toggling into a typed reducer and test it with two records.

Expected: Only the target record changes.

2. Test an unknown id and verify the input objects were not mutated.

Expected: The contract has a defined no-match behaviour.

3. Draw which component owns tasks, filter and form text. Explain any context you introduce.

Expected: Every state value has one clear owner.

## Outcome

A tested reducer and a component/state ownership diagram.

## Check

What belongs inside a reducer?

A network POST request.

A storage write.

A pure state transition.

Reference answer: A pure state transition.

A reducer computes next state; effects and external operations have separate ownership.

## Sources

https://react.dev/learn/extracting-state-logic-into-a-reducer

https://react.dev/learn/managing-state

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_objects