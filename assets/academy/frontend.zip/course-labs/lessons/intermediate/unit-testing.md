# Unit tests, assertions and meaningful boundaries

A useful test compares observable behaviour with an independently stated expectation. Start with pure rules.

Arrange, act, assert

Arrange the input, call the operation and assert its result. Test both accepted and rejected inputs. Name the business case in the test so a failure explains what changed. Avoid reproducing the implementation line for line: the expectation should come from the contract.

Choose useful cases

For a title validator, test spaces, an accepted title, overlong input and boundary length. For a reducer, test target identity and input immutability. An empty array often exposes a missed assumption. A test that only checks the output exists is weak evidence.

Run and repair

The supplied project uses Node’s built-in test runner for its pure domain module. Read a failing assertion’s expected and actual values. Correct either a genuine defect or an incorrect requirement, explaining which changed. Do not simply loosen the test until the build turns green.

## Mental model

A repeatable experiment with a known input and a falsifiable prediction.

Limit: A passing reference test validates the reference behaviour it checks. It does not automatically validate your new feature.

## Worked example

```
import test from "node:test";
import assert from "node:assert/strict";
import { titleResult } from "../src/domain.mjs";
test("blank titles are rejected", () => {
  assert.equal(titleResult("   ").ok, false);
});
```

The expectation comes from the form rule.

Node tests run outside the browser and do not prove keyboard behaviour.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. In course-labs/react-app run npm test and read test/domain.test.mjs.

Expected: Normal, rejected and immutable-update checks pass.

2. Remove the trim guard in a copy and rerun the tests.

Expected: The blank-title test fails for a meaningful reason.

3. Restore the guard and add a new boundary test for the maximum length.

Expected: Your new test fails before its required behaviour is fixed and passes afterward.

## Outcome

A regression test with a demonstrated fail/repair/pass cycle.

## Check

Which test is stronger for a blank-title rule?

The function exists.

The source has five lines.

Whitespace-only input produces an explicit rejection.

Reference answer: Whitespace-only input produces an explicit rejection.

The third assertion checks the stated behaviour rather than implementation shape.

## Sources

https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

https://testing-library.com/docs/react-testing-library/intro/

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Functions