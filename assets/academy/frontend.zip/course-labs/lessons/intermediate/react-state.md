# Events, useState and immutable updates

State is data React retains between renders. Update it through its setter so the UI can reflect the new value.

State and handlers

useState returns a current value and a setter. Call hooks at the top level of a component or custom hook, not inside arbitrary conditions. Pass a function to onClick; do not call the handler while rendering. Keep user actions in event handlers.

Previous-state updates

When the next state depends on the previous state, use a functional update such as setCount(c => c + 1). Multiple updates may be batched. Reading the same old count several times is not the same as applying successive transformations to the queued value.

Replace objects and arrays

Do not mutate a state array with push and expect React to detect every intended update. Return a new array using spread, map or filter, and copy the changed object. Keep ids stable. Derived values such as activeCount can be calculated from tasks rather than stored separately.

## Mental model

Each render is a snapshot; event handlers see the snapshot from which they were created.

Limit: A state setter schedules an update. It does not mutate the current render’s local variable immediately.

## Worked example

```
import { useState } from "react";
function Counter() {
  const [count, setCount] = useState(0);
  return <button onClick={() => setCount(c => c + 1)}>Sessions: {count}</button>;
}
```

The arrow is passed as the event handler.

The functional updater receives the pending previous value.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Add Counter and activate it by mouse and keyboard.

Expected: Each activation adds one session.

2. Queue two functional increments in one handler and compare with two setCount(count + 1) calls.

Expected: The snapshot/updater difference is observable.

3. Add a task toggle using map and an object copy instead of mutation.

Expected: Only the selected task changes while original references remain explainable.

## Outcome

A stateful interaction and an immutable task update with a written snapshot explanation.

## Check

Why use setCount(c => c + 1) for an update based on the previous count?

It transforms the queued previous value.

It writes directly to the DOM.

It prevents all future renders.

Reference answer: It transforms the queued previous value.

The updater handles the pending previous state rather than relying on a stale snapshot.

## Sources

https://react.dev/learn/managing-state

https://react.dev/learn

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Working_with_objects