# Props, conditional rendering and stable keys

Pass data down through props and describe repeated UI from arrays. Keep item identity stable across changes.

Props are inputs
Treat props as read-only. A parent supplies values and callbacks; the child describes their presentation. Conditional expressions can choose loading, empty or populated UI. Be careful when rendering a number with &&: zero may appear as text rather than disappearing.

Map records to UI
Use map to turn an array into elements. Give each sibling a key derived from stable data identity. Random keys change on every render, and index keys can associate state with the wrong row when items are inserted, removed or reordered.

Handle empty and long content
An empty list should explain that there are no tasks instead of looking broken. Use semantic list elements. Test duplicate titles with different ids so you do not accidentally treat the title as the unique identity. Long text must wrap without hiding actions.

## Mental model

Each rendered row carries its own identity badge, even when its position changes.

Limit: A key identifies siblings to React. It is not a DOM id, a security token or a prop automatically passed to the child.

## Worked example

```
type Task = { id: string; title: string };
function TaskList({ tasks }: { tasks: Task[] }) {
  if (tasks.length === 0) return <p>No tasks yet.</p>;
  return <ul>{tasks.map(task => <li key={task.id}>{task.title}</li>)}</ul>;
}
```

The data id is stable even when the array is reordered.

The empty state is an intentional success state.

## Lab

Download and extract frontend.zip. Open a terminal in course-labs/react-app. Install a supported Node.js LTS that meets the Vite requirement (this pack requires Node >=22.12). Run node -v, npm -v, npm ci, then npm run dev -- --host 127.0.0.1. Open the printed URL. Use a second terminal in the same folder for npm test, npm run typecheck and npm run build. The included README explains each command. Stop the dev server with Ctrl+C.

1. Add TaskList to App.tsx and pass two records with distinct ids.

Expected: Both titles appear in a semantic list.

2. Pass an empty array and then duplicate titles with distinct ids.

Expected: The empty message works and identity does not depend on title.

3. Add an input to each row, reorder the records and compare stable keys with index keys. Restore stable keys.

Expected: Your notes explain which row retains its intended state.

## Outcome

A typed list component and an identity/reordering experiment.

## Check

Which key is appropriate for a reorderable task list?

Math.random() during render.

A stable unique task id.

The current array index regardless of changes.

Reference answer: A stable unique task id.

Stable data identity lets React match the same item across renders.

## Sources

https://react.dev/learn/rendering-lists

https://react.dev/learn

https://react.dev/learn/managing-state