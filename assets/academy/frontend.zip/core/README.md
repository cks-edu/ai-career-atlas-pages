# Frontend core practice

Open index.html in a browser for the HTML, label, CSS and JavaScript exercises. No dependencies are needed. Save a copy before editing. HTTP/fetch subtopics use the original local-server lab; file:// is not a substitute for that setup.
