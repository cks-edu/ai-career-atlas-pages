# Java Architect — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Types and contracts: A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on.

Apply types and contracts in Java Architect: Use the concept to complete this role exercise: Draw API, service and repository boundaries for the ticket system

Module contracts: A modular monolith can enforce business boundaries before services require network contracts. Keep public interfaces small and make dependency direction visible rather than treating package names as isolation.

### Types and contracts

A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on. In this role, work through: Ticket management calls a notification interface; it must not edit notification storage directly. The practical workshop develops this into: Draw three Java modules for API, ticket domain and adapters. Move domain rules away from HTTP classes and identify each allowed import. Record one forbidden dependency and how review or a build check detects it.

Mental model: A labeled socket that accepts the correct plug.

Boundary: A correct type does not prove a meaningful value; an empty String is still a String.

Role application: Separate rooms in one building can have doors without needing separate buildings.

A modular monolith can enforce business boundaries before services require network contracts. Keep public interfaces small and make dependency direction visible rather than treating package names as isolation.

Worked example: Ticket management calls a notification interface; it must not edit notification storage directly.

Shared foundation example: title(" Learn ") returns "Learn"; title("") throws an error.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Spring Boot and OpenJDK (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Java Architect: Ticket management calls a notification interface; it must not edit notification storage directly.

Predict the worked case

Read this case without running a tool: Ticket management calls a notification interface; it must not edit notification storage directly. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in types and contracts.

Connect the concept to the role

Apply this rule: A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A correct type does not prove a meaningful value; an empty String is still a String.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies types and contracts to this case: Ticket management calls a notification interface; it must not edit notification storage directly. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Ticket management calls a notification interface; it must not edit notification storage directly. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Types and contracts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with types and contracts. Use the glossary below, then write your prediction for: Ticket management calls a notification interface; it must not edit notification storage directly. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Architect role interview. Explain types and contracts using this case: Ticket management calls a notification interface; it must not edit notification storage directly. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate types and contracts to a system or workflow you know. Explain types and contracts using this case: Ticket management calls a notification interface; it must not edit notification storage directly. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What must be checked beyond the String type?

Interview: Explain types and contracts using this case: Ticket management calls a notification interface; it must not edit notification storage directly. State the evidence, one alternative and where the mental model stops.

Quiz: After the Module contracts rehearsal, check this foundation: A value has the required integer type but is outside the allowed business range. What is missing?

A domain validation rule in addition to the type check.

A cast to another integer type regardless of range.

A longer variable name so the caller understands it.

Reference: A domain validation rule in addition to the type check. — Type correctness and business validity are different parts of a contract.

Sources:

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

### Module contracts

A modular monolith can enforce business boundaries before services require network contracts. Keep public interfaces small and make dependency direction visible rather than treating package names as isolation. In this role, work through: Ticket management calls a notification interface; it must not edit notification storage directly. The practical workshop develops this into: Draw three Java modules for API, ticket domain and adapters. Move domain rules away from HTTP classes and identify each allowed import. Record one forbidden dependency and how review or a build check detects it.

Mental model: Separate rooms in one building can have doors without needing separate buildings.

Boundary: Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities.

Worked example: Ticket management calls a notification interface; it must not edit notification storage directly.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Spring Boot and OpenJDK (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Java Architect workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Draw three Java modules for API, ticket domain and adapters. Move domain rules away from HTTP classes and identify each allowed import. Record one forbidden dependency and how review or a build check detects it.

Trace the typed rule

Open TicketService.java and locate the title validator and main method.

Expected: You can predict normal, blank and oversized title outcomes.

Execute the level checks

Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.

```
java TicketService.java test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS java beginner

Inspect a failure

In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.

Expected: Your rejection case is exercised; explain what part of the contract changed.

Role workshop · predict

Ticket management calls a notification interface; it must not edit notification storage directly. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Draw three Java modules for API, ticket domain and adapters. Move domain rules away from HTTP classes and identify each allowed import. Record one forbidden dependency and how review or a build check detects it.

Expected: A dependency diagram and a compiling example with domain tests independent of transport.

Role workshop · debug and verify

Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save module ADR and dependency check. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A dependency diagram and a compiling example with domain tests independent of transport.

Expected: A dependency diagram and a compiling example with domain tests independent of transport.

Troubleshoot: The role exercise differs from the prediction: Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: module ADR and dependency check; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with module contracts. Use the glossary below, then write your prediction for: Ticket management calls a notification interface; it must not edit notification storage directly. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Architect role interview. Explain module contracts using this case: Ticket management calls a notification interface; it must not edit notification storage directly. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate module contracts to a system or workflow you know. Explain module contracts using this case: Ticket management calls a notification interface; it must not edit notification storage directly. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities.

Interview: Explain module contracts using this case: Ticket management calls a notification interface; it must not edit notification storage directly. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Ticket management calls a notification interface; it must not edit notification storage directly.

A dependency diagram and a compiling example with domain tests independent of transport.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A dependency diagram and a compiling example with domain tests independent of transport. — A modular monolith can enforce business boundaries before services require network contracts. Keep public interfaces small and make dependency direction visible rather than treating package names as isolation. A dependency diagram and a compiling example with domain tests independent of transport.

Sources:

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Service boundary: An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport.

Apply service boundary in Java Architect: Use the concept to complete this role exercise: Record an architecture decision on a modular monolith versus services

Outbox and delivery semantics: A business transaction should persist the event to publish with the business record. Dispatch can repeat after failure, so the consumer must protect its own effects with a durable identity.

### Service boundary

An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport. In this role, work through: Order o1 and event e1 commit together; receiving e1 twice creates one notification. The practical workshop develops this into: Port the included outbox idea into a Java repository test using one transaction boundary. Describe crash points before commit, after commit and after delivery. Implement a fake consumer keyed by event ID.

Mental model: A receptionist translates a visitor request for the right team.

Boundary: Framework annotations do not automatically enforce every business rule.

Role application: Write the sale and its mailing slip together; the post office may deliver a copy.

A business transaction should persist the event to publish with the business record. Dispatch can repeat after failure, so the consumer must protect its own effects with a durable identity.

Worked example: Order o1 and event e1 commit together; receiving e1 twice creates one notification.

Shared foundation example: POST /tickets receives text and creates a ticket; GET returns the count.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Spring Boot and OpenJDK (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Java Architect: Order o1 and event e1 commit together; receiving e1 twice creates one notification.

Predict the worked case

Read this case without running a tool: Order o1 and event e1 commit together; receiving e1 twice creates one notification. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in service boundary.

Connect the concept to the role

Apply this rule: An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Framework annotations do not automatically enforce every business rule.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies service boundary to this case: Order o1 and event e1 commit together; receiving e1 twice creates one notification. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Order o1 and event e1 commit together; receiving e1 twice creates one notification. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Service boundary; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with service boundary. Use the glossary below, then write your prediction for: Order o1 and event e1 commit together; receiving e1 twice creates one notification. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Architect role interview. Explain service boundary using this case: Order o1 and event e1 commit together; receiving e1 twice creates one notification. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate service boundary to a system or workflow you know. Explain service boundary using this case: Order o1 and event e1 commit together; receiving e1 twice creates one notification. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Where should title validation live if two endpoints create tickets?

Interview: Explain service boundary using this case: Order o1 and event e1 commit together; receiving e1 twice creates one notification. State the evidence, one alternative and where the mental model stops.

Quiz: After the Outbox and delivery semantics rehearsal, check this foundation: An HTTP handler validates JSON, but the same rule is needed by a batch job. Where should the shared business rule live?

Only in the HTTP status-code mapping.

In a testable domain operation called by both adapters.

In duplicated handler code maintained independently.

Reference: In a testable domain operation called by both adapters. — Transport adapters translate inputs and outputs; shared business behavior should have a clear reusable boundary.

Sources:

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

### Outbox and delivery semantics

A business transaction should persist the event to publish with the business record. Dispatch can repeat after failure, so the consumer must protect its own effects with a durable identity. In this role, work through: Order o1 and event e1 commit together; receiving e1 twice creates one notification. The practical workshop develops this into: Port the included outbox idea into a Java repository test using one transaction boundary. Describe crash points before commit, after commit and after delivery. Implement a fake consumer keyed by event ID.

Mental model: Write the sale and its mailing slip together; the post office may deliver a copy.

Boundary: Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash.

Worked example: Order o1 and event e1 commit together; receiving e1 twice creates one notification.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Spring Boot and OpenJDK (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Java Architect workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Port the included outbox idea into a Java repository test using one transaction boundary. Describe crash points before commit, after commit and after delivery. Implement a fake consumer keyed by event ID.

Trace the typed rule

Open TicketService.java and locate the title validator and main method.

Expected: You can predict normal, blank and oversized title outcomes.

Execute the level checks

Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.

```
java TicketService.java test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS java intermediate

Inspect a failure

In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.

Expected: Your rejection case is exercised; explain what part of the contract changed.

Role workshop · predict

Order o1 and event e1 commit together; receiving e1 twice creates one notification. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Port the included outbox idea into a Java repository test using one transaction boundary. Describe crash points before commit, after commit and after delivery. Implement a fake consumer keyed by event ID.

Expected: No event without its order; duplicate delivery does not duplicate the notification in the fixture.

Role workshop · debug and verify

Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Java outbox prototype and crash-point matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: No event without its order; duplicate delivery does not duplicate the notification in the fixture.

Expected: No event without its order; duplicate delivery does not duplicate the notification in the fixture.

Troubleshoot: The role exercise differs from the prediction: Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: Java outbox prototype and crash-point matrix; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with outbox and delivery semantics. Use the glossary below, then write your prediction for: Order o1 and event e1 commit together; receiving e1 twice creates one notification. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Architect role interview. Explain outbox and delivery semantics using this case: Order o1 and event e1 commit together; receiving e1 twice creates one notification. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate outbox and delivery semantics to a system or workflow you know. Explain outbox and delivery semantics using this case: Order o1 and event e1 commit together; receiving e1 twice creates one notification. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash.

Interview: Explain outbox and delivery semantics using this case: Order o1 and event e1 commit together; receiving e1 twice creates one notification. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Order o1 and event e1 commit together; receiving e1 twice creates one notification.

Ignore the failing case and keep only the successful screenshot.

No event without its order; duplicate delivery does not duplicate the notification in the fixture.

Treat any successful command as proof that all business and access rules passed.

Reference: No event without its order; duplicate delivery does not duplicate the notification in the fixture. — A business transaction should persist the event to publish with the business record. Dispatch can repeat after failure, so the consumer must protect its own effects with a durable identity. No event without its order; duplicate delivery does not duplicate the notification in the fixture.

Sources:

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Concurrency and evidence: Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy.

Apply concurrency and evidence in Java Architect: Use the concept to complete this role exercise: Design an outbox, compatibility policy and failure recovery exercise

Architecture fitness functions: An architecture decision needs executable or reviewable constraints. Use measured latency, migration compatibility and recovery evidence to revisit the decision as workload changes.

### Concurrency and evidence

Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy. In this role, work through: A new reporting feature must not add a synchronous dependency to every ticket write. The practical workshop develops this into: Create two workload scenarios and a dependency budget. Compare a synchronous reporting call with an asynchronous projection. Record latency measurements or explicitly modeled values, then write an adoption threshold and rollback trigger.

Mental model: Two clerks updating the same inventory ledger.

Boundary: An atomic counter protects one value, not a multi-record transaction.

Role application: Building inspections check whether the design still meets its safety and capacity requirements.

An architecture decision needs executable or reviewable constraints. Use measured latency, migration compatibility and recovery evidence to revisit the decision as workload changes.

Worked example: A new reporting feature must not add a synchronous dependency to every ticket write.

Shared foundation example: AtomicInteger increments are safe for this counter; ticket plus payment needs a wider transaction boundary.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Spring Boot and OpenJDK (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Java Architect: A new reporting feature must not add a synchronous dependency to every ticket write.

Predict the worked case

Read this case without running a tool: A new reporting feature must not add a synchronous dependency to every ticket write. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in concurrency and evidence.

Connect the concept to the role

Apply this rule: Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An atomic counter protects one value, not a multi-record transaction.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies concurrency and evidence to this case: A new reporting feature must not add a synchronous dependency to every ticket write. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A new reporting feature must not add a synchronous dependency to every ticket write. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Concurrency and evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with concurrency and evidence. Use the glossary below, then write your prediction for: A new reporting feature must not add a synchronous dependency to every ticket write. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Architect role interview. Explain concurrency and evidence using this case: A new reporting feature must not add a synchronous dependency to every ticket write. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate concurrency and evidence to a system or workflow you know. Explain concurrency and evidence using this case: A new reporting feature must not add a synchronous dependency to every ticket write. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is an atomic counter insufficient for an order and its payment?

Interview: Explain concurrency and evidence using this case: A new reporting feature must not add a synchronous dependency to every ticket write. State the evidence, one alternative and where the mental model stops.

Quiz: After the Architecture fitness functions rehearsal, check this foundation: An atomic counter is correct under concurrency. Does that prove a separate multi-record operation is atomic?

Yes, because both use the same language runtime.

Yes, if each record increments a counter.

No; the multi-record invariant needs its own coordination boundary.

Reference: No; the multi-record invariant needs its own coordination boundary. — Safety of one atomic operation does not compose automatically into a transaction spanning multiple effects.

Sources:

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/

### Architecture fitness functions

An architecture decision needs executable or reviewable constraints. Use measured latency, migration compatibility and recovery evidence to revisit the decision as workload changes. In this role, work through: A new reporting feature must not add a synchronous dependency to every ticket write. The practical workshop develops this into: Create two workload scenarios and a dependency budget. Compare a synchronous reporting call with an asynchronous projection. Record latency measurements or explicitly modeled values, then write an adoption threshold and rollback trigger.

Mental model: Building inspections check whether the design still meets its safety and capacity requirements.

Boundary: A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding.

Worked example: A new reporting feature must not add a synchronous dependency to every ticket write.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Spring Boot and OpenJDK (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Java Architect workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create two workload scenarios and a dependency budget. Compare a synchronous reporting call with an asynchronous projection. Record latency measurements or explicitly modeled values, then write an adoption threshold and rollback trigger.

Trace the typed rule

Open TicketService.java and locate the title validator and main method.

Expected: You can predict normal, blank and oversized title outcomes.

Execute the level checks

Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.

```
java TicketService.java test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS java advanced

Inspect a failure

In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.

Expected: Your rejection case is exercised; explain what part of the contract changed.

Role workshop · predict

A new reporting feature must not add a synchronous dependency to every ticket write. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create two workload scenarios and a dependency budget. Compare a synchronous reporting call with an asynchronous projection. Record latency measurements or explicitly modeled values, then write an adoption threshold and rollback trigger.

Expected: An ADR with evidence, rejected option, owner and a date/trigger for reconsideration.

Role workshop · debug and verify

A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save architecture-review pack with fitness checks and migration sequence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: An ADR with evidence, rejected option, owner and a date/trigger for reconsideration.

Expected: An ADR with evidence, rejected option, owner and a date/trigger for reconsideration.

Troubleshoot: The role exercise differs from the prediction: A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: architecture-review pack with fitness checks and migration sequence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with architecture fitness functions. Use the glossary below, then write your prediction for: A new reporting feature must not add a synchronous dependency to every ticket write. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Java Architect role interview. Explain architecture fitness functions using this case: A new reporting feature must not add a synchronous dependency to every ticket write. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate architecture fitness functions to a system or workflow you know. Explain architecture fitness functions using this case: A new reporting feature must not add a synchronous dependency to every ticket write. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding.

Interview: Explain architecture fitness functions using this case: A new reporting feature must not add a synchronous dependency to every ticket write. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A new reporting feature must not add a synchronous dependency to every ticket write.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

An ADR with evidence, rejected option, owner and a date/trigger for reconsideration.

Reference: An ADR with evidence, rejected option, owner and a date/trigger for reconsideration. — An architecture decision needs executable or reviewable constraints. Use measured latency, migration compatibility and recovery evidence to revisit the decision as workload changes. An ADR with evidence, rejected option, owner and a date/trigger for reconsideration.

Sources:

Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html

dev.java: learn Java: https://dev.java/learn/

Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/
