# Java Architect

Software Engineering

Start with module contracts. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward architecture-review pack with fitness checks and migration sequence.

## beginner

Draw three Java modules for API, ticket domain and adapters. Move domain rules away from HTTP classes and identify each allowed import. Record one forbidden dependency and how review or a build check detects it.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Types and contracts
A method accepts specific kinds of values and returns a defined result or error. A contract describes behavior callers can depend on.
Mental model: A labeled socket that accepts the correct plug.
Limit: A correct type does not prove a meaningful value; an empty String is still a String.
Example: title(" Learn ") returns "Learn"; title("") throws an error.
Recall: What must be checked beyond the String type?

### Module contracts
A modular monolith can enforce business boundaries before services require network contracts. Keep public interfaces small and make dependency direction visible rather than treating package names as isolation.
Mental model: Separate rooms in one building can have doors without needing separate buildings.
Limit: Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities.
Example: Ticket management calls a notification interface; it must not edit notification storage directly.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities.

1. Trace the typed rule
Open TicketService.java and locate the title validator and main method.
Expected: You can predict normal, blank and oversized title outcomes.

2. Execute the level checks
Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.
```
java TicketService.java test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS java beginner

3. Inspect a failure
In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.
Expected: Your rejection case is exercised; explain what part of the contract changed.

4. Role workshop · predict
Ticket management calls a notification interface; it must not edit notification storage directly. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Draw three Java modules for API, ticket domain and adapters. Move domain rules away from HTTP classes and identify each allowed import. Record one forbidden dependency and how review or a build check detects it.
Expected: A dependency diagram and a compiling example with domain tests independent of transport.

6. Role workshop · debug and verify
Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save module ADR and dependency check. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A dependency diagram and a compiling example with domain tests independent of transport.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Module contracts: Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: module ADR and dependency check
A dependency diagram and a compiling example with domain tests independent of transport.

Interview: Work through this Java Architect case: Ticket management calls a notification interface; it must not edit notification storage directly. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A modular monolith can enforce business boundaries before services require network contracts. Keep public interfaces small and make dependency direction visible rather than treating package names as isolation. Expected evidence: A dependency diagram and a compiling example with domain tests independent of transport. Diagnosis: Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities. State the limits of the mental model: Separate rooms in one building can have doors without needing separate buildings.

Resume: Built module ADR and dependency check using Spring Boot and OpenJDK; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Port the included outbox idea into a Java repository test using one transaction boundary. Describe crash points before commit, after commit and after delivery. Implement a fake consumer keyed by event ID.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Service boundary
An HTTP handler translates a request into an operation and returns a status. Keep business rules separate from transport.
Mental model: A receptionist translates a visitor request for the right team.
Limit: Framework annotations do not automatically enforce every business rule.
Example: POST /tickets receives text and creates a ticket; GET returns the count.
Recall: Where should title validation live if two endpoints create tickets?

### Outbox and delivery semantics
A business transaction should persist the event to publish with the business record. Dispatch can repeat after failure, so the consumer must protect its own effects with a durable identity.
Mental model: Write the sale and its mailing slip together; the post office may deliver a copy.
Limit: Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash.
Example: Order o1 and event e1 commit together; receiving e1 twice creates one notification.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash.

1. Trace the typed rule
Open TicketService.java and locate the title validator and main method.
Expected: You can predict normal, blank and oversized title outcomes.

2. Execute the level checks
Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.
```
java TicketService.java test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS java intermediate

3. Inspect a failure
In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.
Expected: Your rejection case is exercised; explain what part of the contract changed.

4. Role workshop · predict
Order o1 and event e1 commit together; receiving e1 twice creates one notification. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Port the included outbox idea into a Java repository test using one transaction boundary. Describe crash points before commit, after commit and after delivery. Implement a fake consumer keyed by event ID.
Expected: No event without its order; duplicate delivery does not duplicate the notification in the fixture.

6. Role workshop · debug and verify
Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Java outbox prototype and crash-point matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: No event without its order; duplicate delivery does not duplicate the notification in the fixture.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Outbox and delivery semantics: Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Java outbox prototype and crash-point matrix
No event without its order; duplicate delivery does not duplicate the notification in the fixture.

Interview: Work through this Java Architect case: Order o1 and event e1 commit together; receiving e1 twice creates one notification. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A business transaction should persist the event to publish with the business record. Dispatch can repeat after failure, so the consumer must protect its own effects with a durable identity. Expected evidence: No event without its order; duplicate delivery does not duplicate the notification in the fixture. Diagnosis: Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash. State the limits of the mental model: Write the sale and its mailing slip together; the post office may deliver a copy.

Resume: Built Java outbox prototype and crash-point matrix using Spring Boot and OpenJDK; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Create two workload scenarios and a dependency budget. Compare a synchronous reporting call with an asynchronous projection. Record latency measurements or explicitly modeled values, then write an adoption threshold and rollback trigger.

Setup: Install Eclipse Temurin JDK 21 or newer. Run java --version. The file uses the JDK HTTP server and needs no Maven dependencies. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Concurrency and evidence
Requests can overlap. Shared mutable data requires a correct synchronization or storage strategy.
Mental model: Two clerks updating the same inventory ledger.
Limit: An atomic counter protects one value, not a multi-record transaction.
Example: AtomicInteger increments are safe for this counter; ticket plus payment needs a wider transaction boundary.
Recall: Why is an atomic counter insufficient for an order and its payment?

### Architecture fitness functions
An architecture decision needs executable or reviewable constraints. Use measured latency, migration compatibility and recovery evidence to revisit the decision as workload changes.
Mental model: Building inspections check whether the design still meets its safety and capacity requirements.
Limit: A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding.
Example: A new reporting feature must not add a synchronous dependency to every ticket write.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding.

1. Trace the typed rule
Open TicketService.java and locate the title validator and main method.
Expected: You can predict normal, blank and oversized title outcomes.

2. Execute the level checks
Run Java source-file mode. Intermediate and advanced checks start a temporary loopback HTTP service and close it.
```
java TicketService.java test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS java advanced

3. Inspect a failure
In a copy, change the accepted length from 80 to 10 and add an 11-character input assertion.
Expected: Your rejection case is exercised; explain what part of the contract changed.

4. Role workshop · predict
A new reporting feature must not add a synchronous dependency to every ticket write. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create two workload scenarios and a dependency budget. Compare a synchronous reporting call with an asynchronous projection. Record latency measurements or explicitly modeled values, then write an adoption threshold and rollback trigger.
Expected: An ADR with evidence, rejected option, owner and a date/trigger for reconsideration.

6. Role workshop · debug and verify
A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save architecture-review pack with fitness checks and migration sequence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: An ADR with evidence, rejected option, owner and a date/trigger for reconsideration.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Architecture fitness functions: A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: architecture-review pack with fitness checks and migration sequence
An ADR with evidence, rejected option, owner and a date/trigger for reconsideration.

Interview: Work through this Java Architect case: A new reporting feature must not add a synchronous dependency to every ticket write. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An architecture decision needs executable or reviewable constraints. Use measured latency, migration compatibility and recovery evidence to revisit the decision as workload changes. Expected evidence: An ADR with evidence, rejected option, owner and a date/trigger for reconsideration. Diagnosis: A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding. State the limits of the mental model: Building inspections check whether the design still meets its safety and capacity requirements.

Resume: Built architecture-review pack with fitness checks and migration sequence using Spring Boot and OpenJDK; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Spring Boot: first application: https://docs.spring.io/spring-boot/tutorial/first-application/index.html
dev.java: learn Java: https://dev.java/learn/
Eclipse Temurin JDK downloads: https://adoptium.net/temurin/releases/
