# Java Architect — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Module contracts

A modular monolith can enforce business boundaries before services require network contracts. Keep public interfaces small and make dependency direction visible rather than treating package names as isolation.
Mental model: Separate rooms in one building can have doors without needing separate buildings.
Case: Ticket management calls a notification interface; it must not edit notification storage directly.
Task: Draw three Java modules for API, ticket domain and adapters. Move domain rules away from HTTP classes and identify each allowed import. Record one forbidden dependency and how review or a build check detects it.
Acceptance: A dependency diagram and a compiling example with domain tests independent of transport.
Troubleshooting: Circular imports indicate unclear responsibility; move the shared contract to the owning boundary instead of adding global utilities.
Deliverable: module ADR and dependency check

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Outbox and delivery semantics

A business transaction should persist the event to publish with the business record. Dispatch can repeat after failure, so the consumer must protect its own effects with a durable identity.
Mental model: Write the sale and its mailing slip together; the post office may deliver a copy.
Case: Order o1 and event e1 commit together; receiving e1 twice creates one notification.
Task: Port the included outbox idea into a Java repository test using one transaction boundary. Describe crash points before commit, after commit and after delivery. Implement a fake consumer keyed by event ID.
Acceptance: No event without its order; duplicate delivery does not duplicate the notification in the fixture.
Troubleshooting: Publishing before commit creates events for rolled-back orders; moving publish after commit alone can lose events on a crash.
Deliverable: Java outbox prototype and crash-point matrix

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Architecture fitness functions

An architecture decision needs executable or reviewable constraints. Use measured latency, migration compatibility and recovery evidence to revisit the decision as workload changes.
Mental model: Building inspections check whether the design still meets its safety and capacity requirements.
Case: A new reporting feature must not add a synchronous dependency to every ticket write.
Task: Create two workload scenarios and a dependency budget. Compare a synchronous reporting call with an asynchronous projection. Record latency measurements or explicitly modeled values, then write an adoption threshold and rollback trigger.
Acceptance: An ADR with evidence, rejected option, owner and a date/trigger for reconsideration.
Troubleshooting: A precise benchmark from invented data is not evidence; label estimates and rerun with representative workload before deciding.
Deliverable: architecture-review pack with fitness checks and migration sequence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
