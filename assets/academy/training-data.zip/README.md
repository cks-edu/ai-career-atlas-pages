# AI data / training-data infrastructure engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Dataset contracts. A data contract describes a dataset and how it may be used. Missing source or usage permission is an unresolved issue, not an automatic approval. Then try Draft a dataset record. The three levels build toward Versioned training-corpus pipeline. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Dataset contracts

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Dataset contracts
Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information.
Mental model: An ingredient specification lists quality, origin and permitted use.
Boundary: Valid schema does not prove useful labels or lawful use.
Worked example: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Clean rows with missing provenance
Every admitted training record must have known source, allowed use and split-group identity. Three records are structurally valid but lack required provenance fields. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine unknown provenance before dataset assembly; retain source identifiers for review.
Recall: Rebuild the manifest and prove disallowed records do not reach training or evaluation splits. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Dataset contracts: Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A data contract describes a dataset and how it may be used. Missing source or usage permission is an unresolved issue, not an automatic approval.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Create three fictional records with text, source, collection date and permitted-use fields. Leave the source and permission blank in one record.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row dataset inventory and a missing-information report.

3. Try step 2
Define which fields are required and check every record against the definition.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row dataset inventory and a missing-information report.

4. Try step 3
Put incomplete records on hold and write what evidence is needed to resolve them.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row dataset inventory and a missing-information report.

5. Explain and check your result
The incomplete record remains visibly unresolved; a filled-in permission field is a claim to verify, not proof of rights. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A three-row dataset inventory and a missing-information report. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every admitted training record must have known source, allowed use and split-group identity. Apply this toy-case rule manually: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three records are structurally valid but lack required provenance fields. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI data / training-data infrastructure engineer.
Create three fictional records with text, source, collection date and permitted-use fields. Leave the source and permission blank in one record.
Define which fields are required and check every record against the definition.
Put incomplete records on hold and write what evidence is needed to resolve them.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A three-row dataset inventory and a missing-information report. Include beginner-worksheet.md and your completed Dataset contract and quarantine register.
Check: The incomplete record remains visibly unresolved; a filled-in permission field is a claim to verify, not proof of rights.

### Interview
Explain your beginner solution for AI data / training-data infrastructure engineer. Use this scenario: Every admitted training record must have known source, allowed use and split-group identity.
Review: Start with the task and permitted scope. Explain dataset contracts: Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information. Show the input and observed output, then address Quarantine unknown provenance before dataset assembly; retain source identifiers for review. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A three-row dataset inventory and a missing-information report. Include beginner-worksheet.md and your completed Dataset contract and quarantine register.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Deduplication and split boundaries

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, Python, storage formats and reliable pipelines; learn dataset provenance and model evaluation needs.

### Deduplication and split boundaries
Identify duplicates before building evaluation splits. Keep linked entities or near-duplicates together when otherwise they would leak information between training and testing.
Mental model: Do not let two copies of the same exam question count as independent evidence.
Boundary: Similarity thresholds can merge unrelated records and need review.
Worked example: Two paraphrases of one support ticket land in train and test; group them by source case before splitting.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Versioned training-corpus pipeline
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.
Recall: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. Identify one observation that would contradict your claim.

### Terms
Deduplication and split boundaries: Identify duplicates before building evaluation splits. Keep linked entities or near-duplicates together when otherwise they would leak information between training and testing.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Stage immutable source rows in DuckDB and compute normalized hashes. Store raw and normalized text separately with a transformation version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
Every admitted training record must have known source, allowed use and split-group identity. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits.
Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.
Stage immutable source rows in DuckDB and compute normalized hashes. Store raw and normalized text separately with a transformation version.
Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons.
Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.
Deliverables: Data pipeline and versioned manifests; Dataset card and provenance register. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI data / training-data infrastructure engineer. Use this scenario: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.
Review: Start with the task and permitted scope. Explain deduplication and split boundaries: Identify duplicates before building evaluation splits. Keep linked entities or near-duplicates together when otherwise they would leak information between training and testing. Show the input and observed output, then address Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Data pipeline and versioned manifests; Dataset card and provenance register. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Reproducible sampling

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Reproducible sampling
Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset.
Mental model: A lottery audit records the pool and drawing procedure, not only the winners.
Boundary: A seed alone does not make a distributed data pipeline reproducible.
Worked example: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Versioned training-corpus pipeline
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. Export train/validation/test manifests and a lineage table. Implement incremental updates and tombstones so deleted sources are removed from all derived outputs.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.
Recall: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. Identify one observation that would contradict your claim.

### Terms
Reproducible sampling: Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Stage immutable source rows in DuckDB and compute normalized hashes. Store raw and normalized text separately with a transformation version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Export train/validation/test manifests and a lineage table. Implement incremental updates and tombstones so deleted sources are removed from all derived outputs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits.
Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.
Stage immutable source rows in DuckDB and compute normalized hashes. Store raw and normalized text separately with a transformation version.
Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons.
Export train/validation/test manifests and a lineage table. Implement incremental updates and tombstones so deleted sources are removed from all derived outputs.
Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.
Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.
Port the transformations to Spark and compare outputs row-for-row before discussing scale.
Deliverables: Data pipeline and versioned manifests; Dataset card and provenance register; Deletion and contamination test report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. A reviewer must reproduce one result and identify which capabilities you implemented. Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.

### Interview
Explain your advanced solution for AI data / training-data infrastructure engineer. Use this scenario: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.
Review: Start with the task and permitted scope. Explain reproducible sampling: Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset. Show the input and observed output, then address Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Data pipeline and versioned manifests; Dataset card and provenance register; Deletion and contamination test report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
DuckDB — Open source · local
CSV ingestion, SQL transforms and reproducible analysis.
Alternative: SQLite (public domain) for embedded transactional SQL or PostgreSQL (open source) for a shared service.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Apache Spark — Open source · compute costs vary
Scale data transformations after validating local output.
Alternative: DuckDB or Polars (open source) for single-machine workloads; distributed execution is justified by measured needs.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Git — Open source · local
Versioned changes, patches and reproducible source revisions.
Alternative: Mercurial is open source, but Git dominates many team workflows; GitHub and GitLab are hosting choices rather than Git replacements.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
DuckDB: https://duckdb.org/docs/stable/clients/python/overview
Apache Spark: https://spark.apache.org/docs/latest/
Git: https://git-scm.com/docs
Apache Spark: https://spark.apache.org/docs/latest/
PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
