## beginner — Dataset contracts

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Dataset contracts
Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information.
Mental model: An ingredient specification lists quality, origin and permitted use.
Boundary: Valid schema does not prove useful labels or lawful use.
Worked example: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Clean rows with missing provenance
Every admitted training record must have known source, allowed use and split-group identity. Three records are structurally valid but lack required provenance fields. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine unknown provenance before dataset assembly; retain source identifiers for review.
Recall: Rebuild the manifest and prove disallowed records do not reach training or evaluation splits. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Dataset contracts: Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A data contract describes a dataset and how it may be used. Missing source or usage permission is an unresolved issue, not an automatic approval.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Create three fictional records with text, source, collection date and permitted-use fields. Leave the source and permission blank in one record.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row dataset inventory and a missing-information report.

3. Try step 2
Define which fields are required and check every record against the definition.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row dataset inventory and a missing-information report.

4. Try step 3
Put incomplete records on hold and write what evidence is needed to resolve them.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row dataset inventory and a missing-information report.

5. Explain and check your result
The incomplete record remains visibly unresolved; a filled-in permission field is a claim to verify, not proof of rights. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A three-row dataset inventory and a missing-information report. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every admitted training record must have known source, allowed use and split-group identity. Apply this toy-case rule manually: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three records are structurally valid but lack required provenance fields. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI data / training-data infrastructure engineer.
Create three fictional records with text, source, collection date and permitted-use fields. Leave the source and permission blank in one record.
Define which fields are required and check every record against the definition.
Put incomplete records on hold and write what evidence is needed to resolve them.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A three-row dataset inventory and a missing-information report. Include beginner-worksheet.md and your completed Dataset contract and quarantine register.
Check: The incomplete record remains visibly unresolved; a filled-in permission field is a claim to verify, not proof of rights.

### Interview
Explain your beginner solution for AI data / training-data infrastructure engineer. Use this scenario: Every admitted training record must have known source, allowed use and split-group identity.
Review: Start with the task and permitted scope. Explain dataset contracts: Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information. Show the input and observed output, then address Quarantine unknown provenance before dataset assembly; retain source identifiers for review. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A three-row dataset inventory and a missing-information report. Include beginner-worksheet.md and your completed Dataset contract and quarantine register.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

