# AI data / training-data infrastructure engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Dataset contracts: Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Dataset contracts

Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information. In this role, work through: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An ingredient specification lists quality, origin and permitted use.

Boundary: Valid schema does not prove useful labels or lawful use.

Worked example: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); Apache Spark (Open source · compute costs vary); Git (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI data / training-data infrastructure engineer: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift.

Predict the worked case

Read this case without running a tool: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in dataset contracts.

Connect the concept to the role

Apply this rule: Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Valid schema does not prove useful labels or lawful use.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies dataset contracts to this case: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Dataset contracts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with dataset contracts. Use the glossary below, then write your prediction for: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI data / training-data infrastructure engineer role interview. Explain dataset contracts using this case: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate dataset contracts to a system or workflow you know. Explain dataset contracts using this case: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain dataset contracts using this case: An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift.

Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information. — Specify fields, units, allowed values, ownership and usage constraints before data enters training. Preserve rejected records for diagnosis without exposing sensitive information. Valid schema does not prove useful labels or lawful use.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

Apache Spark: https://spark.apache.org/docs/latest/

Git: https://git-scm.com/docs

Apache Spark: https://spark.apache.org/docs/latest/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Diagnose: Clean rows with missing provenance

Every admitted training record must have known source, allowed use and split-group identity. Three records are structurally valid but lack required provenance fields. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine unknown provenance before dataset assembly; retain source identifiers for review. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: An ingredient specification lists quality, origin and permitted use.

An age column receives milliseconds; a range and unit check rejects it instead of allowing an unexplained feature shift.

Worked example: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine unknown provenance before dataset assembly; retain source identifiers for review.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: DuckDB (Open source · local); Apache Spark (Open source · compute costs vary); Git (Open source · local)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

Every admitted training record must have known source, allowed use and split-group identity. Three records are structurally valid but lack required provenance fields. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every admitted training record must have known source, allowed use and split-group identity. Apply this toy-case rule manually: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A data contract describes a dataset and how it may be used. Missing source or usage permission is an unresolved issue, not an automatic approval.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Create three fictional records with text, source, collection date and permitted-use fields. Leave the source and permission blank in one record.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row dataset inventory and a missing-information report.

Preparation · Try step 2

Define which fields are required and check every record against the definition.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row dataset inventory and a missing-information report.

Preparation · Try step 3

Put incomplete records on hold and write what evidence is needed to resolve them.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-row dataset inventory and a missing-information report.

Preparation · Explain and check your result

The incomplete record remains visibly unresolved; a filled-in permission field is a claim to verify, not proof of rights. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A three-row dataset inventory and a missing-information report. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every admitted training record must have known source, allowed use and split-group identity. Apply this toy-case rule manually: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three records are structurally valid but lack required provenance fields. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three records are structurally valid but lack required provenance fields. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: clean rows with missing provenance. Use the glossary below, then write your prediction for: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine unknown provenance before dataset assembly; retain source identifiers for review. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI data / training-data infrastructure engineer role interview. Explain diagnose: clean rows with missing provenance using this case: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine unknown provenance before dataset assembly; retain source identifiers for review. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: clean rows with missing provenance to a system or workflow you know. Explain diagnose: clean rows with missing provenance using this case: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine unknown provenance before dataset assembly; retain source identifiers for review. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Rebuild the manifest and prove disallowed records do not reach training or evaluation splits. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: clean rows with missing provenance using this case: Review when missing_provenance >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine unknown provenance before dataset assembly; retain source identifiers for review. State the evidence, one alternative and where the mental model stops.

Quiz: Clean rows with missing provenance: Every admitted training record must have known source, allowed use and split-group identity.

Change the acceptance rule after seeing an inconvenient result.

Quarantine unknown provenance before dataset assembly; retain source identifiers for review.

Omit failed cases and report only the successful demonstrations.

Reference: Quarantine unknown provenance before dataset assembly; retain source identifiers for review. — Quarantine unknown provenance before dataset assembly; retain source identifiers for review. Rebuild the manifest and prove disallowed records do not reach training or evaluation splits.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

Apache Spark: https://spark.apache.org/docs/latest/

Git: https://git-scm.com/docs

Apache Spark: https://spark.apache.org/docs/latest/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, Python, storage formats and reliable pipelines; learn dataset provenance and model evaluation needs.

Terms:

Deduplication and split boundaries: Identify duplicates before building evaluation splits. Keep linked entities or near-duplicates together when otherwise they would leak information between training and testing.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Deduplication and split boundaries

Identify duplicates before building evaluation splits. Keep linked entities or near-duplicates together when otherwise they would leak information between training and testing. In this role, work through: Two paraphrases of one support ticket land in train and test; group them by source case before splitting. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Do not let two copies of the same exam question count as independent evidence.

Boundary: Similarity thresholds can merge unrelated records and need review.

Worked example: Two paraphrases of one support ticket land in train and test; group them by source case before splitting.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, Python, storage formats and reliable pipelines; learn dataset provenance and model evaluation needs.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); Apache Spark (Open source · compute costs vary); Git (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI data / training-data infrastructure engineer: Two paraphrases of one support ticket land in train and test; group them by source case before splitting.

Predict the worked case

Read this case without running a tool: Two paraphrases of one support ticket land in train and test; group them by source case before splitting. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in deduplication and split boundaries.

Connect the concept to the role

Apply this rule: Identify duplicates before building evaluation splits. Keep linked entities or near-duplicates together when otherwise they would leak information between training and testing. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Similarity thresholds can merge unrelated records and need review.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies deduplication and split boundaries to this case: Two paraphrases of one support ticket land in train and test; group them by source case before splitting. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two paraphrases of one support ticket land in train and test; group them by source case before splitting. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Deduplication and split boundaries; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with deduplication and split boundaries. Use the glossary below, then write your prediction for: Two paraphrases of one support ticket land in train and test; group them by source case before splitting. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI data / training-data infrastructure engineer role interview. Explain deduplication and split boundaries using this case: Two paraphrases of one support ticket land in train and test; group them by source case before splitting. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate deduplication and split boundaries to a system or workflow you know. Explain deduplication and split boundaries using this case: Two paraphrases of one support ticket land in train and test; group them by source case before splitting. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain deduplication and split boundaries using this case: Two paraphrases of one support ticket land in train and test; group them by source case before splitting. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two paraphrases of one support ticket land in train and test; group them by source case before splitting.

Treat a passing starter as proof of the whole role workflow.

Identify duplicates before building evaluation splits. Keep linked entities or near-duplicates together when otherwise they would leak information between training and testing.

Ignore the failure because the tool produced an output.

Reference: Identify duplicates before building evaluation splits. Keep linked entities or near-duplicates together when otherwise they would leak information between training and testing. — Identify duplicates before building evaluation splits. Keep linked entities or near-duplicates together when otherwise they would leak information between training and testing. Similarity thresholds can merge unrelated records and need review.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

Apache Spark: https://spark.apache.org/docs/latest/

Git: https://git-scm.com/docs

Apache Spark: https://spark.apache.org/docs/latest/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Integrate: Versioned training-corpus pipeline

Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons. In this role, work through: Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: Do not let two copies of the same exam question count as independent evidence.

Two paraphrases of one support ticket land in train and test; group them by source case before splitting.

Worked example: Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); Apache Spark (Open source · compute costs vary); Git (Open source · local)

Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Stage immutable source rows in DuckDB and compute normalized hashes. Store raw and normalized text separately with a transformation version.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

Every admitted training record must have known source, allowed use and split-group identity. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-intermediate-2.md: Data pipeline and versioned manifests; Dataset card and provenance register. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: versioned training-corpus pipeline. Use the glossary below, then write your prediction for: Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI data / training-data infrastructure engineer role interview. Explain integrate: versioned training-corpus pipeline using this case: Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: versioned training-corpus pipeline to a system or workflow you know. Explain integrate: versioned training-corpus pipeline using this case: Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. Identify one observation that would contradict your claim.

Interview: Explain integrate: versioned training-corpus pipeline using this case: Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Versioned training-corpus pipeline at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.

Reference: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. — Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

Apache Spark: https://spark.apache.org/docs/latest/

Git: https://git-scm.com/docs

Apache Spark: https://spark.apache.org/docs/latest/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Reproducible sampling: Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Reproducible sampling

Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset. In this role, work through: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A lottery audit records the pool and drawing procedure, not only the winners.

Boundary: A seed alone does not make a distributed data pipeline reproducible.

Worked example: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); Apache Spark (Open source · compute costs vary); Git (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI data / training-data infrastructure engineer: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest.

Predict the worked case

Read this case without running a tool: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in reproducible sampling.

Connect the concept to the role

Apply this rule: Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A seed alone does not make a distributed data pipeline reproducible.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies reproducible sampling to this case: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Reproducible sampling; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with reproducible sampling. Use the glossary below, then write your prediction for: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI data / training-data infrastructure engineer role interview. Explain reproducible sampling using this case: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate reproducible sampling to a system or workflow you know. Explain reproducible sampling using this case: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain reproducible sampling using this case: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset.

Reference: Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset. — Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset. A seed alone does not make a distributed data pipeline reproducible.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

Apache Spark: https://spark.apache.org/docs/latest/

Git: https://git-scm.com/docs

Apache Spark: https://spark.apache.org/docs/latest/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Defend: Versioned training-corpus pipeline

Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. Export train/validation/test manifests and a lineage table. Implement incremental updates and tombstones so deleted sources are removed from all derived outputs. In this role, work through: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A lottery audit records the pool and drawing procedure, not only the winners.

A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest.

Worked example: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); Apache Spark (Open source · compute costs vary); Git (Open source · local)

Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Stage immutable source rows in DuckDB and compute normalized hashes. Store raw and normalized text separately with a transformation version.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Export train/validation/test manifests and a lineage table. Implement incremental updates and tombstones so deleted sources are removed from all derived outputs.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. A reviewer must reproduce one result and identify which capabilities you implemented. Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-advanced-2.md: Data pipeline and versioned manifests; Dataset card and provenance register; Deletion and contamination test report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: versioned training-corpus pipeline. Use the glossary below, then write your prediction for: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI data / training-data infrastructure engineer role interview. Explain defend: versioned training-corpus pipeline using this case: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: versioned training-corpus pipeline to a system or workflow you know. Explain defend: versioned training-corpus pipeline using this case: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. Identify one observation that would contradict your claim.

Interview: Explain defend: versioned training-corpus pipeline using this case: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Versioned training-corpus pipeline at this level?

Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation. — Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation. Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

Apache Spark: https://spark.apache.org/docs/latest/

Git: https://git-scm.com/docs

Apache Spark: https://spark.apache.org/docs/latest/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
