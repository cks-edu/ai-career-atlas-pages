# Deletion and contamination test report

Project: Versioned training-corpus pipeline
Status: blank work product — not completed evidence

## Purpose and audience
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits.

## Required content
Export train/validation/test manifests and a lineage table. Implement incremental updates and tombstones so deleted sources are removed from all derived outputs.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.

## Failure evidence
Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
