# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Data pipeline and versioned manifests.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
