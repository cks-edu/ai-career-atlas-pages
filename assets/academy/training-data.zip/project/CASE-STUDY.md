# Versioned training-corpus pipeline

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.

## Limitations and next iteration
Port the transformations to Spark and compare outputs row-for-row before discussing scale.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
