# Data pipeline and versioned manifests

Project: Versioned training-corpus pipeline
Status: blank work product — not completed evidence

## Purpose and audience
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits.

## Required content
Stage immutable source rows in DuckDB and compute normalized hashes. Store raw and normalized text separately with a transformation version.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.

## Failure evidence
Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
