# SAMPLE — Dataset contract and quarantine register
Role: AI data / training-data infrastructure engineer
Case: Clean rows with missing provenance
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
Every admitted training record must have known source, allowed use and split-group identity.

## Evidence table
| Record | missing_provenance (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three records are structurally valid but lack required provenance fields.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Quarantine unknown provenance before dataset assembly; retain source identifiers for review.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai data / training-data infrastructure engineer.
Before release: Rebuild the manifest and prove disallowed records do not reach training or evaluation splits.

## Design choice and trade-off
Track immutable source manifests; use group-aware splits and reproducible sampling.
Strict provenance gates reduce available data but make later deletion and contamination review possible.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Traceable corpus pipeline: A dataset version can be recreated from recorded inputs.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
