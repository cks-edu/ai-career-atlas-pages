## advanced — Reproducible sampling

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Reproducible sampling
Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset.
Mental model: A lottery audit records the pool and drawing procedure, not only the winners.
Boundary: A seed alone does not make a distributed data pipeline reproducible.
Worked example: A fixed seed with a different source ordering can select different rows; store stable IDs and the resulting manifest.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Versioned training-corpus pipeline
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. Export train/validation/test manifests and a lineage table. Implement incremental updates and tombstones so deleted sources are removed from all derived outputs.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.
Recall: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. Identify one observation that would contradict your claim.

### Terms
Reproducible sampling: Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Stage immutable source rows in DuckDB and compute normalized hashes. Store raw and normalized text separately with a transformation version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Export train/validation/test manifests and a lineage table. Implement incremental updates and tombstones so deleted sources are removed from all derived outputs.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a traceable corpus pipeline that handles duplicates, updates, deletion and dataset splits.
Create 100 synthetic documents with document ID, source URL placeholder, license, version and text. Seed exact duplicates, near duplicates and source deletions.
Stage immutable source rows in DuckDB and compute normalized hashes. Store raw and normalized text separately with a transformation version.
Create quarantine rules for unknown licenses, missing IDs and malformed text. Deduplicate before splitting by source group; preserve a record of excluded rows and reasons.
Export train/validation/test manifests and a lineage table. Implement incremental updates and tombstones so deleted sources are removed from all derived outputs.
Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.
Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions.
Port the transformations to Spark and compare outputs row-for-row before discussing scale.
Deliverables: Data pipeline and versioned manifests; Dataset card and provenance register; Deletion and contamination test report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. A reviewer must reproduce one result and identify which capabilities you implemented. Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.

### Interview
Explain your advanced solution for AI data / training-data infrastructure engineer. Use this scenario: Add the same document under a different filename and revoke a source. Rebuild and prove split disjointness plus deletion propagation.
Review: Start with the task and permitted scope. Explain reproducible sampling: Version source snapshots, filters, random seeds and selection rules. Track what changed when regenerating a training dataset. Show the input and observed output, then address Report duplicate counts, quarantined rows, split overlaps and deletion completeness. Treat near-duplicate similarity thresholds as corpus-specific decisions. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Data pipeline and versioned manifests; Dataset card and provenance register; Deletion and contamination test report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

