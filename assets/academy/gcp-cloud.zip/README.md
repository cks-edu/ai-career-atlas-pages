# Google Cloud Engineer

Software Engineering

Start with cloud run execution boundaries. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward GCP rollout and operational readiness pack.

## beginner

Map the task service to container, service identity, durable database and logging. List which state must move out of memory and how the application obtains configuration.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### Cloud Run execution boundaries
Cloud Run serves containerized workloads with managed infrastructure. Application state must not depend on one instance's memory surviving or receiving the next request.
Mental model: A service counter may send the next visitor to a different clerk.
Limit: If records differ across instances, inspect local process state before adding retries.
Example: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If records differ across instances, inspect local process state before adding retries.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Map the task service to container, service identity, durable database and logging. List which state must move out of memory and how the application obtains configuration.
Expected: A stateless-service design with explicit persistent storage.

6. Role workshop · debug and verify
If records differ across instances, inspect local process state before adding retries. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Cloud Run migration design. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A stateless-service design with explicit persistent storage.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Cloud Run execution boundaries: If records differ across instances, inspect local process state before adding retries.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: Cloud Run migration design
A stateless-service design with explicit persistent storage.

Interview: Work through this Google Cloud Engineer case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Cloud Run serves containerized workloads with managed infrastructure. Application state must not depend on one instance's memory surviving or receiving the next request. Expected evidence: A stateless-service design with explicit persistent storage. Diagnosis: If records differ across instances, inspect local process state before adding retries. State the limits of the mental model: A service counter may send the next visitor to a different clerk.

Resume: Built Cloud Run migration design using Google Cloud IAM, VPC, Cloud Run, Cloud SQL and Monitoring; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create an action/resource matrix and a private-connectivity diagram. Use a sandbox to validate intended access and denial of unrelated resources if available; record every check's execution status.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Service accounts and database access
A workload identity should have only needed permissions. Network connectivity to Cloud SQL and permission to use it are related but distinct configuration tasks.
Mental model: The courier needs both a route and an authorized delivery badge.
Limit: Do not embed service-account keys in a container image to bypass identity setup.
Example: The app needs access to its database, not a broad project-owner role.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not embed service-account keys in a container image to bypass identity setup.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
The app needs access to its database, not a broad project-owner role. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create an action/resource matrix and a private-connectivity diagram. Use a sandbox to validate intended access and denial of unrelated resources if available; record every check's execution status.
Expected: A least-privilege design with explicit connection and authorization tests.

6. Role workshop · debug and verify
Do not embed service-account keys in a container image to bypass identity setup. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save IAM matrix and connection troubleshooting guide. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A least-privilege design with explicit connection and authorization tests.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Service accounts and database access: Do not embed service-account keys in a container image to bypass identity setup.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: IAM matrix and connection troubleshooting guide
A least-privilege design with explicit connection and authorization tests.

Interview: Work through this Google Cloud Engineer case: The app needs access to its database, not a broad project-owner role. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A workload identity should have only needed permissions. Network connectivity to Cloud SQL and permission to use it are related but distinct configuration tasks. Expected evidence: A least-privilege design with explicit connection and authorization tests. Diagnosis: Do not embed service-account keys in a container image to bypass identity setup. State the limits of the mental model: The courier needs both a route and an authorized delivery badge.

Resume: Built IAM matrix and connection troubleshooting guide using Google Cloud IAM, VPC, Cloud Run, Cloud SQL and Monitoring; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write a staged traffic plan, synthetic request, error threshold and rollback procedure. Compare backup/restore assumptions and cost drivers in the official framework before any paid deployment.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Revision rollout and recovery
A new revision needs measurable health and a way to move traffic back. Database changes and queued effects can outlive a revision, so compatibility matters during traffic shifts.
Mental model: Changing the clerk does not undo entries already made in the ledger.
Limit: Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery.
Example: Old and new revisions must understand the data written during a staged rollout.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery.

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Role workshop · predict
Old and new revisions must understand the data written during a staged rollout. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a staged traffic plan, synthetic request, error threshold and rollback procedure. Compare backup/restore assumptions and cost drivers in the official framework before any paid deployment.
Expected: A revision decision record with data-compatibility and cleanup steps.

6. Role workshop · debug and verify
Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save GCP rollout and operational readiness pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A revision decision record with data-compatibility and cleanup steps.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Revision rollout and recovery: Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: GCP rollout and operational readiness pack
A revision decision record with data-compatibility and cleanup steps.

Interview: Work through this Google Cloud Engineer case: Old and new revisions must understand the data written during a staged rollout. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A new revision needs measurable health and a way to move traffic back. Database changes and queued effects can outlive a revision, so compatibility matters during traffic shifts. Expected evidence: A revision decision record with data-compatibility and cleanup steps. Diagnosis: Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery. State the limits of the mental model: Changing the clerk does not undo entries already made in the ledger.

Resume: Built GCP rollout and operational readiness pack using Google Cloud IAM, VPC, Cloud Run, Cloud SQL and Monitoring; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
Google SRE book: https://sre.google/sre-book/table-of-contents/
