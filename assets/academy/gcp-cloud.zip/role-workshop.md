# Google Cloud Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Cloud Run execution boundaries

Cloud Run serves containerized workloads with managed infrastructure. Application state must not depend on one instance's memory surviving or receiving the next request.
Mental model: A service counter may send the next visitor to a different clerk.
Case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run.
Task: Map the task service to container, service identity, durable database and logging. List which state must move out of memory and how the application obtains configuration.
Acceptance: A stateless-service design with explicit persistent storage.
Troubleshooting: If records differ across instances, inspect local process state before adding retries.
Deliverable: Cloud Run migration design

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Service accounts and database access

A workload identity should have only needed permissions. Network connectivity to Cloud SQL and permission to use it are related but distinct configuration tasks.
Mental model: The courier needs both a route and an authorized delivery badge.
Case: The app needs access to its database, not a broad project-owner role.
Task: Create an action/resource matrix and a private-connectivity diagram. Use a sandbox to validate intended access and denial of unrelated resources if available; record every check's execution status.
Acceptance: A least-privilege design with explicit connection and authorization tests.
Troubleshooting: Do not embed service-account keys in a container image to bypass identity setup.
Deliverable: IAM matrix and connection troubleshooting guide

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Revision rollout and recovery

A new revision needs measurable health and a way to move traffic back. Database changes and queued effects can outlive a revision, so compatibility matters during traffic shifts.
Mental model: Changing the clerk does not undo entries already made in the ledger.
Case: Old and new revisions must understand the data written during a staged rollout.
Task: Write a staged traffic plan, synthetic request, error threshold and rollback procedure. Compare backup/restore assumptions and cost drivers in the official framework before any paid deployment.
Acceptance: A revision decision record with data-compatibility and cleanup steps.
Troubleshooting: Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery.
Deliverable: GCP rollout and operational readiness pack

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
