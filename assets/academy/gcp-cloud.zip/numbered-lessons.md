# Google Cloud Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Desired state: A controller compares the current system with a declared target and works to reconcile the difference.

Apply desired state in Google Cloud Engineer: Use the concept to complete this role exercise: Map the local service to Cloud Run and a managed database

Cloud Run execution boundaries: Cloud Run serves containerized workloads with managed infrastructure. Application state must not depend on one instance's memory surviving or receiving the next request.

### Desired state

A controller compares the current system with a declared target and works to reconcile the difference. In this role, work through: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. The practical workshop develops this into: Map the task service to container, service identity, durable database and logging. List which state must move out of memory and how the application obtains configuration.

Mental model: A thermostat compares actual temperature with the set point.

Boundary: It cannot fix every cause: a missing image or insufficient resources still needs action.

Role application: A service counter may send the next visitor to a different clerk.

Cloud Run serves containerized workloads with managed infrastructure. Application state must not depend on one instance's memory surviving or receiving the next request.

Worked example: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run.

Shared foundation example: One replica means the controller tries to keep one Pod running.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Google Cloud IAM, VPC, Cloud Run, Cloud SQL and Monitoring (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Google Cloud Engineer: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run.

Predict the worked case

Read this case without running a tool: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in desired state.

Connect the concept to the role

Apply this rule: A controller compares the current system with a declared target and works to reconcile the difference. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: It cannot fix every cause: a missing image or insufficient resources still needs action.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies desired state to this case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Desired state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with desired state. Use the glossary below, then write your prediction for: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Google Cloud Engineer role interview. Explain desired state using this case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate desired state to a system or workflow you know. Explain desired state using this case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens when a Pod is deleted but its Deployment remains?

Interview: Explain desired state using this case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. State the evidence, one alternative and where the mental model stops.

Quiz: After the Cloud Run execution boundaries rehearsal, check this foundation: A controller is told to run two replicas, but only one is ready. What does the declared target mean?

The controller attempts reconciliation; it is not a guarantee that both are healthy now.

Two healthy replicas must already exist.

The current replica count becomes the new desired target automatically.

Reference: The controller attempts reconciliation; it is not a guarantee that both are healthy now. — Desired and observed state differ during convergence or failure. Inspect readiness, events and constraints.

Sources:

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Cloud Run execution boundaries

Cloud Run serves containerized workloads with managed infrastructure. Application state must not depend on one instance's memory surviving or receiving the next request. In this role, work through: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. The practical workshop develops this into: Map the task service to container, service identity, durable database and logging. List which state must move out of memory and how the application obtains configuration.

Mental model: A service counter may send the next visitor to a different clerk.

Boundary: If records differ across instances, inspect local process state before adding retries.

Worked example: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Google Cloud IAM, VPC, Cloud Run, Cloud SQL and Monitoring (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Google Cloud Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Map the task service to container, service identity, durable database and logging. List which state must move out of memory and how the application obtains configuration.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Map the task service to container, service identity, durable database and logging. List which state must move out of memory and how the application obtains configuration.

Expected: A stateless-service design with explicit persistent storage.

Role workshop · debug and verify

If records differ across instances, inspect local process state before adding retries. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Cloud Run migration design. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A stateless-service design with explicit persistent storage.

Expected: A stateless-service design with explicit persistent storage.

Troubleshoot: The role exercise differs from the prediction: If records differ across instances, inspect local process state before adding retries.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-beginner-2.md: Cloud Run migration design; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cloud run execution boundaries. Use the glossary below, then write your prediction for: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Google Cloud Engineer role interview. Explain cloud run execution boundaries using this case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cloud run execution boundaries to a system or workflow you know. Explain cloud run execution boundaries using this case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If records differ across instances, inspect local process state before adding retries.

Interview: Explain cloud run execution boundaries using this case: The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? The reference in-memory task list cannot become a durable shared database by moving it to Cloud Run.

A stateless-service design with explicit persistent storage.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A stateless-service design with explicit persistent storage. — Cloud Run serves containerized workloads with managed infrastructure. Application state must not depend on one instance's memory surviving or receiving the next request. A stateless-service design with explicit persistent storage.

Sources:

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Readiness and routing: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.

Apply readiness and routing in Google Cloud Engineer: Use the concept to complete this role exercise: Design service-account access and private connectivity

Service accounts and database access: A workload identity should have only needed permissions. Network connectivity to Cloud SQL and permission to use it are related but distinct configuration tasks.

### Readiness and routing

Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. In this role, work through: The app needs access to its database, not a broad project-owner role. The practical workshop develops this into: Create an action/resource matrix and a private-connectivity diagram. Use a sandbox to validate intended access and denial of unrelated resources if available; record every check's execution status.

Mental model: A shop can have lights on but still be closed to customers.

Boundary: A health endpoint can be too shallow; it must reflect the service contract.

Role application: The courier needs both a route and an authorized delivery badge.

A workload identity should have only needed permissions. Network connectivity to Cloud SQL and permission to use it are related but distinct configuration tasks.

Worked example: The app needs access to its database, not a broad project-owner role.

Shared foundation example: This container listens on 8080; the Service accepts 80 and forwards to 8080.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Google Cloud IAM, VPC, Cloud Run, Cloud SQL and Monitoring (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Google Cloud Engineer: The app needs access to its database, not a broad project-owner role.

Predict the worked case

Read this case without running a tool: The app needs access to its database, not a broad project-owner role. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in readiness and routing.

Connect the concept to the role

Apply this rule: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A health endpoint can be too shallow; it must reflect the service contract.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies readiness and routing to this case: The app needs access to its database, not a broad project-owner role. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The app needs access to its database, not a broad project-owner role. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Readiness and routing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with readiness and routing. Use the glossary below, then write your prediction for: The app needs access to its database, not a broad project-owner role. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Google Cloud Engineer role interview. Explain readiness and routing using this case: The app needs access to its database, not a broad project-owner role. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate readiness and routing to a system or workflow you know. Explain readiness and routing using this case: The app needs access to its database, not a broad project-owner role. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain why a Running Pod might still receive no traffic.

Interview: Explain readiness and routing using this case: The app needs access to its database, not a broad project-owner role. State the evidence, one alternative and where the mental model stops.

Quiz: After the Service accounts and database access rehearsal, check this foundation: A process listens on 8080. A Service accepts 80. Which target port should route to that listener?

80 because the Service port must equal the application port.

8080, matching the actual application listener.

443 because readiness always implies TLS.

Reference: 8080, matching the actual application listener. — Service and target ports can differ. Readiness must also reflect whether the workload can serve traffic.

Sources:

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Service accounts and database access

A workload identity should have only needed permissions. Network connectivity to Cloud SQL and permission to use it are related but distinct configuration tasks. In this role, work through: The app needs access to its database, not a broad project-owner role. The practical workshop develops this into: Create an action/resource matrix and a private-connectivity diagram. Use a sandbox to validate intended access and denial of unrelated resources if available; record every check's execution status.

Mental model: The courier needs both a route and an authorized delivery badge.

Boundary: Do not embed service-account keys in a container image to bypass identity setup.

Worked example: The app needs access to its database, not a broad project-owner role.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Google Cloud IAM, VPC, Cloud Run, Cloud SQL and Monitoring (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Google Cloud Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create an action/resource matrix and a private-connectivity diagram. Use a sandbox to validate intended access and denial of unrelated resources if available; record every check's execution status.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

The app needs access to its database, not a broad project-owner role. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create an action/resource matrix and a private-connectivity diagram. Use a sandbox to validate intended access and denial of unrelated resources if available; record every check's execution status.

Expected: A least-privilege design with explicit connection and authorization tests.

Role workshop · debug and verify

Do not embed service-account keys in a container image to bypass identity setup. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save IAM matrix and connection troubleshooting guide. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A least-privilege design with explicit connection and authorization tests.

Expected: A least-privilege design with explicit connection and authorization tests.

Troubleshoot: The role exercise differs from the prediction: Do not embed service-account keys in a container image to bypass identity setup.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-intermediate-2.md: IAM matrix and connection troubleshooting guide; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with service accounts and database access. Use the glossary below, then write your prediction for: The app needs access to its database, not a broad project-owner role. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Google Cloud Engineer role interview. Explain service accounts and database access using this case: The app needs access to its database, not a broad project-owner role. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate service accounts and database access to a system or workflow you know. Explain service accounts and database access using this case: The app needs access to its database, not a broad project-owner role. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not embed service-account keys in a container image to bypass identity setup.

Interview: Explain service accounts and database access using this case: The app needs access to its database, not a broad project-owner role. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? The app needs access to its database, not a broad project-owner role.

Ignore the failing case and keep only the successful screenshot.

A least-privilege design with explicit connection and authorization tests.

Treat any successful command as proof that all business and access rules passed.

Reference: A least-privilege design with explicit connection and authorization tests. — A workload identity should have only needed permissions. Network connectivity to Cloud SQL and permission to use it are related but distinct configuration tasks. A least-privilege design with explicit connection and authorization tests.

Sources:

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Rollback and service objectives: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.

Apply rollback and service objectives in Google Cloud Engineer: Use the concept to complete this role exercise: Specify backup restore, rollout and cost verification steps

Revision rollout and recovery: A new revision needs measurable health and a way to move traffic back. Database changes and queued effects can outlive a revision, so compatibility matters during traffic shifts.

### Rollback and service objectives

A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. In this role, work through: Old and new revisions must understand the data written during a staged rollout. The practical workshop develops this into: Write a staged traffic plan, synthetic request, error threshold and rollback procedure. Compare backup/restore assumptions and cost drivers in the official framework before any paid deployment.

Mental model: A reversible road detour with traffic counters at both ends.

Boundary: A rollback may not undo database changes; release safety includes schema compatibility.

Role application: Changing the clerk does not undo entries already made in the ledger.

A new revision needs measurable health and a way to move traffic back. Database changes and queued effects can outlive a revision, so compatibility matters during traffic shifts.

Worked example: Old and new revisions must understand the data written during a staged rollout.

Shared foundation example: Change the image to a nonexistent tag, inspect events and undo the rollout.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Google Cloud IAM, VPC, Cloud Run, Cloud SQL and Monitoring (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Google Cloud Engineer: Old and new revisions must understand the data written during a staged rollout.

Predict the worked case

Read this case without running a tool: Old and new revisions must understand the data written during a staged rollout. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in rollback and service objectives.

Connect the concept to the role

Apply this rule: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A rollback may not undo database changes; release safety includes schema compatibility.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies rollback and service objectives to this case: Old and new revisions must understand the data written during a staged rollout. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Old and new revisions must understand the data written during a staged rollout. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Rollback and service objectives; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rollback and service objectives. Use the glossary below, then write your prediction for: Old and new revisions must understand the data written during a staged rollout. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Google Cloud Engineer role interview. Explain rollback and service objectives using this case: Old and new revisions must understand the data written during a staged rollout. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rollback and service objectives to a system or workflow you know. Explain rollback and service objectives using this case: Old and new revisions must understand the data written during a staged rollout. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks must pass after undoing a bad image?

Interview: Explain rollback and service objectives using this case: Old and new revisions must understand the data written during a staged rollout. State the evidence, one alternative and where the mental model stops.

Quiz: After the Revision rollout and recovery rehearsal, check this foundation: A rollout undo completes. What additional evidence establishes user recovery?

The deployment command exited zero, so no more checks are needed.

The old image tag exists in the registry.

A representative user operation succeeds and dependent state remains compatible.

Reference: A representative user operation succeeds and dependent state remains compatible. — Control-plane convergence does not verify the business path or reverse external state changes.

Sources:

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Revision rollout and recovery

A new revision needs measurable health and a way to move traffic back. Database changes and queued effects can outlive a revision, so compatibility matters during traffic shifts. In this role, work through: Old and new revisions must understand the data written during a staged rollout. The practical workshop develops this into: Write a staged traffic plan, synthetic request, error threshold and rollback procedure. Compare backup/restore assumptions and cost drivers in the official framework before any paid deployment.

Mental model: Changing the clerk does not undo entries already made in the ledger.

Boundary: Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery.

Worked example: Old and new revisions must understand the data written during a staged rollout.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Google Cloud IAM, VPC, Cloud Run, Cloud SQL and Monitoring (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Google Cloud Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a staged traffic plan, synthetic request, error threshold and rollback procedure. Compare backup/restore assumptions and cost drivers in the official framework before any paid deployment.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Rehearse a failed release

Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

Role workshop · predict

Old and new revisions must understand the data written during a staged rollout. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a staged traffic plan, synthetic request, error threshold and rollback procedure. Compare backup/restore assumptions and cost drivers in the official framework before any paid deployment.

Expected: A revision decision record with data-compatibility and cleanup steps.

Role workshop · debug and verify

Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save GCP rollout and operational readiness pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A revision decision record with data-compatibility and cleanup steps.

Expected: A revision decision record with data-compatibility and cleanup steps.

Troubleshoot: The role exercise differs from the prediction: Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-advanced-2.md: GCP rollout and operational readiness pack; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with revision rollout and recovery. Use the glossary below, then write your prediction for: Old and new revisions must understand the data written during a staged rollout. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Google Cloud Engineer role interview. Explain revision rollout and recovery using this case: Old and new revisions must understand the data written during a staged rollout. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate revision rollout and recovery to a system or workflow you know. Explain revision rollout and recovery using this case: Old and new revisions must understand the data written during a staged rollout. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Rolling traffic back cannot repair a destructive migration; plan expansion and forward recovery.

Interview: Explain revision rollout and recovery using this case: Old and new revisions must understand the data written during a staged rollout. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Old and new revisions must understand the data written during a staged rollout.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A revision decision record with data-compatibility and cleanup steps.

Reference: A revision decision record with data-compatibility and cleanup steps. — A new revision needs measurable health and a way to move traffic back. Database changes and queued effects can outlive a revision, so compatibility matters during traffic shifts. A revision decision record with data-compatibility and cleanup steps.

Sources:

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/
