# Microsoft Fabric Analytics Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Apply keys and constraints in Microsoft Fabric Analytics Engineer: Use the concept to complete this role exercise: Describe the grain and ownership of a lakehouse table

Lakehouse layers and table grain: A lakehouse separates stored data from the transformations and serving models built on it. Define raw, validated and business-ready layers by contracts rather than folder colors.

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. The practical workshop develops this into: Run the local data fixture, draw its mapping to OneLake files and lakehouse tables, then follow the official Fabric lakehouse tutorial in an authorized workspace if available.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: An archive keeps originals, corrected copies and published summaries separately.

A lakehouse separates stored data from the transformations and serving models built on it. Define raw, validated and business-ready layers by contracts rather than folder colors.

Worked example: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Microsoft Fabric, OneLake, notebooks and semantic models (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Microsoft Fabric Analytics Engineer: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30.

Predict the worked case

Read this case without running a tool: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Microsoft Fabric Analytics Engineer role interview. Explain keys and constraints using this case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. State the evidence, one alternative and where the mental model stops.

Quiz: After the Lakehouse layers and table grain rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

Microsoft Fabric: lakehouse tutorial: https://learn.microsoft.com/en-us/fabric/data-engineering/tutorial-lakehouse-introduction

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Lakehouse layers and table grain

A lakehouse separates stored data from the transformations and serving models built on it. Define raw, validated and business-ready layers by contracts rather than folder colors. In this role, work through: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. The practical workshop develops this into: Run the local data fixture, draw its mapping to OneLake files and lakehouse tables, then follow the official Fabric lakehouse tutorial in an authorized workspace if available.

Mental model: An archive keeps originals, corrected copies and published summaries separately.

Boundary: Moving bad rows into another folder does not by itself establish a quality gate.

Worked example: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Microsoft Fabric, OneLake, notebooks and semantic models (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Microsoft Fabric Analytics Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run the local data fixture, draw its mapping to OneLake files and lakehouse tables, then follow the official Fabric lakehouse tutorial in an authorized workspace if available.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run the local data fixture, draw its mapping to OneLake files and lakehouse tables, then follow the official Fabric lakehouse tutorial in an authorized workspace if available.

Expected: A layer contract and reconciled counts; local evidence is labeled as a simulation.

Role workshop · debug and verify

Moving bad rows into another folder does not by itself establish a quality gate. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save lakehouse data contract and layer diagram. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A layer contract and reconciled counts; local evidence is labeled as a simulation.

Expected: A layer contract and reconciled counts; local evidence is labeled as a simulation.

Troubleshoot: The role exercise differs from the prediction: Moving bad rows into another folder does not by itself establish a quality gate.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: lakehouse data contract and layer diagram; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with lakehouse layers and table grain. Use the glossary below, then write your prediction for: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Microsoft Fabric Analytics Engineer role interview. Explain lakehouse layers and table grain using this case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate lakehouse layers and table grain to a system or workflow you know. Explain lakehouse layers and table grain using this case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Moving bad rows into another folder does not by itself establish a quality gate.

Interview: Explain lakehouse layers and table grain using this case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30.

A layer contract and reconciled counts; local evidence is labeled as a simulation.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A layer contract and reconciled counts; local evidence is labeled as a simulation. — A lakehouse separates stored data from the transformations and serving models built on it. Define raw, validated and business-ready layers by contracts rather than folder colors. A layer contract and reconciled counts; local evidence is labeled as a simulation.

Sources:

Microsoft Fabric: lakehouse tutorial: https://learn.microsoft.com/en-us/fabric/data-engineering/tutorial-lakehouse-introduction

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Apply idempotent processing in Microsoft Fabric Analytics Engineer: Use the concept to complete this role exercise: Define tested transformations and a shared metric contract

Semantic model consistency: A shared semantic model should define relationships, grain and metrics so reports agree. Storage success does not prove a correct measure.

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: Paid revenue excludes canceled orders and must not double after joining customer data. The practical workshop develops this into: Create a three-order fixture, define the revenue measure and test a duplicate customer key. In Fabric, build the model following official guidance and compare the measure with a source SQL calculation.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: Different scoreboards should use the same rulebook.

A shared semantic model should define relationships, grain and metrics so reports agree. Storage success does not prove a correct measure.

Worked example: Paid revenue excludes canceled orders and must not double after joining customer data.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Microsoft Fabric, OneLake, notebooks and semantic models (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Microsoft Fabric Analytics Engineer: Paid revenue excludes canceled orders and must not double after joining customer data.

Predict the worked case

Read this case without running a tool: Paid revenue excludes canceled orders and must not double after joining customer data. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: Paid revenue excludes canceled orders and must not double after joining customer data. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Paid revenue excludes canceled orders and must not double after joining customer data. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: Paid revenue excludes canceled orders and must not double after joining customer data. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Microsoft Fabric Analytics Engineer role interview. Explain idempotent processing using this case: Paid revenue excludes canceled orders and must not double after joining customer data. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: Paid revenue excludes canceled orders and must not double after joining customer data. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: Paid revenue excludes canceled orders and must not double after joining customer data. State the evidence, one alternative and where the mental model stops.

Quiz: After the Semantic model consistency rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

Microsoft Fabric: lakehouse tutorial: https://learn.microsoft.com/en-us/fabric/data-engineering/tutorial-lakehouse-introduction

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Semantic model consistency

A shared semantic model should define relationships, grain and metrics so reports agree. Storage success does not prove a correct measure. In this role, work through: Paid revenue excludes canceled orders and must not double after joining customer data. The practical workshop develops this into: Create a three-order fixture, define the revenue measure and test a duplicate customer key. In Fabric, build the model following official guidance and compare the measure with a source SQL calculation.

Mental model: Different scoreboards should use the same rulebook.

Boundary: A many-to-many relationship can multiply values; inspect cardinality before editing the visual.

Worked example: Paid revenue excludes canceled orders and must not double after joining customer data.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Microsoft Fabric, OneLake, notebooks and semantic models (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Microsoft Fabric Analytics Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a three-order fixture, define the revenue measure and test a duplicate customer key. In Fabric, build the model following official guidance and compare the measure with a source SQL calculation.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Paid revenue excludes canceled orders and must not double after joining customer data. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a three-order fixture, define the revenue measure and test a duplicate customer key. In Fabric, build the model following official guidance and compare the measure with a source SQL calculation.

Expected: The metric reconciles and relationship assumptions are documented.

Role workshop · debug and verify

A many-to-many relationship can multiply values; inspect cardinality before editing the visual. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save semantic model specification and metric tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The metric reconciles and relationship assumptions are documented.

Expected: The metric reconciles and relationship assumptions are documented.

Troubleshoot: The role exercise differs from the prediction: A many-to-many relationship can multiply values; inspect cardinality before editing the visual.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: semantic model specification and metric tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with semantic model consistency. Use the glossary below, then write your prediction for: Paid revenue excludes canceled orders and must not double after joining customer data. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Microsoft Fabric Analytics Engineer role interview. Explain semantic model consistency using this case: Paid revenue excludes canceled orders and must not double after joining customer data. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate semantic model consistency to a system or workflow you know. Explain semantic model consistency using this case: Paid revenue excludes canceled orders and must not double after joining customer data. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A many-to-many relationship can multiply values; inspect cardinality before editing the visual.

Interview: Explain semantic model consistency using this case: Paid revenue excludes canceled orders and must not double after joining customer data. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Paid revenue excludes canceled orders and must not double after joining customer data.

Ignore the failing case and keep only the successful screenshot.

The metric reconciles and relationship assumptions are documented.

Treat any successful command as proof that all business and access rules passed.

Reference: The metric reconciles and relationship assumptions are documented. — A shared semantic model should define relationships, grain and metrics so reports agree. Storage success does not prove a correct measure. The metric reconciles and relationship assumptions are documented.

Sources:

Microsoft Fabric: lakehouse tutorial: https://learn.microsoft.com/en-us/fabric/data-engineering/tutorial-lakehouse-introduction

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Apply transaction and recovery in Microsoft Fabric Analytics Engineer: Use the concept to complete this role exercise: Design lineage, capacity monitoring, access and deployment review

Capacity, lineage and promotion: Shared capacity and workspace access are operational constraints. Track data lineage and environment configuration before promoting changes that downstream reports depend on.

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: A changed order field can break a downstream semantic model despite a successful notebook run. The practical workshop develops this into: Build an impact graph, deployment checklist and capacity observation plan. Test a schema-change fixture locally; record actual workspace tests separately and clean up only lab items.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: A shared workshop needs scheduling, access rules and a record of which machine produced each part.

Shared capacity and workspace access are operational constraints. Track data lineage and environment configuration before promoting changes that downstream reports depend on.

Worked example: A changed order field can break a downstream semantic model despite a successful notebook run.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Microsoft Fabric, OneLake, notebooks and semantic models (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Microsoft Fabric Analytics Engineer: A changed order field can break a downstream semantic model despite a successful notebook run.

Predict the worked case

Read this case without running a tool: A changed order field can break a downstream semantic model despite a successful notebook run. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: A changed order field can break a downstream semantic model despite a successful notebook run. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A changed order field can break a downstream semantic model despite a successful notebook run. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: A changed order field can break a downstream semantic model despite a successful notebook run. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Microsoft Fabric Analytics Engineer role interview. Explain transaction and recovery using this case: A changed order field can break a downstream semantic model despite a successful notebook run. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: A changed order field can break a downstream semantic model despite a successful notebook run. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: A changed order field can break a downstream semantic model despite a successful notebook run. State the evidence, one alternative and where the mental model stops.

Quiz: After the Capacity, lineage and promotion rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

Microsoft Fabric: lakehouse tutorial: https://learn.microsoft.com/en-us/fabric/data-engineering/tutorial-lakehouse-introduction

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Capacity, lineage and promotion

Shared capacity and workspace access are operational constraints. Track data lineage and environment configuration before promoting changes that downstream reports depend on. In this role, work through: A changed order field can break a downstream semantic model despite a successful notebook run. The practical workshop develops this into: Build an impact graph, deployment checklist and capacity observation plan. Test a schema-change fixture locally; record actual workspace tests separately and clean up only lab items.

Mental model: A shared workshop needs scheduling, access rules and a record of which machine produced each part.

Boundary: A successful ingestion status is not end-to-end report validation.

Worked example: A changed order field can break a downstream semantic model despite a successful notebook run.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Microsoft Fabric, OneLake, notebooks and semantic models (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Microsoft Fabric Analytics Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Build an impact graph, deployment checklist and capacity observation plan. Test a schema-change fixture locally; record actual workspace tests separately and clean up only lab items.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A changed order field can break a downstream semantic model despite a successful notebook run. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Build an impact graph, deployment checklist and capacity observation plan. Test a schema-change fixture locally; record actual workspace tests separately and clean up only lab items.

Expected: A blocked incompatible change and a documented promotion/recovery route.

Role workshop · debug and verify

A successful ingestion status is not end-to-end report validation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Fabric operational review and lineage pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A blocked incompatible change and a documented promotion/recovery route.

Expected: A blocked incompatible change and a documented promotion/recovery route.

Troubleshoot: The role exercise differs from the prediction: A successful ingestion status is not end-to-end report validation.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: Fabric operational review and lineage pack; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with capacity, lineage and promotion. Use the glossary below, then write your prediction for: A changed order field can break a downstream semantic model despite a successful notebook run. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Microsoft Fabric Analytics Engineer role interview. Explain capacity, lineage and promotion using this case: A changed order field can break a downstream semantic model despite a successful notebook run. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate capacity, lineage and promotion to a system or workflow you know. Explain capacity, lineage and promotion using this case: A changed order field can break a downstream semantic model despite a successful notebook run. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful ingestion status is not end-to-end report validation.

Interview: Explain capacity, lineage and promotion using this case: A changed order field can break a downstream semantic model despite a successful notebook run. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A changed order field can break a downstream semantic model despite a successful notebook run.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A blocked incompatible change and a documented promotion/recovery route.

Reference: A blocked incompatible change and a documented promotion/recovery route. — Shared capacity and workspace access are operational constraints. Track data lineage and environment configuration before promoting changes that downstream reports depend on. A blocked incompatible change and a documented promotion/recovery route.

Sources:

Microsoft Fabric: lakehouse tutorial: https://learn.microsoft.com/en-us/fabric/data-engineering/tutorial-lakehouse-introduction

Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
