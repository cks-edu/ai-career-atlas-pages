# Microsoft Fabric Analytics Engineer

Software Engineering

Start with lakehouse layers and table grain. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward Fabric operational review and lineage pack.

## beginner

Run the local data fixture, draw its mapping to OneLake files and lakehouse tables, then follow the official Fabric lakehouse tutorial in an authorized workspace if available.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Lakehouse layers and table grain
A lakehouse separates stored data from the transformations and serving models built on it. Define raw, validated and business-ready layers by contracts rather than folder colors.
Mental model: An archive keeps originals, corrected copies and published summaries separately.
Limit: Moving bad rows into another folder does not by itself establish a quality gate.
Example: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Moving bad rows into another folder does not by itself establish a quality gate.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run the local data fixture, draw its mapping to OneLake files and lakehouse tables, then follow the official Fabric lakehouse tutorial in an authorized workspace if available.
Expected: A layer contract and reconciled counts; local evidence is labeled as a simulation.

6. Role workshop · debug and verify
Moving bad rows into another folder does not by itself establish a quality gate. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save lakehouse data contract and layer diagram. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A layer contract and reconciled counts; local evidence is labeled as a simulation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Lakehouse layers and table grain: Moving bad rows into another folder does not by itself establish a quality gate.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: lakehouse data contract and layer diagram
A layer contract and reconciled counts; local evidence is labeled as a simulation.

Interview: Work through this Microsoft Fabric Analytics Engineer case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A lakehouse separates stored data from the transformations and serving models built on it. Define raw, validated and business-ready layers by contracts rather than folder colors. Expected evidence: A layer contract and reconciled counts; local evidence is labeled as a simulation. Diagnosis: Moving bad rows into another folder does not by itself establish a quality gate. State the limits of the mental model: An archive keeps originals, corrected copies and published summaries separately.

Resume: Built lakehouse data contract and layer diagram using Microsoft Fabric, OneLake, notebooks and semantic models; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create a three-order fixture, define the revenue measure and test a duplicate customer key. In Fabric, build the model following official guidance and compare the measure with a source SQL calculation.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Semantic model consistency
A shared semantic model should define relationships, grain and metrics so reports agree. Storage success does not prove a correct measure.
Mental model: Different scoreboards should use the same rulebook.
Limit: A many-to-many relationship can multiply values; inspect cardinality before editing the visual.
Example: Paid revenue excludes canceled orders and must not double after joining customer data.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A many-to-many relationship can multiply values; inspect cardinality before editing the visual.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Paid revenue excludes canceled orders and must not double after joining customer data. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a three-order fixture, define the revenue measure and test a duplicate customer key. In Fabric, build the model following official guidance and compare the measure with a source SQL calculation.
Expected: The metric reconciles and relationship assumptions are documented.

6. Role workshop · debug and verify
A many-to-many relationship can multiply values; inspect cardinality before editing the visual. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save semantic model specification and metric tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The metric reconciles and relationship assumptions are documented.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Semantic model consistency: A many-to-many relationship can multiply values; inspect cardinality before editing the visual.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: semantic model specification and metric tests
The metric reconciles and relationship assumptions are documented.

Interview: Work through this Microsoft Fabric Analytics Engineer case: Paid revenue excludes canceled orders and must not double after joining customer data. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A shared semantic model should define relationships, grain and metrics so reports agree. Storage success does not prove a correct measure. Expected evidence: The metric reconciles and relationship assumptions are documented. Diagnosis: A many-to-many relationship can multiply values; inspect cardinality before editing the visual. State the limits of the mental model: Different scoreboards should use the same rulebook.

Resume: Built semantic model specification and metric tests using Microsoft Fabric, OneLake, notebooks and semantic models; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Build an impact graph, deployment checklist and capacity observation plan. Test a schema-change fixture locally; record actual workspace tests separately and clean up only lab items.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Capacity, lineage and promotion
Shared capacity and workspace access are operational constraints. Track data lineage and environment configuration before promoting changes that downstream reports depend on.
Mental model: A shared workshop needs scheduling, access rules and a record of which machine produced each part.
Limit: A successful ingestion status is not end-to-end report validation.
Example: A changed order field can break a downstream semantic model despite a successful notebook run.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful ingestion status is not end-to-end report validation.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A changed order field can break a downstream semantic model despite a successful notebook run. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Build an impact graph, deployment checklist and capacity observation plan. Test a schema-change fixture locally; record actual workspace tests separately and clean up only lab items.
Expected: A blocked incompatible change and a documented promotion/recovery route.

6. Role workshop · debug and verify
A successful ingestion status is not end-to-end report validation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Fabric operational review and lineage pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A blocked incompatible change and a documented promotion/recovery route.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Capacity, lineage and promotion: A successful ingestion status is not end-to-end report validation.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Fabric operational review and lineage pack
A blocked incompatible change and a documented promotion/recovery route.

Interview: Work through this Microsoft Fabric Analytics Engineer case: A changed order field can break a downstream semantic model despite a successful notebook run. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Shared capacity and workspace access are operational constraints. Track data lineage and environment configuration before promoting changes that downstream reports depend on. Expected evidence: A blocked incompatible change and a documented promotion/recovery route. Diagnosis: A successful ingestion status is not end-to-end report validation. State the limits of the mental model: A shared workshop needs scheduling, access rules and a record of which machine produced each part.

Resume: Built Fabric operational review and lineage pack using Microsoft Fabric, OneLake, notebooks and semantic models; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Microsoft Learn: data engineer career path: https://learn.microsoft.com/en-us/training/career-paths/data-engineer
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
Microsoft Fabric: lakehouse tutorial: https://learn.microsoft.com/en-us/fabric/data-engineering/tutorial-lakehouse-introduction
