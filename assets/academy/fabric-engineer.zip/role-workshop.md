# Microsoft Fabric Analytics Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Lakehouse layers and table grain

A lakehouse separates stored data from the transformations and serving models built on it. Define raw, validated and business-ready layers by contracts rather than folder colors.
Mental model: An archive keeps originals, corrected copies and published summaries separately.
Case: Raw orders include a duplicate and negative amount; the curated table has two accepted unique orders totaling 30.
Task: Run the local data fixture, draw its mapping to OneLake files and lakehouse tables, then follow the official Fabric lakehouse tutorial in an authorized workspace if available.
Acceptance: A layer contract and reconciled counts; local evidence is labeled as a simulation.
Troubleshooting: Moving bad rows into another folder does not by itself establish a quality gate.
Deliverable: lakehouse data contract and layer diagram

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Semantic model consistency

A shared semantic model should define relationships, grain and metrics so reports agree. Storage success does not prove a correct measure.
Mental model: Different scoreboards should use the same rulebook.
Case: Paid revenue excludes canceled orders and must not double after joining customer data.
Task: Create a three-order fixture, define the revenue measure and test a duplicate customer key. In Fabric, build the model following official guidance and compare the measure with a source SQL calculation.
Acceptance: The metric reconciles and relationship assumptions are documented.
Troubleshooting: A many-to-many relationship can multiply values; inspect cardinality before editing the visual.
Deliverable: semantic model specification and metric tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Capacity, lineage and promotion

Shared capacity and workspace access are operational constraints. Track data lineage and environment configuration before promoting changes that downstream reports depend on.
Mental model: A shared workshop needs scheduling, access rules and a record of which machine produced each part.
Case: A changed order field can break a downstream semantic model despite a successful notebook run.
Task: Build an impact graph, deployment checklist and capacity observation plan. Test a schema-change fixture locally; record actual workspace tests separately and clean up only lab items.
Acceptance: A blocked incompatible change and a documented promotion/recovery route.
Troubleshooting: A successful ingestion status is not end-to-end report validation.
Deliverable: Fabric operational review and lineage pack

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
