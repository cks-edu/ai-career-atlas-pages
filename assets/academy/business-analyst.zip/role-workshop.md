# Technical Business Analyst — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Acceptance criteria and process boundaries

A requirement explains a user need; acceptance criteria make completion observable. Separate current workflow, proposed workflow and assumptions requiring stakeholder confirmation.
Mental model: A map shows both the destination and the checkpoints needed to know you arrived.
Case: A service request cannot be approved by its own requester in this fictional policy.
Task: Draw requester → reviewer → fulfillment, assign owners and write Given/When/Then cases for valid approval and self-approval. Label the segregation rule as the exercise policy.
Acceptance: Two testable cases with no invented stakeholder signoff.
Troubleshooting: Words such as fast or easy need measurable context before they become acceptance criteria.
Deliverable: process map and requirements register

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Traceability and edge cases

Trace a requirement to its tests and affected roles so a change has visible consequences. Include missing data and exceptions rather than documenting only the happy path.
Mental model: A labeled wire connects each switch to the lamp it controls.
Case: Changing the approval threshold affects both the routing rule and boundary-value tests.
Task: Create IDs R1–R5, link each to a test, then change one fictional threshold from 100 to 200. Update cases at 99,100,199,200 and record which roles must review.
Acceptance: Every changed rule has updated tests and an owner.
Troubleshooting: An orphan requirement or unlinked test indicates a traceability gap.
Deliverable: requirements-to-tests matrix

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Change impact and decision evidence

A change affects process, reporting, access and support work. A recommendation should identify benefits, costs, unknowns and conditions for acceptance.
Mental model: Moving one junction can change every route through it.
Case: A faster approval process may increase unauthorized approvals unless role checks remain.
Task: Write an impact table for the threshold change, compare two options and recommend one with a pilot, metrics and rollback. Include a sample decision log clearly marked fictional.
Acceptance: A reviewable decision with explicit unresolved questions.
Troubleshooting: A completed template is not actual stakeholder approval; keep proposed and obtained signoffs separate.
Deliverable: change assessment and decision pack

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
