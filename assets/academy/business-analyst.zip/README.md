# Technical Business Analyst

Software Engineering

Start with acceptance criteria and process boundaries. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward change assessment and decision pack.

## beginner

Draw requester → reviewer → fulfillment, assign owners and write Given/When/Then cases for valid approval and self-approval. Label the segregation rule as the exercise policy.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Acceptance criteria and process boundaries
A requirement explains a user need; acceptance criteria make completion observable. Separate current workflow, proposed workflow and assumptions requiring stakeholder confirmation.
Mental model: A map shows both the destination and the checkpoints needed to know you arrived.
Limit: Words such as fast or easy need measurable context before they become acceptance criteria.
Example: A service request cannot be approved by its own requester in this fictional policy.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Words such as fast or easy need measurable context before they become acceptance criteria.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A service request cannot be approved by its own requester in this fictional policy. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Draw requester → reviewer → fulfillment, assign owners and write Given/When/Then cases for valid approval and self-approval. Label the segregation rule as the exercise policy.
Expected: Two testable cases with no invented stakeholder signoff.

6. Role workshop · debug and verify
Words such as fast or easy need measurable context before they become acceptance criteria. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save process map and requirements register. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Two testable cases with no invented stakeholder signoff.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Acceptance criteria and process boundaries: Words such as fast or easy need measurable context before they become acceptance criteria.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: process map and requirements register
Two testable cases with no invented stakeholder signoff.

Interview: Work through this Technical Business Analyst case: A service request cannot be approved by its own requester in this fictional policy. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A requirement explains a user need; acceptance criteria make completion observable. Separate current workflow, proposed workflow and assumptions requiring stakeholder confirmation. Expected evidence: Two testable cases with no invented stakeholder signoff. Diagnosis: Words such as fast or easy need measurable context before they become acceptance criteria. State the limits of the mental model: A map shows both the destination and the checkpoints needed to know you arrived.

Resume: Built process map and requirements register using Markdown and spreadsheet requirements workbook; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create IDs R1–R5, link each to a test, then change one fictional threshold from 100 to 200. Update cases at 99,100,199,200 and record which roles must review.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Traceability and edge cases
Trace a requirement to its tests and affected roles so a change has visible consequences. Include missing data and exceptions rather than documenting only the happy path.
Mental model: A labeled wire connects each switch to the lamp it controls.
Limit: An orphan requirement or unlinked test indicates a traceability gap.
Example: Changing the approval threshold affects both the routing rule and boundary-value tests.
Recall: Explain the expected result before running the exercise, then diagnose this failure: An orphan requirement or unlinked test indicates a traceability gap.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
Changing the approval threshold affects both the routing rule and boundary-value tests. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create IDs R1–R5, link each to a test, then change one fictional threshold from 100 to 200. Update cases at 99,100,199,200 and record which roles must review.
Expected: Every changed rule has updated tests and an owner.

6. Role workshop · debug and verify
An orphan requirement or unlinked test indicates a traceability gap. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save requirements-to-tests matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Every changed rule has updated tests and an owner.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Traceability and edge cases: An orphan requirement or unlinked test indicates a traceability gap.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: requirements-to-tests matrix
Every changed rule has updated tests and an owner.

Interview: Work through this Technical Business Analyst case: Changing the approval threshold affects both the routing rule and boundary-value tests. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Trace a requirement to its tests and affected roles so a change has visible consequences. Include missing data and exceptions rather than documenting only the happy path. Expected evidence: Every changed rule has updated tests and an owner. Diagnosis: An orphan requirement or unlinked test indicates a traceability gap. State the limits of the mental model: A labeled wire connects each switch to the lamp it controls.

Resume: Built requirements-to-tests matrix using Markdown and spreadsheet requirements workbook; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write an impact table for the threshold change, compare two options and recommend one with a pilot, metrics and rollback. Include a sample decision log clearly marked fictional.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Change impact and decision evidence
A change affects process, reporting, access and support work. A recommendation should identify benefits, costs, unknowns and conditions for acceptance.
Mental model: Moving one junction can change every route through it.
Limit: A completed template is not actual stakeholder approval; keep proposed and obtained signoffs separate.
Example: A faster approval process may increase unauthorized approvals unless role checks remain.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A completed template is not actual stakeholder approval; keep proposed and obtained signoffs separate.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A faster approval process may increase unauthorized approvals unless role checks remain. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write an impact table for the threshold change, compare two options and recommend one with a pilot, metrics and rollback. Include a sample decision log clearly marked fictional.
Expected: A reviewable decision with explicit unresolved questions.

6. Role workshop · debug and verify
A completed template is not actual stakeholder approval; keep proposed and obtained signoffs separate. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save change assessment and decision pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A reviewable decision with explicit unresolved questions.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Change impact and decision evidence: A completed template is not actual stakeholder approval; keep proposed and obtained signoffs separate.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: change assessment and decision pack
A reviewable decision with explicit unresolved questions.

Interview: Work through this Technical Business Analyst case: A faster approval process may increase unauthorized approvals unless role checks remain. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A change affects process, reporting, access and support work. A recommendation should identify benefits, costs, unknowns and conditions for acceptance. Expected evidence: A reviewable decision with explicit unresolved questions. Diagnosis: A completed template is not actual stakeholder approval; keep proposed and obtained signoffs separate. State the limits of the mental model: Moving one junction can change every route through it.

Resume: Built change assessment and decision pack using Markdown and spreadsheet requirements workbook; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
SAP Learning Journeys: https://learning.sap.com/learning-journeys
