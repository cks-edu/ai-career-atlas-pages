import json
manifest={'apiVersion':'apps/v1','kind':'Deployment','metadata':{'name':'learning-web','namespace':'skillbadi-lab'},'spec':{'replicas':1,'selector':{'matchLabels':{'app':'learning-web'}},'template':{'metadata':{'labels':{'app':'learning-web'}},'spec':{'containers':[{'name':'web','image':'nginx:stable','ports':[{'containerPort':80}]}]}}}}
assert manifest['spec']['selector']['matchLabels']==manifest['spec']['template']['metadata']['labels']
print(json.dumps(manifest,indent=2))
