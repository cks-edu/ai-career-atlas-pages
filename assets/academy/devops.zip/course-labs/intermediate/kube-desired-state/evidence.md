# Kubernetes: describe desired state and inspect observed state

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://kubernetes.io/docs/tutorials/kubernetes-basics/
https://kind.sigs.k8s.io/docs/user/quick-start/
