def probes(process_alive,ready_dependency):
 return {'live':process_alive,'ready':process_alive and ready_dependency}
assert probes(True,False)=={'live':True,'ready':False}
assert probes(False,True)=={'live':False,'ready':False}
print('PASS: dependency outage does not automatically imply dead process')
