# CI: make a failing check block the pipeline

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://docs.github.com/en/actions/reference/security/secure-use
https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-jobs
