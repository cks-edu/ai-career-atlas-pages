import subprocess,sys
command=[sys.executable,'-c','assert 2+2==4']
assert subprocess.run(command,check=False).returncode==0
broken=[sys.executable,'-c','assert 2+2==5']
assert subprocess.run(broken,check=False,capture_output=True).returncode!=0
print('PASS: broken check returns pipeline failure status')
