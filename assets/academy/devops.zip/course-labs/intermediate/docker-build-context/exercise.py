from pathlib import Path
from tempfile import TemporaryDirectory
text='FROM python:3.12-slim\nWORKDIR /app\nUSER 10001:10001\nCMD ["python","-c","print(42)"]\n'
with TemporaryDirectory() as folder:
 path=Path(folder)/'Dockerfile';path.write_text(text)
 assert 'USER 10001:10001' in path.read_text()
 assert 'COPY . .' not in text
 print(text)
