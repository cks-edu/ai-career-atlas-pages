# Infrastructure plans: review destructive intent

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://opentofu.org/docs/language/state/
https://opentofu.org/docs/intro/install/
