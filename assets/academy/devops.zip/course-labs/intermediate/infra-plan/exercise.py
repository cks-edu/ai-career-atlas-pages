changes=[{'name':'learning-vm','actions':['update']},{'name':'learning-db','actions':['delete','create']}]
needs_review=lambda change:'delete' in change['actions']
assert not needs_review(changes[0])
assert needs_review(changes[1])
print('Review required:',[c['name'] for c in changes if needs_review(c)])
