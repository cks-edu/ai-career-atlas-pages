eligible=100000
bad=75
permitted=eligible*(1-0.999)
remaining=permitted-bad
assert round(permitted)==100
assert round(remaining)==25
print('Request budget remaining:',round(remaining))
