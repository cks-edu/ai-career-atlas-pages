def gate(base_errors,base_n,new_errors,new_n):
 if min(base_n,new_n)<100: return 'wait'
 return 'investigate' if new_errors/new_n-base_errors/base_n>0.01 else 'promote'
assert gate(1,1000,0,2)=='wait'
assert gate(1,1000,30,1000)=='investigate'
assert gate(1,1000,2,1000)=='promote'
print('PASS: insufficient, degraded and acceptable example windows')
