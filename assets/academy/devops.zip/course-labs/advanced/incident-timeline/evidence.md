# Incidents: separate observations from hypotheses

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://sre.google/sre-book/monitoring-distributed-systems/
https://opentelemetry.io/docs/concepts/observability-primer/
