events=[{'t':30,'kind':'recovery','note':'error rate normal'},{'t':10,'kind':'observation','note':'5xx elevated'},{'t':20,'kind':'mitigation','note':'reverted candidate'}]
ordered=sorted(events,key=lambda e:e['t'])
assert [e['kind'] for e in ordered]==['observation','mitigation','recovery']
assert all('password' not in e['note'] for e in ordered)
print(' -> '.join(e['kind'] for e in ordered))
