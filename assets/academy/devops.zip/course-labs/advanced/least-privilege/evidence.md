# Delivery security: minimise permissions and secret exposure

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://docs.github.com/en/actions/reference/security/secure-use
https://docs.github.com/en/actions/concepts/security/openid-connect
