def review(permissions):
 return [name for name,value in permissions.items() if value=='write' and name not in {'id-token'}]
assert review({'contents':'read','id-token':'write'})==[]
assert review({'contents':'write','packages':'write'})==['contents','packages']
print('PASS: teaching policy flags broad write grants for review')
