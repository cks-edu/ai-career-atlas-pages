supported={'v1':{'old','expanded'},'v2':{'expanded','new'}}
assert 'expanded' in supported['v1'] & supported['v2']
assert 'new' not in supported['v1']
print('PASS: expanded schema supports a mixed-version window; new-only does not')
