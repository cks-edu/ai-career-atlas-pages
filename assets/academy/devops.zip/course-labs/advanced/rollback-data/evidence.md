# Rollback: application and data versions differ

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://kubernetes.io/docs/concepts/workloads/controllers/deployment/
https://www.postgresql.org/docs/current/tutorial.html
