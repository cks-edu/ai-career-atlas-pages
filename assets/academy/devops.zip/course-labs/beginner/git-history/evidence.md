# Git: record and inspect one deliberate change

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository
