set -eu
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cd "$work"
git init -q
git config user.name 'Learning Example'
git config user.email 'learning@example.invalid'
printf 'local\n' > app.txt
git add app.txt
git commit -qm 'Add local configuration'
test "$(git rev-list --count HEAD)" = 1
test -z "$(git status --porcelain)"
printf 'PASS: one commit and a clean learning repository\n'
