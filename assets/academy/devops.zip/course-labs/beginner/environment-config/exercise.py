def boolean(value):
 if value=='true': return True
 if value=='false': return False
 raise ValueError('Use true or false')
assert boolean('false') is False
assert boolean('true') is True
try:
 boolean('enabled')
except ValueError:
 print('PASS: explicit booleans and rejected unknown value')
else:
 raise AssertionError('Expected rejection')
