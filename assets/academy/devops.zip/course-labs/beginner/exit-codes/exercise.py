import subprocess,sys
ok=subprocess.run([sys.executable,'-c','print("checked")'],capture_output=True,text=True)
bad=subprocess.run([sys.executable,'-c','raise SystemExit(2)'],capture_output=True,text=True)
assert ok.returncode==0 and ok.stdout.strip()=='checked'
assert bad.returncode==2
print('PASS: success and intentional nonzero exit')
