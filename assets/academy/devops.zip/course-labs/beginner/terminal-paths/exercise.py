from pathlib import Path
from tempfile import TemporaryDirectory
with TemporaryDirectory(prefix='skillbadi-ops-') as folder:
 root=Path(folder)
 target=root/'config'/'app.txt'
 target.parent.mkdir()
 target.write_text('environment=local\n',encoding='utf-8')
 assert target.relative_to(root)==Path('config/app.txt')
 assert target.read_text(encoding='utf-8')=='environment=local\n'
 print('PASS: explicit temporary working tree')
