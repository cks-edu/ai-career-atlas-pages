from http.server import BaseHTTPRequestHandler,HTTPServer
from threading import Thread
from urllib.request import urlopen
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  self.send_response(200 if self.path=='/health' else 404)
  self.end_headers()
  self.wfile.write(b'ok')
 def log_message(self,*args): pass
server=HTTPServer(('127.0.0.1',0),Handler)
thread=Thread(target=server.serve_forever);thread.start()
try:
 with urlopen('http://127.0.0.1:%s/health'%server.server_port,timeout=2) as response:
  assert response.status==200 and response.read()==b'ok'
 print('PASS: real loopback health request')
finally:
 server.shutdown();server.server_close();thread.join()
