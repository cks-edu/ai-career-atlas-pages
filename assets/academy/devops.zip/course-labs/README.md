# DevOps Engineer — core lessons

Begin with files, Git, processes, configuration and an actual local health check. Continue to containers, CI, desired state and probes, then SLOs, progressive delivery, recovery and delivery permissions. Native platform extensions are clearly optional and need their stated environment.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A delivery and recovery portfolio with Git history, a failing CI check, an isolated local platform rehearsal and an incident record.
