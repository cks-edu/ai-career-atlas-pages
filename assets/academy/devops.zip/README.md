# DevOps Engineer

Software Engineering

Start with the numbered Beginner lessons. Each lesson combines explanation, a mental model, guided practice, a checked quiz and source reading. Change the guidance lens to match your goal; core concepts remain the same. Existing labs and projects remain available in their tabs.

## beginner

Write a GitHub Actions workflow for the local reference with checkout, supported Node setup and test jobs. Make packaging depend on tests, then deliberately break one assertion in a branch.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### Pipeline dependency gates
A release pipeline represents dependencies between checks, packaging and deployment. A failed prerequisite must prevent publication of an unverified artifact.
Mental model: An assembly line stops shipment when inspection fails.
Limit: Parallel jobs without needs can publish before tests finish; inspect the dependency graph.
Example: A failing title test must block the package job.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Parallel jobs without needs can publish before tests finish; inspect the dependency graph.

### Processes, ports and HTTP evidence
A process runs a program; a listening port accepts connections. Follow a request from the client through the listener and application before changing configuration.
Mental model: A port is a numbered door; a process is the worker behind it; an HTTP status is the worker’s reply.
Limit: A successful connection does not prove the business response is correct.
Example: Connection refused, HTTP 404 and HTTP 500 suggest different boundaries. Capture the exact error before restarting anything.
Recall: How would you distinguish an unreachable listener from a wrong URL?

### Git changes and container boundaries
Git records source changes. A container starts a process from an image with isolated resources; it shares the host kernel. Inspect the exact diff and runtime configuration.
Mental model: An image is a packaged recipe; a container is one running instance using it.
Limit: Containers are not complete virtual machines, and isolation is not a substitute for least privilege.
Example: Inspect a diff before committing. Publish a web container only on 127.0.0.1 for a local exercise; remove only that named container afterwards.
Recall: Why can two containers from one image behave differently?

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
A failing title test must block the package job. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a GitHub Actions workflow for the local reference with checkout, supported Node setup and test jobs. Make packaging depend on tests, then deliberately break one assertion in a branch.
Expected: The failed test blocks the dependent job; repair restores the pipeline.

6. Role workshop · debug and verify
Parallel jobs without needs can publish before tests finish; inspect the dependency graph. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save workflow YAML and failed/passing run evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The failed test blocks the dependent job; repair restores the pipeline.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Pipeline dependency gates: Parallel jobs without needs can publish before tests finish; inspect the dependency graph.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: workflow YAML and failed/passing run evidence
The failed test blocks the dependent job; repair restores the pipeline.

Interview: Work through this DevOps Engineer case: A failing title test must block the package job. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A release pipeline represents dependencies between checks, packaging and deployment. A failed prerequisite must prevent publication of an unverified artifact. Expected evidence: The failed test blocks the dependent job; repair restores the pipeline. Diagnosis: Parallel jobs without needs can publish before tests finish; inspect the dependency graph. State the limits of the mental model: An assembly line stops shipment when inspection fails.

Resume: Built workflow YAML and failed/passing run evidence using GitHub Actions and Docker; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Build a local container, record its image ID/digest, create an environment manifest and compare it with a second build. Write the promotion record with source revision and test result.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Immutable promotion
Identify artifacts by content digest and separate configuration from the build. Rebuilding the same tag for another environment produces a different artifact with weaker provenance.
Mental model: A sealed parcel keeps the same serial number as it moves between depots.
Limit: A mutable latest tag is not enough to prove what was tested; resolve and record the digest.
Example: The digest tested in staging must equal the digest proposed for release.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A mutable latest tag is not enough to prove what was tested; resolve and record the digest.

### Infrastructure plans and state
OpenTofu compares configuration, recorded state and provider observations to propose changes. Review a saved plan and protect state because it can contain sensitive values.
Mental model: Configuration is the intended map; state connects map entries to actual resources; a plan is the proposed edit list.
Limit: A plan is time-sensitive, and state is not a backup of the actual service data.
Example: A local terraform_data resource demonstrates create versus no-change plans without cloud credentials. Remote collaboration additionally requires access controls, locking and recovery.
Recall: Why should a state file not be committed to a public repository?

### Short-lived identity in deployment pipelines
OIDC lets a trusted workflow request a short-lived cloud identity. Scope the trust policy to the repository, environment and permitted subject; separately restrict what that identity can do.
Mental model: A temporary badge grants entry only through an explicitly trusted issuer and door.
Limit: Short lifetime does not make overly broad authorization safe.
Example: A production deployment job requests id-token: write and contents: read; the cloud trust policy restricts the subject and production environment approval.
Recall: Which two policies matter even when no long-lived cloud key is stored?

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
The digest tested in staging must equal the digest proposed for release. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Build a local container, record its image ID/digest, create an environment manifest and compare it with a second build. Write the promotion record with source revision and test result.
Expected: A trace from source to tested artifact to deployment configuration.

6. Role workshop · debug and verify
A mutable latest tag is not enough to prove what was tested; resolve and record the digest. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save artifact manifest and promotion checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A trace from source to tested artifact to deployment configuration.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Immutable promotion: A mutable latest tag is not enough to prove what was tested; resolve and record the digest.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: artifact manifest and promotion checklist
A trace from source to tested artifact to deployment configuration.

Interview: Work through this DevOps Engineer case: The digest tested in staging must equal the digest proposed for release. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Identify artifacts by content digest and separate configuration from the build. Rebuilding the same tag for another environment produces a different artifact with weaker provenance. Expected evidence: A trace from source to tested artifact to deployment configuration. Diagnosis: A mutable latest tag is not enough to prove what was tested; resolve and record the digest. State the limits of the mental model: A sealed parcel keeps the same serial number as it moves between depots.

Resume: Built artifact manifest and promotion checklist using GitHub Actions and Docker; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run the supplied kind failure rehearsal, record events before undo, then verify the endpoint after recovery. Add a separate decision for incompatible database changes.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Deployment recovery gates
A rollout needs an observation window and a user-visible verification. Undoing a Deployment changes its Pod template but does not reverse external data effects.
Mental model: A detour has a return route, but deliveries already made remain delivered.
Limit: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior.
Example: A nonexistent image produces an image-pull failure and a healthy prior replica may remain serving.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior.

### Service signals and error-budget decisions
Measure user-visible success, latency and traffic. Define the eligible population and time window before calculating a service-level indicator. Alert on actionable symptoms.
Mental model: An SLO is a service promise with a limited error allowance, not a dashboard decoration.
Limit: A tiny or biased sample can produce misleading percentages; a single metric cannot establish root cause.
Example: With 10,000 eligible requests and 50 failures, success is 99.5%. Against a 99.9% objective, the allowed failures are 10, so consumption is five times that allowance.
Recall: Why is a Pod count insufficient to decide whether users are affected?

### Recovery drills and platform guardrails
Rehearse restoring service and data in an isolated environment. Measure recovery time and the recoverable data point. Encode safe defaults but retain visibility and escape procedures.
Mental model: A recovery runbook is a fire drill: a written exit route is useful only when people can follow it.
Limit: A successful local drill does not prove regional failover, cloud permissions or production capacity.
Example: Restore a disposable copy, verify record counts and checksums, then run a business request. Record elapsed time and the last recovered transaction.
Recall: What distinguishes a verified restore from simply possessing a backup?

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Role workshop · predict
A nonexistent image produces an image-pull failure and a healthy prior replica may remain serving. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run the supplied kind failure rehearsal, record events before undo, then verify the endpoint after recovery. Add a separate decision for incompatible database changes.
Expected: Healthy rollout and successful HTTP response after recovery; incident timeline preserved.

6. Role workshop · debug and verify
Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save release runbook and rollback evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Healthy rollout and successful HTTP response after recovery; incident timeline preserved.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Deployment recovery gates: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: release runbook and rollback evidence
Healthy rollout and successful HTTP response after recovery; incident timeline preserved.

Interview: Work through this DevOps Engineer case: A nonexistent image produces an image-pull failure and a healthy prior replica may remain serving. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A rollout needs an observation window and a user-visible verification. Undoing a Deployment changes its Pod template but does not reverse external data effects. Expected evidence: Healthy rollout and successful HTTP response after recovery; incident timeline preserved. Diagnosis: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior. State the limits of the mental model: A detour has a return route, but deliveries already made remain delivered.

Resume: Built release runbook and rollback evidence using GitHub Actions and Docker; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
Google SRE book: https://sre.google/sre-book/table-of-contents/
GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use
Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/
GitHub Actions: jobs and dependencies: https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-jobs
curl: command reference: https://curl.se/docs/manpage.html
Docker: getting started: https://docs.docker.com/get-started/
Docker Engine security: https://docs.docker.com/engine/security/
Git: recording changes: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository
Kubernetes: readiness, startup and liveness: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
OpenTofu: infrastructure state: https://opentofu.org/docs/language/state/
OpenTofu: installation options: https://opentofu.org/docs/intro/install/
GitHub Actions: OpenID Connect: https://docs.github.com/en/actions/concepts/security/openid-connect
Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/
Prometheus: recording rules: https://prometheus.io/docs/practices/rules/
