# DevOps Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Pipeline dependency gates

A release pipeline represents dependencies between checks, packaging and deployment. A failed prerequisite must prevent publication of an unverified artifact.
Mental model: An assembly line stops shipment when inspection fails.
Case: A failing title test must block the package job.
Task: Write a GitHub Actions workflow for the local reference with checkout, supported Node setup and test jobs. Make packaging depend on tests, then deliberately break one assertion in a branch.
Acceptance: The failed test blocks the dependent job; repair restores the pipeline.
Troubleshooting: Parallel jobs without needs can publish before tests finish; inspect the dependency graph.
Deliverable: workflow YAML and failed/passing run evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Immutable promotion

Identify artifacts by content digest and separate configuration from the build. Rebuilding the same tag for another environment produces a different artifact with weaker provenance.
Mental model: A sealed parcel keeps the same serial number as it moves between depots.
Case: The digest tested in staging must equal the digest proposed for release.
Task: Build a local container, record its image ID/digest, create an environment manifest and compare it with a second build. Write the promotion record with source revision and test result.
Acceptance: A trace from source to tested artifact to deployment configuration.
Troubleshooting: A mutable latest tag is not enough to prove what was tested; resolve and record the digest.
Deliverable: artifact manifest and promotion checklist

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Deployment recovery gates

A rollout needs an observation window and a user-visible verification. Undoing a Deployment changes its Pod template but does not reverse external data effects.
Mental model: A detour has a return route, but deliveries already made remain delivered.
Case: A nonexistent image produces an image-pull failure and a healthy prior replica may remain serving.
Task: Run the supplied kind failure rehearsal, record events before undo, then verify the endpoint after recovery. Add a separate decision for incompatible database changes.
Acceptance: Healthy rollout and successful HTTP response after recovery; incident timeline preserved.
Troubleshooting: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior.
Deliverable: release runbook and rollback evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
