# DevOps Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Desired state: A controller compares the current system with a declared target and works to reconcile the difference.

Delivery pipeline: A pipeline makes the steps from change to checked artifact explicit and repeatable. A failed check should prevent later dependent release steps.

Pipeline dependency gates: A release pipeline represents dependencies between checks, packaging and deployment. A failed prerequisite must prevent publication of an unverified artifact.

### Terminal foundations: paths and working directories

A command runs from a working directory and resolves relative paths from there. Before changing a file, know which folder contains it and whether the path refers to your exercise or a real system.

How it works
The fixture creates its own temporary directory and writes one file inside it. Joining paths avoids guessing the platform path separator. Cleanup owns only the directory created by the exercise.

Where the model stops
A path normalisation check alone is not a security sandbox; symlinks and permissions affect actual access.

Make one change
Draw the directory tree and locate the created file. Change the relative path to config/local/app.txt, create its parent directories deliberately and confirm no file outside the temporary tree is changed.

Mental model: A relative address starts from the room you are standing in.

Boundary: A path normalisation check alone is not a security sandbox; symlinks and permissions affect actual access.

Worked example: from pathlib import Path
from tempfile import TemporaryDirectory
with TemporaryDirectory(prefix='skillbadi-ops-') as folder:
 root=Path(folder)
 target=root/'config'/'app.txt'
 target.parent.mkdir()
 target.write_text('environment=local\n',encoding='utf-8')
 assert target.relative_to(root)==Path('config/app.txt')
 assert target.read_text(encoding='utf-8')=='environment=local\n'
 print('PASS: explicit temporary working tree')


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/terminal-paths. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Terminal, filesystem and Python pathlib

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Draw the directory tree and locate the created file. Change the relative path to config/local/app.txt, create its parent directories deliberately and confirm no file outside the temporary tree is changed.

Terminal folder: course-labs/beginner/terminal-paths

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The fixture creates its own temporary directory and writes one file inside it. Joining paths avoids guessing the platform path separator. Cleanup owns only the directory created by the exercise.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/terminal-paths. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The file round trips within the temporary tree and the tree is removed afterward. Your diagram matches the path used by the code.

Build your change

Draw the directory tree and locate the created file. Change the relative path to config/local/app.txt, create its parent directories deliberately and confirm no file outside the temporary tree is changed.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The file round trips within the temporary tree and the tree is removed afterward. Your diagram matches the path used by the code.

Break, repair and explain

Deliberately violate this boundary: A path normalisation check alone is not a security sandbox; symlinks and permissions affect actual access. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The file round trips within the temporary tree and the tree is removed afterward. Your diagram matches the path used by the code.

Troubleshoot: My result does not match Terminal foundations: paths and working directories: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The fixture creates its own temporary directory and writes one file inside it. Joining paths avoids guessing the platform path separator. Cleanup owns only the directory created by the exercise. Then inspect this limit: A path normalisation check alone is not a security sandbox; symlinks and permissions affect actual access. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/terminal-paths/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Terminal foundations: paths and working directories line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A relative address starts from the room you are standing in.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Where is a relative path resolved by an ordinary command? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A path normalisation check alone is not a security sandbox; symlinks and permissions affect actual access. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Where is a relative path resolved by an ordinary command?

Interview: Where is a relative path resolved by an ordinary command? Defend your answer using your actual lab result and this boundary: A path normalisation check alone is not a security sandbox; symlinks and permissions affect actual access.

Quiz: Where is a relative path resolved by an ordinary command?

From its working directory.

Always from the website root.

Always from Downloads.

Reference: From its working directory. — The working directory is part of the command environment. Inspect it before applying commands to files.

Sources:

Python: pathlib: https://docs.python.org/3/library/pathlib.html

### Git: record and inspect one deliberate change

Git records snapshots of a repository. The working tree contains edits, the index holds the next snapshot and a commit stores that snapshot with metadata. Learn these states before copying release commands.

How it works
This isolated exercise initialises its own temporary repository, sets a local example identity and commits one file. It does not change global Git settings or contact a remote.

Where the model stops
A local commit is not a push, review or deployment. Do not copy example identity into your real project without choosing your own settings.

Make one change
Before the temporary script exits, add a second edit, inspect git diff, stage it and inspect git diff --cached. Explain which version would enter the next commit.

Mental model: The working desk, packing tray and sealed parcel are three different states.

Boundary: A local commit is not a push, review or deployment. Do not copy example identity into your real project without choosing your own settings.

Worked example: set -eu
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cd "$work"
git init -q
git config user.name 'Learning Example'
git config user.email 'learning@example.invalid'
printf 'local\n' > app.txt
git add app.txt
git commit -qm 'Add local configuration'
test "$(git rev-list --count HEAD)" = 1
test -z "$(git status --porcelain)"
printf 'PASS: one commit and a clean learning repository\n'


Setup: Download and extract devops.zip. Git and a POSIX shell on Linux/macOS or Git Bash on Windows. Run git --version. The script uses an isolated temporary repository and does not change global Git settings. Open a terminal in course-labs/beginner/git-history. The supplied reference file is exercise.sh. Read it before running sh exercise.sh. Keep a copy before editing.

Tools for this exercise: Git and a POSIX shell

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Before the temporary script exits, add a second edit, inspect git diff, stage it and inspect git diff --cached. Explain which version would enter the next commit.

Terminal folder: course-labs/beginner/git-history

```
sh exercise.sh
```

Predict before running

Read exercise.sh. Write the expected output and identify the state changed by this example. This isolated exercise initialises its own temporary repository, sets a local example identity and commits one file. It does not change global Git settings or contact a remote.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/git-history. This checks the reference behaviour only.

```
sh exercise.sh
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: One commit exists and the reference working tree is clean. Your evidence distinguishes unstaged from staged content.

Build your change

Before the temporary script exits, add a second edit, inspect git diff, stage it and inspect git diff --cached. Explain which version would enter the next commit.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. One commit exists and the reference working tree is clean. Your evidence distinguishes unstaged from staged content.

Break, repair and explain

Deliberately violate this boundary: A local commit is not a push, review or deployment. Do not copy example identity into your real project without choosing your own settings. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: One commit exists and the reference working tree is clean. Your evidence distinguishes unstaged from staged content.

Troubleshoot: My result does not match Git: record and inspect one deliberate change: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: This isolated exercise initialises its own temporary repository, sets a local example identity and commits one file. It does not change global Git settings or contact a remote. Then inspect this limit: A local commit is not a push, review or deployment. Do not copy example identity into your real project without choosing your own settings. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/git-history/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Git: record and inspect one deliberate change line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: The working desk, packing tray and sealed parcel are three different states.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Does git add publish the file online? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A local commit is not a push, review or deployment. Do not copy example identity into your real project without choosing your own settings. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does git add publish the file online?

Interview: Does git add publish the file online? Defend your answer using your actual lab result and this boundary: A local commit is not a push, review or deployment. Do not copy example identity into your real project without choosing your own settings.

Quiz: Does git add publish the file online?

Yes.

No; it stages content for a local commit.

Only on macOS.

Reference: No; it stages content for a local commit. — Staging, committing and pushing are separate actions. This fixture performs no network operation.

Sources:

Git: recording changes: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository

### Processes: use exit codes as a contract

Automation needs a machine-readable outcome. A process exit code of zero conventionally means success; a nonzero code signals failure. A success-looking log line does not override the exit code.

How it works
subprocess.run captures output and the return code. The fixture invokes the same Python runtime rather than guessing an executable path. Test a success and a deliberate failure.

Where the model stops
A zero exit code proves only the program chosen success under its own rules. Check that those rules are meaningful.

Make one change
Write a small validation command that exits nonzero for missing required input. Capture the code and explain how a pipeline should stop after that failure.

Mental model: The status light is separate from the message printed on the display.

Boundary: A zero exit code proves only the program chosen success under its own rules. Check that those rules are meaningful.

Worked example: import subprocess,sys
ok=subprocess.run([sys.executable,'-c','print("checked")'],capture_output=True,text=True)
bad=subprocess.run([sys.executable,'-c','raise SystemExit(2)'],capture_output=True,text=True)
assert ok.returncode==0 and ok.stdout.strip()=='checked'
assert bad.returncode==2
print('PASS: success and intentional nonzero exit')


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/exit-codes. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Terminal, process exit codes and Python subprocess

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Write a small validation command that exits nonzero for missing required input. Capture the code and explain how a pipeline should stop after that failure.

Terminal folder: course-labs/beginner/exit-codes

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. subprocess.run captures output and the return code. The fixture invokes the same Python runtime rather than guessing an executable path. Test a success and a deliberate failure.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/exit-codes. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The successful process returns 0 and the failed process returns 2. Your pipeline policy uses the code rather than matching a cheerful log message.

Build your change

Write a small validation command that exits nonzero for missing required input. Capture the code and explain how a pipeline should stop after that failure.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The successful process returns 0 and the failed process returns 2. Your pipeline policy uses the code rather than matching a cheerful log message.

Break, repair and explain

Deliberately violate this boundary: A zero exit code proves only the program chosen success under its own rules. Check that those rules are meaningful. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The successful process returns 0 and the failed process returns 2. Your pipeline policy uses the code rather than matching a cheerful log message.

Troubleshoot: My result does not match Processes: use exit codes as a contract: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: subprocess.run captures output and the return code. The fixture invokes the same Python runtime rather than guessing an executable path. Test a success and a deliberate failure. Then inspect this limit: A zero exit code proves only the program chosen success under its own rules. Check that those rules are meaningful. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/exit-codes/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Processes: use exit codes as a contract line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: The status light is separate from the message printed on the display.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: A script prints Done then exits 2. What should a normal CI step conclude? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A zero exit code proves only the program chosen success under its own rules. Check that those rules are meaningful. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A script prints Done then exits 2. What should a normal CI step conclude?

Interview: A script prints Done then exits 2. What should a normal CI step conclude? Defend your answer using your actual lab result and this boundary: A zero exit code proves only the program chosen success under its own rules. Check that those rules are meaningful.

Quiz: A script prints Done then exits 2. What should a normal CI step conclude?

It passed because it printed Done.

It was skipped.

It failed.

Reference: It failed. — The exit contract determines step success. Output is diagnostic evidence, not a substitute for status.

Sources:

Python: subprocess and return codes: https://docs.python.org/3/library/subprocess.html

### Configuration: parse environment values intentionally

An environment variable arrives as text. Values such as false, 0 and an empty string need explicit parsing. Never assume a nonempty string containing false is a boolean false.

How it works
Use an allowlist for accepted spellings. Reject an unknown value rather than silently enabling a feature. Keep secrets out of printed configuration reports.

Where the model stops
This parser does not manage secret rotation or prove the environment is trusted.

Make one change
Add a port parser for integer text in the range 1024 to 65535. Test blank, 1023, 1024, 65535 and 65536 without printing secret values.

Mental model: A configuration card contains written words that must be interpreted before operating the machine.

Boundary: This parser does not manage secret rotation or prove the environment is trusted.

Worked example: def boolean(value):
 if value=='true': return True
 if value=='false': return False
 raise ValueError('Use true or false')
assert boolean('false') is False
assert boolean('true') is True
try:
 boolean('enabled')
except ValueError:
 print('PASS: explicit booleans and rejected unknown value')
else:
 raise AssertionError('Expected rejection')


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/environment-config. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Environment variables and a typed configuration parser

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add a port parser for integer text in the range 1024 to 65535. Test blank, 1023, 1024, 65535 and 65536 without printing secret values.

Terminal folder: course-labs/beginner/environment-config

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Use an allowlist for accepted spellings. Reject an unknown value rather than silently enabling a feature. Keep secrets out of printed configuration reports.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/environment-config. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Known booleans parse correctly and unknown input is rejected. Your port boundary tests match the declared range.

Build your change

Add a port parser for integer text in the range 1024 to 65535. Test blank, 1023, 1024, 65535 and 65536 without printing secret values.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Known booleans parse correctly and unknown input is rejected. Your port boundary tests match the declared range.

Break, repair and explain

Deliberately violate this boundary: This parser does not manage secret rotation or prove the environment is trusted. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Known booleans parse correctly and unknown input is rejected. Your port boundary tests match the declared range.

Troubleshoot: My result does not match Configuration: parse environment values intentionally: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Use an allowlist for accepted spellings. Reject an unknown value rather than silently enabling a feature. Keep secrets out of printed configuration reports. Then inspect this limit: This parser does not manage secret rotation or prove the environment is trusted. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/environment-config/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Configuration: parse environment values intentionally line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A configuration card contains written words that must be interpreted before operating the machine.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: What is dangerous about bool("false") in Python? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This parser does not manage secret rotation or prove the environment is trusted. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: What is dangerous about bool("false") in Python?

Interview: What is dangerous about bool("false") in Python? Defend your answer using your actual lab result and this boundary: This parser does not manage secret rotation or prove the environment is trusted.

Quiz: What is dangerous about bool("false") in Python?

It evaluates to True because the string is nonempty.

It rotates secrets.

It deletes the variable.

Reference: It evaluates to True because the string is nonempty. — Language truthiness and a configuration format are different rules. Parse the format explicitly.

Sources:

Python: operating-system environment interface: https://docs.python.org/3/library/os.html

### Health checks: send a real local request

A health endpoint gives a service a small observable contract. A successful response proves that endpoint responded; it does not prove every dependency or user journey is healthy.

How it works
This local HTTP server binds only to loopback and chooses an unused port. urllib sends an actual request. The finally block shuts down the server and joins the serving thread.

Where the model stops
The example has no external dependency, TLS or production server. Keep its health claim narrow.

Make one change
Test the missing route and a dependency-failed response separately. Write down whether each check belongs to liveness, readiness or an end-to-end synthetic test.

Mental model: A heartbeat is useful evidence of life, not a complete medical examination.

Boundary: The example has no external dependency, TLS or production server. Keep its health claim narrow.

Worked example: from http.server import BaseHTTPRequestHandler,HTTPServer
from threading import Thread
from urllib.request import urlopen
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  self.send_response(200 if self.path=='/health' else 404)
  self.end_headers()
  self.wfile.write(b'ok')
 def log_message(self,*args): pass
server=HTTPServer(('127.0.0.1',0),Handler)
thread=Thread(target=server.serve_forever);thread.start()
try:
 with urlopen('http://127.0.0.1:%s/health'%server.server_port,timeout=2) as response:
  assert response.status==200 and response.read()==b'ok'
 print('PASS: real loopback health request')
finally:
 server.shutdown();server.server_close();thread.join()


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/beginner/local-health. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: HTTP health endpoint and urllib

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Test the missing route and a dependency-failed response separately. Write down whether each check belongs to liveness, readiness or an end-to-end synthetic test.

Terminal folder: course-labs/beginner/local-health

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. This local HTTP server binds only to loopback and chooses an unused port. urllib sends an actual request. The finally block shuts down the server and joins the serving thread.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/beginner/local-health. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The local health endpoint returns 200 and ok, and the thread stops. Your failure case has an intentional status and bounded request timeout.

Build your change

Test the missing route and a dependency-failed response separately. Write down whether each check belongs to liveness, readiness or an end-to-end synthetic test.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The local health endpoint returns 200 and ok, and the thread stops. Your failure case has an intentional status and bounded request timeout.

Break, repair and explain

Deliberately violate this boundary: The example has no external dependency, TLS or production server. Keep its health claim narrow. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The local health endpoint returns 200 and ok, and the thread stops. Your failure case has an intentional status and bounded request timeout.

Troubleshoot: My result does not match Health checks: send a real local request: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: This local HTTP server binds only to loopback and chooses an unused port. urllib sends an actual request. The finally block shuts down the server and joins the serving thread. Then inspect this limit: The example has no external dependency, TLS or production server. Keep its health claim narrow. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/beginner/local-health/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Health checks: send a real local request line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A heartbeat is useful evidence of life, not a complete medical examination.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Does one healthy /health response prove the database works? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The example has no external dependency, TLS or production server. Keep its health claim narrow. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does one healthy /health response prove the database works?

Interview: Does one healthy /health response prove the database works? Defend your answer using your actual lab result and this boundary: The example has no external dependency, TLS or production server. Keep its health claim narrow.

Quiz: Does one healthy /health response prove the database works?

Yes.

No, unless that dependency was actually part of the defined check.

Only if the port is 80.

Reference: No, unless that dependency was actually part of the defined check. — Health signals need explicit semantics. A probe cannot prove work it did not exercise.

Sources:

Python: local HTTP server; not for production: https://docs.python.org/3/library/http.server.html

### Processes, ports and HTTP evidence

Use a disposable local server to separate network symptoms. A refused connection means no accessible listener at that address/port; an HTTP error means some server replied. Check method, path and response body, not just process existence.

Mental model: A port is a numbered door; a process is the worker behind it; an HTTP status is the worker’s reply.

Boundary: A successful connection does not prove the business response is correct.

Worked example: Connection refused, HTTP 404 and HTTP 500 suggest different boundaries. Capture the exact error before restarting anything.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: Python local HTTP server + curl

Course tool and framework map: 



In a new temporary lab folder, create a text file and serve it on loopback. In another terminal, request the file and an absent path. Stop the server with Ctrl+C.

Commands (after setup)

```
mkdir -p atlas-http-lab
cd atlas-http-lab
printf "ready\n" > health.txt
python3 -m http.server 8139 --bind 127.0.0.1
# Second terminal:
curl -i http://127.0.0.1:8139/health.txt
curl -i http://127.0.0.1:8139/missing.txt
```

Expected: health.txt returns 200 and ready; missing.txt returns 404. After stopping the server, curl reports connection failure. Use this dedicated folder only.

Troubleshoot: curl hangs or reports a proxy response: Confirm loopback address, port and proxy environment. Use curl --noproxy 127.0.0.1 for this local test if appropriate; do not disable organizational network protections globally.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/beginner/processes-ports-and-http-evidence.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Give your first three checks for connection refused versus HTTP 500.

new: Start by describing processes, ports and http evidence in your own words. In a new temporary lab folder, create a text file and serve it on loopback. In another terminal, request the file and an absent path. Stop the server with Ctrl+C. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for processes, ports and http evidence. Give your first three checks for connection refused versus HTTP 500. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect processes, ports and http evidence to one system you already know. Give your first three checks for connection refused versus HTTP 500. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: How would you distinguish an unreachable listener from a wrong URL?

Interview: Give your first three checks for connection refused versus HTTP 500.

Quiz: What does HTTP 500 establish?

A server responded with an internal error.

DNS definitely failed.

No process is listening.

Reference: A server responded with an internal error. — A received HTTP response is different from a transport error. Continue at the application boundary.

Sources:

curl: command reference: https://curl.se/docs/manpage.html

### Git changes and container boundaries

Inspect source diffs before building. Runtime environment variables, mounts and network settings can change behavior even for the same image. Use explicit loopback publishing and a named disposable container so cleanup is scoped.

Mental model: An image is a packaged recipe; a container is one running instance using it.

Boundary: Containers are not complete virtual machines, and isolation is not a substitute for least privilege.

Worked example: Inspect a diff before committing. Publish a web container only on 127.0.0.1 for a local exercise; remove only that named container afterwards.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: Docker Engine / Docker Desktop + Git

Course tool and framework map: 



Install Docker using its official guide. Start the example container, inspect its image identity and logs, request the service and remove only this named instance.

Commands (after setup)

```
docker run -d --name atlas-web-lesson -p 127.0.0.1:8140:80 nginx:stable-alpine
docker inspect atlas-web-lesson --format "{{.Image}}"
docker logs atlas-web-lesson
curl -I http://127.0.0.1:8140
docker rm -f atlas-web-lesson
```

Expected: HTTP response is 200; inspect prints an image content ID. Record the pulled version/digest because this introductory tag can change. Cleanup removes only atlas-web-lesson.

Troubleshoot: Container name already exists: Inspect the named container to determine if it belongs to your earlier exercise. Choose a new unique name or deliberately clean up your own instance; never run a global prune.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/beginner/git-changes-and-container-boundaries.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain image versus container and why configuration belongs in release evidence.

new: Start by describing git changes and container boundaries in your own words. Install Docker using its official guide. Start the example container, inspect its image identity and logs, request the service and remove only this named instance. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for git changes and container boundaries. Explain image versus container and why configuration belongs in release evidence. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect git changes and container boundaries to one system you already know. Explain image versus container and why configuration belongs in release evidence. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why can two containers from one image behave differently?

Interview: Explain image versus container and why configuration belongs in release evidence.

Quiz: Which fact makes a release reproducible?

Only the tag latest.

A recorded immutable image digest plus runtime configuration.

The container name alone.

Reference: A recorded immutable image digest plus runtime configuration. — Tags can move; configuration also affects behavior. Record both artifact identity and relevant configuration.

Sources:

Docker: getting started: https://docs.docker.com/get-started/

Docker Engine security: https://docs.docker.com/engine/security/

Git: recording changes: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository

### Desired state

A controller repeatedly compares desired and observed state. A Deployment declares replica and Pod-template intent; the controller cannot invent a missing image or supply unlimited capacity. Inspect events before changing desired state.

Mental model: A thermostat compares actual temperature with the set point.

Boundary: It cannot fix every cause: a missing image or insufficient resources still needs action.

Worked example: One replica means the controller tries to keep one Pod running.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: Kubernetes kubectl + kind

Course tool and framework map: 



Read the original level lab first. Use its dedicated kind cluster and kubeconfig. Inspect a Deployment and Pod events, then explain the desired/ready difference.

Commands (after setup)

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get deployment,pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
```

Expected: The Deployment shows desired and available replicas. Pending or image failures are visible in Pod/events output. Setup is in the existing Hands-on lab; these commands do not create a cluster.

Troubleshoot: No resources or wrong context: Check the exact local kubeconfig and namespace from the lab. Do not remove context flags or switch to a production cluster to make a command work.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/beginner/desired-state.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain desired, current and ready state separately.

new: Start by describing desired state in your own words. Read the original level lab first. Use its dedicated kind cluster and kubeconfig. Inspect a Deployment and Pod events, then explain the desired/ready difference. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for desired state. Explain desired, current and ready state separately. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect desired state to one system you already know. Explain desired, current and ready state separately. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: What happens when a Pod is deleted but its Deployment remains?

Interview: Explain desired, current and ready state separately.

Quiz: Desired replicas=2 but ready=0. What next?

Keep increasing replicas blindly.

Inspect Pod status and events for the blocking condition.

Declare the service healthy.

Reference: Inspect Pod status and events for the blocking condition. — Controllers reconcile intent within constraints. Evidence identifies scheduling, image or readiness failures.

Sources:

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

### Pipeline dependency gates

CI jobs can run independently unless dependencies are declared. A publish job needs successful checks; workflow permissions and triggers also matter. A skipped or ignored test result is not a safe promotion gate.

Mental model: An assembly line stops shipment when inspection fails.

Boundary: Parallel jobs without needs can publish before tests finish; inspect the dependency graph.

Worked example: A failing title test must block the package job.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: GitHub Actions

Course tool and framework map: 



Open the supplied role-workshop pipeline example. Draw its job dependency graph and add a publish job that requires test. Review the workflow below as a fragment to merge into jobs, not a complete file.

Commands (after setup)

```
test:
  runs-on: ubuntu-latest
  steps:
    - run: exit 1
publish:
  needs: test
  runs-on: ubuntu-latest
  steps:
    - run: echo "publish placeholder"
```

Expected: In an isolated repository workflow with a push or manual trigger, test fails and publish is skipped. The echo is a placeholder, not an actual release.

Troubleshoot: publish still runs after test failure: Inspect needs, if: always() and continue-on-error. Remove success-bypassing behavior from the release gate; retain logs for diagnosis.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/beginner/pipeline-dependency-gates.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain how you would prevent a failed test from producing a release.

new: Start by describing pipeline dependency gates in your own words. Open the supplied role-workshop pipeline example. Draw its job dependency graph and add a publish job that requires test. Review the workflow below as a fragment to merge into jobs, not a complete file. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for pipeline dependency gates. Explain how you would prevent a failed test from producing a release. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect pipeline dependency gates to one system you already know. Explain how you would prevent a failed test from producing a release. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Parallel jobs without needs can publish before tests finish; inspect the dependency graph.

Interview: Explain how you would prevent a failed test from producing a release.

Quiz: What makes publish wait for a successful test job?

A similar job name.

needs: test without bypassing its success condition.

Placing it lower in the YAML file.

Reference: needs: test without bypassing its success condition. — Job order in a file does not define execution dependencies. needs establishes the dependency.

Sources:

GitHub Actions: jobs and dependencies: https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-jobs

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Readiness and routing: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.

Artifact and environment: Build a versioned artifact, then supply environment configuration separately. Record the exact artifact that was deployed.

Immutable promotion: Identify artifacts by content digest and separate configuration from the build. Rebuilding the same tag for another environment produces a different artifact with weaker provenance.

### Containers: separate image build from runtime state

An image is a packaged filesystem and startup configuration. A container is a running instance with writable state. Build context determines which local files can be copied into the image.

How it works
The Python check writes a minimal Dockerfile and verifies its stated non-root user. The optional native extension builds it and runs a deterministic command. Keep secrets and dependency caches out of the context.

Where the model stops
Text inspection is not a container build or vulnerability scan. Docker Engine access and image downloads are required for the native extension.

Make one change
Create a dedicated empty folder containing only this Dockerfile. Build and run the native extension if Docker Engine is available. Record the resolved base image digest and compare it with a tag-only reference.

Mental model: The image is a recipe kit; containers are separate kitchens using that kit.

Boundary: Text inspection is not a container build or vulnerability scan. Docker Engine access and image downloads are required for the native extension.

Worked example: from pathlib import Path
from tempfile import TemporaryDirectory
text='FROM python:3.12-slim\nWORKDIR /app\nUSER 10001:10001\nCMD ["python","-c","print(42)"]\n'
with TemporaryDirectory() as folder:
 path=Path(folder)/'Dockerfile';path.write_text(text)
 assert 'USER 10001:10001' in path.read_text()
 assert 'COPY . .' not in text
 print(text)


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/docker-build-context. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Docker Engine / Docker Desktop; alternative Podman

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Create a dedicated empty folder containing only this Dockerfile. Build and run the native extension if Docker Engine is available. Record the resolved base image digest and compare it with a tag-only reference.

Terminal folder: course-labs/intermediate/docker-build-context

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The Python check writes a minimal Dockerfile and verifies its stated non-root user. The optional native extension builds it and runs a deterministic command. Keep secrets and dependency caches out of the context.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/docker-build-context. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The local check prints the Dockerfile. Only after a successful native build/run may you record the container output 42.

Build your change

Create a dedicated empty folder containing only this Dockerfile. Build and run the native extension if Docker Engine is available. Record the resolved base image digest and compare it with a tag-only reference.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The local check prints the Dockerfile. Only after a successful native build/run may you record the container output 42.

Break, repair and explain

Deliberately violate this boundary: Text inspection is not a container build or vulnerability scan. Docker Engine access and image downloads are required for the native extension. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Optional native-tool extension

Install an authorised Docker Engine or compatible runtime. Docker Desktop licensing differs from the open-source engine; check current terms. Image downloads need network and disk space. Work only in your new learning folder.

```
docker build -t skillbadi-learning:local .
docker run --rm --network none skillbadi-learning:local
```

This is a separate optional environment. Do not claim a platform or model was executed from the local reference check.

Expected: The build succeeds and the container prints 42. Record the actual resolved base image digest; a tag is not immutable.

Expected: The local check prints the Dockerfile. Only after a successful native build/run may you record the container output 42.

Troubleshoot: My result does not match Containers: separate image build from runtime state: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The Python check writes a minimal Dockerfile and verifies its stated non-root user. The optional native extension builds it and runs a deterministic command. Keep secrets and dependency caches out of the context. Then inspect this limit: Text inspection is not a container build or vulnerability scan. Docker Engine access and image downloads are required for the native extension. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. Remove only the image created here when no longer needed: docker image rm skillbadi-learning:local. Do not prune unrelated resources.

Deliverable: course-labs/intermediate/docker-build-context/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Containers: separate image build from runtime state line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: The image is a recipe kit; containers are separate kitchens using that kit.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Does inspecting a Dockerfile prove that its image builds? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Text inspection is not a container build or vulnerability scan. Docker Engine access and image downloads are required for the native extension. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does inspecting a Dockerfile prove that its image builds?

Interview: Does inspecting a Dockerfile prove that its image builds? Defend your answer using your actual lab result and this boundary: Text inspection is not a container build or vulnerability scan. Docker Engine access and image downloads are required for the native extension.

Quiz: Does inspecting a Dockerfile prove that its image builds?

No; execute and inspect the actual build separately.

Yes.

Only when the image is slim.

Reference: No; execute and inspect the actual build separately. — Static inspection and runtime execution are different evidence. Tags can change; a reviewed digest gives an immutable image reference.

Sources:

Docker: getting started: https://docs.docker.com/get-started/

Docker Desktop subscription terms: https://docs.docker.com/subscription/desktop-license/

### CI: make a failing check block the pipeline

Continuous integration runs checks when changes arrive. A useful job has a reproducible environment and a command whose failure stops the job. A green pipeline is meaningful only for the behaviours it actually checked.

How it works
The example runs a real child process and rejects its nonzero result. A GitHub Actions job should use the same contract. Limit token permissions, avoid secrets on untrusted changes and pin reviewed third-party actions.

Where the model stops
The local process test does not execute GitHub-hosted CI. Runner images, account quotas and permissions have separate constraints.

Make one change
In a practice repository, add a minimal workflow that runs the positive assertion. Open a change with the broken assertion and keep the failed job link. Restore it and compare the two runs.

Mental model: A quality gate must connect its red light to the barrier.

Boundary: The local process test does not execute GitHub-hosted CI. Runner images, account quotas and permissions have separate constraints.

Worked example: import subprocess,sys
command=[sys.executable,'-c','assert 2+2==4']
assert subprocess.run(command,check=False).returncode==0
broken=[sys.executable,'-c','assert 2+2==5']
assert subprocess.run(broken,check=False,capture_output=True).returncode!=0
print('PASS: broken check returns pipeline failure status')


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/ci-workflow. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: GitHub Actions; alternatives GitLab CI and Jenkins

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

In a practice repository, add a minimal workflow that runs the positive assertion. Open a change with the broken assertion and keep the failed job link. Restore it and compare the two runs.

Terminal folder: course-labs/intermediate/ci-workflow

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The example runs a real child process and rejects its nonzero result. A GitHub Actions job should use the same contract. Limit token permissions, avoid secrets on untrusted changes and pin reviewed third-party actions.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/ci-workflow. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The local correct command passes and the broken command fails. Your optional hosted run proves its own workflow execution, not merely valid YAML.

Build your change

In a practice repository, add a minimal workflow that runs the positive assertion. Open a change with the broken assertion and keep the failed job link. Restore it and compare the two runs.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The local correct command passes and the broken command fails. Your optional hosted run proves its own workflow execution, not merely valid YAML.

Break, repair and explain

Deliberately violate this boundary: The local process test does not execute GitHub-hosted CI. Runner images, account quotas and permissions have separate constraints. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Optional native-tool extension

Use a practice repository you control. Hosted runners may consume plan minutes; no secrets are needed. This example uses no marketplace action and does not need a checkout because its assertion is inline.

```
# Save as .github/workflows/learning.yml
name: Learning check
on: [push, pull_request]
permissions: {}
jobs:
  check:
    runs-on: ubuntu-latest
    timeout-minutes: 2
    steps:
      - run: python3 -c "assert 2 + 2 == 4"
```

This is a separate optional environment. Do not claim a platform or model was executed from the local reference check.

Expected: The hosted job passes; deliberately change the assertion in a practice branch and observe its failed status.

Expected: The local correct command passes and the broken command fails. Your optional hosted run proves its own workflow execution, not merely valid YAML.

Troubleshoot: My result does not match CI: make a failing check block the pipeline: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The example runs a real child process and rejects its nonzero result. A GitHub Actions job should use the same contract. Limit token permissions, avoid secrets on untrusted changes and pin reviewed third-party actions. Then inspect this limit: The local process test does not execute GitHub-hosted CI. Runner images, account quotas and permissions have separate constraints. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. Restore the valid assertion. Remove only the practice workflow/repository if you no longer need it.

Deliverable: course-labs/intermediate/ci-workflow/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace CI: make a failing check block the pipeline line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A quality gate must connect its red light to the barrier.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Should continue-on-error be used for a required release check? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The local process test does not execute GitHub-hosted CI. Runner images, account quotas and permissions have separate constraints. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Should continue-on-error be used for a required release check?

Interview: Should continue-on-error be used for a required release check? Defend your answer using your actual lab result and this boundary: The local process test does not execute GitHub-hosted CI. Runner images, account quotas and permissions have separate constraints.

Quiz: Should continue-on-error be used for a required release check?

Always.

No; it can allow the job to continue after a required failure.

Only for syntax tests.

Reference: No; it can allow the job to continue after a required failure. — Required checks must actually block when they fail. Optional diagnostics can have separate policies.

Sources:

GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use

GitHub Actions: jobs and dependencies: https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-jobs

### Kubernetes: describe desired state and inspect observed state

A Deployment declares how many replicas of a Pod template should exist. A controller works toward that state. Creating an object does not mean its Pods are ready or that its image can be pulled.

How it works
The local example creates a valid-shaped JSON Deployment document. Its selector and Pod label agree. The native extension applies it to an explicitly chosen local kind cluster and waits for rollout status.

Where the model stops
A JSON document check does not validate a live cluster, admission policy, image supply chain or networking.

Make one change
Save the printed JSON as deployment.json in a dedicated folder. Use only the named local learning cluster. Inspect desired versus available replicas, then deliberately use a nonexistent image tag and investigate the Pod events.

Mental model: A work order describes the target; the status report describes what the team has actually achieved.

Boundary: A JSON document check does not validate a live cluster, admission policy, image supply chain or networking.

Worked example: import json
manifest={'apiVersion':'apps/v1','kind':'Deployment','metadata':{'name':'learning-web','namespace':'skillbadi-lab'},'spec':{'replicas':1,'selector':{'matchLabels':{'app':'learning-web'}},'template':{'metadata':{'labels':{'app':'learning-web'}},'spec':{'containers':[{'name':'web','image':'nginx:stable','ports':[{'containerPort':80}]}]}}}}
assert manifest['spec']['selector']['matchLabels']==manifest['spec']['template']['metadata']['labels']
print(json.dumps(manifest,indent=2))


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/kube-desired-state. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Kubernetes kubectl and kind; managed alternatives EKS / AKS / GKE

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Save the printed JSON as deployment.json in a dedicated folder. Use only the named local learning cluster. Inspect desired versus available replicas, then deliberately use a nonexistent image tag and investigate the Pod events.

Terminal folder: course-labs/intermediate/kube-desired-state

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The local example creates a valid-shaped JSON Deployment document. Its selector and Pod label agree. The native extension applies it to an explicitly chosen local kind cluster and waits for rollout status.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/kube-desired-state. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The local selector check passes. Native success requires a completed rollout; the broken tag should produce pull-related evidence in your cluster rather than a claimed automatic diagnosis.

Build your change

Save the printed JSON as deployment.json in a dedicated folder. Use only the named local learning cluster. Inspect desired versus available replicas, then deliberately use a nonexistent image tag and investigate the Pod events.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The local selector check passes. Native success requires a completed rollout; the broken tag should produce pull-related evidence in your cluster rather than a claimed automatic diagnosis.

Break, repair and explain

Deliberately violate this boundary: A JSON document check does not validate a live cluster, admission policy, image supply chain or networking. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Optional native-tool extension

Optional: install kind, kubectl and a compatible container runtime. Create a new cluster only if the name skillbadi-learning is unused: kind create cluster --name skillbadi-learning. Commands below explicitly target kind-skillbadi-learning. A local cluster uses memory and image downloads; cloud clusters are not required.

```
kubectl --context kind-skillbadi-learning create namespace skillbadi-lab
kubectl --context kind-skillbadi-learning apply -f deployment.json
kubectl --context kind-skillbadi-learning -n skillbadi-lab rollout status deployment/learning-web --timeout=120s
kubectl --context kind-skillbadi-learning -n skillbadi-lab describe pods
```

This is a separate optional environment. Do not claim a platform or model was executed from the local reference check.

Expected: The rollout becomes available if the image can be pulled and scheduled. For failure, record Events and container status before changing the configuration.

Expected: The local selector check passes. Native success requires a completed rollout; the broken tag should produce pull-related evidence in your cluster rather than a claimed automatic diagnosis.

Troubleshoot: My result does not match Kubernetes: describe desired state and inspect observed state: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The local example creates a valid-shaped JSON Deployment document. Its selector and Pod label agree. The native extension applies it to an explicitly chosen local kind cluster and waits for rollout status. Then inspect this limit: A JSON document check does not validate a live cluster, admission policy, image supply chain or networking. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. Delete only the learning cluster you created: kind delete cluster --name skillbadi-learning. Do not delete an existing shared cluster or namespace.

Deliverable: course-labs/intermediate/kube-desired-state/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Kubernetes: describe desired state and inspect observed state line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A work order describes the target; the status report describes what the team has actually achieved.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: kubectl apply reports configured. Are all Pods necessarily ready? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A JSON document check does not validate a live cluster, admission policy, image supply chain or networking. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: kubectl apply reports configured. Are all Pods necessarily ready?

Interview: kubectl apply reports configured. Are all Pods necessarily ready? Defend your answer using your actual lab result and this boundary: A JSON document check does not validate a live cluster, admission policy, image supply chain or networking.

Quiz: kubectl apply reports configured. Are all Pods necessarily ready?

Yes.

Only at one replica.

No; inspect rollout and status separately.

Reference: No; inspect rollout and status separately. — The API accepted a desired-state update. Controllers, scheduling, image pull and readiness are subsequent observable steps.

Sources:

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

### Probes: distinguish liveness from readiness

Readiness decides whether a Pod should receive Service traffic. Liveness can trigger a container restart. Startup probes protect slow-starting applications before the other probes begin.

How it works
A temporary downstream outage can make a service unready without proving its process is stuck. Restarting every replica because the same database is down can add load and erase diagnostic evidence.

Where the model stops
The local rule is a diagnostic decision model, not a probe implementation or proof of cluster behaviour.

Make one change
For the earlier learning Deployment, sketch distinct probe endpoints and thresholds. Test readiness failure in an authorised local app and inspect Service endpoint membership; do not force a liveness restart to hide a dependency outage.

Mental model: Ready for customers and needs restarting are different signs on the same shop.

Boundary: The local rule is a diagnostic decision model, not a probe implementation or proof of cluster behaviour.

Worked example: def probes(process_alive,ready_dependency):
 return {'live':process_alive,'ready':process_alive and ready_dependency}
assert probes(True,False)=={'live':True,'ready':False}
assert probes(False,True)=={'live':False,'ready':False}
print('PASS: dependency outage does not automatically imply dead process')


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/probe-semantics. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Kubernetes readiness, liveness and startup probes

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

For the earlier learning Deployment, sketch distinct probe endpoints and thresholds. Test readiness failure in an authorised local app and inspect Service endpoint membership; do not force a liveness restart to hide a dependency outage.

Terminal folder: course-labs/intermediate/probe-semantics

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. A temporary downstream outage can make a service unready without proving its process is stuck. Restarting every replica because the same database is down can add load and erase diagnostic evidence.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/probe-semantics. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The decision model distinguishes the two signals. Your native report names which probe failed and its actual traffic/restart consequence.

Build your change

For the earlier learning Deployment, sketch distinct probe endpoints and thresholds. Test readiness failure in an authorised local app and inspect Service endpoint membership; do not force a liveness restart to hide a dependency outage.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The decision model distinguishes the two signals. Your native report names which probe failed and its actual traffic/restart consequence.

Break, repair and explain

Deliberately violate this boundary: The local rule is a diagnostic decision model, not a probe implementation or proof of cluster behaviour. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The decision model distinguishes the two signals. Your native report names which probe failed and its actual traffic/restart consequence.

Troubleshoot: My result does not match Probes: distinguish liveness from readiness: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: A temporary downstream outage can make a service unready without proving its process is stuck. Restarting every replica because the same database is down can add load and erase diagnostic evidence. Then inspect this limit: The local rule is a diagnostic decision model, not a probe implementation or proof of cluster behaviour. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/probe-semantics/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Probes: distinguish liveness from readiness line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Ready for customers and needs restarting are different signs on the same shop.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Which signal normally removes an unready Pod from eligible Service endpoints? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The local rule is a diagnostic decision model, not a probe implementation or proof of cluster behaviour. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Which signal normally removes an unready Pod from eligible Service endpoints?

Interview: Which signal normally removes an unready Pod from eligible Service endpoints? Defend your answer using your actual lab result and this boundary: The local rule is a diagnostic decision model, not a probe implementation or proof of cluster behaviour.

Quiz: Which signal normally removes an unready Pod from eligible Service endpoints?

Readiness.

A CSS class.

A log line containing warn.

Reference: Readiness. — Readiness is the traffic eligibility signal. Liveness and startup probes address different lifecycle decisions.

Sources:

Kubernetes: readiness, startup and liveness: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/

### Infrastructure plans: review destructive intent

Infrastructure as code describes intended resources. A plan compares that intent with observed state. A small text diff can still represent a replacement or deletion with a large operational impact.

How it works
Classify planned operations before applying them. The teaching policy flags delete and replace for a manual migration and recovery review. It is a local model rather than an OpenTofu policy engine.

Where the model stops
An allowlisted plan does not prove permissions, cost, drift or safety. Use a dedicated sandbox and reviewed real provider plan.

Make one change
Write a change review explaining data backup, replacement identity and rollback for the database entry. Compare the model with a real OpenTofu plan only in an isolated authorised sandbox; do not apply a cloud plan as part of this local exercise.

Mental model: A revised building plan must show which walls will be removed, not only how few lines changed.

Boundary: An allowlisted plan does not prove permissions, cost, drift or safety. Use a dedicated sandbox and reviewed real provider plan.

Worked example: changes=[{'name':'learning-vm','actions':['update']},{'name':'learning-db','actions':['delete','create']}]
needs_review=lambda change:'delete' in change['actions']
assert not needs_review(changes[0])
assert needs_review(changes[1])
print('Review required:',[c['name'] for c in changes if needs_review(c)])


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/intermediate/infra-plan. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: OpenTofu; commercial alternatives Terraform platform and cloud-native services

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Write a change review explaining data backup, replacement identity and rollback for the database entry. Compare the model with a real OpenTofu plan only in an isolated authorised sandbox; do not apply a cloud plan as part of this local exercise.

Terminal folder: course-labs/intermediate/infra-plan

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Classify planned operations before applying them. The teaching policy flags delete and replace for a manual migration and recovery review. It is a local model rather than an OpenTofu policy engine.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/intermediate/infra-plan. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Only learning-db is flagged. Your review identifies replacement consequences and separates a local policy model from an actual provider plan.

Build your change

Write a change review explaining data backup, replacement identity and rollback for the database entry. Compare the model with a real OpenTofu plan only in an isolated authorised sandbox; do not apply a cloud plan as part of this local exercise.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Only learning-db is flagged. Your review identifies replacement consequences and separates a local policy model from an actual provider plan.

Break, repair and explain

Deliberately violate this boundary: An allowlisted plan does not prove permissions, cost, drift or safety. Use a dedicated sandbox and reviewed real provider plan. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Only learning-db is flagged. Your review identifies replacement consequences and separates a local policy model from an actual provider plan.

Troubleshoot: My result does not match Infrastructure plans: review destructive intent: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Classify planned operations before applying them. The teaching policy flags delete and replace for a manual migration and recovery review. It is a local model rather than an OpenTofu policy engine. Then inspect this limit: An allowlisted plan does not prove permissions, cost, drift or safety. Use a dedicated sandbox and reviewed real provider plan. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/intermediate/infra-plan/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Infrastructure plans: review destructive intent line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A revised building plan must show which walls will be removed, not only how few lines changed.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Does a small source diff guarantee a low-risk infrastructure change? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: An allowlisted plan does not prove permissions, cost, drift or safety. Use a dedicated sandbox and reviewed real provider plan. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does a small source diff guarantee a low-risk infrastructure change?

Interview: Does a small source diff guarantee a low-risk infrastructure change? Defend your answer using your actual lab result and this boundary: An allowlisted plan does not prove permissions, cost, drift or safety. Use a dedicated sandbox and reviewed real provider plan.

Quiz: Does a small source diff guarantee a low-risk infrastructure change?

Yes.

No; inspect planned resource actions and consequences.

Only if written in HCL.

Reference: No; inspect planned resource actions and consequences. — A one-line setting can force replacement. Review the operational change, state, data and recovery path.

Sources:

OpenTofu: infrastructure state: https://opentofu.org/docs/language/state/

OpenTofu: installation options: https://opentofu.org/docs/intro/install/

### Readiness and routing

Service routing selects Pods by labels, then forwards traffic to a target port. Readiness determines eligibility for traffic; liveness determines when a container should restart. Using an unstable dependency in liveness can create restart storms.

Mental model: A shop can have lights on but still be closed to customers.

Boundary: A health endpoint can be too shallow; it must reflect the service contract.

Worked example: This container listens on 8080; the Service accepts 80 and forwards to 8080.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: Kubernetes Service + probes

Course tool and framework map: 



After completing the existing kind setup, inspect selectors, targetPort and endpoint slices. Compare them with Pod labels and the application’s listening port.

Commands (after setup)

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get svc atlas-web -o yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods --show-labels
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get endpointslices
```

Expected: Selector labels match Pods, service port maps to the listening targetPort and ready endpoints are listed. Compare actual output with deployment.yaml.

Troubleshoot: Running Pod but no ready endpoints: Describe the Pod, inspect readiness results and match labels/ports. Do not remove readiness simply to hide the symptom.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/intermediate/readiness-and-routing.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Trace service port, targetPort, label selector and readiness in order.

new: Start by describing readiness and routing in your own words. After completing the existing kind setup, inspect selectors, targetPort and endpoint slices. Compare them with Pod labels and the application’s listening port. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for readiness and routing. Trace service port, targetPort, label selector and readiness in order. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect readiness and routing to one system you already know. Trace service port, targetPort, label selector and readiness in order. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain why a Running Pod might still receive no traffic.

Interview: Trace service port, targetPort, label selector and readiness in order.

Quiz: Should a temporarily unavailable downstream service always fail liveness?

Yes, restart every caller.

No; decide readiness separately and avoid a restart cascade.

Liveness and readiness are identical.

Reference: No; decide readiness separately and avoid a restart cascade. — Liveness should identify a condition a restart can fix. Readiness controls traffic admission.

Sources:

Kubernetes: readiness, startup and liveness: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/

### Immutable promotion

Build and verify an artifact once, then promote the same content digest through environments. A mutable tag can refer to different images at different times. Pinning identity does not eliminate vulnerabilities or bad configuration.

Mental model: A sealed parcel keeps the same serial number as it moves between depots.

Boundary: A mutable latest tag is not enough to prove what was tested; resolve and record the digest.

Worked example: The digest tested in staging must equal the digest proposed for release.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: Docker registry + Kubernetes

Course tool and framework map: 



Pull the introductory image, inspect RepoDigests and record the registry digest. In the existing local manifest, replace the image reference with your actual name@sha256 digest, then review the diff before applying.

Commands (after setup)

```
docker pull nginxinc/nginx-unprivileged:1.28-alpine
docker image inspect nginxinc/nginx-unprivileged:1.28-alpine --format "{{json .RepoDigests}}"
# After editing your local manifest with an actual digest:
git diff -- deployment.yaml
```

Expected: RepoDigests includes a registry-qualified name@sha256 value. Your manifest diff contains that actual value, not a fabricated placeholder. Apply only through the existing local lab instructions.

Troubleshoot: RepoDigests is empty: A locally built image may not have a registry manifest digest yet. Distinguish image content ID from registry digest; use the registry output after a deliberate push/pull.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/intermediate/immutable-promotion.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain the evidence connecting a commit, CI run, artifact digest and deployment.

new: Start by describing immutable promotion in your own words. Pull the introductory image, inspect RepoDigests and record the registry digest. In the existing local manifest, replace the image reference with your actual name@sha256 digest, then review the diff before applying. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for immutable promotion. Explain the evidence connecting a commit, CI run, artifact digest and deployment. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect immutable promotion to one system you already know. Explain the evidence connecting a commit, CI run, artifact digest and deployment. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A mutable latest tag is not enough to prove what was tested; resolve and record the digest.

Interview: Explain the evidence connecting a commit, CI run, artifact digest and deployment.

Quiz: Which promotion preserves tested artifact identity?

Rebuild separately for production.

Promote the exact tested registry digest.

Reuse a mutable tag without checking it.

Reference: Promote the exact tested registry digest. — Same source can build differently. Promote the tested artifact and separately review environment configuration.

Sources:

Docker: getting started: https://docs.docker.com/get-started/

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

### Infrastructure plans and state

State maps declared resources to actual objects. Treat it as sensitive operational data. Start with a built-in local resource so plan/apply behavior can be learned without a cloud bill; cloud providers add permissions, remote state and locking requirements.

Mental model: Configuration is the intended map; state connects map entries to actual resources; a plan is the proposed edit list.

Boundary: A plan is time-sensitive, and state is not a backup of the actual service data.

Worked example: A local terraform_data resource demonstrates create versus no-change plans without cloud credentials. Remote collaboration additionally requires access controls, locking and recovery.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: OpenTofu

Course tool and framework map: 



Install OpenTofu from its official documentation. Create a new empty folder and main.tf containing the shown resource. Run init, plan, apply the saved plan and plan again.

Save as main.tf in a new empty folder

```
resource "terraform_data" "lesson" {
  input = "atlas-lab"
}
```

Then run in the terminal in that folder

```
tofu init
tofu plan -out=lesson.plan
tofu apply lesson.plan
tofu plan
```

Expected: First plan proposes one local resource; second plan reports no changes. Preserve the plan/state privately. Cleanup: tofu destroy in this dedicated folder after reviewing its plan; no cloud resource is created.

Troubleshoot: A cloud resource appears in the plan: Stop: this exercise must use a new empty folder with only terraform_data. Inspect the configuration and workspace rather than approving unexpected changes.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/intermediate/infrastructure-plans-and-state.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain plan review, state protection and drift without claiming state is data backup.

new: Start by describing infrastructure plans and state in your own words. Install OpenTofu from its official documentation. Create a new empty folder and main.tf containing the shown resource. Run init, plan, apply the saved plan and plan again. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for infrastructure plans and state. Explain plan review, state protection and drift without claiming state is data backup. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect infrastructure plans and state to one system you already know. Explain plan review, state protection and drift without claiming state is data backup. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why should a state file not be committed to a public repository?

Interview: Explain plan review, state protection and drift without claiming state is data backup.

Quiz: Is infrastructure state a backup of application records?

Yes, it contains all service data.

No; it maps infrastructure identities and attributes.

Only when stored in Git.

Reference: No; it maps infrastructure identities and attributes. — State serves infrastructure reconciliation and may contain secrets. Back up service data separately.

Sources:

OpenTofu: infrastructure state: https://opentofu.org/docs/language/state/

OpenTofu: installation options: https://opentofu.org/docs/intro/install/

### Short-lived identity in deployment pipelines

Separate identity trust from authorization. A cloud provider must accept only intended workflow subjects, and the resulting role should grant only required deployment actions. Environment approvals and branch protections complement token lifetime.

Mental model: A temporary badge grants entry only through an explicitly trusted issuer and door.

Boundary: Short lifetime does not make overly broad authorization safe.

Worked example: A production deployment job requests id-token: write and contents: read; the cloud trust policy restricts the subject and production environment approval.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: GitHub Actions OIDC + cloud IAM

Course tool and framework map: 



Create a policy-review document for an example production workflow. Record issuer, audience, repository/environment subject, permitted actions and denied actions. Review the minimal workflow permission fragment.

Commands (after setup)

```
permissions:
  contents: read
  id-token: write
# Apply to the deployment job; this alone does not configure cloud trust.
# Use the provider’s documented authentication action and scoped role.
```

Expected: Deliver a trust-policy matrix and two negative tests: untrusted branch/repository denied; unrelated resource operation denied. No cloud credentials or deployment are included in this local exercise.

Troubleshoot: Workflow has id-token permission but cloud login fails: Compare issuer, audience and subject with the cloud trust policy and action configuration. Do not broaden trust to every repository as a shortcut.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/intermediate/short-lived-identity-in-deployment-pipelines.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain how you would test both denied identity and denied resource access.

new: Start by describing short-lived identity in deployment pipelines in your own words. Create a policy-review document for an example production workflow. Record issuer, audience, repository/environment subject, permitted actions and denied actions. Review the minimal workflow permission fragment. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for short-lived identity in deployment pipelines. Explain how you would test both denied identity and denied resource access. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect short-lived identity in deployment pipelines to one system you already know. Explain how you would test both denied identity and denied resource access. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Which two policies matter even when no long-lived cloud key is stored?

Interview: Explain how you would test both denied identity and denied resource access.

Quiz: OIDC login succeeds but role can delete unrelated resources. What is wrong?

Token lifetime only.

The authorization policy is too broad.

The pipeline needs a plaintext permanent key.

Reference: The authorization policy is too broad. — Federation trust controls who can assume a role; authorization controls allowed actions and resources.

Sources:

GitHub Actions: OpenID Connect: https://docs.github.com/en/actions/concepts/security/openid-connect

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Rollback and service objectives: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.

Release and rollback: A deployment needs a success signal, observation window and recovery action. Treat database and external side effects explicitly.

Deployment recovery gates: A rollout needs an observation window and a user-visible verification. Undoing a Deployment changes its Pod template but does not reverse external data effects.

### Reliability: calculate an error budget with units

An SLO states a measurable reliability objective over a defined window. An error budget is the permitted bad fraction of eligible work, not a promise that the service never fails.

How it works
A 99.9% request-success objective permits a 0.1% bad fraction. Compare bad requests with eligible requests; do not substitute downtime minutes into a request-based calculation.

Where the model stops
This arithmetic is not a recommended objective. Real indicators need precise eligibility, windows and no-data treatment.

Make one change
Recalculate with 125 bad requests and explain exhausted budget. Add a zero-traffic window and decide how to display unknown data without calling it perfect reliability.

Mental model: A quality allowance only makes sense with the same unit and accounting window as the work being measured.

Boundary: This arithmetic is not a recommended objective. Real indicators need precise eligibility, windows and no-data treatment.

Worked example: eligible=100000
bad=75
permitted=eligible*(1-0.999)
remaining=permitted-bad
assert round(permitted)==100
assert round(remaining)==25
print('Request budget remaining:',round(remaining))


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/error-budget. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: SLO worksheet; Prometheus and Grafana; commercial managed observability

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Recalculate with 125 bad requests and explain exhausted budget. Add a zero-traffic window and decide how to display unknown data without calling it perfect reliability.

Terminal folder: course-labs/advanced/error-budget

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. A 99.9% request-success objective permits a 0.1% bad fraction. Compare bad requests with eligible requests; do not substitute downtime minutes into a request-based calculation.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/error-budget. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The example permits about 100 bad requests and has 25 remaining. Your exhausted and no-data cases have distinct outcomes.

Build your change

Recalculate with 125 bad requests and explain exhausted budget. Add a zero-traffic window and decide how to display unknown data without calling it perfect reliability.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The example permits about 100 bad requests and has 25 remaining. Your exhausted and no-data cases have distinct outcomes.

Break, repair and explain

Deliberately violate this boundary: This arithmetic is not a recommended objective. Real indicators need precise eligibility, windows and no-data treatment. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The example permits about 100 bad requests and has 25 remaining. Your exhausted and no-data cases have distinct outcomes.

Troubleshoot: My result does not match Reliability: calculate an error budget with units: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: A 99.9% request-success objective permits a 0.1% bad fraction. Compare bad requests with eligible requests; do not substitute downtime minutes into a request-based calculation. Then inspect this limit: This arithmetic is not a recommended objective. Real indicators need precise eligibility, windows and no-data treatment. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/error-budget/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Reliability: calculate an error budget with units line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A quality allowance only makes sense with the same unit and accounting window as the work being measured.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Can downtime minutes be directly compared with a request-count budget? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: This arithmetic is not a recommended objective. Real indicators need precise eligibility, windows and no-data treatment. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Can downtime minutes be directly compared with a request-count budget?

Interview: Can downtime minutes be directly compared with a request-count budget? Defend your answer using your actual lab result and this boundary: This arithmetic is not a recommended objective. Real indicators need precise eligibility, windows and no-data treatment.

Quiz: Can downtime minutes be directly compared with a request-count budget?

Yes.

Only on weekends.

No, units and indicator definition must match.

Reference: No, units and indicator definition must match. — Time-based and request-based indicators answer different questions. Keep the denominator and accounting units explicit.

Sources:

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

### Progressive delivery: compare candidate and baseline

A canary release exposes a limited share of traffic to a candidate. Promotion depends on defined signals and sufficient evidence. A quiet candidate with almost no traffic is not automatically healthy.

How it works
The teaching gate checks minimum request volume and an allowed error-rate difference. It returns wait, promote or investigate instead of collapsing missing evidence into success.

Where the model stops
The thresholds are illustrative. Production comparisons require window alignment, confidence, latency, segmentation and guardrails.

Make one change
Add latency and a missing-metric state. Write a release decision with actual observations and a rollback owner; do not claim these sample thresholds are a universal standard.

Mental model: A trial branch of a shop needs enough real transactions before comparison is meaningful.

Boundary: The thresholds are illustrative. Production comparisons require window alignment, confidence, latency, segmentation and guardrails.

Worked example: def gate(base_errors,base_n,new_errors,new_n):
 if min(base_n,new_n)<100: return 'wait'
 return 'investigate' if new_errors/new_n-base_errors/base_n>0.01 else 'promote'
assert gate(1,1000,0,2)=='wait'
assert gate(1,1000,30,1000)=='investigate'
assert gate(1,1000,2,1000)=='promote'
print('PASS: insufficient, degraded and acceptable example windows')


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/release-progression. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Kubernetes rollout, canary metrics; alternatives Argo Rollouts / managed deployment services

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Add latency and a missing-metric state. Write a release decision with actual observations and a rollback owner; do not claim these sample thresholds are a universal standard.

Terminal folder: course-labs/advanced/release-progression

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. The teaching gate checks minimum request volume and an allowed error-rate difference. It returns wait, promote or investigate instead of collapsing missing evidence into success.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/release-progression. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: Insufficient traffic waits, a degraded candidate triggers investigation and the illustrative acceptable case promotes.

Build your change

Add latency and a missing-metric state. Write a release decision with actual observations and a rollback owner; do not claim these sample thresholds are a universal standard.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. Insufficient traffic waits, a degraded candidate triggers investigation and the illustrative acceptable case promotes.

Break, repair and explain

Deliberately violate this boundary: The thresholds are illustrative. Production comparisons require window alignment, confidence, latency, segmentation and guardrails. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: Insufficient traffic waits, a degraded candidate triggers investigation and the illustrative acceptable case promotes.

Troubleshoot: My result does not match Progressive delivery: compare candidate and baseline: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: The teaching gate checks minimum request volume and an allowed error-rate difference. It returns wait, promote or investigate instead of collapsing missing evidence into success. Then inspect this limit: The thresholds are illustrative. Production comparisons require window alignment, confidence, latency, segmentation and guardrails. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/release-progression/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Progressive delivery: compare candidate and baseline line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: A trial branch of a shop needs enough real transactions before comparison is meaningful.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: A canary saw zero errors in two requests. What is the strongest conclusion? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The thresholds are illustrative. Production comparisons require window alignment, confidence, latency, segmentation and guardrails. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A canary saw zero errors in two requests. What is the strongest conclusion?

Interview: A canary saw zero errors in two requests. What is the strongest conclusion? Defend your answer using your actual lab result and this boundary: The thresholds are illustrative. Production comparisons require window alignment, confidence, latency, segmentation and guardrails.

Quiz: A canary saw zero errors in two requests. What is the strongest conclusion?

There is insufficient evidence to establish reliability.

It is guaranteed safe.

The baseline is unnecessary.

Reference: There is insufficient evidence to establish reliability. — Small samples can hide serious failure rates. Define an evidence threshold before promotion.

Sources:

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

### Rollback: application and data versions differ

Rolling back an application image does not reverse a database migration or an external message. Compatibility between old code and new data must be planned before deployment.

How it works
An expand-and-contract change first adds a compatible field, then moves readers and writers, then removes the old field only when older versions no longer need it. Model the compatibility matrix explicitly.

Where the model stops
A compatibility table is planning evidence, not a tested migration. Backups need actual restore rehearsals.

Make one change
Design an old and new task title column migration. Write backfill verification and a rollback decision for each phase, then rehearse on synthetic data with both reader versions.

Mental model: Putting an old reader back on the desk does not restore the book pages it expects.

Boundary: A compatibility table is planning evidence, not a tested migration. Backups need actual restore rehearsals.

Worked example: supported={'v1':{'old','expanded'},'v2':{'expanded','new'}}
assert 'expanded' in supported['v1'] & supported['v2']
assert 'new' not in supported['v1']
print('PASS: expanded schema supports a mixed-version window; new-only does not')


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/rollback-data. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: Database migration tooling, Kubernetes rollout and backup/restore checks

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Design an old and new task title column migration. Write backfill verification and a rollback decision for each phase, then rehearse on synthetic data with both reader versions.

Terminal folder: course-labs/advanced/rollback-data

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. An expand-and-contract change first adds a compatible field, then moves readers and writers, then removes the old field only when older versions no longer need it. Model the compatibility matrix explicitly.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/rollback-data. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The matrix shows a mixed-version expanded state and an incompatible new-only rollback. Your rehearsal includes observed row counts and a restore limitation.

Build your change

Design an old and new task title column migration. Write backfill verification and a rollback decision for each phase, then rehearse on synthetic data with both reader versions.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The matrix shows a mixed-version expanded state and an incompatible new-only rollback. Your rehearsal includes observed row counts and a restore limitation.

Break, repair and explain

Deliberately violate this boundary: A compatibility table is planning evidence, not a tested migration. Backups need actual restore rehearsals. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The matrix shows a mixed-version expanded state and an incompatible new-only rollback. Your rehearsal includes observed row counts and a restore limitation.

Troubleshoot: My result does not match Rollback: application and data versions differ: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: An expand-and-contract change first adds a compatible field, then moves readers and writers, then removes the old field only when older versions no longer need it. Model the compatibility matrix explicitly. Then inspect this limit: A compatibility table is planning evidence, not a tested migration. Backups need actual restore rehearsals. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/rollback-data/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Rollback: application and data versions differ line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Putting an old reader back on the desk does not restore the book pages it expects.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Does reverting a container image automatically undo a schema migration? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: A compatibility table is planning evidence, not a tested migration. Backups need actual restore rehearsals. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does reverting a container image automatically undo a schema migration?

Interview: Does reverting a container image automatically undo a schema migration? Defend your answer using your actual lab result and this boundary: A compatibility table is planning evidence, not a tested migration. Backups need actual restore rehearsals.

Quiz: Does reverting a container image automatically undo a schema migration?

Yes.

No.

Only for small tables.

Reference: No. — Code, schema and external effects have separate lifecycles. Test compatibility and recovery explicitly.

Sources:

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

PostgreSQL: relational database tutorial: https://www.postgresql.org/docs/current/tutorial.html

### Incidents: separate observations from hypotheses

An incident record should show what was observed, what was suspected and what changed. A timestamped hypothesis is not yet a root cause. Preserve evidence before a repair changes the system.

How it works
Use a consistent time basis and order events. Tie a mitigation to a measured recovery signal. Keep the permanent repair and its regression check separate from the immediate mitigation.

Where the model stops
Temporal correlation does not prove causation. A postmortem needs evidence supporting the causal chain.

Make one change
Write an incident for the broken image-tag lab: symptom, events, hypothesis, diagnostic command, root cause evidence, recovery and a preventive check. Mark any unknown cause honestly.

Mental model: An investigation board uses different pins for witnessed facts and possible explanations.

Boundary: Temporal correlation does not prove causation. A postmortem needs evidence supporting the causal chain.

Worked example: events=[{'t':30,'kind':'recovery','note':'error rate normal'},{'t':10,'kind':'observation','note':'5xx elevated'},{'t':20,'kind':'mitigation','note':'reverted candidate'}]
ordered=sorted(events,key=lambda e:e['t'])
assert [e['kind'] for e in ordered]==['observation','mitigation','recovery']
assert all('password' not in e['note'] for e in ordered)
print(' -> '.join(e['kind'] for e in ordered))


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/incident-timeline. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: kubectl events/logs, OpenTelemetry traces and an incident worksheet

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Write an incident for the broken image-tag lab: symptom, events, hypothesis, diagnostic command, root cause evidence, recovery and a preventive check. Mark any unknown cause honestly.

Terminal folder: course-labs/advanced/incident-timeline

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Use a consistent time basis and order events. Tie a mitigation to a measured recovery signal. Keep the permanent repair and its regression check separate from the immediate mitigation.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/incident-timeline. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The example orders observation, mitigation and recovery. Your incident links each claim to an actual command result and a bounded conclusion.

Build your change

Write an incident for the broken image-tag lab: symptom, events, hypothesis, diagnostic command, root cause evidence, recovery and a preventive check. Mark any unknown cause honestly.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The example orders observation, mitigation and recovery. Your incident links each claim to an actual command result and a bounded conclusion.

Break, repair and explain

Deliberately violate this boundary: Temporal correlation does not prove causation. A postmortem needs evidence supporting the causal chain. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The example orders observation, mitigation and recovery. Your incident links each claim to an actual command result and a bounded conclusion.

Troubleshoot: My result does not match Incidents: separate observations from hypotheses: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Use a consistent time basis and order events. Tie a mitigation to a measured recovery signal. Keep the permanent repair and its regression check separate from the immediate mitigation. Then inspect this limit: Temporal correlation does not prove causation. A postmortem needs evidence supporting the causal chain. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/incident-timeline/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Incidents: separate observations from hypotheses line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: An investigation board uses different pins for witnessed facts and possible explanations.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: A deployment happened before an error spike. Is that alone a proven root cause? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: Temporal correlation does not prove causation. A postmortem needs evidence supporting the causal chain. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: A deployment happened before an error spike. Is that alone a proven root cause?

Interview: A deployment happened before an error spike. Is that alone a proven root cause? Defend your answer using your actual lab result and this boundary: Temporal correlation does not prove causation. A postmortem needs evidence supporting the causal chain.

Quiz: A deployment happened before an error spike. Is that alone a proven root cause?

Yes.

Only when both occur within a minute.

No; investigate a supported causal mechanism.

Reference: No; investigate a supported causal mechanism. — Correlation guides investigation but does not establish cause. Compare changes, traces, events and a reproduction or rollback observation.

Sources:

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

### Delivery security: minimise permissions and secret exposure

A delivery workflow is a privileged program. Limit its identity to the actions required by that job, and avoid giving untrusted contributions access to deployment secrets or elevated tokens.

How it works
Start with no workflow permissions and add job-specific rights when required. Prefer short-lived identity federation for authorised cloud deployment. A configuration review must include who can change and invoke the workflow.

Where the model stops
The local allowlist below does not evaluate a real IAM policy, detect all secrets or prove repository trust settings.

Make one change
Review the earlier CI workflow with an empty permission block. Write separate test and deploy job trust boundaries, list required OIDC claims and document how a pull request cannot assume a production role.

Mental model: Each worker receives only the keys needed for their assigned room and shift.

Boundary: The local allowlist below does not evaluate a real IAM policy, detect all secrets or prove repository trust settings.

Worked example: def review(permissions):
 return [name for name,value in permissions.items() if value=='write' and name not in {'id-token'}]
assert review({'contents':'read','id-token':'write'})==[]
assert review({'contents':'write','packages':'write'})==['contents','packages']
print('PASS: teaching policy flags broad write grants for review')


Setup: Download and extract devops.zip. Python 3.9+ standard library. Run python3 --version; on Windows use py --version and py exercise.py instead. Open a terminal in course-labs/advanced/least-privilege. The supplied reference file is exercise.py. Read it before running python3 exercise.py. Keep a copy before editing.

Tools for this exercise: GitHub Actions OIDC and cloud IAM; alternatives workload identity on other CI platforms

Course tool and framework map: GitHub Actions and Docker (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core); Kubernetes + kubectl + kind (Open source); OpenTofu (Open source); Prometheus + Grafana (Open source with commercial hosted offerings); GitHub Actions + cloud IAM (Commercial hosted service with usage allowances)

Original local teaching example with synthetic data. Examples labelled as policy models do not execute the named production system. Native commands run only in your own stated environment; no backend execution is provided by this website.

Review the earlier CI workflow with an empty permission block. Write separate test and deploy job trust boundaries, list required OIDC claims and document how a pull request cannot assume a production role.

Terminal folder: course-labs/advanced/least-privilege

```
python3 exercise.py
```

Predict before running

Read exercise.py. Write the expected output and identify the state changed by this example. Start with no workflow permissions and add job-specific rights when required. Prefer short-lived identity federation for authorised cloud deployment. A configuration review must include who can change and invoke the workflow.

Expected: A prediction in evidence.md, with one assumption you will check.

Run the reference

Use the stated runtime in course-labs/advanced/least-privilege. This checks the reference behaviour only.

```
python3 exercise.py
```

Run the exact downloaded source, then compare the actual observation with the stated contract.

Expected: The model flags broad writes. Your real review must inspect repository settings and cloud trust policy before claiming the deployment boundary is secure.

Build your change

Review the earlier CI workflow with an empty permission block. Write separate test and deploy job trust boundaries, list required OIDC claims and document how a pull request cannot assume a production role.

Expected: Your changed source and additional checks demonstrate the lesson rule; reference output alone is insufficient. The model flags broad writes. Your real review must inspect repository settings and cloud trust policy before claiming the deployment boundary is secure.

Break, repair and explain

Deliberately violate this boundary: The local allowlist below does not evaluate a real IAM policy, detect all secrets or prove repository trust settings. Record the failing case, one cause, your correction and the check that catches it.

Expected: evidence.md includes input, prediction, observed result, failure, repair, tool/runtime version and a bounded conclusion.

Expected: The model flags broad writes. Your real review must inspect repository settings and cloud trust policy before claiming the deployment boundary is secure.

Troubleshoot: My result does not match Delivery security: minimise permissions and secret exposure: Check the exact runtime and working folder first. Compare your first failing assertion or error with this rule: Start with no workflow permissions and add job-specific rights when required. Prefer short-lived identity federation for authorised cloud deployment. A configuration review must include who can change and invoke the workflow. Then inspect this limit: The local allowlist below does not evaluate a real IAM policy, detect all secrets or prove repository trust settings. Preserve the failing input and change one cause at a time.

Cleanup: Save your source and evidence. Temporary fixtures clean up their own temporary files; do not remove unrelated data. Stop only the local service you started. No cloud account or paid service is required for the reference example.

Deliverable: course-labs/advanced/least-privilege/evidence.md and changed source, including actual command output, one failed case, correction, limitations and sources.

new: Learn the words in the introduction first. Trace Delivery security: minimise permissions and secret exposure line by line, run the reference, then make only the first requested change. Ask the lesson tutor to explain this model: Each worker receives only the keys needed for their assigned room and shift.

seeker: Prepare a coursework example for DevOps Engineer. Answer this interview question before revealing the rubric: Does id-token: write alone authorise every cloud resource? Keep your changed source, test evidence and one debug story. On your résumé claim only observed learning-project results.

switcher: Compare this boundary with a system you already know: The local allowlist below does not evaluate a real IAM policy, detect all secrets or prove repository trust settings. Focus on the changed assumptions, then validate them with the lab rather than relying on familiarity with a tool name. Use only synthetic or authorised data.

Recall: Does id-token: write alone authorise every cloud resource?

Interview: Does id-token: write alone authorise every cloud resource? Defend your answer using your actual lab result and this boundary: The local allowlist below does not evaluate a real IAM policy, detect all secrets or prove repository trust settings.

Quiz: Does id-token: write alone authorise every cloud resource?

No; the cloud role trust and permission policies still decide access.

Yes.

Only with GitHub-hosted runners.

Reference: No; the cloud role trust and permission policies still decide access. — OIDC lets a job request an identity token. A provider verifies its claims and applies its own trust and permission policies.

Sources:

GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use

GitHub Actions: OpenID Connect: https://docs.github.com/en/actions/concepts/security/openid-connect

### Rollback and service objectives

A rollback changes application rollout state, not every external effect. Decide from user-visible symptoms, error-budget impact and migration compatibility. Preserve logs and exact artifact identity before recovery.

Mental model: A reversible road detour with traffic counters at both ends.

Boundary: A rollback may not undo database changes; release safety includes schema compatibility.

Worked example: Change the image to a nonexistent tag, inspect events and undo the rollout.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: Kubernetes rollout + incident evidence

Course tool and framework map: 



Use the advanced local lab’s intentional bad image and recovery. Before undoing, inspect rollout history, Pod events and the known-good revision. Record request evidence after recovery.

Commands (after setup)

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout history deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
# After confirming the previous local revision is compatible:
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Expected: The controller converges on a prior Pod template. Verify a real request via the lab port-forward; rollout status alone does not validate database state or user behavior.

Troubleshoot: No previous revision or incompatible database: Do not assume undo can recover. Use the known-good manifest/digest and a separately rehearsed data recovery or forward-fix plan.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/advanced/rollback-and-service-objectives.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Give a rollback decision with a compatibility constraint and observable acceptance test.

new: Start by describing rollback and service objectives in your own words. Use the advanced local lab’s intentional bad image and recovery. Before undoing, inspect rollout history, Pod events and the known-good revision. Record request evidence after recovery. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for rollback and service objectives. Give a rollback decision with a compatibility constraint and observable acceptance test. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect rollback and service objectives to one system you already know. Give a rollback decision with a compatibility constraint and observable acceptance test. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Which checks must pass after undoing a bad image?

Interview: Give a rollback decision with a compatibility constraint and observable acceptance test.

Quiz: What does rollout undo not reverse?

The previous Pod template selection.

External database changes and side effects.

The requested Deployment revision.

Reference: External database changes and side effects. — A Deployment rollback changes its Pod template history, not unrelated state.

Sources:

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

### Deployment recovery gates

A safe recovery gate checks more than container health. Distinguish an unavailable new Pod from an actual service outage: old ready replicas may still serve. Test degraded capacity, request errors and dependency health before declaring recovery.

Mental model: A detour has a return route, but deliveries already made remain delivered.

Boundary: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior.

Worked example: A nonexistent image produces an image-pull failure and a healthy prior replica may remain serving.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: kubectl + curl + incident timeline

Course tool and framework map: 



Create a small incident timeline using the advanced lab: attempted release, first event, available replica count, request result, recovery decision and final verification. Use read-only checks below.

Commands (after setup)

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get deploy,pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
# While the existing lab port-forward is running:
curl -i http://127.0.0.1:8136
```

Expected: Evidence distinguishes rollout failure from serving impact. Record whether old replicas continued serving; do not label every ImagePullBackOff a total outage.

Troubleshoot: No timestamps or user-impact evidence: Repeat the bounded local drill while capturing times and request results. Do not invent incident duration or production impact.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/advanced/deployment-recovery-gates.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Write a concise incident update separating observed facts, hypotheses and next checks.

new: Start by describing deployment recovery gates in your own words. Create a small incident timeline using the advanced lab: attempted release, first event, available replica count, request result, recovery decision and final verification. Use read-only checks below. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for deployment recovery gates. Write a concise incident update separating observed facts, hypotheses and next checks. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect deployment recovery gates to one system you already know. Write a concise incident update separating observed facts, hypotheses and next checks. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior.

Interview: Write a concise incident update separating observed facts, hypotheses and next checks.

Quiz: New Pod cannot pull its image; old replicas serve successfully. Which statement is accurate?

All users are definitely offline.

Rollout is impaired; measure serving impact separately.

The release is proven successful.

Reference: Rollout is impaired; measure serving impact separately. — Deployment health and service health are related but distinct. Capacity may still be reduced.

Sources:

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

### Service signals and error-budget decisions

Define an eligible request, a good event and a measurement window. For this exercise, good means an eligible request succeeded. Calculate failures and allowance before adding alerts. Production systems may need latency and availability objectives plus multiple burn windows.

Mental model: An SLO is a service promise with a limited error allowance, not a dashboard decoration.

Boundary: A tiny or biased sample can produce misleading percentages; a single metric cannot establish root cause.

Worked example: With 10,000 eligible requests and 50 failures, success is 99.5%. Against a 99.9% objective, the allowed failures are 10, so consumption is five times that allowance.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: Prometheus + Grafana

Course tool and framework map: 



Calculate the synthetic request SLI and error allowance. Write a Prometheus query sketch using your actual metric names, label filters and rate window; review counter resets and missing data.

Commands (after setup)

```
python3 - <<'PYCODE'
total, failures, target = 10000, 50, 0.999
allowed = total * (1 - target)
print(f"success={100*(total-failures)/total:.1f}%")
print(f"budget_multiple={failures/allowed:.1f}")
PYCODE
```

Expected: success=99.5% and budget_multiple=5.0. This is a finite synthetic window calculation, not a deployed alert or proof of long-term SLO compliance.

Troubleshoot: Dashboard ratio differs: Check numerator/denominator populations, time windows, excluded traffic and missing series. A different denominator changes the meaning.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/advanced/service-signals-and-error-budget-decisions.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain one actionable user-symptom alert and the follow-up diagnostic signals.

new: Start by describing service signals and error-budget decisions in your own words. Calculate the synthetic request SLI and error allowance. Write a Prometheus query sketch using your actual metric names, label filters and rate window; review counter resets and missing data. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for service signals and error-budget decisions. Explain one actionable user-symptom alert and the follow-up diagnostic signals. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect service signals and error-budget decisions to one system you already know. Explain one actionable user-symptom alert and the follow-up diagnostic signals. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why is a Pod count insufficient to decide whether users are affected?

Interview: Explain one actionable user-symptom alert and the follow-up diagnostic signals.

Quiz: What must be specified before reporting 99.9% availability?

Only a chart color.

Eligible events, success criteria and a time window.

Only CPU utilization.

Reference: Eligible events, success criteria and a time window. — An SLI is meaningful only with a defined population, measurement and window.

Sources:

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

Prometheus: recording rules: https://prometheus.io/docs/practices/rules/

### Recovery drills and platform guardrails

A recovery plan needs ownership, prerequisites, commands, verification and a stop condition. Test on an isolated copy and distinguish restoring infrastructure from recovering data. Track measured recovery time and latest recoverable data, then compare with objectives.

Mental model: A recovery runbook is a fire drill: a written exit route is useful only when people can follow it.

Boundary: A successful local drill does not prove regional failover, cloud permissions or production capacity.

Worked example: Restore a disposable copy, verify record counts and checksums, then run a business request. Record elapsed time and the last recovered transaction.

Setup: Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Tools for this exercise: Backup tooling + runbook + checksums

Course tool and framework map: 



Create a disposable evidence file, copy it as a snapshot and restore to a separate file. Compare hashes. Then extend the runbook for a real database using its supported consistent-backup and integrity checks.

Commands (after setup)

```
mkdir -p atlas-restore-lab
cd atlas-restore-lab
printf "transaction-001\n" > source.txt
cp source.txt snapshot.txt
cp snapshot.txt restored.txt
python3 - <<'PYCODE'
from pathlib import Path
import hashlib
for name in ["source.txt", "restored.txt"]:
 print(name, hashlib.sha256(Path(name).read_bytes()).hexdigest())
PYCODE
```

Expected: Both hashes match. Document start/end time and transaction-001 as the restored point. This file-copy demonstration does not establish database consistency or production disaster recovery.

Troubleshoot: Hashes match but business checks fail: Byte identity alone is insufficient. Verify schema, credentials, application compatibility and a representative request on the isolated restore.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/advanced/recovery-drills-and-platform-guardrails.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Describe a restore drill that cannot overwrite production and state its remaining limits.

new: Start by describing recovery drills and platform guardrails in your own words. Create a disposable evidence file, copy it as a snapshot and restore to a separate file. Compare hashes. Then extend the runbook for a real database using its supported consistent-backup and integrity checks. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for recovery drills and platform guardrails. Describe a restore drill that cannot overwrite production and state its remaining limits. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect recovery drills and platform guardrails to one system you already know. Describe a restore drill that cannot overwrite production and state its remaining limits. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: What distinguishes a verified restore from simply possessing a backup?

Interview: Describe a restore drill that cannot overwrite production and state its remaining limits.

Quiz: What is the strongest restore acceptance evidence?

The backup exists.

Restored data integrity, a working business request and measured recovery objectives.

A successful infrastructure plan alone.

Reference: Restored data integrity, a working business request and measured recovery objectives. — Recoverability spans data, application behavior and time; test all three.

Sources:

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

OpenTofu: infrastructure state: https://opentofu.org/docs/language/state/
