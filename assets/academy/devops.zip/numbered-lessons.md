# Numbered lesson workbook

Core lessons and original role workshops remain in README.md. Commands below require the stated setup; examples are learning environments, not production deployments.

## beginner

### Processes, ports and HTTP evidence
Use a disposable local server to separate network symptoms. A refused connection means no accessible listener at that address/port; an HTTP error means some server replied. Check method, path and response body, not just process existence.

Mental model: A port is a numbered door; a process is the worker behind it; an HTTP status is the worker’s reply.
Limit: A successful connection does not prove the business response is correct.

Practice: In a new temporary lab folder, create a text file and serve it on loopback. In another terminal, request the file and an absent path. Stop the server with Ctrl+C.
```
mkdir -p atlas-http-lab
cd atlas-http-lab
printf "ready\n" > health.txt
python3 -m http.server 8139 --bind 127.0.0.1
# Second terminal:
curl -i http://127.0.0.1:8139/health.txt
curl -i http://127.0.0.1:8139/missing.txt
```
Expected: health.txt returns 200 and ready; missing.txt returns 404. After stopping the server, curl reports connection failure. Use this dedicated folder only.
Troubleshooting: curl hangs or reports a proxy response: Confirm loopback address, port and proxy environment. Use curl --noproxy 127.0.0.1 for this local test if appropriate; do not disable organizational network protections globally.

Tools: Python local HTTP server + curl
Deliverable: devops/beginner/processes-ports-and-http-evidence.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Give your first three checks for connection refused versus HTTP 500.

new: Start by describing processes, ports and http evidence in your own words. In a new temporary lab folder, create a text file and serve it on loopback. In another terminal, request the file and an absent path. Stop the server with Ctrl+C. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for processes, ports and http evidence. Give your first three checks for connection refused versus HTTP 500. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect processes, ports and http evidence to one system you already know. Give your first three checks for connection refused versus HTTP 500. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: What does HTTP 500 establish?
A server responded with an internal error.
DNS definitely failed.
No process is listening.
Reference: A server responded with an internal error. — A received HTTP response is different from a transport error. Continue at the application boundary.
Sources: https://curl.se/docs/manpage.html

### Git changes and container boundaries
Inspect source diffs before building. Runtime environment variables, mounts and network settings can change behavior even for the same image. Use explicit loopback publishing and a named disposable container so cleanup is scoped.

Mental model: An image is a packaged recipe; a container is one running instance using it.
Limit: Containers are not complete virtual machines, and isolation is not a substitute for least privilege.

Practice: Install Docker using its official guide. Start the example container, inspect its image identity and logs, request the service and remove only this named instance.
```
docker run -d --name atlas-web-lesson -p 127.0.0.1:8140:80 nginx:stable-alpine
docker inspect atlas-web-lesson --format "{{.Image}}"
docker logs atlas-web-lesson
curl -I http://127.0.0.1:8140
docker rm -f atlas-web-lesson
```
Expected: HTTP response is 200; inspect prints an image content ID. Record the pulled version/digest because this introductory tag can change. Cleanup removes only atlas-web-lesson.
Troubleshooting: Container name already exists: Inspect the named container to determine if it belongs to your earlier exercise. Choose a new unique name or deliberately clean up your own instance; never run a global prune.

Tools: Docker Engine / Docker Desktop + Git
Deliverable: devops/beginner/git-changes-and-container-boundaries.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain image versus container and why configuration belongs in release evidence.

new: Start by describing git changes and container boundaries in your own words. Install Docker using its official guide. Start the example container, inspect its image identity and logs, request the service and remove only this named instance. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for git changes and container boundaries. Explain image versus container and why configuration belongs in release evidence. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect git changes and container boundaries to one system you already know. Explain image versus container and why configuration belongs in release evidence. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Which fact makes a release reproducible?
Only the tag latest.
A recorded immutable image digest plus runtime configuration.
The container name alone.
Reference: A recorded immutable image digest plus runtime configuration. — Tags can move; configuration also affects behavior. Record both artifact identity and relevant configuration.
Sources: https://docs.docker.com/get-started/ https://docs.docker.com/engine/security/ https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository

### Desired state
A controller repeatedly compares desired and observed state. A Deployment declares replica and Pod-template intent; the controller cannot invent a missing image or supply unlimited capacity. Inspect events before changing desired state.

Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.

Practice: Read the original level lab first. Use its dedicated kind cluster and kubeconfig. Inspect a Deployment and Pod events, then explain the desired/ready difference.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get deployment,pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
```
Expected: The Deployment shows desired and available replicas. Pending or image failures are visible in Pod/events output. Setup is in the existing Hands-on lab; these commands do not create a cluster.
Troubleshooting: No resources or wrong context: Check the exact local kubeconfig and namespace from the lab. Do not remove context flags or switch to a production cluster to make a command work.

Tools: Kubernetes kubectl + kind
Deliverable: devops/beginner/desired-state.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain desired, current and ready state separately.

new: Start by describing desired state in your own words. Read the original level lab first. Use its dedicated kind cluster and kubeconfig. Inspect a Deployment and Pod events, then explain the desired/ready difference. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for desired state. Explain desired, current and ready state separately. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect desired state to one system you already know. Explain desired, current and ready state separately. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Desired replicas=2 but ready=0. What next?
Keep increasing replicas blindly.
Inspect Pod status and events for the blocking condition.
Declare the service healthy.
Reference: Inspect Pod status and events for the blocking condition. — Controllers reconcile intent within constraints. Evidence identifies scheduling, image or readiness failures.
Sources: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

### Pipeline dependency gates
CI jobs can run independently unless dependencies are declared. A publish job needs successful checks; workflow permissions and triggers also matter. A skipped or ignored test result is not a safe promotion gate.

Mental model: An assembly line stops shipment when inspection fails.
Limit: Parallel jobs without needs can publish before tests finish; inspect the dependency graph.

Practice: Open the supplied role-workshop pipeline example. Draw its job dependency graph and add a publish job that requires test. Review the workflow below as a fragment to merge into jobs, not a complete file.
```
test:
  runs-on: ubuntu-latest
  steps:
    - run: exit 1
publish:
  needs: test
  runs-on: ubuntu-latest
  steps:
    - run: echo "publish placeholder"
```
Expected: In an isolated repository workflow with a push or manual trigger, test fails and publish is skipped. The echo is a placeholder, not an actual release.
Troubleshooting: publish still runs after test failure: Inspect needs, if: always() and continue-on-error. Remove success-bypassing behavior from the release gate; retain logs for diagnosis.

Tools: GitHub Actions
Deliverable: devops/beginner/pipeline-dependency-gates.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain how you would prevent a failed test from producing a release.

new: Start by describing pipeline dependency gates in your own words. Open the supplied role-workshop pipeline example. Draw its job dependency graph and add a publish job that requires test. Review the workflow below as a fragment to merge into jobs, not a complete file. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for pipeline dependency gates. Explain how you would prevent a failed test from producing a release. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect pipeline dependency gates to one system you already know. Explain how you would prevent a failed test from producing a release. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: What makes publish wait for a successful test job?
A similar job name.
needs: test without bypassing its success condition.
Placing it lower in the YAML file.
Reference: needs: test without bypassing its success condition. — Job order in a file does not define execution dependencies. needs establishes the dependency.
Sources: https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-jobs

## intermediate

### Readiness and routing
Service routing selects Pods by labels, then forwards traffic to a target port. Readiness determines eligibility for traffic; liveness determines when a container should restart. Using an unstable dependency in liveness can create restart storms.

Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.

Practice: After completing the existing kind setup, inspect selectors, targetPort and endpoint slices. Compare them with Pod labels and the application’s listening port.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get svc atlas-web -o yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods --show-labels
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get endpointslices
```
Expected: Selector labels match Pods, service port maps to the listening targetPort and ready endpoints are listed. Compare actual output with deployment.yaml.
Troubleshooting: Running Pod but no ready endpoints: Describe the Pod, inspect readiness results and match labels/ports. Do not remove readiness simply to hide the symptom.

Tools: Kubernetes Service + probes
Deliverable: devops/intermediate/readiness-and-routing.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Trace service port, targetPort, label selector and readiness in order.

new: Start by describing readiness and routing in your own words. After completing the existing kind setup, inspect selectors, targetPort and endpoint slices. Compare them with Pod labels and the application’s listening port. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for readiness and routing. Trace service port, targetPort, label selector and readiness in order. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect readiness and routing to one system you already know. Trace service port, targetPort, label selector and readiness in order. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Should a temporarily unavailable downstream service always fail liveness?
Yes, restart every caller.
No; decide readiness separately and avoid a restart cascade.
Liveness and readiness are identical.
Reference: No; decide readiness separately and avoid a restart cascade. — Liveness should identify a condition a restart can fix. Readiness controls traffic admission.
Sources: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/

### Immutable promotion
Build and verify an artifact once, then promote the same content digest through environments. A mutable tag can refer to different images at different times. Pinning identity does not eliminate vulnerabilities or bad configuration.

Mental model: A sealed parcel keeps the same serial number as it moves between depots.
Limit: A mutable latest tag is not enough to prove what was tested; resolve and record the digest.

Practice: Pull the introductory image, inspect RepoDigests and record the registry digest. In the existing local manifest, replace the image reference with your actual name@sha256 digest, then review the diff before applying.
```
docker pull nginxinc/nginx-unprivileged:1.28-alpine
docker image inspect nginxinc/nginx-unprivileged:1.28-alpine --format "{{json .RepoDigests}}"
# After editing your local manifest with an actual digest:
git diff -- deployment.yaml
```
Expected: RepoDigests includes a registry-qualified name@sha256 value. Your manifest diff contains that actual value, not a fabricated placeholder. Apply only through the existing local lab instructions.
Troubleshooting: RepoDigests is empty: A locally built image may not have a registry manifest digest yet. Distinguish image content ID from registry digest; use the registry output after a deliberate push/pull.

Tools: Docker registry + Kubernetes
Deliverable: devops/intermediate/immutable-promotion.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain the evidence connecting a commit, CI run, artifact digest and deployment.

new: Start by describing immutable promotion in your own words. Pull the introductory image, inspect RepoDigests and record the registry digest. In the existing local manifest, replace the image reference with your actual name@sha256 digest, then review the diff before applying. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for immutable promotion. Explain the evidence connecting a commit, CI run, artifact digest and deployment. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect immutable promotion to one system you already know. Explain the evidence connecting a commit, CI run, artifact digest and deployment. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Which promotion preserves tested artifact identity?
Rebuild separately for production.
Promote the exact tested registry digest.
Reuse a mutable tag without checking it.
Reference: Promote the exact tested registry digest. — Same source can build differently. Promote the tested artifact and separately review environment configuration.
Sources: https://docs.docker.com/get-started/ https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

### Infrastructure plans and state
State maps declared resources to actual objects. Treat it as sensitive operational data. Start with a built-in local resource so plan/apply behavior can be learned without a cloud bill; cloud providers add permissions, remote state and locking requirements.

Mental model: Configuration is the intended map; state connects map entries to actual resources; a plan is the proposed edit list.
Limit: A plan is time-sensitive, and state is not a backup of the actual service data.

Practice: Install OpenTofu from its official documentation. Create a new empty folder and main.tf containing the shown resource. Run init, plan, apply the saved plan and plan again.
```
# main.tf (HCL file content):
resource "terraform_data" "lesson" {
  input = "atlas-lab"
}
# Terminal in that dedicated folder:
tofu init
tofu plan -out=lesson.plan
tofu apply lesson.plan
tofu plan
```
Expected: First plan proposes one local resource; second plan reports no changes. Preserve the plan/state privately. Cleanup: tofu destroy in this dedicated folder after reviewing its plan; no cloud resource is created.
Troubleshooting: A cloud resource appears in the plan: Stop: this exercise must use a new empty folder with only terraform_data. Inspect the configuration and workspace rather than approving unexpected changes.

Tools: OpenTofu
Deliverable: devops/intermediate/infrastructure-plans-and-state.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain plan review, state protection and drift without claiming state is data backup.

new: Start by describing infrastructure plans and state in your own words. Install OpenTofu from its official documentation. Create a new empty folder and main.tf containing the shown resource. Run init, plan, apply the saved plan and plan again. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for infrastructure plans and state. Explain plan review, state protection and drift without claiming state is data backup. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect infrastructure plans and state to one system you already know. Explain plan review, state protection and drift without claiming state is data backup. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: Is infrastructure state a backup of application records?
Yes, it contains all service data.
No; it maps infrastructure identities and attributes.
Only when stored in Git.
Reference: No; it maps infrastructure identities and attributes. — State serves infrastructure reconciliation and may contain secrets. Back up service data separately.
Sources: https://opentofu.org/docs/language/state/ https://opentofu.org/docs/intro/install/

### Short-lived identity in deployment pipelines
Separate identity trust from authorization. A cloud provider must accept only intended workflow subjects, and the resulting role should grant only required deployment actions. Environment approvals and branch protections complement token lifetime.

Mental model: A temporary badge grants entry only through an explicitly trusted issuer and door.
Limit: Short lifetime does not make overly broad authorization safe.

Practice: Create a policy-review document for an example production workflow. Record issuer, audience, repository/environment subject, permitted actions and denied actions. Review the minimal workflow permission fragment.
```
permissions:
  contents: read
  id-token: write
# Apply to the deployment job; this alone does not configure cloud trust.
# Use the provider’s documented authentication action and scoped role.
```
Expected: Deliver a trust-policy matrix and two negative tests: untrusted branch/repository denied; unrelated resource operation denied. No cloud credentials or deployment are included in this local exercise.
Troubleshooting: Workflow has id-token permission but cloud login fails: Compare issuer, audience and subject with the cloud trust policy and action configuration. Do not broaden trust to every repository as a shortcut.

Tools: GitHub Actions OIDC + cloud IAM
Deliverable: devops/intermediate/short-lived-identity-in-deployment-pipelines.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain how you would test both denied identity and denied resource access.

new: Start by describing short-lived identity in deployment pipelines in your own words. Create a policy-review document for an example production workflow. Record issuer, audience, repository/environment subject, permitted actions and denied actions. Review the minimal workflow permission fragment. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for short-lived identity in deployment pipelines. Explain how you would test both denied identity and denied resource access. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect short-lived identity in deployment pipelines to one system you already know. Explain how you would test both denied identity and denied resource access. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: OIDC login succeeds but role can delete unrelated resources. What is wrong?
Token lifetime only.
The authorization policy is too broad.
The pipeline needs a plaintext permanent key.
Reference: The authorization policy is too broad. — Federation trust controls who can assume a role; authorization controls allowed actions and resources.
Sources: https://docs.github.com/en/actions/concepts/security/openid-connect

## advanced

### Rollback and service objectives
A rollback changes application rollout state, not every external effect. Decide from user-visible symptoms, error-budget impact and migration compatibility. Preserve logs and exact artifact identity before recovery.

Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.

Practice: Use the advanced local lab’s intentional bad image and recovery. Before undoing, inspect rollout history, Pod events and the known-good revision. Record request evidence after recovery.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout history deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
# After confirming the previous local revision is compatible:
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Expected: The controller converges on a prior Pod template. Verify a real request via the lab port-forward; rollout status alone does not validate database state or user behavior.
Troubleshooting: No previous revision or incompatible database: Do not assume undo can recover. Use the known-good manifest/digest and a separately rehearsed data recovery or forward-fix plan.

Tools: Kubernetes rollout + incident evidence
Deliverable: devops/advanced/rollback-and-service-objectives.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Give a rollback decision with a compatibility constraint and observable acceptance test.

new: Start by describing rollback and service objectives in your own words. Use the advanced local lab’s intentional bad image and recovery. Before undoing, inspect rollout history, Pod events and the known-good revision. Record request evidence after recovery. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for rollback and service objectives. Give a rollback decision with a compatibility constraint and observable acceptance test. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect rollback and service objectives to one system you already know. Give a rollback decision with a compatibility constraint and observable acceptance test. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: What does rollout undo not reverse?
The previous Pod template selection.
External database changes and side effects.
The requested Deployment revision.
Reference: External database changes and side effects. — A Deployment rollback changes its Pod template history, not unrelated state.
Sources: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/ https://sre.google/sre-book/monitoring-distributed-systems/

### Deployment recovery gates
A safe recovery gate checks more than container health. Distinguish an unavailable new Pod from an actual service outage: old ready replicas may still serve. Test degraded capacity, request errors and dependency health before declaring recovery.

Mental model: A detour has a return route, but deliveries already made remain delivered.
Limit: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior.

Practice: Create a small incident timeline using the advanced lab: attempted release, first event, available replica count, request result, recovery decision and final verification. Use read-only checks below.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get deploy,pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
# While the existing lab port-forward is running:
curl -i http://127.0.0.1:8136
```
Expected: Evidence distinguishes rollout failure from serving impact. Record whether old replicas continued serving; do not label every ImagePullBackOff a total outage.
Troubleshooting: No timestamps or user-impact evidence: Repeat the bounded local drill while capturing times and request results. Do not invent incident duration or production impact.

Tools: kubectl + curl + incident timeline
Deliverable: devops/advanced/deployment-recovery-gates.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Write a concise incident update separating observed facts, hypotheses and next checks.

new: Start by describing deployment recovery gates in your own words. Create a small incident timeline using the advanced lab: attempted release, first event, available replica count, request result, recovery decision and final verification. Use read-only checks below. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for deployment recovery gates. Write a concise incident update separating observed facts, hypotheses and next checks. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect deployment recovery gates to one system you already know. Write a concise incident update separating observed facts, hypotheses and next checks. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: New Pod cannot pull its image; old replicas serve successfully. Which statement is accurate?
All users are definitely offline.
Rollout is impaired; measure serving impact separately.
The release is proven successful.
Reference: Rollout is impaired; measure serving impact separately. — Deployment health and service health are related but distinct. Capacity may still be reduced.
Sources: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/ https://sre.google/sre-book/monitoring-distributed-systems/

### Service signals and error-budget decisions
Define an eligible request, a good event and a measurement window. For this exercise, good means an eligible request succeeded. Calculate failures and allowance before adding alerts. Production systems may need latency and availability objectives plus multiple burn windows.

Mental model: An SLO is a service promise with a limited error allowance, not a dashboard decoration.
Limit: A tiny or biased sample can produce misleading percentages; a single metric cannot establish root cause.

Practice: Calculate the synthetic request SLI and error allowance. Write a Prometheus query sketch using your actual metric names, label filters and rate window; review counter resets and missing data.
```
python3 - <<'PYCODE'
total, failures, target = 10000, 50, 0.999
allowed = total * (1 - target)
print(f"success={100*(total-failures)/total:.1f}%")
print(f"budget_multiple={failures/allowed:.1f}")
PYCODE
```
Expected: success=99.5% and budget_multiple=5.0. This is a finite synthetic window calculation, not a deployed alert or proof of long-term SLO compliance.
Troubleshooting: Dashboard ratio differs: Check numerator/denominator populations, time windows, excluded traffic and missing series. A different denominator changes the meaning.

Tools: Prometheus + Grafana
Deliverable: devops/advanced/service-signals-and-error-budget-decisions.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain one actionable user-symptom alert and the follow-up diagnostic signals.

new: Start by describing service signals and error-budget decisions in your own words. Calculate the synthetic request SLI and error allowance. Write a Prometheus query sketch using your actual metric names, label filters and rate window; review counter resets and missing data. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for service signals and error-budget decisions. Explain one actionable user-symptom alert and the follow-up diagnostic signals. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect service signals and error-budget decisions to one system you already know. Explain one actionable user-symptom alert and the follow-up diagnostic signals. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: What must be specified before reporting 99.9% availability?
Only a chart color.
Eligible events, success criteria and a time window.
Only CPU utilization.
Reference: Eligible events, success criteria and a time window. — An SLI is meaningful only with a defined population, measurement and window.
Sources: https://sre.google/sre-book/monitoring-distributed-systems/ https://prometheus.io/docs/practices/rules/

### Recovery drills and platform guardrails
A recovery plan needs ownership, prerequisites, commands, verification and a stop condition. Test on an isolated copy and distinguish restoring infrastructure from recovering data. Track measured recovery time and latest recoverable data, then compare with objectives.

Mental model: A recovery runbook is a fire drill: a written exit route is useful only when people can follow it.
Limit: A successful local drill does not prove regional failover, cloud permissions or production capacity.

Practice: Create a disposable evidence file, copy it as a snapshot and restore to a separate file. Compare hashes. Then extend the runbook for a real database using its supported consistent-backup and integrity checks.
```
mkdir -p atlas-restore-lab
cd atlas-restore-lab
printf "transaction-001\n" > source.txt
cp source.txt snapshot.txt
cp snapshot.txt restored.txt
python3 - <<'PYCODE'
from pathlib import Path
import hashlib
for name in ["source.txt", "restored.txt"]:
 print(name, hashlib.sha256(Path(name).read_bytes()).hexdigest())
PYCODE
```
Expected: Both hashes match. Document start/end time and transaction-001 as the restored point. This file-copy demonstration does not establish database consistency or production disaster recovery.
Troubleshooting: Hashes match but business checks fail: Byte identity alone is insufficient. Verify schema, credentials, application compatibility and a representative request on the isolated restore.

Tools: Backup tooling + runbook + checksums
Deliverable: devops/advanced/recovery-drills-and-platform-guardrails.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Describe a restore drill that cannot overwrite production and state its remaining limits.

new: Start by describing recovery drills and platform guardrails in your own words. Create a disposable evidence file, copy it as a snapshot and restore to a separate file. Compare hashes. Then extend the runbook for a real database using its supported consistent-backup and integrity checks. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.
seeker: Build interview evidence for recovery drills and platform guardrails. Describe a restore drill that cannot overwrite production and state its remaining limits. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.
switcher: Connect recovery drills and platform guardrails to one system you already know. Describe a restore drill that cannot overwrite production and state its remaining limits. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Quiz: What is the strongest restore acceptance evidence?
The backup exists.
Restored data integrity, a working business request and measured recovery objectives.
A successful infrastructure plan alone.
Reference: Restored data integrity, a working business request and measured recovery objectives. — Recoverability spans data, application behavior and time; test all three.
Sources: https://sre.google/sre-book/monitoring-distributed-systems/ https://opentofu.org/docs/language/state/
