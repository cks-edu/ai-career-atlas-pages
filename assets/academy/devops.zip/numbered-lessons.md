# DevOps Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Desired state: A controller compares the current system with a declared target and works to reconcile the difference.

Delivery pipeline: A pipeline makes the steps from change to checked artifact explicit and repeatable. A failed check should prevent later dependent release steps.

Pipeline dependency gates: A release pipeline represents dependencies between checks, packaging and deployment. A failed prerequisite must prevent publication of an unverified artifact.

### Processes, ports and HTTP evidence

Use a disposable local server to separate network symptoms. A refused connection means no accessible listener at that address/port; an HTTP error means some server replied. Check method, path and response body, not just process existence.

Mental model: A port is a numbered door; a process is the worker behind it; an HTTP status is the worker’s reply.

Boundary: A successful connection does not prove the business response is correct.

Worked example: Connection refused, HTTP 404 and HTTP 500 suggest different boundaries. Capture the exact error before restarting anything.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: Python local HTTP server + curl

Course tool and framework map: 



In a new temporary lab folder, create a text file and serve it on loopback. In another terminal, request the file and an absent path. Stop the server with Ctrl+C.

Commands (after setup)

```
mkdir -p atlas-http-lab
cd atlas-http-lab
printf "ready\n" > health.txt
python3 -m http.server 8139 --bind 127.0.0.1
# Second terminal:
curl -i http://127.0.0.1:8139/health.txt
curl -i http://127.0.0.1:8139/missing.txt
```

Expected: health.txt returns 200 and ready; missing.txt returns 404. After stopping the server, curl reports connection failure. Use this dedicated folder only.

Troubleshoot: curl hangs or reports a proxy response: Confirm loopback address, port and proxy environment. Use curl --noproxy 127.0.0.1 for this local test if appropriate; do not disable organizational network protections globally.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/beginner/processes-ports-and-http-evidence.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Give your first three checks for connection refused versus HTTP 500.

new: Start by describing processes, ports and http evidence in your own words. In a new temporary lab folder, create a text file and serve it on loopback. In another terminal, request the file and an absent path. Stop the server with Ctrl+C. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for processes, ports and http evidence. Give your first three checks for connection refused versus HTTP 500. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect processes, ports and http evidence to one system you already know. Give your first three checks for connection refused versus HTTP 500. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: How would you distinguish an unreachable listener from a wrong URL?

Interview: Give your first three checks for connection refused versus HTTP 500.

Quiz: What does HTTP 500 establish?

A server responded with an internal error.

DNS definitely failed.

No process is listening.

Reference: A server responded with an internal error. — A received HTTP response is different from a transport error. Continue at the application boundary.

Sources:

curl: command reference: https://curl.se/docs/manpage.html

### Git changes and container boundaries

Inspect source diffs before building. Runtime environment variables, mounts and network settings can change behavior even for the same image. Use explicit loopback publishing and a named disposable container so cleanup is scoped.

Mental model: An image is a packaged recipe; a container is one running instance using it.

Boundary: Containers are not complete virtual machines, and isolation is not a substitute for least privilege.

Worked example: Inspect a diff before committing. Publish a web container only on 127.0.0.1 for a local exercise; remove only that named container afterwards.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: Docker Engine / Docker Desktop + Git

Course tool and framework map: 



Install Docker using its official guide. Start the example container, inspect its image identity and logs, request the service and remove only this named instance.

Commands (after setup)

```
docker run -d --name atlas-web-lesson -p 127.0.0.1:8140:80 nginx:stable-alpine
docker inspect atlas-web-lesson --format "{{.Image}}"
docker logs atlas-web-lesson
curl -I http://127.0.0.1:8140
docker rm -f atlas-web-lesson
```

Expected: HTTP response is 200; inspect prints an image content ID. Record the pulled version/digest because this introductory tag can change. Cleanup removes only atlas-web-lesson.

Troubleshoot: Container name already exists: Inspect the named container to determine if it belongs to your earlier exercise. Choose a new unique name or deliberately clean up your own instance; never run a global prune.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/beginner/git-changes-and-container-boundaries.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain image versus container and why configuration belongs in release evidence.

new: Start by describing git changes and container boundaries in your own words. Install Docker using its official guide. Start the example container, inspect its image identity and logs, request the service and remove only this named instance. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for git changes and container boundaries. Explain image versus container and why configuration belongs in release evidence. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect git changes and container boundaries to one system you already know. Explain image versus container and why configuration belongs in release evidence. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why can two containers from one image behave differently?

Interview: Explain image versus container and why configuration belongs in release evidence.

Quiz: Which fact makes a release reproducible?

Only the tag latest.

A recorded immutable image digest plus runtime configuration.

The container name alone.

Reference: A recorded immutable image digest plus runtime configuration. — Tags can move; configuration also affects behavior. Record both artifact identity and relevant configuration.

Sources:

Docker: getting started: https://docs.docker.com/get-started/

Docker Engine security: https://docs.docker.com/engine/security/

Git: recording changes: https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository

### Desired state

A controller repeatedly compares desired and observed state. A Deployment declares replica and Pod-template intent; the controller cannot invent a missing image or supply unlimited capacity. Inspect events before changing desired state.

Mental model: A thermostat compares actual temperature with the set point.

Boundary: It cannot fix every cause: a missing image or insufficient resources still needs action.

Worked example: One replica means the controller tries to keep one Pod running.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: Kubernetes kubectl + kind

Course tool and framework map: 



Read the original level lab first. Use its dedicated kind cluster and kubeconfig. Inspect a Deployment and Pod events, then explain the desired/ready difference.

Commands (after setup)

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get deployment,pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
```

Expected: The Deployment shows desired and available replicas. Pending or image failures are visible in Pod/events output. Setup is in the existing Hands-on lab; these commands do not create a cluster.

Troubleshoot: No resources or wrong context: Check the exact local kubeconfig and namespace from the lab. Do not remove context flags or switch to a production cluster to make a command work.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/beginner/desired-state.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain desired, current and ready state separately.

new: Start by describing desired state in your own words. Read the original level lab first. Use its dedicated kind cluster and kubeconfig. Inspect a Deployment and Pod events, then explain the desired/ready difference. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for desired state. Explain desired, current and ready state separately. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect desired state to one system you already know. Explain desired, current and ready state separately. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: What happens when a Pod is deleted but its Deployment remains?

Interview: Explain desired, current and ready state separately.

Quiz: Desired replicas=2 but ready=0. What next?

Keep increasing replicas blindly.

Inspect Pod status and events for the blocking condition.

Declare the service healthy.

Reference: Inspect Pod status and events for the blocking condition. — Controllers reconcile intent within constraints. Evidence identifies scheduling, image or readiness failures.

Sources:

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

### Pipeline dependency gates

CI jobs can run independently unless dependencies are declared. A publish job needs successful checks; workflow permissions and triggers also matter. A skipped or ignored test result is not a safe promotion gate.

Mental model: An assembly line stops shipment when inspection fails.

Boundary: Parallel jobs without needs can publish before tests finish; inspect the dependency graph.

Worked example: A failing title test must block the package job.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: GitHub Actions

Course tool and framework map: 



Open the supplied role-workshop pipeline example. Draw its job dependency graph and add a publish job that requires test. Review the workflow below as a fragment to merge into jobs, not a complete file.

Commands (after setup)

```
test:
  runs-on: ubuntu-latest
  steps:
    - run: exit 1
publish:
  needs: test
  runs-on: ubuntu-latest
  steps:
    - run: echo "publish placeholder"
```

Expected: In an isolated repository workflow with a push or manual trigger, test fails and publish is skipped. The echo is a placeholder, not an actual release.

Troubleshoot: publish still runs after test failure: Inspect needs, if: always() and continue-on-error. Remove success-bypassing behavior from the release gate; retain logs for diagnosis.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/beginner/pipeline-dependency-gates.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain how you would prevent a failed test from producing a release.

new: Start by describing pipeline dependency gates in your own words. Open the supplied role-workshop pipeline example. Draw its job dependency graph and add a publish job that requires test. Review the workflow below as a fragment to merge into jobs, not a complete file. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for pipeline dependency gates. Explain how you would prevent a failed test from producing a release. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect pipeline dependency gates to one system you already know. Explain how you would prevent a failed test from producing a release. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Parallel jobs without needs can publish before tests finish; inspect the dependency graph.

Interview: Explain how you would prevent a failed test from producing a release.

Quiz: What makes publish wait for a successful test job?

A similar job name.

needs: test without bypassing its success condition.

Placing it lower in the YAML file.

Reference: needs: test without bypassing its success condition. — Job order in a file does not define execution dependencies. needs establishes the dependency.

Sources:

GitHub Actions: jobs and dependencies: https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-jobs

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Readiness and routing: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.

Artifact and environment: Build a versioned artifact, then supply environment configuration separately. Record the exact artifact that was deployed.

Immutable promotion: Identify artifacts by content digest and separate configuration from the build. Rebuilding the same tag for another environment produces a different artifact with weaker provenance.

### Readiness and routing

Service routing selects Pods by labels, then forwards traffic to a target port. Readiness determines eligibility for traffic; liveness determines when a container should restart. Using an unstable dependency in liveness can create restart storms.

Mental model: A shop can have lights on but still be closed to customers.

Boundary: A health endpoint can be too shallow; it must reflect the service contract.

Worked example: This container listens on 8080; the Service accepts 80 and forwards to 8080.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: Kubernetes Service + probes

Course tool and framework map: 



After completing the existing kind setup, inspect selectors, targetPort and endpoint slices. Compare them with Pod labels and the application’s listening port.

Commands (after setup)

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get svc atlas-web -o yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods --show-labels
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get endpointslices
```

Expected: Selector labels match Pods, service port maps to the listening targetPort and ready endpoints are listed. Compare actual output with deployment.yaml.

Troubleshoot: Running Pod but no ready endpoints: Describe the Pod, inspect readiness results and match labels/ports. Do not remove readiness simply to hide the symptom.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/intermediate/readiness-and-routing.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Trace service port, targetPort, label selector and readiness in order.

new: Start by describing readiness and routing in your own words. After completing the existing kind setup, inspect selectors, targetPort and endpoint slices. Compare them with Pod labels and the application’s listening port. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for readiness and routing. Trace service port, targetPort, label selector and readiness in order. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect readiness and routing to one system you already know. Trace service port, targetPort, label selector and readiness in order. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain why a Running Pod might still receive no traffic.

Interview: Trace service port, targetPort, label selector and readiness in order.

Quiz: Should a temporarily unavailable downstream service always fail liveness?

Yes, restart every caller.

No; decide readiness separately and avoid a restart cascade.

Liveness and readiness are identical.

Reference: No; decide readiness separately and avoid a restart cascade. — Liveness should identify a condition a restart can fix. Readiness controls traffic admission.

Sources:

Kubernetes: readiness, startup and liveness: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/

### Immutable promotion

Build and verify an artifact once, then promote the same content digest through environments. A mutable tag can refer to different images at different times. Pinning identity does not eliminate vulnerabilities or bad configuration.

Mental model: A sealed parcel keeps the same serial number as it moves between depots.

Boundary: A mutable latest tag is not enough to prove what was tested; resolve and record the digest.

Worked example: The digest tested in staging must equal the digest proposed for release.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: Docker registry + Kubernetes

Course tool and framework map: 



Pull the introductory image, inspect RepoDigests and record the registry digest. In the existing local manifest, replace the image reference with your actual name@sha256 digest, then review the diff before applying.

Commands (after setup)

```
docker pull nginxinc/nginx-unprivileged:1.28-alpine
docker image inspect nginxinc/nginx-unprivileged:1.28-alpine --format "{{json .RepoDigests}}"
# After editing your local manifest with an actual digest:
git diff -- deployment.yaml
```

Expected: RepoDigests includes a registry-qualified name@sha256 value. Your manifest diff contains that actual value, not a fabricated placeholder. Apply only through the existing local lab instructions.

Troubleshoot: RepoDigests is empty: A locally built image may not have a registry manifest digest yet. Distinguish image content ID from registry digest; use the registry output after a deliberate push/pull.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/intermediate/immutable-promotion.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain the evidence connecting a commit, CI run, artifact digest and deployment.

new: Start by describing immutable promotion in your own words. Pull the introductory image, inspect RepoDigests and record the registry digest. In the existing local manifest, replace the image reference with your actual name@sha256 digest, then review the diff before applying. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for immutable promotion. Explain the evidence connecting a commit, CI run, artifact digest and deployment. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect immutable promotion to one system you already know. Explain the evidence connecting a commit, CI run, artifact digest and deployment. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A mutable latest tag is not enough to prove what was tested; resolve and record the digest.

Interview: Explain the evidence connecting a commit, CI run, artifact digest and deployment.

Quiz: Which promotion preserves tested artifact identity?

Rebuild separately for production.

Promote the exact tested registry digest.

Reuse a mutable tag without checking it.

Reference: Promote the exact tested registry digest. — Same source can build differently. Promote the tested artifact and separately review environment configuration.

Sources:

Docker: getting started: https://docs.docker.com/get-started/

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

### Infrastructure plans and state

State maps declared resources to actual objects. Treat it as sensitive operational data. Start with a built-in local resource so plan/apply behavior can be learned without a cloud bill; cloud providers add permissions, remote state and locking requirements.

Mental model: Configuration is the intended map; state connects map entries to actual resources; a plan is the proposed edit list.

Boundary: A plan is time-sensitive, and state is not a backup of the actual service data.

Worked example: A local terraform_data resource demonstrates create versus no-change plans without cloud credentials. Remote collaboration additionally requires access controls, locking and recovery.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: OpenTofu

Course tool and framework map: 



Install OpenTofu from its official documentation. Create a new empty folder and main.tf containing the shown resource. Run init, plan, apply the saved plan and plan again.

Save as main.tf in a new empty folder

```
resource "terraform_data" "lesson" {
  input = "atlas-lab"
}
```

Then run in the terminal in that folder

```
tofu init
tofu plan -out=lesson.plan
tofu apply lesson.plan
tofu plan
```

Expected: First plan proposes one local resource; second plan reports no changes. Preserve the plan/state privately. Cleanup: tofu destroy in this dedicated folder after reviewing its plan; no cloud resource is created.

Troubleshoot: A cloud resource appears in the plan: Stop: this exercise must use a new empty folder with only terraform_data. Inspect the configuration and workspace rather than approving unexpected changes.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/intermediate/infrastructure-plans-and-state.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain plan review, state protection and drift without claiming state is data backup.

new: Start by describing infrastructure plans and state in your own words. Install OpenTofu from its official documentation. Create a new empty folder and main.tf containing the shown resource. Run init, plan, apply the saved plan and plan again. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for infrastructure plans and state. Explain plan review, state protection and drift without claiming state is data backup. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect infrastructure plans and state to one system you already know. Explain plan review, state protection and drift without claiming state is data backup. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why should a state file not be committed to a public repository?

Interview: Explain plan review, state protection and drift without claiming state is data backup.

Quiz: Is infrastructure state a backup of application records?

Yes, it contains all service data.

No; it maps infrastructure identities and attributes.

Only when stored in Git.

Reference: No; it maps infrastructure identities and attributes. — State serves infrastructure reconciliation and may contain secrets. Back up service data separately.

Sources:

OpenTofu: infrastructure state: https://opentofu.org/docs/language/state/

OpenTofu: installation options: https://opentofu.org/docs/intro/install/

### Short-lived identity in deployment pipelines

Separate identity trust from authorization. A cloud provider must accept only intended workflow subjects, and the resulting role should grant only required deployment actions. Environment approvals and branch protections complement token lifetime.

Mental model: A temporary badge grants entry only through an explicitly trusted issuer and door.

Boundary: Short lifetime does not make overly broad authorization safe.

Worked example: A production deployment job requests id-token: write and contents: read; the cloud trust policy restricts the subject and production environment approval.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: GitHub Actions OIDC + cloud IAM

Course tool and framework map: 



Create a policy-review document for an example production workflow. Record issuer, audience, repository/environment subject, permitted actions and denied actions. Review the minimal workflow permission fragment.

Commands (after setup)

```
permissions:
  contents: read
  id-token: write
# Apply to the deployment job; this alone does not configure cloud trust.
# Use the provider’s documented authentication action and scoped role.
```

Expected: Deliver a trust-policy matrix and two negative tests: untrusted branch/repository denied; unrelated resource operation denied. No cloud credentials or deployment are included in this local exercise.

Troubleshoot: Workflow has id-token permission but cloud login fails: Compare issuer, audience and subject with the cloud trust policy and action configuration. Do not broaden trust to every repository as a shortcut.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/intermediate/short-lived-identity-in-deployment-pipelines.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain how you would test both denied identity and denied resource access.

new: Start by describing short-lived identity in deployment pipelines in your own words. Create a policy-review document for an example production workflow. Record issuer, audience, repository/environment subject, permitted actions and denied actions. Review the minimal workflow permission fragment. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for short-lived identity in deployment pipelines. Explain how you would test both denied identity and denied resource access. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect short-lived identity in deployment pipelines to one system you already know. Explain how you would test both denied identity and denied resource access. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Which two policies matter even when no long-lived cloud key is stored?

Interview: Explain how you would test both denied identity and denied resource access.

Quiz: OIDC login succeeds but role can delete unrelated resources. What is wrong?

Token lifetime only.

The authorization policy is too broad.

The pipeline needs a plaintext permanent key.

Reference: The authorization policy is too broad. — Federation trust controls who can assume a role; authorization controls allowed actions and resources.

Sources:

GitHub Actions: OpenID Connect: https://docs.github.com/en/actions/concepts/security/openid-connect

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Rollback and service objectives: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.

Release and rollback: A deployment needs a success signal, observation window and recovery action. Treat database and external side effects explicitly.

Deployment recovery gates: A rollout needs an observation window and a user-visible verification. Undoing a Deployment changes its Pod template but does not reverse external data effects.

### Rollback and service objectives

A rollback changes application rollout state, not every external effect. Decide from user-visible symptoms, error-budget impact and migration compatibility. Preserve logs and exact artifact identity before recovery.

Mental model: A reversible road detour with traffic counters at both ends.

Boundary: A rollback may not undo database changes; release safety includes schema compatibility.

Worked example: Change the image to a nonexistent tag, inspect events and undo the rollout.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: Kubernetes rollout + incident evidence

Course tool and framework map: 



Use the advanced local lab’s intentional bad image and recovery. Before undoing, inspect rollout history, Pod events and the known-good revision. Record request evidence after recovery.

Commands (after setup)

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout history deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
# After confirming the previous local revision is compatible:
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Expected: The controller converges on a prior Pod template. Verify a real request via the lab port-forward; rollout status alone does not validate database state or user behavior.

Troubleshoot: No previous revision or incompatible database: Do not assume undo can recover. Use the known-good manifest/digest and a separately rehearsed data recovery or forward-fix plan.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/advanced/rollback-and-service-objectives.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Give a rollback decision with a compatibility constraint and observable acceptance test.

new: Start by describing rollback and service objectives in your own words. Use the advanced local lab’s intentional bad image and recovery. Before undoing, inspect rollout history, Pod events and the known-good revision. Record request evidence after recovery. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for rollback and service objectives. Give a rollback decision with a compatibility constraint and observable acceptance test. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect rollback and service objectives to one system you already know. Give a rollback decision with a compatibility constraint and observable acceptance test. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Which checks must pass after undoing a bad image?

Interview: Give a rollback decision with a compatibility constraint and observable acceptance test.

Quiz: What does rollout undo not reverse?

The previous Pod template selection.

External database changes and side effects.

The requested Deployment revision.

Reference: External database changes and side effects. — A Deployment rollback changes its Pod template history, not unrelated state.

Sources:

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

### Deployment recovery gates

A safe recovery gate checks more than container health. Distinguish an unavailable new Pod from an actual service outage: old ready replicas may still serve. Test degraded capacity, request errors and dependency health before declaring recovery.

Mental model: A detour has a return route, but deliveries already made remain delivered.

Boundary: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior.

Worked example: A nonexistent image produces an image-pull failure and a healthy prior replica may remain serving.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: kubectl + curl + incident timeline

Course tool and framework map: 



Create a small incident timeline using the advanced lab: attempted release, first event, available replica count, request result, recovery decision and final verification. Use read-only checks below.

Commands (after setup)

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get deploy,pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
# While the existing lab port-forward is running:
curl -i http://127.0.0.1:8136
```

Expected: Evidence distinguishes rollout failure from serving impact. Record whether old replicas continued serving; do not label every ImagePullBackOff a total outage.

Troubleshoot: No timestamps or user-impact evidence: Repeat the bounded local drill while capturing times and request results. Do not invent incident duration or production impact.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/advanced/deployment-recovery-gates.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Write a concise incident update separating observed facts, hypotheses and next checks.

new: Start by describing deployment recovery gates in your own words. Create a small incident timeline using the advanced lab: attempted release, first event, available replica count, request result, recovery decision and final verification. Use read-only checks below. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for deployment recovery gates. Write a concise incident update separating observed facts, hypotheses and next checks. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect deployment recovery gates to one system you already know. Write a concise incident update separating observed facts, hypotheses and next checks. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not infer outage only from one bad Pod; inspect available replicas and actual service behavior.

Interview: Write a concise incident update separating observed facts, hypotheses and next checks.

Quiz: New Pod cannot pull its image; old replicas serve successfully. Which statement is accurate?

All users are definitely offline.

Rollout is impaired; measure serving impact separately.

The release is proven successful.

Reference: Rollout is impaired; measure serving impact separately. — Deployment health and service health are related but distinct. Capacity may still be reduced.

Sources:

Kubernetes: Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

### Service signals and error-budget decisions

Define an eligible request, a good event and a measurement window. For this exercise, good means an eligible request succeeded. Calculate failures and allowance before adding alerts. Production systems may need latency and availability objectives plus multiple burn windows.

Mental model: An SLO is a service promise with a limited error allowance, not a dashboard decoration.

Boundary: A tiny or biased sample can produce misleading percentages; a single metric cannot establish root cause.

Worked example: With 10,000 eligible requests and 50 failures, success is 99.5%. Against a 99.9% objective, the allowed failures are 10, so consumption is five times that allowance.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: Prometheus + Grafana

Course tool and framework map: 



Calculate the synthetic request SLI and error allowance. Write a Prometheus query sketch using your actual metric names, label filters and rate window; review counter resets and missing data.

Commands (after setup)

```
python3 - <<'PYCODE'
total, failures, target = 10000, 50, 0.999
allowed = total * (1 - target)
print(f"success={100*(total-failures)/total:.1f}%")
print(f"budget_multiple={failures/allowed:.1f}")
PYCODE
```

Expected: success=99.5% and budget_multiple=5.0. This is a finite synthetic window calculation, not a deployed alert or proof of long-term SLO compliance.

Troubleshoot: Dashboard ratio differs: Check numerator/denominator populations, time windows, excluded traffic and missing series. A different denominator changes the meaning.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/advanced/service-signals-and-error-budget-decisions.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Explain one actionable user-symptom alert and the follow-up diagnostic signals.

new: Start by describing service signals and error-budget decisions in your own words. Calculate the synthetic request SLI and error allowance. Write a Prometheus query sketch using your actual metric names, label filters and rate window; review counter resets and missing data. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for service signals and error-budget decisions. Explain one actionable user-symptom alert and the follow-up diagnostic signals. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect service signals and error-budget decisions to one system you already know. Explain one actionable user-symptom alert and the follow-up diagnostic signals. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: Why is a Pod count insufficient to decide whether users are affected?

Interview: Explain one actionable user-symptom alert and the follow-up diagnostic signals.

Quiz: What must be specified before reporting 99.9% availability?

Only a chart color.

Eligible events, success criteria and a time window.

Only CPU utilization.

Reference: Eligible events, success criteria and a time window. — An SLI is meaningful only with a defined population, measurement and window.

Sources:

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

Prometheus: recording rules: https://prometheus.io/docs/practices/rules/

### Recovery drills and platform guardrails

A recovery plan needs ownership, prerequisites, commands, verification and a stop condition. Test on an isolated copy and distinguish restoring infrastructure from recovering data. Track measured recovery time and latest recoverable data, then compare with objectives.

Mental model: A recovery runbook is a fire drill: a written exit route is useful only when people can follow it.

Boundary: A successful local drill does not prove regional failover, cloud permissions or production capacity.

Worked example: Restore a disposable copy, verify record counts and checksums, then run a business request. Record elapsed time and the last recovered transaction.

Setup: Use a terminal in a dedicated lab folder. Linux/macOS shell commands also work in WSL on Windows. Install only the tools introduced by the current lesson from the linked official documentation. The Kubernetes exercises require the original Hands-on lab setup and its dedicated atlas-kubeconfig; never use a work or production cluster. Cloud identity exercises are policy-design tasks unless you have an authorized sandbox.

Tools for this exercise: Backup tooling + runbook + checksums

Course tool and framework map: 



Create a disposable evidence file, copy it as a snapshot and restore to a separate file. Compare hashes. Then extend the runbook for a real database using its supported consistent-backup and integrity checks.

Commands (after setup)

```
mkdir -p atlas-restore-lab
cd atlas-restore-lab
printf "transaction-001\n" > source.txt
cp source.txt snapshot.txt
cp snapshot.txt restored.txt
python3 - <<'PYCODE'
from pathlib import Path
import hashlib
for name in ["source.txt", "restored.txt"]:
 print(name, hashlib.sha256(Path(name).read_bytes()).hexdigest())
PYCODE
```

Expected: Both hashes match. Document start/end time and transaction-001 as the restored point. This file-copy demonstration does not establish database consistency or production disaster recovery.

Troubleshoot: Hashes match but business checks fail: Byte identity alone is insufficient. Verify schema, credentials, application compatibility and a representative request on the isolated restore.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: devops/advanced/recovery-drills-and-platform-guardrails.md: prediction, environment/version, commands or configuration, observed result, one failure and recovery, source links, and your answer to: Describe a restore drill that cannot overwrite production and state its remaining limits.

new: Start by describing recovery drills and platform guardrails in your own words. Create a disposable evidence file, copy it as a snapshot and restore to a separate file. Compare hashes. Then extend the runbook for a real database using its supported consistent-backup and integrity checks. If a command or word is unfamiliar, use the linked reference before continuing. Keep one normal and one failure observation.

seeker: Build interview evidence for recovery drills and platform guardrails. Describe a restore drill that cannot overwrite production and state its remaining limits. Save the exact inputs, observed results and recovery in your portfolio; label this a learning exercise, not employment experience.

switcher: Connect recovery drills and platform guardrails to one system you already know. Describe a restore drill that cannot overwrite production and state its remaining limits. Compare the boundary, alternative and operational risk. Reproduce the exercise before claiming the skill transfers.

Recall: What distinguishes a verified restore from simply possessing a backup?

Interview: Describe a restore drill that cannot overwrite production and state its remaining limits.

Quiz: What is the strongest restore acceptance evidence?

The backup exists.

Restored data integrity, a working business request and measured recovery objectives.

A successful infrastructure plan alone.

Reference: Restored data integrity, a working business request and measured recovery objectives. — Recoverability spans data, application behavior and time; test all three.

Sources:

Google SRE: monitoring distributed systems: https://sre.google/sre-book/monitoring-distributed-systems/

OpenTofu: infrastructure state: https://opentofu.org/docs/language/state/
