# Software Test Analyst — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Test cases and oracles

A test oracle is the rule used to judge an observed result. State input, action and expected behavior before running so the result cannot be redefined to match the implementation.
Mental model: A marked measuring stick must exist before measuring the object.
Case: Blank title: zero new tasks and a readable error; valid title: exactly one task.
Task: Run the web reference and write cases for blank, whitespace, normal, 80-character and 81-character titles. Execute them individually from a known empty state.
Acceptance: Five expected/actual rows with timestamps and reproducible inputs.
Troubleshooting: Unclear requirements require an explicit assumption, not an invented pass.
Deliverable: test-cases.csv with evidence links

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Reproducible defect reports

A defect report needs the smallest reliable reproduction, environment, impact and expected versus actual behavior. Severity describes harm; priority describes when the team should act.
Mental model: A repair request must identify both the broken part and how to observe the fault.
Case: A double click that creates two tasks is different from an unreadable button label.
Task: Test rapid submission and server unavailability. Capture one reproducible defect or record that it did not reproduce; reduce steps and specify data/reset conditions.
Acceptance: Another person can repeat the stated observation without guessing.
Troubleshooting: Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause.
Deliverable: defect report and reproduction checklist

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Risk-based release decisions

A release decision considers harmful failures and untested areas, not simply a pass percentage. Document who accepts residual risk and what post-release signal triggers recovery.
Mental model: A car with polished paint still fails inspection if its brakes do not work.
Case: A data-loss defect can block release despite 99 passing cosmetic tests.
Task: Rank loss, duplication, accessibility and outage risks for the task app. Map each to evidence, mark unexecuted cases and write a ship/hold decision with a recovery trigger.
Acceptance: A traceable decision that names unresolved high-impact risks.
Troubleshooting: A green total hides missing coverage; inspect which user outcomes were actually tested.
Deliverable: release-quality report and risk matrix

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
