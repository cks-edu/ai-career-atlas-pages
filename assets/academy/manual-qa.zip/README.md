# Software Test Analyst

Software Engineering

Start with test cases and oracles. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward release-quality report and risk matrix.

## beginner

Run the web reference and write cases for blank, whitespace, normal, 80-character and 81-character titles. Execute them individually from a known empty state.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Observable behavior
A test compares a defined observation with an expected result for a chosen input.
Mental model: A recipe with a taste check rather than a photograph of ingredients.
Limit: Passing examples do not prove every possible input works.
Example: An empty task must not be added and the error must be understandable.
Recall: Write a test case with input, action and expected observation.

### Test cases and oracles
A test oracle is the rule used to judge an observed result. State input, action and expected behavior before running so the result cannot be redefined to match the implementation.
Mental model: A marked measuring stick must exist before measuring the object.
Limit: Unclear requirements require an explicit assumption, not an invented pass.
Example: Blank title: zero new tasks and a readable error; valid title: exactly one task.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Unclear requirements require an explicit assumption, not an invented pass.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Blank title: zero new tasks and a readable error; valid title: exactly one task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run the web reference and write cases for blank, whitespace, normal, 80-character and 81-character titles. Execute them individually from a known empty state.
Expected: Five expected/actual rows with timestamps and reproducible inputs.

6. Role workshop · debug and verify
Unclear requirements require an explicit assumption, not an invented pass. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save test-cases.csv with evidence links. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Five expected/actual rows with timestamps and reproducible inputs.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Test cases and oracles: Unclear requirements require an explicit assumption, not an invented pass.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: test-cases.csv with evidence links
Five expected/actual rows with timestamps and reproducible inputs.

Interview: Work through this Software Test Analyst case: Blank title: zero new tasks and a readable error; valid title: exactly one task. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A test oracle is the rule used to judge an observed result. State input, action and expected behavior before running so the result cannot be redefined to match the implementation. Expected evidence: Five expected/actual rows with timestamps and reproducible inputs. Diagnosis: Unclear requirements require an explicit assumption, not an invented pass. State the limits of the mental model: A marked measuring stick must exist before measuring the object.

Resume: Built test-cases.csv with evidence links using Browser DevTools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Test rapid submission and server unavailability. Capture one reproducible defect or record that it did not reproduce; reduce steps and specify data/reset conditions.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Test boundaries
Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow.
Mental model: Check a component, then an assembled bicycle, then a ride.
Limit: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.
Example: Validate title alone, then HTTP request, then keyboard submission in the browser.
Recall: Which layer should identify whether a failure is parsing or rendering?

### Reproducible defect reports
A defect report needs the smallest reliable reproduction, environment, impact and expected versus actual behavior. Severity describes harm; priority describes when the team should act.
Mental model: A repair request must identify both the broken part and how to observe the fault.
Limit: Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause.
Example: A double click that creates two tasks is different from an unreadable button label.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A double click that creates two tasks is different from an unreadable button label. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Test rapid submission and server unavailability. Capture one reproducible defect or record that it did not reproduce; reduce steps and specify data/reset conditions.
Expected: Another person can repeat the stated observation without guessing.

6. Role workshop · debug and verify
Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save defect report and reproduction checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Another person can repeat the stated observation without guessing.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Reproducible defect reports: Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: defect report and reproduction checklist
Another person can repeat the stated observation without guessing.

Interview: Work through this Software Test Analyst case: A double click that creates two tasks is different from an unreadable button label. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A defect report needs the smallest reliable reproduction, environment, impact and expected versus actual behavior. Severity describes harm; priority describes when the team should act. Expected evidence: Another person can repeat the stated observation without guessing. Diagnosis: Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause. State the limits of the mental model: A repair request must identify both the broken part and how to observe the fault.

Resume: Built defect report and reproduction checklist using Browser DevTools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Rank loss, duplication, accessibility and outage risks for the task app. Map each to evidence, mark unexecuted cases and write a ship/hold decision with a recovery trigger.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Risk-based release
Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery.
Mental model: Inspect brakes before polishing the paint.
Limit: Risk ranking is judgment informed by users, not an excuse to skip known defects.
Example: Test invalid input, double submission, keyboard focus and server restart; record results.
Recall: What evidence would make you hold a release despite a high pass count?

### Risk-based release decisions
A release decision considers harmful failures and untested areas, not simply a pass percentage. Document who accepts residual risk and what post-release signal triggers recovery.
Mental model: A car with polished paint still fails inspection if its brakes do not work.
Limit: A green total hides missing coverage; inspect which user outcomes were actually tested.
Example: A data-loss defect can block release despite 99 passing cosmetic tests.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A green total hides missing coverage; inspect which user outcomes were actually tested.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A data-loss defect can block release despite 99 passing cosmetic tests. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Rank loss, duplication, accessibility and outage risks for the task app. Map each to evidence, mark unexecuted cases and write a ship/hold decision with a recovery trigger.
Expected: A traceable decision that names unresolved high-impact risks.

6. Role workshop · debug and verify
A green total hides missing coverage; inspect which user outcomes were actually tested. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save release-quality report and risk matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A traceable decision that names unresolved high-impact risks.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Risk-based release decisions: A green total hides missing coverage; inspect which user outcomes were actually tested.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: release-quality report and risk matrix
A traceable decision that names unresolved high-impact risks.

Interview: Work through this Software Test Analyst case: A data-loss defect can block release despite 99 passing cosmetic tests. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A release decision considers harmful failures and untested areas, not simply a pass percentage. Document who accepts residual risk and what post-release signal triggers recovery. Expected evidence: A traceable decision that names unresolved high-impact risks. Diagnosis: A green total hides missing coverage; inspect which user outcomes were actually tested. State the limits of the mental model: A car with polished paint still fails inspection if its brakes do not work.

Resume: Built release-quality report and risk matrix using Browser DevTools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
Playwright: installation and first tests: https://playwright.dev/docs/intro
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
