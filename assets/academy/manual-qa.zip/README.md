# Software Test Analyst

Software Engineering

Begin with observable behavior. Write five observable test cases including blank input. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Write five observable test cases including blank input

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference.

### Observable behavior
A test compares a defined observation with an expected result for a chosen input.
Mental model: A recipe with a taste check rather than a photograph of ingredients.
Limit: Passing examples do not prove every possible input works.
Example: An empty task must not be added and the error must be understandable.
Recall: Write a test case with input, action and expected observation.

### Apply observable behavior in Software Test Analyst
Use the concept to complete this role exercise: Write five observable test cases including blank input
Mental model: A recipe with a taste check rather than a photograph of ingredients.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: An empty task must not be added and the error must be understandable. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Apply the role exercise
Write five observable test cases including blank input
Expected: Save a changed artifact and an evidence table; a command passing alone does not complete this step.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: manual-qa-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Write five observable test cases including blank input? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A test compares a defined observation with an expected result for a chosen input. For this role, explicitly address: Write five observable test cases including blank input.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Record expected versus actual results with reproducible defect steps

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference.

### Test boundaries
Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow.
Mental model: Check a component, then an assembled bicycle, then a ride.
Limit: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.
Example: Validate title alone, then HTTP request, then keyboard submission in the browser.
Recall: Which layer should identify whether a failure is parsing or rendering?

### Apply test boundaries in Software Test Analyst
Use the concept to complete this role exercise: Record expected versus actual results with reproducible defect steps
Mental model: Check a component, then an assembled bicycle, then a ride.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Validate title alone, then HTTP request, then keyboard submission in the browser. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Apply the role exercise
Record expected versus actual results with reproducible defect steps
Expected: Save a changed artifact and an evidence table; a command passing alone does not complete this step.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: manual-qa-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Record expected versus actual results with reproducible defect steps? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow. For this role, explicitly address: Record expected versus actual results with reproducible defect steps.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Prioritize release risks and explain gaps in the evidence

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference.

### Risk-based release
Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery.
Mental model: Inspect brakes before polishing the paint.
Limit: Risk ranking is judgment informed by users, not an excuse to skip known defects.
Example: Test invalid input, double submission, keyboard focus and server restart; record results.
Recall: What evidence would make you hold a release despite a high pass count?

### Apply risk-based release in Software Test Analyst
Use the concept to complete this role exercise: Prioritize release risks and explain gaps in the evidence
Mental model: Inspect brakes before polishing the paint.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Test invalid input, double submission, keyboard focus and server restart; record results. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Apply the role exercise
Prioritize release risks and explain gaps in the evidence
Expected: Save a changed artifact and an evidence table; a command passing alone does not complete this step.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: manual-qa-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Prioritize release risks and explain gaps in the evidence? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery. For this role, explicitly address: Prioritize release risks and explain gaps in the evidence.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
Playwright: installation and first tests: https://playwright.dev/docs/intro
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
