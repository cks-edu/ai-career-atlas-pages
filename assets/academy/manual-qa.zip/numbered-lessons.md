# Software Test Analyst — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Observable behavior: A test compares a defined observation with an expected result for a chosen input.

Apply observable behavior in Software Test Analyst: Use the concept to complete this role exercise: Write five observable test cases including blank input

Test cases and oracles: A test oracle is the rule used to judge an observed result. State input, action and expected behavior before running so the result cannot be redefined to match the implementation.

### Observable behavior

A test compares a defined observation with an expected result for a chosen input. In this role, work through: Blank title: zero new tasks and a readable error; valid title: exactly one task. The practical workshop develops this into: Run the web reference and write cases for blank, whitespace, normal, 80-character and 81-character titles. Execute them individually from a known empty state.

Mental model: A recipe with a taste check rather than a photograph of ingredients.

Boundary: Passing examples do not prove every possible input works.

Role application: A marked measuring stick must exist before measuring the object.

A test oracle is the rule used to judge an observed result. State input, action and expected behavior before running so the result cannot be redefined to match the implementation.

Worked example: Blank title: zero new tasks and a readable error; valid title: exactly one task.

Shared foundation example: An empty task must not be added and the error must be understandable.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Browser DevTools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Software Test Analyst: Blank title: zero new tasks and a readable error; valid title: exactly one task.

Predict the worked case

Read this case without running a tool: Blank title: zero new tasks and a readable error; valid title: exactly one task. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in observable behavior.

Connect the concept to the role

Apply this rule: A test compares a defined observation with an expected result for a chosen input. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Passing examples do not prove every possible input works.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies observable behavior to this case: Blank title: zero new tasks and a readable error; valid title: exactly one task. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Blank title: zero new tasks and a readable error; valid title: exactly one task. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Observable behavior; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with observable behavior. Use the glossary below, then write your prediction for: Blank title: zero new tasks and a readable error; valid title: exactly one task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Test Analyst role interview. Explain observable behavior using this case: Blank title: zero new tasks and a readable error; valid title: exactly one task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate observable behavior to a system or workflow you know. Explain observable behavior using this case: Blank title: zero new tasks and a readable error; valid title: exactly one task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Write a test case with input, action and expected observation.

Interview: Explain observable behavior using this case: Blank title: zero new tasks and a readable error; valid title: exactly one task. State the evidence, one alternative and where the mental model stops.

Quiz: After the Test cases and oracles rehearsal, check this foundation: A test reports success because the page loaded. The requirement is to reject blank submissions. Which evidence is missing?

The rejection behavior and unchanged stored state for blank input.

Only the browser version string.

The number of CSS files that loaded.

Reference: The rejection behavior and unchanged stored state for blank input. — An observation must match the contract being tested. Page availability alone does not test the invalid-input rule.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Playwright: installation and first tests: https://playwright.dev/docs/intro

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

### Test cases and oracles

A test oracle is the rule used to judge an observed result. State input, action and expected behavior before running so the result cannot be redefined to match the implementation. In this role, work through: Blank title: zero new tasks and a readable error; valid title: exactly one task. The practical workshop develops this into: Run the web reference and write cases for blank, whitespace, normal, 80-character and 81-character titles. Execute them individually from a known empty state.

Mental model: A marked measuring stick must exist before measuring the object.

Boundary: Unclear requirements require an explicit assumption, not an invented pass.

Worked example: Blank title: zero new tasks and a readable error; valid title: exactly one task.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Browser DevTools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Software Test Analyst workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run the web reference and write cases for blank, whitespace, normal, 80-character and 81-character titles. Execute them individually from a known empty state.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Blank title: zero new tasks and a readable error; valid title: exactly one task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run the web reference and write cases for blank, whitespace, normal, 80-character and 81-character titles. Execute them individually from a known empty state.

Expected: Five expected/actual rows with timestamps and reproducible inputs.

Role workshop · debug and verify

Unclear requirements require an explicit assumption, not an invented pass. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save test-cases.csv with evidence links. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Five expected/actual rows with timestamps and reproducible inputs.

Expected: Five expected/actual rows with timestamps and reproducible inputs.

Troubleshoot: The role exercise differs from the prediction: Unclear requirements require an explicit assumption, not an invented pass.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: test-cases.csv with evidence links; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with test cases and oracles. Use the glossary below, then write your prediction for: Blank title: zero new tasks and a readable error; valid title: exactly one task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Test Analyst role interview. Explain test cases and oracles using this case: Blank title: zero new tasks and a readable error; valid title: exactly one task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate test cases and oracles to a system or workflow you know. Explain test cases and oracles using this case: Blank title: zero new tasks and a readable error; valid title: exactly one task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Unclear requirements require an explicit assumption, not an invented pass.

Interview: Explain test cases and oracles using this case: Blank title: zero new tasks and a readable error; valid title: exactly one task. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Blank title: zero new tasks and a readable error; valid title: exactly one task.

Five expected/actual rows with timestamps and reproducible inputs.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Five expected/actual rows with timestamps and reproducible inputs. — A test oracle is the rule used to judge an observed result. State input, action and expected behavior before running so the result cannot be redefined to match the implementation. Five expected/actual rows with timestamps and reproducible inputs.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Playwright: installation and first tests: https://playwright.dev/docs/intro

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Test boundaries: Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow.

Apply test boundaries in Software Test Analyst: Use the concept to complete this role exercise: Record expected versus actual results with reproducible defect steps

Reproducible defect reports: A defect report needs the smallest reliable reproduction, environment, impact and expected versus actual behavior. Severity describes harm; priority describes when the team should act.

### Test boundaries

Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow. In this role, work through: A double click that creates two tasks is different from an unreadable button label. The practical workshop develops this into: Test rapid submission and server unavailability. Capture one reproducible defect or record that it did not reproduce; reduce steps and specify data/reset conditions.

Mental model: Check a component, then an assembled bicycle, then a ride.

Boundary: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.

Role application: A repair request must identify both the broken part and how to observe the fault.

A defect report needs the smallest reliable reproduction, environment, impact and expected versus actual behavior. Severity describes harm; priority describes when the team should act.

Worked example: A double click that creates two tasks is different from an unreadable button label.

Shared foundation example: Validate title alone, then HTTP request, then keyboard submission in the browser.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Browser DevTools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Software Test Analyst: A double click that creates two tasks is different from an unreadable button label.

Predict the worked case

Read this case without running a tool: A double click that creates two tasks is different from an unreadable button label. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in test boundaries.

Connect the concept to the role

Apply this rule: Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies test boundaries to this case: A double click that creates two tasks is different from an unreadable button label. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A double click that creates two tasks is different from an unreadable button label. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Test boundaries; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with test boundaries. Use the glossary below, then write your prediction for: A double click that creates two tasks is different from an unreadable button label. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Test Analyst role interview. Explain test boundaries using this case: A double click that creates two tasks is different from an unreadable button label. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate test boundaries to a system or workflow you know. Explain test boundaries using this case: A double click that creates two tasks is different from an unreadable button label. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which layer should identify whether a failure is parsing or rendering?

Interview: Explain test boundaries using this case: A double click that creates two tasks is different from an unreadable button label. State the evidence, one alternative and where the mental model stops.

Quiz: After the Reproducible defect reports rehearsal, check this foundation: A function test passes. Which check would examine whether HTTP parsing and the function work together?

Rerun the same isolated function test.

An integration test through the request boundary.

Only inspect a screenshot of the editor.

Reference: An integration test through the request boundary. — Integration tests exercise cooperating parts. They complement rather than replace focused unit checks.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Playwright: installation and first tests: https://playwright.dev/docs/intro

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

### Reproducible defect reports

A defect report needs the smallest reliable reproduction, environment, impact and expected versus actual behavior. Severity describes harm; priority describes when the team should act. In this role, work through: A double click that creates two tasks is different from an unreadable button label. The practical workshop develops this into: Test rapid submission and server unavailability. Capture one reproducible defect or record that it did not reproduce; reduce steps and specify data/reset conditions.

Mental model: A repair request must identify both the broken part and how to observe the fault.

Boundary: Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause.

Worked example: A double click that creates two tasks is different from an unreadable button label.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Browser DevTools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Software Test Analyst workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Test rapid submission and server unavailability. Capture one reproducible defect or record that it did not reproduce; reduce steps and specify data/reset conditions.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

A double click that creates two tasks is different from an unreadable button label. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Test rapid submission and server unavailability. Capture one reproducible defect or record that it did not reproduce; reduce steps and specify data/reset conditions.

Expected: Another person can repeat the stated observation without guessing.

Role workshop · debug and verify

Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save defect report and reproduction checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Another person can repeat the stated observation without guessing.

Expected: Another person can repeat the stated observation without guessing.

Troubleshoot: The role exercise differs from the prediction: Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: defect report and reproduction checklist; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with reproducible defect reports. Use the glossary below, then write your prediction for: A double click that creates two tasks is different from an unreadable button label. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Test Analyst role interview. Explain reproducible defect reports using this case: A double click that creates two tasks is different from an unreadable button label. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate reproducible defect reports to a system or workflow you know. Explain reproducible defect reports using this case: A double click that creates two tasks is different from an unreadable button label. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Intermittent bugs need frequency and timing evidence; do not replace an observation with a suspected cause.

Interview: Explain reproducible defect reports using this case: A double click that creates two tasks is different from an unreadable button label. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A double click that creates two tasks is different from an unreadable button label.

Ignore the failing case and keep only the successful screenshot.

Another person can repeat the stated observation without guessing.

Treat any successful command as proof that all business and access rules passed.

Reference: Another person can repeat the stated observation without guessing. — A defect report needs the smallest reliable reproduction, environment, impact and expected versus actual behavior. Severity describes harm; priority describes when the team should act. Another person can repeat the stated observation without guessing.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Playwright: installation and first tests: https://playwright.dev/docs/intro

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Risk-based release: Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery.

Apply risk-based release in Software Test Analyst: Use the concept to complete this role exercise: Prioritize release risks and explain gaps in the evidence

Risk-based release decisions: A release decision considers harmful failures and untested areas, not simply a pass percentage. Document who accepts residual risk and what post-release signal triggers recovery.

### Risk-based release

Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery. In this role, work through: A data-loss defect can block release despite 99 passing cosmetic tests. The practical workshop develops this into: Rank loss, duplication, accessibility and outage risks for the task app. Map each to evidence, mark unexecuted cases and write a ship/hold decision with a recovery trigger.

Mental model: Inspect brakes before polishing the paint.

Boundary: Risk ranking is judgment informed by users, not an excuse to skip known defects.

Role application: A car with polished paint still fails inspection if its brakes do not work.

A release decision considers harmful failures and untested areas, not simply a pass percentage. Document who accepts residual risk and what post-release signal triggers recovery.

Worked example: A data-loss defect can block release despite 99 passing cosmetic tests.

Shared foundation example: Test invalid input, double submission, keyboard focus and server restart; record results.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Browser DevTools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Software Test Analyst: A data-loss defect can block release despite 99 passing cosmetic tests.

Predict the worked case

Read this case without running a tool: A data-loss defect can block release despite 99 passing cosmetic tests. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in risk-based release.

Connect the concept to the role

Apply this rule: Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Risk ranking is judgment informed by users, not an excuse to skip known defects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies risk-based release to this case: A data-loss defect can block release despite 99 passing cosmetic tests. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A data-loss defect can block release despite 99 passing cosmetic tests. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Risk-based release; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with risk-based release. Use the glossary below, then write your prediction for: A data-loss defect can block release despite 99 passing cosmetic tests. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Test Analyst role interview. Explain risk-based release using this case: A data-loss defect can block release despite 99 passing cosmetic tests. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate risk-based release to a system or workflow you know. Explain risk-based release using this case: A data-loss defect can block release despite 99 passing cosmetic tests. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What evidence would make you hold a release despite a high pass count?

Interview: Explain risk-based release using this case: A data-loss defect can block release despite 99 passing cosmetic tests. State the evidence, one alternative and where the mental model stops.

Quiz: After the Risk-based release decisions rehearsal, check this foundation: Happy-path tests pass, but a plausible high-impact failure is untested. What is a defensible next step?

Declare zero release risk because automated checks passed.

Remove the uncertain case from the report.

Assess its impact, test or mitigate it, and record residual risk for the release owner.

Reference: Assess its impact, test or mitigate it, and record residual risk for the release owner. — Risk-based testing prioritizes harmful plausible failures; passing a limited suite is not proof of complete coverage.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Playwright: installation and first tests: https://playwright.dev/docs/intro

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

### Risk-based release decisions

A release decision considers harmful failures and untested areas, not simply a pass percentage. Document who accepts residual risk and what post-release signal triggers recovery. In this role, work through: A data-loss defect can block release despite 99 passing cosmetic tests. The practical workshop develops this into: Rank loss, duplication, accessibility and outage risks for the task app. Map each to evidence, mark unexecuted cases and write a ship/hold decision with a recovery trigger.

Mental model: A car with polished paint still fails inspection if its brakes do not work.

Boundary: A green total hides missing coverage; inspect which user outcomes were actually tested.

Worked example: A data-loss defect can block release despite 99 passing cosmetic tests.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Browser DevTools (Open web platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Software Test Analyst workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Rank loss, duplication, accessibility and outage risks for the task app. Map each to evidence, mark unexecuted cases and write a ship/hold decision with a recovery trigger.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

A data-loss defect can block release despite 99 passing cosmetic tests. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Rank loss, duplication, accessibility and outage risks for the task app. Map each to evidence, mark unexecuted cases and write a ship/hold decision with a recovery trigger.

Expected: A traceable decision that names unresolved high-impact risks.

Role workshop · debug and verify

A green total hides missing coverage; inspect which user outcomes were actually tested. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save release-quality report and risk matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A traceable decision that names unresolved high-impact risks.

Expected: A traceable decision that names unresolved high-impact risks.

Troubleshoot: The role exercise differs from the prediction: A green total hides missing coverage; inspect which user outcomes were actually tested.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: release-quality report and risk matrix; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with risk-based release decisions. Use the glossary below, then write your prediction for: A data-loss defect can block release despite 99 passing cosmetic tests. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Software Test Analyst role interview. Explain risk-based release decisions using this case: A data-loss defect can block release despite 99 passing cosmetic tests. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate risk-based release decisions to a system or workflow you know. Explain risk-based release decisions using this case: A data-loss defect can block release despite 99 passing cosmetic tests. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A green total hides missing coverage; inspect which user outcomes were actually tested.

Interview: Explain risk-based release decisions using this case: A data-loss defect can block release despite 99 passing cosmetic tests. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A data-loss defect can block release despite 99 passing cosmetic tests.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A traceable decision that names unresolved high-impact risks.

Reference: A traceable decision that names unresolved high-impact risks. — A release decision considers harmful failures and untested areas, not simply a pass percentage. Document who accepts residual risk and what post-release signal triggers recovery. A traceable decision that names unresolved high-impact risks.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Playwright: installation and first tests: https://playwright.dev/docs/intro

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
