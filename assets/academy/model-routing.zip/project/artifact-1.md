# Router and eligibility policy

Project: Quality-constrained model router
Status: blank work product — not completed evidence

## Purpose and audience
Route tasks between models while measuring quality, cost assumptions and fallback behavior.

## Required content
Use model_probe.py to collect baseline outputs for both models on the same tasks. Record errors, latency and task-quality labels before implementing routing.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.

## Failure evidence
Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
