# Baseline/routing evaluation dataset

Project: Quality-constrained model router
Status: blank work product — not completed evidence

## Purpose and audience
Route tasks between models while measuring quality, cost assumptions and fallback behavior.

## Required content
Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.

## Failure evidence
Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
