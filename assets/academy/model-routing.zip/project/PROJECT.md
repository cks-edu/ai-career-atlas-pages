# Quality-constrained model router

Career: Model routing & AI unit economics
Reviewed: 2026-10-22

Route tasks between models while measuring quality, cost assumptions and fallback behavior.

## Prerequisites
Model evaluation, cost accounting and latency instrumentation.

## Included starter versus your implementation
FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Use model_probe.py to collect baseline outputs for both models on the same tasks. Record errors, latency and task-quality labels before implementing routing.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Add bounded fallback and per-request usage accounting. Compare static routing with a simple task classifier using a frozen test set.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

## Portfolio deliverables
1. Router and eligibility policy — artifact-1.md
2. Baseline/routing evaluation dataset — artifact-2.md
3. Unit-economics and failure-mode report — artifact-3.md

## Troubleshooting
- Port occupied: select an unused local port and update client URLs.
- 422 response: inspect the request JSON and schema.
- Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.

## Extension
Add budget reservation under concurrency and test overshoot limits.

## Primary learning resources
- Ollama: https://docs.ollama.com/api/generate — Open source runtime · model licenses vary; Local generation; choose a model that fits memory and permitted use.
- FinOps for AI: https://www.finops.org/framework/technology-categories/ai/ — Public framework; Cost attribution, unit economics and capacity decisions.
- MLflow: https://mlflow.org/docs/latest/ml/tracking/quickstart/ — Open source · hosted offerings optional; Record experiments, parameters and evaluation artifacts.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
