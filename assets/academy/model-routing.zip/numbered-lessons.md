# Model routing & AI unit economics — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Comparable request economics: Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Comparable request economics

Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices. In this role, work through: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Choose a delivery service by the cost of intact arrivals.

Boundary: Prices, workloads and acceptance criteria can change the recommendation.

Worked example: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Ollama (Open source runtime · model licenses vary); FinOps for AI (Public framework); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Model routing & AI unit economics: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both.

Predict the worked case

Read this case without running a tool: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in comparable request economics.

Connect the concept to the role

Apply this rule: Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Prices, workloads and acceptance criteria can change the recommendation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies comparable request economics to this case: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Comparable request economics; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with comparable request economics. Use the glossary below, then write your prediction for: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Model routing & AI unit economics role interview. Explain comparable request economics using this case: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate comparable request economics to a system or workflow you know. Explain comparable request economics using this case: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain comparable request economics using this case: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both.

Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices. — Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices. Prices, workloads and acceptance criteria can change the recommendation.

Sources:

Ollama: https://docs.ollama.com/api/generate

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/

vLLM: https://docs.vllm.ai/en/stable/

### Diagnose: The cheapest route fails the task

The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Two cheaper-route buckets violate the quality constraint, so lower token cost is not enough. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Route difficult cases to a verified fallback and include retries and review in outcome cost. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Choose a delivery service by the cost of intact arrivals.

A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both.

Worked example: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Route difficult cases to a verified fallback and include retries and review in outcome cost.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Ollama (Open source runtime · model licenses vary); FinOps for AI (Public framework); MLflow (Open source · hosted offerings optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Two cheaper-route buckets violate the quality constraint, so lower token cost is not enough. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Apply this toy-case rule manually: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Routing sends requests to different models or methods. Compare cost and delay per accepted result, including failed attempts and fallback.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use fictional totals: route A costs 8 units and produces 40 accepted results; route B costs 12 units and produces 80 accepted results.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-route comparison and a provisional decision rule.

Preparation · Try step 2

Calculate cost per accepted result and list the latency information still missing.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-route comparison and a provisional decision rule.

Preparation · Try step 3

Write a decision rule that checks quality and delay before choosing solely on price.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-route comparison and a provisional decision rule.

Preparation · Explain and check your result

Costs are 0.20 and 0.15 units per accepted result; you avoid declaring a winner on latency without measurements. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A two-route comparison and a provisional decision rule. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Apply this toy-case rule manually: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two cheaper-route buckets violate the quality constraint, so lower token cost is not enough. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two cheaper-route buckets violate the quality constraint, so lower token cost is not enough. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the cheapest route fails the task. Use the glossary below, then write your prediction for: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Route difficult cases to a verified fallback and include retries and review in outcome cost. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Model routing & AI unit economics role interview. Explain diagnose: the cheapest route fails the task using this case: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Route difficult cases to a verified fallback and include retries and review in outcome cost. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the cheapest route fails the task to a system or workflow you know. Explain diagnose: the cheapest route fails the task using this case: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Route difficult cases to a verified fallback and include retries and review in outcome cost. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Compare against a fixed-model baseline on identical tasks with quality and latency constraints. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the cheapest route fails the task using this case: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Route difficult cases to a verified fallback and include retries and review in outcome cost. State the evidence, one alternative and where the mental model stops.

Quiz: The cheapest route fails the task: The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket.

Change the acceptance rule after seeing an inconvenient result.

Route difficult cases to a verified fallback and include retries and review in outcome cost.

Omit failed cases and report only the successful demonstrations.

Reference: Route difficult cases to a verified fallback and include retries and review in outcome cost. — Route difficult cases to a verified fallback and include retries and review in outcome cost. Compare against a fixed-model baseline on identical tasks with quality and latency constraints.

Sources:

Ollama: https://docs.ollama.com/api/generate

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/

vLLM: https://docs.vllm.ai/en/stable/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Model evaluation, cost accounting and latency instrumentation.

Terms:

Routing features and baselines: Use observable request properties to choose a candidate and compare against always using one model. Keep routing decisions auditable and avoid using unavailable future information.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Routing features and baselines

Use observable request properties to choose a candidate and compare against always using one model. Keep routing decisions auditable and avoid using unavailable future information. In this role, work through: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A sorting office routes parcels using address and size visible at dispatch.

Boundary: A complexity label inferred by another model can itself be wrong and costly.

Worked example: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Model evaluation, cost accounting and latency instrumentation.

Tools for this exercise: Document or text editor

Course tool and framework map: Ollama (Open source runtime · model licenses vary); FinOps for AI (Public framework); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Model routing & AI unit economics: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases.

Predict the worked case

Read this case without running a tool: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in routing features and baselines.

Connect the concept to the role

Apply this rule: Use observable request properties to choose a candidate and compare against always using one model. Keep routing decisions auditable and avoid using unavailable future information. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A complexity label inferred by another model can itself be wrong and costly.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies routing features and baselines to this case: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Routing features and baselines; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with routing features and baselines. Use the glossary below, then write your prediction for: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Model routing & AI unit economics role interview. Explain routing features and baselines using this case: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate routing features and baselines to a system or workflow you know. Explain routing features and baselines using this case: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain routing features and baselines using this case: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases.

Treat a passing starter as proof of the whole role workflow.

Use observable request properties to choose a candidate and compare against always using one model. Keep routing decisions auditable and avoid using unavailable future information.

Ignore the failure because the tool produced an output.

Reference: Use observable request properties to choose a candidate and compare against always using one model. Keep routing decisions auditable and avoid using unavailable future information. — Use observable request properties to choose a candidate and compare against always using one model. Keep routing decisions auditable and avoid using unavailable future information. A complexity label inferred by another model can itself be wrong and costly.

Sources:

Ollama: https://docs.ollama.com/api/generate

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/

vLLM: https://docs.vllm.ai/en/stable/

### Integrate: Quality-constrained model router

Route tasks between models while measuring quality, cost assumptions and fallback behavior. Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route. In this role, work through: Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A sorting office routes parcels using address and size visible at dispatch.

Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases.

Worked example: Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Ollama (Open source runtime · model licenses vary); FinOps for AI (Public framework); MLflow (Open source · hosted offerings optional)

Route tasks between models while measuring quality, cost assumptions and fallback behavior. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Route tasks between models while measuring quality, cost assumptions and fallback behavior.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use model_probe.py to collect baseline outputs for both models on the same tasks. Record errors, latency and task-quality labels before implementing routing.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-intermediate-2.md: Router and eligibility policy; Baseline/routing evaluation dataset. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: quality-constrained model router. Use the glossary below, then write your prediction for: Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Model routing & AI unit economics role interview. Explain integrate: quality-constrained model router using this case: Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: quality-constrained model router to a system or workflow you know. Explain integrate: quality-constrained model router using this case: Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. Identify one observation that would contradict your claim.

Interview: Explain integrate: quality-constrained model router using this case: Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Quality-constrained model router at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.

Reference: Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. — Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.

Sources:

Ollama: https://docs.ollama.com/api/generate

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/

vLLM: https://docs.vllm.ai/en/stable/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Fallback-aware routing: Bound fallback chains and measure their combined latency and cost. Preserve task constraints when switching models and test outages deliberately.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Fallback-aware routing

Bound fallback chains and measure their combined latency and cost. Preserve task constraints when switching models and test outages deliberately. In this role, work through: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A detour must still reach the original destination within the travel budget.

Boundary: Different models may have incompatible formats, safety behavior or context limits.

Worked example: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Ollama (Open source runtime · model licenses vary); FinOps for AI (Public framework); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Model routing & AI unit economics: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely.

Predict the worked case

Read this case without running a tool: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in fallback-aware routing.

Connect the concept to the role

Apply this rule: Bound fallback chains and measure their combined latency and cost. Preserve task constraints when switching models and test outages deliberately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Different models may have incompatible formats, safety behavior or context limits.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies fallback-aware routing to this case: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Fallback-aware routing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with fallback-aware routing. Use the glossary below, then write your prediction for: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Model routing & AI unit economics role interview. Explain fallback-aware routing using this case: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate fallback-aware routing to a system or workflow you know. Explain fallback-aware routing using this case: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain fallback-aware routing using this case: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Bound fallback chains and measure their combined latency and cost. Preserve task constraints when switching models and test outages deliberately.

Reference: Bound fallback chains and measure their combined latency and cost. Preserve task constraints when switching models and test outages deliberately. — Bound fallback chains and measure their combined latency and cost. Preserve task constraints when switching models and test outages deliberately. Different models may have incompatible formats, safety behavior or context limits.

Sources:

Ollama: https://docs.ollama.com/api/generate

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/

vLLM: https://docs.vllm.ai/en/stable/

### Defend: Quality-constrained model router

Route tasks between models while measuring quality, cost assumptions and fallback behavior. Add bounded fallback and per-request usage accounting. Compare static routing with a simple task classifier using a frozen test set. In this role, work through: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A detour must still reach the original destination within the travel budget.

A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely.

Worked example: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Ollama (Open source runtime · model licenses vary); FinOps for AI (Public framework); MLflow (Open source · hosted offerings optional)

Route tasks between models while measuring quality, cost assumptions and fallback behavior. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Route tasks between models while measuring quality, cost assumptions and fallback behavior.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use model_probe.py to collect baseline outputs for both models on the same tasks. Record errors, latency and task-quality labels before implementing routing.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add bounded fallback and per-request usage accounting. Compare static routing with a simple task classifier using a frozen test set.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. A reviewer must reproduce one result and identify which capabilities you implemented. Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-advanced-2.md: Router and eligibility policy; Baseline/routing evaluation dataset; Unit-economics and failure-mode report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: quality-constrained model router. Use the glossary below, then write your prediction for: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Model routing & AI unit economics role interview. Explain defend: quality-constrained model router using this case: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: quality-constrained model router to a system or workflow you know. Explain defend: quality-constrained model router using this case: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. Identify one observation that would contradict your claim.

Interview: Explain defend: quality-constrained model router using this case: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Quality-constrained model router at this level?

Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade. — Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade. Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.

Sources:

Ollama: https://docs.ollama.com/api/generate

FinOps for AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/

MLflow: https://mlflow.org/docs/latest/

vLLM: https://docs.vllm.ai/en/stable/
