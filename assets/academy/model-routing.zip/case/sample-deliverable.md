# SAMPLE — Routing evaluation and unit-economics memo
Role: Model routing & AI unit economics
Case: The cheapest route fails the task
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket.

## Evidence table
| Record | unacceptable_outputs (out of ten tasks) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 5 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two cheaper-route buckets violate the quality constraint, so lower token cost is not enough.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Route difficult cases to a verified fallback and include retries and review in outcome cost.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in model routing & ai unit economics.
Before release: Compare against a fixed-model baseline on identical tasks with quality and latency constraints.

## Design choice and trade-off
Measure useful outcomes and routing errors; bound fallback and overload behavior.
Routing adds complexity and classification errors; simple policies may be more reliable than an unvalidated learned router.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Quality-constrained router: Savings claims include fallback and quality-review costs.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
