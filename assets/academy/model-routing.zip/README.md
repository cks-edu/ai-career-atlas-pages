# Model routing & AI unit economics

AI Engineering · Beginner → Intermediate → Advanced

Start with Comparable request economics. Routing sends requests to different models or methods. Compare cost and delay per accepted result, including failed attempts and fallback. Then try Compare two routing options. The three levels build toward Quality-constrained model router. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Comparable request economics

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Comparable request economics
Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices.
Mental model: Choose a delivery service by the cost of intact arrivals.
Boundary: Prices, workloads and acceptance criteria can change the recommendation.
Worked example: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The cheapest route fails the task
The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Two cheaper-route buckets violate the quality constraint, so lower token cost is not enough. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Route difficult cases to a verified fallback and include retries and review in outcome cost.
Recall: Compare against a fixed-model baseline on identical tasks with quality and latency constraints. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Comparable request economics: Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Routing sends requests to different models or methods. Compare cost and delay per accepted result, including failed attempts and fallback.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use fictional totals: route A costs 8 units and produces 40 accepted results; route B costs 12 units and produces 80 accepted results.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-route comparison and a provisional decision rule.

3. Try step 2
Calculate cost per accepted result and list the latency information still missing.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-route comparison and a provisional decision rule.

4. Try step 3
Write a decision rule that checks quality and delay before choosing solely on price.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-route comparison and a provisional decision rule.

5. Explain and check your result
Costs are 0.20 and 0.15 units per accepted result; you avoid declaring a winner on latency without measurements. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A two-route comparison and a provisional decision rule. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Apply this toy-case rule manually: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two cheaper-route buckets violate the quality constraint, so lower token cost is not enough. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Model routing & AI unit economics.
Use fictional totals: route A costs 8 units and produces 40 accepted results; route B costs 12 units and produces 80 accepted results.
Calculate cost per accepted result and list the latency information still missing.
Write a decision rule that checks quality and delay before choosing solely on price.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A two-route comparison and a provisional decision rule. Include beginner-worksheet.md and your completed Routing evaluation and unit-economics memo.
Check: Costs are 0.20 and 0.15 units per accepted result; you avoid declaring a winner on latency without measurements.

### Interview
Explain your beginner solution for Model routing & AI unit economics. Use this scenario: The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket.
Review: Start with the task and permitted scope. Explain comparable request economics: Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices. Show the input and observed output, then address Route difficult cases to a verified fallback and include retries and review in outcome cost. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A two-route comparison and a provisional decision rule. Include beginner-worksheet.md and your completed Routing evaluation and unit-economics memo.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Routing features and baselines

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Model evaluation, cost accounting and latency instrumentation.

### Routing features and baselines
Use observable request properties to choose a candidate and compare against always using one model. Keep routing decisions auditable and avoid using unavailable future information.
Mental model: A sorting office routes parcels using address and size visible at dispatch.
Boundary: A complexity label inferred by another model can itself be wrong and costly.
Worked example: Route short extraction requests separately from long grounded questions, then evaluate each group on the same frozen cases.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Quality-constrained model router
Route tasks between models while measuring quality, cost assumptions and fallback behavior. Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities.
Recall: Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. Identify one observation that would contradict your claim.

### Terms
Routing features and baselines: Use observable request properties to choose a candidate and compare against always using one model. Keep routing decisions auditable and avoid using unavailable future information.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Route tasks between models while measuring quality, cost assumptions and fallback behavior. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use model_probe.py to collect baseline outputs for both models on the same tasks. Record errors, latency and task-quality labels before implementing routing.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Route tasks between models while measuring quality, cost assumptions and fallback behavior.
Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities.
Use model_probe.py to collect baseline outputs for both models on the same tasks. Record errors, latency and task-quality labels before implementing routing.
Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route.
Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.
Deliverables: Router and eligibility policy; Baseline/routing evaluation dataset. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Model routing & AI unit economics. Use this scenario: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.
Review: Start with the task and permitted scope. Explain routing features and baselines: Use observable request properties to choose a candidate and compare against always using one model. Keep routing decisions auditable and avoid using unavailable future information. Show the input and observed output, then address Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Router and eligibility policy; Baseline/routing evaluation dataset. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Fallback-aware routing

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Fallback-aware routing
Bound fallback chains and measure their combined latency and cost. Preserve task constraints when switching models and test outages deliberately.
Mental model: A detour must still reach the original destination within the travel budget.
Boundary: Different models may have incompatible formats, safety behavior or context limits.
Worked example: A failed small-model request falls back once; if the larger model is unavailable, return review rather than looping indefinitely.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Quality-constrained model router
Route tasks between models while measuring quality, cost assumptions and fallback behavior. Add bounded fallback and per-request usage accounting. Compare static routing with a simple task classifier using a frozen test set.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.
Recall: Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. Identify one observation that would contradict your claim.

### Terms
Fallback-aware routing: Bound fallback chains and measure their combined latency and cost. Preserve task constraints when switching models and test outages deliberately.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Route tasks between models while measuring quality, cost assumptions and fallback behavior. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use model_probe.py to collect baseline outputs for both models on the same tasks. Record errors, latency and task-quality labels before implementing routing.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add bounded fallback and per-request usage accounting. Compare static routing with a simple task classifier using a frozen test set.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Route tasks between models while measuring quality, cost assumptions and fallback behavior.
Create 40 tasks split by complexity and expected output requirements. Choose two locally available models or permitted hosted endpoints and record their capabilities.
Use model_probe.py to collect baseline outputs for both models on the same tasks. Record errors, latency and task-quality labels before implementing routing.
Extend the API starter with an eligibility gate for context length, modality and output format, then a routing policy. Preserve the reason for each route.
Add bounded fallback and per-request usage accounting. Compare static routing with a simple task classifier using a frozen test set.
Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.
Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims.
Add budget reservation under concurrency and test overshoot limits.
Deliverables: Router and eligibility policy; Baseline/routing evaluation dataset; Unit-economics and failure-mode report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. A reviewer must reproduce one result and identify which capabilities you implemented. Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.

### Interview
Explain your advanced solution for Model routing & AI unit economics. Use this scenario: Make the preferred endpoint unavailable and submit a task requiring an unsupported capability. Fallback must preserve requirements or return a clear failure, not silently downgrade.
Review: Start with the task and permitted scope. Explain fallback-aware routing: Bound fallback chains and measure their combined latency and cost. Preserve task constraints when switching models and test outages deliberately. Show the input and observed output, then address Report cost per successful task, quality floor violations, fallback rate and p95 latency. Use actual dated rate tables for hosted cost claims. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Router and eligibility policy; Baseline/routing evaluation dataset; Unit-economics and failure-mode report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Ollama — Open source runtime · model licenses vary
Local generation; choose a model that fits memory and permitted use.
Alternative: llama.cpp (open source) for local inference, or a commercial hosted API; model licenses and memory requirements remain separate.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

FinOps for AI — Public framework
Cost attribution, unit economics and capacity decisions.
Alternative: A documented cost-allocation workbook can implement a small practice; commercial cloud cost tools are optional and need validated data.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Ollama: https://docs.ollama.com/api/generate
FinOps for AI: https://www.finops.org/framework/technology-categories/ai/
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
FinOps Foundation: AI: https://www.finops.org/framework/technology-categories/ai/
MLflow: https://mlflow.org/docs/latest/
vLLM: https://docs.vllm.ai/en/stable/
