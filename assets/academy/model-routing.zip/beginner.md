## beginner — Comparable request economics

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Comparable request economics
Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices.
Mental model: Choose a delivery service by the cost of intact arrivals.
Boundary: Prices, workloads and acceptance criteria can change the recommendation.
Worked example: A cheap model succeeds on six of ten tasks while an expensive one succeeds on nine; compute the full workflow cost for both.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The cheapest route fails the task
The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Two cheaper-route buckets violate the quality constraint, so lower token cost is not enough. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Route difficult cases to a verified fallback and include retries and review in outcome cost.
Recall: Compare against a fixed-model baseline on identical tasks with quality and latency constraints. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Comparable request economics: Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Routing sends requests to different models or methods. Compare cost and delay per accepted result, including failed attempts and fallback.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use fictional totals: route A costs 8 units and produces 40 accepted results; route B costs 12 units and produces 80 accepted results.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-route comparison and a provisional decision rule.

3. Try step 2
Calculate cost per accepted result and list the latency information still missing.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-route comparison and a provisional decision rule.

4. Try step 3
Write a decision rule that checks quality and delay before choosing solely on price.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A two-route comparison and a provisional decision rule.

5. Explain and check your result
Costs are 0.20 and 0.15 units per accepted result; you avoid declaring a winner on latency without measurements. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A two-route comparison and a provisional decision rule. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket. Apply this toy-case rule manually: Review when unacceptable_outputs >= 3 (out of ten tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two cheaper-route buckets violate the quality constraint, so lower token cost is not enough. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Model routing & AI unit economics.
Use fictional totals: route A costs 8 units and produces 40 accepted results; route B costs 12 units and produces 80 accepted results.
Calculate cost per accepted result and list the latency information still missing.
Write a decision rule that checks quality and delay before choosing solely on price.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A two-route comparison and a provisional decision rule. Include beginner-worksheet.md and your completed Routing evaluation and unit-economics memo.
Check: Costs are 0.20 and 0.15 units per accepted result; you avoid declaring a winner on latency without measurements.

### Interview
Explain your beginner solution for Model routing & AI unit economics. Use this scenario: The router gate flags more than two unacceptable outputs in a ten-task evaluation bucket.
Review: Start with the task and permitted scope. Explain comparable request economics: Define task success and measure cost per accepted result across candidates. Include retries, fallbacks and manual review rather than comparing only nominal token prices. Show the input and observed output, then address Route difficult cases to a verified fallback and include retries and review in outcome cost. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A two-route comparison and a provisional decision rule. Include beginner-worksheet.md and your completed Routing evaluation and unit-economics memo.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

