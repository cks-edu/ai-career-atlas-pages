## intermediate — Retention and deletion boundaries

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Data mapping and access/retention controls; technical implementation needs SQL or scripting, legal decisions need qualified review.

### Retention and deletion boundaries
Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything.
Mental model: Removing a book from one shelf does not remove all photocopies.
Boundary: Backups and trained models can require different, carefully reviewed handling.
Worked example: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Data lineage and deletion assurance project
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Recall: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. Identify one observation that would contradict your claim.

### Terms
Retention and deletion boundaries: Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies.
Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.
Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.
Deliverables: Lineage database and deletion tests; Data-flow and retention register. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI privacy / data-provenance specialist. Use this scenario: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Review: Start with the task and permitted scope. Explain retention and deletion boundaries: Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything. Show the input and observed output, then address Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Lineage database and deletion tests; Data-flow and retention register. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

