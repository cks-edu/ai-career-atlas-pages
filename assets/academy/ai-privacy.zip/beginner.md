## beginner — Data flow and minimization

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Data flow and minimization
Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training.
Mental model: Pack only what is needed for a journey and know who carries each bag.
Boundary: Removing obvious identifiers does not guarantee anonymity.
Worked example: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Deletion misses the derived store
The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Two deleted records remain in active derived stores beyond the defined policy window. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies.
Recall: Record active-store checks, backup handling and any retention exceptions for qualified review. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Data flow and minimization: Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Personal data can appear in source files, retrieved passages, logs and exports. Removing the original does not automatically remove every copy.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use an invented record: learner Alex, email alex@example.test, question about a course.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A data-flow map and a copy/owner table.

3. Try step 2
Draw its path through a form, document store, assistant context, error log and downloaded report.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A data-flow map and a copy/owner table.

4. Try step 3
For each copy, record why it is needed, who can access it and who decides when it is removed.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A data-flow map and a copy/owner table.

5. Explain and check your result
Logs and exports are included; unknown retention rules remain questions for qualified review rather than invented legal deadlines. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A data-flow map and a copy/owner table. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Apply this toy-case rule manually: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two deleted records remain in active derived stores beyond the defined policy window. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI privacy / data-provenance specialist.
Use an invented record: learner Alex, email alex@example.test, question about a course.
Draw its path through a form, document store, assistant context, error log and downloaded report.
For each copy, record why it is needed, who can access it and who decides when it is removed.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A data-flow map and a copy/owner table. Include beginner-worksheet.md and your completed Deletion evidence ledger.
Check: Logs and exports are included; unknown retention rules remain questions for qualified review rather than invented legal deadlines.

### Interview
Explain your beginner solution for AI privacy / data-provenance specialist. Use this scenario: The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately.
Review: Start with the task and permitted scope. Explain data flow and minimization: Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training. Show the input and observed output, then address Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A data-flow map and a copy/owner table. Include beginner-worksheet.md and your completed Deletion evidence ledger.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

