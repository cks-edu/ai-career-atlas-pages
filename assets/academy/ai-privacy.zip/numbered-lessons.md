# AI privacy / data-provenance specialist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Data flow and minimization: Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Data flow and minimization

Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training. In this role, work through: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Pack only what is needed for a journey and know who carries each bag.

Boundary: Removing obvious identifiers does not guarantee anonymity.

Worked example: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI privacy / data-provenance specialist: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise.

Predict the worked case

Read this case without running a tool: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in data flow and minimization.

Connect the concept to the role

Apply this rule: Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Removing obvious identifiers does not guarantee anonymity.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies data flow and minimization to this case: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Data flow and minimization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with data flow and minimization. Use the glossary below, then write your prediction for: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI privacy / data-provenance specialist role interview. Explain data flow and minimization using this case: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate data flow and minimization to a system or workflow you know. Explain data flow and minimization using this case: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain data flow and minimization using this case: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise.

Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training. — Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training. Removing obvious identifiers does not guarantee anonymity.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Label Studio: https://labelstud.io/guide/

### Diagnose: Deletion misses the derived store

The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Two deleted records remain in active derived stores beyond the defined policy window. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Pack only what is needed for a journey and know who carries each bag.

A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise.

Worked example: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: DuckDB (Open source · local); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Two deleted records remain in active derived stores beyond the defined policy window. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Apply this toy-case rule manually: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Personal data can appear in source files, retrieved passages, logs and exports. Removing the original does not automatically remove every copy.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use an invented record: learner Alex, email alex@example.test, question about a course.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A data-flow map and a copy/owner table.

Preparation · Try step 2

Draw its path through a form, document store, assistant context, error log and downloaded report.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A data-flow map and a copy/owner table.

Preparation · Try step 3

For each copy, record why it is needed, who can access it and who decides when it is removed.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A data-flow map and a copy/owner table.

Preparation · Explain and check your result

Logs and exports are included; unknown retention rules remain questions for qualified review rather than invented legal deadlines. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A data-flow map and a copy/owner table. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Apply this toy-case rule manually: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two deleted records remain in active derived stores beyond the defined policy window. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two deleted records remain in active derived stores beyond the defined policy window. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: deletion misses the derived store. Use the glossary below, then write your prediction for: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI privacy / data-provenance specialist role interview. Explain diagnose: deletion misses the derived store using this case: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: deletion misses the derived store to a system or workflow you know. Explain diagnose: deletion misses the derived store using this case: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Record active-store checks, backup handling and any retention exceptions for qualified review. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: deletion misses the derived store using this case: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. State the evidence, one alternative and where the mental model stops.

Quiz: Deletion misses the derived store: The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately.

Change the acceptance rule after seeing an inconvenient result.

Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies.

Omit failed cases and report only the successful demonstrations.

Reference: Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. — Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. Record active-store checks, backup handling and any retention exceptions for qualified review.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Label Studio: https://labelstud.io/guide/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Data mapping and access/retention controls; technical implementation needs SQL or scripting, legal decisions need qualified review.

Terms:

Retention and deletion boundaries: Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Retention and deletion boundaries

Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything. In this role, work through: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Removing a book from one shelf does not remove all photocopies.

Boundary: Backups and trained models can require different, carefully reviewed handling.

Worked example: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Data mapping and access/retention controls; technical implementation needs SQL or scripting, legal decisions need qualified review.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI privacy / data-provenance specialist: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID.

Predict the worked case

Read this case without running a tool: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in retention and deletion boundaries.

Connect the concept to the role

Apply this rule: Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Backups and trained models can require different, carefully reviewed handling.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies retention and deletion boundaries to this case: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Retention and deletion boundaries; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with retention and deletion boundaries. Use the glossary below, then write your prediction for: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI privacy / data-provenance specialist role interview. Explain retention and deletion boundaries using this case: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate retention and deletion boundaries to a system or workflow you know. Explain retention and deletion boundaries using this case: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain retention and deletion boundaries using this case: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Delete a test record from the primary table, then inspect the index and export cache for the same stable ID.

Treat a passing starter as proof of the whole role workflow.

Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything.

Ignore the failure because the tool produced an output.

Reference: Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything. — Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything. Backups and trained models can require different, carefully reviewed handling.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Label Studio: https://labelstud.io/guide/

### Integrate: Data lineage and deletion assurance project

Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure. In this role, work through: Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: Removing a book from one shelf does not remove all photocopies.

Delete a test record from the primary table, then inspect the index and export cache for the same stable ID.

Worked example: Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-intermediate-2.md: Lineage database and deletion tests; Data-flow and retention register. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: data lineage and deletion assurance project. Use the glossary below, then write your prediction for: Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI privacy / data-provenance specialist role interview. Explain integrate: data lineage and deletion assurance project using this case: Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: data lineage and deletion assurance project to a system or workflow you know. Explain integrate: data lineage and deletion assurance project using this case: Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. Identify one observation that would contradict your claim.

Interview: Explain integrate: data lineage and deletion assurance project using this case: Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Data lineage and deletion assurance project at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.

Reference: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. — Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Label Studio: https://labelstud.io/guide/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Provenance and permitted use: Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

lineage: The trace from source data and transformations to a resulting dataset, model or decision.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Provenance and permitted use

Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse. In this role, work through: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A chain-of-custody label travels with a parcel through each handoff.

Boundary: Legal requirements depend on jurisdiction and context and require qualified review.

Worked example: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI privacy / data-provenance specialist: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission.

Predict the worked case

Read this case without running a tool: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in provenance and permitted use.

Connect the concept to the role

Apply this rule: Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Legal requirements depend on jurisdiction and context and require qualified review.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies provenance and permitted use to this case: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Provenance and permitted use; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with provenance and permitted use. Use the glossary below, then write your prediction for: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI privacy / data-provenance specialist role interview. Explain provenance and permitted use using this case: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate provenance and permitted use to a system or workflow you know. Explain provenance and permitted use using this case: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain provenance and permitted use using this case: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse.

Reference: Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse. — Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse. Legal requirements depend on jurisdiction and context and require qualified review.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Label Studio: https://labelstud.io/guide/

### Defend: Data lineage and deletion assurance project

Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. Draw data flows and write a privacy review with minimization, access, retention and unresolved questions for a qualified reviewer. In this role, work through: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A chain-of-custody label travels with a parcel through each handoff.

A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission.

Worked example: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Draw data flows and write a privacy review with minimization, access, retention and unresolved questions for a qualified reviewer.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A reviewer must reproduce one result and identify which capabilities you implemented. Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-advanced-2.md: Lineage database and deletion tests; Data-flow and retention register; Privacy review with exception handling. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: data lineage and deletion assurance project. Use the glossary below, then write your prediction for: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI privacy / data-provenance specialist role interview. Explain defend: data lineage and deletion assurance project using this case: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: data lineage and deletion assurance project to a system or workflow you know. Explain defend: data lineage and deletion assurance project using this case: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. Identify one observation that would contradict your claim.

Interview: Explain defend: data lineage and deletion assurance project using this case: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Data lineage and deletion assurance project at this level?

Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record. — Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record. Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

Label Studio: https://labelstud.io/guide/
