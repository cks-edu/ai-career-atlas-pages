# Data lineage and deletion assurance project

Career: AI privacy / data-provenance specialist
Reviewed: 2026-10-22

Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies.

## Prerequisites
Data mapping and access/retention controls; technical implementation needs SQL or scripting, legal decisions need qualified review.

## Included starter versus your implementation
DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Draw data flows and write a privacy review with minimization, access, retention and unresolved questions for a qualified reviewer.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Lineage database and deletion tests — artifact-1.md
2. Data-flow and retention register — artifact-2.md
3. Privacy review with exception handling — artifact-3.md

## Troubleshooting
- Missing CSV: run from the extracted folder.
- Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
- Wrong totals: check units, duplicate joins and whether failures are included.

## Extension
Add a permitted provider integration and verify its actual retention/deletion behavior with documented evidence.

## Primary learning resources
- DuckDB: https://duckdb.org/docs/stable/clients/python/overview — Open source · local; CSV ingestion, SQL transforms and reproducible analysis.
- NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework — Public framework · not a certification; Organize governance questions and evidence; project recommendations are editorial.
- diagrams.net: https://www.drawio.com/docs/getting-started/ — Open source editor · browser/desktop; Architecture diagrams, process maps and trust boundaries.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
