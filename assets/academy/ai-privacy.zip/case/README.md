# AI privacy / data-provenance specialist — Deletion misses the derived store

Local synthetic evidence-and-decision lab. The Python replay tests a numeric contract; it does not call a model, run a GPU workload, deploy cloud infrastructure or validate a real business decision.

## Brief
The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately.

## Contract
Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard.

## Setup
Extract this ZIP into a new empty folder. Open a terminal there for the optional Python replay. On macOS/Linux use python3; on Windows use py -3 instead. Python 3.9+; standard library only. No installation commands or paid resources. Spreadsheet/browser learners can complete the same table and memo without Python.

## 1. Set up and define the contract
Read the brief and deletion evidence ledger template. Restate the acceptance rule in your own words, including its units. Use this browser, a text editor or any spreadsheet. No coding or paid account is required. Download the pack if you want to work offline in a spreadsheet.

Exit check: You can distinguish the case contract from a general industry rule.

## 2. Inspect the evidence before checking the answer
Read evidence.csv. Make a five-row decision table using active_copy_age in hours after deletion request. Mark each record as review or within_demo_bound. Explain what a value exactly on the threshold means.

Exit check: All five records have a decision and an evidence-based reason; keep this first attempt.

## 3. Reproduce and repair the broken review rule
The supplied rule uses 96 and misses the case failures. Use the threshold and comparison controls, or edit policy.json locally, to match the stated contract. Do not edit the evidence or answer contract to make a test pass. Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. The threshold edit repairs only this replay, not the underlying system.

Exit check: Run Check policy. The fixture and boundary cases must agree with the contract.

## 4. Write the role-specific deliverable
Complete the draft template as deletion evidence ledger. Cite record IDs, state your decision, name a fictional accountable owner and distinguish observations from causal hypotheses. Address this trade-off: Deleting a source row does not establish deletion from embeddings, caches or backups; document each boundary.

Exit check: A reviewer can trace the recommendation to evidence and identify who must act.

## 5. Rehearse verification and challenge an assumption
Record active-store checks, backup handling and any retention exceptions for qualified review. Add one new example on each side of the boundary and one exactly at it. Explain how missing or unreliable evidence should be handled. For this lab, an absent numeric field is an error, not an automatic pass.

Exit check: Document expected results, one rejected alternative and a condition that reopens the finding.

## 6. Compare, revise and present
Reveal the sample only after drafting. Compare the evidence table, decision, trade-off and limitations; revise your own artifact rather than copying it. Present a two-minute explanation. Then extend the work toward: AI data-flow register — Model a synthetic support assistant.

Exit check: Export your notes and compare with a peer. Self-checkmarks do not certify the written deliverable.

## Expected execution
The original policy deliberately reports zero reviews; verify.py exits nonzero on the fixture and boundary checks. After repair, the report lists 2 review cases and all four tests pass. The report prints to standard output and does not overwrite your files.

## Troubleshooting
- Missing file: open the terminal in the extracted pack directory.
- Python missing: use the in-browser exercise; install Python only from its official distribution if you choose the local route.
- JSON error: use double quotes, numeric threshold and no trailing comma.
- Fixture passes but boundary fails: distinguish > from >= and keep the stated units.
- Missing evidence: reject the malformed record for review; do not silently treat missing as zero.

## Files and answer disclosure
policy.json is the intentionally broken rule; contract.json contains the check oracle. sample-deliverable.md is the worked answer. Keep them closed until you have made an attempt. learner-deliverable.md is your editable template. In-browser notes are separate from these local files.

## Sources
- NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
- PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
- Label Studio: https://labelstud.io/guide/
