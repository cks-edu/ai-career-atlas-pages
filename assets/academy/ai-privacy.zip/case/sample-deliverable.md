# SAMPLE — Deletion evidence ledger
Role: AI privacy / data-provenance specialist
Case: Deletion misses the derived store
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately.

## Evidence table
| Record | active_copy_age (hours after deletion request) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 20 | within_demo_bound |
| case-3 | 25 | review |
| case-4 | 72 | review |
| case-5 | 4 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two deleted records remain in active derived stores beyond the defined policy window.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai privacy / data-provenance specialist.
Before release: Record active-store checks, backup handling and any retention exceptions for qualified review.

## Design choice and trade-off
Track lineage and responsible owners across derived copies; minimize unnecessary sensitive logging.
Deleting a source row does not establish deletion from embeddings, caches or backups; document each boundary.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
AI data-flow register: Derived embeddings, logs and backups are considered explicitly.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
