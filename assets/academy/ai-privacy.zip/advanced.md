## advanced — Provenance and permitted use

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Provenance and permitted use
Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse.
Mental model: A chain-of-custody label travels with a parcel through each handoff.
Boundary: Legal requirements depend on jurisdiction and context and require qualified review.
Worked example: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Data lineage and deletion assurance project
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. Draw data flows and write a privacy review with minimization, access, retention and unresolved questions for a qualified reviewer.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Recall: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. Identify one observation that would contradict your claim.

### Terms
Provenance and permitted use: Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Draw data flows and write a privacy review with minimization, access, retention and unresolved questions for a qualified reviewer.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies.
Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.
Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Draw data flows and write a privacy review with minimization, access, retention and unresolved questions for a qualified reviewer.
Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.
Add a permitted provider integration and verify its actual retention/deletion behavior with documented evidence.
Deliverables: Lineage database and deletion tests; Data-flow and retention register; Privacy review with exception handling. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A reviewer must reproduce one result and identify which capabilities you implemented. Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.

### Interview
Explain your advanced solution for AI privacy / data-provenance specialist. Use this scenario: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Review: Start with the task and permitted scope. Explain provenance and permitted use: Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse. Show the input and observed output, then address Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Lineage database and deletion tests; Data-flow and retention register; Privacy review with exception handling. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

