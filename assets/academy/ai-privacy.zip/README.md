# AI privacy / data-provenance specialist

AI Engineering · Beginner → Intermediate → Advanced

Start with Data flow and minimization. Personal data can appear in source files, retrieved passages, logs and exports. Removing the original does not automatically remove every copy. Then try Trace fictional personal information. The three levels build toward Data lineage and deletion assurance project. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Data flow and minimization

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Data flow and minimization
Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training.
Mental model: Pack only what is needed for a journey and know who carries each bag.
Boundary: Removing obvious identifiers does not guarantee anonymity.
Worked example: A support classifier needs message content but not a customer's full payment card details; use synthetic records in the exercise.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Deletion misses the derived store
The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Two deleted records remain in active derived stores beyond the defined policy window. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies.
Recall: Record active-store checks, backup handling and any retention exceptions for qualified review. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Data flow and minimization: Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Personal data can appear in source files, retrieved passages, logs and exports. Removing the original does not automatically remove every copy.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use an invented record: learner Alex, email alex@example.test, question about a course.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A data-flow map and a copy/owner table.

3. Try step 2
Draw its path through a form, document store, assistant context, error log and downloaded report.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A data-flow map and a copy/owner table.

4. Try step 3
For each copy, record why it is needed, who can access it and who decides when it is removed.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A data-flow map and a copy/owner table.

5. Explain and check your result
Logs and exports are included; unknown retention rules remain questions for qualified review rather than invented legal deadlines. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A data-flow map and a copy/owner table. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Apply this toy-case rule manually: Review when active_copy_age > 24 (hours after deletion request). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two deleted records remain in active derived stores beyond the defined policy window. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI privacy / data-provenance specialist.
Use an invented record: learner Alex, email alex@example.test, question about a course.
Draw its path through a form, document store, assistant context, error log and downloaded report.
For each copy, record why it is needed, who can access it and who decides when it is removed.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A data-flow map and a copy/owner table. Include beginner-worksheet.md and your completed Deletion evidence ledger.
Check: Logs and exports are included; unknown retention rules remain questions for qualified review rather than invented legal deadlines.

### Interview
Explain your beginner solution for AI privacy / data-provenance specialist. Use this scenario: The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately.
Review: Start with the task and permitted scope. Explain data flow and minimization: Trace what data enters, where it is stored, who accesses it and how it leaves. Remove fields that are unnecessary for the declared purpose before sharing or training. Show the input and observed output, then address Trace source IDs through chunks, embeddings and logs, then remove or quarantine residual copies. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A data-flow map and a copy/owner table. Include beginner-worksheet.md and your completed Deletion evidence ledger.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Retention and deletion boundaries

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Data mapping and access/retention controls; technical implementation needs SQL or scripting, legal decisions need qualified review.

### Retention and deletion boundaries
Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything.
Mental model: Removing a book from one shelf does not remove all photocopies.
Boundary: Backups and trained models can require different, carefully reviewed handling.
Worked example: Delete a test record from the primary table, then inspect the index and export cache for the same stable ID.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Data lineage and deletion assurance project
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Recall: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. Identify one observation that would contradict your claim.

### Terms
Retention and deletion boundaries: Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The fictional retention policy requires deletion from active derived stores within 24 hours; backups are reviewed separately. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies.
Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.
Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.
Deliverables: Lineage database and deletion tests; Data-flow and retention register. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI privacy / data-provenance specialist. Use this scenario: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Review: Start with the task and permitted scope. Explain retention and deletion boundaries: Define retention periods and deletion responsibilities across copies, logs, caches and derived artifacts. Verify the actual path rather than assuming one delete button reaches everything. Show the input and observed output, then address Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Lineage database and deletion tests; Data-flow and retention register. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Provenance and permitted use

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Provenance and permitted use
Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse.
Mental model: A chain-of-custody label travels with a parcel through each handoff.
Boundary: Legal requirements depend on jurisdiction and context and require qualified review.
Worked example: A dataset has a public download link but unclear reuse terms; mark permission unresolved instead of treating public access as permission.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Data lineage and deletion assurance project
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. Draw data flows and write a privacy review with minimization, access, retention and unresolved questions for a qualified reviewer.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Recall: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. Identify one observation that would contradict your claim.

### Terms
Provenance and permitted use: Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
lineage: The trace from source data and transformations to a resulting dataset, model or decision.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Draw data flows and write a privacy review with minimization, access, retention and unresolved questions for a qualified reviewer.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Trace personal-data-like synthetic records through an AI pipeline and prove deletion across derived copies.
Create fictional records with subject ID, consent purpose, source, retention date and derived document IDs. Do not use actual personal information.
Build DuckDB lineage tables from source to normalized text, chunks, embeddings placeholder and cache. Separate direct identifiers from content and record purpose constraints.
Create a deletion job that finds every descendant of a subject/source ID and records a tombstone plus completion evidence. Document backup and external-provider limits instead of claiming immediate universal erasure.
Draw data flows and write a privacy review with minimization, access, retention and unresolved questions for a qualified reviewer.
Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction.
Add a permitted provider integration and verify its actual retention/deletion behavior with documented evidence.
Deliverables: Lineage database and deletion tests; Data-flow and retention register; Privacy review with exception handling. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A reviewer must reproduce one result and identify which capabilities you implemented. Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.

### Interview
Explain your advanced solution for AI privacy / data-provenance specialist. Use this scenario: Delete a source while an update job is running; prevent the later job from recreating removed descendants. Test an orphaned cache entry and an expired retention record.
Review: Start with the task and permitted scope. Explain provenance and permitted use: Keep evidence of origin, consent or other applicable permissions, transformations and usage restrictions. Flag uncertainty before downstream reuse. Show the input and observed output, then address Report lineage completeness, deletion lag and remaining exceptions. A technical deletion test is not proof of compliance with every jurisdiction. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Lineage database and deletion tests; Data-flow and retention register; Privacy review with exception handling. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
DuckDB — Open source · local
CSV ingestion, SQL transforms and reproducible analysis.
Alternative: SQLite (public domain) for embedded transactional SQL or PostgreSQL (open source) for a shared service.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

NIST AI RMF — Public framework · not a certification
Organize governance questions and evidence; project recommendations are editorial.
Alternative: OECD AI Principles provide another public perspective; frameworks complement one another and are not automatic certifications.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

diagrams.net — Open source editor · browser/desktop
Architecture diagrams, process maps and trust boundaries.
Alternative: Mermaid (open source) for text diagrams or Microsoft Visio (commercial); choose an editable format teammates can use.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
DuckDB: https://duckdb.org/docs/stable/clients/python/overview
NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework
diagrams.net: https://www.drawio.com/docs/getting-started/
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
Label Studio: https://labelstud.io/guide/
