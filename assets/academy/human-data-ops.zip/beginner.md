## beginner — Annotation workflow design

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Annotation workflow design
Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning.
Mental model: A production line needs quality checks and safe working conditions at each station.
Boundary: A workflow diagram does not demonstrate fair labor practices or real throughput.
Worked example: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A fast queue accumulates unresolved disputes
The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Two batches exceed the agreed unresolved-dispute allowance despite high throughput. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Pause acceptance for disputed labels, clarify instructions and assign an adjudicator.
Recall: Audit a fresh sample for error types and guideline adherence after recalibration. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Annotation workflow design: Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Annotation means adding labels to examples. Consistent instructions and a route for ambiguous cases matter as much as throughput.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Label fictional messages “Great help”, “This did not work” and “Fine, I guess” as positive, negative or uncertain.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A short labeling guide, labeled examples and an escalation rule.

3. Try step 2
Write a rule and an example for each label, then define who reviews uncertain items.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A short labeling guide, labeled examples and an escalation rule.

4. Try step 3
Ask a peer to label the same messages if available; otherwise write two plausible interpretations of the ambiguous message and label them as hypothetical.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A short labeling guide, labeled examples and an escalation rule.

5. Explain and check your result
Ambiguity is visible and reviewable; simulated disagreements are not reported as measured worker agreement. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A short labeling guide, labeled examples and an escalation rule. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Apply this toy-case rule manually: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two batches exceed the agreed unresolved-dispute allowance despite high throughput. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Human-data operations / annotation-quality lead.
Label fictional messages “Great help”, “This did not work” and “Fine, I guess” as positive, negative or uncertain.
Write a rule and an example for each label, then define who reviews uncertain items.
Ask a peer to label the same messages if available; otherwise write two plausible interpretations of the ambiguous message and label them as hypothetical.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A short labeling guide, labeled examples and an escalation rule. Include beginner-worksheet.md and your completed Annotation operations scorecard and escalation playbook.
Check: Ambiguity is visible and reviewable; simulated disagreements are not reported as measured worker agreement.

### Interview
Explain your beginner solution for Human-data operations / annotation-quality lead. Use this scenario: The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch.
Review: Start with the task and permitted scope. Explain annotation workflow design: Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning. Show the input and observed output, then address Pause acceptance for disputed labels, clarify instructions and assign an adjudicator. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A short labeling guide, labeled examples and an escalation rule. Include beginner-worksheet.md and your completed Annotation operations scorecard and escalation playbook.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

