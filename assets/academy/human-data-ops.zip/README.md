# Human-data operations / annotation-quality lead

AI Engineering · Beginner → Intermediate → Advanced

Start with Annotation workflow design. Annotation means adding labels to examples. Consistent instructions and a route for ambiguous cases matter as much as throughput. Then try Design a labeling workflow. The three levels build toward Annotation operations and quality system. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Annotation workflow design

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Annotation workflow design
Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning.
Mental model: A production line needs quality checks and safe working conditions at each station.
Boundary: A workflow diagram does not demonstrate fair labor practices or real throughput.
Worked example: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A fast queue accumulates unresolved disputes
The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Two batches exceed the agreed unresolved-dispute allowance despite high throughput. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Pause acceptance for disputed labels, clarify instructions and assign an adjudicator.
Recall: Audit a fresh sample for error types and guideline adherence after recalibration. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Annotation workflow design: Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Annotation means adding labels to examples. Consistent instructions and a route for ambiguous cases matter as much as throughput.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Label fictional messages “Great help”, “This did not work” and “Fine, I guess” as positive, negative or uncertain.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A short labeling guide, labeled examples and an escalation rule.

3. Try step 2
Write a rule and an example for each label, then define who reviews uncertain items.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A short labeling guide, labeled examples and an escalation rule.

4. Try step 3
Ask a peer to label the same messages if available; otherwise write two plausible interpretations of the ambiguous message and label them as hypothetical.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A short labeling guide, labeled examples and an escalation rule.

5. Explain and check your result
Ambiguity is visible and reviewable; simulated disagreements are not reported as measured worker agreement. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A short labeling guide, labeled examples and an escalation rule. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Apply this toy-case rule manually: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two batches exceed the agreed unresolved-dispute allowance despite high throughput. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Human-data operations / annotation-quality lead.
Label fictional messages “Great help”, “This did not work” and “Fine, I guess” as positive, negative or uncertain.
Write a rule and an example for each label, then define who reviews uncertain items.
Ask a peer to label the same messages if available; otherwise write two plausible interpretations of the ambiguous message and label them as hypothetical.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A short labeling guide, labeled examples and an escalation rule. Include beginner-worksheet.md and your completed Annotation operations scorecard and escalation playbook.
Check: Ambiguity is visible and reviewable; simulated disagreements are not reported as measured worker agreement.

### Interview
Explain your beginner solution for Human-data operations / annotation-quality lead. Use this scenario: The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch.
Review: Start with the task and permitted scope. Explain annotation workflow design: Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning. Show the input and observed output, then address Pause acceptance for disputed labels, clarify instructions and assign an adjudicator. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A short labeling guide, labeled examples and an escalation rule. Include beginner-worksheet.md and your completed Annotation operations scorecard and escalation playbook.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Agreement and adjudication

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Sampling, quality measurement, instruction design and workforce coordination; spreadsheets and basic SQL are useful.

### Agreement and adjudication
Measure disagreement on overlapping tasks and inspect its causes. Distinguish instruction ambiguity, genuine uncertainty and reviewer mistakes before changing the process.
Mental model: Two inspectors disagreeing may reveal a vague specification rather than a careless inspector.
Boundary: High agreement alone does not prove labels are correct.
Worked example: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Annotation operations and quality system
Design an annotation programme with clear instructions, fair review and traceable quality control. Assign overlapping review samples and maintain a work ledger with task status, review reason and resolution. Keep calibration answers separate from annotator instructions.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator.
Recall: Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. Identify one observation that would contradict your claim.

### Terms
Agreement and adjudication: Measure disagreement on overlapping tasks and inspect its causes. Distinguish instruction ambiguity, genuine uncertainty and reviewer mistakes before changing the process.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design an annotation programme with clear instructions, fair review and traceable quality control. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Configure a Label Studio project using the supplied labeling XML. Pilot the instructions on ten cases and revise unclear labels before full annotation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Assign overlapping review samples and maintain a work ledger with task status, review reason and resolution. Keep calibration answers separate from annotator instructions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design an annotation programme with clear instructions, fair review and traceable quality control.
Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator.
Configure a Label Studio project using the supplied labeling XML. Pilot the instructions on ten cases and revise unclear labels before full annotation.
Assign overlapping review samples and maintain a work ledger with task status, review reason and resolution. Keep calibration answers separate from annotator instructions.
Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs.
Deliverables: Annotation guide and configured project; Sampling/quality workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Human-data operations / annotation-quality lead. Use this scenario: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.
Review: Start with the task and permitted scope. Explain agreement and adjudication: Measure disagreement on overlapping tasks and inspect its causes. Distinguish instruction ambiguity, genuine uncertainty and reviewer mistakes before changing the process. Show the input and observed output, then address Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Annotation guide and configured project; Sampling/quality workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Quality sampling and rework

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Quality sampling and rework
Use a declared sampling plan and feedback loop to detect defects in batches. Track rejected work, rework and unresolved cases rather than reporting only completed volume.
Mental model: Inspect shipments and record returns as well as boxes sent.
Boundary: Sample-based review can miss rare or clustered defects.
Worked example: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Annotation operations and quality system
Design an annotation programme with clear instructions, fair review and traceable quality control. Create a quality dashboard and escalation process. Document workload assumptions, feedback timing and how disputed judgments can be appealed.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.
Recall: Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. Identify one observation that would contradict your claim.

### Terms
Quality sampling and rework: Use a declared sampling plan and feedback loop to detect defects in batches. Track rejected work, rework and unresolved cases rather than reporting only completed volume.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design an annotation programme with clear instructions, fair review and traceable quality control. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Configure a Label Studio project using the supplied labeling XML. Pilot the instructions on ten cases and revise unclear labels before full annotation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Assign overlapping review samples and maintain a work ledger with task status, review reason and resolution. Keep calibration answers separate from annotator instructions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create a quality dashboard and escalation process. Document workload assumptions, feedback timing and how disputed judgments can be appealed.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design an annotation programme with clear instructions, fair review and traceable quality control.
Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator.
Configure a Label Studio project using the supplied labeling XML. Pilot the instructions on ten cases and revise unclear labels before full annotation.
Assign overlapping review samples and maintain a work ledger with task status, review reason and resolution. Keep calibration answers separate from annotator instructions.
Create a quality dashboard and escalation process. Document workload assumptions, feedback timing and how disputed judgments can be appealed.
Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.
Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs.
Run a second pilot with revised guidance and compare quality on fresh, difficulty-matched tasks.
Deliverables: Annotation guide and configured project; Sampling/quality workbook; Operations playbook with version-change procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.

### Interview
Explain your advanced solution for Human-data operations / annotation-quality lead. Use this scenario: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.
Review: Start with the task and permitted scope. Explain quality sampling and rework: Use a declared sampling plan and feedback loop to detect defects in batches. Track rejected work, rework and unresolved cases rather than reporting only completed volume. Show the input and observed output, then address Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Annotation guide and configured project; Sampling/quality workbook; Operations playbook with version-change procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Label Studio — Open source Community · commercial editions optional
Configure annotation tasks and export reviewer judgments.
Alternative: A reviewed CSV workbook for small batches, or a commercial annotation platform; access, adjudication and export matter more than brand.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

NIST AI RMF — Public framework · not a certification
Organize governance questions and evidence; project recommendations are editorial.
Alternative: OECD AI Principles provide another public perspective; frameworks complement one another and are not automatic certifications.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Label Studio: https://labelstud.io/guide/quick_start
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework
Label Studio: https://labelstud.io/guide/
PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
