# Human-data operations / annotation-quality lead — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Annotation workflow design: Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Annotation workflow design

Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning. In this role, work through: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A production line needs quality checks and safe working conditions at each station.

Boundary: A workflow diagram does not demonstrate fair labor practices or real throughput.

Worked example: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Human-data operations / annotation-quality lead: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch.

Predict the worked case

Read this case without running a tool: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in annotation workflow design.

Connect the concept to the role

Apply this rule: Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A workflow diagram does not demonstrate fair labor practices or real throughput.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies annotation workflow design to this case: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Annotation workflow design; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with annotation workflow design. Use the glossary below, then write your prediction for: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Human-data operations / annotation-quality lead role interview. Explain annotation workflow design using this case: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate annotation workflow design to a system or workflow you know. Explain annotation workflow design using this case: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain annotation workflow design using this case: Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch.

Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning. — Define task instructions, qualification, assignment, review and escalation before scaling labeling. Make compensation, data access and difficult-content support part of operations planning. A workflow diagram does not demonstrate fair labor practices or real throughput.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Diagnose: A fast queue accumulates unresolved disputes

The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Two batches exceed the agreed unresolved-dispute allowance despite high throughput. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Pause acceptance for disputed labels, clarify instructions and assign an adjudicator. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A production line needs quality checks and safe working conditions at each station.

Labelers receive a glossary and five calibration cases before accessing a bounded synthetic batch.

Worked example: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Pause acceptance for disputed labels, clarify instructions and assign an adjudicator.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Two batches exceed the agreed unresolved-dispute allowance despite high throughput. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Apply this toy-case rule manually: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Annotation means adding labels to examples. Consistent instructions and a route for ambiguous cases matter as much as throughput.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Label fictional messages “Great help”, “This did not work” and “Fine, I guess” as positive, negative or uncertain.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A short labeling guide, labeled examples and an escalation rule.

Preparation · Try step 2

Write a rule and an example for each label, then define who reviews uncertain items.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A short labeling guide, labeled examples and an escalation rule.

Preparation · Try step 3

Ask a peer to label the same messages if available; otherwise write two plausible interpretations of the ambiguous message and label them as hypothetical.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A short labeling guide, labeled examples and an escalation rule.

Preparation · Explain and check your result

Ambiguity is visible and reviewable; simulated disagreements are not reported as measured worker agreement. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A short labeling guide, labeled examples and an escalation rule. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Apply this toy-case rule manually: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two batches exceed the agreed unresolved-dispute allowance despite high throughput. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two batches exceed the agreed unresolved-dispute allowance despite high throughput. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a fast queue accumulates unresolved disputes. Use the glossary below, then write your prediction for: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Pause acceptance for disputed labels, clarify instructions and assign an adjudicator. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Human-data operations / annotation-quality lead role interview. Explain diagnose: a fast queue accumulates unresolved disputes using this case: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Pause acceptance for disputed labels, clarify instructions and assign an adjudicator. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a fast queue accumulates unresolved disputes to a system or workflow you know. Explain diagnose: a fast queue accumulates unresolved disputes using this case: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Pause acceptance for disputed labels, clarify instructions and assign an adjudicator. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Audit a fresh sample for error types and guideline adherence after recalibration. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a fast queue accumulates unresolved disputes using this case: Review when unresolved_disputes >= 3 (out of ten items). This is a declared toy-case contract, not an industry standard. Pause acceptance for disputed labels, clarify instructions and assign an adjudicator. State the evidence, one alternative and where the mental model stops.

Quiz: A fast queue accumulates unresolved disputes: The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch.

Change the acceptance rule after seeing an inconvenient result.

Pause acceptance for disputed labels, clarify instructions and assign an adjudicator.

Omit failed cases and report only the successful demonstrations.

Reference: Pause acceptance for disputed labels, clarify instructions and assign an adjudicator. — Pause acceptance for disputed labels, clarify instructions and assign an adjudicator. Audit a fresh sample for error types and guideline adherence after recalibration.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Sampling, quality measurement, instruction design and workforce coordination; spreadsheets and basic SQL are useful.

Terms:

Agreement and adjudication: Measure disagreement on overlapping tasks and inspect its causes. Distinguish instruction ambiguity, genuine uncertainty and reviewer mistakes before changing the process.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Agreement and adjudication

Measure disagreement on overlapping tasks and inspect its causes. Distinguish instruction ambiguity, genuine uncertainty and reviewer mistakes before changing the process. In this role, work through: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Two inspectors disagreeing may reveal a vague specification rather than a careless inspector.

Boundary: High agreement alone does not prove labels are correct.

Worked example: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Sampling, quality measurement, instruction design and workforce coordination; spreadsheets and basic SQL are useful.

Tools for this exercise: Document or text editor

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Human-data operations / annotation-quality lead: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration.

Predict the worked case

Read this case without running a tool: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in agreement and adjudication.

Connect the concept to the role

Apply this rule: Measure disagreement on overlapping tasks and inspect its causes. Distinguish instruction ambiguity, genuine uncertainty and reviewer mistakes before changing the process. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: High agreement alone does not prove labels are correct.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies agreement and adjudication to this case: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Agreement and adjudication; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with agreement and adjudication. Use the glossary below, then write your prediction for: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Human-data operations / annotation-quality lead role interview. Explain agreement and adjudication using this case: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate agreement and adjudication to a system or workflow you know. Explain agreement and adjudication using this case: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain agreement and adjudication using this case: If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration.

Treat a passing starter as proof of the whole role workflow.

Measure disagreement on overlapping tasks and inspect its causes. Distinguish instruction ambiguity, genuine uncertainty and reviewer mistakes before changing the process.

Ignore the failure because the tool produced an output.

Reference: Measure disagreement on overlapping tasks and inspect its causes. Distinguish instruction ambiguity, genuine uncertainty and reviewer mistakes before changing the process. — Measure disagreement on overlapping tasks and inspect its causes. Distinguish instruction ambiguity, genuine uncertainty and reviewer mistakes before changing the process. High agreement alone does not prove labels are correct.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Integrate: Annotation operations and quality system

Design an annotation programme with clear instructions, fair review and traceable quality control. Assign overlapping review samples and maintain a work ledger with task status, review reason and resolution. Keep calibration answers separate from annotator instructions. In this role, work through: Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: Two inspectors disagreeing may reveal a vague specification rather than a careless inspector.

If reviewers disagree on mixed-intent tickets, add a multi-label rule or an escalation category and retest calibration.

Worked example: Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Design an annotation programme with clear instructions, fair review and traceable quality control. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design an annotation programme with clear instructions, fair review and traceable quality control.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

Prepare the project inputs

Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Configure a Label Studio project using the supplied labeling XML. Pilot the instructions on ten cases and revise unclear labels before full annotation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Assign overlapping review samples and maintain a work ledger with task status, review reason and resolution. Keep calibration answers separate from annotator instructions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Annotation guide and configured project; Sampling/quality workbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: annotation operations and quality system. Use the glossary below, then write your prediction for: Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Human-data operations / annotation-quality lead role interview. Explain integrate: annotation operations and quality system using this case: Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: annotation operations and quality system to a system or workflow you know. Explain integrate: annotation operations and quality system using this case: Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. Identify one observation that would contradict your claim.

Interview: Explain integrate: annotation operations and quality system using this case: Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Annotation operations and quality system at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs.

Reference: Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. — Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Quality sampling and rework: Use a declared sampling plan and feedback loop to detect defects in batches. Track rejected work, rework and unresolved cases rather than reporting only completed volume.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Quality sampling and rework

Use a declared sampling plan and feedback loop to detect defects in batches. Track rejected work, rework and unresolved cases rather than reporting only completed volume. In this role, work through: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect shipments and record returns as well as boxes sent.

Boundary: Sample-based review can miss rare or clustered defects.

Worked example: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Human-data operations / annotation-quality lead: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data.

Predict the worked case

Read this case without running a tool: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in quality sampling and rework.

Connect the concept to the role

Apply this rule: Use a declared sampling plan and feedback loop to detect defects in batches. Track rejected work, rework and unresolved cases rather than reporting only completed volume. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Sample-based review can miss rare or clustered defects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies quality sampling and rework to this case: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Quality sampling and rework; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with quality sampling and rework. Use the glossary below, then write your prediction for: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Human-data operations / annotation-quality lead role interview. Explain quality sampling and rework using this case: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate quality sampling and rework to a system or workflow you know. Explain quality sampling and rework using this case: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain quality sampling and rework using this case: A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Use a declared sampling plan and feedback loop to detect defects in batches. Track rejected work, rework and unresolved cases rather than reporting only completed volume.

Reference: Use a declared sampling plan and feedback loop to detect defects in batches. Track rejected work, rework and unresolved cases rather than reporting only completed volume. — Use a declared sampling plan and feedback loop to detect defects in batches. Track rejected work, rework and unresolved cases rather than reporting only completed volume. Sample-based review can miss rare or clustered defects.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Defend: Annotation operations and quality system

Design an annotation programme with clear instructions, fair review and traceable quality control. Create a quality dashboard and escalation process. Document workload assumptions, feedback timing and how disputed judgments can be appealed. In this role, work through: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: Inspect shipments and record returns as well as boxes sent.

A sample reveals a recurring label error; isolate the affected batch, clarify instructions and recheck before merging it into training data.

Worked example: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Design an annotation programme with clear instructions, fair review and traceable quality control. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design an annotation programme with clear instructions, fair review and traceable quality control.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

Prepare the project inputs

Create 60 synthetic classification tasks, including ambiguous cases and ten calibration items. Define roles for annotator, reviewer and adjudicator.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Configure a Label Studio project using the supplied labeling XML. Pilot the instructions on ten cases and revise unclear labels before full annotation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Assign overlapping review samples and maintain a work ledger with task status, review reason and resolution. Keep calibration answers separate from annotator instructions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Create a quality dashboard and escalation process. Document workload assumptions, feedback timing and how disputed judgments can be appealed.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Annotation guide and configured project; Sampling/quality workbook; Operations playbook with version-change procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: annotation operations and quality system. Use the glossary below, then write your prediction for: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Human-data operations / annotation-quality lead role interview. Explain defend: annotation operations and quality system using this case: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: annotation operations and quality system to a system or workflow you know. Explain defend: annotation operations and quality system using this case: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs. Identify one observation that would contradict your claim.

Interview: Explain defend: annotation operations and quality system using this case: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Annotation operations and quality system at this level?

Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators. — Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators. Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
