# Sampling/quality workbook

Project: Annotation operations and quality system
Status: blank work product — not completed evidence

## Purpose and audience
Design an annotation programme with clear instructions, fair review and traceable quality control.

## Required content
Assign overlapping review samples and maintain a work ledger with task status, review reason and resolution. Keep calibration answers separate from annotator instructions.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs.

## Failure evidence
Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
