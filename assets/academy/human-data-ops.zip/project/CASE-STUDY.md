# Annotation operations and quality system

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Design an annotation programme with clear instructions, fair review and traceable quality control.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report agreement, rework, unresolved ambiguity and turnaround distribution. Avoid ranking people by raw speed when task difficulty differs.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Introduce inconsistent guidance midway through a pilot. Version the instructions, identify affected tasks and arrange targeted re-review rather than blaming annotators.

## Limitations and next iteration
Run a second pilot with revised guidance and compare quality on fresh, difficulty-matched tasks.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
