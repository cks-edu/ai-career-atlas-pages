# Label Studio setup

Create a local project. Import annotation-tasks.json as JSON tasks. In Labeling Setup choose Code and paste label-config.xml. Replace the demonstration labels with your role-specific rubric, then label the sample tasks and export JSON. Preserve original annotations and adjudication separately. The two sample tasks are UI smoke fixtures, not a benchmark.
