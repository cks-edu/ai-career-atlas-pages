# SAMPLE — Annotation operations scorecard and escalation playbook
Role: Human-data operations / annotation-quality lead
Case: A fast queue accumulates unresolved disputes
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The labeling pilot flags more than two unresolved disputed items in a ten-item audit batch.

## Evidence table
| Record | unresolved_disputes (out of ten items) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 5 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two batches exceed the agreed unresolved-dispute allowance despite high throughput.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Pause acceptance for disputed labels, clarify instructions and assign an adjudicator.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in human-data operations / annotation-quality lead.
Before release: Audit a fresh sample for error types and guideline adherence after recalibration.

## Design choice and trade-off
Version guidelines and calibration sets; separate reviewer errors from ambiguous instructions.
Speed targets can worsen quality if difficult cases are hidden or rushed; report rework and case mix.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Annotation operations playbook: Includes quality gates, escalation and workload assumptions.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
