# Databricks Data Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
DataFrames and schemas

A DataFrame is a structured dataset with a schema; inferred types can change when new input arrives. Declare important types and inspect rejected or null conversions.
Mental model: A labeled table keeps every column's meaning consistent across batches.
Case: Amount ten should not silently become a valid numeric amount.
Task: Run the local fixture, then use an authorized Databricks workspace tutorial to load equivalent synthetic data with an explicit schema. Inspect rows and types before transformation.
Acceptance: Two valid unique orders and a documented invalid-value policy.
Troubleshooting: Schema inference on a tiny sample can misclassify later values; enforce the intended contract.
Deliverable: notebook and schema/rejection report

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Delta updates and replay

A merge needs a stable key and unambiguous source records. Multiple source updates for one target require a deterministic ordering/correction rule.
Mental model: A revised ledger entry needs both its account number and revision order.
Case: Order a at version 2 replaces version 1; replay does not create another order.
Task: Create versioned order fixtures, deduplicate source changes by the stated rule and implement a Delta MERGE in a lab workspace. Test replay and stale input; compare counts and totals.
Acceptance: Newer correction wins once and stale data does not overwrite it.
Troubleshooting: A duplicate source key can make a merge ambiguous; resolve it before the merge.
Deliverable: Delta merge notebook and replay tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Jobs, governance and recovery

A scheduled job needs identity, dependency handling, monitoring and data-quality gates. Catalog permissions and runtime configuration affect reproducibility and access.
Mental model: A production schedule assigns both the worker and the permitted materials.
Case: A notebook that completes but loses one source order must fail the publishing gate.
Task: Define a job DAG, inject a missing-row fixture and block downstream publication. Write catalog access, compute-cost and rollback assumptions; retain run IDs and quality results.
Acceptance: A visible failed quality gate and a recoverable rerun plan.
Troubleshooting: Notebook success alone does not certify business data completeness.
Deliverable: Databricks job design and operational runbook

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
