# Databricks Data Engineer

Software Engineering

Start with dataframes and schemas. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward Databricks job design and operational runbook.

## beginner

Run the local fixture, then use an authorized Databricks workspace tutorial to load equivalent synthetic data with an explicit schema. Inspect rows and types before transformation.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### DataFrames and schemas
A DataFrame is a structured dataset with a schema; inferred types can change when new input arrives. Declare important types and inspect rejected or null conversions.
Mental model: A labeled table keeps every column's meaning consistent across batches.
Limit: Schema inference on a tiny sample can misclassify later values; enforce the intended contract.
Example: Amount ten should not silently become a valid numeric amount.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Schema inference on a tiny sample can misclassify later values; enforce the intended contract.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Amount ten should not silently become a valid numeric amount. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run the local fixture, then use an authorized Databricks workspace tutorial to load equivalent synthetic data with an explicit schema. Inspect rows and types before transformation.
Expected: Two valid unique orders and a documented invalid-value policy.

6. Role workshop · debug and verify
Schema inference on a tiny sample can misclassify later values; enforce the intended contract. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save notebook and schema/rejection report. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Two valid unique orders and a documented invalid-value policy.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
DataFrames and schemas: Schema inference on a tiny sample can misclassify later values; enforce the intended contract.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: notebook and schema/rejection report
Two valid unique orders and a documented invalid-value policy.

Interview: Work through this Databricks Data Engineer case: Amount ten should not silently become a valid numeric amount. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A DataFrame is a structured dataset with a schema; inferred types can change when new input arrives. Declare important types and inspect rejected or null conversions. Expected evidence: Two valid unique orders and a documented invalid-value policy. Diagnosis: Schema inference on a tiny sample can misclassify later values; enforce the intended contract. State the limits of the mental model: A labeled table keeps every column's meaning consistent across batches.

Resume: Built notebook and schema/rejection report using Databricks, Apache Spark, Delta Lake and Unity Catalog; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create versioned order fixtures, deduplicate source changes by the stated rule and implement a Delta MERGE in a lab workspace. Test replay and stale input; compare counts and totals.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Delta updates and replay
A merge needs a stable key and unambiguous source records. Multiple source updates for one target require a deterministic ordering/correction rule.
Mental model: A revised ledger entry needs both its account number and revision order.
Limit: A duplicate source key can make a merge ambiguous; resolve it before the merge.
Example: Order a at version 2 replaces version 1; replay does not create another order.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A duplicate source key can make a merge ambiguous; resolve it before the merge.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Order a at version 2 replaces version 1; replay does not create another order. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create versioned order fixtures, deduplicate source changes by the stated rule and implement a Delta MERGE in a lab workspace. Test replay and stale input; compare counts and totals.
Expected: Newer correction wins once and stale data does not overwrite it.

6. Role workshop · debug and verify
A duplicate source key can make a merge ambiguous; resolve it before the merge. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Delta merge notebook and replay tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Newer correction wins once and stale data does not overwrite it.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Delta updates and replay: A duplicate source key can make a merge ambiguous; resolve it before the merge.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Delta merge notebook and replay tests
Newer correction wins once and stale data does not overwrite it.

Interview: Work through this Databricks Data Engineer case: Order a at version 2 replaces version 1; replay does not create another order. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A merge needs a stable key and unambiguous source records. Multiple source updates for one target require a deterministic ordering/correction rule. Expected evidence: Newer correction wins once and stale data does not overwrite it. Diagnosis: A duplicate source key can make a merge ambiguous; resolve it before the merge. State the limits of the mental model: A revised ledger entry needs both its account number and revision order.

Resume: Built Delta merge notebook and replay tests using Databricks, Apache Spark, Delta Lake and Unity Catalog; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Define a job DAG, inject a missing-row fixture and block downstream publication. Write catalog access, compute-cost and rollback assumptions; retain run IDs and quality results.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Jobs, governance and recovery
A scheduled job needs identity, dependency handling, monitoring and data-quality gates. Catalog permissions and runtime configuration affect reproducibility and access.
Mental model: A production schedule assigns both the worker and the permitted materials.
Limit: Notebook success alone does not certify business data completeness.
Example: A notebook that completes but loses one source order must fail the publishing gate.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Notebook success alone does not certify business data completeness.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A notebook that completes but loses one source order must fail the publishing gate. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Define a job DAG, inject a missing-row fixture and block downstream publication. Write catalog access, compute-cost and rollback assumptions; retain run IDs and quality results.
Expected: A visible failed quality gate and a recoverable rerun plan.

6. Role workshop · debug and verify
Notebook success alone does not certify business data completeness. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Databricks job design and operational runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A visible failed quality gate and a recoverable rerun plan.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Jobs, governance and recovery: Notebook success alone does not certify business data completeness.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Databricks job design and operational runbook
A visible failed quality gate and a recoverable rerun plan.

Interview: Work through this Databricks Data Engineer case: A notebook that completes but loses one source order must fail the publishing gate. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A scheduled job needs identity, dependency handling, monitoring and data-quality gates. Catalog permissions and runtime configuration affect reproducibility and access. Expected evidence: A visible failed quality gate and a recoverable rerun plan. Diagnosis: Notebook success alone does not certify business data completeness. State the limits of the mental model: A production schedule assigns both the worker and the permitted materials.

Resume: Built Databricks job design and operational runbook using Databricks, Apache Spark, Delta Lake and Unity Catalog; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Databricks getting-started tutorials: https://docs.databricks.com/aws/en/getting-started/
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
