# Databricks Data Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Apply keys and constraints in Databricks Data Engineer: Use the concept to complete this role exercise: Define a table schema and trace a notebook transformation

DataFrames and schemas: A DataFrame is a structured dataset with a schema; inferred types can change when new input arrives. Declare important types and inspect rejected or null conversions.

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: Amount ten should not silently become a valid numeric amount. The practical workshop develops this into: Run the local fixture, then use an authorized Databricks workspace tutorial to load equivalent synthetic data with an explicit schema. Inspect rows and types before transformation.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: A labeled table keeps every column's meaning consistent across batches.

A DataFrame is a structured dataset with a schema; inferred types can change when new input arrives. Declare important types and inspect rejected or null conversions.

Worked example: Amount ten should not silently become a valid numeric amount.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Databricks, Apache Spark, Delta Lake and Unity Catalog (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Databricks Data Engineer: Amount ten should not silently become a valid numeric amount.

Predict the worked case

Read this case without running a tool: Amount ten should not silently become a valid numeric amount. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: Amount ten should not silently become a valid numeric amount. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Amount ten should not silently become a valid numeric amount. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: Amount ten should not silently become a valid numeric amount. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Databricks Data Engineer role interview. Explain keys and constraints using this case: Amount ten should not silently become a valid numeric amount. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: Amount ten should not silently become a valid numeric amount. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: Amount ten should not silently become a valid numeric amount. State the evidence, one alternative and where the mental model stops.

Quiz: After the DataFrames and schemas rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

Databricks getting-started tutorials: https://docs.databricks.com/aws/en/getting-started/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### DataFrames and schemas

A DataFrame is a structured dataset with a schema; inferred types can change when new input arrives. Declare important types and inspect rejected or null conversions. In this role, work through: Amount ten should not silently become a valid numeric amount. The practical workshop develops this into: Run the local fixture, then use an authorized Databricks workspace tutorial to load equivalent synthetic data with an explicit schema. Inspect rows and types before transformation.

Mental model: A labeled table keeps every column's meaning consistent across batches.

Boundary: Schema inference on a tiny sample can misclassify later values; enforce the intended contract.

Worked example: Amount ten should not silently become a valid numeric amount.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Databricks, Apache Spark, Delta Lake and Unity Catalog (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Databricks Data Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run the local fixture, then use an authorized Databricks workspace tutorial to load equivalent synthetic data with an explicit schema. Inspect rows and types before transformation.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Amount ten should not silently become a valid numeric amount. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run the local fixture, then use an authorized Databricks workspace tutorial to load equivalent synthetic data with an explicit schema. Inspect rows and types before transformation.

Expected: Two valid unique orders and a documented invalid-value policy.

Role workshop · debug and verify

Schema inference on a tiny sample can misclassify later values; enforce the intended contract. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save notebook and schema/rejection report. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Two valid unique orders and a documented invalid-value policy.

Expected: Two valid unique orders and a documented invalid-value policy.

Troubleshoot: The role exercise differs from the prediction: Schema inference on a tiny sample can misclassify later values; enforce the intended contract.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: notebook and schema/rejection report; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with dataframes and schemas. Use the glossary below, then write your prediction for: Amount ten should not silently become a valid numeric amount. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Databricks Data Engineer role interview. Explain dataframes and schemas using this case: Amount ten should not silently become a valid numeric amount. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate dataframes and schemas to a system or workflow you know. Explain dataframes and schemas using this case: Amount ten should not silently become a valid numeric amount. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Schema inference on a tiny sample can misclassify later values; enforce the intended contract.

Interview: Explain dataframes and schemas using this case: Amount ten should not silently become a valid numeric amount. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Amount ten should not silently become a valid numeric amount.

Two valid unique orders and a documented invalid-value policy.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Two valid unique orders and a documented invalid-value policy. — A DataFrame is a structured dataset with a schema; inferred types can change when new input arrives. Declare important types and inspect rejected or null conversions. Two valid unique orders and a documented invalid-value policy.

Sources:

Databricks getting-started tutorials: https://docs.databricks.com/aws/en/getting-started/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Apply idempotent processing in Databricks Data Engineer: Use the concept to complete this role exercise: Design a repeatable pipeline with quality assertions and lineage

Delta updates and replay: A merge needs a stable key and unambiguous source records. Multiple source updates for one target require a deterministic ordering/correction rule.

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: Order a at version 2 replaces version 1; replay does not create another order. The practical workshop develops this into: Create versioned order fixtures, deduplicate source changes by the stated rule and implement a Delta MERGE in a lab workspace. Test replay and stale input; compare counts and totals.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: A revised ledger entry needs both its account number and revision order.

A merge needs a stable key and unambiguous source records. Multiple source updates for one target require a deterministic ordering/correction rule.

Worked example: Order a at version 2 replaces version 1; replay does not create another order.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Databricks, Apache Spark, Delta Lake and Unity Catalog (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Databricks Data Engineer: Order a at version 2 replaces version 1; replay does not create another order.

Predict the worked case

Read this case without running a tool: Order a at version 2 replaces version 1; replay does not create another order. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: Order a at version 2 replaces version 1; replay does not create another order. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Order a at version 2 replaces version 1; replay does not create another order. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: Order a at version 2 replaces version 1; replay does not create another order. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Databricks Data Engineer role interview. Explain idempotent processing using this case: Order a at version 2 replaces version 1; replay does not create another order. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: Order a at version 2 replaces version 1; replay does not create another order. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: Order a at version 2 replaces version 1; replay does not create another order. State the evidence, one alternative and where the mental model stops.

Quiz: After the Delta updates and replay rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

Databricks getting-started tutorials: https://docs.databricks.com/aws/en/getting-started/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Delta updates and replay

A merge needs a stable key and unambiguous source records. Multiple source updates for one target require a deterministic ordering/correction rule. In this role, work through: Order a at version 2 replaces version 1; replay does not create another order. The practical workshop develops this into: Create versioned order fixtures, deduplicate source changes by the stated rule and implement a Delta MERGE in a lab workspace. Test replay and stale input; compare counts and totals.

Mental model: A revised ledger entry needs both its account number and revision order.

Boundary: A duplicate source key can make a merge ambiguous; resolve it before the merge.

Worked example: Order a at version 2 replaces version 1; replay does not create another order.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Databricks, Apache Spark, Delta Lake and Unity Catalog (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Databricks Data Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create versioned order fixtures, deduplicate source changes by the stated rule and implement a Delta MERGE in a lab workspace. Test replay and stale input; compare counts and totals.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Order a at version 2 replaces version 1; replay does not create another order. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create versioned order fixtures, deduplicate source changes by the stated rule and implement a Delta MERGE in a lab workspace. Test replay and stale input; compare counts and totals.

Expected: Newer correction wins once and stale data does not overwrite it.

Role workshop · debug and verify

A duplicate source key can make a merge ambiguous; resolve it before the merge. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Delta merge notebook and replay tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Newer correction wins once and stale data does not overwrite it.

Expected: Newer correction wins once and stale data does not overwrite it.

Troubleshoot: The role exercise differs from the prediction: A duplicate source key can make a merge ambiguous; resolve it before the merge.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: Delta merge notebook and replay tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with delta updates and replay. Use the glossary below, then write your prediction for: Order a at version 2 replaces version 1; replay does not create another order. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Databricks Data Engineer role interview. Explain delta updates and replay using this case: Order a at version 2 replaces version 1; replay does not create another order. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate delta updates and replay to a system or workflow you know. Explain delta updates and replay using this case: Order a at version 2 replaces version 1; replay does not create another order. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A duplicate source key can make a merge ambiguous; resolve it before the merge.

Interview: Explain delta updates and replay using this case: Order a at version 2 replaces version 1; replay does not create another order. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Order a at version 2 replaces version 1; replay does not create another order.

Ignore the failing case and keep only the successful screenshot.

Newer correction wins once and stale data does not overwrite it.

Treat any successful command as proof that all business and access rules passed.

Reference: Newer correction wins once and stale data does not overwrite it. — A merge needs a stable key and unambiguous source records. Multiple source updates for one target require a deterministic ordering/correction rule. Newer correction wins once and stale data does not overwrite it.

Sources:

Databricks getting-started tutorials: https://docs.databricks.com/aws/en/getting-started/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Apply transaction and recovery in Databricks Data Engineer: Use the concept to complete this role exercise: Plan schema evolution, access review, job recovery and compute budgets

Jobs, governance and recovery: A scheduled job needs identity, dependency handling, monitoring and data-quality gates. Catalog permissions and runtime configuration affect reproducibility and access.

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: A notebook that completes but loses one source order must fail the publishing gate. The practical workshop develops this into: Define a job DAG, inject a missing-row fixture and block downstream publication. Write catalog access, compute-cost and rollback assumptions; retain run IDs and quality results.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: A production schedule assigns both the worker and the permitted materials.

A scheduled job needs identity, dependency handling, monitoring and data-quality gates. Catalog permissions and runtime configuration affect reproducibility and access.

Worked example: A notebook that completes but loses one source order must fail the publishing gate.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Databricks, Apache Spark, Delta Lake and Unity Catalog (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Databricks Data Engineer: A notebook that completes but loses one source order must fail the publishing gate.

Predict the worked case

Read this case without running a tool: A notebook that completes but loses one source order must fail the publishing gate. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: A notebook that completes but loses one source order must fail the publishing gate. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A notebook that completes but loses one source order must fail the publishing gate. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: A notebook that completes but loses one source order must fail the publishing gate. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Databricks Data Engineer role interview. Explain transaction and recovery using this case: A notebook that completes but loses one source order must fail the publishing gate. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: A notebook that completes but loses one source order must fail the publishing gate. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: A notebook that completes but loses one source order must fail the publishing gate. State the evidence, one alternative and where the mental model stops.

Quiz: After the Jobs, governance and recovery rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

Databricks getting-started tutorials: https://docs.databricks.com/aws/en/getting-started/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Jobs, governance and recovery

A scheduled job needs identity, dependency handling, monitoring and data-quality gates. Catalog permissions and runtime configuration affect reproducibility and access. In this role, work through: A notebook that completes but loses one source order must fail the publishing gate. The practical workshop develops this into: Define a job DAG, inject a missing-row fixture and block downstream publication. Write catalog access, compute-cost and rollback assumptions; retain run IDs and quality results.

Mental model: A production schedule assigns both the worker and the permitted materials.

Boundary: Notebook success alone does not certify business data completeness.

Worked example: A notebook that completes but loses one source order must fail the publishing gate.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Databricks, Apache Spark, Delta Lake and Unity Catalog (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Databricks Data Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Define a job DAG, inject a missing-row fixture and block downstream publication. Write catalog access, compute-cost and rollback assumptions; retain run IDs and quality results.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A notebook that completes but loses one source order must fail the publishing gate. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Define a job DAG, inject a missing-row fixture and block downstream publication. Write catalog access, compute-cost and rollback assumptions; retain run IDs and quality results.

Expected: A visible failed quality gate and a recoverable rerun plan.

Role workshop · debug and verify

Notebook success alone does not certify business data completeness. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Databricks job design and operational runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A visible failed quality gate and a recoverable rerun plan.

Expected: A visible failed quality gate and a recoverable rerun plan.

Troubleshoot: The role exercise differs from the prediction: Notebook success alone does not certify business data completeness.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: Databricks job design and operational runbook; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with jobs, governance and recovery. Use the glossary below, then write your prediction for: A notebook that completes but loses one source order must fail the publishing gate. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Databricks Data Engineer role interview. Explain jobs, governance and recovery using this case: A notebook that completes but loses one source order must fail the publishing gate. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate jobs, governance and recovery to a system or workflow you know. Explain jobs, governance and recovery using this case: A notebook that completes but loses one source order must fail the publishing gate. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Notebook success alone does not certify business data completeness.

Interview: Explain jobs, governance and recovery using this case: A notebook that completes but loses one source order must fail the publishing gate. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A notebook that completes but loses one source order must fail the publishing gate.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A visible failed quality gate and a recoverable rerun plan.

Reference: A visible failed quality gate and a recoverable rerun plan. — A scheduled job needs identity, dependency handling, monitoring and data-quality gates. Catalog permissions and runtime configuration affect reproducibility and access. A visible failed quality gate and a recoverable rerun plan.

Sources:

Databricks getting-started tutorials: https://docs.databricks.com/aws/en/getting-started/

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
