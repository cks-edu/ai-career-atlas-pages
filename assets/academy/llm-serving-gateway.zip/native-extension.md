# Inspect a running learning endpoint

Requires your separately started, loopback-bound compatible vLLM server and approved model. Follow its versioned installation and model-license documentation; do not open the endpoint publicly. Triton uses different health/model APIs. These commands do not start a GPU or deploy a model.

```sh
curl --fail --max-time 10 http://127.0.0.1:8000/health
curl --fail --max-time 10 http://127.0.0.1:8000/v1/models
curl --fail --max-time 10 http://127.0.0.1:8000/metrics
```

Expected evidence: Capture actual status, model identity and available metric names. A transport pass is not an evaluation of model answers.

Cleanup: these inspection commands create no resources. Stop only separately started learning servers and remove only your own temporary resources after retaining evidence. No cloud resources are provisioned by this pack.
