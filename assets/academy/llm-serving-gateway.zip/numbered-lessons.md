# High-Throughput LLM Serving & AI Gateways — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## intermediate

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

Prefill: Processing input context before generation.

Continuous batching: Updating admitted sequence membership during iterative serving.

Model revision: An immutable identity for the weights/configuration being served.

Serving backend: The engine executing a particular model runtime.

Semantic cache: Reuse selected by similarity plus a reviewed scoping and validity policy.

Token reservation: An admission allowance; distributed enforcement requires atomic state.

KEDA: A Kubernetes event-driven autoscaler that can use external metrics.

KV fraction: Used cache blocks divided by the declared cache pool, not SM compute utilization.

### Memory-bound inference & continuous batching

Prefill processes prompt tokens; decode generates successive tokens while reading weights and cache. Their bottlenecks differ. Continuous batching can admit and finish sequences across iterations rather than waiting for one fixed batch.

Bound a proposed batch by active-sequence count and aggregate declared KV memory. Empty and over-capacity batches are rejected. The memory estimates are provided inputs, not inferred from token counts.

More batching can raise throughput while delaying individual responses. Benchmark prefill and decode separately on the target model, quantization and hardware.

Mental model: Waiting sequences → admission → iteration batch → completed sequences. Picture the boundary as a checked gate between stages.

Boundary: More batching can raise throughput while delaying individual responses. Benchmark prefill and decode separately on the target model, quantization and hardware.

Worked example: function admitBatch(s, maxSequences, kvGiB) {
  return Array.isArray(s) && s.length>0 && Number.isSafeInteger(maxSequences) && maxSequences>0 && Number.isFinite(kvGiB) && kvGiB>0 && s.length<=maxSequences && s.every(x=>Number.isFinite(x)&&x>=0) && s.reduce((a,b)=>a+b,0)<=kvGiB;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract llm-serving-gateway.zip, install Node.js LTS, then open production-ai/12-01-continuous-batching.

Tools for this exercise: JavaScript · local isolated workbench; vLLM / Triton, KEDA / AI gateway as documented optional extensions

Course tool and framework map: vLLM / Triton (Open source · GPU hardware required); KEDA / AI gateway (Open-source autoscaler · gateway edition varies)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires your separately started, loopback-bound compatible vLLM server and approved model. Follow its versioned installation and model-license documentation; do not open the endpoint publicly. Triton uses different health/model APIs. These commands do not start a GPU or deploy a model.

Implement admitBatch and compare a two-request exact-memory fit with a batch that exceeds either independent constraint.

Terminal folder: production-ai/12-01-continuous-batching

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Bound a proposed batch by active-sequence count and aggregate declared KV memory. Empty and over-capacity batches are rejected. The memory estimates are provided inputs, not inferred from token counts.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement admitBatch and compare a two-request exact-memory fit with a batch that exceeds either independent constraint.

Expected: Accept a bounded batch

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Enforce both limits; Reject invalid estimates

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect a running learning endpoint

Requires your separately started, loopback-bound compatible vLLM server and approved model. Follow its versioned installation and model-license documentation; do not open the endpoint publicly. Triton uses different health/model APIs. These commands do not start a GPU or deploy a model.

```
curl --fail --max-time 10 http://127.0.0.1:8000/health
curl --fail --max-time 10 http://127.0.0.1:8000/v1/models
curl --fail --max-time 10 http://127.0.0.1:8000/metrics
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Capture actual status, model identity and available metric names. A transport pass is not an evaluation of model answers.

Expected: Accept a bounded batch; Enforce both limits; Reject invalid estimates. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Admit only within both sequence and memory budgets. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/12-01-continuous-batching/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Waiting sequences → admission → iteration batch → completed sequences. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Which observation distinguishes better throughput from a slower user experience? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Throughput is not the same as per-user latency. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Which observation distinguishes better throughput from a slower user experience?

Interview: Which observation distinguishes better throughput from a slower user experience? Explain the decision, a failing case and a production limitation.

Quiz: Which observation distinguishes better throughput from a slower user experience?

Measure only GPU utilization.

Compare tokens/second with queueing and per-request latency.

Count model files.

Reference: Compare tokens/second with queueing and per-request latency. — Compare tokens/second with queueing and per-request latency. More batching can raise throughput while delaying individual responses. Benchmark prefill and decode separately on the target model, quantization and hardware.

Sources:

vLLM: production metrics and units: https://docs.vllm.ai/en/latest/usage/metrics/

NVIDIA Triton: dynamic batching: https://docs.nvidia.com/deeplearning/triton-inference-server/user-guide/docs/user_guide/batcher.html

### Operating vLLM & Triton with explicit serving contracts

vLLM focuses on LLM inference; Triton supports multiple backends and scheduling options. A running process is not sufficient evidence that the expected model version is ready. Inspect the model, protocol and backend before comparing engines.

The fixture accepts only a ready endpoint whose loaded model revision equals the requested immutable revision and whose declared context ceiling fits input plus output reserve. Pin the real container and model revision separately.

This does not contact either server or measure model quality. Run documented health, request and load checks in an authorized GPU environment before release.

Mental model: Gateway contract → model endpoint → versioned backend → response. Picture the boundary as a checked gate between stages.

Boundary: This does not contact either server or measure model quality. Run documented health, request and load checks in an authorized GPU environment before release.

Worked example: function servingReady(p) {
  return !!p && p.ready===true && typeof p.expectedRevision==='string' && p.expectedRevision.length>0 && p.loadedRevision===p.expectedRevision && [p.inputTokens,p.outputReserve,p.maxContext].every(n=>Number.isSafeInteger(n)&&n>=0) && p.maxContext>0 && p.inputTokens+p.outputReserve<=p.maxContext;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract llm-serving-gateway.zip, install Node.js LTS, then open production-ai/12-02-serving-readiness.

Tools for this exercise: JavaScript · local isolated workbench; vLLM / Triton, KEDA / AI gateway as documented optional extensions

Course tool and framework map: vLLM / Triton (Open source · GPU hardware required); KEDA / AI gateway (Open-source autoscaler · gateway edition varies)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires your separately started, loopback-bound compatible vLLM server and approved model. Follow its versioned installation and model-license documentation; do not open the endpoint publicly. Triton uses different health/model APIs. These commands do not start a GPU or deploy a model.

Implement servingReady. Prepare a request/response contract and write the native smoke-test evidence you would require for both model identity and readiness.

Terminal folder: production-ai/12-02-serving-readiness

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture accepts only a ready endpoint whose loaded model revision equals the requested immutable revision and whose declared context ceiling fits input plus output reserve. Pin the real container and model revision separately.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement servingReady. Prepare a request/response contract and write the native smoke-test evidence you would require for both model identity and readiness.

Expected: Validate ready model

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Reject drift and overflow; Reject unavailable endpoint

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect a running learning endpoint

Requires your separately started, loopback-bound compatible vLLM server and approved model. Follow its versioned installation and model-license documentation; do not open the endpoint publicly. Triton uses different health/model APIs. These commands do not start a GPU or deploy a model.

```
curl --fail --max-time 10 http://127.0.0.1:8000/health
curl --fail --max-time 10 http://127.0.0.1:8000/v1/models
curl --fail --max-time 10 http://127.0.0.1:8000/metrics
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Capture actual status, model identity and available metric names. A transport pass is not an evaluation of model answers.

Expected: Validate ready model; Reject drift and overflow; Reject unavailable endpoint. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Check model identity and request limits at the serving boundary. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/12-02-serving-readiness/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Gateway contract → model endpoint → versioned backend → response. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A rollout reports Ready but serves an old model revision. Which gate is missing? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Container readiness cannot silently substitute a different model. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A rollout reports Ready but serves an old model revision. Which gate is missing?

Interview: A rollout reports Ready but serves an old model revision. Which gate is missing? Explain the decision, a failing case and a production limitation.

Quiz: A rollout reports Ready but serves an old model revision. Which gate is missing?

A model-identity check alongside readiness.

A larger image tag font.

A guarantee that Triton and vLLM have identical APIs.

Reference: A model-identity check alongside readiness. — A model-identity check alongside readiness. This does not contact either server or measure model quality. Run documented health, request and load checks in an authorized GPU environment before release.

Sources:

vLLM: production metrics and units: https://docs.vllm.ai/en/latest/usage/metrics/

NVIDIA Triton: dynamic batching: https://docs.nvidia.com/deeplearning/triton-inference-server/user-guide/docs/user_guide/batcher.html

### AI gateways: tenant budgets, cache & bounded failover

A gateway enforces the authenticated tenant budget before serving a result. Semantic similarity is not permission to reuse a response. Cache reuse needs tenant, model, policy, expiry and an approved eligibility rule; provider failover must preserve data-routing policy.

The pure router uses trusted fixture inputs. It checks reserved token allowance, then an eligible scoped cache entry, then at most one permitted healthy backup after a primary 503. It refuses failover after a stream has started. In production, budget reservation must be atomic across requests.

The browser does not authenticate tenants, compute embeddings, reserve a distributed rate limit or call providers. Eligibility is a reviewed cache-policy input; similarity alone is deliberately insufficient.

Mental model: Authenticated request → budget admission → scoped cache → permitted provider. Picture the boundary as a checked gate between stages.

Boundary: The browser does not authenticate tenants, compute embeddings, reserve a distributed rate limit or call providers. Eligibility is a reviewed cache-policy input; similarity alone is deliberately insufficient.

Worked example: function routeAiRequest(r, providers, budget) {
  if(!r || typeof r.tenant!=='string' || !r.tenant || typeof r.model!=='string' || !r.model || typeof r.policy!=='string' || !r.policy || !Number.isSafeInteger(r.tokens) || r.tokens<0 || !Number.isSafeInteger(budget) || budget<r.tokens || !Number.isFinite(r.now)) return 'deny';
  const c=r.cache;
  if(c && c.eligible===true && c.tenant===r.tenant && c.model===r.model && c.policy===r.policy && Number.isFinite(c.expiresAt) && c.expiresAt>r.now) return 'cache';
  if(!Array.isArray(providers)) return 'deny';
  const p=providers[0]; if(!p || p.allowed!==true) return 'deny';
  if(p.status===200 && typeof p.id==='string' && p.id.length>0) return p.id;
  const b=providers[1];
  return p.status===503 && r.streamStarted!==true && b?.allowed===true && b.status===200 && typeof b.id==='string' && b.id.length>0 ? b.id : 'unavailable';
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract llm-serving-gateway.zip, install Node.js LTS, then open production-ai/12-03-tenant-gateway.

Tools for this exercise: JavaScript · local isolated workbench; vLLM / Triton, KEDA / AI gateway as documented optional extensions

Course tool and framework map: vLLM / Triton (Open source · GPU hardware required); KEDA / AI gateway (Open-source autoscaler · gateway edition varies)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires your separately started, loopback-bound compatible vLLM server and approved model. Follow its versioned installation and model-license documentation; do not open the endpoint publicly. Triton uses different health/model APIs. These commands do not start a GPU or deploy a model.

Implement routeAiRequest. Add cache cases for wrong policy, expired entries and cross-tenant matches; add an unapproved backup and a 503 after streaming.

Terminal folder: production-ai/12-03-tenant-gateway

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The pure router uses trusted fixture inputs. It checks reserved token allowance, then an eligible scoped cache entry, then at most one permitted healthy backup after a primary 503. It refuses failover after a stream has started. In production, budget reservation must be atomic across requests.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement routeAiRequest. Add cache cases for wrong policy, expired entries and cross-tenant matches; add an unapproved backup and a 503 after streaming.

Expected: Use a bounded backup

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Budget and privacy precede reuse; Never replay a partial stream

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect a running learning endpoint

Requires your separately started, loopback-bound compatible vLLM server and approved model. Follow its versioned installation and model-license documentation; do not open the endpoint publicly. Triton uses different health/model APIs. These commands do not start a GPU or deploy a model.

```
curl --fail --max-time 10 http://127.0.0.1:8000/health
curl --fail --max-time 10 http://127.0.0.1:8000/v1/models
curl --fail --max-time 10 http://127.0.0.1:8000/metrics
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Capture actual status, model identity and available metric names. A transport pass is not an evaluation of model answers.

Expected: Use a bounded backup; Budget and privacy precede reuse; Never replay a partial stream. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Enforce budget, cache scope and bounded pre-stream failover. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/12-03-tenant-gateway/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Authenticated request → budget admission → scoped cache → permitted provider. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. The primary fails after emitting half an answer. Should the gateway silently start a second provider? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A backup endpoint must not widen the permitted data destinations. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: The primary fails after emitting half an answer. Should the gateway silently start a second provider?

Interview: The primary fails after emitting half an answer. Should the gateway silently start a second provider? Explain the decision, a failing case and a production limitation.

Quiz: The primary fails after emitting half an answer. Should the gateway silently start a second provider?

Yes, duplicate partial text is always safe.

Yes, ignore tenant destination policy.

No; surface interruption and use an explicit restart policy.

Reference: No; surface interruption and use an explicit restart policy. — No; surface interruption and use an explicit restart policy. The browser does not authenticate tenants, compute embeddings, reserve a distributed rate limit or call providers. Eligibility is a reviewed cache-policy input; similarity alone is deliberately insufficient.

Sources:

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

vLLM: production metrics and units: https://docs.vllm.ai/en/latest/usage/metrics/

### Scaling from KV-cache pressure & queue depth with KEDA

GPU utilization alone may miss a memory-bound or queued serving workload. Combine validated queue depth and KV-cache pressure with measured warmup and capacity limits. KEDA can consume a Prometheus query; it does not create GPU capacity by itself.

This policy recommends one replica increase when queue depth exceeds 10 or KV fraction exceeds 0.8. It caps desired replicas at max and holds when telemetry is stale. Both thresholds are fictional lab choices.

A real autoscaler needs aggregation semantics, cooldown, minimum replicas, metric authentication, node capacity and model-load time. Scaling a hot replica does not move existing sequence state automatically.

Mental model: Serving metrics → fresh aggregate → scaling recommendation → capacity controller. Picture the boundary as a checked gate between stages.

Boundary: A real autoscaler needs aggregation semantics, cooldown, minimum replicas, metric authentication, node capacity and model-load time. Scaling a hot replica does not move existing sequence state automatically.

Worked example: function desiredAiReplicas(p) {
  if(!p || ![p.current,p.max,p.queue,p.ageSeconds].every(Number.isSafeInteger) || p.current<1 || p.max<p.current || p.queue<0 || p.ageSeconds<0 || !Number.isFinite(p.kvFraction) || p.kvFraction<0 || p.kvFraction>1) return null;
  if(p.ageSeconds>60) return p.current;
  return Math.min(p.max,p.current+((p.queue>10 || p.kvFraction>0.8)?1:0));
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract llm-serving-gateway.zip, install Node.js LTS, then open production-ai/12-04-kv-queue-scaling.

Tools for this exercise: JavaScript · local isolated workbench; vLLM / Triton, KEDA / AI gateway as documented optional extensions

Course tool and framework map: vLLM / Triton (Open source · GPU hardware required); KEDA / AI gateway (Open-source autoscaler · gateway edition varies)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires your separately started, loopback-bound compatible vLLM server and approved model. Follow its versioned installation and model-license documentation; do not open the endpoint publicly. Triton uses different health/model APIs. These commands do not start a GPU or deploy a model.

Implement desiredAiReplicas. Write a Prometheus-query design with tenant-safe labels, a single returned value, freshness, cooldown and maximum spend.

Terminal folder: production-ai/12-04-kv-queue-scaling

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This policy recommends one replica increase when queue depth exceeds 10 or KV fraction exceeds 0.8. It caps desired replicas at max and holds when telemetry is stale. Both thresholds are fictional lab choices.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement desiredAiReplicas. Write a Prometheus-query design with tenant-safe labels, a single returned value, freshness, cooldown and maximum spend.

Expected: Scale on fresh pressure

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Hold stale or capped state; Validate units

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect a running learning endpoint

Requires your separately started, loopback-bound compatible vLLM server and approved model. Follow its versioned installation and model-license documentation; do not open the endpoint publicly. Triton uses different health/model APIs. These commands do not start a GPU or deploy a model.

```
curl --fail --max-time 10 http://127.0.0.1:8000/health
curl --fail --max-time 10 http://127.0.0.1:8000/v1/models
curl --fail --max-time 10 http://127.0.0.1:8000/metrics
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Capture actual status, model identity and available metric names. A transport pass is not an evaluation of model answers.

Expected: Scale on fresh pressure; Hold stale or capped state; Validate units. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require freshness and a bounded recommendation with cooldown outside the fixture. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/12-04-kv-queue-scaling/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Serving metrics → fresh aggregate → scaling recommendation → capacity controller. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A metric reports KV-cache usage as 0.8. Which interpretation should you verify? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A stale metric must not trigger unbounded capacity changes. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A metric reports KV-cache usage as 0.8. Which interpretation should you verify?

Interview: A metric reports KV-cache usage as 0.8. Which interpretation should you verify? Explain the decision, a failing case and a production limitation.

Quiz: A metric reports KV-cache usage as 0.8. Which interpretation should you verify?

It is always 0.8 bytes.

Its documented unit is a fraction; 0.8 means 80%.

It means the GPU is 80% busy computing.

Reference: Its documented unit is a fraction; 0.8 means 80%. — Its documented unit is a fraction; 0.8 means 80%. A real autoscaler needs aggregation semantics, cooldown, minimum replicas, metric authentication, node capacity and model-load time. Scaling a hot replica does not move existing sequence state automatically.

Sources:

KEDA: Prometheus scaler: https://keda.sh/docs/2.18/scalers/prometheus/

vLLM: production metrics and units: https://docs.vllm.ai/en/latest/usage/metrics/
