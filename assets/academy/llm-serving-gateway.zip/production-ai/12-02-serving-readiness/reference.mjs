function servingReady(p) {
  return !!p && p.ready===true && typeof p.expectedRevision==='string' && p.expectedRevision.length>0 && p.loadedRevision===p.expectedRevision && [p.inputTokens,p.outputReserve,p.maxContext].every(n=>Number.isSafeInteger(n)&&n>=0) && p.maxContext>0 && p.inputTokens+p.outputReserve<=p.maxContext;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(servingReady({ready:true,expectedRevision:'rev-a',loadedRevision:'rev-a',inputTokens:800,outputReserve:200,maxContext:1000}));
console.log("PASS: Validate ready model");
}
{
const p={ready:true,expectedRevision:'a',loadedRevision:'b',inputTokens:1,outputReserve:1,maxContext:4};assert(!servingReady(p));assert(!servingReady({...p,loadedRevision:'a',inputTokens:4}));
console.log("PASS: Reject drift and overflow");
}
{
assert(!servingReady(null));assert(!servingReady({ready:false}));
console.log("PASS: Reject unavailable endpoint");
}
