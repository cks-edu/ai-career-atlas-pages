# Operating vLLM & Triton with explicit serving contracts

vLLM focuses on LLM inference; Triton supports multiple backends and scheduling options. A running process is not sufficient evidence that the expected model version is ready. Inspect the model, protocol and backend before comparing engines.

The fixture accepts only a ready endpoint whose loaded model revision equals the requested immutable revision and whose declared context ceiling fits input plus output reserve. Pin the real container and model revision separately.

Task: Implement servingReady. Prepare a request/response contract and write the native smoke-test evidence you would require for both model identity and readiness.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Gateway contract → model endpoint → versioned backend → response.
State: Expected revision, loaded revision, readiness and context allowance.
Boundary: Container readiness cannot silently substitute a different model.
Failure: The new container is live while the wrong weights are loaded.
Control: Check model identity and request limits at the serving boundary.
Observability: Record model revision, readiness transitions and request errors.
Blast radius: Requests routed to the incompatible serving endpoint.
Trade-off: Strict identity gates delay rollout while avoiding silent version drift.

Limit: This does not contact either server or measure model quality. Run documented health, request and load checks in an authorized GPU environment before release.

Sources:
https://docs.vllm.ai/en/latest/usage/metrics/
https://docs.nvidia.com/deeplearning/triton-inference-server/user-guide/docs/user_guide/batcher.html
