function routeAiRequest(r, providers, budget) {
  if(!r || typeof r.tenant!=='string' || !r.tenant || typeof r.model!=='string' || !r.model || typeof r.policy!=='string' || !r.policy || !Number.isSafeInteger(r.tokens) || r.tokens<0 || !Number.isSafeInteger(budget) || budget<r.tokens || !Number.isFinite(r.now)) return 'deny';
  const c=r.cache;
  if(c && c.eligible===true && c.tenant===r.tenant && c.model===r.model && c.policy===r.policy && Number.isFinite(c.expiresAt) && c.expiresAt>r.now) return 'cache';
  if(!Array.isArray(providers)) return 'deny';
  const p=providers[0]; if(!p || p.allowed!==true) return 'deny';
  if(p.status===200 && typeof p.id==='string' && p.id.length>0) return p.id;
  const b=providers[1];
  return p.status===503 && r.streamStarted!==true && b?.allowed===true && b.status===200 && typeof b.id==='string' && b.id.length>0 ? b.id : 'unavailable';
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const r={tenant:'a',model:'m1',policy:'p1',tokens:100,now:10};assert(routeAiRequest(r,[{id:'primary',allowed:true,status:503},{id:'backup',allowed:true,status:200}],100)==='backup');
console.log("PASS: Use a bounded backup");
}
{
const r={tenant:'a',model:'m',policy:'p',tokens:2,now:10,cache:{eligible:true,tenant:'a',model:'m',policy:'p',expiresAt:11}};assert(routeAiRequest(r,[],2)==='cache');assert(routeAiRequest(r,[],1)==='deny');assert(routeAiRequest({...r,tenant:'b'},[],2)==='deny');
console.log("PASS: Budget and privacy precede reuse");
}
{
const r={tenant:'a',model:'m',policy:'p',tokens:1,now:10,streamStarted:true};assert(routeAiRequest(r,[{id:'a',allowed:true,status:503},{id:'b',allowed:true,status:200}],5)==='unavailable');assert(routeAiRequest(null,[],5)==='deny');assert(routeAiRequest({...r,streamStarted:false},[{allowed:true,status:200}],5)==='unavailable');assert(routeAiRequest({...r,streamStarted:false},[{id:'a',allowed:true,status:503},{allowed:true,status:200}],5)==='unavailable');
console.log("PASS: Never replay a partial stream");
}
