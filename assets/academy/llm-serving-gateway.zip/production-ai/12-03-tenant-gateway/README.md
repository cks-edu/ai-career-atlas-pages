# AI gateways: tenant budgets, cache & bounded failover

A gateway enforces the authenticated tenant budget before serving a result. Semantic similarity is not permission to reuse a response. Cache reuse needs tenant, model, policy, expiry and an approved eligibility rule; provider failover must preserve data-routing policy.

The pure router uses trusted fixture inputs. It checks reserved token allowance, then an eligible scoped cache entry, then at most one permitted healthy backup after a primary 503. It refuses failover after a stream has started. In production, budget reservation must be atomic across requests.

Task: Implement routeAiRequest. Add cache cases for wrong policy, expired entries and cross-tenant matches; add an unapproved backup and a 503 after streaming.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Authenticated request → budget admission → scoped cache → permitted provider.
State: Tenant, immutable model, policy revision, token reserve and stream state.
Boundary: A backup endpoint must not widen the permitted data destinations.
Failure: A primary 503 leads to an unapproved provider or another tenant’s cached answer.
Control: Enforce budget, cache scope and bounded pre-stream failover.
Observability: Log redacted route reasons, budget reservations and failover counts.
Blast radius: Tenants sharing an incorrectly scoped cache or budget counter.
Trade-off: Caching saves inference cost but risks stale or unauthorized reuse.

Limit: The browser does not authenticate tenants, compute embeddings, reserve a distributed rate limit or call providers. Eligibility is a reviewed cache-policy input; similarity alone is deliberately insufficient.

Sources:
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
https://docs.vllm.ai/en/latest/usage/metrics/
