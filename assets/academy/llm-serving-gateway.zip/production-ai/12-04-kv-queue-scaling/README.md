# Scaling from KV-cache pressure & queue depth with KEDA

GPU utilization alone may miss a memory-bound or queued serving workload. Combine validated queue depth and KV-cache pressure with measured warmup and capacity limits. KEDA can consume a Prometheus query; it does not create GPU capacity by itself.

This policy recommends one replica increase when queue depth exceeds 10 or KV fraction exceeds 0.8. It caps desired replicas at max and holds when telemetry is stale. Both thresholds are fictional lab choices.

Task: Implement desiredAiReplicas. Write a Prometheus-query design with tenant-safe labels, a single returned value, freshness, cooldown and maximum spend.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Serving metrics → fresh aggregate → scaling recommendation → capacity controller.
State: Queue count, KV fraction 0–1, replica cap and observation age.
Boundary: A stale metric must not trigger unbounded capacity changes.
Failure: An old pressure sample repeatedly scales expensive replicas.
Control: Require freshness and a bounded recommendation with cooldown outside the fixture.
Observability: Observe queue age, scaling events, warmup time and rejected requests.
Blast radius: The serving pool and its cloud spending budget.
Trade-off: Faster scale-out lowers queueing but reserves costly idle capacity.

Limit: A real autoscaler needs aggregation semantics, cooldown, minimum replicas, metric authentication, node capacity and model-load time. Scaling a hot replica does not move existing sequence state automatically.

Sources:
https://keda.sh/docs/2.18/scalers/prometheus/
https://docs.vllm.ai/en/latest/usage/metrics/
