function desiredAiReplicas(p) {
  if(!p || ![p.current,p.max,p.queue,p.ageSeconds].every(Number.isSafeInteger) || p.current<1 || p.max<p.current || p.queue<0 || p.ageSeconds<0 || !Number.isFinite(p.kvFraction) || p.kvFraction<0 || p.kvFraction>1) return null;
  if(p.ageSeconds>60) return p.current;
  return Math.min(p.max,p.current+((p.queue>10 || p.kvFraction>0.8)?1:0));
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(desiredAiReplicas({current:2,max:4,queue:11,kvFraction:0.2,ageSeconds:5})===3);
console.log("PASS: Scale on fresh pressure");
}
{
const p={current:4,max:4,queue:99,kvFraction:0.9,ageSeconds:5};assert(desiredAiReplicas(p)===4);assert(desiredAiReplicas({...p,current:2,ageSeconds:61})===2);
console.log("PASS: Hold stale or capped state");
}
{
assert(desiredAiReplicas({current:1,max:3,queue:0,kvFraction:80,ageSeconds:1})===null);assert(desiredAiReplicas(null)===null);
console.log("PASS: Validate units");
}
