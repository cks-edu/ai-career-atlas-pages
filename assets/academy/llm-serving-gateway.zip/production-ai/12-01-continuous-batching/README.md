# Memory-bound inference & continuous batching

Prefill processes prompt tokens; decode generates successive tokens while reading weights and cache. Their bottlenecks differ. Continuous batching can admit and finish sequences across iterations rather than waiting for one fixed batch.

Bound a proposed batch by active-sequence count and aggregate declared KV memory. Empty and over-capacity batches are rejected. The memory estimates are provided inputs, not inferred from token counts.

Task: Implement admitBatch and compare a two-request exact-memory fit with a batch that exceeds either independent constraint.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Waiting sequences → admission → iteration batch → completed sequences.
State: Active count, estimated KV GiB and configured sequence limit.
Boundary: Throughput is not the same as per-user latency.
Failure: An oversized batch exceeds the declared KV memory pool.
Control: Admit only within both sequence and memory budgets.
Observability: Compare throughput, TTFT, ITL and queue age under load.
Blast radius: All admitted sequences competing for the same cache.
Trade-off: Larger batches improve utilization but may worsen tail latency.

Limit: More batching can raise throughput while delaying individual responses. Benchmark prefill and decode separately on the target model, quantization and hardware.

Sources:
https://docs.vllm.ai/en/latest/usage/metrics/
https://docs.nvidia.com/deeplearning/triton-inference-server/user-guide/docs/user_guide/batcher.html
