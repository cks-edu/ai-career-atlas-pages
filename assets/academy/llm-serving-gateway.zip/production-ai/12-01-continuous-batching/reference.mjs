function admitBatch(s, maxSequences, kvGiB) {
  return Array.isArray(s) && s.length>0 && Number.isSafeInteger(maxSequences) && maxSequences>0 && Number.isFinite(kvGiB) && kvGiB>0 && s.length<=maxSequences && s.every(x=>Number.isFinite(x)&&x>=0) && s.reduce((a,b)=>a+b,0)<=kvGiB;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(admitBatch([2,3],4,8));
console.log("PASS: Accept a bounded batch");
}
{
assert(!admitBatch([2,3],1,8));assert(!admitBatch([5,4],4,8));assert(admitBatch([4,4],2,8));
console.log("PASS: Enforce both limits");
}
{
assert(!admitBatch([NaN],2,8));assert(!admitBatch([],2,8));assert(!admitBatch(null,2,8));
console.log("PASS: Reject invalid estimates");
}
