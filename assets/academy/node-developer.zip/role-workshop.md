# Node.js Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Event loop and I/O

Node schedules asynchronous I/O callbacks while JavaScript executes on the event loop. A long synchronous loop delays other requests even when the handler is declared async.
Mental model: One receptionist can start many deliveries but cannot answer calls while doing a long calculation.
Case: A CPU-heavy loop delays a second request; awaiting I/O allows unrelated work to proceed.
Task: In a copy of app.mjs add a bounded 100 ms synchronous delay to a lab-only path. Send that request alongside GET /api/tasks. Measure both durations, remove the delay and repeat.
Acceptance: The second request is delayed during the synchronous work; record measurements rather than promising a fixed duration.
Troubleshooting: If both runs look equal, ensure requests overlap and are not sent sequentially by the client.
Deliverable: event-loop-experiment.md with timing table and environment

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Timeout and cancellation

A timeout bounds waiting; cancellation asks the underlying operation to stop. AbortSignal must be passed to the downstream fetch, and the caller still needs a clear error response.
Mental model: An alarm tells the receptionist to stop waiting and cancel the delivery request.
Case: A local stub taking 500 ms should exceed a 50 ms downstream deadline.
Task: Create a separate local stub, call it with fetch and AbortSignal.timeout(50), catch the timeout and map it to a gateway timeout in your handler. Test a fast stub too, then close both servers.
Acceptance: Fast call succeeds; slow call returns a controlled error; a following health request succeeds.
Troubleshooting: A timeout without cancellation can leave work running. Check that the actual fetch receives the signal, not an unrelated wrapper promise.
Deliverable: timeout-handler.mjs, tests and error mapping table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Backpressure and request budgets

Bound body sizes and concurrent work before allocating unbounded memory. A limit must count bytes rather than assume characters and must release resources on disconnect or rejection.
Mental model: A loading dock has both a weight limit and a maximum number of trucks.
Case: A body of 4097 ASCII bytes exceeds a 4096-byte limit; multibyte text needs a byte count.
Task: Review the reference body loop. Replace string-length counting with Buffer byte counts, reject oversized payloads with 413 and add boundary tests at 4096 and 4097 bytes. Test an interrupted request.
Acceptance: Oversized input creates no task; other requests remain usable; memory conclusions are limited to the measured load.
Troubleshooting: If multibyte input bypasses limits, compare encoded byte length with JavaScript string length.
Deliverable: body-budget tests and a bounded-load report

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
