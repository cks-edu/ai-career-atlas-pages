# Node.js Developer

Software Engineering

Start with event loop and i/o. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward body-budget tests and a bounded-load report.

## beginner

In a copy of app.mjs add a bounded 100 ms synchronous delay to a lab-only path. Send that request alongside GET /api/tasks. Measure both durations, remove the delay and repeat.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Request and response
A client asks a server for a resource. A method, path and body describe the request; a status and body describe the response.
Mental model: A service counter: the request is your order and the response is the result.
Limit: Networks can time out; sending an order does not prove it was fulfilled.
Example: POST /api/tasks sends a title; 201 indicates a new task. GET returns the current list.
Recall: Draw the request and response for adding one task.

### Event loop and I/O
Node schedules asynchronous I/O callbacks while JavaScript executes on the event loop. A long synchronous loop delays other requests even when the handler is declared async.
Mental model: One receptionist can start many deliveries but cannot answer calls while doing a long calculation.
Limit: If both runs look equal, ensure requests overlap and are not sent sequentially by the client.
Example: A CPU-heavy loop delays a second request; awaiting I/O allows unrelated work to proceed.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If both runs look equal, ensure requests overlap and are not sent sequentially by the client.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A CPU-heavy loop delays a second request; awaiting I/O allows unrelated work to proceed. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
In a copy of app.mjs add a bounded 100 ms synchronous delay to a lab-only path. Send that request alongside GET /api/tasks. Measure both durations, remove the delay and repeat.
```
node app.mjs
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: The second request is delayed during the synchronous work; record measurements rather than promising a fixed duration.

6. Role workshop · debug and verify
If both runs look equal, ensure requests overlap and are not sent sequentially by the client. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save event-loop-experiment.md with timing table and environment. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The second request is delayed during the synchronous work; record measurements rather than promising a fixed duration.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Event loop and I/O: If both runs look equal, ensure requests overlap and are not sent sequentially by the client.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: event-loop-experiment.md with timing table and environment
The second request is delayed during the synchronous work; record measurements rather than promising a fixed duration.

Interview: Work through this Node.js Developer case: A CPU-heavy loop delays a second request; awaiting I/O allows unrelated work to proceed. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Node schedules asynchronous I/O callbacks while JavaScript executes on the event loop. A long synchronous loop delays other requests even when the handler is declared async. Expected evidence: The second request is delayed during the synchronous work; record measurements rather than promising a fixed duration. Diagnosis: If both runs look equal, ensure requests overlap and are not sent sequentially by the client. State the limits of the mental model: One receptionist can start many deliveries but cannot answer calls while doing a long calculation.

Resume: Built event-loop-experiment.md with timing table and environment using Node.js; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create a separate local stub, call it with fetch and AbortSignal.timeout(50), catch the timeout and map it to a gateway timeout in your handler. Test a fast stub too, then close both servers.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Validation at a boundary
Check input before storing or using it. Client checks help people; the server must also enforce the rule.
Mental model: A gate with a checklist before a parcel enters a warehouse.
Limit: Valid input can still be unauthorized; validation is not access control.
Example: A blank title receives 400 and does not change task count.
Recall: Why must the server reject invalid input even if the form already checks it?

### Timeout and cancellation
A timeout bounds waiting; cancellation asks the underlying operation to stop. AbortSignal must be passed to the downstream fetch, and the caller still needs a clear error response.
Mental model: An alarm tells the receptionist to stop waiting and cancel the delivery request.
Limit: A timeout without cancellation can leave work running. Check that the actual fetch receives the signal, not an unrelated wrapper promise.
Example: A local stub taking 500 ms should exceed a 50 ms downstream deadline.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A timeout without cancellation can leave work running. Check that the actual fetch receives the signal, not an unrelated wrapper promise.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A local stub taking 500 ms should exceed a 50 ms downstream deadline. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a separate local stub, call it with fetch and AbortSignal.timeout(50), catch the timeout and map it to a gateway timeout in your handler. Test a fast stub too, then close both servers.
```
node --test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Fast call succeeds; slow call returns a controlled error; a following health request succeeds.

6. Role workshop · debug and verify
A timeout without cancellation can leave work running. Check that the actual fetch receives the signal, not an unrelated wrapper promise. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save timeout-handler.mjs, tests and error mapping table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Fast call succeeds; slow call returns a controlled error; a following health request succeeds.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Timeout and cancellation: A timeout without cancellation can leave work running. Check that the actual fetch receives the signal, not an unrelated wrapper promise.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: timeout-handler.mjs, tests and error mapping table
Fast call succeeds; slow call returns a controlled error; a following health request succeeds.

Interview: Work through this Node.js Developer case: A local stub taking 500 ms should exceed a 50 ms downstream deadline. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A timeout bounds waiting; cancellation asks the underlying operation to stop. AbortSignal must be passed to the downstream fetch, and the caller still needs a clear error response. Expected evidence: Fast call succeeds; slow call returns a controlled error; a following health request succeeds. Diagnosis: A timeout without cancellation can leave work running. Check that the actual fetch receives the signal, not an unrelated wrapper promise. State the limits of the mental model: An alarm tells the receptionist to stop waiting and cancel the delivery request.

Resume: Built timeout-handler.mjs, tests and error mapping table using Node.js; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Review the reference body loop. Replace string-length counting with Buffer byte counts, reject oversized payloads with 413 and add boundary tests at 4096 and 4097 bytes. Test an interrupted request.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State and recovery
State is information kept between operations. In-memory state disappears when the process stops; durable storage needs an explicit design.
Mental model: A whiteboard versus a saved notebook.
Limit: A database also fails; persistence needs backups and tested recovery.
Example: Restart this lab server: the task list becomes empty. Explain why before adding a database.
Recall: Name two things required before calling this service production ready.

### Backpressure and request budgets
Bound body sizes and concurrent work before allocating unbounded memory. A limit must count bytes rather than assume characters and must release resources on disconnect or rejection.
Mental model: A loading dock has both a weight limit and a maximum number of trucks.
Limit: If multibyte input bypasses limits, compare encoded byte length with JavaScript string length.
Example: A body of 4097 ASCII bytes exceeds a 4096-byte limit; multibyte text needs a byte count.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If multibyte input bypasses limits, compare encoded byte length with JavaScript string length.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A body of 4097 ASCII bytes exceeds a 4096-byte limit; multibyte text needs a byte count. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Review the reference body loop. Replace string-length counting with Buffer byte counts, reject oversized payloads with 413 and add boundary tests at 4096 and 4097 bytes. Test an interrupted request.
```
node --test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Oversized input creates no task; other requests remain usable; memory conclusions are limited to the measured load.

6. Role workshop · debug and verify
If multibyte input bypasses limits, compare encoded byte length with JavaScript string length. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save body-budget tests and a bounded-load report. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Oversized input creates no task; other requests remain usable; memory conclusions are limited to the measured load.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Backpressure and request budgets: If multibyte input bypasses limits, compare encoded byte length with JavaScript string length.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: body-budget tests and a bounded-load report
Oversized input creates no task; other requests remain usable; memory conclusions are limited to the measured load.

Interview: Work through this Node.js Developer case: A body of 4097 ASCII bytes exceeds a 4096-byte limit; multibyte text needs a byte count. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Bound body sizes and concurrent work before allocating unbounded memory. A limit must count bytes rather than assume characters and must release resources on disconnect or rejection. Expected evidence: Oversized input creates no task; other requests remain usable; memory conclusions are limited to the measured load. Diagnosis: If multibyte input bypasses limits, compare encoded byte length with JavaScript string length. State the limits of the mental model: A loading dock has both a weight limit and a maximum number of trucks.

Resume: Built body-budget tests and a bounded-load report using Node.js; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
Node.js: test runner: https://nodejs.org/api/test.html
