## advanced — Robust speech evaluation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Robust speech evaluation
Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity.
Mental model: A hearing test varies both the speaker and the background sound.
Boundary: Small samples cannot establish fairness across a language community.
Worked example: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Speech recognition robustness audit
Evaluate a real speech recognizer across controlled audio conditions and document its limits. Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.
Worked example: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Recall: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. Identify one observation that would contradict your claim.

### Terms
Robust speech evaluation: Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
WER: Word error rate: substitutions plus deletions plus insertions divided by reference-word count; it can exceed 100%.
ASR: Automatic speech recognition: converting speech audio into text.

### Lab
Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Evaluate a real speech recognizer across controlled audio conditions and document its limits. An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled. Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install openai-whisper jiwer
ffmpeg -i input.wav -ac 1 -ar 16000 -c:a pcm_s16le normalized.wav
whisper normalized.wav --model tiny --output_dir output --output_format json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled.

2. Prepare the project inputs
Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
FFmpeg missing: install it and confirm it is on PATH.
Unexpected language: inspect the recording and language settings.
High WER: audit normalization and reference transcripts before comparing models.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.

### Portfolio
Evaluate a real speech recognizer across controlled audio conditions and document its limits.
Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.
Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions.
Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.
Compare a second recognizer under identical normalization and audio conditions.
Deliverables: Audio/transcript provenance manifest; Reproducible ASR evaluation script; Robustness report with critical-error examples. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A reviewer must reproduce one result and identify which capabilities you implemented. Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

### Interview
Explain your advanced solution for Speech / audio ML engineer. Use this scenario: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Review: Start with the task and permitted scope. Explain robust speech evaluation: Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity. Show the input and observed output, then address Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Audio/transcript provenance manifest; Reproducible ASR evaluation script; Robustness report with critical-error examples. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

