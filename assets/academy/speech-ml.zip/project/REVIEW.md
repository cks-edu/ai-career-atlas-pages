# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Audio/transcript provenance manifest.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
