# Speech recognition robustness audit

Career: Speech / audio ML engineer
Reviewed: 2026-10-22

Evaluate a real speech recognizer across controlled audio conditions and document its limits.

## Prerequisites
Audio signal fundamentals, Python, statistical learning and consent-aware data handling.

## Included starter versus your implementation
An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled.

Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install openai-whisper jiwer
ffmpeg -i input.wav -ac 1 -ar 16000 -c:a pcm_s16le normalized.wav
whisper normalized.wav --model tiny --output_dir output --output_format json
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Audio/transcript provenance manifest — artifact-1.md
2. Reproducible ASR evaluation script — artifact-2.md
3. Robustness report with critical-error examples — artifact-3.md

## Troubleshooting
- FFmpeg missing: install it and confirm it is on PATH.
- Unexpected language: inspect the recording and language settings.
- High WER: audit normalization and reference transcripts before comparing models.

## Extension
Compare a second recognizer under identical normalization and audio conditions.

## Primary learning resources
- Whisper: https://github.com/openai/whisper — Open source code/weights · compute required; Batch speech transcription; requires FFmpeg and model downloads.
- FFmpeg: https://ffmpeg.org/ffmpeg.html — Open source · build licenses vary; Audio conversion without overwriting originals.
- LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html — Open source · no account needed; Import CSV evidence, build review registers and calculate summaries.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
