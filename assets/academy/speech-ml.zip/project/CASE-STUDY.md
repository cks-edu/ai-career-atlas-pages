# Speech recognition robustness audit

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Evaluate a real speech recognizer across controlled audio conditions and document its limits.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

## Limitations and next iteration
Compare a second recognizer under identical normalization and audio conditions.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
