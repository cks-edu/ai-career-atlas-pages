# Robustness report with critical-error examples

Project: Speech recognition robustness audit
Status: blank work product — not completed evidence

## Purpose and audience
Evaluate a real speech recognizer across controlled audio conditions and document its limits.

## Required content
Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.

## Failure evidence
Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
