# Audio/transcript provenance manifest

Project: Speech recognition robustness audit
Status: blank work product — not completed evidence

## Purpose and audience
Evaluate a real speech recognizer across controlled audio conditions and document its limits.

## Required content
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.

## Failure evidence
Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
