# Speech / audio ML engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Transcription error units: Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

WER: Word error rate: substitutions plus deletions plus insertions divided by reference-word count; it can exceed 100%.

### Transcription error units

Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task. In this role, work through: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A copy editor marks missing, changed and extra words against the original.

Boundary: WER alone does not capture speaker identity, meaning or action risk.

Worked example: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Speech / audio ML engineer: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word.

Predict the worked case

Read this case without running a tool: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transcription error units.

Connect the concept to the role

Apply this rule: Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: WER alone does not capture speaker identity, meaning or action risk.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transcription error units to this case: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Transcription error units; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transcription error units. Use the glossary below, then write your prediction for: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Speech / audio ML engineer role interview. Explain transcription error units using this case: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transcription error units to a system or workflow you know. Explain transcription error units using this case: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain transcription error units using this case: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word.

Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task. — Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task. WER alone does not capture speaker identity, meaning or action risk.

Sources:

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

### Diagnose: A transcript metric hides number errors

The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Three utterances fail the critical-field check despite plausible overall transcription. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Report critical-field accuracy separately and require confirmation before using an account number. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A copy editor marks missing, changed and extra words against the original.

Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word.

Worked example: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Report critical-field accuracy separately and require confirmation before using an account number.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary); LibreOffice Calc (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Three utterances fail the critical-field check despite plausible overall transcription. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Apply this toy-case rule manually: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Sampling rate is the number of recorded samples per second. Changing how a recording is represented changes the model’s input.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use a fictional 2-second mono recording sampled at 16,000 samples per second, with 16 bits per sample and no compression.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A calculation sheet with units and assumptions.

Preparation · Try step 2

Calculate sample count and raw data size, excluding any file header.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A calculation sheet with units and assumptions.

Preparation · Try step 3

Repeat for stereo and explain what changed.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A calculation sheet with units and assumptions.

Preparation · Explain and check your result

Mono has 32,000 samples and 64,000 bytes; stereo doubles the data size to 128,000 bytes. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A calculation sheet with units and assumptions. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Apply this toy-case rule manually: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three utterances fail the critical-field check despite plausible overall transcription. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three utterances fail the critical-field check despite plausible overall transcription. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a transcript metric hides number errors. Use the glossary below, then write your prediction for: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Report critical-field accuracy separately and require confirmation before using an account number. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Speech / audio ML engineer role interview. Explain diagnose: a transcript metric hides number errors using this case: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Report critical-field accuracy separately and require confirmation before using an account number. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a transcript metric hides number errors to a system or workflow you know. Explain diagnose: a transcript metric hides number errors using this case: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Report critical-field accuracy separately and require confirmation before using an account number. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Evaluate unseen speakers, noise conditions and corrected read-back flows. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a transcript metric hides number errors using this case: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Report critical-field accuracy separately and require confirmation before using an account number. State the evidence, one alternative and where the mental model stops.

Quiz: A transcript metric hides number errors: The voice workflow treats any wrong account digit in a reviewed utterance as a critical error.

Change the acceptance rule after seeing an inconvenient result.

Report critical-field accuracy separately and require confirmation before using an account number.

Omit failed cases and report only the successful demonstrations.

Reference: Report critical-field accuracy separately and require confirmation before using an account number. — Report critical-field accuracy separately and require confirmation before using an account number. Evaluate unseen speakers, noise conditions and corrected read-back flows.

Sources:

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Audio signal fundamentals, Python, statistical learning and consent-aware data handling.

Terms:

Audio preparation and leakage: Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

WER: Word error rate: substitutions plus deletions plus insertions divided by reference-word count; it can exceed 100%.

ASR: Automatic speech recognition: converting speech audio into text.

### Audio preparation and leakage

Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic. In this role, work through: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Do not test voice recognition using another clip from the same rehearsal by accident.

Boundary: Resampling cannot restore information already lost to poor recording.

Worked example: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Audio signal fundamentals, Python, statistical learning and consent-aware data handling.

Tools for this exercise: Document or text editor

Course tool and framework map: Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Speech / audio ML engineer: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split.

Predict the worked case

Read this case without running a tool: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in audio preparation and leakage.

Connect the concept to the role

Apply this rule: Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Resampling cannot restore information already lost to poor recording.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies audio preparation and leakage to this case: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Audio preparation and leakage; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with audio preparation and leakage. Use the glossary below, then write your prediction for: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Speech / audio ML engineer role interview. Explain audio preparation and leakage using this case: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate audio preparation and leakage to a system or workflow you know. Explain audio preparation and leakage using this case: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain audio preparation and leakage using this case: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split.

Treat a passing starter as proof of the whole role workflow.

Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic.

Ignore the failure because the tool produced an output.

Reference: Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic. — Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic. Resampling cannot restore information already lost to poor recording.

Sources:

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

### Integrate: Speech recognition robustness audit

Evaluate a real speech recognizer across controlled audio conditions and document its limits. Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions. In this role, work through: Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.

Role application: Do not test voice recognition using another clip from the same rehearsal by accident.

Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split.

Worked example: Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.

Setup: Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary); LibreOffice Calc (Open source · no account needed)

Evaluate a real speech recognizer across controlled audio conditions and document its limits. An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled. Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.

Evaluate a real speech recognizer across controlled audio conditions and document its limits.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install openai-whisper jiwer
ffmpeg -i input.wav -ac 1 -ar 16000 -c:a pcm_s16le normalized.wav
whisper normalized.wav --model tiny --output_dir output --output_format json
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled.

Prepare the project inputs

Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.

Deliverable: lesson-intermediate-2.md: Audio/transcript provenance manifest; Reproducible ASR evaluation script. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: speech recognition robustness audit. Use the glossary below, then write your prediction for: Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Speech / audio ML engineer role interview. Explain integrate: speech recognition robustness audit using this case: Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: speech recognition robustness audit to a system or workflow you know. Explain integrate: speech recognition robustness audit using this case: Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. Identify one observation that would contradict your claim.

Interview: Explain integrate: speech recognition robustness audit using this case: Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Speech recognition robustness audit at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.

Reference: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. — Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.

Sources:

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Robust speech evaluation: Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

WER: Word error rate: substitutions plus deletions plus insertions divided by reference-word count; it can exceed 100%.

ASR: Automatic speech recognition: converting speech audio into text.

### Robust speech evaluation

Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity. In this role, work through: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A hearing test varies both the speaker and the background sound.

Boundary: Small samples cannot establish fairness across a language community.

Worked example: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Speech / audio ML engineer: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions.

Predict the worked case

Read this case without running a tool: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in robust speech evaluation.

Connect the concept to the role

Apply this rule: Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Small samples cannot establish fairness across a language community.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies robust speech evaluation to this case: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Robust speech evaluation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with robust speech evaluation. Use the glossary below, then write your prediction for: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Speech / audio ML engineer role interview. Explain robust speech evaluation using this case: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate robust speech evaluation to a system or workflow you know. Explain robust speech evaluation using this case: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain robust speech evaluation using this case: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity.

Reference: Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity. — Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity. Small samples cannot establish fairness across a language community.

Sources:

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

### Defend: Speech recognition robustness audit

Evaluate a real speech recognizer across controlled audio conditions and document its limits. Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions. In this role, work through: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.

Role application: A hearing test varies both the speaker and the background sound.

Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions.

Worked example: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

Setup: Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Whisper (Open source code/weights · compute required); FFmpeg (Open source · build licenses vary); LibreOffice Calc (Open source · no account needed)

Evaluate a real speech recognizer across controlled audio conditions and document its limits. An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled. Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.

Evaluate a real speech recognizer across controlled audio conditions and document its limits.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install openai-whisper jiwer
ffmpeg -i input.wav -ac 1 -ar 16000 -c:a pcm_s16le normalized.wav
whisper normalized.wav --model tiny --output_dir output --output_format json
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled.

Prepare the project inputs

Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A reviewer must reproduce one result and identify which capabilities you implemented. Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.

Deliverable: lesson-advanced-2.md: Audio/transcript provenance manifest; Reproducible ASR evaluation script; Robustness report with critical-error examples. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: speech recognition robustness audit. Use the glossary below, then write your prediction for: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Speech / audio ML engineer role interview. Explain defend: speech recognition robustness audit using this case: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: speech recognition robustness audit to a system or workflow you know. Explain defend: speech recognition robustness audit using this case: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. Identify one observation that would contradict your claim.

Interview: Explain defend: speech recognition robustness audit using this case: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Speech recognition robustness audit at this level?

Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER. — Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER. Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.

Sources:

Whisper: https://github.com/openai/whisper

FFmpeg: https://ffmpeg.org/ffmpeg.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/
