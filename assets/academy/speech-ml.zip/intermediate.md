## intermediate — Audio preparation and leakage

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Audio signal fundamentals, Python, statistical learning and consent-aware data handling.

### Audio preparation and leakage
Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic.
Mental model: Do not test voice recognition using another clip from the same rehearsal by accident.
Boundary: Resampling cannot restore information already lost to poor recording.
Worked example: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Speech recognition robustness audit
Evaluate a real speech recognizer across controlled audio conditions and document its limits. Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.
Worked example: Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Recall: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. Identify one observation that would contradict your claim.

### Terms
Audio preparation and leakage: Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
WER: Word error rate: substitutions plus deletions plus insertions divided by reference-word count; it can exceed 100%.
ASR: Automatic speech recognition: converting speech audio into text.

### Lab
Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Evaluate a real speech recognizer across controlled audio conditions and document its limits. An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled. Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install openai-whisper jiwer
ffmpeg -i input.wav -ac 1 -ar 16000 -c:a pcm_s16le normalized.wav
whisper normalized.wav --model tiny --output_dir output --output_format json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled.

2. Prepare the project inputs
Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
FFmpeg missing: install it and confirm it is on PATH.
Unexpected language: inspect the recording and language settings.
High WER: audit normalization and reference transcripts before comparing models.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.

### Portfolio
Evaluate a real speech recognizer across controlled audio conditions and document its limits.
Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.
Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.
Deliverables: Audio/transcript provenance manifest; Reproducible ASR evaluation script. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Speech / audio ML engineer. Use this scenario: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Review: Start with the task and permitted scope. Explain audio preparation and leakage: Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic. Show the input and observed output, then address Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Audio/transcript provenance manifest; Reproducible ASR evaluation script. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

