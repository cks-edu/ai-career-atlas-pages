# Speech / audio ML engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Transcription error units. Sampling rate is the number of recorded samples per second. Changing how a recording is represented changes the model’s input. Then try Work out audio size. The three levels build toward Speech recognition robustness audit. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Transcription error units

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Transcription error units
Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task.
Mental model: A copy editor marks missing, changed and extra words against the original.
Boundary: WER alone does not capture speaker identity, meaning or action risk.
Worked example: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A transcript metric hides number errors
The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Three utterances fail the critical-field check despite plausible overall transcription. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Report critical-field accuracy separately and require confirmation before using an account number.
Recall: Evaluate unseen speakers, noise conditions and corrected read-back flows. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Transcription error units: Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
WER: Word error rate: substitutions plus deletions plus insertions divided by reference-word count; it can exceed 100%.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Sampling rate is the number of recorded samples per second. Changing how a recording is represented changes the model’s input.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional 2-second mono recording sampled at 16,000 samples per second, with 16 bits per sample and no compression.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A calculation sheet with units and assumptions.

3. Try step 2
Calculate sample count and raw data size, excluding any file header.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A calculation sheet with units and assumptions.

4. Try step 3
Repeat for stereo and explain what changed.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A calculation sheet with units and assumptions.

5. Explain and check your result
Mono has 32,000 samples and 64,000 bytes; stereo doubles the data size to 128,000 bytes. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A calculation sheet with units and assumptions. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Apply this toy-case rule manually: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three utterances fail the critical-field check despite plausible overall transcription. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Speech / audio ML engineer.
Use a fictional 2-second mono recording sampled at 16,000 samples per second, with 16 bits per sample and no compression.
Calculate sample count and raw data size, excluding any file header.
Repeat for stereo and explain what changed.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A calculation sheet with units and assumptions. Include beginner-worksheet.md and your completed Audio evaluation worksheet.
Check: Mono has 32,000 samples and 64,000 bytes; stereo doubles the data size to 128,000 bytes.

### Interview
Explain your beginner solution for Speech / audio ML engineer. Use this scenario: The voice workflow treats any wrong account digit in a reviewed utterance as a critical error.
Review: Start with the task and permitted scope. Explain transcription error units: Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task. Show the input and observed output, then address Report critical-field accuracy separately and require confirmation before using an account number. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A calculation sheet with units and assumptions. Include beginner-worksheet.md and your completed Audio evaluation worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Audio preparation and leakage

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Audio signal fundamentals, Python, statistical learning and consent-aware data handling.

### Audio preparation and leakage
Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic.
Mental model: Do not test voice recognition using another clip from the same rehearsal by accident.
Boundary: Resampling cannot restore information already lost to poor recording.
Worked example: Resample an authorized recording and verify duration before and after; keep all clips from one speaker in the declared split.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Speech recognition robustness audit
Evaluate a real speech recognizer across controlled audio conditions and document its limits. Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.
Worked example: Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Recall: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. Identify one observation that would contradict your claim.

### Terms
Audio preparation and leakage: Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
WER: Word error rate: substitutions plus deletions plus insertions divided by reference-word count; it can exceed 100%.
ASR: Automatic speech recognition: converting speech audio into text.

### Lab
Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Evaluate a real speech recognizer across controlled audio conditions and document its limits. An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled. Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install openai-whisper jiwer
ffmpeg -i input.wav -ac 1 -ar 16000 -c:a pcm_s16le normalized.wav
whisper normalized.wav --model tiny --output_dir output --output_format json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled.

2. Prepare the project inputs
Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
FFmpeg missing: install it and confirm it is on PATH.
Unexpected language: inspect the recording and language settings.
High WER: audit normalization and reference transcripts before comparing models.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.

### Portfolio
Evaluate a real speech recognizer across controlled audio conditions and document its limits.
Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.
Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.
Deliverables: Audio/transcript provenance manifest; Reproducible ASR evaluation script. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Speech / audio ML engineer. Use this scenario: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Review: Start with the task and permitted scope. Explain audio preparation and leakage: Record sample rate, channel handling and segmentation. Split by speaker or recording session where shared identity would otherwise make held-out results optimistic. Show the input and observed output, then address Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Audio/transcript provenance manifest; Reproducible ASR evaluation script. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Robust speech evaluation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Robust speech evaluation
Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity.
Mental model: A hearing test varies both the speaker and the background sound.
Boundary: Small samples cannot establish fairness across a language community.
Worked example: Evaluate a small consented set with and without noise; report per-condition counts and inspect number substitutions.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Speech recognition robustness audit
Evaluate a real speech recognizer across controlled audio conditions and document its limits. Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.
Worked example: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Recall: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. Identify one observation that would contradict your claim.

### Terms
Robust speech evaluation: Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
WER: Word error rate: substitutions plus deletions plus insertions divided by reference-word count; it can exceed 100%.
ASR: Automatic speech recognition: converting speech audio into text.

### Lab
Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Evaluate a real speech recognizer across controlled audio conditions and document its limits. An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled. Initial model download and CPU/GPU runtime required. Audio rights and participant consent must be documented.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install FFmpeg from its official distribution and Whisper in a dedicated Python environment. Supply a self-recorded or licensed input.wav; audio is not bundled. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install openai-whisper jiwer
ffmpeg -i input.wav -ac 1 -ar 16000 -c:a pcm_s16le normalized.wav
whisper normalized.wav --model tiny --output_dir output --output_format json
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: An audio manifest template and command recipe. Whisper performs actual transcription when you supply audio and download the model; no transcript results are pre-filled.

2. Prepare the project inputs
Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
FFmpeg missing: install it and confirm it is on PATH.
Unexpected language: inspect the recording and language settings.
High WER: audit normalization and reference transcripts before comparing models.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop transcription jobs and retain only permitted audio. Do not overwrite original recordings during normalization.

### Portfolio
Evaluate a real speech recognizer across controlled audio conditions and document its limits.
Collect self-recorded or appropriately licensed audio with reference transcripts and speaker/session IDs. Avoid evaluating training-adjacent clips as independent evidence.
Run the supplied audio conversion recipe on copies of recordings. Retain sample rate, duration and original hash in a manifest.
Transcribe with Whisper, save raw hypotheses and compute word error rate with jiwer. Define normalization rules before scoring numbers, punctuation and contractions.
Create noise and speed variants, then compare errors by condition and speaker. Add a manual review rubric for meaning-changing substitutions.
Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness.
Compare a second recognizer under identical normalization and audio conditions.
Deliverables: Audio/transcript provenance manifest; Reproducible ASR evaluation script; Robustness report with critical-error examples. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A reviewer must reproduce one result and identify which capabilities you implemented. Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.

### Interview
Explain your advanced solution for Speech / audio ML engineer. Use this scenario: Include silence, background speech and a critical negation. Inspect hallucinated text and meaning reversal rather than relying only on average WER.
Review: Start with the task and permitted scope. Explain robust speech evaluation: Compare recognition across declared accents, noise levels and domains, with qualified review. Track confidence limitations and add clarification for consequential ambiguity. Show the input and observed output, then address Report WER, critical semantic errors, real-time factor and failures by condition. Small volunteer samples do not establish population-wide accent fairness. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Audio/transcript provenance manifest; Reproducible ASR evaluation script; Robustness report with critical-error examples. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Whisper — Open source code/weights · compute required
Batch speech transcription; requires FFmpeg and model downloads.
Alternative: A commercial speech API or another openly licensed ASR model; inspect language coverage, privacy and model terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

FFmpeg — Open source · build licenses vary
Audio conversion without overwriting originals.
Alternative: GStreamer (open source); compare pipeline needs and the exact codec/plugin licenses.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Whisper: https://github.com/openai/whisper
FFmpeg: https://ffmpeg.org/ffmpeg.html
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
ONNX Runtime: https://onnxruntime.ai/docs/
