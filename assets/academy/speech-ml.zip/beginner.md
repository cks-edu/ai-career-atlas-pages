## beginner — Transcription error units

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Transcription error units
Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task.
Mental model: A copy editor marks missing, changed and extra words against the original.
Boundary: WER alone does not capture speaker identity, meaning or action risk.
Worked example: Two errors in ten reference words gives 20% WER; an incorrect amount may be more harmful than a missing filler word.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A transcript metric hides number errors
The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Three utterances fail the critical-field check despite plausible overall transcription. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Report critical-field accuracy separately and require confirmation before using an account number.
Recall: Evaluate unseen speakers, noise conditions and corrected read-back flows. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Transcription error units: Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
WER: Word error rate: substitutions plus deletions plus insertions divided by reference-word count; it can exceed 100%.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Sampling rate is the number of recorded samples per second. Changing how a recording is represented changes the model’s input.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional 2-second mono recording sampled at 16,000 samples per second, with 16 bits per sample and no compression.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A calculation sheet with units and assumptions.

3. Try step 2
Calculate sample count and raw data size, excluding any file header.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A calculation sheet with units and assumptions.

4. Try step 3
Repeat for stereo and explain what changed.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A calculation sheet with units and assumptions.

5. Explain and check your result
Mono has 32,000 samples and 64,000 bytes; stereo doubles the data size to 128,000 bytes. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A calculation sheet with units and assumptions. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The voice workflow treats any wrong account digit in a reviewed utterance as a critical error. Apply this toy-case rule manually: Review when wrong_digits >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three utterances fail the critical-field check despite plausible overall transcription. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Speech / audio ML engineer.
Use a fictional 2-second mono recording sampled at 16,000 samples per second, with 16 bits per sample and no compression.
Calculate sample count and raw data size, excluding any file header.
Repeat for stereo and explain what changed.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A calculation sheet with units and assumptions. Include beginner-worksheet.md and your completed Audio evaluation worksheet.
Check: Mono has 32,000 samples and 64,000 bytes; stereo doubles the data size to 128,000 bytes.

### Interview
Explain your beginner solution for Speech / audio ML engineer. Use this scenario: The voice workflow treats any wrong account digit in a reviewed utterance as a critical error.
Review: Start with the task and permitted scope. Explain transcription error units: Word error rate compares substitutions, deletions and insertions with reference words. Preserve transcription conventions and inspect which errors matter for the task. Show the input and observed output, then address Report critical-field accuracy separately and require confirmation before using an account number. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A calculation sheet with units and assumptions. Include beginner-worksheet.md and your completed Audio evaluation worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

