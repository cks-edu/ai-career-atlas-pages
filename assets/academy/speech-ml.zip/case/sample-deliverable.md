# SAMPLE — Audio evaluation worksheet
Role: Speech / audio ML engineer
Case: A transcript metric hides number errors
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The voice workflow treats any wrong account digit in a reviewed utterance as a critical error.

## Evidence table
| Record | wrong_digits (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three utterances fail the critical-field check despite plausible overall transcription.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Report critical-field accuracy separately and require confirmation before using an account number.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in speech / audio ml engineer.
Before release: Evaluate unseen speakers, noise conditions and corrected read-back flows.

## Design choice and trade-off
Separate linguistic transcription quality from task-critical fields; preserve speaker-disjoint evaluation.
Confirmation adds conversational turns but reduces the cost of silently accepting a wrong identifier.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Accent robustness study: Explain sample sizes and avoid population-wide claims.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
