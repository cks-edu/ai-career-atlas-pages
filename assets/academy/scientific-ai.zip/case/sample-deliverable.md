# SAMPLE — Spatial-validation report and scientific assumptions table
Role: AI for materials, climate, energy & geospatial analysis
Case: Spatial neighbors leak into evaluation
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The geospatial protocol requires no sampled tile overlap between training and evaluation regions.

## Evidence table
| Record | overlapping_tiles (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 3 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three spatial splits overlap and undermine the claim of generalization to new regions.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Use geographically separated holdouts and document resolution, masks and time boundaries.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai for materials, climate, energy & geospatial analysis.
Before release: Compare physical or statistical baselines and report uncertainty in unseen regions.

## Design choice and trade-off
Choose domain-valid splits and physical plausibility checks; retain uncertainty and provenance.
Geographic separation can make scores lower but is more informative for deployment in an unfamiliar region.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Geospatial change study: Report cloud masking, spatial leakage and uncertainty.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
