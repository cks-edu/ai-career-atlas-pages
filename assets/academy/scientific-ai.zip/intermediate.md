## intermediate — Geospatial validation

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Choose one domain and its physical assumptions; scientific roles often need advanced subject expertise as well as ML.

### Geospatial validation
Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline.
Mental model: An exam on the next street may be easier than an exam in an unfamiliar city.
Boundary: One regional holdout does not establish global transfer.
Worked example: Hold out a region rather than random neighboring pixels and compare errors by terrain or season.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Geospatial change analysis with uncertainty
Build a reproducible spatial analysis where data quality and spatial leakage are visible. Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.
Recall: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. Identify one observation that would contradict your claim.

### Terms
Geospatial validation: Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a reproducible spatial analysis where data quality and spatial leakage are visible. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a reproducible spatial analysis where data quality and spatial leakage are visible.
Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.
Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.
Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.
Deliverables: Geospatial processing pipeline and data manifest; Maps with uncertainty and coverage. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI for materials, climate, energy & geospatial analysis. Use this scenario: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.
Review: Start with the task and permitted scope. Explain geospatial validation: Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline. Show the input and observed output, then address Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Geospatial processing pipeline and data manifest; Maps with uncertainty and coverage. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

