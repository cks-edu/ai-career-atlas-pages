# Geospatial change analysis with uncertainty

Career: AI for materials, climate, energy & geospatial analysis
Reviewed: 2026-10-22

Build a reproducible spatial analysis where data quality and spatial leakage are visible.

## Prerequisites
Choose one domain and its physical assumptions; scientific roles often need advanced subject expertise as well as ML.

## Included starter versus your implementation
DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Create maps with units, legends and uncertainty/coverage layers. Compare against an independent reference where available and document confounders such as clouds or sensor changes.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Geospatial processing pipeline and data manifest — artifact-1.md
2. Maps with uncertainty and coverage — artifact-2.md
3. Scientific methods/limitations report — artifact-3.md

## Troubleshooting
- Missing CSV: run from the extracted folder.
- Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
- Wrong totals: check units, duplicate joins and whether failures are included.

## Extension
Repeat on another region or season to assess transfer rather than claiming global validity.

## Primary learning resources
- Rasterio: https://rasterio.readthedocs.io/en/stable/quickstart.html — Open source · native dependencies; Raster metadata, coordinate systems and spatial processing.
- scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html — Open source · CPU; Pipelines, baselines, data splits and statistical evaluation.
- QGIS: https://docs.qgis.org/ — Open source · local; Inspect geospatial layers and produce documented maps.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
