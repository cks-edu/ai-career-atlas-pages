# Maps with uncertainty and coverage

Project: Geospatial change analysis with uncertainty
Status: blank work product — not completed evidence

## Purpose and audience
Build a reproducible spatial analysis where data quality and spatial leakage are visible.

## Required content
Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.

## Failure evidence
Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
