# Scientific methods/limitations report

Project: Geospatial change analysis with uncertainty
Status: blank work product — not completed evidence

## Purpose and audience
Build a reproducible spatial analysis where data quality and spatial leakage are visible.

## Required content
Create maps with units, legends and uncertainty/coverage layers. Compare against an independent reference where available and document confounders such as clouds or sensor changes.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.

## Failure evidence
Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
