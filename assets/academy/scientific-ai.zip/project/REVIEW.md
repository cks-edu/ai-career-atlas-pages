# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Geospatial processing pipeline and data manifest.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
