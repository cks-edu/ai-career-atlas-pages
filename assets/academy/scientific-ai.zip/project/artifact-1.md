# Geospatial processing pipeline and data manifest

Project: Geospatial change analysis with uncertainty
Status: blank work product — not completed evidence

## Purpose and audience
Build a reproducible spatial analysis where data quality and spatial leakage are visible.

## Required content
Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.

## Failure evidence
Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
