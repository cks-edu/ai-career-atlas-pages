# AI for materials, climate, energy & geospatial analysis — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Spatial and temporal context: Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

coordinate: A position described relative to a named frame or coordinate reference system.

### Spatial and temporal context

Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps. In this role, work through: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Two maps cannot be overlaid correctly if their scales and origins differ.

Boundary: Resampling can change values and uncertainty, not just file shape.

Worked example: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Rasterio (Open source · native dependencies); scikit-learn (Open source · CPU); QGIS (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI for materials, climate, energy & geospatial analysis: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis.

Predict the worked case

Read this case without running a tool: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in spatial and temporal context.

Connect the concept to the role

Apply this rule: Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Resampling can change values and uncertainty, not just file shape.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies spatial and temporal context to this case: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Spatial and temporal context; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with spatial and temporal context. Use the glossary below, then write your prediction for: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for materials, climate, energy & geospatial analysis role interview. Explain spatial and temporal context using this case: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate spatial and temporal context to a system or workflow you know. Explain spatial and temporal context using this case: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain spatial and temporal context using this case: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis.

Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps. — Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps. Resampling can change values and uncertainty, not just file shape.

Sources:

Rasterio: https://rasterio.readthedocs.io/en/stable/quickstart.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

QGIS: https://docs.qgis.org/

Google Earth Engine tutorials: https://developers.google.com/earth-engine/tutorials/tutorials

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Diagnose: Spatial neighbors leak into evaluation

The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Three spatial splits overlap and undermine the claim of generalization to new regions. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Use geographically separated holdouts and document resolution, masks and time boundaries. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Two maps cannot be overlaid correctly if their scales and origins differ.

A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis.

Worked example: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Use geographically separated holdouts and document resolution, masks and time boundaries.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Rasterio (Open source · native dependencies); scikit-learn (Open source · CPU); QGIS (Open source · local)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Three spatial splits overlap and undermine the claim of generalization to new regions. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Apply this toy-case rule manually: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A scientific prediction needs a defined place, time and measurement process. Physical constraints and data collection matter alongside model scores.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Choose the task of predicting tomorrow’s energy use for one fictional building, in kilowatt-hours.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A forecast brief with units, timing, baseline and data checks.

Preparation · Try step 2

List data available today, the forecast period and a simple baseline such as the previous comparable day.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A forecast brief with units, timing, baseline and data checks.

Preparation · Try step 3

Write checks for missing readings, changed opening hours and impossible negative consumption values.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A forecast brief with units, timing, baseline and data checks.

Preparation · Explain and check your result

Future measured consumption is not an input to today’s forecast; the result is scoped to the stated building and conditions. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A forecast brief with units, timing, baseline and data checks. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Apply this toy-case rule manually: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three spatial splits overlap and undermine the claim of generalization to new regions. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three spatial splits overlap and undermine the claim of generalization to new regions. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: spatial neighbors leak into evaluation. Use the glossary below, then write your prediction for: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Use geographically separated holdouts and document resolution, masks and time boundaries. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for materials, climate, energy & geospatial analysis role interview. Explain diagnose: spatial neighbors leak into evaluation using this case: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Use geographically separated holdouts and document resolution, masks and time boundaries. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: spatial neighbors leak into evaluation to a system or workflow you know. Explain diagnose: spatial neighbors leak into evaluation using this case: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Use geographically separated holdouts and document resolution, masks and time boundaries. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Compare physical or statistical baselines and report uncertainty in unseen regions. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: spatial neighbors leak into evaluation using this case: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Use geographically separated holdouts and document resolution, masks and time boundaries. State the evidence, one alternative and where the mental model stops.

Quiz: Spatial neighbors leak into evaluation: The geospatial protocol requires no sampled tile overlap between training and evaluation regions.

Change the acceptance rule after seeing an inconvenient result.

Use geographically separated holdouts and document resolution, masks and time boundaries.

Omit failed cases and report only the successful demonstrations.

Reference: Use geographically separated holdouts and document resolution, masks and time boundaries. — Use geographically separated holdouts and document resolution, masks and time boundaries. Compare physical or statistical baselines and report uncertainty in unseen regions.

Sources:

Rasterio: https://rasterio.readthedocs.io/en/stable/quickstart.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

QGIS: https://docs.qgis.org/

Google Earth Engine tutorials: https://developers.google.com/earth-engine/tutorials/tutorials

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Choose one domain and its physical assumptions; scientific roles often need advanced subject expertise as well as ML.

Terms:

Geospatial validation: Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Geospatial validation

Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline. In this role, work through: Hold out a region rather than random neighboring pixels and compare errors by terrain or season. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An exam on the next street may be easier than an exam in an unfamiliar city.

Boundary: One regional holdout does not establish global transfer.

Worked example: Hold out a region rather than random neighboring pixels and compare errors by terrain or season.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Choose one domain and its physical assumptions; scientific roles often need advanced subject expertise as well as ML.

Tools for this exercise: Document or text editor

Course tool and framework map: Rasterio (Open source · native dependencies); scikit-learn (Open source · CPU); QGIS (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI for materials, climate, energy & geospatial analysis: Hold out a region rather than random neighboring pixels and compare errors by terrain or season.

Predict the worked case

Read this case without running a tool: Hold out a region rather than random neighboring pixels and compare errors by terrain or season. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in geospatial validation.

Connect the concept to the role

Apply this rule: Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: One regional holdout does not establish global transfer.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies geospatial validation to this case: Hold out a region rather than random neighboring pixels and compare errors by terrain or season. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Hold out a region rather than random neighboring pixels and compare errors by terrain or season. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Geospatial validation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with geospatial validation. Use the glossary below, then write your prediction for: Hold out a region rather than random neighboring pixels and compare errors by terrain or season. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for materials, climate, energy & geospatial analysis role interview. Explain geospatial validation using this case: Hold out a region rather than random neighboring pixels and compare errors by terrain or season. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate geospatial validation to a system or workflow you know. Explain geospatial validation using this case: Hold out a region rather than random neighboring pixels and compare errors by terrain or season. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain geospatial validation using this case: Hold out a region rather than random neighboring pixels and compare errors by terrain or season. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Hold out a region rather than random neighboring pixels and compare errors by terrain or season.

Treat a passing starter as proof of the whole role workflow.

Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline.

Ignore the failure because the tool produced an output.

Reference: Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline. — Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline. One regional holdout does not establish global transfer.

Sources:

Rasterio: https://rasterio.readthedocs.io/en/stable/quickstart.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

QGIS: https://docs.qgis.org/

Google Earth Engine tutorials: https://developers.google.com/earth-engine/tutorials/tutorials

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Integrate: Geospatial change analysis with uncertainty

Build a reproducible spatial analysis where data quality and spatial leakage are visible. Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels. In this role, work through: Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: An exam on the next street may be easier than an exam in an unfamiliar city.

Hold out a region rather than random neighboring pixels and compare errors by terrain or season.

Worked example: Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Rasterio (Open source · native dependencies); scikit-learn (Open source · CPU); QGIS (Open source · local)

Build a reproducible spatial analysis where data quality and spatial leakage are visible. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a reproducible spatial analysis where data quality and spatial leakage are visible.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-intermediate-2.md: Geospatial processing pipeline and data manifest; Maps with uncertainty and coverage. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: geospatial change analysis with uncertainty. Use the glossary below, then write your prediction for: Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for materials, climate, energy & geospatial analysis role interview. Explain integrate: geospatial change analysis with uncertainty using this case: Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: geospatial change analysis with uncertainty to a system or workflow you know. Explain integrate: geospatial change analysis with uncertainty using this case: Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. Identify one observation that would contradict your claim.

Interview: Explain integrate: geospatial change analysis with uncertainty using this case: Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Geospatial change analysis with uncertainty at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.

Reference: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. — Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.

Sources:

Rasterio: https://rasterio.readthedocs.io/en/stable/quickstart.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

QGIS: https://docs.qgis.org/

Google Earth Engine tutorials: https://developers.google.com/earth-engine/tutorials/tutorials

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Scientific uncertainty communication: Show coverage, error and assumptions alongside predictions. Distinguish model output from observed measurements and state where the model should not be used.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Scientific uncertainty communication

Show coverage, error and assumptions alongside predictions. Distinguish model output from observed measurements and state where the model should not be used. In this role, work through: Publish a predicted map with an error summary and mask locations outside the supported data range. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A weather map includes uncertainty and blank areas instead of painting every location with equal confidence.

Boundary: A visually detailed map may still be scientifically unreliable.

Worked example: Publish a predicted map with an error summary and mask locations outside the supported data range.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Rasterio (Open source · native dependencies); scikit-learn (Open source · CPU); QGIS (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI for materials, climate, energy & geospatial analysis: Publish a predicted map with an error summary and mask locations outside the supported data range.

Predict the worked case

Read this case without running a tool: Publish a predicted map with an error summary and mask locations outside the supported data range. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in scientific uncertainty communication.

Connect the concept to the role

Apply this rule: Show coverage, error and assumptions alongside predictions. Distinguish model output from observed measurements and state where the model should not be used. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A visually detailed map may still be scientifically unreliable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies scientific uncertainty communication to this case: Publish a predicted map with an error summary and mask locations outside the supported data range. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Publish a predicted map with an error summary and mask locations outside the supported data range. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Scientific uncertainty communication; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with scientific uncertainty communication. Use the glossary below, then write your prediction for: Publish a predicted map with an error summary and mask locations outside the supported data range. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for materials, climate, energy & geospatial analysis role interview. Explain scientific uncertainty communication using this case: Publish a predicted map with an error summary and mask locations outside the supported data range. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate scientific uncertainty communication to a system or workflow you know. Explain scientific uncertainty communication using this case: Publish a predicted map with an error summary and mask locations outside the supported data range. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain scientific uncertainty communication using this case: Publish a predicted map with an error summary and mask locations outside the supported data range. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Publish a predicted map with an error summary and mask locations outside the supported data range.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Show coverage, error and assumptions alongside predictions. Distinguish model output from observed measurements and state where the model should not be used.

Reference: Show coverage, error and assumptions alongside predictions. Distinguish model output from observed measurements and state where the model should not be used. — Show coverage, error and assumptions alongside predictions. Distinguish model output from observed measurements and state where the model should not be used. A visually detailed map may still be scientifically unreliable.

Sources:

Rasterio: https://rasterio.readthedocs.io/en/stable/quickstart.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

QGIS: https://docs.qgis.org/

Google Earth Engine tutorials: https://developers.google.com/earth-engine/tutorials/tutorials

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Defend: Geospatial change analysis with uncertainty

Build a reproducible spatial analysis where data quality and spatial leakage are visible. Create maps with units, legends and uncertainty/coverage layers. Compare against an independent reference where available and document confounders such as clouds or sensor changes. In this role, work through: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A weather map includes uncertainty and blank areas instead of painting every location with equal confidence.

Publish a predicted map with an error summary and mask locations outside the supported data range.

Worked example: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Rasterio (Open source · native dependencies); scikit-learn (Open source · CPU); QGIS (Open source · local)

Build a reproducible spatial analysis where data quality and spatial leakage are visible. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Build a reproducible spatial analysis where data quality and spatial leakage are visible.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Create maps with units, legends and uncertainty/coverage layers. Compare against an independent reference where available and document confounders such as clouds or sensor changes.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-advanced-2.md: Geospatial processing pipeline and data manifest; Maps with uncertainty and coverage; Scientific methods/limitations report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: geospatial change analysis with uncertainty. Use the glossary below, then write your prediction for: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for materials, climate, energy & geospatial analysis role interview. Explain defend: geospatial change analysis with uncertainty using this case: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: geospatial change analysis with uncertainty to a system or workflow you know. Explain defend: geospatial change analysis with uncertainty using this case: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. Identify one observation that would contradict your claim.

Interview: Explain defend: geospatial change analysis with uncertainty using this case: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Geospatial change analysis with uncertainty at this level?

Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change. — Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change. Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.

Sources:

Rasterio: https://rasterio.readthedocs.io/en/stable/quickstart.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

QGIS: https://docs.qgis.org/

Google Earth Engine tutorials: https://developers.google.com/earth-engine/tutorials/tutorials

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
