# AI for materials, climate, energy & geospatial analysis

AI Engineering · Beginner → Intermediate → Advanced

Start with Spatial and temporal context. A scientific prediction needs a defined place, time and measurement process. Physical constraints and data collection matter alongside model scores. Then try Frame a fictional energy forecast. The three levels build toward Geospatial change analysis with uncertainty. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Spatial and temporal context

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Spatial and temporal context
Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps.
Mental model: Two maps cannot be overlaid correctly if their scales and origins differ.
Boundary: Resampling can change values and uncertainty, not just file shape.
Worked example: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Spatial neighbors leak into evaluation
The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Three spatial splits overlap and undermine the claim of generalization to new regions. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Use geographically separated holdouts and document resolution, masks and time boundaries.
Recall: Compare physical or statistical baselines and report uncertainty in unseen regions. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Spatial and temporal context: Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
coordinate: A position described relative to a named frame or coordinate reference system.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A scientific prediction needs a defined place, time and measurement process. Physical constraints and data collection matter alongside model scores.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose the task of predicting tomorrow’s energy use for one fictional building, in kilowatt-hours.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A forecast brief with units, timing, baseline and data checks.

3. Try step 2
List data available today, the forecast period and a simple baseline such as the previous comparable day.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A forecast brief with units, timing, baseline and data checks.

4. Try step 3
Write checks for missing readings, changed opening hours and impossible negative consumption values.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A forecast brief with units, timing, baseline and data checks.

5. Explain and check your result
Future measured consumption is not an input to today’s forecast; the result is scoped to the stated building and conditions. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A forecast brief with units, timing, baseline and data checks. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Apply this toy-case rule manually: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three spatial splits overlap and undermine the claim of generalization to new regions. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI for materials, climate, energy & geospatial analysis.
Choose the task of predicting tomorrow’s energy use for one fictional building, in kilowatt-hours.
List data available today, the forecast period and a simple baseline such as the previous comparable day.
Write checks for missing readings, changed opening hours and impossible negative consumption values.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A forecast brief with units, timing, baseline and data checks. Include beginner-worksheet.md and your completed Spatial-validation report and scientific assumptions table.
Check: Future measured consumption is not an input to today’s forecast; the result is scoped to the stated building and conditions.

### Interview
Explain your beginner solution for AI for materials, climate, energy & geospatial analysis. Use this scenario: The geospatial protocol requires no sampled tile overlap between training and evaluation regions.
Review: Start with the task and permitted scope. Explain spatial and temporal context: Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps. Show the input and observed output, then address Use geographically separated holdouts and document resolution, masks and time boundaries. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A forecast brief with units, timing, baseline and data checks. Include beginner-worksheet.md and your completed Spatial-validation report and scientific assumptions table.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Geospatial validation

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Choose one domain and its physical assumptions; scientific roles often need advanced subject expertise as well as ML.

### Geospatial validation
Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline.
Mental model: An exam on the next street may be easier than an exam in an unfamiliar city.
Boundary: One regional holdout does not establish global transfer.
Worked example: Hold out a region rather than random neighboring pixels and compare errors by terrain or season.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Geospatial change analysis with uncertainty
Build a reproducible spatial analysis where data quality and spatial leakage are visible. Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.
Recall: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. Identify one observation that would contradict your claim.

### Terms
Geospatial validation: Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a reproducible spatial analysis where data quality and spatial leakage are visible. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a reproducible spatial analysis where data quality and spatial leakage are visible.
Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.
Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.
Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.
Deliverables: Geospatial processing pipeline and data manifest; Maps with uncertainty and coverage. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI for materials, climate, energy & geospatial analysis. Use this scenario: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.
Review: Start with the task and permitted scope. Explain geospatial validation: Separate evaluation by relevant regions or time periods to avoid nearby or repeated observations leaking into the test set. Compare with a domain-relevant baseline. Show the input and observed output, then address Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Geospatial processing pipeline and data manifest; Maps with uncertainty and coverage. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Scientific uncertainty communication

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Scientific uncertainty communication
Show coverage, error and assumptions alongside predictions. Distinguish model output from observed measurements and state where the model should not be used.
Mental model: A weather map includes uncertainty and blank areas instead of painting every location with equal confidence.
Boundary: A visually detailed map may still be scientifically unreliable.
Worked example: Publish a predicted map with an error summary and mask locations outside the supported data range.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Geospatial change analysis with uncertainty
Build a reproducible spatial analysis where data quality and spatial leakage are visible. Create maps with units, legends and uncertainty/coverage layers. Compare against an independent reference where available and document confounders such as clouds or sensor changes.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.
Recall: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. Identify one observation that would contradict your claim.

### Terms
Scientific uncertainty communication: Show coverage, error and assumptions alongside predictions. Distinguish model output from observed measurements and state where the model should not be used.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a reproducible spatial analysis where data quality and spatial leakage are visible. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create maps with units, legends and uncertainty/coverage layers. Compare against an independent reference where available and document confounders such as clouds or sensor changes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Build a reproducible spatial analysis where data quality and spatial leakage are visible.
Choose a licensed public raster dataset for a bounded region and two dates. Record CRS, resolution, units, nodata, source version and acquisition conditions.
Inspect rasters with QGIS or Rasterio, align CRS and resolution explicitly, and preserve nodata masks. Save the processing parameters and a small test region.
Compute a simple change baseline before fitting any model. Use spatial blocks and temporal separation for evaluation; do not randomly split neighboring pixels.
Create maps with units, legends and uncertainty/coverage layers. Compare against an independent reference where available and document confounders such as clouds or sensor changes.
Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.
Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change.
Repeat on another region or season to assess transfer rather than claiming global validity.
Deliverables: Geospatial processing pipeline and data manifest; Maps with uncertainty and coverage; Scientific methods/limitations report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.

### Interview
Explain your advanced solution for AI for materials, climate, energy & geospatial analysis. Use this scenario: Introduce a shifted CRS or nodata value interpreted as zero. Detect the misalignment and show the corrected result before interpreting apparent change.
Review: Start with the task and permitted scope. Explain scientific uncertainty communication: Show coverage, error and assumptions alongside predictions. Distinguish model output from observed measurements and state where the model should not be used. Show the input and observed output, then address Report valid coverage, spatially held-out error and sensitivity to preprocessing. A visually striking map is not proof of causal or physical change. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Geospatial processing pipeline and data manifest; Maps with uncertainty and coverage; Scientific methods/limitations report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Rasterio — Open source · native dependencies
Raster metadata, coordinate systems and spatial processing.
Alternative: GDAL (open source) or QGIS (open source) for raster workflows; coordinate systems and resampling choices still need care.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

QGIS — Open source · local
Inspect geospatial layers and produce documented maps.
Alternative: ArcGIS (commercial) or Python geospatial libraries; compare licensing, plugins and collaboration requirements.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Rasterio: https://rasterio.readthedocs.io/en/stable/quickstart.html
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
QGIS: https://docs.qgis.org/
Google Earth Engine tutorials: https://developers.google.com/earth-engine/tutorials/tutorials
scikit-learn: https://scikit-learn.org/stable/user_guide.html
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
