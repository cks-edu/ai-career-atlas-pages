## beginner — Spatial and temporal context

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Spatial and temporal context
Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps.
Mental model: Two maps cannot be overlaid correctly if their scales and origins differ.
Boundary: Resampling can change values and uncertainty, not just file shape.
Worked example: A temperature raster and a land-use raster require compatible coordinates and resolution before pixelwise analysis.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Spatial neighbors leak into evaluation
The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Three spatial splits overlap and undermine the claim of generalization to new regions. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Use geographically separated holdouts and document resolution, masks and time boundaries.
Recall: Compare physical or statistical baselines and report uncertainty in unseen regions. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Spatial and temporal context: Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
coordinate: A position described relative to a named frame or coordinate reference system.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A scientific prediction needs a defined place, time and measurement process. Physical constraints and data collection matter alongside model scores.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose the task of predicting tomorrow’s energy use for one fictional building, in kilowatt-hours.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A forecast brief with units, timing, baseline and data checks.

3. Try step 2
List data available today, the forecast period and a simple baseline such as the previous comparable day.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A forecast brief with units, timing, baseline and data checks.

4. Try step 3
Write checks for missing readings, changed opening hours and impossible negative consumption values.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A forecast brief with units, timing, baseline and data checks.

5. Explain and check your result
Future measured consumption is not an input to today’s forecast; the result is scoped to the stated building and conditions. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A forecast brief with units, timing, baseline and data checks. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The geospatial protocol requires no sampled tile overlap between training and evaluation regions. Apply this toy-case rule manually: Review when overlapping_tiles >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three spatial splits overlap and undermine the claim of generalization to new regions. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI for materials, climate, energy & geospatial analysis.
Choose the task of predicting tomorrow’s energy use for one fictional building, in kilowatt-hours.
List data available today, the forecast period and a simple baseline such as the previous comparable day.
Write checks for missing readings, changed opening hours and impossible negative consumption values.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A forecast brief with units, timing, baseline and data checks. Include beginner-worksheet.md and your completed Spatial-validation report and scientific assumptions table.
Check: Future measured consumption is not an input to today’s forecast; the result is scoped to the stated building and conditions.

### Interview
Explain your beginner solution for AI for materials, climate, energy & geospatial analysis. Use this scenario: The geospatial protocol requires no sampled tile overlap between training and evaluation regions.
Review: Start with the task and permitted scope. Explain spatial and temporal context: Record coordinate systems, time ranges, units and missing-data conventions. Align observations before fitting a model or comparing maps. Show the input and observed output, then address Use geographically separated holdouts and document resolution, masks and time boundaries. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A forecast brief with units, timing, baseline and data checks. Include beginner-worksheet.md and your completed Spatial-validation report and scientific assumptions table.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

