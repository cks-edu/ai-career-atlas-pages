# AI governance / responsible AI specialist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Accountable AI inventories: Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Accountable AI inventories

Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models. In this role, work through: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A vehicle register connects each vehicle to an owner and permitted purpose.

Boundary: An inventory is not a legal compliance determination.

Worked example: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI governance / responsible AI specialist: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions.

Predict the worked case

Read this case without running a tool: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in accountable ai inventories.

Connect the concept to the role

Apply this rule: Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An inventory is not a legal compliance determination.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies accountable ai inventories to this case: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Accountable AI inventories; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with accountable ai inventories. Use the glossary below, then write your prediction for: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI governance / responsible AI specialist role interview. Explain accountable ai inventories using this case: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate accountable ai inventories to a system or workflow you know. Explain accountable ai inventories using this case: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain accountable ai inventories using this case: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions.

Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models. — Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models. An inventory is not a legal compliance determination.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

Label Studio: https://labelstud.io/guide/

### Diagnose: The inventory says approved, evidence is missing

A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Three pilot records are marked ready despite missing required governance evidence. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Change their status to pending review, assign owners and request the missing artifacts. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A vehicle register connects each vehicle to an owner and permitted purpose.

A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions.

Worked example: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Change their status to pending review, assign owners and request the missing artifacts.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Three pilot records are marked ready despite missing required governance evidence. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Apply this toy-case rule manually: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Governance assigns responsibilities for how AI is used. Model errors and risks in the surrounding business process need separate attention.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use a fictional library assistant that suggests answers from approved rules, with a librarian reviewing before sending.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page AI inventory entry and a two-row risk record.

Preparation · Try step 2

Record purpose, users, input data, model output, reviewer and affected people.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page AI inventory entry and a two-row risk record.

Preparation · Try step 3

List one possible model mistake and one process failure, then assign an owner and a review action to each.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page AI inventory entry and a two-row risk record.

Preparation · Explain and check your result

Both invented policy and an omitted human review are considered; a named role owns each follow-up. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A one-page AI inventory entry and a two-row risk record. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Apply this toy-case rule manually: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three pilot records are marked ready despite missing required governance evidence. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three pilot records are marked ready despite missing required governance evidence. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the inventory says approved, evidence is missing. Use the glossary below, then write your prediction for: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Change their status to pending review, assign owners and request the missing artifacts. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI governance / responsible AI specialist role interview. Explain diagnose: the inventory says approved, evidence is missing using this case: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Change their status to pending review, assign owners and request the missing artifacts. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the inventory says approved, evidence is missing to a system or workflow you know. Explain diagnose: the inventory says approved, evidence is missing using this case: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Change their status to pending review, assign owners and request the missing artifacts. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Review the evidence register, approval history and the conditions for reopening a decision. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the inventory says approved, evidence is missing using this case: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Change their status to pending review, assign owners and request the missing artifacts. State the evidence, one alternative and where the mental model stops.

Quiz: The inventory says approved, evidence is missing: A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot.

Change the acceptance rule after seeing an inconvenient result.

Change their status to pending review, assign owners and request the missing artifacts.

Omit failed cases and report only the successful demonstrations.

Reference: Change their status to pending review, assign owners and request the missing artifacts. — Change their status to pending review, assign owners and request the missing artifacts. Review the evidence register, approval history and the conditions for reopening a decision.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

Label Studio: https://labelstud.io/guide/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Structured risk analysis, evidence handling and stakeholder coordination. Legal interpretations require qualified local expertise.

Terms:

Controls and evidence: Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Controls and evidence

Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process. In this role, work through: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A fire plan needs exits, responsible wardens and drill records.

Boundary: A signed document alone cannot show the control operated in practice.

Worked example: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Structured risk analysis, evidence handling and stakeholder coordination. Legal interpretations require qualified local expertise.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI governance / responsible AI specialist: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released.

Predict the worked case

Read this case without running a tool: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in controls and evidence.

Connect the concept to the role

Apply this rule: Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A signed document alone cannot show the control operated in practice.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies controls and evidence to this case: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Controls and evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with controls and evidence. Use the glossary below, then write your prediction for: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI governance / responsible AI specialist role interview. Explain controls and evidence using this case: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate controls and evidence to a system or workflow you know. Explain controls and evidence using this case: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain controls and evidence using this case: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released.

Treat a passing starter as proof of the whole role workflow.

Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process.

Ignore the failure because the tool produced an output.

Reference: Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process. — Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process. A signed document alone cannot show the control operated in practice.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

Label Studio: https://labelstud.io/guide/

### Integrate: AI inventory and pilot approval dossier

Build a reviewable governance process for a fictional organization adopting three AI systems. Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner. In this role, work through: Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A fire plan needs exits, responsible wardens and drill records.

A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released.

Worked example: Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Build a reviewable governance process for a fictional organization adopting three AI systems. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Build a reviewable governance process for a fictional organization adopting three AI systems.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

In Calc, create one sheet each for inventory, risks, controls, evidence and decisions. Give every risk and evidence item a stable ID; map the workflow using NIST Govern, Map, Measure and Manage as organizing concepts.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: AI inventory and risk/control workbook; Pilot assessment and decision minutes. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: ai inventory and pilot approval dossier. Use the glossary below, then write your prediction for: Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI governance / responsible AI specialist role interview. Explain integrate: ai inventory and pilot approval dossier using this case: Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: ai inventory and pilot approval dossier to a system or workflow you know. Explain integrate: ai inventory and pilot approval dossier using this case: Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. Identify one observation that would contradict your claim.

Interview: Explain integrate: ai inventory and pilot approval dossier using this case: Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI inventory and pilot approval dossier at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification.

Reference: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. — Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

Label Studio: https://labelstud.io/guide/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Lifecycle review triggers: Specify when changes, incidents or new uses reopen an assessment. Keep approval scope, expiry and escalation responsibilities explicit.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lifecycle review triggers

Specify when changes, incidents or new uses reopen an assessment. Keep approval scope, expiry and escalation responsibilities explicit. In this role, work through: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A vehicle needs another inspection after a major modification.

Boundary: Framework alignment does not replace qualified jurisdiction-specific advice.

Worked example: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI governance / responsible AI specialist: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval.

Predict the worked case

Read this case without running a tool: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in lifecycle review triggers.

Connect the concept to the role

Apply this rule: Specify when changes, incidents or new uses reopen an assessment. Keep approval scope, expiry and escalation responsibilities explicit. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Framework alignment does not replace qualified jurisdiction-specific advice.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies lifecycle review triggers to this case: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Lifecycle review triggers; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with lifecycle review triggers. Use the glossary below, then write your prediction for: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI governance / responsible AI specialist role interview. Explain lifecycle review triggers using this case: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate lifecycle review triggers to a system or workflow you know. Explain lifecycle review triggers using this case: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain lifecycle review triggers using this case: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Specify when changes, incidents or new uses reopen an assessment. Keep approval scope, expiry and escalation responsibilities explicit.

Reference: Specify when changes, incidents or new uses reopen an assessment. Keep approval scope, expiry and escalation responsibilities explicit. — Specify when changes, incidents or new uses reopen an assessment. Keep approval scope, expiry and escalation responsibilities explicit. Framework alignment does not replace qualified jurisdiction-specific advice.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

Label Studio: https://labelstud.io/guide/

### Defend: AI inventory and pilot approval dossier

Build a reviewable governance process for a fictional organization adopting three AI systems. Run a mock approval meeting using the provided agenda. Record approve-with-conditions, defer or reject decisions with reasons, due dates and conditions for reopening. In this role, work through: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A vehicle needs another inspection after a major modification.

A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval.

Worked example: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification); diagrams.net (Open source editor · browser/desktop)

Build a reviewable governance process for a fictional organization adopting three AI systems. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Build a reviewable governance process for a fictional organization adopting three AI systems.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

In Calc, create one sheet each for inventory, risks, controls, evidence and decisions. Give every risk and evidence item a stable ID; map the workflow using NIST Govern, Map, Measure and Manage as organizing concepts.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Run a mock approval meeting using the provided agenda. Record approve-with-conditions, defer or reject decisions with reasons, due dates and conditions for reopening.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. A reviewer must reproduce one result and identify which capabilities you implemented. A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: AI inventory and risk/control workbook; Pilot assessment and decision minutes; Change-review and incident escalation procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: ai inventory and pilot approval dossier. Use the glossary below, then write your prediction for: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI governance / responsible AI specialist role interview. Explain defend: ai inventory and pilot approval dossier using this case: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: ai inventory and pilot approval dossier to a system or workflow you know. Explain defend: ai inventory and pilot approval dossier using this case: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. Identify one observation that would contradict your claim.

Interview: Explain defend: ai inventory and pilot approval dossier using this case: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI inventory and pilot approval dossier at this level?

A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot. — A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot. Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

diagrams.net: https://www.drawio.com/docs/getting-started/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

Label Studio: https://labelstud.io/guide/
