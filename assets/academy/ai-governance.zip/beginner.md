## beginner — Accountable AI inventories

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Accountable AI inventories
Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models.
Mental model: A vehicle register connects each vehicle to an owner and permitted purpose.
Boundary: An inventory is not a legal compliance determination.
Worked example: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The inventory says approved, evidence is missing
A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Three pilot records are marked ready despite missing required governance evidence. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Change their status to pending review, assign owners and request the missing artifacts.
Recall: Review the evidence register, approval history and the conditions for reopening a decision. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Accountable AI inventories: Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Governance assigns responsibilities for how AI is used. Model errors and risks in the surrounding business process need separate attention.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional library assistant that suggests answers from approved rules, with a librarian reviewing before sending.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page AI inventory entry and a two-row risk record.

3. Try step 2
Record purpose, users, input data, model output, reviewer and affected people.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page AI inventory entry and a two-row risk record.

4. Try step 3
List one possible model mistake and one process failure, then assign an owner and a review action to each.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page AI inventory entry and a two-row risk record.

5. Explain and check your result
Both invented policy and an omitted human review are considered; a named role owns each follow-up. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A one-page AI inventory entry and a two-row risk record. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Apply this toy-case rule manually: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three pilot records are marked ready despite missing required governance evidence. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI governance / responsible AI specialist.
Use a fictional library assistant that suggests answers from approved rules, with a librarian reviewing before sending.
Record purpose, users, input data, model output, reviewer and affected people.
List one possible model mistake and one process failure, then assign an owner and a review action to each.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A one-page AI inventory entry and a two-row risk record. Include beginner-worksheet.md and your completed Governance assessment memo and risk register.
Check: Both invented policy and an omitted human review are considered; a named role owns each follow-up.

### Interview
Explain your beginner solution for AI governance / responsible AI specialist. Use this scenario: A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot.
Review: Start with the task and permitted scope. Explain accountable ai inventories: Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models. Show the input and observed output, then address Change their status to pending review, assign owners and request the missing artifacts. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A one-page AI inventory entry and a two-row risk record. Include beginner-worksheet.md and your completed Governance assessment memo and risk register.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

