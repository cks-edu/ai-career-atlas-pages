import csv,sys
rows=list(csv.DictReader(open('inventory.csv',newline='',encoding='utf-8')))
missing=[r['id'] for r in rows if not r['owner'] or not r['reviewer']]
assert missing==['attendance']
print('Missing accountability: attendance')
print('Human decision required: evidence completeness is not risk approval')
print('PASS governance '+(sys.argv[1] if len(sys.argv)>1 else 'beginner'))
