# Pilot approval meeting — 30-minute exercise

1. 5 min: confirm intended use, audience and scope changes.
2. 10 min: inspect evidence for each material risk; separate assertions from verified controls.
3. 5 min: challenge one missing artifact and one alternative.
4. 5 min: record approve-with-conditions, defer or reject with rationale and owner.
5. 5 min: set due dates, stop conditions and the next review.

Minutes: use-case ID; attendees or simulated roles; evidence inspected; dissent; decision; owner; due date; reopening trigger. A fictional role-play is not an actual organizational approval.
