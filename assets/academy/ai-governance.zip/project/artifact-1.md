# AI inventory and risk/control workbook

Project: AI inventory and pilot approval dossier
Status: blank work product — not completed evidence

## Purpose and audience
Build a reviewable governance process for a fictional organization adopting three AI systems.

## Required content
In Calc, create one sheet each for inventory, risks, controls, evidence and decisions. Give every risk and evidence item a stable ID; map the workflow using NIST Govern, Map, Measure and Manage as organizing concepts.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification.

## Failure evidence
A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
