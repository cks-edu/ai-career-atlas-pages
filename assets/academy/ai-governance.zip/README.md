# AI governance / responsible AI specialist

AI Engineering · Beginner → Intermediate → Advanced

Start with Accountable AI inventories. Governance assigns responsibilities for how AI is used. Model errors and risks in the surrounding business process need separate attention. Then try Make an AI use-case record. The three levels build toward AI inventory and pilot approval dossier. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Accountable AI inventories

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Accountable AI inventories
Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models.
Mental model: A vehicle register connects each vehicle to an owner and permitted purpose.
Boundary: An inventory is not a legal compliance determination.
Worked example: A meeting assistant has a named owner and retention plan; a hiring screener additionally needs review of its consequential decisions.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The inventory says approved, evidence is missing
A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Three pilot records are marked ready despite missing required governance evidence. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Change their status to pending review, assign owners and request the missing artifacts.
Recall: Review the evidence register, approval history and the conditions for reopening a decision. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Accountable AI inventories: Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Governance assigns responsibilities for how AI is used. Model errors and risks in the surrounding business process need separate attention.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional library assistant that suggests answers from approved rules, with a librarian reviewing before sending.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page AI inventory entry and a two-row risk record.

3. Try step 2
Record purpose, users, input data, model output, reviewer and affected people.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page AI inventory entry and a two-row risk record.

4. Try step 3
List one possible model mistake and one process failure, then assign an owner and a review action to each.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page AI inventory entry and a two-row risk record.

5. Explain and check your result
Both invented policy and an omitted human review are considered; a named role owns each follow-up. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A one-page AI inventory entry and a two-row risk record. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Apply this toy-case rule manually: Review when missing_controls >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three pilot records are marked ready despite missing required governance evidence. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI governance / responsible AI specialist.
Use a fictional library assistant that suggests answers from approved rules, with a librarian reviewing before sending.
Record purpose, users, input data, model output, reviewer and affected people.
List one possible model mistake and one process failure, then assign an owner and a review action to each.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A one-page AI inventory entry and a two-row risk record. Include beginner-worksheet.md and your completed Governance assessment memo and risk register.
Check: Both invented policy and an omitted human review are considered; a named role owns each follow-up.

### Interview
Explain your beginner solution for AI governance / responsible AI specialist. Use this scenario: A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot.
Review: Start with the task and permitted scope. Explain accountable ai inventories: Record each use case, purpose, data, owner and affected people. Begin with a decision someone is responsible for rather than a list of fashionable models. Show the input and observed output, then address Change their status to pending review, assign owners and request the missing artifacts. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A one-page AI inventory entry and a two-row risk record. Include beginner-worksheet.md and your completed Governance assessment memo and risk register.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Controls and evidence

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Structured risk analysis, evidence handling and stakeholder coordination. Legal interpretations require qualified local expertise.

### Controls and evidence
Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process.
Mental model: A fire plan needs exits, responsible wardens and drill records.
Boundary: A signed document alone cannot show the control operated in practice.
Worked example: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI inventory and pilot approval dossier
Build a reviewable governance process for a fictional organization adopting three AI systems. Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.
Recall: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. Identify one observation that would contradict your claim.

### Terms
Controls and evidence: Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a reviewable governance process for a fictional organization adopting three AI systems. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
In Calc, create one sheet each for inventory, risks, controls, evidence and decisions. Give every risk and evidence item a stable ID; map the workflow using NIST Govern, Map, Measure and Manage as organizing concepts.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a reviewable governance process for a fictional organization adopting three AI systems.
Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.
In Calc, create one sheet each for inventory, risks, controls, evidence and decisions. Give every risk and evidence item a stable ID; map the workflow using NIST Govern, Map, Measure and Manage as organizing concepts.
Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.
Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification.
Deliverables: AI inventory and risk/control workbook; Pilot assessment and decision minutes. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI governance / responsible AI specialist. Use this scenario: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.
Review: Start with the task and permitted scope. Explain controls and evidence: Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process. Show the input and observed output, then address Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [AI inventory and risk/control workbook; Pilot assessment and decision minutes. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Lifecycle review triggers

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Lifecycle review triggers
Specify when changes, incidents or new uses reopen an assessment. Keep approval scope, expiry and escalation responsibilities explicit.
Mental model: A vehicle needs another inspection after a major modification.
Boundary: Framework alignment does not replace qualified jurisdiction-specific advice.
Worked example: A summarizer becomes a recommendation tool for promotion decisions; reopen the assessment instead of reusing the old low-impact approval.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI inventory and pilot approval dossier
Build a reviewable governance process for a fictional organization adopting three AI systems. Run a mock approval meeting using the provided agenda. Record approve-with-conditions, defer or reject decisions with reasons, due dates and conditions for reopening.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.
Recall: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. Identify one observation that would contradict your claim.

### Terms
Lifecycle review triggers: Specify when changes, incidents or new uses reopen an assessment. Keep approval scope, expiry and escalation responsibilities explicit.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a reviewable governance process for a fictional organization adopting three AI systems. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
In Calc, create one sheet each for inventory, risks, controls, evidence and decisions. Give every risk and evidence item a stable ID; map the workflow using NIST Govern, Map, Measure and Manage as organizing concepts.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run a mock approval meeting using the provided agenda. Record approve-with-conditions, defer or reject decisions with reasons, due dates and conditions for reopening.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a reviewable governance process for a fictional organization adopting three AI systems.
Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.
In Calc, create one sheet each for inventory, risks, controls, evidence and decisions. Give every risk and evidence item a stable ID; map the workflow using NIST Govern, Map, Measure and Manage as organizing concepts.
Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.
Run a mock approval meeting using the provided agenda. Record approve-with-conditions, defer or reject decisions with reasons, due dates and conditions for reopening.
A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.
Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification.
Apply the process to one permitted real pilot and clearly separate actual evidence from the fictional demonstration.
Deliverables: AI inventory and risk/control workbook; Pilot assessment and decision minutes; Change-review and incident escalation procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. A reviewer must reproduce one result and identify which capabilities you implemented. A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.

### Interview
Explain your advanced solution for AI governance / responsible AI specialist. Use this scenario: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.
Review: Start with the task and permitted scope. Explain lifecycle review triggers: Specify when changes, incidents or new uses reopen an assessment. Keep approval scope, expiry and escalation responsibilities explicit. Show the input and observed output, then address Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [AI inventory and risk/control workbook; Pilot assessment and decision minutes; Change-review and incident escalation procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

NIST AI RMF — Public framework · not a certification
Organize governance questions and evidence; project recommendations are editorial.
Alternative: OECD AI Principles provide another public perspective; frameworks complement one another and are not automatic certifications.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

diagrams.net — Open source editor · browser/desktop
Architecture diagrams, process maps and trust boundaries.
Alternative: Mermaid (open source) for text diagrams or Microsoft Visio (commercial); choose an editable format teammates can use.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework
diagrams.net: https://www.drawio.com/docs/getting-started/
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics
Label Studio: https://labelstud.io/guide/
