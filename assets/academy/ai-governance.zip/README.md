# AI Governance Practitioner

AI Engineering

Begin with use-case inventory. Build an inventory with owner, data and affected people. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Build an inventory with owner, data and affected people

Setup: Open inventory.csv and decision-template.md in a spreadsheet/text editor. Python is optional: the checker demonstrates missing fields, while the core deliverable is a human review.

### Use-case inventory
Record what a system does, who owns it, whose data it uses and who is affected.
Mental model: A register of vehicles with owners, destinations and cargo.
Limit: An inventory is a starting point, not a legal compliance determination.
Example: A FAQ assistant and an attendance system have different data and impact.
Recall: Which missing field would prevent meaningful review?

### Apply use-case inventory in AI Governance Practitioner
Use the concept to complete this role exercise: Build an inventory with owner, data and affected people
Mental model: A register of vehicles with owners, destinations and cargo.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: A FAQ assistant and an attendance system have different data and impact. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Check completeness manually or with Python
Review every inventory row for owner, data and reviewer. The optional command checks this fixed fixture.
```
python3 review.py beginner
```
Expected: The attendance system is reported as missing accountable fields. A checker does not approve a system.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Build an inventory with owner, data and affected people
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: ai-governance-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Build an inventory with owner, data and affected people? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Record what a system does, who owns it, whose data it uses and who is affected. For this role, explicitly address: Build an inventory with owner, data and affected people.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Write a risk-control-evidence register for two use cases

Setup: Open inventory.csv and decision-template.md in a spreadsheet/text editor. Python is optional: the checker demonstrates missing fields, while the core deliverable is a human review.

### Risk and evidence
Describe a plausible harm, who experiences it, the control and the evidence that the control works.
Mental model: A fire plan links a hazard to exits, drills and named wardens.
Limit: A low score on an arbitrary matrix is not proof of safety.
Example: Personal attendance data without an accountable owner stays on hold.
Recall: What evidence would change a hold decision?

### Apply risk and evidence in AI Governance Practitioner
Use the concept to complete this role exercise: Write a risk-control-evidence register for two use cases
Mental model: A fire plan links a hazard to exits, drills and named wardens.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Personal attendance data without an accountable owner stays on hold. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Check completeness manually or with Python
Review every inventory row for owner, data and reviewer. The optional command checks this fixed fixture.
```
python3 review.py intermediate
```
Expected: The attendance system is reported as missing accountable fields. A checker does not approve a system.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Write a risk-control-evidence register for two use cases
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: ai-governance-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Write a risk-control-evidence register for two use cases? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Describe a plausible harm, who experiences it, the control and the evidence that the control works. For this role, explicitly address: Write a risk-control-evidence register for two use cases.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Prepare a review decision, monitoring owner and re-review triggers

Setup: Open inventory.csv and decision-template.md in a spreadsheet/text editor. Python is optional: the checker demonstrates missing fields, while the core deliverable is a human review.

### Accountable lifecycle
Assign approval, monitoring, escalation and retirement responsibilities throughout use.
Mental model: A relay race needs an explicit handover, not just a finish line.
Limit: A checklist cannot replace domain experts or jurisdiction-specific review.
Example: Specify who pauses the system if inappropriate data appears in its input.
Recall: How do you detect a material change that requires another review?

### Apply accountable lifecycle in AI Governance Practitioner
Use the concept to complete this role exercise: Prepare a review decision, monitoring owner and re-review triggers
Mental model: A relay race needs an explicit handover, not just a finish line.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Specify who pauses the system if inappropriate data appears in its input. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Check completeness manually or with Python
Review every inventory row for owner, data and reviewer. The optional command checks this fixed fixture.
```
python3 review.py advanced
```
Expected: The attendance system is reported as missing accountable fields. A checker does not approve a system.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Apply the role exercise
Prepare a review decision, monitoring owner and re-review triggers
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: ai-governance-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Prepare a review decision, monitoring owner and re-review triggers? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Assign approval, monitoring, escalation and retirement responsibilities throughout use. For this role, explicitly address: Prepare a review decision, monitoring owner and re-review triggers.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
NIST AI RMF Playbook: https://www.nist.gov/itl/ai-risk-management-framework/nist-ai-rmf-playbook
