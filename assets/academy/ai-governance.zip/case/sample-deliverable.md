# SAMPLE — Governance assessment memo and risk register
Role: AI governance / responsible AI specialist
Case: The inventory says approved, evidence is missing
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot.

## Evidence table
| Record | missing_controls (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three pilot records are marked ready despite missing required governance evidence.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Change their status to pending review, assign owners and request the missing artifacts.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai governance / responsible ai specialist.
Before release: Review the evidence register, approval history and the conditions for reopening a decision.

## Design choice and trade-off
Separate vendor assertions from verified controls; record accountable owners and conditional approvals.
A lightweight pilot process can be proportionate, but unresolved high-impact controls must remain visible.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
AI inventory and intake kit: Each use case has an accountable owner and review path.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
