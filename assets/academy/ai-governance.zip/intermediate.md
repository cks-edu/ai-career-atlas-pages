## intermediate — Controls and evidence

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Structured risk analysis, evidence handling and stakeholder coordination. Legal interpretations require qualified local expertise.

### Controls and evidence
Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process.
Mental model: A fire plan needs exits, responsible wardens and drill records.
Boundary: A signed document alone cannot show the control operated in practice.
Worked example: A policy says human review is required; inspect a sample approval record and test that unapproved outputs cannot be released.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI inventory and pilot approval dossier
Build a reviewable governance process for a fictional organization adopting three AI systems. Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.
Recall: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. Identify one observation that would contradict your claim.

### Terms
Controls and evidence: Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Build a reviewable governance process for a fictional organization adopting three AI systems. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
In Calc, create one sheet each for inventory, risks, controls, evidence and decisions. Give every risk and evidence item a stable ID; map the workflow using NIST Govern, Map, Measure and Manage as organizing concepts.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
A fictional organization requires an owner, a data-use review and an incident contact before approving an AI pilot. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Build a reviewable governance process for a fictional organization adopting three AI systems.
Create three use cases: internal summarization, customer support and employee training. Record purpose, owner, data classes, vendor, affected users and review status in the supplied register.
In Calc, create one sheet each for inventory, risks, controls, evidence and decisions. Give every risk and evidence item a stable ID; map the workflow using NIST Govern, Map, Measure and Manage as organizing concepts.
Write a two-page intake questionnaire and a review checklist proportionate to each use case. Distinguish vendor assertions, tested controls and missing evidence; assign an accountable owner.
Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification.
Deliverables: AI inventory and risk/control workbook; Pilot assessment and decision minutes. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI governance / responsible AI specialist. Use this scenario: A vendor changes retention terms and the business expands the assistant to a new audience. Reopen affected decisions, trace impacted controls and document who can stop the pilot.
Review: Start with the task and permitted scope. Explain controls and evidence: Connect a risk to an owner, control and evidence that the control works. Distinguish a proposed policy from a tested operating process. Show the input and observed output, then address Ask a peer to trace three decisions back to source evidence and ownership. Measure missing evidence, overdue controls and traceability; this is not legal certification. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [AI inventory and risk/control workbook; Pilot assessment and decision minutes. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

