# Use-case review
Purpose:
Affected people:
Evidence and missing information:
Accountable owner:
Decision: hold / bounded pilot / reject
Conditions and reviewer:
Monitoring and escalation:
Reopening trigger:
Limitations:
