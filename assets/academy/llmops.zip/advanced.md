## advanced — Operational LLM change control

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Operational LLM change control
Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success.
Mental model: A dimmer raises light gradually while someone watches for overload.
Boundary: A successful HTTP response may contain an unusable or misleading answer.
Worked example: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Versioned prompt release pipeline
Deliver a prompt-and-model release process that prevents silent quality regressions. Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Recall: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. Identify one observation that would contradict your claim.

### Terms
Operational LLM change control: Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Deliver a prompt-and-model release process that prevents silent quality regressions. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Deliver a prompt-and-model release process that prevents silent quality regressions.
Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.
Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair.
Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.
Add retrieval-index version to the release bundle and test a stale corpus independently of the model.
Deliverables: Prompt registry and release pipeline; Blinded evaluation sheet and comparison report; Canary and rollback playbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A reviewer must reproduce one result and identify which capabilities you implemented. Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.

### Interview
Explain your advanced solution for LLMOps / GenAIOps engineer. Use this scenario: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Review: Start with the task and permitted scope. Explain operational llm change control: Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success. Show the input and observed output, then address Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Prompt registry and release pipeline; Blinded evaluation sheet and comparison report; Canary and rollback playbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

