## beginner — Prompt and source versioning

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Prompt and source versioning
LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior.
Mental model: A theater performance depends on script, cast and stage directions together.
Boundary: Provider model names may not identify immutable weights; record available version metadata.
Worked example: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Prompt changes miss a language slice
The pilot permits at most two critical failures per ten reviewed multilingual tasks. Two language slices fail the declared gate; a pooled average hid the regression. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved.
Recall: Re-evaluate frozen and unseen cases, recording rubric and prompt versions. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Prompt and source versioning: LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A release needs examples of acceptable and unacceptable behavior. One average score can hide a serious failure.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional assistant that answers only these rules: “Library closes at 6 pm” and “Loans last 14 days.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A four-case test table with expected behavior and failure severity.

3. Try step 2
Create four cases: a closing-time question, a loan-duration question, an unknown printing-price question and a request to invent a rule.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A four-case test table with expected behavior and failure severity.

4. Try step 3
Write the acceptable response and a failure condition for each, keeping invented policy separate from minor wording differences.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A four-case test table with expected behavior and failure severity.

5. Explain and check your result
Unsupported questions require an uncertainty response; a fluent invented rule fails even if it sounds helpful. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A four-case test table with expected behavior and failure severity. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot permits at most two critical failures per ten reviewed multilingual tasks. Apply this toy-case rule manually: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two language slices fail the declared gate; a pooled average hid the regression. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to LLMOps / GenAIOps engineer.
Use a fictional assistant that answers only these rules: “Library closes at 6 pm” and “Loans last 14 days.”
Create four cases: a closing-time question, a loan-duration question, an unknown printing-price question and a request to invent a rule.
Write the acceptable response and a failure condition for each, keeping invented policy separate from minor wording differences.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A four-case test table with expected behavior and failure severity. Include beginner-worksheet.md and your completed Prompt release scorecard.
Check: Unsupported questions require an uncertainty response; a fluent invented rule fails even if it sounds helpful.

### Interview
Explain your beginner solution for LLMOps / GenAIOps engineer. Use this scenario: The pilot permits at most two critical failures per ten reviewed multilingual tasks.
Review: Start with the task and permitted scope. Explain prompt and source versioning: LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior. Show the input and observed output, then address Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A four-case test table with expected behavior and failure severity. Include beginner-worksheet.md and your completed Prompt release scorecard.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

