# LLMOps / GenAIOps engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Prompt and source versioning: LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Prompt and source versioning

LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior. In this role, work through: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A theater performance depends on script, cast and stage directions together.

Boundary: Provider model names may not identify immutable weights; record available version metadata.

Worked example: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for LLMOps / GenAIOps engineer: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases.

Predict the worked case

Read this case without running a tool: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in prompt and source versioning.

Connect the concept to the role

Apply this rule: LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Provider model names may not identify immutable weights; record available version metadata.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies prompt and source versioning to this case: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Prompt and source versioning; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with prompt and source versioning. Use the glossary below, then write your prediction for: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLMOps / GenAIOps engineer role interview. Explain prompt and source versioning using this case: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate prompt and source versioning to a system or workflow you know. Explain prompt and source versioning using this case: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain prompt and source versioning using this case: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases.

LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior. — LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior. Provider model names may not identify immutable weights; record available version metadata.

Sources:

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

OpenTelemetry: https://opentelemetry.io/docs/

### Diagnose: Prompt changes miss a language slice

The pilot permits at most two critical failures per ten reviewed multilingual tasks. Two language slices fail the declared gate; a pooled average hid the regression. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A theater performance depends on script, cast and stage directions together.

A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases.

Worked example: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The pilot permits at most two critical failures per ten reviewed multilingual tasks. Two language slices fail the declared gate; a pooled average hid the regression. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot permits at most two critical failures per ten reviewed multilingual tasks. Apply this toy-case rule manually: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A release needs examples of acceptable and unacceptable behavior. One average score can hide a serious failure.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use a fictional assistant that answers only these rules: “Library closes at 6 pm” and “Loans last 14 days.”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A four-case test table with expected behavior and failure severity.

Preparation · Try step 2

Create four cases: a closing-time question, a loan-duration question, an unknown printing-price question and a request to invent a rule.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A four-case test table with expected behavior and failure severity.

Preparation · Try step 3

Write the acceptable response and a failure condition for each, keeping invented policy separate from minor wording differences.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A four-case test table with expected behavior and failure severity.

Preparation · Explain and check your result

Unsupported questions require an uncertainty response; a fluent invented rule fails even if it sounds helpful. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A four-case test table with expected behavior and failure severity. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot permits at most two critical failures per ten reviewed multilingual tasks. Apply this toy-case rule manually: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two language slices fail the declared gate; a pooled average hid the regression. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two language slices fail the declared gate; a pooled average hid the regression. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: prompt changes miss a language slice. Use the glossary below, then write your prediction for: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLMOps / GenAIOps engineer role interview. Explain diagnose: prompt changes miss a language slice using this case: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: prompt changes miss a language slice to a system or workflow you know. Explain diagnose: prompt changes miss a language slice using this case: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Re-evaluate frozen and unseen cases, recording rubric and prompt versions. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: prompt changes miss a language slice using this case: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved. State the evidence, one alternative and where the mental model stops.

Quiz: Prompt changes miss a language slice: The pilot permits at most two critical failures per ten reviewed multilingual tasks.

Change the acceptance rule after seeing an inconvenient result.

Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved.

Omit failed cases and report only the successful demonstrations.

Reference: Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved. — Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved. Re-evaluate frozen and unseen cases, recording rubric and prompt versions.

Sources:

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

OpenTelemetry: https://opentelemetry.io/docs/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn Python, APIs, Git, tests and basic statistics for interpreting evaluation results. You do not need to train a foundation model. Senior work includes experiment design, stakeholder acceptance and release-risk decisions.

Terms:

Evaluation before rollout: Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Evaluation before rollout

Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate. In this role, work through: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A restaurant tests a new menu for taste, allergens and preparation time separately.

Boundary: Automated graders can be biased or wrong and need calibration.

Worked example: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn Python, APIs, Git, tests and basic statistics for interpreting evaluation results. You do not need to train a foundation model. Senior work includes experiment design, stakeholder acceptance and release-risk decisions.

Tools for this exercise: Document or text editor

Course tool and framework map: Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for LLMOps / GenAIOps engineer: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression.

Predict the worked case

Read this case without running a tool: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in evaluation before rollout.

Connect the concept to the role

Apply this rule: Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Automated graders can be biased or wrong and need calibration.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies evaluation before rollout to this case: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Evaluation before rollout; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with evaluation before rollout. Use the glossary below, then write your prediction for: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLMOps / GenAIOps engineer role interview. Explain evaluation before rollout using this case: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate evaluation before rollout to a system or workflow you know. Explain evaluation before rollout using this case: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain evaluation before rollout using this case: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression.

Treat a passing starter as proof of the whole role workflow.

Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate.

Ignore the failure because the tool produced an output.

Reference: Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate. — Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate. Automated graders can be biased or wrong and need calibration.

Sources:

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

OpenTelemetry: https://opentelemetry.io/docs/

### Integrate: Versioned prompt release pipeline

Deliver a prompt-and-model release process that prevents silent quality regressions. Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version. In this role, work through: Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A restaurant tests a new menu for taste, allergens and preparation time separately.

A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression.

Worked example: Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Deliver a prompt-and-model release process that prevents silent quality regressions. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Deliver a prompt-and-model release process that prevents silent quality regressions.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The pilot permits at most two critical failures per ten reviewed multilingual tasks. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-intermediate-2.md: Prompt registry and release pipeline; Blinded evaluation sheet and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: versioned prompt release pipeline. Use the glossary below, then write your prediction for: Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLMOps / GenAIOps engineer role interview. Explain integrate: versioned prompt release pipeline using this case: Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: versioned prompt release pipeline to a system or workflow you know. Explain integrate: versioned prompt release pipeline using this case: Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. Identify one observation that would contradict your claim.

Interview: Explain integrate: versioned prompt release pipeline using this case: Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Versioned prompt release pipeline at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.

Reference: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. — Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.

Sources:

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

OpenTelemetry: https://opentelemetry.io/docs/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Operational LLM change control: Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Operational LLM change control

Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success. In this role, work through: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A dimmer raises light gradually while someone watches for overload.

Boundary: A successful HTTP response may contain an unusable or misleading answer.

Worked example: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for LLMOps / GenAIOps engineer: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached.

Predict the worked case

Read this case without running a tool: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in operational llm change control.

Connect the concept to the role

Apply this rule: Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A successful HTTP response may contain an unusable or misleading answer.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies operational llm change control to this case: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Operational LLM change control; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with operational llm change control. Use the glossary below, then write your prediction for: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLMOps / GenAIOps engineer role interview. Explain operational llm change control using this case: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate operational llm change control to a system or workflow you know. Explain operational llm change control using this case: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain operational llm change control using this case: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success.

Reference: Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success. — Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success. A successful HTTP response may contain an unusable or misleading answer.

Sources:

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

OpenTelemetry: https://opentelemetry.io/docs/

### Defend: Versioned prompt release pipeline

Deliver a prompt-and-model release process that prevents silent quality regressions. Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair. In this role, work through: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A dimmer raises light gradually while someone watches for overload.

Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached.

Worked example: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Ollama (Open source runtime · model licenses vary); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Deliver a prompt-and-model release process that prevents silent quality regressions. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Deliver a prompt-and-model release process that prevents silent quality regressions.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A reviewer must reproduce one result and identify which capabilities you implemented. Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-advanced-2.md: Prompt registry and release pipeline; Blinded evaluation sheet and comparison report; Canary and rollback playbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: versioned prompt release pipeline. Use the glossary below, then write your prediction for: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLMOps / GenAIOps engineer role interview. Explain defend: versioned prompt release pipeline using this case: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: versioned prompt release pipeline to a system or workflow you know. Explain defend: versioned prompt release pipeline using this case: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. Identify one observation that would contradict your claim.

Interview: Explain defend: versioned prompt release pipeline using this case: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Versioned prompt release pipeline at this level?

Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint. — Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint. Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.

Sources:

Ollama: https://docs.ollama.com/api/generate

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

OpenTelemetry: https://opentelemetry.io/docs/
