# SAMPLE — Prompt release scorecard
Role: LLMOps / GenAIOps engineer
Case: Prompt changes miss a language slice
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The pilot permits at most two critical failures per ten reviewed multilingual tasks.

## Evidence table
| Record | critical_failures (out of ten) | Decision |
|---|---:|---|
| case-1 | 1 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 5 | review |
| case-5 | 0 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two language slices fail the declared gate; a pooled average hid the regression.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in llmops / genaiops engineer.
Before release: Re-evaluate frozen and unseen cases, recording rubric and prompt versions.

## Design choice and trade-off
Track prompt, retrieval and model versions together; inspect consequential slices independently.
Small slices produce noisy scores; require adequate review rather than silently dropping difficult languages.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Build an evaluation release gate: Preserve baseline and rejected-candidate reports. Explain each failure independently of the aggregate score. Version dataset, evaluator and candidate configuration together.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
