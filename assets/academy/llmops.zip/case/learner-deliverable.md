# WORKING DRAFT — Prompt release scorecard

Case: Prompt changes miss a language slice

## Decision and scope
[What is being decided? What is outside the lab?]

## Evidence
[Record IDs, values, units and expected treatment; do not hide contrary evidence.]

## Finding and alternative explanation
[Separate observation from hypothesis.]

## Proposed action and accountable owner
[Name a role, a bounded action and a review checkpoint.]

## Verification and reopening condition
[State positive, negative and boundary checks.]

## Trade-off and limitations
[Compare an alternative and state what is still untested.]
