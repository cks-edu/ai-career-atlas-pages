# Versioned prompt release pipeline

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Deliver a prompt-and-model release process that prevents silent quality regressions.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.

## Limitations and next iteration
Add retrieval-index version to the release bundle and test a stale corpus independently of the model.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
