# Canary and rollback playbook

Project: Versioned prompt release pipeline
Status: blank work product — not completed evidence

## Purpose and audience
Deliver a prompt-and-model release process that prevents silent quality regressions.

## Required content
Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.

## Failure evidence
Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
