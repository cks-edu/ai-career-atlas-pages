# Versioned prompt release pipeline

Career: LLMOps / GenAIOps engineer
Reviewed: 2026-10-22

Deliver a prompt-and-model release process that prevents silent quality regressions.

## Prerequisites
Learn Python, APIs, Git, tests and basic statistics for interpreting evaluation results. You do not need to train a foundation model. Senior work includes experiment design, stakeholder acceptance and release-risk decisions.

## Included starter versus your implementation
FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

## Portfolio deliverables
1. Prompt registry and release pipeline — artifact-1.md
2. Blinded evaluation sheet and comparison report — artifact-2.md
3. Canary and rollback playbook — artifact-3.md

## Troubleshooting
- Port occupied: select an unused local port and update client URLs.
- 422 response: inspect the request JSON and schema.
- Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.

## Extension
Add retrieval-index version to the release bundle and test a stale corpus independently of the model.

## Primary learning resources
- Ollama: https://docs.ollama.com/api/generate — Open source runtime · model licenses vary; Local generation; choose a model that fits memory and permitted use.
- MLflow: https://mlflow.org/docs/latest/ml/tracking/quickstart/ — Open source · hosted offerings optional; Record experiments, parameters and evaluation artifacts.
- GitHub Actions: https://docs.github.com/en/actions — Commercial hosted service · usage limits; CI checks and reviewable build artifacts; paid usage may apply.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
