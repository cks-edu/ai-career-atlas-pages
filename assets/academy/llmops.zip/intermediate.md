## intermediate — Evaluation before rollout

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn Python, APIs, Git, tests and basic statistics for interpreting evaluation results. You do not need to train a foundation model. Senior work includes experiment design, stakeholder acceptance and release-risk decisions.

### Evaluation before rollout
Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate.
Mental model: A restaurant tests a new menu for taste, allergens and preparation time separately.
Boundary: Automated graders can be biased or wrong and need calibration.
Worked example: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Versioned prompt release pipeline
Deliver a prompt-and-model release process that prevents silent quality regressions. Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Recall: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. Identify one observation that would contradict your claim.

### Terms
Evaluation before rollout: Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Deliver a prompt-and-model release process that prevents silent quality regressions. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The pilot permits at most two critical failures per ten reviewed multilingual tasks. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Deliver a prompt-and-model release process that prevents silent quality regressions.
Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.
Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.
Deliverables: Prompt registry and release pipeline; Blinded evaluation sheet and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for LLMOps / GenAIOps engineer. Use this scenario: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Review: Start with the task and permitted scope. Explain evaluation before rollout: Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate. Show the input and observed output, then address Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Prompt registry and release pipeline; Blinded evaluation sheet and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

