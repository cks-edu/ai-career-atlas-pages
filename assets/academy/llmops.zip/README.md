# LLMOps / GenAIOps engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Prompt and source versioning. A release needs examples of acceptable and unacceptable behavior. One average score can hide a serious failure. Then try Create a tiny answer test set. The three levels build toward Versioned prompt release pipeline. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Prompt and source versioning

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Prompt and source versioning
LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior.
Mental model: A theater performance depends on script, cast and stage directions together.
Boundary: Provider model names may not identify immutable weights; record available version metadata.
Worked example: A prompt is unchanged but the document collection is updated. Treat it as a new candidate and rerun relevant cases.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Prompt changes miss a language slice
The pilot permits at most two critical failures per ten reviewed multilingual tasks. Two language slices fail the declared gate; a pooled average hid the regression. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved.
Recall: Re-evaluate frozen and unseen cases, recording rubric and prompt versions. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Prompt and source versioning: LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A release needs examples of acceptable and unacceptable behavior. One average score can hide a serious failure.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional assistant that answers only these rules: “Library closes at 6 pm” and “Loans last 14 days.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A four-case test table with expected behavior and failure severity.

3. Try step 2
Create four cases: a closing-time question, a loan-duration question, an unknown printing-price question and a request to invent a rule.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A four-case test table with expected behavior and failure severity.

4. Try step 3
Write the acceptable response and a failure condition for each, keeping invented policy separate from minor wording differences.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A four-case test table with expected behavior and failure severity.

5. Explain and check your result
Unsupported questions require an uncertainty response; a fluent invented rule fails even if it sounds helpful. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A four-case test table with expected behavior and failure severity. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot permits at most two critical failures per ten reviewed multilingual tasks. Apply this toy-case rule manually: Review when critical_failures >= 3 (out of ten). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two language slices fail the declared gate; a pooled average hid the regression. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to LLMOps / GenAIOps engineer.
Use a fictional assistant that answers only these rules: “Library closes at 6 pm” and “Loans last 14 days.”
Create four cases: a closing-time question, a loan-duration question, an unknown printing-price question and a request to invent a rule.
Write the acceptable response and a failure condition for each, keeping invented policy separate from minor wording differences.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A four-case test table with expected behavior and failure severity. Include beginner-worksheet.md and your completed Prompt release scorecard.
Check: Unsupported questions require an uncertainty response; a fluent invented rule fails even if it sounds helpful.

### Interview
Explain your beginner solution for LLMOps / GenAIOps engineer. Use this scenario: The pilot permits at most two critical failures per ten reviewed multilingual tasks.
Review: Start with the task and permitted scope. Explain prompt and source versioning: LLM behavior depends on prompts, model identity, retrieval data and tool configuration. Version the complete change bundle so an evaluation can be connected to the deployed behavior. Show the input and observed output, then address Add slice-specific evaluation gates and hold the changed prompt until failed cases are resolved. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A four-case test table with expected behavior and failure severity. Include beginner-worksheet.md and your completed Prompt release scorecard.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Evaluation before rollout

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn Python, APIs, Git, tests and basic statistics for interpreting evaluation results. You do not need to train a foundation model. Senior work includes experiment design, stakeholder acceptance and release-risk decisions.

### Evaluation before rollout
Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate.
Mental model: A restaurant tests a new menu for taste, allergens and preparation time separately.
Boundary: Automated graders can be biased or wrong and need calibration.
Worked example: A prompt returns more valid JSON but invents policy details. Format improvement cannot cancel the grounding regression.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Versioned prompt release pipeline
Deliver a prompt-and-model release process that prevents silent quality regressions. Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Recall: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. Identify one observation that would contradict your claim.

### Terms
Evaluation before rollout: Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Deliver a prompt-and-model release process that prevents silent quality regressions. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The pilot permits at most two critical failures per ten reviewed multilingual tasks. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Deliver a prompt-and-model release process that prevents silent quality regressions.
Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.
Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.
Deliverables: Prompt registry and release pipeline; Blinded evaluation sheet and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for LLMOps / GenAIOps engineer. Use this scenario: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Review: Start with the task and permitted scope. Explain evaluation before rollout: Compare a candidate on normal, unsupported and adversarial inputs with the same grading rules. Separate factual support, format validity, latency and review rate. Show the input and observed output, then address Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Prompt registry and release pipeline; Blinded evaluation sheet and comparison report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Operational LLM change control

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Operational LLM change control
Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success.
Mental model: A dimmer raises light gradually while someone watches for overload.
Boundary: A successful HTTP response may contain an unusable or misleading answer.
Worked example: Route a small permitted test workload to a candidate, compare failures, and restore the prior prompt/source bundle if the guardrail is breached.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Versioned prompt release pipeline
Deliver a prompt-and-model release process that prevents silent quality regressions. Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Recall: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. Identify one observation that would contradict your claim.

### Terms
Operational LLM change control: Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Deliver a prompt-and-model release process that prevents silent quality regressions. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Deliver a prompt-and-model release process that prevents silent quality regressions.
Author 40 fictional summarization cases with critical facts, prohibited additions and long-input examples. Freeze a held-out subset and write the grading rubric before generation.
Use model_probe.py to record real local outputs from a chosen model. Store prompt text, model digest, decoding settings, case ID and generation error in each run record.
Implement a version comparison report with deterministic fact checks and blinded human review. Log runs and artifacts in MLflow; keep evaluator version distinct from candidate prompt version.
Create CI for schema checks and deterministic fixtures, plus a separately invoked live-model evaluation job. Define release approval, canary sample and rollback by prompt/model pair.
Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth.
Add retrieval-index version to the release bundle and test a stale corpus independently of the model.
Deliverables: Prompt registry and release pipeline; Blinded evaluation sheet and comparison report; Canary and rollback playbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A reviewer must reproduce one result and identify which capabilities you implemented. Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.

### Interview
Explain your advanced solution for LLMOps / GenAIOps engineer. Use this scenario: Change a prompt so it drops dates while producing fluent summaries. Demonstrate a blocked release and restoration of the prior version; also test an unreachable endpoint.
Review: Start with the task and permitted scope. Explain operational llm change control: Roll out changes in bounded stages, preserve trace identifiers and define fallback behavior. Monitor user outcomes as well as token consumption and transport success. Show the input and observed output, then address Report critical-fact retention, unsupported claims, review agreement, latency and failed calls. Do not call a judge model’s score ground truth. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Prompt registry and release pipeline; Blinded evaluation sheet and comparison report; Canary and rollback playbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Ollama — Open source runtime · model licenses vary
Local generation; choose a model that fits memory and permitted use.
Alternative: llama.cpp (open source) for local inference, or a commercial hosted API; model licenses and memory requirements remain separate.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

GitHub Actions — Commercial hosted service · usage limits
CI checks and reviewable build artifacts; paid usage may apply.
Alternative: GitLab CI (open-core/commercial offerings) or Jenkins (open source); runners and compute still need operating resources.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Ollama: https://docs.ollama.com/api/generate
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
GitHub Actions: https://docs.github.com/en/actions
MLflow: https://mlflow.org/docs/latest/
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
OpenTelemetry: https://opentelemetry.io/docs/
