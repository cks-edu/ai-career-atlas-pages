# Applied scientist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Testable research questions: Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

ablation: An experiment removing or changing a component to investigate its contribution.

### Testable research questions

Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help. In this role, work through: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A fair race needs a track, competitors and a finish line.

Boundary: A narrow result may not generalize outside the stated population.

Worked example: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Applied scientist: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better.

Predict the worked case

Read this case without running a tool: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in testable research questions.

Connect the concept to the role

Apply this rule: Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A narrow result may not generalize outside the stated population.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies testable research questions to this case: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Testable research questions; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with testable research questions. Use the glossary below, then write your prediction for: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Applied scientist role interview. Explain testable research questions using this case: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate testable research questions to a system or workflow you know. Explain testable research questions using this case: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain testable research questions using this case: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better.

Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help. — Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help. A narrow result may not generalize outside the stated population.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Google Research careers: https://research.google/careers/

### Diagnose: A gain smaller than run variability

The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Two experiments are too variable for the current single-run improvement claim. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A fair race needs a track, competitors and a finish line.

Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better.

Worked example: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Two experiments are too variable for the current single-run improvement claim. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Apply this toy-case rule manually: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A hypothesis must be specific enough that evidence could contradict it. Choose the comparison method and outcome before seeing results.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use this fictional complaint: “Our help search misses relevant articles.”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page experiment plan, with no fabricated results.

Preparation · Try step 2

Write a hypothesis comparing keyword search with a proposed new method on the same 20 labeled questions.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page experiment plan, with no fabricated results.

Preparation · Try step 3

Define relevance, a primary metric and what result would count against the hypothesis.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page experiment plan, with no fabricated results.

Preparation · Explain and check your result

Both methods use the same held-out questions; the plan specifies an outcome that could disprove the proposed improvement. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A one-page experiment plan, with no fabricated results. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Apply this toy-case rule manually: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two experiments are too variable for the current single-run improvement claim. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two experiments are too variable for the current single-run improvement claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a gain smaller than run variability. Use the glossary below, then write your prediction for: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Applied scientist role interview. Explain diagnose: a gain smaller than run variability using this case: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a gain smaller than run variability to a system or workflow you know. Explain diagnose: a gain smaller than run variability using this case: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Use matched budgets and untouched evaluation data; include all planned runs. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a gain smaller than run variability using this case: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain. State the evidence, one alternative and where the mental model stops.

Quiz: A gain smaller than run variability: The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis.

Change the acceptance rule after seeing an inconvenient result.

Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain.

Omit failed cases and report only the successful demonstrations.

Reference: Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain. — Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain. Use matched budgets and untouched evaluation data; include all planned runs.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Google Research careers: https://research.google/careers/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Advanced statistics and experimental design; some employers require postgraduate training or equivalent research evidence.

Terms:

Controlled comparisons: Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

ablation: An experiment removing or changing a component to investigate its contribution.

### Controlled comparisons

Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result. In this role, work through: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Compare recipes with the same oven and ingredients except the one change under study.

Boundary: Repeated tuning against one test set turns it into development data.

Worked example: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Advanced statistics and experimental design; some employers require postgraduate training or equivalent research evidence.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Applied scientist: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results.

Predict the worked case

Read this case without running a tool: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in controlled comparisons.

Connect the concept to the role

Apply this rule: Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Repeated tuning against one test set turns it into development data.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies controlled comparisons to this case: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Controlled comparisons; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with controlled comparisons. Use the glossary below, then write your prediction for: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Applied scientist role interview. Explain controlled comparisons using this case: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate controlled comparisons to a system or workflow you know. Explain controlled comparisons using this case: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain controlled comparisons using this case: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results.

Treat a passing starter as proof of the whole role workflow.

Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result.

Ignore the failure because the tool produced an output.

Reference: Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result. — Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result. Repeated tuning against one test set turns it into development data.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Google Research careers: https://research.google/careers/

### Integrate: Hypothesis-driven model improvement study

Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair. In this role, work through: Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: Compare recipes with the same oven and ingredients except the one change under study.

Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results.

Worked example: Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-intermediate-2.md: Experiment notebook and run manifest; Ablation table and uncertainty analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: hypothesis-driven model improvement study. Use the glossary below, then write your prediction for: Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Applied scientist role interview. Explain integrate: hypothesis-driven model improvement study using this case: Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: hypothesis-driven model improvement study to a system or workflow you know. Explain integrate: hypothesis-driven model improvement study using this case: Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. Identify one observation that would contradict your claim.

Interview: Explain integrate: hypothesis-driven model improvement study using this case: Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Hypothesis-driven model improvement study at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.

Reference: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. — Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Google Research careers: https://research.google/careers/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Ablation and limitations: Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

ablation: An experiment removing or changing a component to investigate its contribution.

### Ablation and limitations

Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists. In this role, work through: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Remove one ingredient to see whether it changes the dish.

Boundary: Ablations can interact; one component may matter only in combination with another.

Worked example: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Applied scientist: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload.

Predict the worked case

Read this case without running a tool: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in ablation and limitations.

Connect the concept to the role

Apply this rule: Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Ablations can interact; one component may matter only in combination with another.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies ablation and limitations to this case: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Ablation and limitations; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with ablation and limitations. Use the glossary below, then write your prediction for: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Applied scientist role interview. Explain ablation and limitations using this case: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate ablation and limitations to a system or workflow you know. Explain ablation and limitations using this case: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain ablation and limitations using this case: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists.

Reference: Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists. — Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists. Ablations can interact; one component may matter only in combination with another.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Google Research careers: https://research.google/careers/

### Defend: Hypothesis-driven model improvement study

Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. Inspect errors by predeclared slices and distinguish exploratory findings from confirmatory results. Write a recommendation that includes complexity and operational cost. In this role, work through: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: Remove one ingredient to see whether it changes the dish.

If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload.

Worked example: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional)

Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Inspect errors by predeclared slices and distinguish exploratory findings from confirmatory results. Write a recommendation that includes complexity and operational cost.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A reviewer must reproduce one result and identify which capabilities you implemented. Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-advanced-2.md: Experiment notebook and run manifest; Ablation table and uncertainty analysis; Scientific decision memo with negative results. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: hypothesis-driven model improvement study. Use the glossary below, then write your prediction for: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Applied scientist role interview. Explain defend: hypothesis-driven model improvement study using this case: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: hypothesis-driven model improvement study to a system or workflow you know. Explain defend: hypothesis-driven model improvement study using this case: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. Identify one observation that would contradict your claim.

Interview: Explain defend: hypothesis-driven model improvement study using this case: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Hypothesis-driven model improvement study at this level?

Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference. — Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference. Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

scikit-learn: https://scikit-learn.org/stable/user_guide.html

Google Research careers: https://research.google/careers/
