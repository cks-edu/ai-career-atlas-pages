# SAMPLE — Ablation table and scientific limitations note
Role: Applied scientist
Case: A gain smaller than run variability
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis.

## Evidence table
| Record | seed_spread (percentage points) | Decision |
|---|---:|---|
| case-1 | 1 | within_demo_bound |
| case-2 | 3 | within_demo_bound |
| case-3 | 4 | review |
| case-4 | 7 | review |
| case-5 | 2 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two experiments are too variable for the current single-run improvement claim.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in applied scientist.
Before release: Use matched budgets and untouched evaluation data; include all planned runs.

## Design choice and trade-off
Predeclare the baseline and primary metric; preserve negative and inconclusive experiments.
Repeated runs consume compute but distinguish robust improvements from favorable random seeds.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Ranking-method ablation: Report variation and failure cases, not only the best run.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
