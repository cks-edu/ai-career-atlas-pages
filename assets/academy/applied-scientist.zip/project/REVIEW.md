# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Experiment notebook and run manifest.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
