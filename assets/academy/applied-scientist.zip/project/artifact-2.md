# Ablation table and uncertainty analysis

Project: Hypothesis-driven model improvement study
Status: blank work product — not completed evidence

## Purpose and audience
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report.

## Required content
Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.

## Failure evidence
Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
