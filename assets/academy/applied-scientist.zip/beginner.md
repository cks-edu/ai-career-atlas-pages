## beginner — Testable research questions

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Testable research questions
Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help.
Mental model: A fair race needs a track, competitors and a finish line.
Boundary: A narrow result may not generalize outside the stated population.
Worked example: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A gain smaller than run variability
The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Two experiments are too variable for the current single-run improvement claim. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain.
Recall: Use matched budgets and untouched evaluation data; include all planned runs. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Testable research questions: Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
ablation: An experiment removing or changing a component to investigate its contribution.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A hypothesis must be specific enough that evidence could contradict it. Choose the comparison method and outcome before seeing results.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use this fictional complaint: “Our help search misses relevant articles.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page experiment plan, with no fabricated results.

3. Try step 2
Write a hypothesis comparing keyword search with a proposed new method on the same 20 labeled questions.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page experiment plan, with no fabricated results.

4. Try step 3
Define relevance, a primary metric and what result would count against the hypothesis.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page experiment plan, with no fabricated results.

5. Explain and check your result
Both methods use the same held-out questions; the plan specifies an outcome that could disprove the proposed improvement. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A one-page experiment plan, with no fabricated results. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Apply this toy-case rule manually: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two experiments are too variable for the current single-run improvement claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Applied scientist.
Use this fictional complaint: “Our help search misses relevant articles.”
Write a hypothesis comparing keyword search with a proposed new method on the same 20 labeled questions.
Define relevance, a primary metric and what result would count against the hypothesis.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A one-page experiment plan, with no fabricated results. Include beginner-worksheet.md and your completed Ablation table and scientific limitations note.
Check: Both methods use the same held-out questions; the plan specifies an outcome that could disprove the proposed improvement.

### Interview
Explain your beginner solution for Applied scientist. Use this scenario: The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis.
Review: Start with the task and permitted scope. Explain testable research questions: Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help. Show the input and observed output, then address Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A one-page experiment plan, with no fabricated results. Include beginner-worksheet.md and your completed Ablation table and scientific limitations note.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

