## intermediate — Controlled comparisons

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Advanced statistics and experimental design; some employers require postgraduate training or equivalent research evidence.

### Controlled comparisons
Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result.
Mental model: Compare recipes with the same oven and ingredients except the one change under study.
Boundary: Repeated tuning against one test set turns it into development data.
Worked example: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Hypothesis-driven model improvement study
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Recall: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. Identify one observation that would contradict your claim.

### Terms
Controlled comparisons: Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ablation: An experiment removing or changing a component to investigate its contribution.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report.
Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.
Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.
Deliverables: Experiment notebook and run manifest; Ablation table and uncertainty analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Applied scientist. Use this scenario: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Review: Start with the task and permitted scope. Explain controlled comparisons: Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result. Show the input and observed output, then address Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Experiment notebook and run manifest; Ablation table and uncertainty analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

