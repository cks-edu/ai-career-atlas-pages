## advanced — Ablation and limitations

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Ablation and limitations
Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists.
Mental model: Remove one ingredient to see whether it changes the dish.
Boundary: Ablations can interact; one component may matter only in combination with another.
Worked example: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Hypothesis-driven model improvement study
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. Inspect errors by predeclared slices and distinguish exploratory findings from confirmatory results. Write a recommendation that includes complexity and operational cost.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Recall: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. Identify one observation that would contradict your claim.

### Terms
Ablation and limitations: Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ablation: An experiment removing or changing a component to investigate its contribution.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Inspect errors by predeclared slices and distinguish exploratory findings from confirmatory results. Write a recommendation that includes complexity and operational cost.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report.
Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.
Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Inspect errors by predeclared slices and distinguish exploratory findings from confirmatory results. Write a recommendation that includes complexity and operational cost.
Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.
Replicate the conclusion on a second dataset before claiming generality.
Deliverables: Experiment notebook and run manifest; Ablation table and uncertainty analysis; Scientific decision memo with negative results. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A reviewer must reproduce one result and identify which capabilities you implemented. Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.

### Interview
Explain your advanced solution for Applied scientist. Use this scenario: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Review: Start with the task and permitted scope. Explain ablation and limitations: Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists. Show the input and observed output, then address Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Experiment notebook and run manifest; Ablation table and uncertainty analysis; Scientific decision memo with negative results. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

