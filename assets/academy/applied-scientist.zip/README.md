# Applied scientist

AI Engineering · Beginner → Intermediate → Advanced

Start with Testable research questions. A hypothesis must be specific enough that evidence could contradict it. Choose the comparison method and outcome before seeing results. Then try Turn a complaint into an experiment. The three levels build toward Hypothesis-driven model improvement study. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Testable research questions

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Testable research questions
Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help.
Mental model: A fair race needs a track, competitors and a finish line.
Boundary: A narrow result may not generalize outside the stated population.
Worked example: Ask whether adding a retrieval feature improves a fixed ranking metric on a held-out query set, rather than whether AI is better.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A gain smaller than run variability
The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Two experiments are too variable for the current single-run improvement claim. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain.
Recall: Use matched budgets and untouched evaluation data; include all planned runs. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Testable research questions: Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
ablation: An experiment removing or changing a component to investigate its contribution.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A hypothesis must be specific enough that evidence could contradict it. Choose the comparison method and outcome before seeing results.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use this fictional complaint: “Our help search misses relevant articles.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page experiment plan, with no fabricated results.

3. Try step 2
Write a hypothesis comparing keyword search with a proposed new method on the same 20 labeled questions.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page experiment plan, with no fabricated results.

4. Try step 3
Define relevance, a primary metric and what result would count against the hypothesis.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page experiment plan, with no fabricated results.

5. Explain and check your result
Both methods use the same held-out questions; the plan specifies an outcome that could disprove the proposed improvement. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A one-page experiment plan, with no fabricated results. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Apply this toy-case rule manually: Review when seed_spread > 3 (percentage points). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two experiments are too variable for the current single-run improvement claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Applied scientist.
Use this fictional complaint: “Our help search misses relevant articles.”
Write a hypothesis comparing keyword search with a proposed new method on the same 20 labeled questions.
Define relevance, a primary metric and what result would count against the hypothesis.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A one-page experiment plan, with no fabricated results. Include beginner-worksheet.md and your completed Ablation table and scientific limitations note.
Check: Both methods use the same held-out questions; the plan specifies an outcome that could disprove the proposed improvement.

### Interview
Explain your beginner solution for Applied scientist. Use this scenario: The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis.
Review: Start with the task and permitted scope. Explain testable research questions: Turn a broad goal into a hypothesis with measurable outcomes and a baseline. Specify the population and conditions under which the proposed method should help. Show the input and observed output, then address Repeat controlled seeds and report uncertainty and effect sizes before claiming a gain. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A one-page experiment plan, with no fabricated results. Include beginner-worksheet.md and your completed Ablation table and scientific limitations note.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Controlled comparisons

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Advanced statistics and experimental design; some employers require postgraduate training or equivalent research evidence.

### Controlled comparisons
Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result.
Mental model: Compare recipes with the same oven and ingredients except the one change under study.
Boundary: Repeated tuning against one test set turns it into development data.
Worked example: Use the same split and scoring code for baseline and candidate, then repeat across declared seeds and report all results.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Hypothesis-driven model improvement study
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Recall: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. Identify one observation that would contradict your claim.

### Terms
Controlled comparisons: Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ablation: An experiment removing or changing a component to investigate its contribution.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The predeclared study gate flags run-to-run accuracy spreads above three percentage points for further analysis. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report.
Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.
Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.
Deliverables: Experiment notebook and run manifest; Ablation table and uncertainty analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Applied scientist. Use this scenario: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Review: Start with the task and permitted scope. Explain controlled comparisons: Change one meaningful factor at a time when possible, repeat trials and inspect variability. Keep evaluation choices independent of the final held-out result. Show the input and observed output, then address Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Experiment notebook and run manifest; Ablation table and uncertainty analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Ablation and limitations

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Ablation and limitations
Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists.
Mental model: Remove one ingredient to see whether it changes the dish.
Boundary: Ablations can interact; one component may matter only in combination with another.
Worked example: If removing reranking leaves quality unchanged, inspect whether the reranker adds latency without benefit on this workload.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Hypothesis-driven model improvement study
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. Inspect errors by predeclared slices and distinguish exploratory findings from confirmatory results. Write a recommendation that includes complexity and operational cost.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Recall: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. Identify one observation that would contradict your claim.

### Terms
Ablation and limitations: Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ablation: An experiment removing or changing a component to investigate its contribution.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Inspect errors by predeclared slices and distinguish exploratory findings from confirmatory results. Write a recommendation that includes complexity and operational cost.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Test a specific modeling hypothesis with controlled baselines and a decision-ready experiment report.
Choose one public tabular dataset and define the hypothesis before exploration, such as whether nonlinear interactions improve a fixed task. Preserve an untouched test split.
Run the included baseline and add a second model with a bounded tuning budget. Use identical data partitions and preprocessing rules.
Run three seeds and ablate one feature group at a time. Log parameters, split IDs and wall time so comparisons are fair.
Inspect errors by predeclared slices and distinguish exploratory findings from confirmatory results. Write a recommendation that includes complexity and operational cost.
Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result.
Replicate the conclusion on a second dataset before claiming generality.
Deliverables: Experiment notebook and run manifest; Ablation table and uncertainty analysis; Scientific decision memo with negative results. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A reviewer must reproduce one result and identify which capabilities you implemented. Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.

### Interview
Explain your advanced solution for Applied scientist. Use this scenario: Deliberately evaluate a model on a contaminated split, then rebuild with grouping or time separation and explain the difference.
Review: Start with the task and permitted scope. Explain ablation and limitations: Remove a component to investigate whether it contributes to the result. Distinguish evidence supporting an explanation from proof that no alternative explanation exists. Show the input and observed output, then address Report paired outcome differences, uncertainty and failure slices. A better mean without uncertainty and a clean split is not a strong result. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Experiment notebook and run manifest; Ablation table and uncertainty analysis; Scientific decision memo with negative results. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
scikit-learn: https://scikit-learn.org/stable/user_guide.html
Google Research careers: https://research.google/careers/
