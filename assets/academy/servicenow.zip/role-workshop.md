# ServiceNow Developer / Administrator — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Records, tables and assignment

A service workflow needs a defined table, state and ownership. Distinguish requester-visible fields from internal operational notes before building forms.
Mental model: A service desk keeps a public receipt and an internal work ticket.
Case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy.
Task: Complete the workbook data dictionary, then use a developer instance if available to model a synthetic request. Define states and mandatory closure evidence; test a blank resolution.
Acceptance: A rejected invalid closure and a valid assigned request.
Troubleshooting: Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable.
Deliverable: table dictionary and state tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Server rules and access controls

Client form rules improve interaction while server rules and access controls protect other entry points. Test the same policy through more than one permitted interface.
Mental model: A sign on the door helps visitors; the lock enforces entry.
Case: Hiding an internal note on a form must not expose it through an API to the requester.
Task: Create a role/field matrix and test requester versus fulfiller access in a lab instance. Compare form behavior and authorized API access, using synthetic records only.
Acceptance: Both interfaces enforce the intended access; observations are recorded separately.
Troubleshooting: UI-only restrictions do not establish server security.
Deliverable: ACL matrix and interface test evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Update promotion and workflow recovery

Configuration promotion needs dependencies, conflict review and a plan for records already in flight. Reverting a rule does not undo approvals or notifications already sent.
Mental model: Replacing the route map does not bring back parcels already delivered.
Case: An approval workflow changed mid-request needs a documented treatment of existing requests.
Task: Prepare a lab update package using the instance's supported mechanism, list dependencies and rehearse import/retest in a second environment if available. Write a recovery plan for in-flight records.
Acceptance: A manifest and evidence-based release decision with pending environment checks labeled.
Troubleshooting: Never promote unrelated captured changes simply because they are in the same package.
Deliverable: ServiceNow release workbook and in-flight case analysis

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
