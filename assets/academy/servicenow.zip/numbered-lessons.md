# ServiceNow Developer / Administrator — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Acceptance criteria: Describe an observable result that determines whether a requirement has been met.

Apply acceptance criteria in ServiceNow Developer / Administrator: Use the concept to complete this role exercise: Model an incident table, states and field-level permissions

Records, tables and assignment: A service workflow needs a defined table, state and ownership. Distinguish requester-visible fields from internal operational notes before building forms.

### Acceptance criteria

Describe an observable result that determines whether a requirement has been met. In this role, work through: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. The practical workshop develops this into: Complete the workbook data dictionary, then use a developer instance if available to model a synthetic request. Define states and mandatory closure evidence; test a blank resolution.

Mental model: A delivery receipt lists what must arrive, not just that a truck drove.

Boundary: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Role application: A service desk keeps a public receipt and an internal work ticket.

A service workflow needs a defined table, state and ownership. Distinguish requester-visible fields from internal operational notes before building forms.

Worked example: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy.

Shared foundation example: Given an empty title, submitting a request shows an error and creates no ticket.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: ServiceNow tables, Flow Designer and access controls (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for ServiceNow Developer / Administrator: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy.

Predict the worked case

Read this case without running a tool: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in acceptance criteria.

Connect the concept to the role

Apply this rule: Describe an observable result that determines whether a requirement has been met. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies acceptance criteria to this case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Acceptance criteria; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with acceptance criteria. Use the glossary below, then write your prediction for: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ServiceNow Developer / Administrator role interview. Explain acceptance criteria using this case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate acceptance criteria to a system or workflow you know. Explain acceptance criteria using this case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Turn “make it easier” into a measurable task outcome.

Interview: Explain acceptance criteria using this case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. State the evidence, one alternative and where the mental model stops.

Quiz: After the Records, tables and assignment rehearsal, check this foundation: A requirement says “make this workflow easier.” What makes its acceptance testable?

A defined user task and observable result, reviewed with the relevant stakeholder.

A count of implementation files without a user outcome.

A statement that the chosen tool is widely used.

Reference: A defined user task and observable result, reviewed with the relevant stakeholder. — Acceptance criteria describe observable outcomes. Stakeholder review is still needed to ensure the outcome solves the right problem.

Sources:

ServiceNow developer learning: https://developer.servicenow.com/dev.do

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Records, tables and assignment

A service workflow needs a defined table, state and ownership. Distinguish requester-visible fields from internal operational notes before building forms. In this role, work through: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. The practical workshop develops this into: Complete the workbook data dictionary, then use a developer instance if available to model a synthetic request. Define states and mandatory closure evidence; test a blank resolution.

Mental model: A service desk keeps a public receipt and an internal work ticket.

Boundary: Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable.

Worked example: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: ServiceNow tables, Flow Designer and access controls (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required ServiceNow Developer / Administrator workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Complete the workbook data dictionary, then use a developer instance if available to model a synthetic request. Define states and mandatory closure evidence; test a blank resolution.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Complete the workbook data dictionary, then use a developer instance if available to model a synthetic request. Define states and mandatory closure evidence; test a blank resolution.

Expected: A rejected invalid closure and a valid assigned request.

Role workshop · debug and verify

Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save table dictionary and state tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A rejected invalid closure and a valid assigned request.

Expected: A rejected invalid closure and a valid assigned request.

Troubleshoot: The role exercise differs from the prediction: Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: table dictionary and state tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with records, tables and assignment. Use the glossary below, then write your prediction for: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ServiceNow Developer / Administrator role interview. Explain records, tables and assignment using this case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate records, tables and assignment to a system or workflow you know. Explain records, tables and assignment using this case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable.

Interview: Explain records, tables and assignment using this case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy.

A rejected invalid closure and a valid assigned request.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A rejected invalid closure and a valid assigned request. — A service workflow needs a defined table, state and ownership. Distinguish requester-visible fields from internal operational notes before building forms. A rejected invalid closure and a valid assigned request.

Sources:

ServiceNow developer learning: https://developer.servicenow.com/dev.do

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Traceability: Connect a user need to the proposed change, its test and its evidence.

Apply traceability in ServiceNow Developer / Administrator: Use the concept to complete this role exercise: Define a flow with validation, notifications and acceptance cases

Server rules and access controls: Client form rules improve interaction while server rules and access controls protect other entry points. Test the same policy through more than one permitted interface.

### Traceability

Connect a user need to the proposed change, its test and its evidence. In this role, work through: Hiding an internal note on a form must not expose it through an API to the requester. The practical workshop develops this into: Create a role/field matrix and test requester versus fulfiller access in a lab instance. Compare form behavior and authorized API access, using synthetic records only.

Mental model: Labels connect a parcel to its order and delivery receipt.

Boundary: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Role application: A sign on the door helps visitors; the lock enforces entry.

Client form rules improve interaction while server rules and access controls protect other entry points. Test the same policy through more than one permitted interface.

Worked example: Hiding an internal note on a form must not expose it through an API to the requester.

Shared foundation example: Need R1 points to screen S1, test T1 and a recorded observation.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: ServiceNow tables, Flow Designer and access controls (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for ServiceNow Developer / Administrator: Hiding an internal note on a form must not expose it through an API to the requester.

Predict the worked case

Read this case without running a tool: Hiding an internal note on a form must not expose it through an API to the requester. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in traceability.

Connect the concept to the role

Apply this rule: Connect a user need to the proposed change, its test and its evidence. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies traceability to this case: Hiding an internal note on a form must not expose it through an API to the requester. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Hiding an internal note on a form must not expose it through an API to the requester. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Traceability; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with traceability. Use the glossary below, then write your prediction for: Hiding an internal note on a form must not expose it through an API to the requester. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ServiceNow Developer / Administrator role interview. Explain traceability using this case: Hiding an internal note on a form must not expose it through an API to the requester. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate traceability to a system or workflow you know. Explain traceability using this case: Hiding an internal note on a form must not expose it through an API to the requester. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you identify which tests are affected by a changed requirement?

Interview: Explain traceability using this case: Hiding an internal note on a form must not expose it through an API to the requester. State the evidence, one alternative and where the mental model stops.

Quiz: After the Server rules and access controls rehearsal, check this foundation: A requirement changes. What evidence helps identify affected checks?

The total number of screenshots in the project.

Links from the requirement to its design, test cases and recorded results.

Only the latest file modification time.

Reference: Links from the requirement to its design, test cases and recorded results. — Traceability connects a need to the change and its verification; documents without those links do not establish impact.

Sources:

ServiceNow developer learning: https://developer.servicenow.com/dev.do

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Server rules and access controls

Client form rules improve interaction while server rules and access controls protect other entry points. Test the same policy through more than one permitted interface. In this role, work through: Hiding an internal note on a form must not expose it through an API to the requester. The practical workshop develops this into: Create a role/field matrix and test requester versus fulfiller access in a lab instance. Compare form behavior and authorized API access, using synthetic records only.

Mental model: A sign on the door helps visitors; the lock enforces entry.

Boundary: UI-only restrictions do not establish server security.

Worked example: Hiding an internal note on a form must not expose it through an API to the requester.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: ServiceNow tables, Flow Designer and access controls (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required ServiceNow Developer / Administrator workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a role/field matrix and test requester versus fulfiller access in a lab instance. Compare form behavior and authorized API access, using synthetic records only.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

Hiding an internal note on a form must not expose it through an API to the requester. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a role/field matrix and test requester versus fulfiller access in a lab instance. Compare form behavior and authorized API access, using synthetic records only.

Expected: Both interfaces enforce the intended access; observations are recorded separately.

Role workshop · debug and verify

UI-only restrictions do not establish server security. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save ACL matrix and interface test evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Both interfaces enforce the intended access; observations are recorded separately.

Expected: Both interfaces enforce the intended access; observations are recorded separately.

Troubleshoot: The role exercise differs from the prediction: UI-only restrictions do not establish server security.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: ACL matrix and interface test evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with server rules and access controls. Use the glossary below, then write your prediction for: Hiding an internal note on a form must not expose it through an API to the requester. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ServiceNow Developer / Administrator role interview. Explain server rules and access controls using this case: Hiding an internal note on a form must not expose it through an API to the requester. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate server rules and access controls to a system or workflow you know. Explain server rules and access controls using this case: Hiding an internal note on a form must not expose it through an API to the requester. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: UI-only restrictions do not establish server security.

Interview: Explain server rules and access controls using this case: Hiding an internal note on a form must not expose it through an API to the requester. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Hiding an internal note on a form must not expose it through an API to the requester.

Ignore the failing case and keep only the successful screenshot.

Both interfaces enforce the intended access; observations are recorded separately.

Treat any successful command as proof that all business and access rules passed.

Reference: Both interfaces enforce the intended access; observations are recorded separately. — Client form rules improve interaction while server rules and access controls protect other entry points. Test the same policy through more than one permitted interface. Both interfaces enforce the intended access; observations are recorded separately.

Sources:

ServiceNow developer learning: https://developer.servicenow.com/dev.do

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Release decision and ownership: Document the evidence, remaining risk, responsible owner and recovery trigger for a change.

Apply release decision and ownership in ServiceNow Developer / Administrator: Use the concept to complete this role exercise: Plan scoped application promotion, access review and rollback evidence

Update promotion and workflow recovery: Configuration promotion needs dependencies, conflict review and a plan for records already in flight. Reverting a rule does not undo approvals or notifications already sent.

### Release decision and ownership

Document the evidence, remaining risk, responsible owner and recovery trigger for a change. In this role, work through: An approval workflow changed mid-request needs a documented treatment of existing requests. The practical workshop develops this into: Prepare a lab update package using the instance's supported mechanism, list dependencies and rehearse import/retest in a second environment if available. Write a recovery plan for in-flight records.

Mental model: A flight checklist has an accountable pilot and reasons to delay departure.

Boundary: A checklist supports judgment; it does not transfer accountability to a tool.

Role application: Replacing the route map does not bring back parcels already delivered.

Configuration promotion needs dependencies, conflict review and a plan for records already in flight. Reverting a rule does not undo approvals or notifications already sent.

Worked example: An approval workflow changed mid-request needs a documented treatment of existing requests.

Shared foundation example: Hold a release if unauthorized users can export records, even if basic navigation works.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: ServiceNow tables, Flow Designer and access controls (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for ServiceNow Developer / Administrator: An approval workflow changed mid-request needs a documented treatment of existing requests.

Predict the worked case

Read this case without running a tool: An approval workflow changed mid-request needs a documented treatment of existing requests. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in release decision and ownership.

Connect the concept to the role

Apply this rule: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A checklist supports judgment; it does not transfer accountability to a tool.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies release decision and ownership to this case: An approval workflow changed mid-request needs a documented treatment of existing requests. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An approval workflow changed mid-request needs a documented treatment of existing requests. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Release decision and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with release decision and ownership. Use the glossary below, then write your prediction for: An approval workflow changed mid-request needs a documented treatment of existing requests. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ServiceNow Developer / Administrator role interview. Explain release decision and ownership using this case: An approval workflow changed mid-request needs a documented treatment of existing requests. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate release decision and ownership to a system or workflow you know. Explain release decision and ownership using this case: An approval workflow changed mid-request needs a documented treatment of existing requests. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would make a conditional approval expire?

Interview: Explain release decision and ownership using this case: An approval workflow changed mid-request needs a documented treatment of existing requests. State the evidence, one alternative and where the mental model stops.

Quiz: After the Update promotion and workflow recovery rehearsal, check this foundation: A release has a known access-control defect but basic navigation passes. What should the decision include?

Only the navigation pass count.

An anonymous approval with no recovery trigger.

The defect evidence, impact, accountable owner and explicit release or hold criteria.

Reference: The defect evidence, impact, accountable owner and explicit release or hold criteria. — A release decision needs evidence and ownership. Basic checks do not cancel a serious unresolved risk.

Sources:

ServiceNow developer learning: https://developer.servicenow.com/dev.do

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Update promotion and workflow recovery

Configuration promotion needs dependencies, conflict review and a plan for records already in flight. Reverting a rule does not undo approvals or notifications already sent. In this role, work through: An approval workflow changed mid-request needs a documented treatment of existing requests. The practical workshop develops this into: Prepare a lab update package using the instance's supported mechanism, list dependencies and rehearse import/retest in a second environment if available. Write a recovery plan for in-flight records.

Mental model: Replacing the route map does not bring back parcels already delivered.

Boundary: Never promote unrelated captured changes simply because they are in the same package.

Worked example: An approval workflow changed mid-request needs a documented treatment of existing requests.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: ServiceNow tables, Flow Designer and access controls (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required ServiceNow Developer / Administrator workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Prepare a lab update package using the instance's supported mechanism, list dependencies and rehearse import/retest in a second environment if available. Write a recovery plan for in-flight records.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

An approval workflow changed mid-request needs a documented treatment of existing requests. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Prepare a lab update package using the instance's supported mechanism, list dependencies and rehearse import/retest in a second environment if available. Write a recovery plan for in-flight records.

Expected: A manifest and evidence-based release decision with pending environment checks labeled.

Role workshop · debug and verify

Never promote unrelated captured changes simply because they are in the same package. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save ServiceNow release workbook and in-flight case analysis. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A manifest and evidence-based release decision with pending environment checks labeled.

Expected: A manifest and evidence-based release decision with pending environment checks labeled.

Troubleshoot: The role exercise differs from the prediction: Never promote unrelated captured changes simply because they are in the same package.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: ServiceNow release workbook and in-flight case analysis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with update promotion and workflow recovery. Use the glossary below, then write your prediction for: An approval workflow changed mid-request needs a documented treatment of existing requests. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ServiceNow Developer / Administrator role interview. Explain update promotion and workflow recovery using this case: An approval workflow changed mid-request needs a documented treatment of existing requests. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate update promotion and workflow recovery to a system or workflow you know. Explain update promotion and workflow recovery using this case: An approval workflow changed mid-request needs a documented treatment of existing requests. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Never promote unrelated captured changes simply because they are in the same package.

Interview: Explain update promotion and workflow recovery using this case: An approval workflow changed mid-request needs a documented treatment of existing requests. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? An approval workflow changed mid-request needs a documented treatment of existing requests.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A manifest and evidence-based release decision with pending environment checks labeled.

Reference: A manifest and evidence-based release decision with pending environment checks labeled. — Configuration promotion needs dependencies, conflict review and a plan for records already in flight. Reverting a rule does not undo approvals or notifications already sent. A manifest and evidence-based release decision with pending environment checks labeled.

Sources:

ServiceNow developer learning: https://developer.servicenow.com/dev.do

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys
