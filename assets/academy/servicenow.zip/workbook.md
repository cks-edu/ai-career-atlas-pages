# Learning project — service request workflow
Use synthetic people and data. Replace each bracket. Do not label proposed evidence as observed.

## Beginner: understand the work
User: [who needs help]
Problem: [what blocks them]
Current steps: [request -> triage -> assign -> resolve]
Acceptance example: Given [context], when [action], then [observable result].
Out-of-scope: [what is excluded]

## Intermediate: test a change
Proposed change: [one change]
Alternatives: [at least two]
Five synthetic test cases: [input, expected outcome, actual observation]
Accessibility / permissions / data constraints: [record each]
Evidence links: [artifact and date]

## Advanced: release decision
Decision: [go, revise, hold]
Owner: [named fictional accountable person]
Monitoring signal and threshold: [definition and why]
Recovery: [trigger, action, verification]
Known limitations: [at least two]
Version and review date: [date]
