# ServiceNow Developer / Administrator

Software Engineering

Start with records, tables and assignment. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward ServiceNow release workbook and in-flight case analysis.

## beginner

Complete the workbook data dictionary, then use a developer instance if available to model a synthetic request. Define states and mandatory closure evidence; test a blank resolution.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Records, tables and assignment
A service workflow needs a defined table, state and ownership. Distinguish requester-visible fields from internal operational notes before building forms.
Mental model: A service desk keeps a public receipt and an internal work ticket.
Limit: Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable.
Example: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Complete the workbook data dictionary, then use a developer instance if available to model a synthetic request. Define states and mandatory closure evidence; test a blank resolution.
Expected: A rejected invalid closure and a valid assigned request.

6. Role workshop · debug and verify
Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save table dictionary and state tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A rejected invalid closure and a valid assigned request.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Records, tables and assignment: Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: table dictionary and state tests
A rejected invalid closure and a valid assigned request.

Interview: Work through this ServiceNow Developer / Administrator case: A request starts New, is assigned to a group and cannot be Closed without a resolution note under the lab policy. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A service workflow needs a defined table, state and ownership. Distinguish requester-visible fields from internal operational notes before building forms. Expected evidence: A rejected invalid closure and a valid assigned request. Diagnosis: Developer instance availability is not guaranteed; keep a complete offline contract when access is unavailable. State the limits of the mental model: A service desk keeps a public receipt and an internal work ticket.

Resume: Built table dictionary and state tests using ServiceNow tables, Flow Designer and access controls; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create a role/field matrix and test requester versus fulfiller access in a lab instance. Compare form behavior and authorized API access, using synthetic records only.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Server rules and access controls
Client form rules improve interaction while server rules and access controls protect other entry points. Test the same policy through more than one permitted interface.
Mental model: A sign on the door helps visitors; the lock enforces entry.
Limit: UI-only restrictions do not establish server security.
Example: Hiding an internal note on a form must not expose it through an API to the requester.
Recall: Explain the expected result before running the exercise, then diagnose this failure: UI-only restrictions do not establish server security.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
Hiding an internal note on a form must not expose it through an API to the requester. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a role/field matrix and test requester versus fulfiller access in a lab instance. Compare form behavior and authorized API access, using synthetic records only.
Expected: Both interfaces enforce the intended access; observations are recorded separately.

6. Role workshop · debug and verify
UI-only restrictions do not establish server security. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save ACL matrix and interface test evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Both interfaces enforce the intended access; observations are recorded separately.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Server rules and access controls: UI-only restrictions do not establish server security.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: ACL matrix and interface test evidence
Both interfaces enforce the intended access; observations are recorded separately.

Interview: Work through this ServiceNow Developer / Administrator case: Hiding an internal note on a form must not expose it through an API to the requester. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Client form rules improve interaction while server rules and access controls protect other entry points. Test the same policy through more than one permitted interface. Expected evidence: Both interfaces enforce the intended access; observations are recorded separately. Diagnosis: UI-only restrictions do not establish server security. State the limits of the mental model: A sign on the door helps visitors; the lock enforces entry.

Resume: Built ACL matrix and interface test evidence using ServiceNow tables, Flow Designer and access controls; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Prepare a lab update package using the instance's supported mechanism, list dependencies and rehearse import/retest in a second environment if available. Write a recovery plan for in-flight records.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Update promotion and workflow recovery
Configuration promotion needs dependencies, conflict review and a plan for records already in flight. Reverting a rule does not undo approvals or notifications already sent.
Mental model: Replacing the route map does not bring back parcels already delivered.
Limit: Never promote unrelated captured changes simply because they are in the same package.
Example: An approval workflow changed mid-request needs a documented treatment of existing requests.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Never promote unrelated captured changes simply because they are in the same package.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
An approval workflow changed mid-request needs a documented treatment of existing requests. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Prepare a lab update package using the instance's supported mechanism, list dependencies and rehearse import/retest in a second environment if available. Write a recovery plan for in-flight records.
Expected: A manifest and evidence-based release decision with pending environment checks labeled.

6. Role workshop · debug and verify
Never promote unrelated captured changes simply because they are in the same package. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save ServiceNow release workbook and in-flight case analysis. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A manifest and evidence-based release decision with pending environment checks labeled.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Update promotion and workflow recovery: Never promote unrelated captured changes simply because they are in the same package.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: ServiceNow release workbook and in-flight case analysis
A manifest and evidence-based release decision with pending environment checks labeled.

Interview: Work through this ServiceNow Developer / Administrator case: An approval workflow changed mid-request needs a documented treatment of existing requests. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Configuration promotion needs dependencies, conflict review and a plan for records already in flight. Reverting a rule does not undo approvals or notifications already sent. Expected evidence: A manifest and evidence-based release decision with pending environment checks labeled. Diagnosis: Never promote unrelated captured changes simply because they are in the same package. State the limits of the mental model: Replacing the route map does not bring back parcels already delivered.

Resume: Built ServiceNow release workbook and in-flight case analysis using ServiceNow tables, Flow Designer and access controls; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
ServiceNow developer learning: https://developer.servicenow.com/dev.do
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
SAP Learning Journeys: https://learning.sap.com/learning-journeys
