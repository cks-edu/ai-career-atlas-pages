# AI platform engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Platform contracts: An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.

### Platform contracts

An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit. In this role, work through: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A building provides power and fire exits; occupants still operate their appliances safely.

Boundary: A deployment template does not automatically make every workload production ready.

Worked example: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); Prometheus (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI platform engineer: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks.

Predict the worked case

Read this case without running a tool: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in platform contracts.

Connect the concept to the role

Apply this rule: An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A deployment template does not automatically make every workload production ready.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies platform contracts to this case: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Platform contracts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with platform contracts. Use the glossary below, then write your prediction for: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI platform engineer role interview. Explain platform contracts using this case: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate platform contracts to a system or workflow you know. Explain platform contracts using this case: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain platform contracts using this case: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? The platform provisions a namespace and quota; the team owns model behavior and application readiness checks.

An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit. — An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit. A deployment template does not automatically make every workload production ready.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

Prometheus: https://prometheus.io/docs/introduction/overview/

Kubernetes: https://kubernetes.io/docs/tutorials/

OpenTelemetry: https://opentelemetry.io/docs/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

### Diagnose: A tenant exhausts the shared budget

The gateway lab permits at most ten accepted requests per tenant per window. Two tenants exceed the configured admission contract. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Enforce identity-scoped limits atomically before work enters the shared queue. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A building provides power and fire exits; occupants still operate their appliances safely.

The platform provisions a namespace and quota; the team owns model behavior and application readiness checks.

Worked example: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Enforce identity-scoped limits atomically before work enters the shared queue.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); Prometheus (Open source)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The gateway lab permits at most ten accepted requests per tenant per window. Two tenants exceed the configured admission contract. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The gateway lab permits at most ten accepted requests per tenant per window. Apply this toy-case rule manually: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A platform provides shared services that applications use. A clear contract explains expected inputs, outputs and errors.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Define a fictional service that accepts a question and a document ID and returns an answer plus its source.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Three request/response examples and an owner table.

Preparation · Try step 2

Write examples for a valid request, a missing question and a user who cannot access the document.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Three request/response examples and an owner table.

Preparation · Try step 3

Assign responsibility for checking user access, finding documents and displaying an error.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Three request/response examples and an owner table.

Preparation · Explain and check your result

The unauthorized example returns no document content; each failure has an identified owner. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: Three request/response examples and an owner table. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The gateway lab permits at most ten accepted requests per tenant per window. Apply this toy-case rule manually: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two tenants exceed the configured admission contract. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two tenants exceed the configured admission contract. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a tenant exhausts the shared budget. Use the glossary below, then write your prediction for: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Enforce identity-scoped limits atomically before work enters the shared queue. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI platform engineer role interview. Explain diagnose: a tenant exhausts the shared budget using this case: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Enforce identity-scoped limits atomically before work enters the shared queue. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a tenant exhausts the shared budget to a system or workflow you know. Explain diagnose: a tenant exhausts the shared budget using this case: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Enforce identity-scoped limits atomically before work enters the shared queue. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Allowed traffic succeeds; excess requests fail without consuming another tenant’s budget. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a tenant exhausts the shared budget using this case: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Enforce identity-scoped limits atomically before work enters the shared queue. State the evidence, one alternative and where the mental model stops.

Quiz: A tenant exhausts the shared budget: The gateway lab permits at most ten accepted requests per tenant per window.

Change the acceptance rule after seeing an inconvenient result.

Enforce identity-scoped limits atomically before work enters the shared queue.

Omit failed cases and report only the successful demonstrations.

Reference: Enforce identity-scoped limits atomically before work enters the shared queue. — Enforce identity-scoped limits atomically before work enters the shared queue. Allowed traffic succeeds; excess requests fail without consuming another tenant’s budget.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

Prometheus: https://prometheus.io/docs/introduction/overview/

Kubernetes: https://kubernetes.io/docs/tutorials/

OpenTelemetry: https://opentelemetry.io/docs/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: A DevOps/cloud background transfers well. Start with Linux, networking, HTTP, Python, containers and one cloud IAM model. Senior platform ownership also requires cross-team API design, migration planning and on-call judgment.

Terms:

Tenant isolation: Separate identity, compute budgets, data access and network permissions for teams sharing infrastructure. Test denied actions as carefully as successful onboarding.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

Pod: A Kubernetes unit containing one or more containers scheduled together.

namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

RBAC: Role-based access control: permissions are assigned through roles; test both allowed and denied actions.

### Tenant isolation

Separate identity, compute budgets, data access and network permissions for teams sharing infrastructure. Test denied actions as carefully as successful onboarding. In this role, work through: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Apartments share a building but each has its own lock and utility meter.

Boundary: Namespaces alone do not supply all network or host isolation.

Worked example: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: A DevOps/cloud background transfers well. Start with Linux, networking, HTTP, Python, containers and one cloud IAM model. Senior platform ownership also requires cross-team API design, migration planning and on-call judgment.

Tools for this exercise: Document or text editor

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); Prometheus (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI platform engineer: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota.

Predict the worked case

Read this case without running a tool: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in tenant isolation.

Connect the concept to the role

Apply this rule: Separate identity, compute budgets, data access and network permissions for teams sharing infrastructure. Test denied actions as carefully as successful onboarding. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Namespaces alone do not supply all network or host isolation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies tenant isolation to this case: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Tenant isolation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with tenant isolation. Use the glossary below, then write your prediction for: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI platform engineer role interview. Explain tenant isolation using this case: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate tenant isolation to a system or workflow you know. Explain tenant isolation using this case: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain tenant isolation using this case: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota.

Treat a passing starter as proof of the whole role workflow.

Separate identity, compute budgets, data access and network permissions for teams sharing infrastructure. Test denied actions as carefully as successful onboarding.

Ignore the failure because the tool produced an output.

Reference: Separate identity, compute budgets, data access and network permissions for teams sharing infrastructure. Test denied actions as carefully as successful onboarding. — Separate identity, compute budgets, data access and network permissions for teams sharing infrastructure. Test denied actions as carefully as successful onboarding. Namespaces alone do not supply all network or host isolation.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

Prometheus: https://prometheus.io/docs/introduction/overview/

Kubernetes: https://kubernetes.io/docs/tutorials/

OpenTelemetry: https://opentelemetry.io/docs/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

### Integrate: Namespaced AI service platform

Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script. In this role, work through: Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Role application: Apartments share a building but each has its own lock and utility meter.

Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota.

Worked example: Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.

Setup: Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); Prometheus (Open source)

Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Prepare the project inputs

Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The gateway lab permits at most ten accepted requests per tenant per window. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Deliverable: lesson-intermediate-2.md: Platform manifests and onboarding template; Quota/RBAC evidence and dashboard exports. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: namespaced ai service platform. Use the glossary below, then write your prediction for: Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI platform engineer role interview. Explain integrate: namespaced ai service platform using this case: Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: namespaced ai service platform to a system or workflow you know. Explain integrate: namespaced ai service platform using this case: Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. Identify one observation that would contradict your claim.

Interview: Explain integrate: namespaced ai service platform using this case: Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Namespaced AI service platform at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.

Reference: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. — Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

Prometheus: https://prometheus.io/docs/introduction/overview/

Kubernetes: https://kubernetes.io/docs/tutorials/

OpenTelemetry: https://opentelemetry.io/docs/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Platform lifecycle management: Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

Pod: A Kubernetes unit containing one or more containers scheduled together.

namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

RBAC: Role-based access control: permissions are assigned through roles; test both allowed and denied actions.

### Platform lifecycle management

Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability. In this role, work through: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A public transport timetable must support existing travelers while routes change.

Boundary: A rollback can leave behind state created by the newer workload.

Worked example: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); Prometheus (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI platform engineer: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data.

Predict the worked case

Read this case without running a tool: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in platform lifecycle management.

Connect the concept to the role

Apply this rule: Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A rollback can leave behind state created by the newer workload.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies platform lifecycle management to this case: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Platform lifecycle management; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with platform lifecycle management. Use the glossary below, then write your prediction for: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI platform engineer role interview. Explain platform lifecycle management using this case: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate platform lifecycle management to a system or workflow you know. Explain platform lifecycle management using this case: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain platform lifecycle management using this case: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability.

Reference: Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability. — Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability. A rollback can leave behind state created by the newer workload.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

Prometheus: https://prometheus.io/docs/introduction/overview/

Kubernetes: https://kubernetes.io/docs/tutorials/

OpenTelemetry: https://opentelemetry.io/docs/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

### Defend: Namespaced AI service platform

Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. Install a metrics stack from its official chart instructions, record chart versions and add availability, restart and saturation panels. Write a team onboarding manifest with owner and runbook labels. In this role, work through: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Role application: A public transport timetable must support existing travelers while routes change.

Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data.

Worked example: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.

Setup: Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); Prometheus (Open source)

Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Prepare the project inputs

Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Install a metrics stack from its official chart instructions, record chart versions and add availability, restart and saturation panels. Write a team onboarding manifest with owner and runbook labels.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. A reviewer must reproduce one result and identify which capabilities you implemented. Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Deliverable: lesson-advanced-2.md: Platform manifests and onboarding template; Quota/RBAC evidence and dashboard exports; Service ownership and rollback runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: namespaced ai service platform. Use the glossary below, then write your prediction for: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI platform engineer role interview. Explain defend: namespaced ai service platform using this case: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: namespaced ai service platform to a system or workflow you know. Explain defend: namespaced ai service platform using this case: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. Identify one observation that would contradict your claim.

Interview: Explain defend: namespaced ai service platform using this case: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Namespaced AI service platform at this level?

Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error. — Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error. Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

Prometheus: https://prometheus.io/docs/introduction/overview/

Kubernetes: https://kubernetes.io/docs/tutorials/

OpenTelemetry: https://opentelemetry.io/docs/

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html
