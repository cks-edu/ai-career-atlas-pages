# Namespaced AI service platform

Career: AI platform engineer
Reviewed: 2026-10-22

Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path.

## Prerequisites
A DevOps/cloud background transfers well. Start with Linux, networking, HTTP, Python, containers and one cloud IAM model. Senior platform ownership also requires cross-team API design, migration planning and on-call judgment.

## Included starter versus your implementation
A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context.

```sh
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Install a metrics stack from its official chart instructions, record chart versions and add availability, restart and saturation panels. Write a team onboarding manifest with owner and runbook labels.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

## Portfolio deliverables
1. Platform manifests and onboarding template — artifact-1.md
2. Quota/RBAC evidence and dashboard exports — artifact-2.md
3. Service ownership and rollback runbook — artifact-3.md

## Troubleshooting
- ImagePullBackOff: inspect kubectl describe pod and image availability.
- Pending: inspect resource requests and node capacity.
- NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.

## Extension
Port one namespace to a sandbox cloud cluster, recording IAM mappings, cost limits and teardown evidence.

## Primary learning resources
- kind: https://kind.sigs.k8s.io/docs/user/quick-start/ — Open source · local containers; Disposable Kubernetes cluster; requires a compatible container runtime.
- Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/ — Open source · local or cloud; Resource, identity and container security controls.
- Prometheus: https://prometheus.io/docs/introduction/overview/ — Open source; Metrics collection and alert evidence.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
