# Namespaced AI service platform

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.

## Limitations and next iteration
Port one namespace to a sandbox cloud cluster, recording IAM mappings, cost limits and teardown evidence.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
