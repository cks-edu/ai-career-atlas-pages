# Platform manifests and onboarding template

Project: Namespaced AI service platform
Status: blank work product — not completed evidence

## Purpose and audience
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path.

## Required content
Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.

## Failure evidence
Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
