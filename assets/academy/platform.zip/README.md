# AI platform engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Platform contracts. A platform provides shared services that applications use. A clear contract explains expected inputs, outputs and errors. Then try Write a mock service contract. The three levels build toward Namespaced AI service platform. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Platform contracts

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Platform contracts
An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit.
Mental model: A building provides power and fire exits; occupants still operate their appliances safely.
Boundary: A deployment template does not automatically make every workload production ready.
Worked example: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A tenant exhausts the shared budget
The gateway lab permits at most ten accepted requests per tenant per window. Two tenants exceed the configured admission contract. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Enforce identity-scoped limits atomically before work enters the shared queue.
Recall: Allowed traffic succeeds; excess requests fail without consuming another tenant’s budget. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Platform contracts: An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A platform provides shared services that applications use. A clear contract explains expected inputs, outputs and errors.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Define a fictional service that accepts a question and a document ID and returns an answer plus its source.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Three request/response examples and an owner table.

3. Try step 2
Write examples for a valid request, a missing question and a user who cannot access the document.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Three request/response examples and an owner table.

4. Try step 3
Assign responsibility for checking user access, finding documents and displaying an error.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Three request/response examples and an owner table.

5. Explain and check your result
The unauthorized example returns no document content; each failure has an identified owner. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Three request/response examples and an owner table. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The gateway lab permits at most ten accepted requests per tenant per window. Apply this toy-case rule manually: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two tenants exceed the configured admission contract. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI platform engineer.
Define a fictional service that accepts a question and a document ID and returns an answer plus its source.
Write examples for a valid request, a missing question and a user who cannot access the document.
Assign responsibility for checking user access, finding documents and displaying an error.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Three request/response examples and an owner table. Include beginner-worksheet.md and your completed Tenant-isolation test report.
Check: The unauthorized example returns no document content; each failure has an identified owner.

### Interview
Explain your beginner solution for AI platform engineer. Use this scenario: The gateway lab permits at most ten accepted requests per tenant per window.
Review: Start with the task and permitted scope. Explain platform contracts: An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit. Show the input and observed output, then address Enforce identity-scoped limits atomically before work enters the shared queue. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Three request/response examples and an owner table. Include beginner-worksheet.md and your completed Tenant-isolation test report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Tenant isolation

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: A DevOps/cloud background transfers well. Start with Linux, networking, HTTP, Python, containers and one cloud IAM model. Senior platform ownership also requires cross-team API design, migration planning and on-call judgment.

### Tenant isolation
Separate identity, compute budgets, data access and network permissions for teams sharing infrastructure. Test denied actions as carefully as successful onboarding.
Mental model: Apartments share a building but each has its own lock and utility meter.
Boundary: Namespaces alone do not supply all network or host isolation.
Worked example: Team A's service account cannot list Team B's secrets and cannot allocate beyond its namespace quota.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Namespaced AI service platform
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.
Recall: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. Identify one observation that would contradict your claim.

### Terms
Tenant isolation: Separate identity, compute budgets, data access and network permissions for teams sharing infrastructure. Test denied actions as carefully as successful onboarding.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.
RBAC: Role-based access control: permissions are assigned through roles; test both allowed and denied actions.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The gateway lab permits at most ten accepted requests per tenant per window. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path.
Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.
Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.
Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.
Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.
Deliverables: Platform manifests and onboarding template; Quota/RBAC evidence and dashboard exports. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI platform engineer. Use this scenario: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.
Review: Start with the task and permitted scope. Explain tenant isolation: Separate identity, compute budgets, data access and network permissions for teams sharing infrastructure. Test denied actions as carefully as successful onboarding. Show the input and observed output, then address Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Platform manifests and onboarding template; Quota/RBAC evidence and dashboard exports. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Platform lifecycle management

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Platform lifecycle management
Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability.
Mental model: A public transport timetable must support existing travelers while routes change.
Boundary: A rollback can leave behind state created by the newer workload.
Worked example: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Namespaced AI service platform
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. Install a metrics stack from its official chart instructions, record chart versions and add availability, restart and saturation panels. Write a team onboarding manifest with owner and runbook labels.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.
Recall: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. Identify one observation that would contradict your claim.

### Terms
Platform lifecycle management: Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.
RBAC: Role-based access control: permissions are assigned through roles; test both allowed and denied actions.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Install a metrics stack from its official chart instructions, record chart versions and add availability, restart and saturation panels. Write a team onboarding manifest with owner and runbook labels.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path.
Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.
Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.
Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.
Install a metrics stack from its official chart instructions, record chart versions and add availability, restart and saturation panels. Write a team onboarding manifest with owner and runbook labels.
Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.
Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.
Port one namespace to a sandbox cloud cluster, recording IAM mappings, cost limits and teardown evidence.
Deliverables: Platform manifests and onboarding template; Quota/RBAC evidence and dashboard exports; Service ownership and rollback runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. A reviewer must reproduce one result and identify which capabilities you implemented. Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.

### Interview
Explain your advanced solution for AI platform engineer. Use this scenario: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.
Review: Start with the task and permitted scope. Explain platform lifecycle management: Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability. Show the input and observed output, then address Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Platform manifests and onboarding template; Quota/RBAC evidence and dashboard exports; Service ownership and rollback runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
kind — Open source · local containers
Disposable Kubernetes cluster; requires a compatible container runtime.
Alternative: minikube (open source); managed Kubernetes is a separate commercial hosting choice, not required for a first lab.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Kubernetes security contexts — Open source · local or cloud
Resource, identity and container security controls.
Alternative: A local container or Docker Compose can suit a small service; managed cloud Kubernetes adds provider fees and responsibilities.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Prometheus — Open source
Metrics collection and alert evidence.
Alternative: VictoriaMetrics has open-source and commercial editions; a managed monitoring service has separate retention and cost terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
kind: https://kind.sigs.k8s.io/docs/user/quick-start/
Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/
Prometheus: https://prometheus.io/docs/introduction/overview/
Kubernetes: https://kubernetes.io/docs/tutorials/
OpenTelemetry: https://opentelemetry.io/docs/
Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html
