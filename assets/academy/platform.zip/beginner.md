## beginner — Platform contracts

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Platform contracts
An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit.
Mental model: A building provides power and fire exits; occupants still operate their appliances safely.
Boundary: A deployment template does not automatically make every workload production ready.
Worked example: The platform provisions a namespace and quota; the team owns model behavior and application readiness checks.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A tenant exhausts the shared budget
The gateway lab permits at most ten accepted requests per tenant per window. Two tenants exceed the configured admission contract. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Enforce identity-scoped limits atomically before work enters the shared queue.
Recall: Allowed traffic succeeds; excess requests fail without consuming another tenant’s budget. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Platform contracts: An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A platform provides shared services that applications use. A clear contract explains expected inputs, outputs and errors.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Define a fictional service that accepts a question and a document ID and returns an answer plus its source.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Three request/response examples and an owner table.

3. Try step 2
Write examples for a valid request, a missing question and a user who cannot access the document.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Three request/response examples and an owner table.

4. Try step 3
Assign responsibility for checking user access, finding documents and displaying an error.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Three request/response examples and an owner table.

5. Explain and check your result
The unauthorized example returns no document content; each failure has an identified owner. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Three request/response examples and an owner table. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The gateway lab permits at most ten accepted requests per tenant per window. Apply this toy-case rule manually: Review when accepted_requests >= 11 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two tenants exceed the configured admission contract. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI platform engineer.
Define a fictional service that accepts a question and a document ID and returns an answer plus its source.
Write examples for a valid request, a missing question and a user who cannot access the document.
Assign responsibility for checking user access, finding documents and displaying an error.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Three request/response examples and an owner table. Include beginner-worksheet.md and your completed Tenant-isolation test report.
Check: The unauthorized example returns no document content; each failure has an identified owner.

### Interview
Explain your beginner solution for AI platform engineer. Use this scenario: The gateway lab permits at most ten accepted requests per tenant per window.
Review: Start with the task and permitted scope. Explain platform contracts: An internal platform offers a supported interface for deploying and operating workloads. Make the boundary between platform responsibilities and application responsibilities explicit. Show the input and observed output, then address Enforce identity-scoped limits atomically before work enters the shared queue. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Three request/response examples and an owner table. Include beginner-worksheet.md and your completed Tenant-isolation test report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

