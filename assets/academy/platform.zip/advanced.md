## advanced — Platform lifecycle management

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Platform lifecycle management
Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability.
Mental model: A public transport timetable must support existing travelers while routes change.
Boundary: A rollback can leave behind state created by the newer workload.
Worked example: Release template v2 to a test namespace, verify health and permissions, then rehearse a return to v1 with compatible data.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Namespaced AI service platform
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. Install a metrics stack from its official chart instructions, record chart versions and add availability, restart and saturation panels. Write a team onboarding manifest with owner and runbook labels.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.
Recall: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. Identify one observation that would contradict your claim.

### Terms
Platform lifecycle management: Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.
RBAC: Role-based access control: permissions are assigned through roles; test both allowed and denied actions.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Install a metrics stack from its official chart instructions, record chart versions and add availability, restart and saturation panels. Write a team onboarding manifest with owner and runbook labels.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Create a local Kubernetes platform with clear ownership, resource limits and a repeatable service onboarding path.
Use kind on a machine with Docker and at least 8 GB available memory. Start with two fictional teams and a CPU HTTP service; GPU scheduling is an optional extension.
Apply the included namespace and deployment manifests using the explicit kind-atlas-portfolio context. Inspect readiness and resource requests before opening a loopback port-forward.
Create separate team namespaces, service accounts, ResourceQuotas and LimitRanges. Add one allowed and one forbidden operation to an RBAC acceptance script.
Install a metrics stack from its official chart instructions, record chart versions and add availability, restart and saturation panels. Write a team onboarding manifest with owner and runbook labels.
Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.
Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation.
Port one namespace to a sandbox cloud cluster, recording IAM mappings, cost limits and teardown evidence.
Deliverables: Platform manifests and onboarding template; Quota/RBAC evidence and dashboard exports; Service ownership and rollback runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. A reviewer must reproduce one result and identify which capabilities you implemented. Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.

### Interview
Explain your advanced solution for AI platform engineer. Use this scenario: Deploy an invalid image tag, inspect events and roll back. Then request more CPU than the team quota permits and record the admission error.
Review: Start with the task and permitted scope. Explain platform lifecycle management: Version templates and interfaces, offer migration guidance and test rollback. Evaluate the platform through developer task success and operating reliability. Show the input and observed output, then address Capture rollout duration, denied RBAC actions, quota enforcement and recovery time. kind does not prove managed-cloud networking or GPU isolation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Platform manifests and onboarding template; Quota/RBAC evidence and dashboard exports; Service ownership and rollback runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

