# Data Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Ingestion contracts and quarantine

A data contract names keys, types, accepted ranges and rejection behavior. Keep rejected records with reasons so a successful pipeline does not hide lost business data.
Mental model: An intake station counts delivered, accepted and returned parcels separately.
Case: a=10,b=20,a=10,c=-5 yields two unique accepted orders, one replay and one rejected row.
Task: Extend pipeline.py to emit accepted, duplicate and rejected identifiers separately. Save a run manifest containing source filename, input count and the three outcome counts.
Acceptance: 4 input rows = 2 accepted + 1 duplicate + 1 rejected; total accepted amount 30.
Troubleshooting: A reconciliation mismatch means a row was dropped or classified twice; inspect identifiers before totals.
Deliverable: ingestion manifest and quarantine file

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Corrections versus duplicates

A repeated ID with the same payload is a replay; the same ID with a newer business version may be a correction. Define ordering and conflict behavior explicitly.
Mental model: A reprinted invoice is not the same as a revised invoice.
Case: Order a changes from amount 10/version 1 to 12/version 2; total becomes 32, not 42.
Task: Add a version field and upsert only newer versions. Test identical replay, stale version and newer correction. Keep an audit of which update was accepted.
Acceptance: Two target orders; total 32 after correction; stale/replayed values do not overwrite it.
Troubleshooting: INSERT OR IGNORE hides legitimate corrections; compare version and payload before deciding.
Deliverable: versioned loader and correction tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Backfill isolation

A backfill reprocesses historical data and can conflict with ongoing ingestion. Bound the time range, keep lineage and reconcile before exposing replacement output.
Mental model: Repair one shelf of an archive without mixing unreviewed copies into the public catalog.
Case: Rebuild one day's partition to a temporary target, compare IDs and totals, then promote it.
Task: Create two dated fixture batches, rebuild only the first into a staging table and introduce an intentional missing row. Make the quality gate block promotion; repair and rerun.
Acceptance: The bad backfill cannot replace the published table; repaired counts and totals match.
Troubleshooting: A successful task status does not prove completeness; compare source IDs as well as counts.
Deliverable: backfill script, lineage manifest and promotion gate

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
