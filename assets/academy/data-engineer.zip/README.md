# Data Engineer

Software Engineering

Start with ingestion contracts and quarantine. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward backfill script, lineage manifest and promotion gate.

## beginner

Extend pipeline.py to emit accepted, duplicate and rejected identifiers separately. Save a run manifest containing source filename, input count and the three outcome counts.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Ingestion contracts and quarantine
A data contract names keys, types, accepted ranges and rejection behavior. Keep rejected records with reasons so a successful pipeline does not hide lost business data.
Mental model: An intake station counts delivered, accepted and returned parcels separately.
Limit: A reconciliation mismatch means a row was dropped or classified twice; inspect identifiers before totals.
Example: a=10,b=20,a=10,c=-5 yields two unique accepted orders, one replay and one rejected row.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A reconciliation mismatch means a row was dropped or classified twice; inspect identifiers before totals.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
a=10,b=20,a=10,c=-5 yields two unique accepted orders, one replay and one rejected row. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Extend pipeline.py to emit accepted, duplicate and rejected identifiers separately. Save a run manifest containing source filename, input count and the three outcome counts.
Expected: 4 input rows = 2 accepted + 1 duplicate + 1 rejected; total accepted amount 30.

6. Role workshop · debug and verify
A reconciliation mismatch means a row was dropped or classified twice; inspect identifiers before totals. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save ingestion manifest and quarantine file. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: 4 input rows = 2 accepted + 1 duplicate + 1 rejected; total accepted amount 30.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Ingestion contracts and quarantine: A reconciliation mismatch means a row was dropped or classified twice; inspect identifiers before totals.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: ingestion manifest and quarantine file
4 input rows = 2 accepted + 1 duplicate + 1 rejected; total accepted amount 30.

Interview: Work through this Data Engineer case: a=10,b=20,a=10,c=-5 yields two unique accepted orders, one replay and one rejected row. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A data contract names keys, types, accepted ranges and rejection behavior. Keep rejected records with reasons so a successful pipeline does not hide lost business data. Expected evidence: 4 input rows = 2 accepted + 1 duplicate + 1 rejected; total accepted amount 30. Diagnosis: A reconciliation mismatch means a row was dropped or classified twice; inspect identifiers before totals. State the limits of the mental model: An intake station counts delivered, accepted and returned parcels separately.

Resume: Built ingestion manifest and quarantine file using Python and PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Add a version field and upsert only newer versions. Test identical replay, stale version and newer correction. Keep an audit of which update was accepted.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Corrections versus duplicates
A repeated ID with the same payload is a replay; the same ID with a newer business version may be a correction. Define ordering and conflict behavior explicitly.
Mental model: A reprinted invoice is not the same as a revised invoice.
Limit: INSERT OR IGNORE hides legitimate corrections; compare version and payload before deciding.
Example: Order a changes from amount 10/version 1 to 12/version 2; total becomes 32, not 42.
Recall: Explain the expected result before running the exercise, then diagnose this failure: INSERT OR IGNORE hides legitimate corrections; compare version and payload before deciding.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Order a changes from amount 10/version 1 to 12/version 2; total becomes 32, not 42. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add a version field and upsert only newer versions. Test identical replay, stale version and newer correction. Keep an audit of which update was accepted.
Expected: Two target orders; total 32 after correction; stale/replayed values do not overwrite it.

6. Role workshop · debug and verify
INSERT OR IGNORE hides legitimate corrections; compare version and payload before deciding. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save versioned loader and correction tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Two target orders; total 32 after correction; stale/replayed values do not overwrite it.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Corrections versus duplicates: INSERT OR IGNORE hides legitimate corrections; compare version and payload before deciding.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: versioned loader and correction tests
Two target orders; total 32 after correction; stale/replayed values do not overwrite it.

Interview: Work through this Data Engineer case: Order a changes from amount 10/version 1 to 12/version 2; total becomes 32, not 42. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A repeated ID with the same payload is a replay; the same ID with a newer business version may be a correction. Define ordering and conflict behavior explicitly. Expected evidence: Two target orders; total 32 after correction; stale/replayed values do not overwrite it. Diagnosis: INSERT OR IGNORE hides legitimate corrections; compare version and payload before deciding. State the limits of the mental model: A reprinted invoice is not the same as a revised invoice.

Resume: Built versioned loader and correction tests using Python and PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Create two dated fixture batches, rebuild only the first into a staging table and introduce an intentional missing row. Make the quality gate block promotion; repair and rerun.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Backfill isolation
A backfill reprocesses historical data and can conflict with ongoing ingestion. Bound the time range, keep lineage and reconcile before exposing replacement output.
Mental model: Repair one shelf of an archive without mixing unreviewed copies into the public catalog.
Limit: A successful task status does not prove completeness; compare source IDs as well as counts.
Example: Rebuild one day's partition to a temporary target, compare IDs and totals, then promote it.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful task status does not prove completeness; compare source IDs as well as counts.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Rebuild one day's partition to a temporary target, compare IDs and totals, then promote it. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create two dated fixture batches, rebuild only the first into a staging table and introduce an intentional missing row. Make the quality gate block promotion; repair and rerun.
Expected: The bad backfill cannot replace the published table; repaired counts and totals match.

6. Role workshop · debug and verify
A successful task status does not prove completeness; compare source IDs as well as counts. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save backfill script, lineage manifest and promotion gate. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The bad backfill cannot replace the published table; repaired counts and totals match.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Backfill isolation: A successful task status does not prove completeness; compare source IDs as well as counts.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: backfill script, lineage manifest and promotion gate
The bad backfill cannot replace the published table; repaired counts and totals match.

Interview: Work through this Data Engineer case: Rebuild one day's partition to a temporary target, compare IDs and totals, then promote it. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A backfill reprocesses historical data and can conflict with ongoing ingestion. Bound the time range, keep lineage and reconcile before exposing replacement output. Expected evidence: The bad backfill cannot replace the published table; repaired counts and totals match. Diagnosis: A successful task status does not prove completeness; compare source IDs as well as counts. State the limits of the mental model: Repair one shelf of an archive without mixing unreviewed copies into the public catalog.

Resume: Built backfill script, lineage manifest and promotion gate using Python and PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
