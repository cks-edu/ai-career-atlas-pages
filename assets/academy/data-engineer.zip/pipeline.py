import csv, io, sqlite3, sys
rows = list(csv.DictReader(io.StringIO('id,amount\na,10\nb,20\na,10\nc,-5\n')))
db=sqlite3.connect(':memory:')
db.execute('CREATE TABLE orders (id TEXT PRIMARY KEY, amount INTEGER CHECK(amount>=0))')
rejected=[]
def load():
    for row in rows:
        if int(row['amount']) < 0:
            rejected.append(row['id']); continue
        db.execute('INSERT OR IGNORE INTO orders VALUES (?,?)',(row['id'],int(row['amount'])))
    db.commit()
load()
assert db.execute('SELECT SUM(amount) FROM orders').fetchone()[0]==30
print('accepted=2 total=30 rejected=c')
if sys.argv[1]!='beginner':
    load(); assert db.execute('SELECT COUNT(*) FROM orders').fetchone()[0]==2
    print('replay: still 2 orders, total 30')
if sys.argv[1]=='advanced':
    db.execute('BEGIN'); db.execute('UPDATE orders SET amount=99 WHERE id="a"'); db.rollback()
    assert db.execute('SELECT SUM(amount) FROM orders').fetchone()[0]==30
    print('rollback: total restored to 30')
print('PASS data '+sys.argv[1]); db.close()
