## beginner — Harm scenarios

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Harm scenarios
Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth.
Mental model: A safety inspection asks what could go wrong and who would be hurt.
Boundary: A classroom scenario does not establish a real-world incidence rate.
Worked example: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The safeguard blocks legitimate requests
The trial gate flags more than two false blocks in ten clearly permitted tasks. Two configurations overblock legitimate tasks beyond the agreed pilot tolerance. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Inspect policy interpretation and calibrate thresholds with allowed neighboring examples.
Recall: Measure both missed violations and false blocks across relevant languages and tasks. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Harm scenarios: Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A safety boundary needs both prohibited and acceptable neighboring cases. Excessive refusal can also make an assistant unhelpful.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose a fictional tutor that should explain methods but should not impersonate a student submitting graded work.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A six-case boundary table and two example responses.

3. Try step 2
Write three allowed requests and three requests that cross that boundary.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A six-case boundary table and two example responses.

4. Try step 3
Draft helpful responses for one of each, including what support remains available.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A six-case boundary table and two example responses.

5. Explain and check your result
The rule distinguishes learning support from submitting work as someone else; harmless learning requests are not all refused. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A six-case boundary table and two example responses. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The trial gate flags more than two false blocks in ten clearly permitted tasks. Apply this toy-case rule manually: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two configurations overblock legitimate tasks beyond the agreed pilot tolerance. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI safety / safeguards engineer.
Choose a fictional tutor that should explain methods but should not impersonate a student submitting graded work.
Write three allowed requests and three requests that cross that boundary.
Draft helpful responses for one of each, including what support remains available.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A six-case boundary table and two example responses. Include beginner-worksheet.md and your completed Safeguard calibration and escalation plan.
Check: The rule distinguishes learning support from submitting work as someone else; harmless learning requests are not all refused.

### Interview
Explain your beginner solution for AI safety / safeguards engineer. Use this scenario: The trial gate flags more than two false blocks in ten clearly permitted tasks.
Review: Start with the task and permitted scope. Explain harm scenarios: Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth. Show the input and observed output, then address Inspect policy interpretation and calibrate thresholds with allowed neighboring examples. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A six-case boundary table and two example responses. Include beginner-worksheet.md and your completed Safeguard calibration and escalation plan.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

