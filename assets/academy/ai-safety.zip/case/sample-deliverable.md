# SAMPLE — Safeguard calibration and escalation plan
Role: AI safety / safeguards engineer
Case: The safeguard blocks legitimate requests
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The trial gate flags more than two false blocks in ten clearly permitted tasks.

## Evidence table
| Record | false_blocks (out of ten permitted tasks) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 7 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two configurations overblock legitimate tasks beyond the agreed pilot tolerance.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Inspect policy interpretation and calibrate thresholds with allowed neighboring examples.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai safety / safeguards engineer.
Before release: Measure both missed violations and false blocks across relevant languages and tasks.

## Design choice and trade-off
Define allowed and prohibited behavior together; keep a review path for ambiguous cases.
More aggressive blocking can reduce some harms while excluding legitimate users; report the trade-off.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Safeguard evaluation pack: Report false positives by legitimate task type.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
