## advanced — Layered safety evidence

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Layered safety evidence
Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable.
Mental model: Several independent barriers can slow an accident more effectively than one warning sign.
Boundary: Multiple layers may share the same blind spot and still require evaluation.
Worked example: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Safeguard evaluation and escalation system
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. Create a human escalation workflow with ownership, response targets and appeal/correction steps. Record known gaps and expected operator actions.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Recall: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. Identify one observation that would contradict your claim.

### Terms
Layered safety evidence: Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create a human escalation workflow with ownership, response targets and appeal/correction steps. Record known gaps and expected operator actions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score.
Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.
Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Create a human escalation workflow with ownership, response targets and appeal/correction steps. Record known gaps and expected operator actions.
Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.
Test a policy update against both old and new cases to detect regressions.
Deliverables: Safeguard policy and test harness; Reviewed case set and error analysis; Escalation operating procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.

### Interview
Explain your advanced solution for AI safety / safeguards engineer. Use this scenario: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Review: Start with the task and permitted scope. Explain layered safety evidence: Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable. Show the input and observed output, then address Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Safeguard policy and test harness; Reviewed case set and error analysis; Escalation operating procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

