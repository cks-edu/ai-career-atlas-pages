# AI safety / safeguards engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Harm scenarios. A safety boundary needs both prohibited and acceptable neighboring cases. Excessive refusal can also make an assistant unhelpful. Then try Define a homework-help boundary. The three levels build toward Safeguard evaluation and escalation system. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Harm scenarios

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Harm scenarios
Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth.
Mental model: A safety inspection asks what could go wrong and who would be hurt.
Boundary: A classroom scenario does not establish a real-world incidence rate.
Worked example: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The safeguard blocks legitimate requests
The trial gate flags more than two false blocks in ten clearly permitted tasks. Two configurations overblock legitimate tasks beyond the agreed pilot tolerance. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Inspect policy interpretation and calibrate thresholds with allowed neighboring examples.
Recall: Measure both missed violations and false blocks across relevant languages and tasks. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Harm scenarios: Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A safety boundary needs both prohibited and acceptable neighboring cases. Excessive refusal can also make an assistant unhelpful.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose a fictional tutor that should explain methods but should not impersonate a student submitting graded work.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A six-case boundary table and two example responses.

3. Try step 2
Write three allowed requests and three requests that cross that boundary.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A six-case boundary table and two example responses.

4. Try step 3
Draft helpful responses for one of each, including what support remains available.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A six-case boundary table and two example responses.

5. Explain and check your result
The rule distinguishes learning support from submitting work as someone else; harmless learning requests are not all refused. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A six-case boundary table and two example responses. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The trial gate flags more than two false blocks in ten clearly permitted tasks. Apply this toy-case rule manually: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two configurations overblock legitimate tasks beyond the agreed pilot tolerance. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI safety / safeguards engineer.
Choose a fictional tutor that should explain methods but should not impersonate a student submitting graded work.
Write three allowed requests and three requests that cross that boundary.
Draft helpful responses for one of each, including what support remains available.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A six-case boundary table and two example responses. Include beginner-worksheet.md and your completed Safeguard calibration and escalation plan.
Check: The rule distinguishes learning support from submitting work as someone else; harmless learning requests are not all refused.

### Interview
Explain your beginner solution for AI safety / safeguards engineer. Use this scenario: The trial gate flags more than two false blocks in ten clearly permitted tasks.
Review: Start with the task and permitted scope. Explain harm scenarios: Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth. Show the input and observed output, then address Inspect policy interpretation and calibrate thresholds with allowed neighboring examples. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A six-case boundary table and two example responses. Include beginner-worksheet.md and your completed Safeguard calibration and escalation plan.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Safeguard trade-offs

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Evaluation design, risk analysis and model/application engineering; research roles may need advanced ML expertise.

### Safeguard trade-offs
Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone.
Mental model: A smoke alarm should detect fires without constantly alarming at normal cooking.
Boundary: No single classifier or keyword list covers every context.
Worked example: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Safeguard evaluation and escalation system
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Recall: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. Identify one observation that would contradict your claim.

### Terms
Safeguard trade-offs: Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The trial gate flags more than two false blocks in ten clearly permitted tasks. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score.
Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.
Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.
Deliverables: Safeguard policy and test harness; Reviewed case set and error analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI safety / safeguards engineer. Use this scenario: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Review: Start with the task and permitted scope. Explain safeguard trade-offs: Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone. Show the input and observed output, then address Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Safeguard policy and test harness; Reviewed case set and error analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Layered safety evidence

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Layered safety evidence
Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable.
Mental model: Several independent barriers can slow an accident more effectively than one warning sign.
Boundary: Multiple layers may share the same blind spot and still require evaluation.
Worked example: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Safeguard evaluation and escalation system
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. Create a human escalation workflow with ownership, response targets and appeal/correction steps. Record known gaps and expected operator actions.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Recall: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. Identify one observation that would contradict your claim.

### Terms
Layered safety evidence: Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create a human escalation workflow with ownership, response targets and appeal/correction steps. Record known gaps and expected operator actions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score.
Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.
Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Create a human escalation workflow with ownership, response targets and appeal/correction steps. Record known gaps and expected operator actions.
Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.
Test a policy update against both old and new cases to detect regressions.
Deliverables: Safeguard policy and test harness; Reviewed case set and error analysis; Escalation operating procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.

### Interview
Explain your advanced solution for AI safety / safeguards engineer. Use this scenario: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Review: Start with the task and permitted scope. Explain layered safety evidence: Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable. Show the input and observed output, then address Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Safeguard policy and test harness; Reviewed case set and error analysis; Escalation operating procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Python — Open source · local
Isolated environments and reproducible scripts.
Alternative: A spreadsheet for manual evidence exercises, or another supported programming language for implementation; reproduce the same acceptance checks.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

NIST AI RMF — Public framework · not a certification
Organize governance questions and evidence; project recommendations are editorial.
Alternative: OECD AI Principles provide another public perspective; frameworks complement one another and are not automatic certifications.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Label Studio — Open source Community · commercial editions optional
Configure annotation tasks and export reviewer judgments.
Alternative: A reviewed CSV workbook for small batches, or a commercial annotation platform; access, adjudication and export matter more than brand.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Python: https://docs.python.org/3/library/venv.html
NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework
Label Studio: https://labelstud.io/guide/quick_start
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/
MLflow: https://mlflow.org/docs/latest/
