# AI safety / safeguards engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Harm scenarios: Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Harm scenarios

Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth. In this role, work through: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A safety inspection asks what could go wrong and who would be hurt.

Boundary: A classroom scenario does not establish a real-world incidence rate.

Worked example: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); NIST AI RMF (Public framework · not a certification); Label Studio (Open source Community · commercial editions optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI safety / safeguards engineer: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route.

Predict the worked case

Read this case without running a tool: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in harm scenarios.

Connect the concept to the role

Apply this rule: Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A classroom scenario does not establish a real-world incidence rate.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies harm scenarios to this case: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Harm scenarios; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with harm scenarios. Use the glossary below, then write your prediction for: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI safety / safeguards engineer role interview. Explain harm scenarios using this case: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate harm scenarios to a system or workflow you know. Explain harm scenarios using this case: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain harm scenarios using this case: A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route.

Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth. — Describe a plausible harmful outcome, affected people and how the system could contribute. Distinguish severity from likelihood and avoid treating one risk number as objective truth. A classroom scenario does not establish a real-world incidence rate.

Sources:

Python: https://docs.python.org/3/library/venv.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/quick_start

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

MLflow: https://mlflow.org/docs/latest/

### Diagnose: The safeguard blocks legitimate requests

The trial gate flags more than two false blocks in ten clearly permitted tasks. Two configurations overblock legitimate tasks beyond the agreed pilot tolerance. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Inspect policy interpretation and calibrate thresholds with allowed neighboring examples. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A safety inspection asks what could go wrong and who would be hurt.

A tutoring answer confidently invents a prerequisite. Record the misleading guidance, affected learner and a correction route.

Worked example: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Inspect policy interpretation and calibrate thresholds with allowed neighboring examples.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Python (Open source · local); NIST AI RMF (Public framework · not a certification); Label Studio (Open source Community · commercial editions optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The trial gate flags more than two false blocks in ten clearly permitted tasks. Two configurations overblock legitimate tasks beyond the agreed pilot tolerance. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The trial gate flags more than two false blocks in ten clearly permitted tasks. Apply this toy-case rule manually: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A safety boundary needs both prohibited and acceptable neighboring cases. Excessive refusal can also make an assistant unhelpful.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Choose a fictional tutor that should explain methods but should not impersonate a student submitting graded work.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A six-case boundary table and two example responses.

Preparation · Try step 2

Write three allowed requests and three requests that cross that boundary.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A six-case boundary table and two example responses.

Preparation · Try step 3

Draft helpful responses for one of each, including what support remains available.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A six-case boundary table and two example responses.

Preparation · Explain and check your result

The rule distinguishes learning support from submitting work as someone else; harmless learning requests are not all refused. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A six-case boundary table and two example responses. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The trial gate flags more than two false blocks in ten clearly permitted tasks. Apply this toy-case rule manually: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two configurations overblock legitimate tasks beyond the agreed pilot tolerance. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two configurations overblock legitimate tasks beyond the agreed pilot tolerance. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the safeguard blocks legitimate requests. Use the glossary below, then write your prediction for: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Inspect policy interpretation and calibrate thresholds with allowed neighboring examples. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI safety / safeguards engineer role interview. Explain diagnose: the safeguard blocks legitimate requests using this case: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Inspect policy interpretation and calibrate thresholds with allowed neighboring examples. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the safeguard blocks legitimate requests to a system or workflow you know. Explain diagnose: the safeguard blocks legitimate requests using this case: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Inspect policy interpretation and calibrate thresholds with allowed neighboring examples. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure both missed violations and false blocks across relevant languages and tasks. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the safeguard blocks legitimate requests using this case: Review when false_blocks >= 3 (out of ten permitted tasks). This is a declared toy-case contract, not an industry standard. Inspect policy interpretation and calibrate thresholds with allowed neighboring examples. State the evidence, one alternative and where the mental model stops.

Quiz: The safeguard blocks legitimate requests: The trial gate flags more than two false blocks in ten clearly permitted tasks.

Change the acceptance rule after seeing an inconvenient result.

Inspect policy interpretation and calibrate thresholds with allowed neighboring examples.

Omit failed cases and report only the successful demonstrations.

Reference: Inspect policy interpretation and calibrate thresholds with allowed neighboring examples. — Inspect policy interpretation and calibrate thresholds with allowed neighboring examples. Measure both missed violations and false blocks across relevant languages and tasks.

Sources:

Python: https://docs.python.org/3/library/venv.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/quick_start

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

MLflow: https://mlflow.org/docs/latest/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Evaluation design, risk analysis and model/application engineering; research roles may need advanced ML expertise.

Terms:

Safeguard trade-offs: Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Safeguard trade-offs

Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone. In this role, work through: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A smoke alarm should detect fires without constantly alarming at normal cooking.

Boundary: No single classifier or keyword list covers every context.

Worked example: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Evaluation design, risk analysis and model/application engineering; research roles may need advanced ML expertise.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); NIST AI RMF (Public framework · not a certification); Label Studio (Open source Community · commercial editions optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI safety / safeguards engineer: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases.

Predict the worked case

Read this case without running a tool: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in safeguard trade-offs.

Connect the concept to the role

Apply this rule: Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: No single classifier or keyword list covers every context.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies safeguard trade-offs to this case: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Safeguard trade-offs; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with safeguard trade-offs. Use the glossary below, then write your prediction for: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI safety / safeguards engineer role interview. Explain safeguard trade-offs using this case: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate safeguard trade-offs to a system or workflow you know. Explain safeguard trade-offs using this case: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain safeguard trade-offs using this case: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases.

Treat a passing starter as proof of the whole role workflow.

Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone.

Ignore the failure because the tool produced an output.

Reference: Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone. — Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone. No single classifier or keyword list covers every context.

Sources:

Python: https://docs.python.org/3/library/venv.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/quick_start

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

MLflow: https://mlflow.org/docs/latest/

### Integrate: Safeguard evaluation and escalation system

Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review. In this role, work through: Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: A smoke alarm should detect fires without constantly alarming at normal cooking.

A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases.

Worked example: Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); NIST AI RMF (Public framework · not a certification); Label Studio (Open source Community · commercial editions optional)

Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The trial gate flags more than two false blocks in ten clearly permitted tasks. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-intermediate-2.md: Safeguard policy and test harness; Reviewed case set and error analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: safeguard evaluation and escalation system. Use the glossary below, then write your prediction for: Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI safety / safeguards engineer role interview. Explain integrate: safeguard evaluation and escalation system using this case: Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: safeguard evaluation and escalation system to a system or workflow you know. Explain integrate: safeguard evaluation and escalation system using this case: Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. Identify one observation that would contradict your claim.

Interview: Explain integrate: safeguard evaluation and escalation system using this case: Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Safeguard evaluation and escalation system at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.

Reference: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. — Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.

Sources:

Python: https://docs.python.org/3/library/venv.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/quick_start

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

MLflow: https://mlflow.org/docs/latest/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Layered safety evidence: Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Layered safety evidence

Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable. In this role, work through: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Several independent barriers can slow an accident more effectively than one warning sign.

Boundary: Multiple layers may share the same blind spot and still require evaluation.

Worked example: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); NIST AI RMF (Public framework · not a certification); Label Studio (Open source Community · commercial editions optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI safety / safeguards engineer: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it.

Predict the worked case

Read this case without running a tool: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in layered safety evidence.

Connect the concept to the role

Apply this rule: Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Multiple layers may share the same blind spot and still require evaluation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies layered safety evidence to this case: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Layered safety evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with layered safety evidence. Use the glossary below, then write your prediction for: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI safety / safeguards engineer role interview. Explain layered safety evidence using this case: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate layered safety evidence to a system or workflow you know. Explain layered safety evidence using this case: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain layered safety evidence using this case: If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable.

Reference: Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable. — Combine input handling, bounded actions, output review and escalation. Record which layer addresses each failure and what happens if a layer is unavailable. Multiple layers may share the same blind spot and still require evaluation.

Sources:

Python: https://docs.python.org/3/library/venv.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/quick_start

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

MLflow: https://mlflow.org/docs/latest/

### Defend: Safeguard evaluation and escalation system

Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. Create a human escalation workflow with ownership, response targets and appeal/correction steps. Record known gaps and expected operator actions. In this role, work through: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: Several independent barriers can slow an accident more effectively than one warning sign.

If the output checker is unavailable for a consequential workflow, route to review rather than silently bypassing it.

Worked example: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); NIST AI RMF (Public framework · not a certification); Label Studio (Open source Community · commercial editions optional)

Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Create a human escalation workflow with ownership, response targets and appeal/correction steps. Record known gaps and expected operator actions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-advanced-2.md: Safeguard policy and test harness; Reviewed case set and error analysis; Escalation operating procedure. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: safeguard evaluation and escalation system. Use the glossary below, then write your prediction for: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI safety / safeguards engineer role interview. Explain defend: safeguard evaluation and escalation system using this case: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: safeguard evaluation and escalation system to a system or workflow you know. Explain defend: safeguard evaluation and escalation system using this case: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. Identify one observation that would contradict your claim.

Interview: Explain defend: safeguard evaluation and escalation system using this case: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Safeguard evaluation and escalation system at this level?

Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate. — Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate. Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.

Sources:

Python: https://docs.python.org/3/library/venv.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Label Studio: https://labelstud.io/guide/quick_start

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

MLflow: https://mlflow.org/docs/latest/
