# Safeguard evaluation and escalation system

Career: AI safety / safeguards engineer
Reviewed: 2026-10-22

Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score.

## Prerequisites
Evaluation design, risk analysis and model/application engineering; research roles may need advanced ML expertise.

## Included starter versus your implementation
A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+; the scoring skeleton needs only the standard library.

```sh
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Create a human escalation workflow with ownership, response targets and appeal/correction steps. Record known gaps and expected operator actions.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Safeguard policy and test harness — artifact-1.md
2. Reviewed case set and error analysis — artifact-2.md
3. Escalation operating procedure — artifact-3.md

## Troubleshooting
- Missing predictions: keep them in the denominator.
- Metric disagrees with humans: inspect rubric validity before optimizing the model.
- Scores change: compare candidate, dataset and evaluator versions separately.

## Extension
Test a policy update against both old and new cases to detect regressions.

## Primary learning resources
- Python: https://docs.python.org/3/library/venv.html — Open source · local; Isolated environments and reproducible scripts.
- NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework — Public framework · not a certification; Organize governance questions and evidence; project recommendations are editorial.
- Label Studio: https://labelstud.io/guide/quick_start — Open source Community · commercial editions optional; Configure annotation tasks and export reviewer judgments.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
