## intermediate — Safeguard trade-offs

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Evaluation design, risk analysis and model/application engineering; research roles may need advanced ML expertise.

### Safeguard trade-offs
Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone.
Mental model: A smoke alarm should detect fires without constantly alarming at normal cooking.
Boundary: No single classifier or keyword list covers every context.
Worked example: A filter blocks a harmless educational question. Include it in the false-positive set while preserving genuinely disallowed cases.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Safeguard evaluation and escalation system
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Recall: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. Identify one observation that would contradict your claim.

### Terms
Safeguard trade-offs: Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The trial gate flags more than two false blocks in ten clearly permitted tasks. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Design and evaluate safeguards for a bounded assistant without reducing safety to a single classifier score.
Define a fictional customer-support scope, allowed content, escalation categories and 40 benign/boundary test cases. Avoid collecting real sensitive conversations.
Use the evaluation starter to track decisions and reasons. Write rubric examples for allow, clarify, refuse and escalate; define handling for uncertainty.
Implement a simple deterministic baseline, then compare a model-based safeguard if available. Separate pre-generation input handling from output review.
Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee.
Deliverables: Safeguard policy and test harness; Reviewed case set and error analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI safety / safeguards engineer. Use this scenario: Include benign requests containing alarming words and harmful implications phrased politely. Inspect false refusals and missed context rather than optimizing a single pass rate.
Review: Start with the task and permitted scope. Explain safeguard trade-offs: Measure both missed harmful cases and blocked legitimate cases. Review ambiguous examples with a declared policy instead of optimizing refusal counts alone. Show the input and observed output, then address Report false refusal and missed escalation by category, reviewer agreement and unresolved cases. The project is a scoped evaluation, not a universal safety guarantee. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Safeguard policy and test harness; Reviewed case set and error analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

