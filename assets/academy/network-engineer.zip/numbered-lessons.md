# Network Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Layered diagnosis: Check local process, address resolution, connection and application response separately.

Apply layered diagnosis in Network Engineer: Use the concept to complete this role exercise: Explain name resolution, loopback and destination ports

DNS, transport and application layers: Name resolution maps names to addresses; transport connects endpoints; application protocols define responses. Diagnose each boundary independently.

### Layered diagnosis

Check local process, address resolution, connection and application response separately. In this role, work through: localhost resolves, port connects and /missing returns 404: the last failure is application-level. The practical workshop develops this into: Run the loopback diagnostic and record resolution, port and HTTP observations. Draw source address/port and destination address/port for one request. Mark which endpoint is the client and which is the server.

Mental model: Follow a letter from address book to road to reception desk.

Boundary: Layers interact; one successful check does not establish every other layer.

Role application: Find the address, travel to it, then ask the receptionist for the correct room.

Name resolution maps names to addresses; transport connects endpoints; application protocols define responses. Diagnose each boundary independently.

Worked example: localhost resolves, port connects and /missing returns 404: the last failure is application-level.

Shared foundation example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: OS DNS and connection diagnostics (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Network Engineer: localhost resolves, port connects and /missing returns 404: the last failure is application-level.

Predict the worked case

Read this case without running a tool: localhost resolves, port connects and /missing returns 404: the last failure is application-level. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in layered diagnosis.

Connect the concept to the role

Apply this rule: Check local process, address resolution, connection and application response separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Layers interact; one successful check does not establish every other layer.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies layered diagnosis to this case: localhost resolves, port connects and /missing returns 404: the last failure is application-level. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: localhost resolves, port connects and /missing returns 404: the last failure is application-level. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Layered diagnosis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with layered diagnosis. Use the glossary below, then write your prediction for: localhost resolves, port connects and /missing returns 404: the last failure is application-level. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Network Engineer role interview. Explain layered diagnosis using this case: localhost resolves, port connects and /missing returns 404: the last failure is application-level. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate layered diagnosis to a system or workflow you know. Explain layered diagnosis using this case: localhost resolves, port connects and /missing returns 404: the last failure is application-level. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is a 404 different from connection refused?

Interview: Explain layered diagnosis using this case: localhost resolves, port connects and /missing returns 404: the last failure is application-level. State the evidence, one alternative and where the mental model stops.

Quiz: After the DNS, transport and application layers rehearsal, check this foundation: A request returns HTTP 500 rather than connection refused. Which next step best follows the evidence?

Inspect application and upstream error evidence for that request.

Assume DNS failed before any server response.

Immediately rewrite the local firewall policy.

Reference: Inspect application and upstream error evidence for that request. — An HTTP response points beyond the basic connection boundary; identify its origin before diagnosing the application.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### DNS, transport and application layers

Name resolution maps names to addresses; transport connects endpoints; application protocols define responses. Diagnose each boundary independently. In this role, work through: localhost resolves, port connects and /missing returns 404: the last failure is application-level. The practical workshop develops this into: Run the loopback diagnostic and record resolution, port and HTTP observations. Draw source address/port and destination address/port for one request. Mark which endpoint is the client and which is the server.

Mental model: Find the address, travel to it, then ask the receptionist for the correct room.

Boundary: A successful ping does not verify the application port or HTTP route.

Worked example: localhost resolves, port connects and /missing returns 404: the last failure is application-level.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OS DNS and connection diagnostics (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Network Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run the loopback diagnostic and record resolution, port and HTTP observations. Draw source address/port and destination address/port for one request. Mark which endpoint is the client and which is the server.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

localhost resolves, port connects and /missing returns 404: the last failure is application-level. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run the loopback diagnostic and record resolution, port and HTTP observations. Draw source address/port and destination address/port for one request. Mark which endpoint is the client and which is the server.

```
python3 diagnose.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A four-tuple and layered diagnosis for each fixture.

Role workshop · debug and verify

A successful ping does not verify the application port or HTTP route. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save network trace worksheet. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A four-tuple and layered diagnosis for each fixture.

Expected: A four-tuple and layered diagnosis for each fixture.

Troubleshoot: The role exercise differs from the prediction: A successful ping does not verify the application port or HTTP route.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: network trace worksheet; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with dns, transport and application layers. Use the glossary below, then write your prediction for: localhost resolves, port connects and /missing returns 404: the last failure is application-level. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Network Engineer role interview. Explain dns, transport and application layers using this case: localhost resolves, port connects and /missing returns 404: the last failure is application-level. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate dns, transport and application layers to a system or workflow you know. Explain dns, transport and application layers using this case: localhost resolves, port connects and /missing returns 404: the last failure is application-level. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful ping does not verify the application port or HTTP route.

Interview: Explain dns, transport and application layers using this case: localhost resolves, port connects and /missing returns 404: the last failure is application-level. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? localhost resolves, port connects and /missing returns 404: the last failure is application-level.

A four-tuple and layered diagnosis for each fixture.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A four-tuple and layered diagnosis for each fixture. — Name resolution maps names to addresses; transport connects endpoints; application protocols define responses. Diagnose each boundary independently. A four-tuple and layered diagnosis for each fixture.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Least privilege and change scope: Use only the rights required for the task and record exactly what you intend to change.

Apply least privilege and change scope in Network Engineer: Use the concept to complete this role exercise: Trace a request from DNS through connection to application status

Routing and name-resolution evidence: A routing path and a DNS answer can each be correct while the intended service is unavailable. Use approved packet capture and route inspection to test a hypothesis.

### Least privilege and change scope

Use only the rights required for the task and record exactly what you intend to change. In this role, work through: Two DNS answers can send clients to different endpoints during a change. The practical workshop develops this into: In a disposable environment compare approved DNS lookup results, local route table and a connection attempt. If capturing packets, capture only lab traffic and identify handshake versus application failure.

Mental model: Borrow a key to one room rather than the master key.

Boundary: Permissions cannot replace backups or ownership of a change.

Role application: A correct street address does not guarantee the road is open.

A routing path and a DNS answer can each be correct while the intended service is unavailable. Use approved packet capture and route inspection to test a hypothesis.

Worked example: Two DNS answers can send clients to different endpoints during a change.

Shared foundation example: Run the loopback diagnostic without changing DNS or firewall settings.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: OS DNS and connection diagnostics (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Network Engineer: Two DNS answers can send clients to different endpoints during a change.

Predict the worked case

Read this case without running a tool: Two DNS answers can send clients to different endpoints during a change. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in least privilege and change scope.

Connect the concept to the role

Apply this rule: Use only the rights required for the task and record exactly what you intend to change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Permissions cannot replace backups or ownership of a change.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies least privilege and change scope to this case: Two DNS answers can send clients to different endpoints during a change. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two DNS answers can send clients to different endpoints during a change. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Least privilege and change scope; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with least privilege and change scope. Use the glossary below, then write your prediction for: Two DNS answers can send clients to different endpoints during a change. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Network Engineer role interview. Explain least privilege and change scope using this case: Two DNS answers can send clients to different endpoints during a change. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate least privilege and change scope to a system or workflow you know. Explain least privilege and change scope using this case: Two DNS answers can send clients to different endpoints during a change. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What information should a change ticket contain before modifying a network setting?

Interview: Explain least privilege and change scope using this case: Two DNS answers can send clients to different endpoints during a change. State the evidence, one alternative and where the mental model stops.

Quiz: After the Routing and name-resolution evidence rehearsal, check this foundation: A diagnostic only needs to read a local log. Which access is appropriate?

Permanent administrator rights for convenience.

The narrow read permission required for that log.

Write access to every service configuration.

Reference: The narrow read permission required for that log. — Match permissions to the task. Extra privileges add risk without evidence that they are required.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Routing and name-resolution evidence

A routing path and a DNS answer can each be correct while the intended service is unavailable. Use approved packet capture and route inspection to test a hypothesis. In this role, work through: Two DNS answers can send clients to different endpoints during a change. The practical workshop develops this into: In a disposable environment compare approved DNS lookup results, local route table and a connection attempt. If capturing packets, capture only lab traffic and identify handshake versus application failure.

Mental model: A correct street address does not guarantee the road is open.

Boundary: Do not capture unrelated users' traffic or infer packet loss from one missing response.

Worked example: Two DNS answers can send clients to different endpoints during a change.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OS DNS and connection diagnostics (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Network Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

In a disposable environment compare approved DNS lookup results, local route table and a connection attempt. If capturing packets, capture only lab traffic and identify handshake versus application failure.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Two DNS answers can send clients to different endpoints during a change. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

In a disposable environment compare approved DNS lookup results, local route table and a connection attempt. If capturing packets, capture only lab traffic and identify handshake versus application failure.

Expected: A hypothesis supported by timestamps and packet/command evidence.

Role workshop · debug and verify

Do not capture unrelated users' traffic or infer packet loss from one missing response. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save redacted diagnostic capture and hypothesis log. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A hypothesis supported by timestamps and packet/command evidence.

Expected: A hypothesis supported by timestamps and packet/command evidence.

Troubleshoot: The role exercise differs from the prediction: Do not capture unrelated users' traffic or infer packet loss from one missing response.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: redacted diagnostic capture and hypothesis log; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with routing and name-resolution evidence. Use the glossary below, then write your prediction for: Two DNS answers can send clients to different endpoints during a change. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Network Engineer role interview. Explain routing and name-resolution evidence using this case: Two DNS answers can send clients to different endpoints during a change. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate routing and name-resolution evidence to a system or workflow you know. Explain routing and name-resolution evidence using this case: Two DNS answers can send clients to different endpoints during a change. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not capture unrelated users' traffic or infer packet loss from one missing response.

Interview: Explain routing and name-resolution evidence using this case: Two DNS answers can send clients to different endpoints during a change. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Two DNS answers can send clients to different endpoints during a change.

Ignore the failing case and keep only the successful screenshot.

A hypothesis supported by timestamps and packet/command evidence.

Treat any successful command as proof that all business and access rules passed.

Reference: A hypothesis supported by timestamps and packet/command evidence. — A routing path and a DNS answer can each be correct while the intended service is unavailable. Use approved packet capture and route inspection to test a hypothesis. A hypothesis supported by timestamps and packet/command evidence.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Recovery evidence: A recovery is complete when the original user operation works and important side effects have been checked.

Apply recovery evidence in Network Engineer: Use the concept to complete this role exercise: Write a change plan with routing checks, rollback trigger and outage evidence

Network change rollback: A network change needs baseline reachability, out-of-band recovery and a bounded validation window. Account for stateful sessions and DNS caching when interpreting recovery.

### Recovery evidence

A recovery is complete when the original user operation works and important side effects have been checked. In this role, work through: A route change that loses management access needs a preplanned recovery path. The practical workshop develops this into: Write a lab change plan with before/after flow matrices, exact rollback and owner. Simulate a blocked service in a disposable environment and verify both management and user flows after recovery.

Mental model: Repair a tap, then test water flow and inspect for leaks.

Boundary: One successful retry does not establish long-term reliability.

Role application: Keep an alternate route before closing the only road back to the control room.

A network change needs baseline reachability, out-of-band recovery and a bounded validation window. Account for stateful sessions and DNS caching when interpreting recovery.

Worked example: A route change that loses management access needs a preplanned recovery path.

Shared foundation example: After correcting a path, record HTTP status, timestamp and the user-visible result.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: OS DNS and connection diagnostics (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Network Engineer: A route change that loses management access needs a preplanned recovery path.

Predict the worked case

Read this case without running a tool: A route change that loses management access needs a preplanned recovery path. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in recovery evidence.

Connect the concept to the role

Apply this rule: A recovery is complete when the original user operation works and important side effects have been checked. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: One successful retry does not establish long-term reliability.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies recovery evidence to this case: A route change that loses management access needs a preplanned recovery path. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A route change that loses management access needs a preplanned recovery path. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Recovery evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with recovery evidence. Use the glossary below, then write your prediction for: A route change that loses management access needs a preplanned recovery path. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Network Engineer role interview. Explain recovery evidence using this case: A route change that loses management access needs a preplanned recovery path. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate recovery evidence to a system or workflow you know. Explain recovery evidence using this case: A route change that loses management access needs a preplanned recovery path. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would you record for the next person handling the incident?

Interview: Explain recovery evidence using this case: A route change that loses management access needs a preplanned recovery path. State the evidence, one alternative and where the mental model stops.

Quiz: After the Network change rollback rehearsal, check this foundation: A repair command succeeds after an outage. Which check most directly tests recovery?

Confirm that a process exists.

Confirm the runbook file was opened.

Repeat the original user operation and inspect important side effects.

Reference: Repeat the original user operation and inspect important side effects. — Recovery must be measured at the affected operation, not inferred solely from a successful repair command.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Network change rollback

A network change needs baseline reachability, out-of-band recovery and a bounded validation window. Account for stateful sessions and DNS caching when interpreting recovery. In this role, work through: A route change that loses management access needs a preplanned recovery path. The practical workshop develops this into: Write a lab change plan with before/after flow matrices, exact rollback and owner. Simulate a blocked service in a disposable environment and verify both management and user flows after recovery.

Mental model: Keep an alternate route before closing the only road back to the control room.

Boundary: A single restored connection does not prove every required flow recovered; rerun the matrix.

Worked example: A route change that loses management access needs a preplanned recovery path.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: OS DNS and connection diagnostics (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Network Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a lab change plan with before/after flow matrices, exact rollback and owner. Simulate a blocked service in a disposable environment and verify both management and user flows after recovery.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A route change that loses management access needs a preplanned recovery path. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a lab change plan with before/after flow matrices, exact rollback and owner. Simulate a blocked service in a disposable environment and verify both management and user flows after recovery.

Expected: A tested recovery sequence or clearly marked tabletop evidence.

Role workshop · debug and verify

A single restored connection does not prove every required flow recovered; rerun the matrix. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save network change record and post-change evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A tested recovery sequence or clearly marked tabletop evidence.

Expected: A tested recovery sequence or clearly marked tabletop evidence.

Troubleshoot: The role exercise differs from the prediction: A single restored connection does not prove every required flow recovered; rerun the matrix.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: network change record and post-change evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with network change rollback. Use the glossary below, then write your prediction for: A route change that loses management access needs a preplanned recovery path. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Network Engineer role interview. Explain network change rollback using this case: A route change that loses management access needs a preplanned recovery path. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate network change rollback to a system or workflow you know. Explain network change rollback using this case: A route change that loses management access needs a preplanned recovery path. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A single restored connection does not prove every required flow recovered; rerun the matrix.

Interview: Explain network change rollback using this case: A route change that loses management access needs a preplanned recovery path. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A route change that loses management access needs a preplanned recovery path.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A tested recovery sequence or clearly marked tabletop evidence.

Reference: A tested recovery sequence or clearly marked tabletop evidence. — A network change needs baseline reachability, out-of-band recovery and a bounded validation window. Account for stateful sessions and DNS caching when interpreting recovery. A tested recovery sequence or clearly marked tabletop evidence.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
