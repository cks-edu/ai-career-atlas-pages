# Network Engineer

Software Engineering

Start with dns, transport and application layers. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward network change record and post-change evidence.

## beginner

Run the loopback diagnostic and record resolution, port and HTTP observations. Draw source address/port and destination address/port for one request. Mark which endpoint is the client and which is the server.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Layered diagnosis
Check local process, address resolution, connection and application response separately.
Mental model: Follow a letter from address book to road to reception desk.
Limit: Layers interact; one successful check does not establish every other layer.
Example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path.
Recall: Why is a 404 different from connection refused?

### DNS, transport and application layers
Name resolution maps names to addresses; transport connects endpoints; application protocols define responses. Diagnose each boundary independently.
Mental model: Find the address, travel to it, then ask the receptionist for the correct room.
Limit: A successful ping does not verify the application port or HTTP route.
Example: localhost resolves, port connects and /missing returns 404: the last failure is application-level.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful ping does not verify the application port or HTTP route.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
localhost resolves, port connects and /missing returns 404: the last failure is application-level. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run the loopback diagnostic and record resolution, port and HTTP observations. Draw source address/port and destination address/port for one request. Mark which endpoint is the client and which is the server.
```
python3 diagnose.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A four-tuple and layered diagnosis for each fixture.

6. Role workshop · debug and verify
A successful ping does not verify the application port or HTTP route. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save network trace worksheet. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A four-tuple and layered diagnosis for each fixture.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
DNS, transport and application layers: A successful ping does not verify the application port or HTTP route.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: network trace worksheet
A four-tuple and layered diagnosis for each fixture.

Interview: Work through this Network Engineer case: localhost resolves, port connects and /missing returns 404: the last failure is application-level. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Name resolution maps names to addresses; transport connects endpoints; application protocols define responses. Diagnose each boundary independently. Expected evidence: A four-tuple and layered diagnosis for each fixture. Diagnosis: A successful ping does not verify the application port or HTTP route. State the limits of the mental model: Find the address, travel to it, then ask the receptionist for the correct room.

Resume: Built network trace worksheet using OS DNS and connection diagnostics; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

In a disposable environment compare approved DNS lookup results, local route table and a connection attempt. If capturing packets, capture only lab traffic and identify handshake versus application failure.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Least privilege and change scope
Use only the rights required for the task and record exactly what you intend to change.
Mental model: Borrow a key to one room rather than the master key.
Limit: Permissions cannot replace backups or ownership of a change.
Example: Run the loopback diagnostic without changing DNS or firewall settings.
Recall: What information should a change ticket contain before modifying a network setting?

### Routing and name-resolution evidence
A routing path and a DNS answer can each be correct while the intended service is unavailable. Use approved packet capture and route inspection to test a hypothesis.
Mental model: A correct street address does not guarantee the road is open.
Limit: Do not capture unrelated users' traffic or infer packet loss from one missing response.
Example: Two DNS answers can send clients to different endpoints during a change.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not capture unrelated users' traffic or infer packet loss from one missing response.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Two DNS answers can send clients to different endpoints during a change. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
In a disposable environment compare approved DNS lookup results, local route table and a connection attempt. If capturing packets, capture only lab traffic and identify handshake versus application failure.
Expected: A hypothesis supported by timestamps and packet/command evidence.

6. Role workshop · debug and verify
Do not capture unrelated users' traffic or infer packet loss from one missing response. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save redacted diagnostic capture and hypothesis log. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A hypothesis supported by timestamps and packet/command evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Routing and name-resolution evidence: Do not capture unrelated users' traffic or infer packet loss from one missing response.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: redacted diagnostic capture and hypothesis log
A hypothesis supported by timestamps and packet/command evidence.

Interview: Work through this Network Engineer case: Two DNS answers can send clients to different endpoints during a change. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A routing path and a DNS answer can each be correct while the intended service is unavailable. Use approved packet capture and route inspection to test a hypothesis. Expected evidence: A hypothesis supported by timestamps and packet/command evidence. Diagnosis: Do not capture unrelated users' traffic or infer packet loss from one missing response. State the limits of the mental model: A correct street address does not guarantee the road is open.

Resume: Built redacted diagnostic capture and hypothesis log using OS DNS and connection diagnostics; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write a lab change plan with before/after flow matrices, exact rollback and owner. Simulate a blocked service in a disposable environment and verify both management and user flows after recovery.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Recovery evidence
A recovery is complete when the original user operation works and important side effects have been checked.
Mental model: Repair a tap, then test water flow and inspect for leaks.
Limit: One successful retry does not establish long-term reliability.
Example: After correcting a path, record HTTP status, timestamp and the user-visible result.
Recall: What would you record for the next person handling the incident?

### Network change rollback
A network change needs baseline reachability, out-of-band recovery and a bounded validation window. Account for stateful sessions and DNS caching when interpreting recovery.
Mental model: Keep an alternate route before closing the only road back to the control room.
Limit: A single restored connection does not prove every required flow recovered; rerun the matrix.
Example: A route change that loses management access needs a preplanned recovery path.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A single restored connection does not prove every required flow recovered; rerun the matrix.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A route change that loses management access needs a preplanned recovery path. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a lab change plan with before/after flow matrices, exact rollback and owner. Simulate a blocked service in a disposable environment and verify both management and user flows after recovery.
Expected: A tested recovery sequence or clearly marked tabletop evidence.

6. Role workshop · debug and verify
A single restored connection does not prove every required flow recovered; rerun the matrix. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save network change record and post-change evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A tested recovery sequence or clearly marked tabletop evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Network change rollback: A single restored connection does not prove every required flow recovered; rerun the matrix.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: network change record and post-change evidence
A tested recovery sequence or clearly marked tabletop evidence.

Interview: Work through this Network Engineer case: A route change that loses management access needs a preplanned recovery path. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A network change needs baseline reachability, out-of-band recovery and a bounded validation window. Account for stateful sessions and DNS caching when interpreting recovery. Expected evidence: A tested recovery sequence or clearly marked tabletop evidence. Diagnosis: A single restored connection does not prove every required flow recovered; rerun the matrix. State the limits of the mental model: Keep an alternate route before closing the only road back to the control room.

Resume: Built network change record and post-change evidence using OS DNS and connection diagnostics; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting
Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html
Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
