# Network Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
DNS, transport and application layers

Name resolution maps names to addresses; transport connects endpoints; application protocols define responses. Diagnose each boundary independently.
Mental model: Find the address, travel to it, then ask the receptionist for the correct room.
Case: localhost resolves, port connects and /missing returns 404: the last failure is application-level.
Task: Run the loopback diagnostic and record resolution, port and HTTP observations. Draw source address/port and destination address/port for one request. Mark which endpoint is the client and which is the server.
Acceptance: A four-tuple and layered diagnosis for each fixture.
Troubleshooting: A successful ping does not verify the application port or HTTP route.
Deliverable: network trace worksheet

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Routing and name-resolution evidence

A routing path and a DNS answer can each be correct while the intended service is unavailable. Use approved packet capture and route inspection to test a hypothesis.
Mental model: A correct street address does not guarantee the road is open.
Case: Two DNS answers can send clients to different endpoints during a change.
Task: In a disposable environment compare approved DNS lookup results, local route table and a connection attempt. If capturing packets, capture only lab traffic and identify handshake versus application failure.
Acceptance: A hypothesis supported by timestamps and packet/command evidence.
Troubleshooting: Do not capture unrelated users' traffic or infer packet loss from one missing response.
Deliverable: redacted diagnostic capture and hypothesis log

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Network change rollback

A network change needs baseline reachability, out-of-band recovery and a bounded validation window. Account for stateful sessions and DNS caching when interpreting recovery.
Mental model: Keep an alternate route before closing the only road back to the control room.
Case: A route change that loses management access needs a preplanned recovery path.
Task: Write a lab change plan with before/after flow matrices, exact rollback and owner. Simulate a blocked service in a disposable environment and verify both management and user flows after recovery.
Acceptance: A tested recovery sequence or clearly marked tabletop evidence.
Troubleshooting: A single restored connection does not prove every required flow recovered; rerun the matrix.
Deliverable: network change record and post-change evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
