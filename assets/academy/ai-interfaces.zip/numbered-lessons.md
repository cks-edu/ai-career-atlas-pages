# AI Interfaces & Streaming — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## intermediate

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

reducer: A function that returns the next state from current state and an event.

stale: Belonging to an earlier request or version.

NDJSON: One complete JSON value per newline-delimited record.

buffer: Data retained until enough input arrives to process it.

AbortController: A browser API for signalling cancellation to supported operations.

partial: Received content that is not a verified complete result.

live region: A region assistive technology can announce when its content changes.

focus: The element receiving keyboard interaction.

### Streaming UI: requests own their state

Streaming answers arrive in pieces. If a second request starts before the first ends, late chunks from the old request can overwrite the new answer. Give each request an ID, and let the UI accept chunks only for the active request.

Keep activeId, text and status in one reducer. Starting a request clears the previous draft. A chunk from any other ID leaves the state unchanged. A real DOM view renders this state; the local sandbox tests the reducer only.

Ignoring a late chunk does not cancel the server’s inference or billing. Pair UI ownership with AbortController and an appropriate server cancellation policy.

Mental model: User submit → new request ID → stream chunks → rendered draft. Picture the boundary as a checked gate between stages.

Boundary: Ignoring a late chunk does not cancel the server’s inference or billing. Pair UI ownership with AbortController and an appropriate server cancellation policy.

Worked example: function streamState(state, event) {
  if (event.type === 'START') return {activeId:event.id,text:'',status:'streaming'};
  if (event.id !== state.activeId || state.status !== 'streaming') return state;
  if (event.type === 'CHUNK') return {...state,text:state.text + event.text};
  if (event.type === 'DONE') return {...state,status:'done'};
  return state;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-interfaces.zip, install Node.js LTS, then open production-ai/02-01-stream-request-state.

Tools for this exercise: JavaScript · local isolated workbench; Fetch / Streams API, WAI / WCAG as documented optional extensions

Course tool and framework map: Fetch / Streams API (Open web standard · local); WAI / WCAG (Open accessibility standard)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement streamState. Replay START a, START b, CHUNK a, CHUNK b and DONE b. Then connect this reducer to your own DOM outside the isolated sandbox.

Terminal folder: production-ai/02-01-stream-request-state

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Keep activeId, text and status in one reducer. Starting a request clears the previous draft. A chunk from any other ID leaves the state unchanged. A real DOM view renders this state; the local sandbox tests the reducer only.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement streamState. Replay START a, START b, CHUNK a, CHUNK b and DONE b. Then connect this reducer to your own DOM outside the isolated sandbox.

Expected: A new request clears the old answer

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Stale chunks cannot overwrite state; Only active chunks append before completion

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A new request clears the old answer; Stale chunks cannot overwrite state; Only active chunks append before completion. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Reject stale request IDs in the reducer. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/02-01-stream-request-state/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: User submit → new request ID → stream chunks → rendered draft. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Two streams overlap. How do you prevent an old answer from changing the new one? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Only the active request may change its draft. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Two streams overlap. How do you prevent an old answer from changing the new one?

Interview: Two streams overlap. How do you prevent an old answer from changing the new one? Explain the decision, a failing case and a production limitation.

Quiz: Two streams overlap. How do you prevent an old answer from changing the new one?

Increase the font size.

Append all chunks in arrival order.

Bind updates to the active request ID.

Reference: Bind updates to the active request ID. — The reducer must enforce ownership. Arrival order alone does not identify the user’s current request.

Sources:

MDN: using Fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

MDN: using readable streams: https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Using_readable_streams

### A network chunk is not a message

A transport can split a logical message across reads or deliver several messages in one read. Never call JSON.parse on every raw chunk and assume it contains exactly one object. Buffer text until the agreed delimiter appears.

This exercise uses newline-delimited JSON, not the full Server-Sent Events protocol. Keep the incomplete tail between reads and parse only complete nonempty lines. In a real UTF-8 stream, use a streaming TextDecoder so multi-byte characters can cross byte chunks.

Production parsers also need size limits, protocol errors and an explicit end-of-stream policy. NDJSON framing is not interchangeable with SSE data fields.

Mental model: Byte reads → streaming decode → text buffer → complete records. Picture the boundary as a checked gate between stages.

Boundary: Production parsers also need size limits, protocol errors and an explicit end-of-stream policy. NDJSON framing is not interchangeable with SSE data fields.

Worked example: function readLines(remainder, chunk) {
  const lines = (remainder + chunk).split('\n');
  const tail = lines.pop();
  return {items:lines.filter(x => x.trim()).map(x => JSON.parse(x)),remainder:tail};
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-interfaces.zip, install Node.js LTS, then open production-ai/02-02-stream-framing.

Tools for this exercise: JavaScript · local isolated workbench; Fetch / Streams API, WAI / WCAG as documented optional extensions

Course tool and framework map: Fetch / Streams API (Open web standard · local); WAI / WCAG (Open accessibility standard)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement the NDJSON buffer, test every possible split in a short record, and document an end-of-stream error policy.

Terminal folder: production-ai/02-02-stream-framing

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This exercise uses newline-delimited JSON, not the full Server-Sent Events protocol. Keep the incomplete tail between reads and parse only complete nonempty lines. In a real UTF-8 stream, use a streaming TextDecoder so multi-byte characters can cross byte chunks.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement the NDJSON buffer, test every possible split in a short record, and document an end-of-stream error policy.

Expected: One complete line parses

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Split records retain the tail; Several records and blank lines work

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: One complete line parses; Split records retain the tail; Several records and blank lines work. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Parse complete newline-delimited records and retain the tail. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/02-02-stream-framing/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Byte reads → streaming decode → text buffer → complete records. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A read contains half a JSON object. What should the stream parser do? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Transport reads do not define application message boundaries. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A read contains half a JSON object. What should the stream parser do?

Interview: A read contains half a JSON object. What should the stream parser do? Explain the decision, a failing case and a production limitation.

Quiz: A read contains half a JSON object. What should the stream parser do?

Buffer it until the record delimiter arrives.

Invent the missing fields.

Treat the truncated object as the final answer.

Reference: Buffer it until the record delimiter arrives. — Separate transport framing from logical records. The receiver must retain incomplete text without claiming completion.

Sources:

MDN: using readable streams: https://developer.mozilla.org/en-US/docs/Web/API/Streams_API/Using_readable_streams

### Cancellation and honest partial answers

Stopping a stream is a state change, not proof that the server completed the task. Keep the received draft as partial and prevent later completion events from changing a cancelled request into success. Give the user a clear retry action.

CANCEL changes streaming to cancelled and preserves the draft. DONE changes only a streaming request to complete. In an actual fetch, AbortController interrupts client-side consumption; separately check how the backend cancels its work.

Client abort does not guarantee that remote work stopped or that a billable operation was undone. Never label a partial answer complete.

Mental model: Stop action → cancelled state → abort signal → user decision. Picture the boundary as a checked gate between stages.

Boundary: Client abort does not guarantee that remote work stopped or that a billable operation was undone. Never label a partial answer complete.

Worked example: function cancelState(state, event) {
  if (state.status !== 'streaming') return state;
  if (event === 'CANCEL') return {...state,status:'cancelled'};
  if (event === 'DONE') return {...state,status:'complete'};
  return state;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-interfaces.zip, install Node.js LTS, then open production-ai/02-03-stream-cancellation.

Tools for this exercise: JavaScript · local isolated workbench; Fetch / Streams API, WAI / WCAG as documented optional extensions

Course tool and framework map: Fetch / Streams API (Open web standard · local); WAI / WCAG (Open accessibility standard)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement cancelState and a late-DONE test. Build a small DOM demo with a Stop button, partial label and AbortController using the official Fetch guide.

Terminal folder: production-ai/02-03-stream-cancellation

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

CANCEL changes streaming to cancelled and preserves the draft. DONE changes only a streaming request to complete. In an actual fetch, AbortController interrupts client-side consumption; separately check how the backend cancels its work.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement cancelState and a late-DONE test. Build a small DOM demo with a Stop button, partial label and AbortController using the official Fetch guide.

Expected: Cancel preserves the partial answer

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Late completion is ignored; Normal completion and unknown events differ

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Cancel preserves the partial answer; Late completion is ignored; Normal completion and unknown events differ. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Accept DONE only from streaming state. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/02-03-stream-cancellation/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Stop action → cancelled state → abort signal → user decision. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. The browser aborts a stream. What may the UI truthfully claim? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A received completion event cannot resurrect a cancelled run. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: The browser aborts a stream. What may the UI truthfully claim?

Interview: The browser aborts a stream. What may the UI truthfully claim? Explain the decision, a failing case and a production limitation.

Quiz: The browser aborts a stream. What may the UI truthfully claim?

The server never ran.

The local request was stopped; remote completion may need checking.

The answer is complete.

Reference: The local request was stopped; remote completion may need checking. — Cancellation has a scope. Preserve that distinction when reporting status or retrying an operation.

Sources:

MDN: using Fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch

### Accessible status without announcing every token

A streaming page needs accessible feedback, but announcing every token can make it unusable. Keep the answer readable and announce meaningful status transitions: started, finished, stopped or failed. Avoid moving keyboard focus whenever a chunk arrives.

Produce a short status message when the status changes. Ordinary text chunks leave the status message unchanged. A DOM implementation can put that message in a polite live region and keep the stream text outside it.

A string function is not an accessibility audit. Check keyboard control, focus, screen readers, contrast and reduced motion in the complete interface.

Mental model: Status transition → concise live message → learner reads the answer. Picture the boundary as a checked gate between stages.

Boundary: A string function is not an accessibility audit. Check keyboard control, focus, screen readers, contrast and reduced motion in the complete interface.

Worked example: function statusMessage(previous, current) {
  if (previous === current) return '';
  return {streaming:'Answer started.',complete:'Answer ready.',cancelled:'Answer stopped; partial text remains.',error:'Answer failed; try again.'}[current] || '';
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-interfaces.zip, install Node.js LTS, then open production-ai/02-04-stream-accessibility.

Tools for this exercise: JavaScript · local isolated workbench; Fetch / Streams API, WAI / WCAG as documented optional extensions

Course tool and framework map: Fetch / Streams API (Open web standard · local); WAI / WCAG (Open accessibility standard)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement statusMessage. Add a polite live status and a keyboard-operable Stop button to a separate local page, then record a manual keyboard and screen-reader check.

Terminal folder: production-ai/02-04-stream-accessibility

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Produce a short status message when the status changes. Ordinary text chunks leave the status message unchanged. A DOM implementation can put that message in a polite live region and keep the stream text outside it.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement statusMessage. Add a polite live status and a keyboard-operable Stop button to a separate local page, then record a manual keyboard and screen-reader check.

Expected: Starting is announced

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Chunks do not repeat the announcement; Completion and error are clear

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Starting is announced; Chunks do not repeat the announcement; Completion and error are clear. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Announce meaningful transitions and keep focus stable. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/02-04-stream-accessibility/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Status transition → concise live message → learner reads the answer. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. How should an accessible interface report incoming answer tokens? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: New answer text is not automatically a new announcement. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: How should an accessible interface report incoming answer tokens?

Interview: How should an accessible interface report incoming answer tokens? Explain the decision, a failing case and a production limitation.

Quiz: How should an accessible interface report incoming answer tokens?

Move focus to each token.

Put the whole answer in an assertive live region.

Keep text readable and announce meaningful status changes.

Reference: Keep text readable and announce meaningful status changes. — Status messages support orientation without taking over the learner’s reading or keyboard position.

Sources:

W3C: status messages: https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html
