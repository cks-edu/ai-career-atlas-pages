# AI Inference Infrastructure, Evals & Production Guardrails

Operate a measured service with explicit release and cost gates.

Use the in-browser Practise workbench, or extract the course ZIP and install a currently supported Node.js LTS from nodejs.org. Run each reference.mjs from its numbered production-ai folder; run starter.mjs to see the failing initial checks. No packages or model files are required.

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Mental model: follow Path → State → Boundary → Failure → Control → Observability → Blast radius → Trade-off; inspect each lesson’s concrete version before changing code.

Tools and alternatives:
vLLM — Open source · GPU/hardware dependent. Measure inference serving, queues and token latency. Alternative: SGLang or a reviewed managed inference service.
OpenTelemetry — Open source / open specification. Collect service traces and declared latency/resource signals. Alternative: Provider-native telemetry; compare portability and cost.

Project: Build an independently changed learning artifact for AI Inference Infrastructure, Evals & Production Guardrails. Operate a measured service with explicit release and cost gates. Use synthetic data and make the tested scope explicit.
Draw the eight-node path and identify data, authority and resource boundaries.
Implement your own changed policy using the four lessons; retain valid and invalid cases.
Inject a declared failure, capture the result, repair it and run the regression checks.
Write an ADR with options, trade-offs, source/runtime versions, limitations and a rollback/recovery decision.

The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.
