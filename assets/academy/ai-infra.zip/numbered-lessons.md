# AI Inference Infrastructure, Evals & Production Guardrails — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## advanced

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

p99: The value at or below which 99% of measured observations fall.

TTFT: Time to first generated token, with measurement boundaries stated.

backpressure: A signal that slows or rejects producers when a consumer is overloaded.

KV cache: Stored attention keys and values whose memory grows with served context.

release gate: A predeclared rule controlling whether a candidate is promoted.

slice: A meaningful subset of evaluation cases, such as a language or risk category.

reservation: Capacity or budget set aside before a unit of work begins.

atomic: An operation committed as one indivisible state change.

### Serving latency: budget the complete request

A model server is only one part of response time. Queueing, retrieval, prompt processing, generation and networking all contribute. A fast average can hide painful tail latency. Set an end-to-end target and preserve stage measurements.

Sum supplied stage durations and compare with a declared request budget. Reject invalid telemetry instead of calling it zero. This arithmetic fixture does not measure vLLM or estimate hardware throughput; use actual traces for production decisions.

Adding stage percentiles does not produce the end-to-end percentile. Request-level correlated traces are needed to measure p99 correctly.

Mental model: Gateway → queue → retrieval → inference → response. Picture the boundary as a checked gate between stages.

Boundary: Adding stage percentiles does not produce the end-to-end percentile. Request-level correlated traces are needed to measure p99 correctly.

Worked example: function withinLatency(stages, budget) {
  return Array.isArray(stages) && Number.isFinite(budget) && budget >= 0 &&
    stages.every(x => Number.isFinite(x) && x >= 0) && stages.reduce((a,b)=>a+b,0) <= budget;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-infra.zip, install Node.js LTS, then open production-ai/04-01-latency-budget.

Tools for this exercise: JavaScript · local isolated workbench; vLLM, OpenTelemetry as documented optional extensions

Course tool and framework map: vLLM (Open source · GPU/hardware dependent); OpenTelemetry (Open source / open specification)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement withinLatency. Draw a request trace with a queue spike and explain time-to-first-token versus total generation latency.

Terminal folder: production-ai/04-01-latency-budget

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Sum supplied stage durations and compare with a declared request budget. Reject invalid telemetry instead of calling it zero. This arithmetic fixture does not measure vLLM or estimate hardware throughput; use actual traces for production decisions.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement withinLatency. Draw a request trace with a queue spike and explain time-to-first-token versus total generation latency.

Expected: The whole request is counted

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Tail-stage overflow is detected; Missing/negative measurements fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: The whole request is counted; Tail-stage overflow is detected; Missing/negative measurements fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Validate measurements and compare total duration with the budget. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/04-01-latency-budget/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Gateway → queue → retrieval → inference → response. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Can you add the p99 of retrieval to the p99 of generation and call it end-to-end p99? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A stage average cannot establish end-to-end p99. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Can you add the p99 of retrieval to the p99 of generation and call it end-to-end p99?

Interview: Can you add the p99 of retrieval to the p99 of generation and call it end-to-end p99? Explain the decision, a failing case and a production limitation.

Quiz: Can you add the p99 of retrieval to the p99 of generation and call it end-to-end p99?

Yes, always.

Only if the chart is green.

No; measure the complete requests and their correlated stages.

Reference: No; measure the complete requests and their correlated stages. — Percentiles from separate distributions do not generally add. Trace actual requests to understand their tail.

Sources:

vLLM: production metrics: https://docs.vllm.ai/en/latest/design/metrics/

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

### Admission control before the GPU queue grows

A service should reject or defer work it cannot finish responsibly. Accepting every request into an unbounded queue increases waiting time and memory pressure. Check the queue, request size and available budget before admitting new work.

This admission rule uses supplied queue depth and limits. At the maximum queue depth, the next request is rejected. These are policy inputs, not a real GPU scheduler. In a deployment, return an explicit overload result and use bounded retries with jitter.

A request count does not model token length, KV-cache usage or fair scheduling. Measure workload and hardware before choosing limits.

Mental model: Request → size check → queue capacity → admit or back off. Picture the boundary as a checked gate between stages.

Boundary: A request count does not model token length, KV-cache usage or fair scheduling. Measure workload and hardware before choosing limits.

Worked example: function admit(depth, maxDepth, tokens, maxTokens) {
  return [depth,maxDepth,tokens,maxTokens].every(n => Number.isSafeInteger(n) && n >= 0) &&
    depth < maxDepth && tokens > 0 && tokens <= maxTokens;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-infra.zip, install Node.js LTS, then open production-ai/04-02-admission-control.

Tools for this exercise: JavaScript · local isolated workbench; vLLM, OpenTelemetry as documented optional extensions

Course tool and framework map: vLLM (Open source · GPU/hardware dependent); OpenTelemetry (Open source / open specification)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement admit. Test the exact queue and token boundaries, then write how a gateway reports overload without retry storms.

Terminal folder: production-ai/04-02-admission-control

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This admission rule uses supplied queue depth and limits. At the maximum queue depth, the next request is rejected. These are policy inputs, not a real GPU scheduler. In a deployment, return an explicit overload result and use bounded retries with jitter.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement admit. Test the exact queue and token boundaries, then write how a gateway reports overload without retry storms.

Expected: Within-budget work is accepted

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Full queues and oversized work are rejected; Invalid capacity is rejected

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Within-budget work is accepted; Full queues and oversized work are rejected; Invalid capacity is rejected. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Reject when queue capacity or token limits are reached. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/04-02-admission-control/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Request → size check → queue capacity → admit or back off. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. The queue is full. Which behavior best protects a latency target? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A public API must not promise unlimited accepted work. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: The queue is full. Which behavior best protects a latency target?

Interview: The queue is full. Which behavior best protects a latency target? Explain the decision, a failing case and a production limitation.

Quiz: The queue is full. Which behavior best protects a latency target?

Signal overload and use a bounded retry/defer policy.

Accept everything and hide the wait.

Retry immediately without a limit.

Reference: Signal overload and use a bounded retry/defer policy. — Backpressure must be visible to callers and coupled with a recovery policy, rather than an ever-growing queue.

Sources:

vLLM: production metrics: https://docs.vllm.ai/en/latest/design/metrics/

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

### Evaluation gates before deployment

A release candidate can improve an overall score while failing a critical case. Declare the gates before evaluating: minimum quality, protected safety cases and a matching evaluation revision. Keep the raw case results behind any aggregate.

The local release gate checks finite quality, a predeclared minimum, no critical failures, and the expected evaluation revision. A pass means this declared report meets the gate, not that the system is universally safe.

A fabricated report can satisfy a schema. The cases, labels, execution and sample uncertainty must be reviewed separately.

Mental model: Versioned cases → candidate outputs → report → release decision. Picture the boundary as a checked gate between stages.

Boundary: A fabricated report can satisfy a schema. The cases, labels, execution and sample uncertainty must be reviewed separately.

Worked example: function releaseOK(report, revision, minQuality) {
  return !!report && report.revision === revision && Number.isFinite(report.quality) &&
    report.quality >= minQuality && report.quality <= 1 && report.criticalFailures === 0;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-infra.zip, install Node.js LTS, then open production-ai/04-03-release-evaluation.

Tools for this exercise: JavaScript · local isolated workbench; vLLM, OpenTelemetry as documented optional extensions

Course tool and framework map: vLLM (Open source · GPU/hardware dependent); OpenTelemetry (Open source / open specification)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement releaseOK and retain the failing report. Write a release ADR with dataset revision, candidate revision, rollback target and known untested conditions.

Terminal folder: production-ai/04-03-release-evaluation

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The local release gate checks finite quality, a predeclared minimum, no critical failures, and the expected evaluation revision. A pass means this declared report meets the gate, not that the system is universally safe.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement releaseOK and retain the failing report. Write a release ADR with dataset revision, candidate revision, rollback target and known untested conditions.

Expected: A matching clean report passes

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Critical failures and stale revisions block release; Invalid metrics cannot pass

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A matching clean report passes; Critical failures and stale revisions block release; Invalid metrics cannot pass. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Block mismatched revisions, invalid metrics and any critical failure. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/04-03-release-evaluation/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Versioned cases → candidate outputs → report → release decision. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A candidate’s average improves, but one protected safety case regresses. What should happen? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: An overall average cannot waive a critical failure. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A candidate’s average improves, but one protected safety case regresses. What should happen?

Interview: A candidate’s average improves, but one protected safety case regresses. What should happen? Explain the decision, a failing case and a production limitation.

Quiz: A candidate’s average improves, but one protected safety case regresses. What should happen?

Publish the higher average only.

Apply the predeclared critical-failure gate and inspect the case.

Remove the failing case from evaluation.

Reference: Apply the predeclared critical-failure gate and inspect the case. — Changing the test after observing failure defeats the gate. Investigate and document the result before promotion.

Sources:

NIST: AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

scikit-learn: data leakage: https://scikit-learn.org/stable/common_pitfalls.html#data-leakage

### Cost limits are execution boundaries

Repeated tool calls and long generations can consume a shared budget quickly. Reserve permitted cost before starting the next unit of work, rather than noticing overspend after it finishes. Use a conservative reservation and reconcile it with measured usage.

This exercise uses integer budget units, not a provider’s price list. Permit a new reservation only when spent plus reserved work fits the cap. Reject invalid values. Production services need concurrency-safe accounting and a way to cancel work.

A local counter is not a financial ledger, and estimated tokens do not guarantee a final bill. Provider pricing and concurrent requests require separate validation.

Mental model: Request → estimate/reserve → execute → reconcile measured use. Picture the boundary as a checked gate between stages.

Boundary: A local counter is not a financial ledger, and estimated tokens do not guarantee a final bill. Provider pricing and concurrent requests require separate validation.

Worked example: function canReserve(spent, reserved, next, cap) {
  return [spent,reserved,next,cap].every(n=>Number.isSafeInteger(n) && n>=0) && spent + reserved + next <= cap;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-infra.zip, install Node.js LTS, then open production-ai/04-04-cost-guardrail.

Tools for this exercise: JavaScript · local isolated workbench; vLLM, OpenTelemetry as documented optional extensions

Course tool and framework map: vLLM (Open source · GPU/hardware dependent); OpenTelemetry (Open source / open specification)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement canReserve. Show an oversubscription race in an ADR and propose a transaction or bounded per-worker allowance.

Terminal folder: production-ai/04-04-cost-guardrail

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This exercise uses integer budget units, not a provider’s price list. Permit a new reservation only when spent plus reserved work fits the cap. Reject invalid values. Production services need concurrency-safe accounting and a way to cancel work.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement canReserve. Show an oversubscription race in an ADR and propose a transaction or bounded per-worker allowance.

Expected: Affordable work fits including reservations

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Exact cap and overspend differ; Invalid or negative amounts fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Affordable work fits including reservations; Exact cap and overspend differ; Invalid or negative amounts fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Use atomic reservations and refuse work beyond the cap. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/04-04-cost-guardrail/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Request → estimate/reserve → execute → reconcile measured use. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Two workers may start calls at the same time. Is a local check-then-increment sufficient? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Budget checks belong before the next call. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Two workers may start calls at the same time. Is a local check-then-increment sufficient?

Interview: Two workers may start calls at the same time. Is a local check-then-increment sufficient? Explain the decision, a failing case and a production limitation.

Quiz: Two workers may start calls at the same time. Is a local check-then-increment sufficient?

Yes, counters always synchronize.

Yes, if the prompt mentions cost.

No; coordinate reservations atomically at the shared budget boundary.

Reference: No; coordinate reservations atomically at the shared budget boundary. — Concurrency changes the problem: both workers can observe the same balance before either updates it.

Sources:

OpenTelemetry: observability primer: https://opentelemetry.io/docs/concepts/observability-primer/

NIST: AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
