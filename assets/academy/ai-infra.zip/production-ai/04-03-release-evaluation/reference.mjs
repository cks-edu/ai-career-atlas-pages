function releaseOK(report, revision, minQuality) {
  return !!report && report.revision === revision && Number.isFinite(report.quality) &&
    report.quality >= minQuality && report.quality <= 1 && report.criticalFailures === 0;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(releaseOK({revision:'r2',quality:.9,criticalFailures:0},'r2',.8));
console.log("PASS: A matching clean report passes");
}
{
assert(!releaseOK({revision:'r2',quality:.99,criticalFailures:1},'r2',.8)); assert(!releaseOK({revision:'r1',quality:.9,criticalFailures:0},'r2',.8));
console.log("PASS: Critical failures and stale revisions block release");
}
{
assert(!releaseOK({revision:'r2',quality:NaN,criticalFailures:0},'r2',.8)); assert(!releaseOK({revision:'r2',quality:2,criticalFailures:0},'r2',.8));
console.log("PASS: Invalid metrics cannot pass");
}
