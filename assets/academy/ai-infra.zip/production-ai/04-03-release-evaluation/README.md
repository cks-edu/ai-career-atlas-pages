# Evaluation gates before deployment

A release candidate can improve an overall score while failing a critical case. Declare the gates before evaluating: minimum quality, protected safety cases and a matching evaluation revision. Keep the raw case results behind any aggregate.

The local release gate checks finite quality, a predeclared minimum, no critical failures, and the expected evaluation revision. A pass means this declared report meets the gate, not that the system is universally safe.

Task: Implement releaseOK and retain the failing report. Write a release ADR with dataset revision, candidate revision, rollback target and known untested conditions.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Versioned cases → candidate outputs → report → release decision.
State: Report revision, quality and critical failures form the gate input.
Boundary: An overall average cannot waive a critical failure.
Failure: Better formatting hides a safety regression.
Control: Block mismatched revisions, invalid metrics and any critical failure.
Observability: Retain case-level diffs, slice metrics and rejected releases.
Blast radius: All deployments promoted from this gate.
Trade-off: Conservative gates slow promotion but make the decision auditable.

Limit: A fabricated report can satisfy a schema. The cases, labels, execution and sample uncertainty must be reviewed separately.

Sources:
https://www.nist.gov/itl/ai-risk-management-framework
https://scikit-learn.org/stable/common_pitfalls.html#data-leakage
