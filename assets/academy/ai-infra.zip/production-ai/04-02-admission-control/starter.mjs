function admit(depth,maxDepth,tokens,maxTokens) { return true; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(admit(2,3,100,200));
console.log("PASS: Within-budget work is accepted");
}
{
assert(!admit(3,3,100,200)); assert(!admit(1,3,201,200));
console.log("PASS: Full queues and oversized work are rejected");
}
{
assert(!admit(-1,3,100,200)); assert(!admit(1,3,0,200)); assert(!admit(1,3,Infinity,200));
console.log("PASS: Invalid capacity is rejected");
}
