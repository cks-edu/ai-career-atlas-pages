# Admission control before the GPU queue grows

A service should reject or defer work it cannot finish responsibly. Accepting every request into an unbounded queue increases waiting time and memory pressure. Check the queue, request size and available budget before admitting new work.

This admission rule uses supplied queue depth and limits. At the maximum queue depth, the next request is rejected. These are policy inputs, not a real GPU scheduler. In a deployment, return an explicit overload result and use bounded retries with jitter.

Task: Implement admit. Test the exact queue and token boundaries, then write how a gateway reports overload without retry storms.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Request → size check → queue capacity → admit or back off.
State: Queue depth and per-request token demand change over time.
Boundary: A public API must not promise unlimited accepted work.
Failure: An unbounded queue makes every request time out.
Control: Reject when queue capacity or token limits are reached.
Observability: Measure rejections, queue wait, active tokens and memory pressure.
Blast radius: All users sharing the serving pool.
Trade-off: Backpressure protects admitted requests but callers need an honest retry policy.

Limit: A request count does not model token length, KV-cache usage or fair scheduling. Measure workload and hardware before choosing limits.

Sources:
https://docs.vllm.ai/en/latest/design/metrics/
https://opentelemetry.io/docs/concepts/observability-primer/
