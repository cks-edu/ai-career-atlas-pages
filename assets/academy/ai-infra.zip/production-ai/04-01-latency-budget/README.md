# Serving latency: budget the complete request

A model server is only one part of response time. Queueing, retrieval, prompt processing, generation and networking all contribute. A fast average can hide painful tail latency. Set an end-to-end target and preserve stage measurements.

Sum supplied stage durations and compare with a declared request budget. Reject invalid telemetry instead of calling it zero. This arithmetic fixture does not measure vLLM or estimate hardware throughput; use actual traces for production decisions.

Task: Implement withinLatency. Draw a request trace with a queue spike and explain time-to-first-token versus total generation latency.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Gateway → queue → retrieval → inference → response.
State: Each request carries measured stage durations and a deadline.
Boundary: A stage average cannot establish end-to-end p99.
Failure: Queueing consumes the deadline before generation starts.
Control: Validate measurements and compare total duration with the budget.
Observability: Collect queue wait, time to first token and end-to-end latency.
Blast radius: Requests sharing the overloaded deployment.
Trade-off: Tighter admission limits protect latency but reject or defer more work.

Limit: Adding stage percentiles does not produce the end-to-end percentile. Request-level correlated traces are needed to measure p99 correctly.

Sources:
https://docs.vllm.ai/en/latest/design/metrics/
https://opentelemetry.io/docs/concepts/observability-primer/
