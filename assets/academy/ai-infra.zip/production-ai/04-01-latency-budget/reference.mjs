function withinLatency(stages, budget) {
  return Array.isArray(stages) && Number.isFinite(budget) && budget >= 0 &&
    stages.every(x => Number.isFinite(x) && x >= 0) && stages.reduce((a,b)=>a+b,0) <= budget;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(withinLatency([20,30,40],100));
console.log("PASS: The whole request is counted");
}
{
assert(!withinLatency([20,30,60],100)); assert(withinLatency([20,30,50],100));
console.log("PASS: Tail-stage overflow is detected");
}
{
assert(!withinLatency([20,NaN],100)); assert(!withinLatency([-1,20],100));
console.log("PASS: Missing/negative measurements fail");
}
