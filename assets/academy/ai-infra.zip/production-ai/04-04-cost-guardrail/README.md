# Cost limits are execution boundaries

Repeated tool calls and long generations can consume a shared budget quickly. Reserve permitted cost before starting the next unit of work, rather than noticing overspend after it finishes. Use a conservative reservation and reconcile it with measured usage.

This exercise uses integer budget units, not a provider’s price list. Permit a new reservation only when spent plus reserved work fits the cap. Reject invalid values. Production services need concurrency-safe accounting and a way to cancel work.

Task: Implement canReserve. Show an oversubscription race in an ADR and propose a transaction or bounded per-worker allowance.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Request → estimate/reserve → execute → reconcile measured use.
State: Spent, reserved and cap are integer policy units.
Boundary: Budget checks belong before the next call.
Failure: Two simultaneous calls both spend the same remaining allowance.
Control: Use atomic reservations and refuse work beyond the cap.
Observability: Track reservation, actual usage and denied work by run.
Blast radius: The account or tenant sharing the budget.
Trade-off: Conservative reservations prevent overspend but may reject affordable work.

Limit: A local counter is not a financial ledger, and estimated tokens do not guarantee a final bill. Provider pricing and concurrent requests require separate validation.

Sources:
https://opentelemetry.io/docs/concepts/observability-primer/
https://www.nist.gov/itl/ai-risk-management-framework
