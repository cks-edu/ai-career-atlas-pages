function canReserve(spent, reserved, next, cap) {
  return [spent,reserved,next,cap].every(n=>Number.isSafeInteger(n) && n>=0) && spent + reserved + next <= cap;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(canReserve(20,30,10,100));
console.log("PASS: Affordable work fits including reservations");
}
{
assert(canReserve(20,30,50,100)); assert(!canReserve(20,30,51,100));
console.log("PASS: Exact cap and overspend differ");
}
{
assert(!canReserve(-1,0,1,100)); assert(!canReserve(0,0,Infinity,100));
console.log("PASS: Invalid or negative amounts fail");
}
