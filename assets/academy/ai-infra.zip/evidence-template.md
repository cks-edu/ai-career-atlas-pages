# Local learning evidence

## Input and setup

## Observed versus expected

## Failure and recovery

## Limitation

## Sources
