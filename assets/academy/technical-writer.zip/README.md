# Technical Writer / Developer Educator

Software Engineering

Start with task-oriented instructions. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward versioned documentation release pack.

## beginner

Write a quick start for the supplied web reference. Include version checks, working directory, command, expected URL and stop action. Follow it from a freshly extracted pack.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Task-oriented instructions
A guide should state prerequisites, exact actions and recognizable success before optional detail. Define unfamiliar terms where they first become necessary.
Mental model: A trail guide names the starting point and the landmarks that prove you are on course.
Limit: A command can be correct but unusable in the wrong directory; make context explicit.
Example: A learner must know which folder contains app.mjs before running node app.mjs.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A command can be correct but unusable in the wrong directory; make context explicit.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A learner must know which folder contains app.mjs before running node app.mjs. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a quick start for the supplied web reference. Include version checks, working directory, command, expected URL and stop action. Follow it from a freshly extracted pack.
Expected: A new terminal reaches the working page without an unstated step.

6. Role workshop · debug and verify
A command can be correct but unusable in the wrong directory; make context explicit. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save tested quick-start.md. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A new terminal reaches the working page without an unstated step.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Task-oriented instructions: A command can be correct but unusable in the wrong directory; make context explicit.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: tested quick-start.md
A new terminal reaches the working page without an unstated step.

Interview: Work through this Technical Writer / Developer Educator case: A learner must know which folder contains app.mjs before running node app.mjs. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A guide should state prerequisites, exact actions and recognizable success before optional detail. Define unfamiliar terms where they first become necessary. Expected evidence: A new terminal reaches the working page without an unstated step. Diagnosis: A command can be correct but unusable in the wrong directory; make context explicit. State the limits of the mental model: A trail guide names the starting point and the landmarks that prove you are on course.

Resume: Built tested quick-start.md using Markdown and Git; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Deliberately reproduce those three lab errors safely. Capture exact messages and write a symptom/check/recovery table, including how to verify recovery.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Troubleshooting information architecture
Troubleshooting starts from symptoms readers can recognize and branches toward evidence. Keep cause hypotheses distinct from confirmed diagnoses.
Mental model: A station sign starts with where you are, then shows the route to the destination.
Limit: A generic reinstall instruction often destroys context and wastes time; diagnose the narrow cause.
Example: Command not found, missing file and EADDRINUSE require different checks.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A generic reinstall instruction often destroys context and wastes time; diagnose the narrow cause.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
Command not found, missing file and EADDRINUSE require different checks. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Deliberately reproduce those three lab errors safely. Capture exact messages and write a symptom/check/recovery table, including how to verify recovery.
Expected: Each branch ends with an observable working result.

6. Role workshop · debug and verify
A generic reinstall instruction often destroys context and wastes time; diagnose the narrow cause. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save troubleshooting guide and reproduction notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Each branch ends with an observable working result.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Troubleshooting information architecture: A generic reinstall instruction often destroys context and wastes time; diagnose the narrow cause.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: troubleshooting guide and reproduction notes
Each branch ends with an observable working result.

Interview: Work through this Technical Writer / Developer Educator case: Command not found, missing file and EADDRINUSE require different checks. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Troubleshooting starts from symptoms readers can recognize and branches toward evidence. Keep cause hypotheses distinct from confirmed diagnoses. Expected evidence: Each branch ends with an observable working result. Diagnosis: A generic reinstall instruction often destroys context and wastes time; diagnose the narrow cause. State the limits of the mental model: A station sign starts with where you are, then shows the route to the destination.

Resume: Built troubleshooting guide and reproduction notes using Markdown and Git; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write release notes, a compatibility table and a documentation test checklist. Have another reader or an independent clean walkthrough run the changed examples; record actual execution status.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Versioned documentation maintenance
Documentation has a supported environment and lifecycle just like code. Tie examples to tested versions and update links, migration advice and deprecations as behavior changes.
Mental model: A map needs an edition date when roads change.
Limit: A current-looking date is not verification; record what was actually checked.
Example: A new optional priority field changes examples but should preserve old request instructions during migration.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A current-looking date is not verification; record what was actually checked.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A new optional priority field changes examples but should preserve old request instructions during migration. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write release notes, a compatibility table and a documentation test checklist. Have another reader or an independent clean walkthrough run the changed examples; record actual execution status.
Expected: Examples match the described version and old/new behavior is unambiguous.

6. Role workshop · debug and verify
A current-looking date is not verification; record what was actually checked. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save versioned documentation release pack. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Examples match the described version and old/new behavior is unambiguous.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Versioned documentation maintenance: A current-looking date is not verification; record what was actually checked.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: versioned documentation release pack
Examples match the described version and old/new behavior is unambiguous.

Interview: Work through this Technical Writer / Developer Educator case: A new optional priority field changes examples but should preserve old request instructions during migration. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Documentation has a supported environment and lifecycle just like code. Tie examples to tested versions and update links, migration advice and deprecations as behavior changes. Expected evidence: Examples match the described version and old/new behavior is unambiguous. Diagnosis: A current-looking date is not verification; record what was actually checked. State the limits of the mental model: A map needs an edition date when roads change.

Resume: Built versioned documentation release pack using Markdown and Git; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
MDN: learn web development: https://developer.mozilla.org/en-US/docs/Learn_web_development
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
SAP Learning Journeys: https://learning.sap.com/learning-journeys
