# Technical Writer / Developer Educator — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Task-oriented instructions

A guide should state prerequisites, exact actions and recognizable success before optional detail. Define unfamiliar terms where they first become necessary.
Mental model: A trail guide names the starting point and the landmarks that prove you are on course.
Case: A learner must know which folder contains app.mjs before running node app.mjs.
Task: Write a quick start for the supplied web reference. Include version checks, working directory, command, expected URL and stop action. Follow it from a freshly extracted pack.
Acceptance: A new terminal reaches the working page without an unstated step.
Troubleshooting: A command can be correct but unusable in the wrong directory; make context explicit.
Deliverable: tested quick-start.md

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Troubleshooting information architecture

Troubleshooting starts from symptoms readers can recognize and branches toward evidence. Keep cause hypotheses distinct from confirmed diagnoses.
Mental model: A station sign starts with where you are, then shows the route to the destination.
Case: Command not found, missing file and EADDRINUSE require different checks.
Task: Deliberately reproduce those three lab errors safely. Capture exact messages and write a symptom/check/recovery table, including how to verify recovery.
Acceptance: Each branch ends with an observable working result.
Troubleshooting: A generic reinstall instruction often destroys context and wastes time; diagnose the narrow cause.
Deliverable: troubleshooting guide and reproduction notes

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Versioned documentation maintenance

Documentation has a supported environment and lifecycle just like code. Tie examples to tested versions and update links, migration advice and deprecations as behavior changes.
Mental model: A map needs an edition date when roads change.
Case: A new optional priority field changes examples but should preserve old request instructions during migration.
Task: Write release notes, a compatibility table and a documentation test checklist. Have another reader or an independent clean walkthrough run the changed examples; record actual execution status.
Acceptance: Examples match the described version and old/new behavior is unambiguous.
Troubleshooting: A current-looking date is not verification; record what was actually checked.
Deliverable: versioned documentation release pack

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
