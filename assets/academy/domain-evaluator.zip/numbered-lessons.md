# Domain evaluator / AI trainer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Task-specific correctness: Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Task-specific correctness

Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition. In this role, work through: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A referee needs the rules of this sport, not only good eyesight.

Boundary: A practice rubric does not qualify someone to make professional clinical or legal judgments.

Worked example: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Domain evaluator / AI trainer: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice.

Predict the worked case

Read this case without running a tool: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in task-specific correctness.

Connect the concept to the role

Apply this rule: Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A practice rubric does not qualify someone to make professional clinical or legal judgments.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies task-specific correctness to this case: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Task-specific correctness; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with task-specific correctness. Use the glossary below, then write your prediction for: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Domain evaluator / AI trainer role interview. Explain task-specific correctness using this case: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate task-specific correctness to a system or workflow you know. Explain task-specific correctness using this case: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain task-specific correctness using this case: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice.

Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition. — Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition. A practice rubric does not qualify someone to make professional clinical or legal judgments.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Label Studio: https://labelstud.io/guide/

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Diagnose: A plausible answer has no support

The annotation rubric requires every accepted domain answer to have a checked factual basis. Three accepted answers include unsupported statements; polished wording influenced the ratings. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Separate correctness from style and adjudicate evidence against the rubric. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A referee needs the rules of this sport, not only good eyesight.

For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice.

Worked example: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Separate correctness from style and adjudicate evidence against the rubric.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The annotation rubric requires every accepted domain answer to have a checked factual basis. Three accepted answers include unsupported statements; polished wording influenced the ratings. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The annotation rubric requires every accepted domain answer to have a checked factual basis. Apply this toy-case rule manually: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A rubric is a shared rule for judging work. Correctness, completeness and style should be reviewed separately.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use the fact “A triangle has three sides.” Review A: “A triangle has three sides” and B: “A triangle has four sides, explained beautifully.”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-answer evaluation sheet with reasons.

Preparation · Try step 2

Create a small rubric with correctness and clarity as separate criteria.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-answer evaluation sheet with reasons.

Preparation · Try step 3

Add an incomplete answer, “A triangle is a shape”, and explain why it differs from the wrong answer.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-answer evaluation sheet with reasons.

Preparation · Explain and check your result

Good style does not rescue a false fact; the incomplete answer is distinguished from a factual error. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A three-answer evaluation sheet with reasons. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The annotation rubric requires every accepted domain answer to have a checked factual basis. Apply this toy-case rule manually: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three accepted answers include unsupported statements; polished wording influenced the ratings. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three accepted answers include unsupported statements; polished wording influenced the ratings. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a plausible answer has no support. Use the glossary below, then write your prediction for: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Separate correctness from style and adjudicate evidence against the rubric. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Domain evaluator / AI trainer role interview. Explain diagnose: a plausible answer has no support using this case: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Separate correctness from style and adjudicate evidence against the rubric. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a plausible answer has no support to a system or workflow you know. Explain diagnose: a plausible answer has no support using this case: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Separate correctness from style and adjudicate evidence against the rubric. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Have another qualified reviewer independently assess a new sample and resolve disagreements. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a plausible answer has no support using this case: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Separate correctness from style and adjudicate evidence against the rubric. State the evidence, one alternative and where the mental model stops.

Quiz: A plausible answer has no support: The annotation rubric requires every accepted domain answer to have a checked factual basis.

Change the acceptance rule after seeing an inconvenient result.

Separate correctness from style and adjudicate evidence against the rubric.

Omit failed cases and report only the successful demonstrations.

Reference: Separate correctness from style and adjudicate evidence against the rubric. — Separate correctness from style and adjudicate evidence against the rubric. Have another qualified reviewer independently assess a new sample and resolve disagreements.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Label Studio: https://labelstud.io/guide/

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong subject knowledge and careful evaluation. Coding, medicine, law or science assignments require the corresponding expertise.

Terms:

Calibration and disagreement: Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Calibration and disagreement

Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation. In this role, work through: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Musicians tune to a reference before playing together.

Boundary: Agreement can still be consistently wrong if the reference is flawed.

Worked example: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong subject knowledge and careful evaluation. Coding, medicine, law or science assignments require the corresponding expertise.

Tools for this exercise: Document or text editor

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Domain evaluator / AI trainer: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example.

Predict the worked case

Read this case without running a tool: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in calibration and disagreement.

Connect the concept to the role

Apply this rule: Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Agreement can still be consistently wrong if the reference is flawed.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies calibration and disagreement to this case: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Calibration and disagreement; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with calibration and disagreement. Use the glossary below, then write your prediction for: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Domain evaluator / AI trainer role interview. Explain calibration and disagreement using this case: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate calibration and disagreement to a system or workflow you know. Explain calibration and disagreement using this case: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain calibration and disagreement using this case: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example.

Treat a passing starter as proof of the whole role workflow.

Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation.

Ignore the failure because the tool produced an output.

Reference: Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation. — Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation. Agreement can still be consistently wrong if the reference is flawed.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Label Studio: https://labelstud.io/guide/

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Integrate: Expert rubric and adjudication portfolio

Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample. In this role, work through: Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: Musicians tune to a reference before playing together.

Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example.

Worked example: Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

Prepare the project inputs

Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The annotation rubric requires every accepted domain answer to have a checked factual basis. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Domain rubric and source-backed case set; Independent labels and adjudication record. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: expert rubric and adjudication portfolio. Use the glossary below, then write your prediction for: Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Domain evaluator / AI trainer role interview. Explain integrate: expert rubric and adjudication portfolio using this case: Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: expert rubric and adjudication portfolio to a system or workflow you know. Explain integrate: expert rubric and adjudication portfolio using this case: Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. Identify one observation that would contradict your claim.

Interview: Explain integrate: expert rubric and adjudication portfolio using this case: Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Expert rubric and adjudication portfolio at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.

Reference: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. — Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Label Studio: https://labelstud.io/guide/

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Evaluation evidence handoff: Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Evaluation evidence handoff

Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled. In this role, work through: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A marked exam includes the teacher's reasoning, not only a total score.

Boundary: A small annotated set does not establish population-wide quality.

Worked example: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Domain evaluator / AI trainer: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric.

Predict the worked case

Read this case without running a tool: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in evaluation evidence handoff.

Connect the concept to the role

Apply this rule: Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A small annotated set does not establish population-wide quality.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies evaluation evidence handoff to this case: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Evaluation evidence handoff; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with evaluation evidence handoff. Use the glossary below, then write your prediction for: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Domain evaluator / AI trainer role interview. Explain evaluation evidence handoff using this case: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate evaluation evidence handoff to a system or workflow you know. Explain evaluation evidence handoff using this case: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain evaluation evidence handoff using this case: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled.

Reference: Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled. — Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled. A small annotated set does not establish population-wide quality.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Label Studio: https://labelstud.io/guide/

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

### Defend: Expert rubric and adjudication portfolio

Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Adjudicate disagreements with source evidence and revise ambiguous rubric language. Preserve original judgments and explain each change. In this role, work through: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A marked exam includes the teacher's reasoning, not only a total score.

Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric.

Worked example: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Label Studio (Open source Community · commercial editions optional); LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed)

Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

Prepare the project inputs

Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Adjudicate disagreements with source evidence and revise ambiguous rubric language. Preserve original judgments and explain each change.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A reviewer must reproduce one result and identify which capabilities you implemented. Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Domain rubric and source-backed case set; Independent labels and adjudication record; Evaluator guidance and limitations statement. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: expert rubric and adjudication portfolio. Use the glossary below, then write your prediction for: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Domain evaluator / AI trainer role interview. Explain defend: expert rubric and adjudication portfolio using this case: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: expert rubric and adjudication portfolio to a system or workflow you know. Explain defend: expert rubric and adjudication portfolio using this case: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. Identify one observation that would contradict your claim.

Interview: Explain defend: expert rubric and adjudication portfolio using this case: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Expert rubric and adjudication portfolio at this level?

Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention. — Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention. Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.

Sources:

Label Studio: https://labelstud.io/guide/quick_start

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Label Studio: https://labelstud.io/guide/

Google Technical Writing: https://developers.google.com/tech-writing

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
