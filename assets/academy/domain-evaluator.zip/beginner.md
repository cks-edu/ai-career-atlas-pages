## beginner — Task-specific correctness

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Task-specific correctness
Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition.
Mental model: A referee needs the rules of this sport, not only good eyesight.
Boundary: A practice rubric does not qualify someone to make professional clinical or legal judgments.
Worked example: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A plausible answer has no support
The annotation rubric requires every accepted domain answer to have a checked factual basis. Three accepted answers include unsupported statements; polished wording influenced the ratings. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Separate correctness from style and adjudicate evidence against the rubric.
Recall: Have another qualified reviewer independently assess a new sample and resolve disagreements. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Task-specific correctness: Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A rubric is a shared rule for judging work. Correctness, completeness and style should be reviewed separately.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use the fact “A triangle has three sides.” Review A: “A triangle has three sides” and B: “A triangle has four sides, explained beautifully.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-answer evaluation sheet with reasons.

3. Try step 2
Create a small rubric with correctness and clarity as separate criteria.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-answer evaluation sheet with reasons.

4. Try step 3
Add an incomplete answer, “A triangle is a shape”, and explain why it differs from the wrong answer.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-answer evaluation sheet with reasons.

5. Explain and check your result
Good style does not rescue a false fact; the incomplete answer is distinguished from a factual error. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A three-answer evaluation sheet with reasons. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The annotation rubric requires every accepted domain answer to have a checked factual basis. Apply this toy-case rule manually: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three accepted answers include unsupported statements; polished wording influenced the ratings. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Domain evaluator / AI trainer.
Use the fact “A triangle has three sides.” Review A: “A triangle has three sides” and B: “A triangle has four sides, explained beautifully.”
Create a small rubric with correctness and clarity as separate criteria.
Add an incomplete answer, “A triangle is a shape”, and explain why it differs from the wrong answer.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A three-answer evaluation sheet with reasons. Include beginner-worksheet.md and your completed Annotated answer set and calibration note.
Check: Good style does not rescue a false fact; the incomplete answer is distinguished from a factual error.

### Interview
Explain your beginner solution for Domain evaluator / AI trainer. Use this scenario: The annotation rubric requires every accepted domain answer to have a checked factual basis.
Review: Start with the task and permitted scope. Explain task-specific correctness: Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition. Show the input and observed output, then address Separate correctness from style and adjudicate evidence against the rubric. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A three-answer evaluation sheet with reasons. Include beginner-worksheet.md and your completed Annotated answer set and calibration note.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

