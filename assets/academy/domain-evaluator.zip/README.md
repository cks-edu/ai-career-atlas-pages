# Domain evaluator / AI trainer

AI Engineering · Beginner → Intermediate → Advanced

Start with Task-specific correctness. A rubric is a shared rule for judging work. Correctness, completeness and style should be reviewed separately. Then try Score two simple explanations. The three levels build toward Expert rubric and adjudication portfolio. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Task-specific correctness

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Task-specific correctness
Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition.
Mental model: A referee needs the rules of this sport, not only good eyesight.
Boundary: A practice rubric does not qualify someone to make professional clinical or legal judgments.
Worked example: For a fictional policy answer, require the exception clause and source passage; do not reward fluent but unsupported advice.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A plausible answer has no support
The annotation rubric requires every accepted domain answer to have a checked factual basis. Three accepted answers include unsupported statements; polished wording influenced the ratings. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Separate correctness from style and adjudicate evidence against the rubric.
Recall: Have another qualified reviewer independently assess a new sample and resolve disagreements. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Task-specific correctness: Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A rubric is a shared rule for judging work. Correctness, completeness and style should be reviewed separately.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use the fact “A triangle has three sides.” Review A: “A triangle has three sides” and B: “A triangle has four sides, explained beautifully.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-answer evaluation sheet with reasons.

3. Try step 2
Create a small rubric with correctness and clarity as separate criteria.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-answer evaluation sheet with reasons.

4. Try step 3
Add an incomplete answer, “A triangle is a shape”, and explain why it differs from the wrong answer.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-answer evaluation sheet with reasons.

5. Explain and check your result
Good style does not rescue a false fact; the incomplete answer is distinguished from a factual error. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A three-answer evaluation sheet with reasons. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The annotation rubric requires every accepted domain answer to have a checked factual basis. Apply this toy-case rule manually: Review when unsupported_statements >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three accepted answers include unsupported statements; polished wording influenced the ratings. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Domain evaluator / AI trainer.
Use the fact “A triangle has three sides.” Review A: “A triangle has three sides” and B: “A triangle has four sides, explained beautifully.”
Create a small rubric with correctness and clarity as separate criteria.
Add an incomplete answer, “A triangle is a shape”, and explain why it differs from the wrong answer.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A three-answer evaluation sheet with reasons. Include beginner-worksheet.md and your completed Annotated answer set and calibration note.
Check: Good style does not rescue a false fact; the incomplete answer is distinguished from a factual error.

### Interview
Explain your beginner solution for Domain evaluator / AI trainer. Use this scenario: The annotation rubric requires every accepted domain answer to have a checked factual basis.
Review: Start with the task and permitted scope. Explain task-specific correctness: Define correctness for the domain and identify which judgments require credentials or specialist review. A plausible answer can fail because it omits a crucial condition. Show the input and observed output, then address Separate correctness from style and adjudicate evidence against the rubric. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A three-answer evaluation sheet with reasons. Include beginner-worksheet.md and your completed Annotated answer set and calibration note.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Calibration and disagreement

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong subject knowledge and careful evaluation. Coding, medicine, law or science assignments require the corresponding expertise.

### Calibration and disagreement
Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation.
Mental model: Musicians tune to a reference before playing together.
Boundary: Agreement can still be consistently wrong if the reference is flawed.
Worked example: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Expert rubric and adjudication portfolio
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Recall: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. Identify one observation that would contradict your claim.

### Terms
Calibration and disagreement: Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The annotation rubric requires every accepted domain answer to have a checked factual basis. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.
Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.
Deliverables: Domain rubric and source-backed case set; Independent labels and adjudication record. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Domain evaluator / AI trainer. Use this scenario: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Review: Start with the task and permitted scope. Explain calibration and disagreement: Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation. Show the input and observed output, then address Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Domain rubric and source-backed case set; Independent labels and adjudication record. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Evaluation evidence handoff

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Evaluation evidence handoff
Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled.
Mental model: A marked exam includes the teacher's reasoning, not only a total score.
Boundary: A small annotated set does not establish population-wide quality.
Worked example: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Expert rubric and adjudication portfolio
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Adjudicate disagreements with source evidence and revise ambiguous rubric language. Preserve original judgments and explain each change.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Recall: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. Identify one observation that would contradict your claim.

### Terms
Evaluation evidence handoff: Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Adjudicate disagreements with source evidence and revise ambiguous rubric language. Preserve original judgments and explain each change.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.
Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Adjudicate disagreements with source evidence and revise ambiguous rubric language. Preserve original judgments and explain each change.
Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.
Test the revised rubric on fresh cases to check whether agreement improves without hiding difficult examples.
Deliverables: Domain rubric and source-backed case set; Independent labels and adjudication record; Evaluator guidance and limitations statement. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A reviewer must reproduce one result and identify which capabilities you implemented. Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

### Interview
Explain your advanced solution for Domain evaluator / AI trainer. Use this scenario: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Review: Start with the task and permitted scope. Explain evaluation evidence handoff: Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled. Show the input and observed output, then address Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Domain rubric and source-backed case set; Independent labels and adjudication record; Evaluator guidance and limitations statement. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Label Studio — Open source Community · commercial editions optional
Configure annotation tasks and export reviewer judgments.
Alternative: A reviewed CSV workbook for small batches, or a commercial annotation platform; access, adjudication and export matter more than brand.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Writer / Impress — Open source · no account needed
Edit reports, workshop decks and export PDF deliverables.
Alternative: Microsoft Word/PowerPoint (commercial) or Google Docs/Slides (hosted); retain editable and accessible exports.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Label Studio: https://labelstud.io/guide/quick_start
LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Label Studio: https://labelstud.io/guide/
Google Technical Writing: https://developers.google.com/tech-writing
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
