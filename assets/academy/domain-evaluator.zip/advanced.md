## advanced — Evaluation evidence handoff

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Evaluation evidence handoff
Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled.
Mental model: A marked exam includes the teacher's reasoning, not only a total score.
Boundary: A small annotated set does not establish population-wide quality.
Worked example: Deliver ten reviewed cases with source IDs, severity and unresolved questions, then show how one disagreement changed the rubric.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Expert rubric and adjudication portfolio
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Adjudicate disagreements with source evidence and revise ambiguous rubric language. Preserve original judgments and explain each change.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Recall: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. Identify one observation that would contradict your claim.

### Terms
Evaluation evidence handoff: Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Adjudicate disagreements with source evidence and revise ambiguous rubric language. Preserve original judgments and explain each change.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.
Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Adjudicate disagreements with source evidence and revise ambiguous rubric language. Preserve original judgments and explain each change.
Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.
Test the revised rubric on fresh cases to check whether agreement improves without hiding difficult examples.
Deliverables: Domain rubric and source-backed case set; Independent labels and adjudication record; Evaluator guidance and limitations statement. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A reviewer must reproduce one result and identify which capabilities you implemented. Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

### Interview
Explain your advanced solution for Domain evaluator / AI trainer. Use this scenario: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Review: Start with the task and permitted scope. Explain evaluation evidence handoff: Provide labeled examples, reasons, uncertainty and escalation cases so others can inspect the judgment process. Keep contributor identity and provenance controlled. Show the input and observed output, then address Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Domain rubric and source-backed case set; Independent labels and adjudication record; Evaluator guidance and limitations statement. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

