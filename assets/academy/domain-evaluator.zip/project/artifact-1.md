# Domain rubric and source-backed case set

Project: Expert rubric and adjudication portfolio
Status: blank work product — not completed evidence

## Purpose and audience
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.

## Required content
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.

## Failure evidence
Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
