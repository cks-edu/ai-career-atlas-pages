# Expert rubric and adjudication portfolio

Career: Domain evaluator / AI trainer
Reviewed: 2026-10-22

Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.

## Prerequisites
Strong subject knowledge and careful evaluation. Coding, medicine, law or science assignments require the corresponding expertise.

## Included starter versus your implementation
Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Adjudicate disagreements with source evidence and revise ambiguous rubric language. Preserve original judgments and explain each change.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```

## Portfolio deliverables
1. Domain rubric and source-backed case set — artifact-1.md
2. Independent labels and adjudication record — artifact-2.md
3. Evaluator guidance and limitations statement — artifact-3.md

## Troubleshooting
- CSV appears in one column: select comma as the separator during import.
- Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
- No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.

## Extension
Test the revised rubric on fresh cases to check whether agreement improves without hiding difficult examples.

## Primary learning resources
- Label Studio: https://labelstud.io/guide/quick_start — Open source Community · commercial editions optional; Configure annotation tasks and export reviewer judgments.
- LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/ — Open source · no account needed; Edit reports, workshop decks and export PDF deliverables.
- LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html — Open source · no account needed; Import CSV evidence, build review registers and calculate summaries.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
