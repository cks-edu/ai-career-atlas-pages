# Independent labels and adjudication record

Project: Expert rubric and adjudication portfolio
Status: blank work product — not completed evidence

## Purpose and audience
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.

## Required content
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.

## Failure evidence
Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
