# Expert rubric and adjudication portfolio

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.

## Limitations and next iteration
Test the revised rubric on fresh cases to check whether agreement improves without hiding difficult examples.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
