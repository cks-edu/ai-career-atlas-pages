## intermediate — Calibration and disagreement

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong subject knowledge and careful evaluation. Coding, medicine, law or science assignments require the corresponding expertise.

### Calibration and disagreement
Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation.
Mental model: Musicians tune to a reference before playing together.
Boundary: Agreement can still be consistently wrong if the reference is flawed.
Worked example: Two evaluators give different scores to a partially supported answer; identify the missing criterion and add a boundary example.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Expert rubric and adjudication portfolio
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Recall: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. Identify one observation that would contradict your claim.

### Terms
Calibration and disagreement: Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The annotation rubric requires every accepted domain answer to have a checked factual basis. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Create a domain-specific evaluation rubric and demonstrate consistent evidence-based judgments.
Choose a domain in which you have appropriate expertise. Use public or synthetic examples, with source references and no real high-stakes decisions about individuals.
Define the task, acceptable answers, critical errors and uncertainty categories. Write anchored examples at each score level before labeling.
Import 30 cases into Label Studio or Calc and score them blind to candidate identity. Ask a qualified peer to independently review an overlap sample.
Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials.
Deliverables: Domain rubric and source-backed case set; Independent labels and adjudication record. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Domain evaluator / AI trainer. Use this scenario: Include a plausible answer with an unsupported citation and a case where the evidence is insufficient. Reward justified uncertainty rather than confident invention.
Review: Start with the task and permitted scope. Explain calibration and disagreement: Score shared examples independently, compare reasons and revise unclear rubric language. Preserve uncertainty instead of forcing reviewers to agree without explanation. Show the input and observed output, then address Report agreement, error categories and unresolved cases. The portfolio demonstrates evaluation practice, not a substitute for required professional credentials. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Domain rubric and source-backed case set; Independent labels and adjudication record. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

