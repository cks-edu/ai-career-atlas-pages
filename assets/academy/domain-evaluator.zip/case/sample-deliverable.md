# SAMPLE — Annotated answer set and calibration note
Role: Domain evaluator / AI trainer
Case: A plausible answer has no support
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The annotation rubric requires every accepted domain answer to have a checked factual basis.

## Evidence table
| Record | unsupported_statements (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 3 | review |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three accepted answers include unsupported statements; polished wording influenced the ratings.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Separate correctness from style and adjudicate evidence against the rubric.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in domain evaluator / ai trainer.
Before release: Have another qualified reviewer independently assess a new sample and resolve disagreements.

## Design choice and trade-off
Write clear positive and negative examples; keep uncertain judgments visible for domain review.
Agreement is useful but does not prove truth when reviewers share the same mistaken assumption.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Domain evaluation set: Another qualified reviewer can apply the rubric.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
