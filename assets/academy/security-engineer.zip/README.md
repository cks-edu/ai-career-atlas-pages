# Security Engineer

Software Engineering

Start with control objectives and assets. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward security readiness review and response tabletop.

## beginner

Draw the data flow, classify synthetic fields and write misuse cases for unauthorized read, modification and deletion. Map each to prevention and detection evidence.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Authentication and authorization
Authentication establishes identity; authorization decides which action that identity may perform.
Mental model: An ID card tells who you are; the door policy says where you may enter.
Limit: A valid login does not authorize access to every record.
Example: Alice may read but not write; an unknown user is denied.
Recall: Where should an object ownership check happen?

### Control objectives and assets
A security control addresses a defined risk to an asset. Start with who needs access, what harm matters and where trust changes before choosing products.
Mental model: Locks are chosen after identifying the rooms and valuables they protect.
Limit: A product name alone does not demonstrate a control works.
Example: A support export contains customer data and requires a narrower audience than public help pages.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A product name alone does not demonstrate a control works.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A support export contains customer data and requires a narrower audience than public help pages. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Draw the data flow, classify synthetic fields and write misuse cases for unauthorized read, modification and deletion. Map each to prevention and detection evidence.
```
python3 access.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A threat/control matrix with a named owner for every important control.

6. Role workshop · debug and verify
A product name alone does not demonstrate a control works. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save security architecture and control register. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A threat/control matrix with a named owner for every important control.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Control objectives and assets: A product name alone does not demonstrate a control works.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: security architecture and control register
A threat/control matrix with a named owner for every important control.

Interview: Work through this Security Engineer case: A support export contains customer data and requires a narrower audience than public help pages. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A security control addresses a defined risk to an asset. Start with who needs access, what harm matters and where trust changes before choosing products. Expected evidence: A threat/control matrix with a named owner for every important control. Diagnosis: A product name alone does not demonstrate a control works. State the limits of the mental model: Locks are chosen after identifying the rooms and valuables they protect.

Resume: Built security architecture and control register using Threat modeling, identity controls and structured logs; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Extend access.py with audit records and test allowed read, denied write and unknown identity. Check that logs omit sensitive payloads and include action/outcome.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Code and data separation
Parameterized SQL keeps input values separate from SQL instructions.
Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.
Limit: Parameters protect values; dynamic table names still require explicit allowlists.
Example: The malicious-looking owner string is treated as a value and returns zero rows.
Recall: Why is escaping one example string weaker than using parameters?

### Defense in depth and verification
Independent controls reduce reliance on a single failure point. Verify authorization, input handling and audit behavior with concrete positive and negative cases.
Mental model: A locked door, restricted key and alarm serve different purposes.
Limit: Logging full payloads can create a new data exposure; inspect fields deliberately.
Example: An authenticated reader must still be denied a write, and the denial should produce a useful audit event.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Logging full payloads can create a new data exposure; inspect fields deliberately.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
An authenticated reader must still be denied a write, and the denial should produce a useful audit event. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Extend access.py with audit records and test allowed read, denied write and unknown identity. Check that logs omit sensitive payloads and include action/outcome.
```
python3 access.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Correct allow/deny decisions and useful minimal audit evidence.

6. Role workshop · debug and verify
Logging full payloads can create a new data exposure; inspect fields deliberately. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save control tests and log schema. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Correct allow/deny decisions and useful minimal audit evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Defense in depth and verification: Logging full payloads can create a new data exposure; inspect fields deliberately.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: control tests and log schema
Correct allow/deny decisions and useful minimal audit evidence.

Interview: Work through this Security Engineer case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Independent controls reduce reliance on a single failure point. Verify authorization, input handling and audit behavior with concrete positive and negative cases. Expected evidence: Correct allow/deny decisions and useful minimal audit evidence. Diagnosis: Logging full payloads can create a new data exposure; inspect fields deliberately. State the limits of the mental model: A locked door, restricted key and alarm serve different purposes.

Resume: Built control tests and log schema using Threat modeling, identity controls and structured logs; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Review the earlier threat model for the new feature, define an alert and response playbook, and write a release recommendation with unresolved controls and accountable owners.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Threat models and regression
State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.
Mental model: Mark doors and valuable rooms on a building map before choosing locks.
Limit: A threat model is a living hypothesis, not proof that the system is secure.
Example: Reader-write, unknown-read and unsupported-delete must all be denied.
Recall: How would a new export endpoint change the threat model?

### Residual risk and response readiness
No finite test suite proves absence of risk. State residual risks, operational detection and the conditions that require re-review after a system change.
Mental model: A building inspection includes maintenance and emergency plans, not a permanent guarantee.
Limit: Do not convert untested assumptions into passed controls to complete a checklist.
Example: A new bulk-export feature changes both data exposure and incident response needs.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not convert untested assumptions into passed controls to complete a checklist.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A new bulk-export feature changes both data exposure and incident response needs. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Review the earlier threat model for the new feature, define an alert and response playbook, and write a release recommendation with unresolved controls and accountable owners.
```
python3 access.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A bounded recommendation with re-review triggers.

6. Role workshop · debug and verify
Do not convert untested assumptions into passed controls to complete a checklist. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save security readiness review and response tabletop. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A bounded recommendation with re-review triggers.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Residual risk and response readiness: Do not convert untested assumptions into passed controls to complete a checklist.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: security readiness review and response tabletop
A bounded recommendation with re-review triggers.

Interview: Work through this Security Engineer case: A new bulk-export feature changes both data exposure and incident response needs. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: No finite test suite proves absence of risk. State residual risks, operational detection and the conditions that require re-review after a system change. Expected evidence: A bounded recommendation with re-review triggers. Diagnosis: Do not convert untested assumptions into passed controls to complete a checklist. State the limits of the mental model: A building inspection includes maintenance and emergency plans, not a permanent guarantee.

Resume: Built security readiness review and response tabletop using Threat modeling, identity controls and structured logs; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
