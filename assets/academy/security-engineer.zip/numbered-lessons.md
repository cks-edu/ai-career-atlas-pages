# Security Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Authentication and authorization: Authentication establishes identity; authorization decides which action that identity may perform.

Apply authentication and authorization in Security Engineer: Use the concept to complete this role exercise: Map assets, actors, entry points and trust boundaries

Control objectives and assets: A security control addresses a defined risk to an asset. Start with who needs access, what harm matters and where trust changes before choosing products.

### Authentication and authorization

Authentication establishes identity; authorization decides which action that identity may perform. In this role, work through: A support export contains customer data and requires a narrower audience than public help pages. The practical workshop develops this into: Draw the data flow, classify synthetic fields and write misuse cases for unauthorized read, modification and deletion. Map each to prevention and detection evidence.

Mental model: An ID card tells who you are; the door policy says where you may enter.

Boundary: A valid login does not authorize access to every record.

Role application: Locks are chosen after identifying the rooms and valuables they protect.

A security control addresses a defined risk to an asset. Start with who needs access, what harm matters and where trust changes before choosing products.

Worked example: A support export contains customer data and requires a narrower audience than public help pages.

Shared foundation example: Alice may read but not write; an unknown user is denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Threat modeling, identity controls and structured logs (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Security Engineer: A support export contains customer data and requires a narrower audience than public help pages.

Predict the worked case

Read this case without running a tool: A support export contains customer data and requires a narrower audience than public help pages. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in authentication and authorization.

Connect the concept to the role

Apply this rule: Authentication establishes identity; authorization decides which action that identity may perform. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A valid login does not authorize access to every record.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies authentication and authorization to this case: A support export contains customer data and requires a narrower audience than public help pages. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A support export contains customer data and requires a narrower audience than public help pages. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Authentication and authorization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with authentication and authorization. Use the glossary below, then write your prediction for: A support export contains customer data and requires a narrower audience than public help pages. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Engineer role interview. Explain authentication and authorization using this case: A support export contains customer data and requires a narrower audience than public help pages. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate authentication and authorization to a system or workflow you know. Explain authentication and authorization using this case: A support export contains customer data and requires a narrower audience than public help pages. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Where should an object ownership check happen?

Interview: Explain authentication and authorization using this case: A support export contains customer data and requires a narrower audience than public help pages. State the evidence, one alternative and where the mental model stops.

Quiz: After the Control objectives and assets rehearsal, check this foundation: A logged-in user requests another user’s private record. What must the service still check?

Whether this identity is permitted to perform this action on that record.

Only whether the session token has the correct syntax.

Only whether the record identifier exists.

Reference: Whether this identity is permitted to perform this action on that record. — Authentication establishes identity; authorization checks the action and resource.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Control objectives and assets

A security control addresses a defined risk to an asset. Start with who needs access, what harm matters and where trust changes before choosing products. In this role, work through: A support export contains customer data and requires a narrower audience than public help pages. The practical workshop develops this into: Draw the data flow, classify synthetic fields and write misuse cases for unauthorized read, modification and deletion. Map each to prevention and detection evidence.

Mental model: Locks are chosen after identifying the rooms and valuables they protect.

Boundary: A product name alone does not demonstrate a control works.

Worked example: A support export contains customer data and requires a narrower audience than public help pages.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Threat modeling, identity controls and structured logs (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Security Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Draw the data flow, classify synthetic fields and write misuse cases for unauthorized read, modification and deletion. Map each to prevention and detection evidence.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A support export contains customer data and requires a narrower audience than public help pages. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Draw the data flow, classify synthetic fields and write misuse cases for unauthorized read, modification and deletion. Map each to prevention and detection evidence.

```
python3 access.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A threat/control matrix with a named owner for every important control.

Role workshop · debug and verify

A product name alone does not demonstrate a control works. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save security architecture and control register. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A threat/control matrix with a named owner for every important control.

Expected: A threat/control matrix with a named owner for every important control.

Troubleshoot: The role exercise differs from the prediction: A product name alone does not demonstrate a control works.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: security architecture and control register; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with control objectives and assets. Use the glossary below, then write your prediction for: A support export contains customer data and requires a narrower audience than public help pages. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Engineer role interview. Explain control objectives and assets using this case: A support export contains customer data and requires a narrower audience than public help pages. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate control objectives and assets to a system or workflow you know. Explain control objectives and assets using this case: A support export contains customer data and requires a narrower audience than public help pages. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A product name alone does not demonstrate a control works.

Interview: Explain control objectives and assets using this case: A support export contains customer data and requires a narrower audience than public help pages. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A support export contains customer data and requires a narrower audience than public help pages.

A threat/control matrix with a named owner for every important control.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A threat/control matrix with a named owner for every important control. — A security control addresses a defined risk to an asset. Start with who needs access, what harm matters and where trust changes before choosing products. A threat/control matrix with a named owner for every important control.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Code and data separation: Parameterized SQL keeps input values separate from SQL instructions.

Apply code and data separation in Security Engineer: Use the concept to complete this role exercise: Test authentication, authorization and sensitive-data handling

Defense in depth and verification: Independent controls reduce reliance on a single failure point. Verify authorization, input handling and audit behavior with concrete positive and negative cases.

### Code and data separation

Parameterized SQL keeps input values separate from SQL instructions. In this role, work through: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. The practical workshop develops this into: Extend access.py with audit records and test allowed read, denied write and unknown identity. Check that logs omit sensitive payloads and include action/outcome.

Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.

Boundary: Parameters protect values; dynamic table names still require explicit allowlists.

Role application: A locked door, restricted key and alarm serve different purposes.

Independent controls reduce reliance on a single failure point. Verify authorization, input handling and audit behavior with concrete positive and negative cases.

Worked example: An authenticated reader must still be denied a write, and the denial should produce a useful audit event.

Shared foundation example: The malicious-looking owner string is treated as a value and returns zero rows.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Threat modeling, identity controls and structured logs (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Security Engineer: An authenticated reader must still be denied a write, and the denial should produce a useful audit event.

Predict the worked case

Read this case without running a tool: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in code and data separation.

Connect the concept to the role

Apply this rule: Parameterized SQL keeps input values separate from SQL instructions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Parameters protect values; dynamic table names still require explicit allowlists.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies code and data separation to this case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Code and data separation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with code and data separation. Use the glossary below, then write your prediction for: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Engineer role interview. Explain code and data separation using this case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate code and data separation to a system or workflow you know. Explain code and data separation using this case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is escaping one example string weaker than using parameters?

Interview: Explain code and data separation using this case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. State the evidence, one alternative and where the mental model stops.

Quiz: After the Defense in depth and verification rehearsal, check this foundation: A query binds a user value through a parameter. Can that same placeholder choose an arbitrary table name?

Yes, placeholders bind all SQL syntax.

No; structural identifiers need an allowlisted query design.

Yes, if the identifier arrives over HTTPS.

Reference: No; structural identifiers need an allowlisted query design. — Parameters bind values, not arbitrary SQL structure. Transport security does not change SQL semantics.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Defense in depth and verification

Independent controls reduce reliance on a single failure point. Verify authorization, input handling and audit behavior with concrete positive and negative cases. In this role, work through: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. The practical workshop develops this into: Extend access.py with audit records and test allowed read, denied write and unknown identity. Check that logs omit sensitive payloads and include action/outcome.

Mental model: A locked door, restricted key and alarm serve different purposes.

Boundary: Logging full payloads can create a new data exposure; inspect fields deliberately.

Worked example: An authenticated reader must still be denied a write, and the denial should produce a useful audit event.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Threat modeling, identity controls and structured logs (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Security Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Extend access.py with audit records and test allowed read, denied write and unknown identity. Check that logs omit sensitive payloads and include action/outcome.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

An authenticated reader must still be denied a write, and the denial should produce a useful audit event. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Extend access.py with audit records and test allowed read, denied write and unknown identity. Check that logs omit sensitive payloads and include action/outcome.

```
python3 access.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Correct allow/deny decisions and useful minimal audit evidence.

Role workshop · debug and verify

Logging full payloads can create a new data exposure; inspect fields deliberately. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save control tests and log schema. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Correct allow/deny decisions and useful minimal audit evidence.

Expected: Correct allow/deny decisions and useful minimal audit evidence.

Troubleshoot: The role exercise differs from the prediction: Logging full payloads can create a new data exposure; inspect fields deliberately.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: control tests and log schema; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defense in depth and verification. Use the glossary below, then write your prediction for: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Engineer role interview. Explain defense in depth and verification using this case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defense in depth and verification to a system or workflow you know. Explain defense in depth and verification using this case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Logging full payloads can create a new data exposure; inspect fields deliberately.

Interview: Explain defense in depth and verification using this case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? An authenticated reader must still be denied a write, and the denial should produce a useful audit event.

Ignore the failing case and keep only the successful screenshot.

Correct allow/deny decisions and useful minimal audit evidence.

Treat any successful command as proof that all business and access rules passed.

Reference: Correct allow/deny decisions and useful minimal audit evidence. — Independent controls reduce reliance on a single failure point. Verify authorization, input handling and audit behavior with concrete positive and negative cases. Correct allow/deny decisions and useful minimal audit evidence.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Threat models and regression: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.

Apply threat models and regression in Security Engineer: Use the concept to complete this role exercise: Write a control-validation plan and an incident recovery tabletop

Residual risk and response readiness: No finite test suite proves absence of risk. State residual risks, operational detection and the conditions that require re-review after a system change.

### Threat models and regression

State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. In this role, work through: A new bulk-export feature changes both data exposure and incident response needs. The practical workshop develops this into: Review the earlier threat model for the new feature, define an alert and response playbook, and write a release recommendation with unresolved controls and accountable owners.

Mental model: Mark doors and valuable rooms on a building map before choosing locks.

Boundary: A threat model is a living hypothesis, not proof that the system is secure.

Role application: A building inspection includes maintenance and emergency plans, not a permanent guarantee.

No finite test suite proves absence of risk. State residual risks, operational detection and the conditions that require re-review after a system change.

Worked example: A new bulk-export feature changes both data exposure and incident response needs.

Shared foundation example: Reader-write, unknown-read and unsupported-delete must all be denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Threat modeling, identity controls and structured logs (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Security Engineer: A new bulk-export feature changes both data exposure and incident response needs.

Predict the worked case

Read this case without running a tool: A new bulk-export feature changes both data exposure and incident response needs. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in threat models and regression.

Connect the concept to the role

Apply this rule: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A threat model is a living hypothesis, not proof that the system is secure.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies threat models and regression to this case: A new bulk-export feature changes both data exposure and incident response needs. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A new bulk-export feature changes both data exposure and incident response needs. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Threat models and regression; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with threat models and regression. Use the glossary below, then write your prediction for: A new bulk-export feature changes both data exposure and incident response needs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Engineer role interview. Explain threat models and regression using this case: A new bulk-export feature changes both data exposure and incident response needs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate threat models and regression to a system or workflow you know. Explain threat models and regression using this case: A new bulk-export feature changes both data exposure and incident response needs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would a new export endpoint change the threat model?

Interview: Explain threat models and regression using this case: A new bulk-export feature changes both data exposure and incident response needs. State the evidence, one alternative and where the mental model stops.

Quiz: After the Residual risk and response readiness rehearsal, check this foundation: A denied action is fixed after a security defect. What helps detect its recurrence?

Document only the successful authorized path.

Remove the denied case because it now passes.

Add a repeatable negative test tied to the actor, action and trust boundary.

Reference: Add a repeatable negative test tied to the actor, action and trust boundary. — Regression checks preserve evidence for important misuse cases; the threat model explains why the control matters.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Residual risk and response readiness

No finite test suite proves absence of risk. State residual risks, operational detection and the conditions that require re-review after a system change. In this role, work through: A new bulk-export feature changes both data exposure and incident response needs. The practical workshop develops this into: Review the earlier threat model for the new feature, define an alert and response playbook, and write a release recommendation with unresolved controls and accountable owners.

Mental model: A building inspection includes maintenance and emergency plans, not a permanent guarantee.

Boundary: Do not convert untested assumptions into passed controls to complete a checklist.

Worked example: A new bulk-export feature changes both data exposure and incident response needs.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Threat modeling, identity controls and structured logs (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Security Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Review the earlier threat model for the new feature, define an alert and response playbook, and write a release recommendation with unresolved controls and accountable owners.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A new bulk-export feature changes both data exposure and incident response needs. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Review the earlier threat model for the new feature, define an alert and response playbook, and write a release recommendation with unresolved controls and accountable owners.

```
python3 access.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A bounded recommendation with re-review triggers.

Role workshop · debug and verify

Do not convert untested assumptions into passed controls to complete a checklist. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save security readiness review and response tabletop. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A bounded recommendation with re-review triggers.

Expected: A bounded recommendation with re-review triggers.

Troubleshoot: The role exercise differs from the prediction: Do not convert untested assumptions into passed controls to complete a checklist.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: security readiness review and response tabletop; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with residual risk and response readiness. Use the glossary below, then write your prediction for: A new bulk-export feature changes both data exposure and incident response needs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Security Engineer role interview. Explain residual risk and response readiness using this case: A new bulk-export feature changes both data exposure and incident response needs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate residual risk and response readiness to a system or workflow you know. Explain residual risk and response readiness using this case: A new bulk-export feature changes both data exposure and incident response needs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not convert untested assumptions into passed controls to complete a checklist.

Interview: Explain residual risk and response readiness using this case: A new bulk-export feature changes both data exposure and incident response needs. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A new bulk-export feature changes both data exposure and incident response needs.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A bounded recommendation with re-review triggers.

Reference: A bounded recommendation with re-review triggers. — No finite test suite proves absence of risk. State residual risks, operational detection and the conditions that require re-review after a system change. A bounded recommendation with re-review triggers.

Sources:

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
