# Security Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Control objectives and assets

A security control addresses a defined risk to an asset. Start with who needs access, what harm matters and where trust changes before choosing products.
Mental model: Locks are chosen after identifying the rooms and valuables they protect.
Case: A support export contains customer data and requires a narrower audience than public help pages.
Task: Draw the data flow, classify synthetic fields and write misuse cases for unauthorized read, modification and deletion. Map each to prevention and detection evidence.
Acceptance: A threat/control matrix with a named owner for every important control.
Troubleshooting: A product name alone does not demonstrate a control works.
Deliverable: security architecture and control register

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Defense in depth and verification

Independent controls reduce reliance on a single failure point. Verify authorization, input handling and audit behavior with concrete positive and negative cases.
Mental model: A locked door, restricted key and alarm serve different purposes.
Case: An authenticated reader must still be denied a write, and the denial should produce a useful audit event.
Task: Extend access.py with audit records and test allowed read, denied write and unknown identity. Check that logs omit sensitive payloads and include action/outcome.
Acceptance: Correct allow/deny decisions and useful minimal audit evidence.
Troubleshooting: Logging full payloads can create a new data exposure; inspect fields deliberately.
Deliverable: control tests and log schema

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Residual risk and response readiness

No finite test suite proves absence of risk. State residual risks, operational detection and the conditions that require re-review after a system change.
Mental model: A building inspection includes maintenance and emergency plans, not a permanent guarantee.
Case: A new bulk-export feature changes both data exposure and incident response needs.
Task: Review the earlier threat model for the new feature, define an alert and response playbook, and write a release recommendation with unresolved controls and accountable owners.
Acceptance: A bounded recommendation with re-review triggers.
Troubleshooting: Do not convert untested assumptions into passed controls to complete a checklist.
Deliverable: security readiness review and response tabletop

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
