# Cloud Security Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Cloud control and data planes

Cloud administration and data access are distinct attack surfaces. A principal may configure a resource without needing to read its stored business data.
Mental model: A building manager can repair the lock without opening every tenant's safe.
Case: Viewing a storage resource in the console does not necessarily authorize reading its objects.
Task: Create a two-plane access diagram for a fictional app. List deployment, runtime and analyst identities and their minimum actions; map each to official provider guidance.
Acceptance: No identity receives broad access merely for convenience.
Troubleshooting: An authorization failure needs the exact action/resource context, not a blanket administrator grant.
Deliverable: cloud access architecture

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Configuration drift and evidence

A secure configuration can drift after deployment. Version intended policy, observe actual settings and make exceptions explicit rather than silently changing the baseline.
Mental model: An inspection compares the building with the approved plan, including approved deviations.
Case: A storage endpoint intended to be private becomes publicly reachable after a change.
Task: Create intended/observed configuration JSON fixtures and a diff report. Flag public access, unrestricted ingress and missing logging; label this a policy simulation, then map checks to a sandbox provider tool if available.
Acceptance: Each drift item has a reason, owner and remediation action.
Troubleshooting: A text diff alone cannot prove effective access; verify actual policy evaluation in the provider.
Deliverable: drift checker and exception register

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Credential compromise response

Respond to exposed cloud credentials by scoping access, preserving audit evidence, revoking credentials and checking affected resources. Rotation alone does not undo prior actions.
Mental model: Replacing a stolen key does not inventory what was taken.
Case: A build credential may have modified storage policy during its exposure window.
Task: Use synthetic audit events to build a timeline, list accessible assets and propose containment. Define a clean deployment identity and post-recovery access checks.
Acceptance: A response plan covering both credential replacement and resource integrity.
Troubleshooting: Do not destroy logs or assume the last visible action was the only action.
Deliverable: cloud incident case and recovery checklist

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
