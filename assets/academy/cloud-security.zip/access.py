import sys, sqlite3
users={'alice':{'role':'reader'},'bob':{'role':'editor'}}
def allowed(user,action):
    return user in users and (action=='read' or (action=='write' and users[user]['role']=='editor'))
assert allowed('alice','read') and not allowed('alice','write') and not allowed('unknown','read')
print('reader: read allowed; write denied; unknown denied')
db=sqlite3.connect(':memory:');db.execute('CREATE TABLE notes (owner TEXT, note TEXT)');db.execute('INSERT INTO notes VALUES (?,?)',('alice','hello'))
def get(owner):return db.execute('SELECT note FROM notes WHERE owner=?',(owner,)).fetchall()
if sys.argv[1]!='beginner':
    assert get('alice')==[('hello',)] and get("' OR 1=1 --")==[]
    print('parameterized query: malicious fixture returns 0 rows')
if sys.argv[1]=='advanced':
    tests=[('alice','write',False),('bob','write',True),('unknown','read',False),('bob','delete',False)]
    assert all(allowed(u,a)==v for u,a,v in tests)
    print('4 authorization regression cases pass')
print('PASS security '+sys.argv[1]);db.close()
