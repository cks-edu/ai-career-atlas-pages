# Cloud Security Engineer

Software Engineering

Start with cloud control and data planes. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward cloud incident case and recovery checklist.

## beginner

Create a two-plane access diagram for a fictional app. List deployment, runtime and analyst identities and their minimum actions; map each to official provider guidance.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Authentication and authorization
Authentication establishes identity; authorization decides which action that identity may perform.
Mental model: An ID card tells who you are; the door policy says where you may enter.
Limit: A valid login does not authorize access to every record.
Example: Alice may read but not write; an unknown user is denied.
Recall: Where should an object ownership check happen?

### Cloud control and data planes
Cloud administration and data access are distinct attack surfaces. A principal may configure a resource without needing to read its stored business data.
Mental model: A building manager can repair the lock without opening every tenant's safe.
Limit: An authorization failure needs the exact action/resource context, not a blanket administrator grant.
Example: Viewing a storage resource in the console does not necessarily authorize reading its objects.
Recall: Explain the expected result before running the exercise, then diagnose this failure: An authorization failure needs the exact action/resource context, not a blanket administrator grant.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Viewing a storage resource in the console does not necessarily authorize reading its objects. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a two-plane access diagram for a fictional app. List deployment, runtime and analyst identities and their minimum actions; map each to official provider guidance.
Expected: No identity receives broad access merely for convenience.

6. Role workshop · debug and verify
An authorization failure needs the exact action/resource context, not a blanket administrator grant. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save cloud access architecture. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: No identity receives broad access merely for convenience.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cloud control and data planes: An authorization failure needs the exact action/resource context, not a blanket administrator grant.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: cloud access architecture
No identity receives broad access merely for convenience.

Interview: Work through this Cloud Security Engineer case: Viewing a storage resource in the console does not necessarily authorize reading its objects. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Cloud administration and data access are distinct attack surfaces. A principal may configure a resource without needing to read its stored business data. Expected evidence: No identity receives broad access merely for convenience. Diagnosis: An authorization failure needs the exact action/resource context, not a blanket administrator grant. State the limits of the mental model: A building manager can repair the lock without opening every tenant's safe.

Resume: Built cloud access architecture using Cloud IAM, network policy and audit logging; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create intended/observed configuration JSON fixtures and a diff report. Flag public access, unrestricted ingress and missing logging; label this a policy simulation, then map checks to a sandbox provider tool if available.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Code and data separation
Parameterized SQL keeps input values separate from SQL instructions.
Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.
Limit: Parameters protect values; dynamic table names still require explicit allowlists.
Example: The malicious-looking owner string is treated as a value and returns zero rows.
Recall: Why is escaping one example string weaker than using parameters?

### Configuration drift and evidence
A secure configuration can drift after deployment. Version intended policy, observe actual settings and make exceptions explicit rather than silently changing the baseline.
Mental model: An inspection compares the building with the approved plan, including approved deviations.
Limit: A text diff alone cannot prove effective access; verify actual policy evaluation in the provider.
Example: A storage endpoint intended to be private becomes publicly reachable after a change.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A text diff alone cannot prove effective access; verify actual policy evaluation in the provider.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A storage endpoint intended to be private becomes publicly reachable after a change. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create intended/observed configuration JSON fixtures and a diff report. Flag public access, unrestricted ingress and missing logging; label this a policy simulation, then map checks to a sandbox provider tool if available.
Expected: Each drift item has a reason, owner and remediation action.

6. Role workshop · debug and verify
A text diff alone cannot prove effective access; verify actual policy evaluation in the provider. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save drift checker and exception register. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Each drift item has a reason, owner and remediation action.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Configuration drift and evidence: A text diff alone cannot prove effective access; verify actual policy evaluation in the provider.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: drift checker and exception register
Each drift item has a reason, owner and remediation action.

Interview: Work through this Cloud Security Engineer case: A storage endpoint intended to be private becomes publicly reachable after a change. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A secure configuration can drift after deployment. Version intended policy, observe actual settings and make exceptions explicit rather than silently changing the baseline. Expected evidence: Each drift item has a reason, owner and remediation action. Diagnosis: A text diff alone cannot prove effective access; verify actual policy evaluation in the provider. State the limits of the mental model: An inspection compares the building with the approved plan, including approved deviations.

Resume: Built drift checker and exception register using Cloud IAM, network policy and audit logging; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Use synthetic audit events to build a timeline, list accessible assets and propose containment. Define a clean deployment identity and post-recovery access checks.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Threat models and regression
State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.
Mental model: Mark doors and valuable rooms on a building map before choosing locks.
Limit: A threat model is a living hypothesis, not proof that the system is secure.
Example: Reader-write, unknown-read and unsupported-delete must all be denied.
Recall: How would a new export endpoint change the threat model?

### Credential compromise response
Respond to exposed cloud credentials by scoping access, preserving audit evidence, revoking credentials and checking affected resources. Rotation alone does not undo prior actions.
Mental model: Replacing a stolen key does not inventory what was taken.
Limit: Do not destroy logs or assume the last visible action was the only action.
Example: A build credential may have modified storage policy during its exposure window.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not destroy logs or assume the last visible action was the only action.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A build credential may have modified storage policy during its exposure window. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use synthetic audit events to build a timeline, list accessible assets and propose containment. Define a clean deployment identity and post-recovery access checks.
Expected: A response plan covering both credential replacement and resource integrity.

6. Role workshop · debug and verify
Do not destroy logs or assume the last visible action was the only action. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save cloud incident case and recovery checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A response plan covering both credential replacement and resource integrity.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Credential compromise response: Do not destroy logs or assume the last visible action was the only action.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: cloud incident case and recovery checklist
A response plan covering both credential replacement and resource integrity.

Interview: Work through this Cloud Security Engineer case: A build credential may have modified storage policy during its exposure window. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Respond to exposed cloud credentials by scoping access, preserving audit evidence, revoking credentials and checking affected resources. Rotation alone does not undo prior actions. Expected evidence: A response plan covering both credential replacement and resource integrity. Diagnosis: Do not destroy logs or assume the last visible action was the only action. State the limits of the mental model: Replacing a stolen key does not inventory what was taken.

Resume: Built cloud incident case and recovery checklist using Cloud IAM, network policy and audit logging; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/
OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
