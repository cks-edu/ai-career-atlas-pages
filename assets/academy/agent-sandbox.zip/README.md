# Agent sandbox & execution infrastructure

AI Engineering · Beginner → Intermediate → Advanced

Start with Execution threat models. A sandbox is a restricted execution environment. Limits must cover files, network access and resource use, not just the command name. Then try Design a restricted code exercise. The three levels build toward Bounded code execution environment. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Execution threat models

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Execution threat models
Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls.
Mental model: An unknown chemical is handled inside a defined protective enclosure.
Boundary: A benign demo cannot prove a sandbox resists every escape technique.
Worked example: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A completed run leaves writable state behind
The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Three runs leave mutable artifacts that another tenant could encounter. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Use separate per-run storage and a verified cleanup or quarantine lifecycle.
Recall: Test concurrent runs, timeout cleanup and safe artifact export without host secrets. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Execution threat models: Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A sandbox is a restricted execution environment. Limits must cover files, network access and resource use, not just the command name.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine an assistant running learner code in a disposable training environment. List allowed files and explicitly exclude credentials and host files.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A sandbox policy sketch and three rejection cases.

3. Try step 2
Define limits for runtime, memory and network access.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A sandbox policy sketch and three rejection cases.

4. Try step 3
Describe expected behavior for an infinite loop, a secret-file read and an external connection attempt, without executing them.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A sandbox policy sketch and three rejection cases.

5. Explain and check your result
Each case has an enforced boundary and expected result; the exercise makes no claim that a real sandbox was deployed. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A sandbox policy sketch and three rejection cases. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Apply this toy-case rule manually: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three runs leave mutable artifacts that another tenant could encounter. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Agent sandbox & execution infrastructure.
Imagine an assistant running learner code in a disposable training environment. List allowed files and explicitly exclude credentials and host files.
Define limits for runtime, memory and network access.
Describe expected behavior for an infinite loop, a secret-file read and an external connection attempt, without executing them.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A sandbox policy sketch and three rejection cases. Include beginner-worksheet.md and your completed Sandbox isolation and lifecycle checklist.
Check: Each case has an enforced boundary and expected result; the exercise makes no claim that a real sandbox was deployed.

### Interview
Explain your beginner solution for Agent sandbox & execution infrastructure. Use this scenario: The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs.
Review: Start with the task and permitted scope. Explain execution threat models: Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls. Show the input and observed output, then address Use separate per-run storage and a verified cleanup or quarantine lifecycle. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A sandbox policy sketch and three rejection cases. Include beginner-worksheet.md and your completed Sandbox isolation and lifecycle checklist.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Resource and network isolation

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Linux isolation, networking, resource controls and untrusted-code threat modeling.

### Resource and network isolation
Bound CPU, memory, execution time, filesystem writes and outbound access. Verify denied behavior instead of assuming a container default is sufficient.
Mental model: A workshop gives each experiment a bench, power limit and locked supply cupboard.
Boundary: Container boundaries and host configuration must be assessed together.
Worked example: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Bounded code execution environment
Build a lab execution service with explicit resource and filesystem boundaries. Mount only a per-job scratch directory. Define a fixed allowlist of commands and reject host paths, privileged mode and arbitrary mounts.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox.
Recall: Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. Identify one observation that would contradict your claim.

### Terms
Resource and network isolation: Bound CPU, memory, execution time, filesystem writes and outbound access. Verify denied behavior instead of assuming a container default is sufficient.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a lab execution service with explicit resource and filesystem boundaries. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Deploy the starter, then create a separate Job manifest with non-root execution, read-only root filesystem, dropped capabilities, no service-account token and resource/deadline limits.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Mount only a per-job scratch directory. Define a fixed allowlist of commands and reject host paths, privileged mode and arbitrary mounts.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Build a lab execution service with explicit resource and filesystem boundaries.
Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox.
Deploy the starter, then create a separate Job manifest with non-root execution, read-only root filesystem, dropped capabilities, no service-account token and resource/deadline limits.
Mount only a per-job scratch directory. Define a fixed allowlist of commands and reject host paths, privileged mode and arbitrary mounts.
Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.
Deliverables: Execution manifests and command contract; Isolation/timeout/cleanup evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Agent sandbox & execution infrastructure. Use this scenario: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.
Review: Start with the task and permitted scope. Explain resource and network isolation: Bound CPU, memory, execution time, filesystem writes and outbound access. Verify denied behavior instead of assuming a container default is sufficient. Show the input and observed output, then address Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Execution manifests and command contract; Isolation/timeout/cleanup evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Sandbox lifecycle

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Sandbox lifecycle
Create clean environments, collect bounded artifacts and destroy task state after use. Prevent one task from reading another task's leftovers.
Mental model: A laboratory cleans the bench between samples to avoid contamination.
Boundary: Deleting a container does not necessarily erase external volumes or logs.
Worked example: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Bounded code execution environment
Build a lab execution service with explicit resource and filesystem boundaries. Add a network policy with a CNI that actually enforces it; verify denied egress empirically. For stronger isolation, evaluate a sandbox runtime and document its threat model.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.
Recall: Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. Identify one observation that would contradict your claim.

### Terms
Sandbox lifecycle: Create clean environments, collect bounded artifacts and destroy task state after use. Prevent one task from reading another task's leftovers.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a lab execution service with explicit resource and filesystem boundaries. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Deploy the starter, then create a separate Job manifest with non-root execution, read-only root filesystem, dropped capabilities, no service-account token and resource/deadline limits.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Mount only a per-job scratch directory. Define a fixed allowlist of commands and reject host paths, privileged mode and arbitrary mounts.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add a network policy with a CNI that actually enforces it; verify denied egress empirically. For stronger isolation, evaluate a sandbox runtime and document its threat model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Build a lab execution service with explicit resource and filesystem boundaries.
Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox.
Deploy the starter, then create a separate Job manifest with non-root execution, read-only root filesystem, dropped capabilities, no service-account token and resource/deadline limits.
Mount only a per-job scratch directory. Define a fixed allowlist of commands and reject host paths, privileged mode and arbitrary mounts.
Add a network policy with a CNI that actually enforces it; verify denied egress empirically. For stronger isolation, evaluate a sandbox runtime and document its threat model.
Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.
Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.
Compare a sandboxed runtime or microVM on compatible infrastructure using the same probes.
Deliverables: Execution manifests and command contract; Isolation/timeout/cleanup evidence; Sandbox threat model and runtime ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.

### Interview
Explain your advanced solution for Agent sandbox & execution infrastructure. Use this scenario: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.
Review: Start with the task and permitted scope. Explain sandbox lifecycle: Create clean environments, collect bounded artifacts and destroy task state after use. Prevent one task from reading another task's leftovers. Show the input and observed output, then address Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Execution manifests and command contract; Isolation/timeout/cleanup evidence; Sandbox threat model and runtime ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
kind — Open source · local containers
Disposable Kubernetes cluster; requires a compatible container runtime.
Alternative: minikube (open source); managed Kubernetes is a separate commercial hosting choice, not required for a first lab.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Kubernetes security contexts — Open source · local or cloud
Resource, identity and container security controls.
Alternative: A local container or Docker Compose can suit a small service; managed cloud Kubernetes adds provider fees and responsibilities.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

OWASP GenAI security guidance — Public guidance
Threat-model and defensive-test planning.
Alternative: A role-specific threat model and policy test suite complement this guidance; buying a scanner is not an equivalent replacement.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
kind: https://kind.sigs.k8s.io/docs/user/quick-start/
Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/
OWASP GenAI security guidance: https://genai.owasp.org/llm-top-10/
Kubernetes: https://kubernetes.io/docs/tutorials/
OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/
GitHub Actions: https://docs.github.com/en/actions
