## beginner — Execution threat models

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Execution threat models
Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls.
Mental model: An unknown chemical is handled inside a defined protective enclosure.
Boundary: A benign demo cannot prove a sandbox resists every escape technique.
Worked example: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A completed run leaves writable state behind
The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Three runs leave mutable artifacts that another tenant could encounter. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Use separate per-run storage and a verified cleanup or quarantine lifecycle.
Recall: Test concurrent runs, timeout cleanup and safe artifact export without host secrets. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Execution threat models: Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A sandbox is a restricted execution environment. Limits must cover files, network access and resource use, not just the command name.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine an assistant running learner code in a disposable training environment. List allowed files and explicitly exclude credentials and host files.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A sandbox policy sketch and three rejection cases.

3. Try step 2
Define limits for runtime, memory and network access.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A sandbox policy sketch and three rejection cases.

4. Try step 3
Describe expected behavior for an infinite loop, a secret-file read and an external connection attempt, without executing them.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A sandbox policy sketch and three rejection cases.

5. Explain and check your result
Each case has an enforced boundary and expected result; the exercise makes no claim that a real sandbox was deployed. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A sandbox policy sketch and three rejection cases. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Apply this toy-case rule manually: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three runs leave mutable artifacts that another tenant could encounter. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Agent sandbox & execution infrastructure.
Imagine an assistant running learner code in a disposable training environment. List allowed files and explicitly exclude credentials and host files.
Define limits for runtime, memory and network access.
Describe expected behavior for an infinite loop, a secret-file read and an external connection attempt, without executing them.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A sandbox policy sketch and three rejection cases. Include beginner-worksheet.md and your completed Sandbox isolation and lifecycle checklist.
Check: Each case has an enforced boundary and expected result; the exercise makes no claim that a real sandbox was deployed.

### Interview
Explain your beginner solution for Agent sandbox & execution infrastructure. Use this scenario: The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs.
Review: Start with the task and permitted scope. Explain execution threat models: Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls. Show the input and observed output, then address Use separate per-run storage and a verified cleanup or quarantine lifecycle. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A sandbox policy sketch and three rejection cases. Include beginner-worksheet.md and your completed Sandbox isolation and lifecycle checklist.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

