# SAMPLE — Sandbox isolation and lifecycle checklist
Role: Agent sandbox & execution infrastructure
Case: A completed run leaves writable state behind
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs.

## Evidence table
| Record | shared_writable_artifacts (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 3 | review |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three runs leave mutable artifacts that another tenant could encounter.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Use separate per-run storage and a verified cleanup or quarantine lifecycle.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in agent sandbox & execution infrastructure.
Before release: Test concurrent runs, timeout cleanup and safe artifact export without host secrets.

## Design choice and trade-off
Constrain filesystem, network and resources; treat generated code as untrusted.
A container boundary alone does not establish strong tenant isolation; document the mechanism and threat model.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Bounded code runner: Timeouts release resources and output is size-limited.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
