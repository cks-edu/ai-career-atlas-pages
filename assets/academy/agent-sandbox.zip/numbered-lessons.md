# Agent sandbox & execution infrastructure — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Execution threat models: Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Execution threat models

Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls. In this role, work through: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An unknown chemical is handled inside a defined protective enclosure.

Boundary: A benign demo cannot prove a sandbox resists every escape technique.

Worked example: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); OWASP GenAI security guidance (Public guidance)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Agent sandbox & execution infrastructure: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible.

Predict the worked case

Read this case without running a tool: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in execution threat models.

Connect the concept to the role

Apply this rule: Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A benign demo cannot prove a sandbox resists every escape technique.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies execution threat models to this case: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Execution threat models; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with execution threat models. Use the glossary below, then write your prediction for: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent sandbox & execution infrastructure role interview. Explain execution threat models using this case: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate execution threat models to a system or workflow you know. Explain execution threat models using this case: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain execution threat models using this case: Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible.

Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls. — Assume generated code may read files, create processes and attempt network calls. Identify the assets it must not reach before choosing containment controls. A benign demo cannot prove a sandbox resists every escape technique.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

OWASP GenAI security guidance: https://genai.owasp.org/llm-top-10/

Kubernetes: https://kubernetes.io/docs/tutorials/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

GitHub Actions: https://docs.github.com/en/actions

### Diagnose: A completed run leaves writable state behind

The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Three runs leave mutable artifacts that another tenant could encounter. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Use separate per-run storage and a verified cleanup or quarantine lifecycle. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: An unknown chemical is handled inside a defined protective enclosure.

Use a disposable workspace with synthetic files and no production credentials; list the host directories that must remain inaccessible.

Worked example: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Use separate per-run storage and a verified cleanup or quarantine lifecycle.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); OWASP GenAI security guidance (Public guidance)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Three runs leave mutable artifacts that another tenant could encounter. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Apply this toy-case rule manually: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A sandbox is a restricted execution environment. Limits must cover files, network access and resource use, not just the command name.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine an assistant running learner code in a disposable training environment. List allowed files and explicitly exclude credentials and host files.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A sandbox policy sketch and three rejection cases.

Preparation · Try step 2

Define limits for runtime, memory and network access.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A sandbox policy sketch and three rejection cases.

Preparation · Try step 3

Describe expected behavior for an infinite loop, a secret-file read and an external connection attempt, without executing them.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A sandbox policy sketch and three rejection cases.

Preparation · Explain and check your result

Each case has an enforced boundary and expected result; the exercise makes no claim that a real sandbox was deployed. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A sandbox policy sketch and three rejection cases. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Apply this toy-case rule manually: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three runs leave mutable artifacts that another tenant could encounter. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three runs leave mutable artifacts that another tenant could encounter. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a completed run leaves writable state behind. Use the glossary below, then write your prediction for: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Use separate per-run storage and a verified cleanup or quarantine lifecycle. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent sandbox & execution infrastructure role interview. Explain diagnose: a completed run leaves writable state behind using this case: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Use separate per-run storage and a verified cleanup or quarantine lifecycle. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a completed run leaves writable state behind to a system or workflow you know. Explain diagnose: a completed run leaves writable state behind using this case: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Use separate per-run storage and a verified cleanup or quarantine lifecycle. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Test concurrent runs, timeout cleanup and safe artifact export without host secrets. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a completed run leaves writable state behind using this case: Review when shared_writable_artifacts >= 1 (count). This is a declared toy-case contract, not an industry standard. Use separate per-run storage and a verified cleanup or quarantine lifecycle. State the evidence, one alternative and where the mental model stops.

Quiz: A completed run leaves writable state behind: The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs.

Change the acceptance rule after seeing an inconvenient result.

Use separate per-run storage and a verified cleanup or quarantine lifecycle.

Omit failed cases and report only the successful demonstrations.

Reference: Use separate per-run storage and a verified cleanup or quarantine lifecycle. — Use separate per-run storage and a verified cleanup or quarantine lifecycle. Test concurrent runs, timeout cleanup and safe artifact export without host secrets.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

OWASP GenAI security guidance: https://genai.owasp.org/llm-top-10/

Kubernetes: https://kubernetes.io/docs/tutorials/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

GitHub Actions: https://docs.github.com/en/actions

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Linux isolation, networking, resource controls and untrusted-code threat modeling.

Terms:

Resource and network isolation: Bound CPU, memory, execution time, filesystem writes and outbound access. Verify denied behavior instead of assuming a container default is sufficient.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

Pod: A Kubernetes unit containing one or more containers scheduled together.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Resource and network isolation

Bound CPU, memory, execution time, filesystem writes and outbound access. Verify denied behavior instead of assuming a container default is sufficient. In this role, work through: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A workshop gives each experiment a bench, power limit and locked supply cupboard.

Boundary: Container boundaries and host configuration must be assessed together.

Worked example: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Linux isolation, networking, resource controls and untrusted-code threat modeling.

Tools for this exercise: Document or text editor

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); OWASP GenAI security guidance (Public guidance)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Agent sandbox & execution infrastructure: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied.

Predict the worked case

Read this case without running a tool: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in resource and network isolation.

Connect the concept to the role

Apply this rule: Bound CPU, memory, execution time, filesystem writes and outbound access. Verify denied behavior instead of assuming a container default is sufficient. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Container boundaries and host configuration must be assessed together.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies resource and network isolation to this case: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Resource and network isolation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with resource and network isolation. Use the glossary below, then write your prediction for: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent sandbox & execution infrastructure role interview. Explain resource and network isolation using this case: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate resource and network isolation to a system or workflow you know. Explain resource and network isolation using this case: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain resource and network isolation using this case: A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied.

Treat a passing starter as proof of the whole role workflow.

Bound CPU, memory, execution time, filesystem writes and outbound access. Verify denied behavior instead of assuming a container default is sufficient.

Ignore the failure because the tool produced an output.

Reference: Bound CPU, memory, execution time, filesystem writes and outbound access. Verify denied behavior instead of assuming a container default is sufficient. — Bound CPU, memory, execution time, filesystem writes and outbound access. Verify denied behavior instead of assuming a container default is sufficient. Container boundaries and host configuration must be assessed together.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

OWASP GenAI security guidance: https://genai.owasp.org/llm-top-10/

Kubernetes: https://kubernetes.io/docs/tutorials/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

GitHub Actions: https://docs.github.com/en/actions

### Integrate: Bounded code execution environment

Build a lab execution service with explicit resource and filesystem boundaries. Mount only a per-job scratch directory. Define a fixed allowlist of commands and reject host paths, privileged mode and arbitrary mounts. In this role, work through: Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Role application: A workshop gives each experiment a bench, power limit and locked supply cupboard.

A runaway process reaches its declared time limit and is stopped; a request to an unapproved endpoint is denied.

Worked example: Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox.

Setup: Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); OWASP GenAI security guidance (Public guidance)

Build a lab execution service with explicit resource and filesystem boundaries. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Build a lab execution service with explicit resource and filesystem boundaries.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Prepare the project inputs

Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Deploy the starter, then create a separate Job manifest with non-root execution, read-only root filesystem, dropped capabilities, no service-account token and resource/deadline limits.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Mount only a per-job scratch directory. Define a fixed allowlist of commands and reject host paths, privileged mode and arbitrary mounts.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The sandbox lifecycle contract permits zero writable artifacts shared between isolated tenant runs. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Deliverable: lesson-intermediate-2.md: Execution manifests and command contract; Isolation/timeout/cleanup evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: bounded code execution environment. Use the glossary below, then write your prediction for: Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent sandbox & execution infrastructure role interview. Explain integrate: bounded code execution environment using this case: Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: bounded code execution environment to a system or workflow you know. Explain integrate: bounded code execution environment using this case: Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. Identify one observation that would contradict your claim.

Interview: Explain integrate: bounded code execution environment using this case: Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Bounded code execution environment at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.

Reference: Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. — Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

OWASP GenAI security guidance: https://genai.owasp.org/llm-top-10/

Kubernetes: https://kubernetes.io/docs/tutorials/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

GitHub Actions: https://docs.github.com/en/actions

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Sandbox lifecycle: Create clean environments, collect bounded artifacts and destroy task state after use. Prevent one task from reading another task's leftovers.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

Pod: A Kubernetes unit containing one or more containers scheduled together.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Sandbox lifecycle

Create clean environments, collect bounded artifacts and destroy task state after use. Prevent one task from reading another task's leftovers. In this role, work through: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A laboratory cleans the bench between samples to avoid contamination.

Boundary: Deleting a container does not necessarily erase external volumes or logs.

Worked example: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); OWASP GenAI security guidance (Public guidance)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Agent sandbox & execution infrastructure: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result.

Predict the worked case

Read this case without running a tool: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in sandbox lifecycle.

Connect the concept to the role

Apply this rule: Create clean environments, collect bounded artifacts and destroy task state after use. Prevent one task from reading another task's leftovers. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Deleting a container does not necessarily erase external volumes or logs.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies sandbox lifecycle to this case: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Sandbox lifecycle; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with sandbox lifecycle. Use the glossary below, then write your prediction for: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent sandbox & execution infrastructure role interview. Explain sandbox lifecycle using this case: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate sandbox lifecycle to a system or workflow you know. Explain sandbox lifecycle using this case: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain sandbox lifecycle using this case: Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Create clean environments, collect bounded artifacts and destroy task state after use. Prevent one task from reading another task's leftovers.

Reference: Create clean environments, collect bounded artifacts and destroy task state after use. Prevent one task from reading another task's leftovers. — Create clean environments, collect bounded artifacts and destroy task state after use. Prevent one task from reading another task's leftovers. Deleting a container does not necessarily erase external volumes or logs.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

OWASP GenAI security guidance: https://genai.owasp.org/llm-top-10/

Kubernetes: https://kubernetes.io/docs/tutorials/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

GitHub Actions: https://docs.github.com/en/actions

### Defend: Bounded code execution environment

Build a lab execution service with explicit resource and filesystem boundaries. Add a network policy with a CNI that actually enforces it; verify denied egress empirically. For stronger isolation, evaluate a sandbox runtime and document its threat model. In this role, work through: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Role application: A laboratory cleans the bench between samples to avoid contamination.

Write a marker in task A, start task B from a fresh image and verify the marker is absent before accepting B's result.

Worked example: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.

Setup: Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: kind (Open source · local containers); Kubernetes security contexts (Open source · local or cloud); OWASP GenAI security guidance (Public guidance)

Build a lab execution service with explicit resource and filesystem boundaries. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Build a lab execution service with explicit resource and filesystem boundaries.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Prepare the project inputs

Use only disposable fixtures in a dedicated kind cluster. The starter HTTP pod is an infrastructure baseline, not a secure untrusted-code sandbox.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Deploy the starter, then create a separate Job manifest with non-root execution, read-only root filesystem, dropped capabilities, no service-account token and resource/deadline limits.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Mount only a per-job scratch directory. Define a fixed allowlist of commands and reject host paths, privileged mode and arbitrary mounts.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add a network policy with a CNI that actually enforces it; verify denied egress empirically. For stronger isolation, evaluate a sandbox runtime and document its threat model.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. A reviewer must reproduce one result and identify which capabilities you implemented. Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Deliverable: lesson-advanced-2.md: Execution manifests and command contract; Isolation/timeout/cleanup evidence; Sandbox threat model and runtime ADR. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: bounded code execution environment. Use the glossary below, then write your prediction for: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent sandbox & execution infrastructure role interview. Explain defend: bounded code execution environment using this case: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: bounded code execution environment to a system or workflow you know. Explain defend: bounded code execution environment using this case: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee. Identify one observation that would contradict your claim.

Interview: Explain defend: bounded code execution environment using this case: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Bounded code execution environment at this level?

Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared. — Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared. Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Kubernetes security contexts: https://kubernetes.io/docs/tasks/configure-pod-container/security-context/

OWASP GenAI security guidance: https://genai.owasp.org/llm-top-10/

Kubernetes: https://kubernetes.io/docs/tutorials/

OWASP GenAI Security Project: https://genai.owasp.org/llm-top-10/

GitHub Actions: https://docs.github.com/en/actions
