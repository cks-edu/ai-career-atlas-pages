# Isolation/timeout/cleanup evidence

Project: Bounded code execution environment
Status: blank work product — not completed evidence

## Purpose and audience
Build a lab execution service with explicit resource and filesystem boundaries.

## Required content
Mount only a per-job scratch directory. Define a fixed allowlist of commands and reject host paths, privileged mode and arbitrary mounts.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.

## Failure evidence
Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
