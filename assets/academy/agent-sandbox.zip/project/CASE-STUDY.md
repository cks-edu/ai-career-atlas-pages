# Bounded code execution environment

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a lab execution service with explicit resource and filesystem boundaries.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.

## Limitations and next iteration
Compare a sandboxed runtime or microVM on compatible infrastructure using the same probes.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
