# Sandbox threat model and runtime ADR

Project: Bounded code execution environment
Status: blank work product — not completed evidence

## Purpose and audience
Build a lab execution service with explicit resource and filesystem boundaries.

## Required content
Add a network policy with a CNI that actually enforces it; verify denied egress empirically. For stronger isolation, evaluate a sandbox runtime and document its threat model.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report boundary tests, cleanup completeness and residual kernel/runtime risks. Containers alone are not a complete hostile-code isolation guarantee.

## Failure evidence
Run harmless probes that try to write outside scratch, exceed a bounded timeout and read an unmounted file. Record what is blocked and what remains shared.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
