# AI accessibility & assistive interaction — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Access needs and task barriers: Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Access needs and task barriers

Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls. In this role, work through: A generated summary has readable structure and source links; the original content remains available to assistive technology. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A ramp helps only when it connects to the entrance people need.

Boundary: Automated accessibility checks do not cover every user experience.

Worked example: A generated summary has readable structure and source links; the original content remains available to assistive technology.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Writer / Impress (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI accessibility & assistive interaction: A generated summary has readable structure and source links; the original content remains available to assistive technology.

Predict the worked case

Read this case without running a tool: A generated summary has readable structure and source links; the original content remains available to assistive technology. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in access needs and task barriers.

Connect the concept to the role

Apply this rule: Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Automated accessibility checks do not cover every user experience.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies access needs and task barriers to this case: A generated summary has readable structure and source links; the original content remains available to assistive technology. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A generated summary has readable structure and source links; the original content remains available to assistive technology. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Access needs and task barriers; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with access needs and task barriers. Use the glossary below, then write your prediction for: A generated summary has readable structure and source links; the original content remains available to assistive technology. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI accessibility & assistive interaction role interview. Explain access needs and task barriers using this case: A generated summary has readable structure and source links; the original content remains available to assistive technology. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate access needs and task barriers to a system or workflow you know. Explain access needs and task barriers using this case: A generated summary has readable structure and source links; the original content remains available to assistive technology. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain access needs and task barriers using this case: A generated summary has readable structure and source links; the original content remains available to assistive technology. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A generated summary has readable structure and source links; the original content remains available to assistive technology.

Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls. — Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls. Automated accessibility checks do not cover every user experience.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

Figma learning resources: https://help.figma.com/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Diagnose: Streaming output traps focus

The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Three tasks lose focus during updates, preventing keyboard users from completing them. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Keep focus under user control and announce updates without replacing the active interaction context. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A ramp helps only when it connects to the entrance people need.

A generated summary has readable structure and source links; the original content remains available to assistive technology.

Worked example: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Keep focus under user control and announce updates without replacing the active interaction context.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Writer / Impress (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Three tasks lose focus during updates, preventing keyboard users from completing them. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Apply this toy-case rule manually: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Accessibility starts with a specific barrier to completing a task. AI should not remove existing accessible ways to get help.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine an assistant that streams an answer, moves keyboard focus automatically and offers an unlabeled icon to stop.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated redesign and a plan to test with affected users.

Preparation · Try step 2

List potential barriers for keyboard and screen-reader use; label these as hypotheses until tested.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated redesign and a plan to test with affected users.

Preparation · Try step 3

Sketch stable focus behavior, a clearly labeled Stop button and an alternative route to the information.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated redesign and a plan to test with affected users.

Preparation · Explain and check your result

The redesign keeps a usable non-AI route; a desk review is not reported as participant research. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: An annotated redesign and a plan to test with affected users. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Apply this toy-case rule manually: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three tasks lose focus during updates, preventing keyboard users from completing them. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three tasks lose focus during updates, preventing keyboard users from completing them. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: streaming output traps focus. Use the glossary below, then write your prediction for: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Keep focus under user control and announce updates without replacing the active interaction context. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI accessibility & assistive interaction role interview. Explain diagnose: streaming output traps focus using this case: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Keep focus under user control and announce updates without replacing the active interaction context. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: streaming output traps focus to a system or workflow you know. Explain diagnose: streaming output traps focus using this case: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Keep focus under user control and announce updates without replacing the active interaction context. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Test streaming, cancellation and correction with keyboard and relevant assistive technology. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: streaming output traps focus using this case: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Keep focus under user control and announce updates without replacing the active interaction context. State the evidence, one alternative and where the mental model stops.

Quiz: Streaming output traps focus: The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker.

Change the acceptance rule after seeing an inconvenient result.

Keep focus under user control and announce updates without replacing the active interaction context.

Omit failed cases and report only the successful demonstrations.

Reference: Keep focus under user control and announce updates without replacing the active interaction context. — Keep focus under user control and announce updates without replacing the active interaction context. Test streaming, cancellation and correction with keyboard and relevant assistive technology.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

Figma learning resources: https://help.figma.com/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Accessible design and user research with disabled participants; engineering variants need frontend skills.

Terms:

Accessible error and status communication: Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Accessible error and status communication

Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction. In this role, work through: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A station announces platform changes as well as displaying them.

Boundary: Too many live announcements can overwhelm screen-reader users.

Worked example: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Accessible design and user research with disabled participants; engineering variants need frontend skills.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Writer / Impress (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI accessibility & assistive interaction: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top.

Predict the worked case

Read this case without running a tool: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in accessible error and status communication.

Connect the concept to the role

Apply this rule: Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Too many live announcements can overwhelm screen-reader users.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies accessible error and status communication to this case: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Accessible error and status communication; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with accessible error and status communication. Use the glossary below, then write your prediction for: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI accessibility & assistive interaction role interview. Explain accessible error and status communication using this case: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate accessible error and status communication to a system or workflow you know. Explain accessible error and status communication using this case: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain accessible error and status communication using this case: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top.

Treat a passing starter as proof of the whole role workflow.

Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction.

Ignore the failure because the tool produced an output.

Reference: Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction. — Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction. Too many live announcements can overwhelm screen-reader users.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

Figma learning resources: https://help.figma.com/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Integrate: Accessible AI assistance prototype

Design an AI interaction with accessible control, feedback and recovery. Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology. In this role, work through: Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A station announces platform changes as well as displaying them.

After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top.

Worked example: Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Writer / Impress (Open source · no account needed)

Design an AI interaction with accessible control, feedback and recovery. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design an AI interaction with accessible control, feedback and recovery.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

Prepare the project inputs

Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create Penpot boards and an HTML prototype with labeled controls, logical headings, keyboard navigation and visible focus. Keep status updates understandable without color alone.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Accessible prototype and interaction spec; Manual accessibility test report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: accessible ai assistance prototype. Use the glossary below, then write your prediction for: Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI accessibility & assistive interaction role interview. Explain integrate: accessible ai assistance prototype using this case: Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: accessible ai assistance prototype to a system or workflow you know. Explain integrate: accessible ai assistance prototype using this case: Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. Identify one observation that would contradict your claim.

Interview: Explain integrate: accessible ai assistance prototype using this case: Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Accessible AI assistance prototype at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.

Reference: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. — Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

Figma learning resources: https://help.figma.com/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Assistive workflow evaluation: Test with relevant assistive technologies and, when possible, consenting users. Distinguish a scripted audit from an observed user study.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Assistive workflow evaluation

Test with relevant assistive technologies and, when possible, consenting users. Distinguish a scripted audit from an observed user study. In this role, work through: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A route inspection and a journey with a traveler reveal different barriers.

Boundary: One device or impairment experience cannot represent all accessibility needs.

Worked example: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Writer / Impress (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI accessibility & assistive interaction: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results.

Predict the worked case

Read this case without running a tool: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in assistive workflow evaluation.

Connect the concept to the role

Apply this rule: Test with relevant assistive technologies and, when possible, consenting users. Distinguish a scripted audit from an observed user study. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: One device or impairment experience cannot represent all accessibility needs.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies assistive workflow evaluation to this case: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Assistive workflow evaluation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with assistive workflow evaluation. Use the glossary below, then write your prediction for: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI accessibility & assistive interaction role interview. Explain assistive workflow evaluation using this case: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate assistive workflow evaluation to a system or workflow you know. Explain assistive workflow evaluation using this case: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain assistive workflow evaluation using this case: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Test with relevant assistive technologies and, when possible, consenting users. Distinguish a scripted audit from an observed user study.

Reference: Test with relevant assistive technologies and, when possible, consenting users. Distinguish a scripted audit from an observed user study. — Test with relevant assistive technologies and, when possible, consenting users. Distinguish a scripted audit from an observed user study. One device or impairment experience cannot represent all accessibility needs.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

Figma learning resources: https://help.figma.com/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Defend: Accessible AI assistance prototype

Design an AI interaction with accessible control, feedback and recovery. Run keyboard, zoom and screen-reader checks using the WAI guidance. Where possible, test with consenting users with relevant access needs and record accommodations. In this role, work through: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A route inspection and a journey with a traveler reveal different barriers.

Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results.

Worked example: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance); LibreOffice Writer / Impress (Open source · no account needed)

Design an AI interaction with accessible control, feedback and recovery. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design an AI interaction with accessible control, feedback and recovery.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

Prepare the project inputs

Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create Penpot boards and an HTML prototype with labeled controls, logical headings, keyboard navigation and visible focus. Keep status updates understandable without color alone.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Run keyboard, zoom and screen-reader checks using the WAI guidance. Where possible, test with consenting users with relevant access needs and record accommodations.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. A reviewer must reproduce one result and identify which capabilities you implemented. Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Accessible prototype and interaction spec; Manual accessibility test report; Remediation log and user-research plan. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: accessible ai assistance prototype. Use the glossary below, then write your prediction for: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI accessibility & assistive interaction role interview. Explain defend: accessible ai assistance prototype using this case: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: accessible ai assistance prototype to a system or workflow you know. Explain defend: accessible ai assistance prototype using this case: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. Identify one observation that would contradict your claim.

Interview: Explain defend: accessible ai assistance prototype using this case: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Accessible AI assistance prototype at this level?

Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context. — Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context. Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

Figma learning resources: https://help.figma.com/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
