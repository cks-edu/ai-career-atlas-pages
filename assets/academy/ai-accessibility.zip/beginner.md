## beginner — Access needs and task barriers

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Access needs and task barriers
Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls.
Mental model: A ramp helps only when it connects to the entrance people need.
Boundary: Automated accessibility checks do not cover every user experience.
Worked example: A generated summary has readable structure and source links; the original content remains available to assistive technology.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Streaming output traps focus
The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Three tasks lose focus during updates, preventing keyboard users from completing them. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Keep focus under user control and announce updates without replacing the active interaction context.
Recall: Test streaming, cancellation and correction with keyboard and relevant assistive technology. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Access needs and task barriers: Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Accessibility starts with a specific barrier to completing a task. AI should not remove existing accessible ways to get help.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine an assistant that streams an answer, moves keyboard focus automatically and offers an unlabeled icon to stop.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated redesign and a plan to test with affected users.

3. Try step 2
List potential barriers for keyboard and screen-reader use; label these as hypotheses until tested.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated redesign and a plan to test with affected users.

4. Try step 3
Sketch stable focus behavior, a clearly labeled Stop button and an alternative route to the information.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated redesign and a plan to test with affected users.

5. Explain and check your result
The redesign keeps a usable non-AI route; a desk review is not reported as participant research. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An annotated redesign and a plan to test with affected users. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Apply this toy-case rule manually: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three tasks lose focus during updates, preventing keyboard users from completing them. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI accessibility & assistive interaction.
Imagine an assistant that streams an answer, moves keyboard focus automatically and offers an unlabeled icon to stop.
List potential barriers for keyboard and screen-reader use; label these as hypotheses until tested.
Sketch stable focus behavior, a clearly labeled Stop button and an alternative route to the information.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An annotated redesign and a plan to test with affected users. Include beginner-worksheet.md and your completed Accessibility findings report and interaction specification.
Check: The redesign keeps a usable non-AI route; a desk review is not reported as participant research.

### Interview
Explain your beginner solution for AI accessibility & assistive interaction. Use this scenario: The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker.
Review: Start with the task and permitted scope. Explain access needs and task barriers: Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls. Show the input and observed output, then address Keep focus under user control and announce updates without replacing the active interaction context. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An annotated redesign and a plan to test with affected users. Include beginner-worksheet.md and your completed Accessibility findings report and interaction specification.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

