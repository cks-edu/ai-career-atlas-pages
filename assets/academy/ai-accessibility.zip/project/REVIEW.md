# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Accessible prototype and interaction spec.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
