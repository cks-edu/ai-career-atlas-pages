# Accessible AI assistance prototype

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Design an AI interaction with accessible control, feedback and recovery.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.

## Limitations and next iteration
Test across a second browser/assistive-technology combination and record differences.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
