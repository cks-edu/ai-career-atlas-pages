# Accessible AI assistance prototype

Career: AI accessibility & assistive interaction
Reviewed: 2026-10-22

Design an AI interaction with accessible control, feedback and recovery.

## Prerequisites
Accessible design and user research with disabled participants; engineering variants need frontend skills.

## Included starter versus your implementation
Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Create Penpot boards and an HTML prototype with labeled controls, logical headings, keyboard navigation and visible focus. Keep status updates understandable without color alone.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Run keyboard, zoom and screen-reader checks using the WAI guidance. Where possible, test with consenting users with relevant access needs and record accommodations.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Accessible prototype and interaction spec — artifact-1.md
2. Manual accessibility test report — artifact-2.md
3. Remediation log and user-research plan — artifact-3.md

## Troubleshooting
- CSV appears in one column: select comma as the separator during import.
- Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
- No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.

## Extension
Test across a second browser/assistive-technology combination and record differences.

## Primary learning resources
- Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/ — Open source · hosted account or self-hosting; Connect prototype boards and test interaction flows; Figma is an alternative.
- W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/ — Public guidance; Manual accessibility checks; preliminary checks are not full conformance assessment.
- LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/ — Open source · no account needed; Edit reports, workshop decks and export PDF deliverables.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
