## intermediate — Accessible error and status communication

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Accessible design and user research with disabled participants; engineering variants need frontend skills.

### Accessible error and status communication
Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction.
Mental model: A station announces platform changes as well as displaying them.
Boundary: Too many live announcements can overwhelm screen-reader users.
Worked example: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Accessible AI assistance prototype
Design an AI interaction with accessible control, feedback and recovery. Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.
Recall: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. Identify one observation that would contradict your claim.

### Terms
Accessible error and status communication: Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design an AI interaction with accessible control, feedback and recovery. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

2. Prepare the project inputs
Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create Penpot boards and an HTML prototype with labeled controls, logical headings, keyboard navigation and visible focus. Keep status updates understandable without color alone.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design an AI interaction with accessible control, feedback and recovery.
Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.
Create Penpot boards and an HTML prototype with labeled controls, logical headings, keyboard navigation and visible focus. Keep status updates understandable without color alone.
Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.
Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.
Deliverables: Accessible prototype and interaction spec; Manual accessibility test report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI accessibility & assistive interaction. Use this scenario: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.
Review: Start with the task and permitted scope. Explain accessible error and status communication: Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction. Show the input and observed output, then address Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Accessible prototype and interaction spec; Manual accessibility test report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

