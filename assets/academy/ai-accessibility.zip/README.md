# AI accessibility & assistive interaction

AI Engineering · Beginner → Intermediate → Advanced

Start with Access needs and task barriers. Accessibility starts with a specific barrier to completing a task. AI should not remove existing accessible ways to get help. Then try Review a changing answer screen. The three levels build toward Accessible AI assistance prototype. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Access needs and task barriers

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Access needs and task barriers
Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls.
Mental model: A ramp helps only when it connects to the entrance people need.
Boundary: Automated accessibility checks do not cover every user experience.
Worked example: A generated summary has readable structure and source links; the original content remains available to assistive technology.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Streaming output traps focus
The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Three tasks lose focus during updates, preventing keyboard users from completing them. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Keep focus under user control and announce updates without replacing the active interaction context.
Recall: Test streaming, cancellation and correction with keyboard and relevant assistive technology. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Access needs and task barriers: Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Accessibility starts with a specific barrier to completing a task. AI should not remove existing accessible ways to get help.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine an assistant that streams an answer, moves keyboard focus automatically and offers an unlabeled icon to stop.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated redesign and a plan to test with affected users.

3. Try step 2
List potential barriers for keyboard and screen-reader use; label these as hypotheses until tested.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated redesign and a plan to test with affected users.

4. Try step 3
Sketch stable focus behavior, a clearly labeled Stop button and an alternative route to the information.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An annotated redesign and a plan to test with affected users.

5. Explain and check your result
The redesign keeps a usable non-AI route; a desk review is not reported as participant research. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An annotated redesign and a plan to test with affected users. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Apply this toy-case rule manually: Review when focus_losses >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three tasks lose focus during updates, preventing keyboard users from completing them. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI accessibility & assistive interaction.
Imagine an assistant that streams an answer, moves keyboard focus automatically and offers an unlabeled icon to stop.
List potential barriers for keyboard and screen-reader use; label these as hypotheses until tested.
Sketch stable focus behavior, a clearly labeled Stop button and an alternative route to the information.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An annotated redesign and a plan to test with affected users. Include beginner-worksheet.md and your completed Accessibility findings report and interaction specification.
Check: The redesign keeps a usable non-AI route; a desk review is not reported as participant research.

### Interview
Explain your beginner solution for AI accessibility & assistive interaction. Use this scenario: The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker.
Review: Start with the task and permitted scope. Explain access needs and task barriers: Begin with the person's task and access needs, not an assumption that AI is inherently assistive. Preserve a usable non-AI path and predictable controls. Show the input and observed output, then address Keep focus under user control and announce updates without replacing the active interaction context. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An annotated redesign and a plan to test with affected users. Include beginner-worksheet.md and your completed Accessibility findings report and interaction specification.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Accessible error and status communication

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Accessible design and user research with disabled participants; engineering variants need frontend skills.

### Accessible error and status communication
Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction.
Mental model: A station announces platform changes as well as displaying them.
Boundary: Too many live announcements can overwhelm screen-reader users.
Worked example: After generation fails, a readable status explains recovery and keyboard focus stays at a useful control rather than jumping to the page top.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Accessible AI assistance prototype
Design an AI interaction with accessible control, feedback and recovery. Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.
Recall: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. Identify one observation that would contradict your claim.

### Terms
Accessible error and status communication: Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design an AI interaction with accessible control, feedback and recovery. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

2. Prepare the project inputs
Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create Penpot boards and an HTML prototype with labeled controls, logical headings, keyboard navigation and visible focus. Keep status updates understandable without color alone.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design an AI interaction with accessible control, feedback and recovery.
Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.
Create Penpot boards and an HTML prototype with labeled controls, logical headings, keyboard navigation and visible focus. Keep status updates understandable without color alone.
Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.
Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.
Deliverables: Accessible prototype and interaction spec; Manual accessibility test report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI accessibility & assistive interaction. Use this scenario: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.
Review: Start with the task and permitted scope. Explain accessible error and status communication: Make loading, uncertainty and errors perceivable without relying on color or visual position. Preserve focus and allow keyboard correction. Show the input and observed output, then address Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Accessible prototype and interaction spec; Manual accessibility test report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Assistive workflow evaluation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Assistive workflow evaluation
Test with relevant assistive technologies and, when possible, consenting users. Distinguish a scripted audit from an observed user study.
Mental model: A route inspection and a journey with a traveler reveal different barriers.
Boundary: One device or impairment experience cannot represent all accessibility needs.
Worked example: Complete the task using keyboard and a screen reader, record obstacles, then plan a participant study without inventing participant results.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Accessible AI assistance prototype
Design an AI interaction with accessible control, feedback and recovery. Run keyboard, zoom and screen-reader checks using the WAI guidance. Where possible, test with consenting users with relevant access needs and record accommodations.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.
Recall: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. Identify one observation that would contradict your claim.

### Terms
Assistive workflow evaluation: Test with relevant assistive technologies and, when possible, consenting users. Distinguish a scripted audit from an observed user study.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design an AI interaction with accessible control, feedback and recovery. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. An editable SVG wireframe is included for import into Penpot.

2. Prepare the project inputs
Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create Penpot boards and an HTML prototype with labeled controls, logical headings, keyboard navigation and visible focus. Keep status updates understandable without color alone.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run keyboard, zoom and screen-reader checks using the WAI guidance. Where possible, test with consenting users with relevant access needs and record accommodations.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design an AI interaction with accessible control, feedback and recovery.
Choose a document-summary workflow and define tasks requiring source review, correction and cancellation. Plan accessible participation and consent for any user sessions.
Create Penpot boards and an HTML prototype with labeled controls, logical headings, keyboard navigation and visible focus. Keep status updates understandable without color alone.
Implement a stop control and preserve the user’s draft after errors. Specify live-region behavior so streaming output does not overwhelm assistive technology.
Run keyboard, zoom and screen-reader checks using the WAI guidance. Where possible, test with consenting users with relevant access needs and record accommodations.
Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.
Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience.
Test across a second browser/assistive-technology combination and record differences.
Deliverables: Accessible prototype and interaction spec; Manual accessibility test report; Remediation log and user-research plan. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. A reviewer must reproduce one result and identify which capabilities you implemented. Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.

### Interview
Explain your advanced solution for AI accessibility & assistive interaction. Use this scenario: Disable pointer input, zoom the page and trigger a long generated response. Verify focus, cancellation and recovery without losing context.
Review: Start with the task and permitted scope. Explain assistive workflow evaluation: Test with relevant assistive technologies and, when possible, consenting users. Distinguish a scripted audit from an observed user study. Show the input and observed output, then address Report task barriers and remediations with reproducible steps. Automated checks and solo simulation do not establish full WCAG conformance or lived user experience. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Accessible prototype and interaction spec; Manual accessibility test report; Remediation log and user-research plan. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Penpot — Open source · hosted account or self-hosting
Connect prototype boards and test interaction flows; Figma is an alternative.
Alternative: Figma (commercial hosted service with plan-specific access); paper prototypes are sufficient for the first exercise.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

W3C WAI checks — Public guidance
Manual accessibility checks; preliminary checks are not full conformance assessment.
Alternative: Use manual keyboard and assistive-technology checks alongside axe-core (open source); automated tests do not replace WAI guidance or user testing.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Writer / Impress — Open source · no account needed
Edit reports, workshop decks and export PDF deliverables.
Alternative: Microsoft Word/PowerPoint (commercial) or Google Docs/Slides (hosted); retain editable and accessible exports.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/
W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/
LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/
W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/
Figma learning resources: https://help.figma.com/
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
