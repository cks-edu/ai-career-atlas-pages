# SAMPLE — Accessibility findings report and interaction specification
Role: AI accessibility & assistive interaction
Case: Streaming output traps focus
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The assistive-interaction pilot treats any task with an unrecoverable keyboard-focus loss as a blocker.

## Evidence table
| Record | focus_losses (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three tasks lose focus during updates, preventing keyboard users from completing them.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Keep focus under user control and announce updates without replacing the active interaction context.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai accessibility & assistive interaction.
Before release: Test streaming, cancellation and correction with keyboard and relevant assistive technology.

## Design choice and trade-off
Design status updates and recovery with affected users; combine technical and usability checks.
Automated accessibility checks find only part of the problem; real interaction can expose different barriers.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Accessible AI reading assistant: Updates do not overwhelm focus or hide source information.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
