# Snowflake Data Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Warehouse, storage and stage

Snowflake separates compute warehouses from stored data; a stage identifies files to load. Warehouse size and running time affect cost independently of table row count.
Mental model: The warehouse is the work crew; the stage is the receiving dock; tables are the archive.
Case: A CSV with order IDs and amounts is staged before loading into a declared table.
Task: Reconcile the local fixture first. In an authorized Snowflake account follow the official loading tutorial, choose a small permitted warehouse, create a lab table/stage and inspect loaded rows.
Acceptance: Counts and values match the declared file; actual account usage is recorded.
Troubleshooting: A missing warehouse or wrong role can block a query even when the table exists.
Deliverable: load worksheet and warehouse/role notes

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
COPY validation and replay

Loading a file needs error inspection and a deliberate replay policy. File-load history and business-key uniqueness are different concerns.
Mental model: A receiving log tracks parcels while business keys identify what is inside them.
Case: Replaying a corrected file must not silently double order totals.
Task: Create clean and malformed CSV fixtures, validate the load using the official COPY options, inspect rejected rows and define a MERGE/upsert policy for corrected orders. Compare count and sum after replay.
Acceptance: Bad rows are explained and the intended final total remains correct.
Troubleshooting: Do not equate successful COPY status with correct business deduplication.
Deliverable: load/replay SQL and reconciliation evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Roles and cost controls

Separate loading, transformation and read access, and monitor compute usage with clear ownership. Automatic suspension helps but does not replace workload review.
Mental model: Different workers need different keys and a meter for the equipment they run.
Case: A reporting role should not change ingestion tables or warehouse administration.
Task: Write a role matrix, test allowed/denied operations in a lab account and define auto-suspend and usage-review settings from current docs. Document restoration options for the selected edition/retention.
Acceptance: Least-privilege evidence and a dated cost/retention plan.
Troubleshooting: Feature availability and retention vary; verify account configuration before promising recovery.
Deliverable: Snowflake operations and access review

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
