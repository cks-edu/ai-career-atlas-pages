# Snowflake Data Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Apply keys and constraints in Snowflake Data Engineer: Use the concept to complete this role exercise: Load synthetic orders with a declared schema

Warehouse, storage and stage: Snowflake separates compute warehouses from stored data; a stage identifies files to load. Warehouse size and running time affect cost independently of table row count.

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: A CSV with order IDs and amounts is staged before loading into a declared table. The practical workshop develops this into: Reconcile the local fixture first. In an authorized Snowflake account follow the official loading tutorial, choose a small permitted warehouse, create a lab table/stage and inspect loaded rows.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: The warehouse is the work crew; the stage is the receiving dock; tables are the archive.

Snowflake separates compute warehouses from stored data; a stage identifies files to load. Warehouse size and running time affect cost independently of table row count.

Worked example: A CSV with order IDs and amounts is staged before loading into a declared table.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Snowflake warehouses, stages and SQL (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Snowflake Data Engineer: A CSV with order IDs and amounts is staged before loading into a declared table.

Predict the worked case

Read this case without running a tool: A CSV with order IDs and amounts is staged before loading into a declared table. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: A CSV with order IDs and amounts is staged before loading into a declared table. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A CSV with order IDs and amounts is staged before loading into a declared table. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: A CSV with order IDs and amounts is staged before loading into a declared table. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Snowflake Data Engineer role interview. Explain keys and constraints using this case: A CSV with order IDs and amounts is staged before loading into a declared table. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: A CSV with order IDs and amounts is staged before loading into a declared table. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: A CSV with order IDs and amounts is staged before loading into a declared table. State the evidence, one alternative and where the mental model stops.

Quiz: After the Warehouse, storage and stage rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

Snowflake: internal stages: https://docs.snowflake.com/en/user-guide/data-load-local-file-system-create-stage

Snowflake tutorials: https://docs.snowflake.com/en/learn-tutorials

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Warehouse, storage and stage

Snowflake separates compute warehouses from stored data; a stage identifies files to load. Warehouse size and running time affect cost independently of table row count. In this role, work through: A CSV with order IDs and amounts is staged before loading into a declared table. The practical workshop develops this into: Reconcile the local fixture first. In an authorized Snowflake account follow the official loading tutorial, choose a small permitted warehouse, create a lab table/stage and inspect loaded rows.

Mental model: The warehouse is the work crew; the stage is the receiving dock; tables are the archive.

Boundary: A missing warehouse or wrong role can block a query even when the table exists.

Worked example: A CSV with order IDs and amounts is staged before loading into a declared table.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Snowflake warehouses, stages and SQL (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Snowflake Data Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Reconcile the local fixture first. In an authorized Snowflake account follow the official loading tutorial, choose a small permitted warehouse, create a lab table/stage and inspect loaded rows.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A CSV with order IDs and amounts is staged before loading into a declared table. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Reconcile the local fixture first. In an authorized Snowflake account follow the official loading tutorial, choose a small permitted warehouse, create a lab table/stage and inspect loaded rows.

Expected: Counts and values match the declared file; actual account usage is recorded.

Role workshop · debug and verify

A missing warehouse or wrong role can block a query even when the table exists. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save load worksheet and warehouse/role notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Counts and values match the declared file; actual account usage is recorded.

Expected: Counts and values match the declared file; actual account usage is recorded.

Troubleshoot: The role exercise differs from the prediction: A missing warehouse or wrong role can block a query even when the table exists.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: load worksheet and warehouse/role notes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with warehouse, storage and stage. Use the glossary below, then write your prediction for: A CSV with order IDs and amounts is staged before loading into a declared table. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Snowflake Data Engineer role interview. Explain warehouse, storage and stage using this case: A CSV with order IDs and amounts is staged before loading into a declared table. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate warehouse, storage and stage to a system or workflow you know. Explain warehouse, storage and stage using this case: A CSV with order IDs and amounts is staged before loading into a declared table. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A missing warehouse or wrong role can block a query even when the table exists.

Interview: Explain warehouse, storage and stage using this case: A CSV with order IDs and amounts is staged before loading into a declared table. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A CSV with order IDs and amounts is staged before loading into a declared table.

Counts and values match the declared file; actual account usage is recorded.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Counts and values match the declared file; actual account usage is recorded. — Snowflake separates compute warehouses from stored data; a stage identifies files to load. Warehouse size and running time affect cost independently of table row count. Counts and values match the declared file; actual account usage is recorded.

Sources:

Snowflake: internal stages: https://docs.snowflake.com/en/user-guide/data-load-local-file-system-create-stage

Snowflake tutorials: https://docs.snowflake.com/en/learn-tutorials

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Apply idempotent processing in Snowflake Data Engineer: Use the concept to complete this role exercise: Design staged ingestion and rejected-row reconciliation

COPY validation and replay: Loading a file needs error inspection and a deliberate replay policy. File-load history and business-key uniqueness are different concerns.

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: Replaying a corrected file must not silently double order totals. The practical workshop develops this into: Create clean and malformed CSV fixtures, validate the load using the official COPY options, inspect rejected rows and define a MERGE/upsert policy for corrected orders. Compare count and sum after replay.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: A receiving log tracks parcels while business keys identify what is inside them.

Loading a file needs error inspection and a deliberate replay policy. File-load history and business-key uniqueness are different concerns.

Worked example: Replaying a corrected file must not silently double order totals.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Snowflake warehouses, stages and SQL (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Snowflake Data Engineer: Replaying a corrected file must not silently double order totals.

Predict the worked case

Read this case without running a tool: Replaying a corrected file must not silently double order totals. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: Replaying a corrected file must not silently double order totals. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Replaying a corrected file must not silently double order totals. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: Replaying a corrected file must not silently double order totals. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Snowflake Data Engineer role interview. Explain idempotent processing using this case: Replaying a corrected file must not silently double order totals. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: Replaying a corrected file must not silently double order totals. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: Replaying a corrected file must not silently double order totals. State the evidence, one alternative and where the mental model stops.

Quiz: After the COPY validation and replay rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

Snowflake: internal stages: https://docs.snowflake.com/en/user-guide/data-load-local-file-system-create-stage

Snowflake tutorials: https://docs.snowflake.com/en/learn-tutorials

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### COPY validation and replay

Loading a file needs error inspection and a deliberate replay policy. File-load history and business-key uniqueness are different concerns. In this role, work through: Replaying a corrected file must not silently double order totals. The practical workshop develops this into: Create clean and malformed CSV fixtures, validate the load using the official COPY options, inspect rejected rows and define a MERGE/upsert policy for corrected orders. Compare count and sum after replay.

Mental model: A receiving log tracks parcels while business keys identify what is inside them.

Boundary: Do not equate successful COPY status with correct business deduplication.

Worked example: Replaying a corrected file must not silently double order totals.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Snowflake warehouses, stages and SQL (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Snowflake Data Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create clean and malformed CSV fixtures, validate the load using the official COPY options, inspect rejected rows and define a MERGE/upsert policy for corrected orders. Compare count and sum after replay.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Replaying a corrected file must not silently double order totals. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create clean and malformed CSV fixtures, validate the load using the official COPY options, inspect rejected rows and define a MERGE/upsert policy for corrected orders. Compare count and sum after replay.

Expected: Bad rows are explained and the intended final total remains correct.

Role workshop · debug and verify

Do not equate successful COPY status with correct business deduplication. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save load/replay SQL and reconciliation evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Bad rows are explained and the intended final total remains correct.

Expected: Bad rows are explained and the intended final total remains correct.

Troubleshoot: The role exercise differs from the prediction: Do not equate successful COPY status with correct business deduplication.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: load/replay SQL and reconciliation evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with copy validation and replay. Use the glossary below, then write your prediction for: Replaying a corrected file must not silently double order totals. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Snowflake Data Engineer role interview. Explain copy validation and replay using this case: Replaying a corrected file must not silently double order totals. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate copy validation and replay to a system or workflow you know. Explain copy validation and replay using this case: Replaying a corrected file must not silently double order totals. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not equate successful COPY status with correct business deduplication.

Interview: Explain copy validation and replay using this case: Replaying a corrected file must not silently double order totals. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Replaying a corrected file must not silently double order totals.

Ignore the failing case and keep only the successful screenshot.

Bad rows are explained and the intended final total remains correct.

Treat any successful command as proof that all business and access rules passed.

Reference: Bad rows are explained and the intended final total remains correct. — Loading a file needs error inspection and a deliberate replay policy. File-load history and business-key uniqueness are different concerns. Bad rows are explained and the intended final total remains correct.

Sources:

Snowflake: internal stages: https://docs.snowflake.com/en/user-guide/data-load-local-file-system-create-stage

Snowflake tutorials: https://docs.snowflake.com/en/learn-tutorials

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Apply transaction and recovery in Snowflake Data Engineer: Use the concept to complete this role exercise: Specify role separation, warehouse cost monitoring and restore/replay checks

Roles and cost controls: Separate loading, transformation and read access, and monitor compute usage with clear ownership. Automatic suspension helps but does not replace workload review.

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: A reporting role should not change ingestion tables or warehouse administration. The practical workshop develops this into: Write a role matrix, test allowed/denied operations in a lab account and define auto-suspend and usage-review settings from current docs. Document restoration options for the selected edition/retention.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: Different workers need different keys and a meter for the equipment they run.

Separate loading, transformation and read access, and monitor compute usage with clear ownership. Automatic suspension helps but does not replace workload review.

Worked example: A reporting role should not change ingestion tables or warehouse administration.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Snowflake warehouses, stages and SQL (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Snowflake Data Engineer: A reporting role should not change ingestion tables or warehouse administration.

Predict the worked case

Read this case without running a tool: A reporting role should not change ingestion tables or warehouse administration. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: A reporting role should not change ingestion tables or warehouse administration. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A reporting role should not change ingestion tables or warehouse administration. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: A reporting role should not change ingestion tables or warehouse administration. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Snowflake Data Engineer role interview. Explain transaction and recovery using this case: A reporting role should not change ingestion tables or warehouse administration. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: A reporting role should not change ingestion tables or warehouse administration. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: A reporting role should not change ingestion tables or warehouse administration. State the evidence, one alternative and where the mental model stops.

Quiz: After the Roles and cost controls rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

Snowflake: internal stages: https://docs.snowflake.com/en/user-guide/data-load-local-file-system-create-stage

Snowflake tutorials: https://docs.snowflake.com/en/learn-tutorials

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Roles and cost controls

Separate loading, transformation and read access, and monitor compute usage with clear ownership. Automatic suspension helps but does not replace workload review. In this role, work through: A reporting role should not change ingestion tables or warehouse administration. The practical workshop develops this into: Write a role matrix, test allowed/denied operations in a lab account and define auto-suspend and usage-review settings from current docs. Document restoration options for the selected edition/retention.

Mental model: Different workers need different keys and a meter for the equipment they run.

Boundary: Feature availability and retention vary; verify account configuration before promising recovery.

Worked example: A reporting role should not change ingestion tables or warehouse administration.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Snowflake warehouses, stages and SQL (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Snowflake Data Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a role matrix, test allowed/denied operations in a lab account and define auto-suspend and usage-review settings from current docs. Document restoration options for the selected edition/retention.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A reporting role should not change ingestion tables or warehouse administration. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a role matrix, test allowed/denied operations in a lab account and define auto-suspend and usage-review settings from current docs. Document restoration options for the selected edition/retention.

Expected: Least-privilege evidence and a dated cost/retention plan.

Role workshop · debug and verify

Feature availability and retention vary; verify account configuration before promising recovery. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Snowflake operations and access review. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Least-privilege evidence and a dated cost/retention plan.

Expected: Least-privilege evidence and a dated cost/retention plan.

Troubleshoot: The role exercise differs from the prediction: Feature availability and retention vary; verify account configuration before promising recovery.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: Snowflake operations and access review; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with roles and cost controls. Use the glossary below, then write your prediction for: A reporting role should not change ingestion tables or warehouse administration. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Snowflake Data Engineer role interview. Explain roles and cost controls using this case: A reporting role should not change ingestion tables or warehouse administration. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate roles and cost controls to a system or workflow you know. Explain roles and cost controls using this case: A reporting role should not change ingestion tables or warehouse administration. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Feature availability and retention vary; verify account configuration before promising recovery.

Interview: Explain roles and cost controls using this case: A reporting role should not change ingestion tables or warehouse administration. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A reporting role should not change ingestion tables or warehouse administration.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Least-privilege evidence and a dated cost/retention plan.

Reference: Least-privilege evidence and a dated cost/retention plan. — Separate loading, transformation and read access, and monitor compute usage with clear ownership. Automatic suspension helps but does not replace workload review. Least-privilege evidence and a dated cost/retention plan.

Sources:

Snowflake: internal stages: https://docs.snowflake.com/en/user-guide/data-load-local-file-system-create-stage

Snowflake tutorials: https://docs.snowflake.com/en/learn-tutorials

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
