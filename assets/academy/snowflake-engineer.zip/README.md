# Snowflake Data Engineer

Software Engineering

Start with warehouse, storage and stage. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward Snowflake operations and access review.

## beginner

Reconcile the local fixture first. In an authorized Snowflake account follow the official loading tutorial, choose a small permitted warehouse, create a lab table/stage and inspect loaded rows.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Warehouse, storage and stage
Snowflake separates compute warehouses from stored data; a stage identifies files to load. Warehouse size and running time affect cost independently of table row count.
Mental model: The warehouse is the work crew; the stage is the receiving dock; tables are the archive.
Limit: A missing warehouse or wrong role can block a query even when the table exists.
Example: A CSV with order IDs and amounts is staged before loading into a declared table.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A missing warehouse or wrong role can block a query even when the table exists.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A CSV with order IDs and amounts is staged before loading into a declared table. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Reconcile the local fixture first. In an authorized Snowflake account follow the official loading tutorial, choose a small permitted warehouse, create a lab table/stage and inspect loaded rows.
Expected: Counts and values match the declared file; actual account usage is recorded.

6. Role workshop · debug and verify
A missing warehouse or wrong role can block a query even when the table exists. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save load worksheet and warehouse/role notes. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Counts and values match the declared file; actual account usage is recorded.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Warehouse, storage and stage: A missing warehouse or wrong role can block a query even when the table exists.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: load worksheet and warehouse/role notes
Counts and values match the declared file; actual account usage is recorded.

Interview: Work through this Snowflake Data Engineer case: A CSV with order IDs and amounts is staged before loading into a declared table. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Snowflake separates compute warehouses from stored data; a stage identifies files to load. Warehouse size and running time affect cost independently of table row count. Expected evidence: Counts and values match the declared file; actual account usage is recorded. Diagnosis: A missing warehouse or wrong role can block a query even when the table exists. State the limits of the mental model: The warehouse is the work crew; the stage is the receiving dock; tables are the archive.

Resume: Built load worksheet and warehouse/role notes using Snowflake warehouses, stages and SQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create clean and malformed CSV fixtures, validate the load using the official COPY options, inspect rejected rows and define a MERGE/upsert policy for corrected orders. Compare count and sum after replay.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### COPY validation and replay
Loading a file needs error inspection and a deliberate replay policy. File-load history and business-key uniqueness are different concerns.
Mental model: A receiving log tracks parcels while business keys identify what is inside them.
Limit: Do not equate successful COPY status with correct business deduplication.
Example: Replaying a corrected file must not silently double order totals.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not equate successful COPY status with correct business deduplication.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Replaying a corrected file must not silently double order totals. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create clean and malformed CSV fixtures, validate the load using the official COPY options, inspect rejected rows and define a MERGE/upsert policy for corrected orders. Compare count and sum after replay.
Expected: Bad rows are explained and the intended final total remains correct.

6. Role workshop · debug and verify
Do not equate successful COPY status with correct business deduplication. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save load/replay SQL and reconciliation evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Bad rows are explained and the intended final total remains correct.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
COPY validation and replay: Do not equate successful COPY status with correct business deduplication.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: load/replay SQL and reconciliation evidence
Bad rows are explained and the intended final total remains correct.

Interview: Work through this Snowflake Data Engineer case: Replaying a corrected file must not silently double order totals. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Loading a file needs error inspection and a deliberate replay policy. File-load history and business-key uniqueness are different concerns. Expected evidence: Bad rows are explained and the intended final total remains correct. Diagnosis: Do not equate successful COPY status with correct business deduplication. State the limits of the mental model: A receiving log tracks parcels while business keys identify what is inside them.

Resume: Built load/replay SQL and reconciliation evidence using Snowflake warehouses, stages and SQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write a role matrix, test allowed/denied operations in a lab account and define auto-suspend and usage-review settings from current docs. Document restoration options for the selected edition/retention.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Roles and cost controls
Separate loading, transformation and read access, and monitor compute usage with clear ownership. Automatic suspension helps but does not replace workload review.
Mental model: Different workers need different keys and a meter for the equipment they run.
Limit: Feature availability and retention vary; verify account configuration before promising recovery.
Example: A reporting role should not change ingestion tables or warehouse administration.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Feature availability and retention vary; verify account configuration before promising recovery.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A reporting role should not change ingestion tables or warehouse administration. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a role matrix, test allowed/denied operations in a lab account and define auto-suspend and usage-review settings from current docs. Document restoration options for the selected edition/retention.
Expected: Least-privilege evidence and a dated cost/retention plan.

6. Role workshop · debug and verify
Feature availability and retention vary; verify account configuration before promising recovery. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Snowflake operations and access review. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Least-privilege evidence and a dated cost/retention plan.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Roles and cost controls: Feature availability and retention vary; verify account configuration before promising recovery.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Snowflake operations and access review
Least-privilege evidence and a dated cost/retention plan.

Interview: Work through this Snowflake Data Engineer case: A reporting role should not change ingestion tables or warehouse administration. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Separate loading, transformation and read access, and monitor compute usage with clear ownership. Automatic suspension helps but does not replace workload review. Expected evidence: Least-privilege evidence and a dated cost/retention plan. Diagnosis: Feature availability and retention vary; verify account configuration before promising recovery. State the limits of the mental model: Different workers need different keys and a meter for the equipment they run.

Resume: Built Snowflake operations and access review using Snowflake warehouses, stages and SQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Snowflake tutorials: https://docs.snowflake.com/en/learn-tutorials
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
Snowflake: internal stages: https://docs.snowflake.com/en/user-guide/data-load-local-file-system-create-stage
