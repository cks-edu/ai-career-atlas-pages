# AWS Cloud Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Desired state: A controller compares the current system with a declared target and works to reconcile the difference.

Apply desired state in AWS Cloud Engineer: Use the concept to complete this role exercise: Map local compute, storage and identity to AWS services

AWS responsibility mapping: Choose compute, storage, identity and telemetry services by workload needs and operational responsibility. A managed service reduces some administration but does not configure application permissions for you.

### Desired state

A controller compares the current system with a declared target and works to reconcile the difference. In this role, work through: A web service uses compute, a private data store, an execution identity and logs as separate concerns. The practical workshop develops this into: Map the local task service to EC2 or a managed container option, S3/RDS where appropriate and CloudWatch. Draw request and credential flows; list why each service is needed before creating anything.

Mental model: A thermostat compares actual temperature with the set point.

Boundary: It cannot fix every cause: a missing image or insufficient resources still needs action.

Role application: Renting an apartment changes who repairs the roof, not who locks your door.

Choose compute, storage, identity and telemetry services by workload needs and operational responsibility. A managed service reduces some administration but does not configure application permissions for you.

Worked example: A web service uses compute, a private data store, an execution identity and logs as separate concerns.

Shared foundation example: One replica means the controller tries to keep one Pod running.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: AWS IAM, VPC, EC2, S3, RDS and CloudWatch (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AWS Cloud Engineer: A web service uses compute, a private data store, an execution identity and logs as separate concerns.

Predict the worked case

Read this case without running a tool: A web service uses compute, a private data store, an execution identity and logs as separate concerns. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in desired state.

Connect the concept to the role

Apply this rule: A controller compares the current system with a declared target and works to reconcile the difference. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: It cannot fix every cause: a missing image or insufficient resources still needs action.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies desired state to this case: A web service uses compute, a private data store, an execution identity and logs as separate concerns. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A web service uses compute, a private data store, an execution identity and logs as separate concerns. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Desired state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with desired state. Use the glossary below, then write your prediction for: A web service uses compute, a private data store, an execution identity and logs as separate concerns. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AWS Cloud Engineer role interview. Explain desired state using this case: A web service uses compute, a private data store, an execution identity and logs as separate concerns. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate desired state to a system or workflow you know. Explain desired state using this case: A web service uses compute, a private data store, an execution identity and logs as separate concerns. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens when a Pod is deleted but its Deployment remains?

Interview: Explain desired state using this case: A web service uses compute, a private data store, an execution identity and logs as separate concerns. State the evidence, one alternative and where the mental model stops.

Quiz: After the AWS responsibility mapping rehearsal, check this foundation: A controller is told to run two replicas, but only one is ready. What does the declared target mean?

The controller attempts reconciliation; it is not a guarantee that both are healthy now.

Two healthy replicas must already exist.

The current replica count becomes the new desired target automatically.

Reference: The controller attempts reconciliation; it is not a guarantee that both are healthy now. — Desired and observed state differ during convergence or failure. Inspect readiness, events and constraints.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### AWS responsibility mapping

Choose compute, storage, identity and telemetry services by workload needs and operational responsibility. A managed service reduces some administration but does not configure application permissions for you. In this role, work through: A web service uses compute, a private data store, an execution identity and logs as separate concerns. The practical workshop develops this into: Map the local task service to EC2 or a managed container option, S3/RDS where appropriate and CloudWatch. Draw request and credential flows; list why each service is needed before creating anything.

Mental model: Renting an apartment changes who repairs the roof, not who locks your door.

Boundary: Do not put a database on a public path merely because the web entry point is public.

Worked example: A web service uses compute, a private data store, an execution identity and logs as separate concerns.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: AWS IAM, VPC, EC2, S3, RDS and CloudWatch (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required AWS Cloud Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Map the local task service to EC2 or a managed container option, S3/RDS where appropriate and CloudWatch. Draw request and credential flows; list why each service is needed before creating anything.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

A web service uses compute, a private data store, an execution identity and logs as separate concerns. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Map the local task service to EC2 or a managed container option, S3/RDS where appropriate and CloudWatch. Draw request and credential flows; list why each service is needed before creating anything.

Expected: A service map with owners, data classification and alternatives.

Role workshop · debug and verify

Do not put a database on a public path merely because the web entry point is public. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save AWS architecture diagram and responsibility table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A service map with owners, data classification and alternatives.

Expected: A service map with owners, data classification and alternatives.

Troubleshoot: The role exercise differs from the prediction: Do not put a database on a public path merely because the web entry point is public.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-beginner-2.md: AWS architecture diagram and responsibility table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with aws responsibility mapping. Use the glossary below, then write your prediction for: A web service uses compute, a private data store, an execution identity and logs as separate concerns. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AWS Cloud Engineer role interview. Explain aws responsibility mapping using this case: A web service uses compute, a private data store, an execution identity and logs as separate concerns. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate aws responsibility mapping to a system or workflow you know. Explain aws responsibility mapping using this case: A web service uses compute, a private data store, an execution identity and logs as separate concerns. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not put a database on a public path merely because the web entry point is public.

Interview: Explain aws responsibility mapping using this case: A web service uses compute, a private data store, an execution identity and logs as separate concerns. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A web service uses compute, a private data store, an execution identity and logs as separate concerns.

A service map with owners, data classification and alternatives.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A service map with owners, data classification and alternatives. — Choose compute, storage, identity and telemetry services by workload needs and operational responsibility. A managed service reduces some administration but does not configure application permissions for you. A service map with owners, data classification and alternatives.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Readiness and routing: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.

Apply readiness and routing in AWS Cloud Engineer: Use the concept to complete this role exercise: Draw private database and public ingress boundaries with least privilege

Least-privilege access design: IAM permissions, network reachability and service configuration are separate gates. Test denied actions as well as allowed actions using an authorized sandbox identity.

### Readiness and routing

Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. In this role, work through: An application that only reads one bucket prefix should not receive account-wide storage administration. The practical workshop develops this into: Write a narrowly scoped policy proposal with resource and action justifications. Validate it using AWS's policy tools in a sandbox if available; otherwise mark validation pending and review positive/negative cases manually.

Mental model: A shop can have lights on but still be closed to customers.

Boundary: A health endpoint can be too shallow; it must reflect the service contract.

Role application: A route to the door and a key for the lock are separate requirements.

IAM permissions, network reachability and service configuration are separate gates. Test denied actions as well as allowed actions using an authorized sandbox identity.

Worked example: An application that only reads one bucket prefix should not receive account-wide storage administration.

Shared foundation example: This container listens on 8080; the Service accepts 80 and forwards to 8080.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: AWS IAM, VPC, EC2, S3, RDS and CloudWatch (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AWS Cloud Engineer: An application that only reads one bucket prefix should not receive account-wide storage administration.

Predict the worked case

Read this case without running a tool: An application that only reads one bucket prefix should not receive account-wide storage administration. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in readiness and routing.

Connect the concept to the role

Apply this rule: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A health endpoint can be too shallow; it must reflect the service contract.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies readiness and routing to this case: An application that only reads one bucket prefix should not receive account-wide storage administration. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An application that only reads one bucket prefix should not receive account-wide storage administration. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Readiness and routing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with readiness and routing. Use the glossary below, then write your prediction for: An application that only reads one bucket prefix should not receive account-wide storage administration. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AWS Cloud Engineer role interview. Explain readiness and routing using this case: An application that only reads one bucket prefix should not receive account-wide storage administration. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate readiness and routing to a system or workflow you know. Explain readiness and routing using this case: An application that only reads one bucket prefix should not receive account-wide storage administration. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain why a Running Pod might still receive no traffic.

Interview: Explain readiness and routing using this case: An application that only reads one bucket prefix should not receive account-wide storage administration. State the evidence, one alternative and where the mental model stops.

Quiz: After the Least-privilege access design rehearsal, check this foundation: A process listens on 8080. A Service accepts 80. Which target port should route to that listener?

80 because the Service port must equal the application port.

8080, matching the actual application listener.

443 because readiness always implies TLS.

Reference: 8080, matching the actual application listener. — Service and target ports can differ. Readiness must also reflect whether the workload can serve traffic.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Least-privilege access design

IAM permissions, network reachability and service configuration are separate gates. Test denied actions as well as allowed actions using an authorized sandbox identity. In this role, work through: An application that only reads one bucket prefix should not receive account-wide storage administration. The practical workshop develops this into: Write a narrowly scoped policy proposal with resource and action justifications. Validate it using AWS's policy tools in a sandbox if available; otherwise mark validation pending and review positive/negative cases manually.

Mental model: A route to the door and a key for the lock are separate requirements.

Boundary: A network timeout is not automatically an IAM denial; inspect the layer and error code.

Worked example: An application that only reads one bucket prefix should not receive account-wide storage administration.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: AWS IAM, VPC, EC2, S3, RDS and CloudWatch (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required AWS Cloud Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a narrowly scoped policy proposal with resource and action justifications. Validate it using AWS's policy tools in a sandbox if available; otherwise mark validation pending and review positive/negative cases manually.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

An application that only reads one bucket prefix should not receive account-wide storage administration. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a narrowly scoped policy proposal with resource and action justifications. Validate it using AWS's policy tools in a sandbox if available; otherwise mark validation pending and review positive/negative cases manually.

Expected: An access matrix with intended allowed read and denied unrelated write.

Role workshop · debug and verify

A network timeout is not automatically an IAM denial; inspect the layer and error code. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save policy proposal and authorization test plan. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: An access matrix with intended allowed read and denied unrelated write.

Expected: An access matrix with intended allowed read and denied unrelated write.

Troubleshoot: The role exercise differs from the prediction: A network timeout is not automatically an IAM denial; inspect the layer and error code.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-intermediate-2.md: policy proposal and authorization test plan; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with least-privilege access design. Use the glossary below, then write your prediction for: An application that only reads one bucket prefix should not receive account-wide storage administration. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AWS Cloud Engineer role interview. Explain least-privilege access design using this case: An application that only reads one bucket prefix should not receive account-wide storage administration. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate least-privilege access design to a system or workflow you know. Explain least-privilege access design using this case: An application that only reads one bucket prefix should not receive account-wide storage administration. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A network timeout is not automatically an IAM denial; inspect the layer and error code.

Interview: Explain least-privilege access design using this case: An application that only reads one bucket prefix should not receive account-wide storage administration. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? An application that only reads one bucket prefix should not receive account-wide storage administration.

Ignore the failing case and keep only the successful screenshot.

An access matrix with intended allowed read and denied unrelated write.

Treat any successful command as proof that all business and access rules passed.

Reference: An access matrix with intended allowed read and denied unrelated write. — IAM permissions, network reachability and service configuration are separate gates. Test denied actions as well as allowed actions using an authorized sandbox identity. An access matrix with intended allowed read and denied unrelated write.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Rollback and service objectives: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.

Apply rollback and service objectives in AWS Cloud Engineer: Use the concept to complete this role exercise: Create a deployment/recovery design and cost estimate before any paid resource creation

Recovery and cost engineering: Availability, backup recovery and cost controls need separate evidence. A multi-zone design is not a substitute for restoring accidentally deleted data.

### Rollback and service objectives

A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. In this role, work through: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. The practical workshop develops this into: Use the AWS framework to write a restore rehearsal, service health checks and a cost worksheet including storage, requests and data transfer. If running a sandbox, inventory and remove only resources created for the exercise.

Mental model: A reversible road detour with traffic counters at both ends.

Boundary: A rollback may not undo database changes; release safety includes schema compatibility.

Role application: Two open shops help during an outage; an archive restores records both shops deleted.

Availability, backup recovery and cost controls need separate evidence. A multi-zone design is not a substitute for restoring accidentally deleted data.

Worked example: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service.

Shared foundation example: Change the image to a nonexistent tag, inspect events and undo the rollout.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: AWS IAM, VPC, EC2, S3, RDS and CloudWatch (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AWS Cloud Engineer: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service.

Predict the worked case

Read this case without running a tool: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in rollback and service objectives.

Connect the concept to the role

Apply this rule: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A rollback may not undo database changes; release safety includes schema compatibility.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies rollback and service objectives to this case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Rollback and service objectives; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rollback and service objectives. Use the glossary below, then write your prediction for: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AWS Cloud Engineer role interview. Explain rollback and service objectives using this case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rollback and service objectives to a system or workflow you know. Explain rollback and service objectives using this case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks must pass after undoing a bad image?

Interview: Explain rollback and service objectives using this case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. State the evidence, one alternative and where the mental model stops.

Quiz: After the Recovery and cost engineering rehearsal, check this foundation: A rollout undo completes. What additional evidence establishes user recovery?

The deployment command exited zero, so no more checks are needed.

The old image tag exists in the registry.

A representative user operation succeeds and dependent state remains compatible.

Reference: A representative user operation succeeds and dependent state remains compatible. — Control-plane convergence does not verify the business path or reverse external state changes.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Recovery and cost engineering

Availability, backup recovery and cost controls need separate evidence. A multi-zone design is not a substitute for restoring accidentally deleted data. In this role, work through: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. The practical workshop develops this into: Use the AWS framework to write a restore rehearsal, service health checks and a cost worksheet including storage, requests and data transfer. If running a sandbox, inventory and remove only resources created for the exercise.

Mental model: Two open shops help during an outage; an archive restores records both shops deleted.

Boundary: A budget alert is not a guaranteed spending cap; include resource cleanup and ownership.

Worked example: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: AWS IAM, VPC, EC2, S3, RDS and CloudWatch (Commercial cloud service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required AWS Cloud Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Use the AWS framework to write a restore rehearsal, service health checks and a cost worksheet including storage, requests and data transfer. If running a sandbox, inventory and remove only resources created for the exercise.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Rehearse a failed release

Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

Role workshop · predict

Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Use the AWS framework to write a restore rehearsal, service health checks and a cost worksheet including storage, requests and data transfer. If running a sandbox, inventory and remove only resources created for the exercise.

Expected: A recovery checklist and dated cost estimate with region and usage assumptions.

Role workshop · debug and verify

A budget alert is not a guaranteed spending cap; include resource cleanup and ownership. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save AWS operational readiness review. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A recovery checklist and dated cost estimate with region and usage assumptions.

Expected: A recovery checklist and dated cost estimate with region and usage assumptions.

Troubleshoot: The role exercise differs from the prediction: A budget alert is not a guaranteed spending cap; include resource cleanup and ownership.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-advanced-2.md: AWS operational readiness review; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with recovery and cost engineering. Use the glossary below, then write your prediction for: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AWS Cloud Engineer role interview. Explain recovery and cost engineering using this case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate recovery and cost engineering to a system or workflow you know. Explain recovery and cost engineering using this case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A budget alert is not a guaranteed spending cap; include resource cleanup and ownership.

Interview: Explain recovery and cost engineering using this case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A recovery checklist and dated cost estimate with region and usage assumptions.

Reference: A recovery checklist and dated cost estimate with region and usage assumptions. — Availability, backup recovery and cost controls need separate evidence. A multi-zone design is not a substitute for restoring accidentally deleted data. A recovery checklist and dated cost estimate with region and usage assumptions.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/
