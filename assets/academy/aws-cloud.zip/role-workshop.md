# AWS Cloud Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
AWS responsibility mapping

Choose compute, storage, identity and telemetry services by workload needs and operational responsibility. A managed service reduces some administration but does not configure application permissions for you.
Mental model: Renting an apartment changes who repairs the roof, not who locks your door.
Case: A web service uses compute, a private data store, an execution identity and logs as separate concerns.
Task: Map the local task service to EC2 or a managed container option, S3/RDS where appropriate and CloudWatch. Draw request and credential flows; list why each service is needed before creating anything.
Acceptance: A service map with owners, data classification and alternatives.
Troubleshooting: Do not put a database on a public path merely because the web entry point is public.
Deliverable: AWS architecture diagram and responsibility table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Least-privilege access design

IAM permissions, network reachability and service configuration are separate gates. Test denied actions as well as allowed actions using an authorized sandbox identity.
Mental model: A route to the door and a key for the lock are separate requirements.
Case: An application that only reads one bucket prefix should not receive account-wide storage administration.
Task: Write a narrowly scoped policy proposal with resource and action justifications. Validate it using AWS's policy tools in a sandbox if available; otherwise mark validation pending and review positive/negative cases manually.
Acceptance: An access matrix with intended allowed read and denied unrelated write.
Troubleshooting: A network timeout is not automatically an IAM denial; inspect the layer and error code.
Deliverable: policy proposal and authorization test plan

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Recovery and cost engineering

Availability, backup recovery and cost controls need separate evidence. A multi-zone design is not a substitute for restoring accidentally deleted data.
Mental model: Two open shops help during an outage; an archive restores records both shops deleted.
Case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service.
Task: Use the AWS framework to write a restore rehearsal, service health checks and a cost worksheet including storage, requests and data transfer. If running a sandbox, inventory and remove only resources created for the exercise.
Acceptance: A recovery checklist and dated cost estimate with region and usage assumptions.
Troubleshooting: A budget alert is not a guaranteed spending cap; include resource cleanup and ownership.
Deliverable: AWS operational readiness review

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
