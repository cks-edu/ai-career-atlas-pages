# AWS Cloud Engineer

Software Engineering

Start with aws responsibility mapping. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward AWS operational readiness review.

## beginner

Map the local task service to EC2 or a managed container option, S3/RDS where appropriate and CloudWatch. Draw request and credential flows; list why each service is needed before creating anything.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### AWS responsibility mapping
Choose compute, storage, identity and telemetry services by workload needs and operational responsibility. A managed service reduces some administration but does not configure application permissions for you.
Mental model: Renting an apartment changes who repairs the roof, not who locks your door.
Limit: Do not put a database on a public path merely because the web entry point is public.
Example: A web service uses compute, a private data store, an execution identity and logs as separate concerns.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not put a database on a public path merely because the web entry point is public.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
A web service uses compute, a private data store, an execution identity and logs as separate concerns. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Map the local task service to EC2 or a managed container option, S3/RDS where appropriate and CloudWatch. Draw request and credential flows; list why each service is needed before creating anything.
Expected: A service map with owners, data classification and alternatives.

6. Role workshop · debug and verify
Do not put a database on a public path merely because the web entry point is public. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save AWS architecture diagram and responsibility table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A service map with owners, data classification and alternatives.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
AWS responsibility mapping: Do not put a database on a public path merely because the web entry point is public.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: AWS architecture diagram and responsibility table
A service map with owners, data classification and alternatives.

Interview: Work through this AWS Cloud Engineer case: A web service uses compute, a private data store, an execution identity and logs as separate concerns. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Choose compute, storage, identity and telemetry services by workload needs and operational responsibility. A managed service reduces some administration but does not configure application permissions for you. Expected evidence: A service map with owners, data classification and alternatives. Diagnosis: Do not put a database on a public path merely because the web entry point is public. State the limits of the mental model: Renting an apartment changes who repairs the roof, not who locks your door.

Resume: Built AWS architecture diagram and responsibility table using AWS IAM, VPC, EC2, S3, RDS and CloudWatch; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Write a narrowly scoped policy proposal with resource and action justifications. Validate it using AWS's policy tools in a sandbox if available; otherwise mark validation pending and review positive/negative cases manually.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Least-privilege access design
IAM permissions, network reachability and service configuration are separate gates. Test denied actions as well as allowed actions using an authorized sandbox identity.
Mental model: A route to the door and a key for the lock are separate requirements.
Limit: A network timeout is not automatically an IAM denial; inspect the layer and error code.
Example: An application that only reads one bucket prefix should not receive account-wide storage administration.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A network timeout is not automatically an IAM denial; inspect the layer and error code.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
An application that only reads one bucket prefix should not receive account-wide storage administration. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a narrowly scoped policy proposal with resource and action justifications. Validate it using AWS's policy tools in a sandbox if available; otherwise mark validation pending and review positive/negative cases manually.
Expected: An access matrix with intended allowed read and denied unrelated write.

6. Role workshop · debug and verify
A network timeout is not automatically an IAM denial; inspect the layer and error code. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save policy proposal and authorization test plan. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: An access matrix with intended allowed read and denied unrelated write.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Least-privilege access design: A network timeout is not automatically an IAM denial; inspect the layer and error code.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: policy proposal and authorization test plan
An access matrix with intended allowed read and denied unrelated write.

Interview: Work through this AWS Cloud Engineer case: An application that only reads one bucket prefix should not receive account-wide storage administration. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: IAM permissions, network reachability and service configuration are separate gates. Test denied actions as well as allowed actions using an authorized sandbox identity. Expected evidence: An access matrix with intended allowed read and denied unrelated write. Diagnosis: A network timeout is not automatically an IAM denial; inspect the layer and error code. State the limits of the mental model: A route to the door and a key for the lock are separate requirements.

Resume: Built policy proposal and authorization test plan using AWS IAM, VPC, EC2, S3, RDS and CloudWatch; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Use the AWS framework to write a restore rehearsal, service health checks and a cost worksheet including storage, requests and data transfer. If running a sandbox, inventory and remove only resources created for the exercise.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Recovery and cost engineering
Availability, backup recovery and cost controls need separate evidence. A multi-zone design is not a substitute for restoring accidentally deleted data.
Mental model: Two open shops help during an outage; an archive restores records both shops deleted.
Limit: A budget alert is not a guaranteed spending cap; include resource cleanup and ownership.
Example: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A budget alert is not a guaranteed spending cap; include resource cleanup and ownership.

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Role workshop · predict
Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use the AWS framework to write a restore rehearsal, service health checks and a cost worksheet including storage, requests and data transfer. If running a sandbox, inventory and remove only resources created for the exercise.
Expected: A recovery checklist and dated cost estimate with region and usage assumptions.

6. Role workshop · debug and verify
A budget alert is not a guaranteed spending cap; include resource cleanup and ownership. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save AWS operational readiness review. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A recovery checklist and dated cost estimate with region and usage assumptions.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Recovery and cost engineering: A budget alert is not a guaranteed spending cap; include resource cleanup and ownership.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: AWS operational readiness review
A recovery checklist and dated cost estimate with region and usage assumptions.

Interview: Work through this AWS Cloud Engineer case: Set proposed recovery objectives, identify backup age and calculate the cost assumptions for a small service. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Availability, backup recovery and cost controls need separate evidence. A multi-zone design is not a substitute for restoring accidentally deleted data. Expected evidence: A recovery checklist and dated cost estimate with region and usage assumptions. Diagnosis: A budget alert is not a guaranteed spending cap; include resource cleanup and ownership. State the limits of the mental model: Two open shops help during an outage; an archive restores records both shops deleted.

Resume: Built AWS operational readiness review using AWS IAM, VPC, EC2, S3, RDS and CloudWatch; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
Google SRE book: https://sre.google/sre-book/table-of-contents/
