## advanced — Research infrastructure trade-offs

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Research infrastructure trade-offs
Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change.
Mental model: A faster microscope is useful only if it still shows the same specimen reliably.
Boundary: Timing improvements on a toy input may not persist on the full experiment.
Worked example: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Reproducible experiment harness
Turn an experimental idea into a configurable, tested research implementation. Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.
Recall: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. Identify one observation that would contradict your claim.

### Terms
Research infrastructure trade-offs: Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Turn an experimental idea into a configurable, tested research implementation. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the tensor starter to establish the environment. Implement a configuration file for seed, data split, batch size and optimizer; reject unknown fields.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Turn an experimental idea into a configurable, tested research implementation.
Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.
Use the tensor starter to establish the environment. Implement a configuration file for seed, data split, batch size and optimizer; reject unknown fields.
Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.
Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping.
Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.
Add CI for CPU smoke tests and a separately scheduled accelerator validation job.
Deliverables: Tested research repository; Configuration/run registry and regenerated figures; Reproduction report with discrepancies. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. A reviewer must reproduce one result and identify which capabilities you implemented. Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

### Interview
Explain your advanced solution for AI research engineer. Use this scenario: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.
Review: Start with the task and permitted scope. Explain research infrastructure trade-offs: Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change. Show the input and observed output, then address Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Tested research repository; Configuration/run registry and regenerated figures; Reproduction report with discrepancies. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

