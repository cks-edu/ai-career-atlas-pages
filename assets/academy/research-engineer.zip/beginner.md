## beginner — Executable paper reading

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Executable paper reading
Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce.
Mental model: Turn a recipe description into a shopping list and ordered cooking steps.
Boundary: A description may omit implementation details needed for exact replication.
Worked example: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Reproduction without the data version
The reproduction contract requires code commit, dataset version and configuration hash for each run. Three runs cannot be independently reconstructed from their recorded metadata. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Capture immutable input and configuration references before launching experiments.
Recall: Recreate one run from a fresh environment and explain numerical tolerance. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Executable paper reading: Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Reproduction means checking whether an experiment can be repeated. A paper can omit details that matter for the outcome.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Read: “We trained a model for ten epochs on a public dataset and improved accuracy.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A missing-details checklist and a reproducibility note.

3. Try step 2
List missing details about dataset version, split, model, preprocessing, random seeds and the comparison baseline.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A missing-details checklist and a reproducibility note.

4. Try step 3
Draft a configuration checklist and mark which conclusions cannot yet be verified.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A missing-details checklist and a reproducibility note.

5. Explain and check your result
You distinguish reported claims from evidence you could reproduce; no absent detail is silently guessed. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A missing-details checklist and a reproducibility note. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The reproduction contract requires code commit, dataset version and configuration hash for each run. Apply this toy-case rule manually: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three runs cannot be independently reconstructed from their recorded metadata. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI research engineer.
Read: “We trained a model for ten epochs on a public dataset and improved accuracy.”
List missing details about dataset version, split, model, preprocessing, random seeds and the comparison baseline.
Draft a configuration checklist and mark which conclusions cannot yet be verified.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A missing-details checklist and a reproducibility note. Include beginner-worksheet.md and your completed Reproducibility manifest and deviation log.
Check: You distinguish reported claims from evidence you could reproduce; no absent detail is silently guessed.

### Interview
Explain your beginner solution for AI research engineer. Use this scenario: The reproduction contract requires code commit, dataset version and configuration hash for each run.
Review: Start with the task and permitted scope. Explain executable paper reading: Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce. Show the input and observed output, then address Capture immutable input and configuration references before launching experiments. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A missing-details checklist and a reproducibility note. Include beginner-worksheet.md and your completed Reproducibility manifest and deviation log.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

