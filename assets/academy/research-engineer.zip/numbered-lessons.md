# AI research engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Executable paper reading: Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

tensor: A multidimensional array of values with a shape and data type.

### Executable paper reading

Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce. In this role, work through: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Turn a recipe description into a shopping list and ordered cooking steps.

Boundary: A description may omit implementation details needed for exact replication.

Worked example: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI research engineer: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log.

Predict the worked case

Read this case without running a tool: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in executable paper reading.

Connect the concept to the role

Apply this rule: Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A description may omit implementation details needed for exact replication.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies executable paper reading to this case: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Executable paper reading; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with executable paper reading. Use the glossary below, then write your prediction for: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research engineer role interview. Explain executable paper reading using this case: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate executable paper reading to a system or workflow you know. Explain executable paper reading using this case: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain executable paper reading using this case: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log.

Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce. — Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce. A description may omit implementation details needed for exact replication.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

Google Research careers: https://research.google/careers/

### Diagnose: Reproduction without the data version

The reproduction contract requires code commit, dataset version and configuration hash for each run. Three runs cannot be independently reconstructed from their recorded metadata. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Capture immutable input and configuration references before launching experiments. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Turn a recipe description into a shopping list and ordered cooking steps.

Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log.

Worked example: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Capture immutable input and configuration references before launching experiments.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The reproduction contract requires code commit, dataset version and configuration hash for each run. Three runs cannot be independently reconstructed from their recorded metadata. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The reproduction contract requires code commit, dataset version and configuration hash for each run. Apply this toy-case rule manually: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Reproduction means checking whether an experiment can be repeated. A paper can omit details that matter for the outcome.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Read: “We trained a model for ten epochs on a public dataset and improved accuracy.”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A missing-details checklist and a reproducibility note.

Preparation · Try step 2

List missing details about dataset version, split, model, preprocessing, random seeds and the comparison baseline.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A missing-details checklist and a reproducibility note.

Preparation · Try step 3

Draft a configuration checklist and mark which conclusions cannot yet be verified.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A missing-details checklist and a reproducibility note.

Preparation · Explain and check your result

You distinguish reported claims from evidence you could reproduce; no absent detail is silently guessed. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A missing-details checklist and a reproducibility note. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The reproduction contract requires code commit, dataset version and configuration hash for each run. Apply this toy-case rule manually: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three runs cannot be independently reconstructed from their recorded metadata. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three runs cannot be independently reconstructed from their recorded metadata. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: reproduction without the data version. Use the glossary below, then write your prediction for: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Capture immutable input and configuration references before launching experiments. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research engineer role interview. Explain diagnose: reproduction without the data version using this case: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Capture immutable input and configuration references before launching experiments. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: reproduction without the data version to a system or workflow you know. Explain diagnose: reproduction without the data version using this case: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Capture immutable input and configuration references before launching experiments. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Recreate one run from a fresh environment and explain numerical tolerance. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: reproduction without the data version using this case: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Capture immutable input and configuration references before launching experiments. State the evidence, one alternative and where the mental model stops.

Quiz: Reproduction without the data version: The reproduction contract requires code commit, dataset version and configuration hash for each run.

Change the acceptance rule after seeing an inconvenient result.

Capture immutable input and configuration references before launching experiments.

Omit failed cases and report only the successful demonstrations.

Reference: Capture immutable input and configuration references before launching experiments. — Capture immutable input and configuration references before launching experiments. Recreate one run from a fresh environment and explain numerical tolerance.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

Google Research careers: https://research.google/careers/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, tensor frameworks, numerical debugging and ability to read papers; requirements vary by laboratory.

Terms:

Reproducible experiment harnesses: Make configurations, seeds, dependencies and artifacts explicit. Add small correctness checks before spending resources on long experiments.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.

checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.

tensor: A multidimensional array of values with a shape and data type.

### Reproducible experiment harnesses

Make configurations, seeds, dependencies and artifacts explicit. Add small correctness checks before spending resources on long experiments. In this role, work through: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A laboratory notebook records the apparatus and settings for each trial.

Boundary: Fixed seeds cannot guarantee identical results across every device and library.

Worked example: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, tensor frameworks, numerical debugging and ability to read papers; requirements vary by laboratory.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI research engineer: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run.

Predict the worked case

Read this case without running a tool: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in reproducible experiment harnesses.

Connect the concept to the role

Apply this rule: Make configurations, seeds, dependencies and artifacts explicit. Add small correctness checks before spending resources on long experiments. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Fixed seeds cannot guarantee identical results across every device and library.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies reproducible experiment harnesses to this case: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Reproducible experiment harnesses; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with reproducible experiment harnesses. Use the glossary below, then write your prediction for: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research engineer role interview. Explain reproducible experiment harnesses using this case: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate reproducible experiment harnesses to a system or workflow you know. Explain reproducible experiment harnesses using this case: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain reproducible experiment harnesses using this case: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run.

Treat a passing starter as proof of the whole role workflow.

Make configurations, seeds, dependencies and artifacts explicit. Add small correctness checks before spending resources on long experiments.

Ignore the failure because the tool produced an output.

Reference: Make configurations, seeds, dependencies and artifacts explicit. Add small correctness checks before spending resources on long experiments. — Make configurations, seeds, dependencies and artifacts explicit. Add small correctness checks before spending resources on long experiments. Fixed seeds cannot guarantee identical results across every device and library.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

Google Research careers: https://research.google/careers/

### Integrate: Reproducible experiment harness

Turn an experimental idea into a configurable, tested research implementation. Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run. In this role, work through: Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Role application: A laboratory notebook records the apparatus and settings for each trial.

A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run.

Worked example: Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.

Setup: Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Turn an experimental idea into a configurable, tested research implementation. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Turn an experimental idea into a configurable, tested research implementation.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

Prepare the project inputs

Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use the tensor starter to establish the environment. Implement a configuration file for seed, data split, batch size and optimizer; reject unknown fields.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The reproduction contract requires code commit, dataset version and configuration hash for each run. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Deliverable: lesson-intermediate-2.md: Tested research repository; Configuration/run registry and regenerated figures. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: reproducible experiment harness. Use the glossary below, then write your prediction for: Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research engineer role interview. Explain integrate: reproducible experiment harness using this case: Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: reproducible experiment harness to a system or workflow you know. Explain integrate: reproducible experiment harness using this case: Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. Identify one observation that would contradict your claim.

Interview: Explain integrate: reproducible experiment harness using this case: Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Reproducible experiment harness at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.

Reference: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. — Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

Google Research careers: https://research.google/careers/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Research infrastructure trade-offs: Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.

checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.

tensor: A multidimensional array of values with a shape and data type.

### Research infrastructure trade-offs

Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change. In this role, work through: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A faster microscope is useful only if it still shows the same specimen reliably.

Boundary: Timing improvements on a toy input may not persist on the full experiment.

Worked example: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI research engineer: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability.

Predict the worked case

Read this case without running a tool: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in research infrastructure trade-offs.

Connect the concept to the role

Apply this rule: Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Timing improvements on a toy input may not persist on the full experiment.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies research infrastructure trade-offs to this case: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Research infrastructure trade-offs; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with research infrastructure trade-offs. Use the glossary below, then write your prediction for: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research engineer role interview. Explain research infrastructure trade-offs using this case: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate research infrastructure trade-offs to a system or workflow you know. Explain research infrastructure trade-offs using this case: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain research infrastructure trade-offs using this case: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change.

Reference: Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change. — Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change. Timing improvements on a toy input may not persist on the full experiment.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

Google Research careers: https://research.google/careers/

### Defend: Reproducible experiment harness

Turn an experimental idea into a configurable, tested research implementation. Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping. In this role, work through: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Role application: A faster microscope is useful only if it still shows the same specimen reliably.

Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability.

Worked example: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

Setup: Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PyTorch (Open source · hardware dependent); MLflow (Open source · hosted offerings optional); GitHub Actions (Commercial hosted service · usage limits)

Turn an experimental idea into a configurable, tested research implementation. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Turn an experimental idea into a configurable, tested research implementation.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

Prepare the project inputs

Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use the tensor starter to establish the environment. Implement a configuration file for seed, data split, batch size and optimizer; reject unknown fields.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. A reviewer must reproduce one result and identify which capabilities you implemented. Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Deliverable: lesson-advanced-2.md: Tested research repository; Configuration/run registry and regenerated figures; Reproduction report with discrepancies. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: reproducible experiment harness. Use the glossary below, then write your prediction for: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI research engineer role interview. Explain defend: reproducible experiment harness using this case: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: reproducible experiment harness to a system or workflow you know. Explain defend: reproducible experiment harness using this case: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. Identify one observation that would contradict your claim.

Interview: Explain defend: reproducible experiment harness using this case: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Reproducible experiment harness at this level?

Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference. — Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference. Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

GitHub Actions: https://docs.github.com/en/actions

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

Google Research careers: https://research.google/careers/
