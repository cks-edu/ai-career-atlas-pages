# AI research engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Executable paper reading. Reproduction means checking whether an experiment can be repeated. A paper can omit details that matter for the outcome. Then try Audit a fictional experiment description. The three levels build toward Reproducible experiment harness. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Executable paper reading

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Executable paper reading
Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce.
Mental model: Turn a recipe description into a shopping list and ordered cooking steps.
Boundary: A description may omit implementation details needed for exact replication.
Worked example: Write tensor shapes and loss terms before coding; mark an unspecified preprocessing choice as an assumption in the reproduction log.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Reproduction without the data version
The reproduction contract requires code commit, dataset version and configuration hash for each run. Three runs cannot be independently reconstructed from their recorded metadata. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Capture immutable input and configuration references before launching experiments.
Recall: Recreate one run from a fresh environment and explain numerical tolerance. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Executable paper reading: Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Reproduction means checking whether an experiment can be repeated. A paper can omit details that matter for the outcome.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Read: “We trained a model for ten epochs on a public dataset and improved accuracy.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A missing-details checklist and a reproducibility note.

3. Try step 2
List missing details about dataset version, split, model, preprocessing, random seeds and the comparison baseline.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A missing-details checklist and a reproducibility note.

4. Try step 3
Draft a configuration checklist and mark which conclusions cannot yet be verified.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A missing-details checklist and a reproducibility note.

5. Explain and check your result
You distinguish reported claims from evidence you could reproduce; no absent detail is silently guessed. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A missing-details checklist and a reproducibility note. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The reproduction contract requires code commit, dataset version and configuration hash for each run. Apply this toy-case rule manually: Review when missing_run_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three runs cannot be independently reconstructed from their recorded metadata. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI research engineer.
Read: “We trained a model for ten epochs on a public dataset and improved accuracy.”
List missing details about dataset version, split, model, preprocessing, random seeds and the comparison baseline.
Draft a configuration checklist and mark which conclusions cannot yet be verified.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A missing-details checklist and a reproducibility note. Include beginner-worksheet.md and your completed Reproducibility manifest and deviation log.
Check: You distinguish reported claims from evidence you could reproduce; no absent detail is silently guessed.

### Interview
Explain your beginner solution for AI research engineer. Use this scenario: The reproduction contract requires code commit, dataset version and configuration hash for each run.
Review: Start with the task and permitted scope. Explain executable paper reading: Translate a paper's method into inputs, operations and measurable outputs. Identify missing details and distinguish the authors' reported result from what you reproduce. Show the input and observed output, then address Capture immutable input and configuration references before launching experiments. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A missing-details checklist and a reproducibility note. Include beginner-worksheet.md and your completed Reproducibility manifest and deviation log.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Reproducible experiment harnesses

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, tensor frameworks, numerical debugging and ability to read papers; requirements vary by laboratory.

### Reproducible experiment harnesses
Make configurations, seeds, dependencies and artifacts explicit. Add small correctness checks before spending resources on long experiments.
Mental model: A laboratory notebook records the apparatus and settings for each trial.
Boundary: Fixed seeds cannot guarantee identical results across every device and library.
Worked example: A smoke test uses two batches to verify finite loss and checkpoint loading before scheduling a longer run.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Reproducible experiment harness
Turn an experimental idea into a configurable, tested research implementation. Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.
Recall: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. Identify one observation that would contradict your claim.

### Terms
Reproducible experiment harnesses: Make configurations, seeds, dependencies and artifacts explicit. Add small correctness checks before spending resources on long experiments.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Turn an experimental idea into a configurable, tested research implementation. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the tensor starter to establish the environment. Implement a configuration file for seed, data split, batch size and optimizer; reject unknown fields.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The reproduction contract requires code commit, dataset version and configuration hash for each run. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Turn an experimental idea into a configurable, tested research implementation.
Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.
Use the tensor starter to establish the environment. Implement a configuration file for seed, data split, batch size and optimizer; reject unknown fields.
Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.
Deliverables: Tested research repository; Configuration/run registry and regenerated figures. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI research engineer. Use this scenario: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.
Review: Start with the task and permitted scope. Explain reproducible experiment harnesses: Make configurations, seeds, dependencies and artifacts explicit. Add small correctness checks before spending resources on long experiments. Show the input and observed output, then address Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Tested research repository; Configuration/run registry and regenerated figures. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Research infrastructure trade-offs

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Research infrastructure trade-offs
Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change.
Mental model: A faster microscope is useful only if it still shows the same specimen reliably.
Boundary: Timing improvements on a toy input may not persist on the full experiment.
Worked example: Mixed precision improves speed; compare losses and final metrics within declared tolerances and record any instability.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Reproducible experiment harness
Turn an experimental idea into a configurable, tested research implementation. Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.
Recall: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. Identify one observation that would contradict your claim.

### Terms
Research infrastructure trade-offs: Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Turn an experimental idea into a configurable, tested research implementation. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use the tensor starter to establish the environment. Implement a configuration file for seed, data split, batch size and optimizer; reject unknown fields.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Turn an experimental idea into a configurable, tested research implementation.
Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.
Use the tensor starter to establish the environment. Implement a configuration file for seed, data split, batch size and optimizer; reject unknown fields.
Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.
Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping.
Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.
Add CI for CPU smoke tests and a separately scheduled accelerator validation job.
Deliverables: Tested research repository; Configuration/run registry and regenerated figures; Reproduction report with discrepancies. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. A reviewer must reproduce one result and identify which capabilities you implemented. Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

### Interview
Explain your advanced solution for AI research engineer. Use this scenario: Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.
Review: Start with the task and permitted scope. Explain research infrastructure trade-offs: Optimize experiment throughput without changing the scientific question unnoticed. Profile bottlenecks and verify numerical behavior after a performance change. Show the input and observed output, then address Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Tested research repository; Configuration/run registry and regenerated figures; Reproduction report with discrepancies. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

GitHub Actions — Commercial hosted service · usage limits
CI checks and reviewable build artifacts; paid usage may apply.
Alternative: GitLab CI (open-core/commercial offerings) or Jenkins (open source); runners and compute still need operating resources.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
GitHub Actions: https://docs.github.com/en/actions
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
MLflow: https://mlflow.org/docs/latest/
Google Research careers: https://research.google/careers/
