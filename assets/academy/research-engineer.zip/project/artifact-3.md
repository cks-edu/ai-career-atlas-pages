# Reproduction report with discrepancies

Project: Reproducible experiment harness
Status: blank work product — not completed evidence

## Purpose and audience
Turn an experimental idea into a configurable, tested research implementation.

## Required content
Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.

## Failure evidence
Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
