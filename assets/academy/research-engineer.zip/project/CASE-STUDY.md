# Reproducible experiment harness

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Turn an experimental idea into a configurable, tested research implementation.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

## Limitations and next iteration
Add CI for CPU smoke tests and a separately scheduled accelerator validation job.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
