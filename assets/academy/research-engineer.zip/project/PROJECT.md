# Reproducible experiment harness

Career: AI research engineer
Reviewed: 2026-10-22

Turn an experimental idea into a configurable, tested research implementation.

## Prerequisites
Python, tensor frameworks, numerical debugging and ability to read papers; requirements vary by laboratory.

## Included starter versus your implementation
A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Select a small open paper implementation or define a simple optimization experiment. Record the exact claim, repository license and hardware assumptions; do not promise paper reproduction on incompatible hardware.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Use the tensor starter to establish the environment. Implement a configuration file for seed, data split, batch size and optimizer; reject unknown fields.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Run a bounded sweep and write a script that rebuilds the result table from raw logs. Keep failed runs in the report and explain early stopping.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Tested research repository — artifact-1.md
2. Configuration/run registry and regenerated figures — artifact-2.md
3. Reproduction report with discrepancies — artifact-3.md

## Troubleshooting
- CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
- OOM: reduce batch/context size and inspect live allocations.
- Unstable timings: warm up, synchronize and isolate other workloads.

## Extension
Add CI for CPU smoke tests and a separately scheduled accelerator validation job.

## Primary learning resources
- PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html — Open source · hardware dependent; Tensor operations, training and hardware-aware profiling.
- MLflow: https://mlflow.org/docs/latest/ml/tracking/quickstart/ — Open source · hosted offerings optional; Record experiments, parameters and evaluation artifacts.
- GitHub Actions: https://docs.github.com/en/actions — Commercial hosted service · usage limits; CI checks and reviewable build artifacts; paid usage may apply.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
