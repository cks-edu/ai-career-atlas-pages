"""Bounded PyTorch environment/timing probe; not a training or kernel implementation."""
import json,os,time
import torch

def run():
    device=os.environ.get('DEVICE','cpu')
    if device not in ('cpu','cuda'): raise ValueError('DEVICE must be cpu or cuda')
    if device=='cuda' and not torch.cuda.is_available(): raise RuntimeError('CUDA unavailable; install a compatible build/driver or use CPU.')
    torch.manual_seed(42)
    a=torch.randn(256,256,device=device);b=torch.randn(256,256,device=device)
    for _ in range(3): result=a@b
    if device=='cuda': torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats()
    start=time.perf_counter()
    for _ in range(10): result=a@b
    if device=='cuda': torch.cuda.synchronize()
    return {'torch':torch.__version__,'device':device,'shape':list(result.shape),'finite':bool(torch.isfinite(result).all()),'seconds_per_matmul':(time.perf_counter()-start)/10,'peak_allocated_bytes':torch.cuda.max_memory_allocated() if device=='cuda' else None}
if __name__=='__main__': print(json.dumps(run(),indent=2))
