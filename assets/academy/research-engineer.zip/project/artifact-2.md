# Configuration/run registry and regenerated figures

Project: Reproducible experiment harness
Status: blank work product — not completed evidence

## Purpose and audience
Turn an experimental idea into a configurable, tested research implementation.

## Required content
Add a smoke test, deterministic data fixture and checkpoint round-trip test. Log source commit, dependency versions and metrics for each run.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.

## Failure evidence
Interrupt a run and resume from checkpoint; compare metrics and step counts with the uninterrupted reference.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
