# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Tested research repository.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report reproducibility tolerance, runtime, failure rate and sensitivity to seeds. Distinguish reproducing a mechanism from reproducing a published headline result.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
