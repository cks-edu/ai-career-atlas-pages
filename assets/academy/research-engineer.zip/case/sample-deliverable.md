# SAMPLE — Reproducibility manifest and deviation log
Role: AI research engineer
Case: Reproduction without the data version
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The reproduction contract requires code commit, dataset version and configuration hash for each run.

## Evidence table
| Record | missing_run_fields (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three runs cannot be independently reconstructed from their recorded metadata.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Capture immutable input and configuration references before launching experiments.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai research engineer.
Before release: Recreate one run from a fresh environment and explain numerical tolerance.

## Design choice and trade-off
Automate configuration validation and artifact capture; preserve failed runs for diagnosis.
Strict reproducibility has storage and setup costs but reduces ambiguous research conclusions.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Small-paper reproduction: Document deviations from published settings.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
