# Test Automation / SDET

Software Engineering

Start with assertions and isolated fixtures. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward CI workflow, trace analysis and flaky-test policy.

## beginner

Install Playwright using its official guide in a fresh project. Start the local reference, use role/label locators to submit a task and assert its visible result. Reset the server between isolated tests.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Observable behavior
A test compares a defined observation with an expected result for a chosen input.
Mental model: A recipe with a taste check rather than a photograph of ingredients.
Limit: Passing examples do not prove every possible input works.
Example: An empty task must not be added and the error must be understandable.
Recall: Write a test case with input, action and expected observation.

### Assertions and isolated fixtures
An automated test needs an observable assertion and independent starting state. A script that clicks controls without checking results can pass while the feature is broken.
Mental model: A rehearsal needs a judge, not only a list of movements.
Limit: A passing test with no meaningful assertion is not feature coverage.
Example: After one valid submission the task list contains exactly one matching title.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A passing test with no meaningful assertion is not feature coverage.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
After one valid submission the task list contains exactly one matching title. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Install Playwright using its official guide in a fresh project. Start the local reference, use role/label locators to submit a task and assert its visible result. Reset the server between isolated tests.
Expected: The test fails if rendering is deliberately removed, then passes after repair.

6. Role workshop · debug and verify
A passing test with no meaningful assertion is not feature coverage. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Playwright test and failure proof. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The test fails if rendering is deliberately removed, then passes after repair.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Assertions and isolated fixtures: A passing test with no meaningful assertion is not feature coverage.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: Playwright test and failure proof
The test fails if rendering is deliberately removed, then passes after repair.

Interview: Work through this Test Automation / SDET case: After one valid submission the task list contains exactly one matching title. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An automated test needs an observable assertion and independent starting state. A script that clicks controls without checking results can pass while the feature is broken. Expected evidence: The test fails if rendering is deliberately removed, then passes after repair. Diagnosis: A passing test with no meaningful assertion is not feature coverage. State the limits of the mental model: A rehearsal needs a judge, not only a list of movements.

Resume: Built Playwright test and failure proof using Playwright; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create a fresh service process or isolated store per test worker. Add invalid-input and duplicate-submission tests; run them in reversed order and with two workers.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Test boundaries
Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow.
Mental model: Check a component, then an assembled bicycle, then a ride.
Limit: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.
Example: Validate title alone, then HTTP request, then keyboard submission in the browser.
Recall: Which layer should identify whether a failure is parsing or rendering?

### Test data and API boundaries
Use API setup for state when the test is about UI behavior, but test the API itself separately. Fixtures should not depend on execution order or shared mutable records.
Mental model: Prepare the stage separately from testing the actor's performance.
Limit: Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions.
Example: Two tests must each see their own task list rather than inherit the previous test's records.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Two tests must each see their own task list rather than inherit the previous test's records. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a fresh service process or isolated store per test worker. Add invalid-input and duplicate-submission tests; run them in reversed order and with two workers.
Expected: Results remain consistent across order and worker count.

6. Role workshop · debug and verify
Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save fixture helpers and repeat-run report. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Results remain consistent across order and worker count.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Test data and API boundaries: Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: fixture helpers and repeat-run report
Results remain consistent across order and worker count.

Interview: Work through this Test Automation / SDET case: Two tests must each see their own task list rather than inherit the previous test's records. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Use API setup for state when the test is about UI behavior, but test the API itself separately. Fixtures should not depend on execution order or shared mutable records. Expected evidence: Results remain consistent across order and worker count. Diagnosis: Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions. State the limits of the mental model: Prepare the stage separately from testing the actor's performance.

Resume: Built fixture helpers and repeat-run report using Playwright; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Add CI setup, server readiness check and Playwright trace retention on failure. Deliberately break a locator, inspect the trace, repair it and document artifact retention.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Risk-based release
Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery.
Mental model: Inspect brakes before polishing the paint.
Limit: Risk ranking is judgment informed by users, not an excuse to skip known defects.
Example: Test invalid input, double submission, keyboard focus and server restart; record results.
Recall: What evidence would make you hold a release despite a high pass count?

### Failure diagnostics in CI
A failing CI test should preserve enough evidence to distinguish product, test and environment failures. Retries are diagnostic signals, not a way to erase instability.
Mental model: A flight recorder makes the failed journey inspectable after landing.
Limit: A test that passes only on retry remains a stability issue to investigate.
Example: A missing server and a wrong button label should produce different diagnostics.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A test that passes only on retry remains a stability issue to investigate.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
A missing server and a wrong button label should produce different diagnostics. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add CI setup, server readiness check and Playwright trace retention on failure. Deliberately break a locator, inspect the trace, repair it and document artifact retention.
Expected: The pipeline fails visibly and retains the relevant trace; clean run then passes.

6. Role workshop · debug and verify
A test that passes only on retry remains a stability issue to investigate. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save CI workflow, trace analysis and flaky-test policy. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The pipeline fails visibly and retains the relevant trace; clean run then passes.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Failure diagnostics in CI: A test that passes only on retry remains a stability issue to investigate.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: CI workflow, trace analysis and flaky-test policy
The pipeline fails visibly and retains the relevant trace; clean run then passes.

Interview: Work through this Test Automation / SDET case: A missing server and a wrong button label should produce different diagnostics. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A failing CI test should preserve enough evidence to distinguish product, test and environment failures. Retries are diagnostic signals, not a way to erase instability. Expected evidence: The pipeline fails visibly and retains the relevant trace; clean run then passes. Diagnosis: A test that passes only on retry remains a stability issue to investigate. State the limits of the mental model: A flight recorder makes the failed journey inspectable after landing.

Resume: Built CI workflow, trace analysis and flaky-test policy using Playwright; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Playwright: installation and first tests: https://playwright.dev/docs/intro
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
