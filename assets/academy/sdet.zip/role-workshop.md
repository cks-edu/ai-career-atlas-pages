# Test Automation / SDET — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Assertions and isolated fixtures

An automated test needs an observable assertion and independent starting state. A script that clicks controls without checking results can pass while the feature is broken.
Mental model: A rehearsal needs a judge, not only a list of movements.
Case: After one valid submission the task list contains exactly one matching title.
Task: Install Playwright using its official guide in a fresh project. Start the local reference, use role/label locators to submit a task and assert its visible result. Reset the server between isolated tests.
Acceptance: The test fails if rendering is deliberately removed, then passes after repair.
Troubleshooting: A passing test with no meaningful assertion is not feature coverage.
Deliverable: Playwright test and failure proof

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Test data and API boundaries

Use API setup for state when the test is about UI behavior, but test the API itself separately. Fixtures should not depend on execution order or shared mutable records.
Mental model: Prepare the stage separately from testing the actor's performance.
Case: Two tests must each see their own task list rather than inherit the previous test's records.
Task: Create a fresh service process or isolated store per test worker. Add invalid-input and duplicate-submission tests; run them in reversed order and with two workers.
Acceptance: Results remain consistent across order and worker count.
Troubleshooting: Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions.
Deliverable: fixture helpers and repeat-run report

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Failure diagnostics in CI

A failing CI test should preserve enough evidence to distinguish product, test and environment failures. Retries are diagnostic signals, not a way to erase instability.
Mental model: A flight recorder makes the failed journey inspectable after landing.
Case: A missing server and a wrong button label should produce different diagnostics.
Task: Add CI setup, server readiness check and Playwright trace retention on failure. Deliberately break a locator, inspect the trace, repair it and document artifact retention.
Acceptance: The pipeline fails visibly and retains the relevant trace; clean run then passes.
Troubleshooting: A test that passes only on retry remains a stability issue to investigate.
Deliverable: CI workflow, trace analysis and flaky-test policy

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
