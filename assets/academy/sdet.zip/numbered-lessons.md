# Test Automation / SDET — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Observable behavior: A test compares a defined observation with an expected result for a chosen input.

Apply observable behavior in Test Automation / SDET: Use the concept to complete this role exercise: Run the reference validation checks and identify assertions

Assertions and isolated fixtures: An automated test needs an observable assertion and independent starting state. A script that clicks controls without checking results can pass while the feature is broken.

### Observable behavior

A test compares a defined observation with an expected result for a chosen input. In this role, work through: After one valid submission the task list contains exactly one matching title. The practical workshop develops this into: Install Playwright using its official guide in a fresh project. Start the local reference, use role/label locators to submit a task and assert its visible result. Reset the server between isolated tests.

Mental model: A recipe with a taste check rather than a photograph of ingredients.

Boundary: Passing examples do not prove every possible input works.

Role application: A rehearsal needs a judge, not only a list of movements.

An automated test needs an observable assertion and independent starting state. A script that clicks controls without checking results can pass while the feature is broken.

Worked example: After one valid submission the task list contains exactly one matching title.

Shared foundation example: An empty task must not be added and the error must be understandable.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Playwright (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Test Automation / SDET: After one valid submission the task list contains exactly one matching title.

Predict the worked case

Read this case without running a tool: After one valid submission the task list contains exactly one matching title. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in observable behavior.

Connect the concept to the role

Apply this rule: A test compares a defined observation with an expected result for a chosen input. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Passing examples do not prove every possible input works.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies observable behavior to this case: After one valid submission the task list contains exactly one matching title. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After one valid submission the task list contains exactly one matching title. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Observable behavior; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with observable behavior. Use the glossary below, then write your prediction for: After one valid submission the task list contains exactly one matching title. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Test Automation / SDET role interview. Explain observable behavior using this case: After one valid submission the task list contains exactly one matching title. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate observable behavior to a system or workflow you know. Explain observable behavior using this case: After one valid submission the task list contains exactly one matching title. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Write a test case with input, action and expected observation.

Interview: Explain observable behavior using this case: After one valid submission the task list contains exactly one matching title. State the evidence, one alternative and where the mental model stops.

Quiz: After the Assertions and isolated fixtures rehearsal, check this foundation: A test reports success because the page loaded. The requirement is to reject blank submissions. Which evidence is missing?

The rejection behavior and unchanged stored state for blank input.

Only the browser version string.

The number of CSS files that loaded.

Reference: The rejection behavior and unchanged stored state for blank input. — An observation must match the contract being tested. Page availability alone does not test the invalid-input rule.

Sources:

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

### Assertions and isolated fixtures

An automated test needs an observable assertion and independent starting state. A script that clicks controls without checking results can pass while the feature is broken. In this role, work through: After one valid submission the task list contains exactly one matching title. The practical workshop develops this into: Install Playwright using its official guide in a fresh project. Start the local reference, use role/label locators to submit a task and assert its visible result. Reset the server between isolated tests.

Mental model: A rehearsal needs a judge, not only a list of movements.

Boundary: A passing test with no meaningful assertion is not feature coverage.

Worked example: After one valid submission the task list contains exactly one matching title.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Playwright (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Test Automation / SDET workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Install Playwright using its official guide in a fresh project. Start the local reference, use role/label locators to submit a task and assert its visible result. Reset the server between isolated tests.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web beginner

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

After one valid submission the task list contains exactly one matching title. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Install Playwright using its official guide in a fresh project. Start the local reference, use role/label locators to submit a task and assert its visible result. Reset the server between isolated tests.

Expected: The test fails if rendering is deliberately removed, then passes after repair.

Role workshop · debug and verify

A passing test with no meaningful assertion is not feature coverage. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Playwright test and failure proof. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The test fails if rendering is deliberately removed, then passes after repair.

Expected: The test fails if rendering is deliberately removed, then passes after repair.

Troubleshoot: The role exercise differs from the prediction: A passing test with no meaningful assertion is not feature coverage.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-beginner-2.md: Playwright test and failure proof; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with assertions and isolated fixtures. Use the glossary below, then write your prediction for: After one valid submission the task list contains exactly one matching title. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Test Automation / SDET role interview. Explain assertions and isolated fixtures using this case: After one valid submission the task list contains exactly one matching title. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate assertions and isolated fixtures to a system or workflow you know. Explain assertions and isolated fixtures using this case: After one valid submission the task list contains exactly one matching title. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A passing test with no meaningful assertion is not feature coverage.

Interview: Explain assertions and isolated fixtures using this case: After one valid submission the task list contains exactly one matching title. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? After one valid submission the task list contains exactly one matching title.

The test fails if rendering is deliberately removed, then passes after repair.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: The test fails if rendering is deliberately removed, then passes after repair. — An automated test needs an observable assertion and independent starting state. A script that clicks controls without checking results can pass while the feature is broken. The test fails if rendering is deliberately removed, then passes after repair.

Sources:

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Test boundaries: Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow.

Apply test boundaries in Test Automation / SDET: Use the concept to complete this role exercise: Automate the add-task flow with Playwright locators

Test data and API boundaries: Use API setup for state when the test is about UI behavior, but test the API itself separately. Fixtures should not depend on execution order or shared mutable records.

### Test boundaries

Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow. In this role, work through: Two tests must each see their own task list rather than inherit the previous test's records. The practical workshop develops this into: Create a fresh service process or isolated store per test worker. Add invalid-input and duplicate-submission tests; run them in reversed order and with two workers.

Mental model: Check a component, then an assembled bicycle, then a ride.

Boundary: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.

Role application: Prepare the stage separately from testing the actor's performance.

Use API setup for state when the test is about UI behavior, but test the API itself separately. Fixtures should not depend on execution order or shared mutable records.

Worked example: Two tests must each see their own task list rather than inherit the previous test's records.

Shared foundation example: Validate title alone, then HTTP request, then keyboard submission in the browser.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Playwright (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Test Automation / SDET: Two tests must each see their own task list rather than inherit the previous test's records.

Predict the worked case

Read this case without running a tool: Two tests must each see their own task list rather than inherit the previous test's records. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in test boundaries.

Connect the concept to the role

Apply this rule: Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies test boundaries to this case: Two tests must each see their own task list rather than inherit the previous test's records. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two tests must each see their own task list rather than inherit the previous test's records. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Test boundaries; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with test boundaries. Use the glossary below, then write your prediction for: Two tests must each see their own task list rather than inherit the previous test's records. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Test Automation / SDET role interview. Explain test boundaries using this case: Two tests must each see their own task list rather than inherit the previous test's records. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate test boundaries to a system or workflow you know. Explain test boundaries using this case: Two tests must each see their own task list rather than inherit the previous test's records. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which layer should identify whether a failure is parsing or rendering?

Interview: Explain test boundaries using this case: Two tests must each see their own task list rather than inherit the previous test's records. State the evidence, one alternative and where the mental model stops.

Quiz: After the Test data and API boundaries rehearsal, check this foundation: A function test passes. Which check would examine whether HTTP parsing and the function work together?

Rerun the same isolated function test.

An integration test through the request boundary.

Only inspect a screenshot of the editor.

Reference: An integration test through the request boundary. — Integration tests exercise cooperating parts. They complement rather than replace focused unit checks.

Sources:

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

### Test data and API boundaries

Use API setup for state when the test is about UI behavior, but test the API itself separately. Fixtures should not depend on execution order or shared mutable records. In this role, work through: Two tests must each see their own task list rather than inherit the previous test's records. The practical workshop develops this into: Create a fresh service process or isolated store per test worker. Add invalid-input and duplicate-submission tests; run them in reversed order and with two workers.

Mental model: Prepare the stage separately from testing the actor's performance.

Boundary: Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions.

Worked example: Two tests must each see their own task list rather than inherit the previous test's records.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Playwright (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Test Automation / SDET workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a fresh service process or isolated store per test worker. Add invalid-input and duplicate-submission tests; run them in reversed order and with two workers.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web intermediate

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

Two tests must each see their own task list rather than inherit the previous test's records. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a fresh service process or isolated store per test worker. Add invalid-input and duplicate-submission tests; run them in reversed order and with two workers.

Expected: Results remain consistent across order and worker count.

Role workshop · debug and verify

Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save fixture helpers and repeat-run report. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Results remain consistent across order and worker count.

Expected: Results remain consistent across order and worker count.

Troubleshoot: The role exercise differs from the prediction: Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-intermediate-2.md: fixture helpers and repeat-run report; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with test data and api boundaries. Use the glossary below, then write your prediction for: Two tests must each see their own task list rather than inherit the previous test's records. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Test Automation / SDET role interview. Explain test data and api boundaries using this case: Two tests must each see their own task list rather than inherit the previous test's records. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate test data and api boundaries to a system or workflow you know. Explain test data and api boundaries using this case: Two tests must each see their own task list rather than inherit the previous test's records. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Flakiness often comes from shared state or arbitrary sleeps; wait for observable conditions.

Interview: Explain test data and api boundaries using this case: Two tests must each see their own task list rather than inherit the previous test's records. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Two tests must each see their own task list rather than inherit the previous test's records.

Ignore the failing case and keep only the successful screenshot.

Results remain consistent across order and worker count.

Treat any successful command as proof that all business and access rules passed.

Reference: Results remain consistent across order and worker count. — Use API setup for state when the test is about UI behavior, but test the API itself separately. Fixtures should not depend on execution order or shared mutable records. Results remain consistent across order and worker count.

Sources:

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Risk-based release: Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery.

Apply risk-based release in Test Automation / SDET: Use the concept to complete this role exercise: Design isolated fixtures and collect traces for a failing CI run

Failure diagnostics in CI: A failing CI test should preserve enough evidence to distinguish product, test and environment failures. Retries are diagnostic signals, not a way to erase instability.

### Risk-based release

Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery. In this role, work through: A missing server and a wrong button label should produce different diagnostics. The practical workshop develops this into: Add CI setup, server readiness check and Playwright trace retention on failure. Deliberately break a locator, inspect the trace, repair it and document artifact retention.

Mental model: Inspect brakes before polishing the paint.

Boundary: Risk ranking is judgment informed by users, not an excuse to skip known defects.

Role application: A flight recorder makes the failed journey inspectable after landing.

A failing CI test should preserve enough evidence to distinguish product, test and environment failures. Retries are diagnostic signals, not a way to erase instability.

Worked example: A missing server and a wrong button label should produce different diagnostics.

Shared foundation example: Test invalid input, double submission, keyboard focus and server restart; record results.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Playwright (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Test Automation / SDET: A missing server and a wrong button label should produce different diagnostics.

Predict the worked case

Read this case without running a tool: A missing server and a wrong button label should produce different diagnostics. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in risk-based release.

Connect the concept to the role

Apply this rule: Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Risk ranking is judgment informed by users, not an excuse to skip known defects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies risk-based release to this case: A missing server and a wrong button label should produce different diagnostics. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A missing server and a wrong button label should produce different diagnostics. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Risk-based release; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with risk-based release. Use the glossary below, then write your prediction for: A missing server and a wrong button label should produce different diagnostics. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Test Automation / SDET role interview. Explain risk-based release using this case: A missing server and a wrong button label should produce different diagnostics. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate risk-based release to a system or workflow you know. Explain risk-based release using this case: A missing server and a wrong button label should produce different diagnostics. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What evidence would make you hold a release despite a high pass count?

Interview: Explain risk-based release using this case: A missing server and a wrong button label should produce different diagnostics. State the evidence, one alternative and where the mental model stops.

Quiz: After the Failure diagnostics in CI rehearsal, check this foundation: Happy-path tests pass, but a plausible high-impact failure is untested. What is a defensible next step?

Declare zero release risk because automated checks passed.

Remove the uncertain case from the report.

Assess its impact, test or mitigate it, and record residual risk for the release owner.

Reference: Assess its impact, test or mitigate it, and record residual risk for the release owner. — Risk-based testing prioritizes harmful plausible failures; passing a limited suite is not proof of complete coverage.

Sources:

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs

### Failure diagnostics in CI

A failing CI test should preserve enough evidence to distinguish product, test and environment failures. Retries are diagnostic signals, not a way to erase instability. In this role, work through: A missing server and a wrong button label should produce different diagnostics. The practical workshop develops this into: Add CI setup, server readiness check and Playwright trace retention on failure. Deliberately break a locator, inspect the trace, repair it and document artifact retention.

Mental model: A flight recorder makes the failed journey inspectable after landing.

Boundary: A test that passes only on retry remains a stability issue to investigate.

Worked example: A missing server and a wrong button label should produce different diagnostics.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Playwright (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Test Automation / SDET workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add CI setup, server readiness check and Playwright trace retention on failure. Deliberately break a locator, inspect the trace, repair it and document artifact retention.

Read the rule

Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.

Expected: Trimmed title succeeds; blank and overlong titles are rejected.

Run focused checks

Run the supplied checks before editing.

```
node app.mjs test advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: PASS web advanced

Use the browser

Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.

```
node app.mjs
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

Role workshop · predict

A missing server and a wrong button label should produce different diagnostics. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add CI setup, server readiness check and Playwright trace retention on failure. Deliberately break a locator, inspect the trace, repair it and document artifact retention.

Expected: The pipeline fails visibly and retains the relevant trace; clean run then passes.

Role workshop · debug and verify

A test that passes only on retry remains a stability issue to investigate. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save CI workflow, trace analysis and flaky-test policy. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The pipeline fails visibly and retains the relevant trace; clean run then passes.

Expected: The pipeline fails visibly and retains the relevant trace; clean run then passes.

Troubleshoot: The role exercise differs from the prediction: A test that passes only on retry remains a stability issue to investigate.

Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Deliverable: lesson-advanced-2.md: CI workflow, trace analysis and flaky-test policy; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure diagnostics in ci. Use the glossary below, then write your prediction for: A missing server and a wrong button label should produce different diagnostics. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Test Automation / SDET role interview. Explain failure diagnostics in ci using this case: A missing server and a wrong button label should produce different diagnostics. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure diagnostics in ci to a system or workflow you know. Explain failure diagnostics in ci using this case: A missing server and a wrong button label should produce different diagnostics. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A test that passes only on retry remains a stability issue to investigate.

Interview: Explain failure diagnostics in ci using this case: A missing server and a wrong button label should produce different diagnostics. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A missing server and a wrong button label should produce different diagnostics.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

The pipeline fails visibly and retains the relevant trace; clean run then passes.

Reference: The pipeline fails visibly and retains the relevant trace; clean run then passes. — A failing CI test should preserve enough evidence to distinguish product, test and environment failures. Retries are diagnostic signals, not a way to erase instability. The pipeline fails visibly and retains the relevant trace; clean run then passes.

Sources:

Playwright: installation and first tests: https://playwright.dev/docs/intro

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
