# Self-service AI service template

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Create a repeatable developer path from service request to a tested local deployment.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

## Limitations and next iteration
Add template version migration and show how existing services receive a security fix without overwriting team code.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
