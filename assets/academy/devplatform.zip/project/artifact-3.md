# Developer quickstart and support runbook

Project: Self-service AI service template
Status: blank work product — not completed evidence

## Purpose and audience
Create a repeatable developer path from service request to a tested local deployment.

## Required content
Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.

## Failure evidence
Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
