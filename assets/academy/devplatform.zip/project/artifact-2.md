# Portal walkthrough and policy checks

Project: Self-service AI service template
Status: blank work product — not completed evidence

## Purpose and audience
Create a repeatable developer path from service request to a tested local deployment.

## Required content
Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.

## Failure evidence
Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
