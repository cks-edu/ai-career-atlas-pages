# Self-service AI service template

Career: AI developer-platform / research-productivity engineer
Reviewed: 2026-10-22

Create a repeatable developer path from service request to a tested local deployment.

## Prerequisites
Learn application delivery, CI/CD, API design, documentation and platform operations. Senior work includes product discovery, compatibility management and facilitating adoption across teams.

## Included starter versus your implementation
A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context.

```sh
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Package the provided Kubernetes starter as a repository template with named inputs. Generate manifests without embedding secrets and validate required ownership metadata.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

## Portfolio deliverables
1. Template repository and CI pipeline — artifact-1.md
2. Portal walkthrough and policy checks — artifact-2.md
3. Developer quickstart and support runbook — artifact-3.md

## Troubleshooting
- ImagePullBackOff: inspect kubectl describe pod and image availability.
- Pending: inspect resource requests and node capacity.
- NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.

## Extension
Add template version migration and show how existing services receive a security fix without overwriting team code.

## Primary learning resources
- Backstage: https://backstage.io/docs/features/software-templates/ — Open source; Developer onboarding and software templates.
- GitHub Actions: https://docs.github.com/en/actions — Commercial hosted service · usage limits; CI checks and reviewable build artifacts; paid usage may apply.
- kind: https://kind.sigs.k8s.io/docs/user/quick-start/ — Open source · local containers; Disposable Kubernetes cluster; requires a compatible container runtime.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
