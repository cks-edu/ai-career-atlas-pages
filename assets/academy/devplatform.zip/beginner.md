## beginner — Developer journey measurement

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Developer journey measurement
Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads.
Mental model: A trail is useful when walkers reach the destination, not when they collect maps.
Boundary: A single experienced developer is not representative of every newcomer.
Worked example: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Templates create ownerless services
Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Three scaffolded services lack required ownership evidence. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate service metadata during template generation and provide a clear repair path.
Recall: A complete template succeeds; incomplete metadata blocks publication with actionable errors. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Developer journey measurement: Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A developer platform should remove a specific obstacle. Improve the onboarding task before deciding to build a portal.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Review these instructions: “Install tools. Get credentials. Run the app.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A revised setup checklist with visible unknowns.

3. Try step 2
Rewrite them to name the required version, where approved access comes from, the command to run and what success would look like; use placeholders for unknown project details.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A revised setup checklist with visible unknowns.

4. Try step 3
List three questions that must be answered before another person can follow the guide.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A revised setup checklist with visible unknowns.

5. Explain and check your result
You do not invent credentials or missing commands; each unknown has a clear question and owner. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A revised setup checklist with visible unknowns. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Apply this toy-case rule manually: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three scaffolded services lack required ownership evidence. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI developer-platform / research-productivity engineer.
Review these instructions: “Install tools. Get credentials. Run the app.”
Rewrite them to name the required version, where approved access comes from, the command to run and what success would look like; use placeholders for unknown project details.
List three questions that must be answered before another person can follow the guide.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A revised setup checklist with visible unknowns. Include beginner-worksheet.md and your completed Service template acceptance report.
Check: You do not invent credentials or missing commands; each unknown has a clear question and owner.

### Interview
Explain your beginner solution for AI developer-platform / research-productivity engineer. Use this scenario: Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields.
Review: Start with the task and permitted scope. Explain developer journey measurement: Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads. Show the input and observed output, then address Validate service metadata during template generation and provide a clear repair path. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A revised setup checklist with visible unknowns. Include beginner-worksheet.md and your completed Service template acceptance report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

