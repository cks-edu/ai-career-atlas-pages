## advanced — Template change safety

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Template change safety
Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories.
Mental model: Updating a house blueprint does not automatically renovate existing houses.
Boundary: Automated updates still require compatibility and behavior checks.
Worked example: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Self-service AI service template
Create a repeatable developer path from service request to a tested local deployment. Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.
Recall: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. Identify one observation that would contradict your claim.

### Terms
Template change safety: Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Create a repeatable developer path from service request to a tested local deployment. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Package the provided Kubernetes starter as a repository template with named inputs. Generate manifests without embedding secrets and validate required ownership metadata.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Create a repeatable developer path from service request to a tested local deployment.
Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.
Package the provided Kubernetes starter as a repository template with named inputs. Generate manifests without embedding secrets and validate required ownership metadata.
Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.
Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced.
Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.
Add template version migration and show how existing services receive a security fix without overwriting team code.
Deliverables: Template repository and CI pipeline; Portal walkthrough and policy checks; Developer quickstart and support runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. A reviewer must reproduce one result and identify which capabilities you implemented. Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

### Interview
Explain your advanced solution for AI developer-platform / research-productivity engineer. Use this scenario: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.
Review: Start with the task and permitted scope. Explain template change safety: Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories. Show the input and observed output, then address Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Template repository and CI pipeline; Portal walkthrough and policy checks; Developer quickstart and support runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

