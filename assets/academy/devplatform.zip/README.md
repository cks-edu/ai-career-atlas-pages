# AI developer-platform / research-productivity engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Developer journey measurement. A developer platform should remove a specific obstacle. Improve the onboarding task before deciding to build a portal. Then try Review a fictional setup guide. The three levels build toward Self-service AI service template. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Developer journey measurement

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Developer journey measurement
Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads.
Mental model: A trail is useful when walkers reach the destination, not when they collect maps.
Boundary: A single experienced developer is not representative of every newcomer.
Worked example: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Templates create ownerless services
Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Three scaffolded services lack required ownership evidence. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate service metadata during template generation and provide a clear repair path.
Recall: A complete template succeeds; incomplete metadata blocks publication with actionable errors. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Developer journey measurement: Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A developer platform should remove a specific obstacle. Improve the onboarding task before deciding to build a portal.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Review these instructions: “Install tools. Get credentials. Run the app.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A revised setup checklist with visible unknowns.

3. Try step 2
Rewrite them to name the required version, where approved access comes from, the command to run and what success would look like; use placeholders for unknown project details.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A revised setup checklist with visible unknowns.

4. Try step 3
List three questions that must be answered before another person can follow the guide.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A revised setup checklist with visible unknowns.

5. Explain and check your result
You do not invent credentials or missing commands; each unknown has a clear question and owner. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A revised setup checklist with visible unknowns. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Apply this toy-case rule manually: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three scaffolded services lack required ownership evidence. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI developer-platform / research-productivity engineer.
Review these instructions: “Install tools. Get credentials. Run the app.”
Rewrite them to name the required version, where approved access comes from, the command to run and what success would look like; use placeholders for unknown project details.
List three questions that must be answered before another person can follow the guide.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A revised setup checklist with visible unknowns. Include beginner-worksheet.md and your completed Service template acceptance report.
Check: You do not invent credentials or missing commands; each unknown has a clear question and owner.

### Interview
Explain your beginner solution for AI developer-platform / research-productivity engineer. Use this scenario: Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields.
Review: Start with the task and permitted scope. Explain developer journey measurement: Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads. Show the input and observed output, then address Validate service metadata during template generation and provide a clear repair path. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A revised setup checklist with visible unknowns. Include beginner-worksheet.md and your completed Service template acceptance report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Golden paths and escape hatches

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn application delivery, CI/CD, API design, documentation and platform operations. Senior work includes product discovery, compatibility management and facilitating adoption across teams.

### Golden paths and escape hatches
Provide a supported default that solves common needs while documenting its constraints and how teams request exceptions. Avoid hiding configuration people must understand.
Mental model: A marked hiking route offers guidance but also explains conditions and alternatives.
Boundary: A golden path should not promise support for untested combinations.
Worked example: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Self-service AI service template
Create a repeatable developer path from service request to a tested local deployment. Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.
Recall: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. Identify one observation that would contradict your claim.

### Terms
Golden paths and escape hatches: Provide a supported default that solves common needs while documenting its constraints and how teams request exceptions. Avoid hiding configuration people must understand.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Create a repeatable developer path from service request to a tested local deployment. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Package the provided Kubernetes starter as a repository template with named inputs. Generate manifests without embedding secrets and validate required ownership metadata.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Create a repeatable developer path from service request to a tested local deployment.
Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.
Package the provided Kubernetes starter as a repository template with named inputs. Generate manifests without embedding secrets and validate required ownership metadata.
Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.
Deliverables: Template repository and CI pipeline; Portal walkthrough and policy checks. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI developer-platform / research-productivity engineer. Use this scenario: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.
Review: Start with the task and permitted scope. Explain golden paths and escape hatches: Provide a supported default that solves common needs while documenting its constraints and how teams request exceptions. Avoid hiding configuration people must understand. Show the input and observed output, then address Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Template repository and CI pipeline; Portal walkthrough and policy checks. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Template change safety

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Template change safety
Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories.
Mental model: Updating a house blueprint does not automatically renovate existing houses.
Boundary: Automated updates still require compatibility and behavior checks.
Worked example: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Self-service AI service template
Create a repeatable developer path from service request to a tested local deployment. Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.
Recall: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. Identify one observation that would contradict your claim.

### Terms
Template change safety: Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Create a repeatable developer path from service request to a tested local deployment. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Package the provided Kubernetes starter as a repository template with named inputs. Generate manifests without embedding secrets and validate required ownership metadata.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Create a repeatable developer path from service request to a tested local deployment.
Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.
Package the provided Kubernetes starter as a repository template with named inputs. Generate manifests without embedding secrets and validate required ownership metadata.
Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.
Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced.
Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.
Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.
Add template version migration and show how existing services receive a security fix without overwriting team code.
Deliverables: Template repository and CI pipeline; Portal walkthrough and policy checks; Developer quickstart and support runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. A reviewer must reproduce one result and identify which capabilities you implemented. Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

### Interview
Explain your advanced solution for AI developer-platform / research-productivity engineer. Use this scenario: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.
Review: Start with the task and permitted scope. Explain template change safety: Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories. Show the input and observed output, then address Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Template repository and CI pipeline; Portal walkthrough and policy checks; Developer quickstart and support runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Backstage — Open source
Developer onboarding and software templates.
Alternative: A small repository of service templates and ownership metadata can be enough initially; commercial internal portals add hosted features.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

GitHub Actions — Commercial hosted service · usage limits
CI checks and reviewable build artifacts; paid usage may apply.
Alternative: GitLab CI (open-core/commercial offerings) or Jenkins (open source); runners and compute still need operating resources.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

kind — Open source · local containers
Disposable Kubernetes cluster; requires a compatible container runtime.
Alternative: minikube (open source); managed Kubernetes is a separate commercial hosting choice, not required for a first lab.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Backstage: https://backstage.io/docs/features/software-templates/
GitHub Actions: https://docs.github.com/en/actions
kind: https://kind.sigs.k8s.io/docs/user/quick-start/
Backstage: https://backstage.io/docs/overview/what-is-backstage/
GitHub Actions: https://docs.github.com/en/actions
Kubernetes: https://kubernetes.io/docs/tutorials/
