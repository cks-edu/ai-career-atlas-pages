# AI developer-platform / research-productivity engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Developer journey measurement: Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Developer journey measurement

Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads. In this role, work through: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A trail is useful when walkers reach the destination, not when they collect maps.

Boundary: A single experienced developer is not representative of every newcomer.

Worked example: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Backstage (Open source); GitHub Actions (Commercial hosted service · usage limits); kind (Open source · local containers)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI developer-platform / research-productivity engineer: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task.

Predict the worked case

Read this case without running a tool: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in developer journey measurement.

Connect the concept to the role

Apply this rule: Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A single experienced developer is not representative of every newcomer.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies developer journey measurement to this case: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Developer journey measurement; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with developer journey measurement. Use the glossary below, then write your prediction for: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-platform / research-productivity engineer role interview. Explain developer journey measurement using this case: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate developer journey measurement to a system or workflow you know. Explain developer journey measurement using this case: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain developer journey measurement using this case: A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task.

Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads. — Observe the steps from a new repository to a working service. Identify repeated friction and measure time to a verified outcome rather than template downloads. A single experienced developer is not representative of every newcomer.

Sources:

Backstage: https://backstage.io/docs/features/software-templates/

GitHub Actions: https://docs.github.com/en/actions

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Backstage: https://backstage.io/docs/overview/what-is-backstage/

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

### Diagnose: Templates create ownerless services

Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Three scaffolded services lack required ownership evidence. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate service metadata during template generation and provide a clear repair path. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A trail is useful when walkers reach the destination, not when they collect maps.

A developer creates a service but cannot find logs. Include log discovery and a health check in the onboarding task.

Worked example: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate service metadata during template generation and provide a clear repair path.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Backstage (Open source); GitHub Actions (Commercial hosted service · usage limits); kind (Open source · local containers)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Three scaffolded services lack required ownership evidence. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Apply this toy-case rule manually: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A developer platform should remove a specific obstacle. Improve the onboarding task before deciding to build a portal.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Review these instructions: “Install tools. Get credentials. Run the app.”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A revised setup checklist with visible unknowns.

Preparation · Try step 2

Rewrite them to name the required version, where approved access comes from, the command to run and what success would look like; use placeholders for unknown project details.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A revised setup checklist with visible unknowns.

Preparation · Try step 3

List three questions that must be answered before another person can follow the guide.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A revised setup checklist with visible unknowns.

Preparation · Explain and check your result

You do not invent credentials or missing commands; each unknown has a clear question and owner. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A revised setup checklist with visible unknowns. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Apply this toy-case rule manually: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three scaffolded services lack required ownership evidence. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three scaffolded services lack required ownership evidence. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: templates create ownerless services. Use the glossary below, then write your prediction for: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate service metadata during template generation and provide a clear repair path. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-platform / research-productivity engineer role interview. Explain diagnose: templates create ownerless services using this case: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate service metadata during template generation and provide a clear repair path. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: templates create ownerless services to a system or workflow you know. Explain diagnose: templates create ownerless services using this case: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate service metadata during template generation and provide a clear repair path. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: A complete template succeeds; incomplete metadata blocks publication with actionable errors. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: templates create ownerless services using this case: Review when missing_service_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Validate service metadata during template generation and provide a clear repair path. State the evidence, one alternative and where the mental model stops.

Quiz: Templates create ownerless services: Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields.

Change the acceptance rule after seeing an inconvenient result.

Validate service metadata during template generation and provide a clear repair path.

Omit failed cases and report only the successful demonstrations.

Reference: Validate service metadata during template generation and provide a clear repair path. — Validate service metadata during template generation and provide a clear repair path. A complete template succeeds; incomplete metadata blocks publication with actionable errors.

Sources:

Backstage: https://backstage.io/docs/features/software-templates/

GitHub Actions: https://docs.github.com/en/actions

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Backstage: https://backstage.io/docs/overview/what-is-backstage/

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn application delivery, CI/CD, API design, documentation and platform operations. Senior work includes product discovery, compatibility management and facilitating adoption across teams.

Terms:

Golden paths and escape hatches: Provide a supported default that solves common needs while documenting its constraints and how teams request exceptions. Avoid hiding configuration people must understand.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

Pod: A Kubernetes unit containing one or more containers scheduled together.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Golden paths and escape hatches

Provide a supported default that solves common needs while documenting its constraints and how teams request exceptions. Avoid hiding configuration people must understand. In this role, work through: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A marked hiking route offers guidance but also explains conditions and alternatives.

Boundary: A golden path should not promise support for untested combinations.

Worked example: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Learn application delivery, CI/CD, API design, documentation and platform operations. Senior work includes product discovery, compatibility management and facilitating adoption across teams.

Tools for this exercise: Document or text editor

Course tool and framework map: Backstage (Open source); GitHub Actions (Commercial hosted service · usage limits); kind (Open source · local containers)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI developer-platform / research-productivity engineer: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path.

Predict the worked case

Read this case without running a tool: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in golden paths and escape hatches.

Connect the concept to the role

Apply this rule: Provide a supported default that solves common needs while documenting its constraints and how teams request exceptions. Avoid hiding configuration people must understand. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A golden path should not promise support for untested combinations.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies golden paths and escape hatches to this case: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Golden paths and escape hatches; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with golden paths and escape hatches. Use the glossary below, then write your prediction for: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-platform / research-productivity engineer role interview. Explain golden paths and escape hatches using this case: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate golden paths and escape hatches to a system or workflow you know. Explain golden paths and escape hatches using this case: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain golden paths and escape hatches using this case: A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path.

Treat a passing starter as proof of the whole role workflow.

Provide a supported default that solves common needs while documenting its constraints and how teams request exceptions. Avoid hiding configuration people must understand.

Ignore the failure because the tool produced an output.

Reference: Provide a supported default that solves common needs while documenting its constraints and how teams request exceptions. Avoid hiding configuration people must understand. — Provide a supported default that solves common needs while documenting its constraints and how teams request exceptions. Avoid hiding configuration people must understand. A golden path should not promise support for untested combinations.

Sources:

Backstage: https://backstage.io/docs/features/software-templates/

GitHub Actions: https://docs.github.com/en/actions

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Backstage: https://backstage.io/docs/overview/what-is-backstage/

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

### Integrate: Self-service AI service template

Create a repeatable developer path from service request to a tested local deployment. Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions. In this role, work through: Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Role application: A marked hiking route offers guidance but also explains conditions and alternatives.

A template provides CI, health checks and ownership metadata; an unusual GPU workload follows an explicit review path.

Worked example: Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.

Setup: Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Backstage (Open source); GitHub Actions (Commercial hosted service · usage limits); kind (Open source · local containers)

Create a repeatable developer path from service request to a tested local deployment. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Create a repeatable developer path from service request to a tested local deployment.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Prepare the project inputs

Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Package the provided Kubernetes starter as a repository template with named inputs. Generate manifests without embedding secrets and validate required ownership metadata.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Deliverable: lesson-intermediate-2.md: Template repository and CI pipeline; Portal walkthrough and policy checks. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: self-service ai service template. Use the glossary below, then write your prediction for: Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-platform / research-productivity engineer role interview. Explain integrate: self-service ai service template using this case: Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: self-service ai service template to a system or workflow you know. Explain integrate: self-service ai service template using this case: Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. Identify one observation that would contradict your claim.

Interview: Explain integrate: self-service ai service template using this case: Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Self-service AI service template at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.

Reference: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. — Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.

Sources:

Backstage: https://backstage.io/docs/features/software-templates/

GitHub Actions: https://docs.github.com/en/actions

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Backstage: https://backstage.io/docs/overview/what-is-backstage/

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Template change safety: Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

Pod: A Kubernetes unit containing one or more containers scheduled together.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Template change safety

Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories. In this role, work through: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Updating a house blueprint does not automatically renovate existing houses.

Boundary: Automated updates still require compatibility and behavior checks.

Worked example: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Backstage (Open source); GitHub Actions (Commercial hosted service · usage limits); kind (Open source · local containers)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI developer-platform / research-productivity engineer: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix.

Predict the worked case

Read this case without running a tool: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in template change safety.

Connect the concept to the role

Apply this rule: Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Automated updates still require compatibility and behavior checks.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies template change safety to this case: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Template change safety; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with template change safety. Use the glossary below, then write your prediction for: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-platform / research-productivity engineer role interview. Explain template change safety using this case: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate template change safety to a system or workflow you know. Explain template change safety using this case: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain template change safety using this case: Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories.

Reference: Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories. — Version templates, test generated projects and document migration steps. Distinguish changes to future scaffolds from updates required in already-created repositories. Automated updates still require compatibility and behavior checks.

Sources:

Backstage: https://backstage.io/docs/features/software-templates/

GitHub Actions: https://docs.github.com/en/actions

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Backstage: https://backstage.io/docs/overview/what-is-backstage/

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/

### Defend: Self-service AI service template

Create a repeatable developer path from service request to a tested local deployment. Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced. In this role, work through: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Role application: Updating a house blueprint does not automatically renovate existing houses.

Template v3 fixes a dependency; scan generated services and offer a tested upgrade instead of assuming they inherited the fix.

Worked example: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

Setup: Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Backstage (Open source); GitHub Actions (Commercial hosted service · usage limits); kind (Open source · local containers)

Create a repeatable developer path from service request to a tested local deployment. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Create a repeatable developer path from service request to a tested local deployment.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Prepare the project inputs

Define two fictional teams and a minimal service contract: owner, repository, data class, runtime, limits and runbook.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Package the provided Kubernetes starter as a repository template with named inputs. Generate manifests without embedding secrets and validate required ownership metadata.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a GitHub Actions workflow for tests and manifest checks. Pin third-party actions to reviewed commit digests in the final portfolio and declare minimal workflow permissions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Use Backstage software templates or a local form prototype to collect inputs and generate the repository. Document where identity, secrets and policy approval must be enforced.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. A reviewer must reproduce one result and identify which capabilities you implemented. Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Deliverable: lesson-advanced-2.md: Template repository and CI pipeline; Portal walkthrough and policy checks; Developer quickstart and support runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: self-service ai service template. Use the glossary below, then write your prediction for: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI developer-platform / research-productivity engineer role interview. Explain defend: self-service ai service template using this case: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: self-service ai service template to a system or workflow you know. Explain defend: self-service ai service template using this case: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer. Identify one observation that would contradict your claim.

Interview: Explain defend: self-service ai service template using this case: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Self-service AI service template at this level?

Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation. — Request a service without an owner and with an excessive resource limit. Reject both before deployment; demonstrate a failed rollout and the developer-facing explanation. Measure setup steps, time to first successful deployment, failure clarity and template reproducibility with a second reviewer.

Sources:

Backstage: https://backstage.io/docs/features/software-templates/

GitHub Actions: https://docs.github.com/en/actions

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Backstage: https://backstage.io/docs/overview/what-is-backstage/

GitHub Actions: https://docs.github.com/en/actions

Kubernetes: https://kubernetes.io/docs/tutorials/
