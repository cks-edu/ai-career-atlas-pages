# SAMPLE — Service template acceptance report
Role: AI developer-platform / research-productivity engineer
Case: Templates create ownerless services
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
Every generated service must declare an owner, runbook and lifecycle policy. Count missing fields.

## Evidence table
| Record | missing_service_fields (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three scaffolded services lack required ownership evidence.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Validate service metadata during template generation and provide a clear repair path.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai developer-platform / research-productivity engineer.
Before release: A complete template succeeds; incomplete metadata blocks publication with actionable errors.

## Design choice and trade-off
Combine self-service defaults with tested contracts; retain an accountable owner for template changes.
Too many gates slow onboarding; require evidence that reduces concrete operational risk.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Generate a tested golden-path project: A fresh folder can run the generated app and its tests. Existing work cannot be silently overwritten. The service contract accurately states ownership and scope.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
