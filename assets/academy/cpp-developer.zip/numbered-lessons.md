# C / C++ Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

State machines: A state machine defines allowed states and how events change them.

Apply state machines in C / C++ Developer: Use the concept to complete this role exercise: Compile the sensor simulation and trace each array access

Array bounds and explicit states: C arrays do not check every index for you. Keep length alongside data, use explicit state values and validate sensor input before using it to choose an actuator state.

### State machines

A state machine defines allowed states and how events change them. In this role, work through: Four readings have indices 0 through 3; index 4 is outside the array. The practical workshop develops this into: Compile sensor.c with warnings enabled. Trace each reading and state. Add exact threshold readings and a sentinel invalid reading with a documented safe state rather than accessing another array element.

Mental model: Traffic lights change according to explicit rules.

Boundary: Real timing, interrupts and hardware noise require additional engineering.

Role application: Numbered lockers have a first and last valid slot; an invalid number is not another locker.

C arrays do not check every index for you. Keep length alongside data, use explicit state values and validate sensor input before using it to choose an actuator state.

Worked example: Four readings have indices 0 through 3; index 4 is outside the array.

Shared foundation example: A fan turns on at 30, stays on at 28 and turns off at 25.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Clang or GCC (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for C / C++ Developer: Four readings have indices 0 through 3; index 4 is outside the array.

Predict the worked case

Read this case without running a tool: Four readings have indices 0 through 3; index 4 is outside the array. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state machines.

Connect the concept to the role

Apply this rule: A state machine defines allowed states and how events change them. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Real timing, interrupts and hardware noise require additional engineering.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state machines to this case: Four readings have indices 0 through 3; index 4 is outside the array. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Four readings have indices 0 through 3; index 4 is outside the array. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for State machines; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state machines. Use the glossary below, then write your prediction for: Four readings have indices 0 through 3; index 4 is outside the array. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C / C++ Developer role interview. Explain state machines using this case: Four readings have indices 0 through 3; index 4 is outside the array. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state machines to a system or workflow you know. Explain state machines using this case: Four readings have indices 0 through 3; index 4 is outside the array. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What state would you use when a sensor reading is unavailable?

Interview: Explain state machines using this case: Four readings have indices 0 through 3; index 4 is outside the array. State the evidence, one alternative and where the mental model stops.

Quiz: After the Array bounds and explicit states rehearsal, check this foundation: An event is valid only in one workflow state. How should it be handled in another state?

Apply the declared transition policy, including rejection or no-op where defined.

Always jump to the final state to complete the flow.

Ignore the current state and repeat the last action.

Reference: Apply the declared transition policy, including rejection or no-op where defined. — A transition depends on the current state and event, not only the event name.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

### Array bounds and explicit states

C arrays do not check every index for you. Keep length alongside data, use explicit state values and validate sensor input before using it to choose an actuator state. In this role, work through: Four readings have indices 0 through 3; index 4 is outside the array. The practical workshop develops this into: Compile sensor.c with warnings enabled. Trace each reading and state. Add exact threshold readings and a sentinel invalid reading with a documented safe state rather than accessing another array element.

Mental model: Numbered lockers have a first and last valid slot; an invalid number is not another locker.

Boundary: Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length.

Worked example: Four readings have indices 0 through 3; index 4 is outside the array.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Clang or GCC (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required C / C++ Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Compile sensor.c with warnings enabled. Trace each reading and state. Add exact threshold readings and a sentinel invalid reading with a documented safe state rather than accessing another array element.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

Four readings have indices 0 through 3; index 4 is outside the array. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Compile sensor.c with warnings enabled. Trace each reading and state. Add exact threshold readings and a sentinel invalid reading with a documented safe state rather than accessing another array element.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: All reads stay in bounds; the invalid reading produces the chosen fault state.

Role workshop · debug and verify

Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save transition table and annotated C source. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: All reads stay in bounds; the invalid reading produces the chosen fault state.

Expected: All reads stay in bounds; the invalid reading produces the chosen fault state.

Troubleshoot: The role exercise differs from the prediction: Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: transition table and annotated C source; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with array bounds and explicit states. Use the glossary below, then write your prediction for: Four readings have indices 0 through 3; index 4 is outside the array. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C / C++ Developer role interview. Explain array bounds and explicit states using this case: Four readings have indices 0 through 3; index 4 is outside the array. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate array bounds and explicit states to a system or workflow you know. Explain array bounds and explicit states using this case: Four readings have indices 0 through 3; index 4 is outside the array. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length.

Interview: Explain array bounds and explicit states using this case: Four readings have indices 0 through 3; index 4 is outside the array. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Four readings have indices 0 through 3; index 4 is outside the array.

All reads stay in bounds; the invalid reading produces the chosen fault state.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: All reads stay in bounds; the invalid reading produces the chosen fault state. — C arrays do not check every index for you. Keep length alongside data, use explicit state values and validate sensor input before using it to choose an actuator state. All reads stay in bounds; the invalid reading produces the chosen fault state.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Memory and ownership: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.

Apply memory and ownership in C / C++ Developer: Use the concept to complete this role exercise: Add a missing-reading state without using an invalid array index

Resource lifetime: A resource has one ownership policy and must be released on every exit path. In C++ use RAII where appropriate; in C design cleanup paths explicitly rather than relying on the happy path.

### Memory and ownership

Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. In this role, work through: Opening a missing input file must not lead to reading a null file handle. The practical workshop develops this into: Extend the host simulation to read a small text fixture. Check fopen/ifstream failure, parse each reading, close the resource and report invalid lines. Test an absent file and malformed text.

Mental model: A borrowed library book must not be used after it is returned.

Boundary: Languages enforce different parts of this discipline; concurrency adds other hazards.

Role application: The person who checks out equipment is responsible for returning it even if the event is canceled.

A resource has one ownership policy and must be released on every exit path. In C++ use RAII where appropriate; in C design cleanup paths explicitly rather than relying on the happy path.

Worked example: Opening a missing input file must not lead to reading a null file handle.

Shared foundation example: A fixed array of four readings is traversed with indices zero through three.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Clang or GCC (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for C / C++ Developer: Opening a missing input file must not lead to reading a null file handle.

Predict the worked case

Read this case without running a tool: Opening a missing input file must not lead to reading a null file handle. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in memory and ownership.

Connect the concept to the role

Apply this rule: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Languages enforce different parts of this discipline; concurrency adds other hazards.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies memory and ownership to this case: Opening a missing input file must not lead to reading a null file handle. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Opening a missing input file must not lead to reading a null file handle. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Memory and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with memory and ownership. Use the glossary below, then write your prediction for: Opening a missing input file must not lead to reading a null file handle. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C / C++ Developer role interview. Explain memory and ownership using this case: Opening a missing input file must not lead to reading a null file handle. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate memory and ownership to a system or workflow you know. Explain memory and ownership using this case: Opening a missing input file must not lead to reading a null file handle. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is index four invalid in a four-element array?

Interview: Explain memory and ownership using this case: Opening a missing input file must not lead to reading a null file handle. State the evidence, one alternative and where the mental model stops.

Quiz: After the Resource lifetime rehearsal, check this foundation: A buffer has capacity four and zero-based indices. Which index range is valid?

1 through 4 inclusive.

0 through 3 inclusive.

0 through 4 inclusive.

Reference: 0 through 3 inclusive. — Capacity is the number of elements; the last valid zero-based index is capacity minus one. Lifetime checks are separate.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

### Resource lifetime

A resource has one ownership policy and must be released on every exit path. In C++ use RAII where appropriate; in C design cleanup paths explicitly rather than relying on the happy path. In this role, work through: Opening a missing input file must not lead to reading a null file handle. The practical workshop develops this into: Extend the host simulation to read a small text fixture. Check fopen/ifstream failure, parse each reading, close the resource and report invalid lines. Test an absent file and malformed text.

Mental model: The person who checks out equipment is responsible for returning it even if the event is canceled.

Boundary: A crash only on a missing file usually points to an unchecked open result.

Worked example: Opening a missing input file must not lead to reading a null file handle.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Clang or GCC (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required C / C++ Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Extend the host simulation to read a small text fixture. Check fopen/ifstream failure, parse each reading, close the resource and report invalid lines. Test an absent file and malformed text.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

Opening a missing input file must not lead to reading a null file handle. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Extend the host simulation to read a small text fixture. Check fopen/ifstream failure, parse each reading, close the resource and report invalid lines. Test an absent file and malformed text.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Both failures are controlled; no leaked handle or use after close in the exercised paths.

Role workshop · debug and verify

A crash only on a missing file usually points to an unchecked open result. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save file-input implementation and error-path tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Both failures are controlled; no leaked handle or use after close in the exercised paths.

Expected: Both failures are controlled; no leaked handle or use after close in the exercised paths.

Troubleshoot: The role exercise differs from the prediction: A crash only on a missing file usually points to an unchecked open result.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: file-input implementation and error-path tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with resource lifetime. Use the glossary below, then write your prediction for: Opening a missing input file must not lead to reading a null file handle. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C / C++ Developer role interview. Explain resource lifetime using this case: Opening a missing input file must not lead to reading a null file handle. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate resource lifetime to a system or workflow you know. Explain resource lifetime using this case: Opening a missing input file must not lead to reading a null file handle. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A crash only on a missing file usually points to an unchecked open result.

Interview: Explain resource lifetime using this case: Opening a missing input file must not lead to reading a null file handle. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Opening a missing input file must not lead to reading a null file handle.

Ignore the failing case and keep only the successful screenshot.

Both failures are controlled; no leaked handle or use after close in the exercised paths.

Treat any successful command as proof that all business and access rules passed.

Reference: Both failures are controlled; no leaked handle or use after close in the exercised paths. — A resource has one ownership policy and must be released on every exit path. In C++ use RAII where appropriate; in C design cleanup paths explicitly rather than relying on the happy path. Both failures are controlled; no leaked handle or use after close in the exercised paths.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Determinism and timing: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.

Apply determinism and timing in C / C++ Developer: Use the concept to complete this role exercise: Run sanitizer-enabled checks and document remaining concurrency risks

Sanitizers and undefined behavior: Compiler sanitizers instrument certain invalid operations at runtime. They complement warnings and tests but cannot prove unexecuted paths or real-time hardware behavior.

### Determinism and timing

A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. In this role, work through: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. The practical workshop develops this into: Compile the host exercise with -fsanitize=address,undefined -g and run boundary fixtures. Introduce one out-of-bounds access in a scratch copy, capture the diagnostic, then repair it and rerun cleanly.

Mental model: A rehearsal follows a script; a live performance adds timing constraints.

Boundary: A host simulation does not validate hardware or real-time deadlines.

Role application: A rehearsal safety inspector watches the paths you actually walk.

Compiler sanitizers instrument certain invalid operations at runtime. They complement warnings and tests but cannot prove unexecuted paths or real-time hardware behavior.

Worked example: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer.

Shared foundation example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Clang or GCC (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for C / C++ Developer: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer.

Predict the worked case

Read this case without running a tool: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in determinism and timing.

Connect the concept to the role

Apply this rule: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A host simulation does not validate hardware or real-time deadlines.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies determinism and timing to this case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Determinism and timing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with determinism and timing. Use the glossary below, then write your prediction for: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C / C++ Developer role interview. Explain determinism and timing using this case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate determinism and timing to a system or workflow you know. Explain determinism and timing using this case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What measurements would be required on actual hardware?

Interview: Explain determinism and timing using this case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. State the evidence, one alternative and where the mental model stops.

Quiz: After the Sanitizers and undefined behavior rehearsal, check this foundation: A replay produces the expected output every time. What is still needed for a real-time deadline claim?

No further evidence if results are deterministic.

Only a larger input file.

Measured timing under the intended resource and load conditions.

Reference: Measured timing under the intended resource and load conditions. — Repeatable results do not establish latency or worst-case timing on the target system.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

### Sanitizers and undefined behavior

Compiler sanitizers instrument certain invalid operations at runtime. They complement warnings and tests but cannot prove unexecuted paths or real-time hardware behavior. In this role, work through: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. The practical workshop develops this into: Compile the host exercise with -fsanitize=address,undefined -g and run boundary fixtures. Introduce one out-of-bounds access in a scratch copy, capture the diagnostic, then repair it and rerun cleanly.

Mental model: A rehearsal safety inspector watches the paths you actually walk.

Boundary: If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass.

Worked example: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Clang or GCC (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required C / C++ Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Compile the host exercise with -fsanitize=address,undefined -g and run boundary fixtures. Introduce one out-of-bounds access in a scratch copy, capture the diagnostic, then repair it and rerun cleanly.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Compile the host exercise with -fsanitize=address,undefined -g and run boundary fixtures. Introduce one out-of-bounds access in a scratch copy, capture the diagnostic, then repair it and rerun cleanly.

```
cc -Wall -Wextra -fsanitize=address,undefined -g sensor.c -o sensor
./sensor
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A recorded failing diagnostic followed by a clean run of the same case.

Role workshop · debug and verify

If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save sanitizer report, repaired source and untested concurrency/hardware list. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A recorded failing diagnostic followed by a clean run of the same case.

Expected: A recorded failing diagnostic followed by a clean run of the same case.

Troubleshoot: The role exercise differs from the prediction: If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: sanitizer report, repaired source and untested concurrency/hardware list; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with sanitizers and undefined behavior. Use the glossary below, then write your prediction for: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C / C++ Developer role interview. Explain sanitizers and undefined behavior using this case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate sanitizers and undefined behavior to a system or workflow you know. Explain sanitizers and undefined behavior using this case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass.

Interview: Explain sanitizers and undefined behavior using this case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A recorded failing diagnostic followed by a clean run of the same case.

Reference: A recorded failing diagnostic followed by a clean run of the same case. — Compiler sanitizers instrument certain invalid operations at runtime. They complement warnings and tests but cannot prove unexecuted paths or real-time hardware behavior. A recorded failing diagnostic followed by a clean run of the same case.

Sources:

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html
