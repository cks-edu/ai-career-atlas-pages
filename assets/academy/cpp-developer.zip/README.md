# C / C++ Developer

Software Engineering

Start with array bounds and explicit states. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward sanitizer report, repaired source and untested concurrency/hardware list.

## beginner

Compile sensor.c with warnings enabled. Trace each reading and state. Add exact threshold readings and a sentinel invalid reading with a documented safe state rather than accessing another array element.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State machines
A state machine defines allowed states and how events change them.
Mental model: Traffic lights change according to explicit rules.
Limit: Real timing, interrupts and hardware noise require additional engineering.
Example: A fan turns on at 30, stays on at 28 and turns off at 25.
Recall: What state would you use when a sensor reading is unavailable?

### Array bounds and explicit states
C arrays do not check every index for you. Keep length alongside data, use explicit state values and validate sensor input before using it to choose an actuator state.
Mental model: Numbered lockers have a first and last valid slot; an invalid number is not another locker.
Limit: Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length.
Example: Four readings have indices 0 through 3; index 4 is outside the array.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
Four readings have indices 0 through 3; index 4 is outside the array. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Compile sensor.c with warnings enabled. Trace each reading and state. Add exact threshold readings and a sentinel invalid reading with a documented safe state rather than accessing another array element.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: All reads stay in bounds; the invalid reading produces the chosen fault state.

6. Role workshop · debug and verify
Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save transition table and annotated C source. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: All reads stay in bounds; the invalid reading produces the chosen fault state.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Array bounds and explicit states: Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: transition table and annotated C source
All reads stay in bounds; the invalid reading produces the chosen fault state.

Interview: Work through this C / C++ Developer case: Four readings have indices 0 through 3; index 4 is outside the array. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: C arrays do not check every index for you. Keep length alongside data, use explicit state values and validate sensor input before using it to choose an actuator state. Expected evidence: All reads stay in bounds; the invalid reading produces the chosen fault state. Diagnosis: Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length. State the limits of the mental model: Numbered lockers have a first and last valid slot; an invalid number is not another locker.

Resume: Built transition table and annotated C source using Clang or GCC; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Extend the host simulation to read a small text fixture. Check fopen/ifstream failure, parse each reading, close the resource and report invalid lines. Test an absent file and malformed text.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Memory and ownership
Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.
Mental model: A borrowed library book must not be used after it is returned.
Limit: Languages enforce different parts of this discipline; concurrency adds other hazards.
Example: A fixed array of four readings is traversed with indices zero through three.
Recall: Why is index four invalid in a four-element array?

### Resource lifetime
A resource has one ownership policy and must be released on every exit path. In C++ use RAII where appropriate; in C design cleanup paths explicitly rather than relying on the happy path.
Mental model: The person who checks out equipment is responsible for returning it even if the event is canceled.
Limit: A crash only on a missing file usually points to an unchecked open result.
Example: Opening a missing input file must not lead to reading a null file handle.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A crash only on a missing file usually points to an unchecked open result.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
Opening a missing input file must not lead to reading a null file handle. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Extend the host simulation to read a small text fixture. Check fopen/ifstream failure, parse each reading, close the resource and report invalid lines. Test an absent file and malformed text.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Both failures are controlled; no leaked handle or use after close in the exercised paths.

6. Role workshop · debug and verify
A crash only on a missing file usually points to an unchecked open result. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save file-input implementation and error-path tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Both failures are controlled; no leaked handle or use after close in the exercised paths.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Resource lifetime: A crash only on a missing file usually points to an unchecked open result.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: file-input implementation and error-path tests
Both failures are controlled; no leaked handle or use after close in the exercised paths.

Interview: Work through this C / C++ Developer case: Opening a missing input file must not lead to reading a null file handle. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A resource has one ownership policy and must be released on every exit path. In C++ use RAII where appropriate; in C design cleanup paths explicitly rather than relying on the happy path. Expected evidence: Both failures are controlled; no leaked handle or use after close in the exercised paths. Diagnosis: A crash only on a missing file usually points to an unchecked open result. State the limits of the mental model: The person who checks out equipment is responsible for returning it even if the event is canceled.

Resume: Built file-input implementation and error-path tests using Clang or GCC; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Compile the host exercise with -fsanitize=address,undefined -g and run boundary fixtures. Introduce one out-of-bounds access in a scratch copy, capture the diagnostic, then repair it and rerun cleanly.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Determinism and timing
A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.
Mental model: A rehearsal follows a script; a live performance adds timing constraints.
Limit: A host simulation does not validate hardware or real-time deadlines.
Example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.
Recall: What measurements would be required on actual hardware?

### Sanitizers and undefined behavior
Compiler sanitizers instrument certain invalid operations at runtime. They complement warnings and tests but cannot prove unexecuted paths or real-time hardware behavior.
Mental model: A rehearsal safety inspector watches the paths you actually walk.
Limit: If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass.
Example: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Compile the host exercise with -fsanitize=address,undefined -g and run boundary fixtures. Introduce one out-of-bounds access in a scratch copy, capture the diagnostic, then repair it and rerun cleanly.
```
cc -Wall -Wextra -fsanitize=address,undefined -g sensor.c -o sensor
./sensor
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A recorded failing diagnostic followed by a clean run of the same case.

6. Role workshop · debug and verify
If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save sanitizer report, repaired source and untested concurrency/hardware list. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A recorded failing diagnostic followed by a clean run of the same case.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Sanitizers and undefined behavior: If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: sanitizer report, repaired source and untested concurrency/hardware list
A recorded failing diagnostic followed by a clean run of the same case.

Interview: Work through this C / C++ Developer case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Compiler sanitizers instrument certain invalid operations at runtime. They complement warnings and tests but cannot prove unexecuted paths or real-time hardware behavior. Expected evidence: A recorded failing diagnostic followed by a clean run of the same case. Diagnosis: If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass. State the limits of the mental model: A rehearsal safety inspector watches the paths you actually walk.

Resume: Built sanitizer report, repaired source and untested concurrency/hardware list using Clang or GCC; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html
The Rust Programming Language: https://doc.rust-lang.org/book/
Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html
