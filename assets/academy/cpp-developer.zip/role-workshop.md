# C / C++ Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Array bounds and explicit states

C arrays do not check every index for you. Keep length alongside data, use explicit state values and validate sensor input before using it to choose an actuator state.
Mental model: Numbered lockers have a first and last valid slot; an invalid number is not another locker.
Case: Four readings have indices 0 through 3; index 4 is outside the array.
Task: Compile sensor.c with warnings enabled. Trace each reading and state. Add exact threshold readings and a sentinel invalid reading with a documented safe state rather than accessing another array element.
Acceptance: All reads stay in bounds; the invalid reading produces the chosen fault state.
Troubleshooting: Unexpected output near the last item suggests an off-by-one loop; inspect < versus <= with the array length.
Deliverable: transition table and annotated C source

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Resource lifetime

A resource has one ownership policy and must be released on every exit path. In C++ use RAII where appropriate; in C design cleanup paths explicitly rather than relying on the happy path.
Mental model: The person who checks out equipment is responsible for returning it even if the event is canceled.
Case: Opening a missing input file must not lead to reading a null file handle.
Task: Extend the host simulation to read a small text fixture. Check fopen/ifstream failure, parse each reading, close the resource and report invalid lines. Test an absent file and malformed text.
Acceptance: Both failures are controlled; no leaked handle or use after close in the exercised paths.
Troubleshooting: A crash only on a missing file usually points to an unchecked open result.
Deliverable: file-input implementation and error-path tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Sanitizers and undefined behavior

Compiler sanitizers instrument certain invalid operations at runtime. They complement warnings and tests but cannot prove unexecuted paths or real-time hardware behavior.
Mental model: A rehearsal safety inspector watches the paths you actually walk.
Case: A deliberately out-of-bounds access in a disposable copy should be detected by AddressSanitizer.
Task: Compile the host exercise with -fsanitize=address,undefined -g and run boundary fixtures. Introduce one out-of-bounds access in a scratch copy, capture the diagnostic, then repair it and rerun cleanly.
Acceptance: A recorded failing diagnostic followed by a clean run of the same case.
Troubleshooting: If sanitizer flags are unsupported, record compiler/platform and use a supported host rather than reporting a pass.
Deliverable: sanitizer report, repaired source and untested concurrency/hardware list

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
