# Dockerizing AI & GPU Kubernetes Orchestration — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

CUDA image: A container user-space stack that must be compatible with the host driver.

PVC: A request for persistent storage, not GPU memory.

VRAM: Memory attached to the GPU.

KV cache: Per-sequence attention state whose size depends on model, length and implementation.

MIG: Hardware partitioning supported by selected NVIDIA GPUs.

Time slicing: Scheduling access to a shared device; guarantees depend on the implementation.

DRA: Dynamic Resource Allocation uses claims and driver-managed devices.

Gang admission: Coordinating a group whose members are needed together.

### Slim CUDA containers & external model weights

Keep the application image separate from large model artifacts. Pin compatible CUDA, driver and serving versions. Fetch approved weights from object storage or a volume before readiness, verify their digest and measure cold start.

The lab accepts a policy envelope {rootfsModelGb, externalWeights, gpuMode, vramBudgetGb}. It rejects more than 5 decimal GB of baked weights and requires an explicit full-device or supported MIG allocation with a positive VRAM budget. These fields describe admission policy; they are not Kubernetes PodSpec fields.

Five GB is a fictional organization threshold. A declared VRAM budget is not enforcement. S3 downloads, PVC access, host RAM and actual VRAM loading require separate real-tool tests.

Mental model: Registry → artifact fetch → verified local volume → serving process. Picture the boundary as a checked gate between stages.

Boundary: Five GB is a fictional organization threshold. A declared VRAM budget is not enforcement. S3 downloads, PVC access, host RAM and actual VRAM loading require separate real-tool tests.

Worked example: function validateGpuPodSpec(p) {
  return !!p && Number.isFinite(p.rootfsModelGb) && p.rootfsModelGb >= 0 &&
    p.rootfsModelGb <= 5 && p.externalWeights === true &&
    ['full','mig'].includes(p.gpuMode) && Number.isFinite(p.vramBudgetGb) && p.vramBudgetGb > 0 &&
    (p.gpuMode !== 'mig' || (p.migSupported === true && typeof p.migProfile === 'string' && p.migProfile.length > 0));
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-docker-k8s.zip, install Node.js LTS, then open production-ai/11-01-cuda-weight-contract.

Tools for this exercise: JavaScript · local isolated workbench; Docker / Kubernetes / GPU Operator, MIG / DRA / Kueue as documented optional extensions

Course tool and framework map: Docker / Kubernetes / GPU Operator (Open-source projects · hardware and support cost separately); MIG / DRA / Kueue (Hardware- and version-dependent capabilities)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: An authorized GPU learning cluster is required. Replace every YOUR_ placeholder after inspecting your context; these commands read state. Inspect scheduling events, resource names and readiness separately. A CPU-only kind cluster does not create a GPU.

Implement validateGpuPodSpec for the policy envelope. Test exactly 5 GB, above 5 GB, a full GPU with no budget and a supported MIG plan. Sketch the separate actual resource limits manifest.

Terminal folder: production-ai/11-01-cuda-weight-contract

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The lab accepts a policy envelope {rootfsModelGb, externalWeights, gpuMode, vramBudgetGb}. It rejects more than 5 decimal GB of baked weights and requires an explicit full-device or supported MIG allocation with a positive VRAM budget. These fields describe admission policy; they are not Kubernetes PodSpec fields.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement validateGpuPodSpec for the policy envelope. Test exactly 5 GB, above 5 GB, a full GPU with no budget and a supported MIG plan. Sketch the separate actual resource limits manifest.

Expected: Approve a declared full device

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Apply the weight boundary; Reject missing or unsupported allocation

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect the declared GPU allocation

An authorized GPU learning cluster is required. Replace every YOUR_ placeholder after inspecting your context; these commands read state. Inspect scheduling events, resource names and readiness separately. A CPU-only kind cluster does not create a GPU.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods -o wide
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT get nodes -o custom-columns='NAME:.metadata.name,GPU:.status.allocatable.nvidia\.com/gpu'
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record the actual allocatable resource name, assigned node and first scheduling/readiness condition. Never invent a successful allocation.

Expected: Approve a declared full device; Apply the weight boundary; Reject missing or unsupported allocation. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Gate startup on verified weights and a supported resource plan. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/11-01-cuda-weight-contract/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Registry → artifact fetch → verified local volume → serving process. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A small CUDA image cannot serve after startup. Which evidence should you inspect first? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A small image does not imply that the model fits in VRAM. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A small CUDA image cannot serve after startup. Which evidence should you inspect first?

Interview: A small CUDA image cannot serve after startup. Which evidence should you inspect first? Explain the decision, a failing case and a production limitation.

Quiz: A small CUDA image cannot serve after startup. Which evidence should you inspect first?

Assume the small image proves GPU capacity.

Check weight integrity/load logs, driver compatibility and readiness.

Bake every model into one image.

Reference: Check weight integrity/load logs, driver compatibility and readiness. — Check weight integrity/load logs, driver compatibility and readiness. Five GB is a fictional organization threshold. A declared VRAM budget is not enforcement. S3 downloads, PVC access, host RAM and actual VRAM loading require separate real-tool tests.

Sources:

Kubernetes: scheduling GPU resources: https://kubernetes.io/docs/tasks/manage-gpus/scheduling-gpus/

NVIDIA GPU Operator: MIG management: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/gpu-operator-mig.html

### GPU VRAM, CPU RAM & bandwidth boundaries

CPU RAM and GPU VRAM are different capacity pools. Weights, KV cache and runtime workspace compete for device memory. Moving data over PCIe or a network adds transfer cost; free host memory is not automatic free device memory.

Sum declared weights, cache, workspace and headroom in GiB, then compare with the allocated device capacity. Reject negative, missing and non-finite inputs before calculating. This is a planning arithmetic check, not a runtime profiler.

Quantization, tensor layout, fragmentation and concurrency affect actual use. Measure device peak allocation and throughput for the selected model and hardware.

Mental model: Weights and request state → host staging → device allocation → generation. Picture the boundary as a checked gate between stages.

Boundary: Quantization, tensor layout, fragmentation and concurrency affect actual use. Measure device peak allocation and throughput for the selected model and hardware.

Worked example: function fitsGpuMemory(p) {
  const k=['weightsGiB','cacheGiB','workspaceGiB','headroomGiB','capacityGiB'];
  return !!p && k.every(k=>Number.isFinite(p[k]) && p[k]>=0) && p.capacityGiB>0 &&
    p.weightsGiB+p.cacheGiB+p.workspaceGiB+p.headroomGiB<=p.capacityGiB;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-docker-k8s.zip, install Node.js LTS, then open production-ai/11-02-vram-bandwidth.

Tools for this exercise: JavaScript · local isolated workbench; Docker / Kubernetes / GPU Operator, MIG / DRA / Kueue as documented optional extensions

Course tool and framework map: Docker / Kubernetes / GPU Operator (Open-source projects · hardware and support cost separately); MIG / DRA / Kueue (Hardware- and version-dependent capabilities)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: An authorized GPU learning cluster is required. Replace every YOUR_ placeholder after inspecting your context; these commands read state. Inspect scheduling events, resource names and readiness separately. A CPU-only kind cluster does not create a GPU.

Implement fitsGpuMemory. Draw independent CPU RAM and VRAM pools, then add a context/concurrency case that violates the declared device budget.

Terminal folder: production-ai/11-02-vram-bandwidth

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Sum declared weights, cache, workspace and headroom in GiB, then compare with the allocated device capacity. Reject negative, missing and non-finite inputs before calculating. This is a planning arithmetic check, not a runtime profiler.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement fitsGpuMemory. Draw independent CPU RAM and VRAM pools, then add a context/concurrency case that violates the declared device budget.

Expected: Fit a declared workload

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Distinguish fit and overflow; Reject unknown capacity

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect the declared GPU allocation

An authorized GPU learning cluster is required. Replace every YOUR_ placeholder after inspecting your context; these commands read state. Inspect scheduling events, resource names and readiness separately. A CPU-only kind cluster does not create a GPU.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods -o wide
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT get nodes -o custom-columns='NAME:.metadata.name,GPU:.status.allocatable.nvidia\.com/gpu'
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record the actual allocatable resource name, assigned node and first scheduling/readiness condition. Never invent a successful allocation.

Expected: Fit a declared workload; Distinguish fit and overflow; Reject unknown capacity. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Reserve headroom and bound concurrency/context before admission. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/11-02-vram-bandwidth/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Weights and request state → host staging → device allocation → generation. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. The model fits alone but fails at high concurrency. What changed? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Host RAM cannot satisfy a device allocation without an explicit offload design. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: The model fits alone but fails at high concurrency. What changed?

Interview: The model fits alone but fails at high concurrency. What changed? Explain the decision, a failing case and a production limitation.

Quiz: The model fits alone but fails at high concurrency. What changed?

The container gained a CPU core.

Host RAM became equivalent to VRAM.

Per-request state such as KV cache consumes the remaining VRAM.

Reference: Per-request state such as KV cache consumes the remaining VRAM. — Per-request state such as KV cache consumes the remaining VRAM. Quantization, tensor layout, fragmentation and concurrency affect actual use. Measure device peak allocation and throughput for the selected model and hardware.

Sources:

vLLM: production metrics and units: https://docs.vllm.ai/en/latest/usage/metrics/

Kubernetes: scheduling GPU resources: https://kubernetes.io/docs/tasks/manage-gpus/scheduling-gpus/

### GPU Operator, time slicing & MIG isolation

GPU Operator manages components such as drivers and device plugins. MIG partitions supported GPUs into hardware instances. Traditional device-plugin time slicing multiplexes access and does not provide MIG-equivalent memory or fault isolation.

Choose dedicated allocation by default. This policy allows MIG only when hardware support is declared, and refuses traditional time slicing for an isolation-required tenant. Do not turn a scheduling share count into an assumed byte limit.

Capabilities depend on GPU architecture, driver, operator and sharing implementation. New memory-enforced sharing mechanisms must be evaluated by their actual version and guarantees.

Mental model: Tenant requirement → hardware capability → allocation mode → workload. Picture the boundary as a checked gate between stages.

Boundary: Capabilities depend on GPU architecture, driver, operator and sharing implementation. New memory-enforced sharing mechanisms must be evaluated by their actual version and guarantees.

Worked example: function chooseGpuSharing(p) {
  if(!p || !['full','mig','time-slicing'].includes(p.mode)) return 'reject';
  if(p.mode==='mig' && p.migSupported!==true) return 'reject';
  if(p.isolationRequired===true && p.mode==='time-slicing') return 'reject';
  return p.mode;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-docker-k8s.zip, install Node.js LTS, then open production-ai/11-03-mig-sharing.

Tools for this exercise: JavaScript · local isolated workbench; Docker / Kubernetes / GPU Operator, MIG / DRA / Kueue as documented optional extensions

Course tool and framework map: Docker / Kubernetes / GPU Operator (Open-source projects · hardware and support cost separately); MIG / DRA / Kueue (Hardware- and version-dependent capabilities)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: An authorized GPU learning cluster is required. Replace every YOUR_ placeholder after inspecting your context; these commands read state. Inspect scheduling events, resource names and readiness separately. A CPU-only kind cluster does not create a GPU.

Implement chooseGpuSharing. Write a two-column comparison of dedicated devices, MIG and traditional time slicing using the official capability documents.

Terminal folder: production-ai/11-03-mig-sharing

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Choose dedicated allocation by default. This policy allows MIG only when hardware support is declared, and refuses traditional time slicing for an isolation-required tenant. Do not turn a scheduling share count into an assumed byte limit.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement chooseGpuSharing. Write a two-column comparison of dedicated devices, MIG and traditional time slicing using the official capability documents.

Expected: Accept supported isolation

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Reject false isolation; Keep explicit full-device choice

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect the declared GPU allocation

An authorized GPU learning cluster is required. Replace every YOUR_ placeholder after inspecting your context; these commands read state. Inspect scheduling events, resource names and readiness separately. A CPU-only kind cluster does not create a GPU.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods -o wide
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT get nodes -o custom-columns='NAME:.metadata.name,GPU:.status.allocatable.nvidia\.com/gpu'
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record the actual allocatable resource name, assigned node and first scheduling/readiness condition. Never invent a successful allocation.

Expected: Accept supported isolation; Reject false isolation; Keep explicit full-device choice. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Reject unsupported isolation plans before scheduling. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/11-03-mig-sharing/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Tenant requirement → hardware capability → allocation mode → workload. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does a traditional time-slicing replica provide a dedicated fraction of VRAM? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Scheduling fairness is separate from hardware memory isolation. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does a traditional time-slicing replica provide a dedicated fraction of VRAM?

Interview: Does a traditional time-slicing replica provide a dedicated fraction of VRAM? Explain the decision, a failing case and a production limitation.

Quiz: Does a traditional time-slicing replica provide a dedicated fraction of VRAM?

Yes, every share is a hardware partition.

No; inspect the exact sharing implementation and use supported isolation.

Only if the Pod is Ready.

Reference: No; inspect the exact sharing implementation and use supported isolation. — No; inspect the exact sharing implementation and use supported isolation. Capabilities depend on GPU architecture, driver, operator and sharing implementation. New memory-enforced sharing mechanisms must be evaluated by their actual version and guarantees.

Sources:

NVIDIA GPU Operator: MIG management: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/gpu-operator-mig.html

NVIDIA GPU Operator: time slicing: https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/gpu-sharing.html

### Gang scheduling & Dynamic Resource Allocation

A distributed AI job may need all its workers before it can make progress. Admission and gang scheduling coordinate resources; DRA describes resource claims and device selection. DRA alone is not an all-workers-ready training protocol.

The fixture admits a job only when all requested workers fit, the chosen claim driver is ready and each worker has a declared positive device count. It returns a planning decision without creating Kubernetes objects.

Check the Kubernetes version, enabled DRA features, vendor driver and chosen scheduler/controller. Do not copy a claim or gang-scheduling API from a different release.

Mental model: Job requirements → group admission → device claims → worker startup. Picture the boundary as a checked gate between stages.

Boundary: Check the Kubernetes version, enabled DRA features, vendor driver and chosen scheduler/controller. Do not copy a claim or gang-scheduling API from a different release.

Worked example: function admitGpuGroup(p) {
  if(!p || !Number.isSafeInteger(p.workers) || p.workers<1 || !Number.isSafeInteger(p.availableSlots) || p.availableSlots<0 || !Number.isSafeInteger(p.devicesPerWorker) || p.devicesPerWorker<1) return false;
  return p.driverReady===true && p.workers<=p.availableSlots;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-docker-k8s.zip, install Node.js LTS, then open production-ai/11-04-gang-dra.

Tools for this exercise: JavaScript · local isolated workbench; Docker / Kubernetes / GPU Operator, MIG / DRA / Kueue as documented optional extensions

Course tool and framework map: Docker / Kubernetes / GPU Operator (Open-source projects · hardware and support cost separately); MIG / DRA / Kueue (Hardware- and version-dependent capabilities)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: An authorized GPU learning cluster is required. Replace every YOUR_ placeholder after inspecting your context; these commands read state. Inspect scheduling events, resource names and readiness separately. A CPU-only kind cluster does not create a GPU.

Implement admitGpuGroup. Draw admission versus allocation versus readiness; record the exact scheduler and DRA driver you would test in a native extension.

Terminal folder: production-ai/11-04-gang-dra

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture admits a job only when all requested workers fit, the chosen claim driver is ready and each worker has a declared positive device count. It returns a planning decision without creating Kubernetes objects.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement admitGpuGroup. Draw admission versus allocation versus readiness; record the exact scheduler and DRA driver you would test in a native extension.

Expected: Admit a complete group

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Wait for capacity or driver; Reject malformed requirements

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect the declared GPU allocation

An authorized GPU learning cluster is required. Replace every YOUR_ placeholder after inspecting your context; these commands read state. Inspect scheduling events, resource names and readiness separately. A CPU-only kind cluster does not create a GPU.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods -o wide
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT get nodes -o custom-columns='NAME:.metadata.name,GPU:.status.allocatable.nvidia\.com/gpu'
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record the actual allocatable resource name, assigned node and first scheduling/readiness condition. Never invent a successful allocation.

Expected: Admit a complete group; Wait for capacity or driver; Reject malformed requirements. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Admit the coordinated group only when its declared requirements fit. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/11-04-gang-dra/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Job requirements → group admission → device claims → worker startup. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Why can a DRA device claim exist while a distributed job cannot progress? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A resource claim does not guarantee the whole job can start. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Why can a DRA device claim exist while a distributed job cannot progress?

Interview: Why can a DRA device claim exist while a distributed job cannot progress? Explain the decision, a failing case and a production limitation.

Quiz: Why can a DRA device claim exist while a distributed job cannot progress?

The claim guarantees every worker is running.

DRA replaces job coordination in all clusters.

Device allocation and coordinated job admission are separate responsibilities.

Reference: Device allocation and coordinated job admission are separate responsibilities. — Device allocation and coordinated job admission are separate responsibilities. Check the Kubernetes version, enabled DRA features, vendor driver and chosen scheduler/controller. Do not copy a claim or gang-scheduling API from a different release.

Sources:

Kubernetes: Dynamic Resource Allocation: https://kubernetes.io/docs/concepts/resource-management/dynamic-resource-allocation/

Kueue: all-or-nothing admission with workload groups: https://kueue.sigs.k8s.io/v0.20/docs/concepts/all_or_nothing/
