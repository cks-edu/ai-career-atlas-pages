# Inspect the declared GPU allocation

An authorized GPU learning cluster is required. Replace every YOUR_ placeholder after inspecting your context; these commands read state. Inspect scheduling events, resource names and readiness separately. A CPU-only kind cluster does not create a GPU.

```sh
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get pods -o wide
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE describe pod YOUR_POD
kubectl --context YOUR_LEARNING_CONTEXT get nodes -o custom-columns='NAME:.metadata.name,GPU:.status.allocatable.nvidia\.com/gpu'
```

Expected evidence: Record the actual allocatable resource name, assigned node and first scheduling/readiness condition. Never invent a successful allocation.

Cleanup: these inspection commands create no resources. Stop only separately started learning servers and remove only your own temporary resources after retaining evidence. No cloud resources are provisioned by this pack.
