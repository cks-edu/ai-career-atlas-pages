function chooseGpuSharing(p) {
  if(!p || !['full','mig','time-slicing'].includes(p.mode)) return 'reject';
  if(p.mode==='mig' && p.migSupported!==true) return 'reject';
  if(p.isolationRequired===true && p.mode==='time-slicing') return 'reject';
  return p.mode;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(chooseGpuSharing({mode:'mig',migSupported:true,isolationRequired:true})==='mig');
console.log("PASS: Accept supported isolation");
}
{
assert(chooseGpuSharing({mode:'time-slicing',isolationRequired:true})==='reject');assert(chooseGpuSharing({mode:'mig',migSupported:false})==='reject');
console.log("PASS: Reject false isolation");
}
{
assert(chooseGpuSharing({mode:'full',isolationRequired:true})==='full');assert(chooseGpuSharing(null)==='reject');assert(chooseGpuSharing({mode:'magic'})==='reject');
console.log("PASS: Keep explicit full-device choice");
}
