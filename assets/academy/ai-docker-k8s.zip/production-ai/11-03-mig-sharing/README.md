# GPU Operator, time slicing & MIG isolation

GPU Operator manages components such as drivers and device plugins. MIG partitions supported GPUs into hardware instances. Traditional device-plugin time slicing multiplexes access and does not provide MIG-equivalent memory or fault isolation.

Choose dedicated allocation by default. This policy allows MIG only when hardware support is declared, and refuses traditional time slicing for an isolation-required tenant. Do not turn a scheduling share count into an assumed byte limit.

Task: Implement chooseGpuSharing. Write a two-column comparison of dedicated devices, MIG and traditional time slicing using the official capability documents.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Tenant requirement → hardware capability → allocation mode → workload.
State: Isolation requirement, supported MIG flag and selected sharing mode.
Boundary: Scheduling fairness is separate from hardware memory isolation.
Failure: A tenant expects isolated memory from a time-sliced GPU.
Control: Reject unsupported isolation plans before scheduling.
Observability: Inspect node labels, allocatable resources and interference tests.
Blast radius: Other workloads sharing the physical device.
Trade-off: MIG isolation restricts partition shapes; dedicated devices reduce sharing efficiency.

Limit: Capabilities depend on GPU architecture, driver, operator and sharing implementation. New memory-enforced sharing mechanisms must be evaluated by their actual version and guarantees.

Sources:
https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/gpu-operator-mig.html
https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/gpu-sharing.html
