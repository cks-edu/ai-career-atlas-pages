# Gang scheduling & Dynamic Resource Allocation

A distributed AI job may need all its workers before it can make progress. Admission and gang scheduling coordinate resources; DRA describes resource claims and device selection. DRA alone is not an all-workers-ready training protocol.

The fixture admits a job only when all requested workers fit, the chosen claim driver is ready and each worker has a declared positive device count. It returns a planning decision without creating Kubernetes objects.

Task: Implement admitGpuGroup. Draw admission versus allocation versus readiness; record the exact scheduler and DRA driver you would test in a native extension.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Job requirements → group admission → device claims → worker startup.
State: Required workers, available slots, device count and driver readiness.
Boundary: A resource claim does not guarantee the whole job can start.
Failure: Half the workers reserve scarce GPUs while the rest wait indefinitely.
Control: Admit the coordinated group only when its declared requirements fit.
Observability: Inspect pending claims, admission conditions and worker readiness.
Blast radius: The job and queued jobs competing for reserved devices.
Trade-off: Waiting for a whole group can improve useful progress while increasing queue time.

Limit: Check the Kubernetes version, enabled DRA features, vendor driver and chosen scheduler/controller. Do not copy a claim or gang-scheduling API from a different release.

Sources:
https://kubernetes.io/docs/concepts/resource-management/dynamic-resource-allocation/
https://kueue.sigs.k8s.io/v0.20/docs/concepts/all_or_nothing/
