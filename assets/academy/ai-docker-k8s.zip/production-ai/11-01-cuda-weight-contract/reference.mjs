function validateGpuPodSpec(p) {
  return !!p && Number.isFinite(p.rootfsModelGb) && p.rootfsModelGb >= 0 &&
    p.rootfsModelGb <= 5 && p.externalWeights === true &&
    ['full','mig'].includes(p.gpuMode) && Number.isFinite(p.vramBudgetGb) && p.vramBudgetGb > 0 &&
    (p.gpuMode !== 'mig' || (p.migSupported === true && typeof p.migProfile === 'string' && p.migProfile.length > 0));
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(validateGpuPodSpec({rootfsModelGb:1,externalWeights:true,gpuMode:'full',vramBudgetGb:24}));
console.log("PASS: Approve a declared full device");
}
{
const p={rootfsModelGb:5,externalWeights:true,gpuMode:'full',vramBudgetGb:24};assert(validateGpuPodSpec(p));assert(!validateGpuPodSpec({...p,rootfsModelGb:5.01}));
console.log("PASS: Apply the weight boundary");
}
{
assert(!validateGpuPodSpec(null));assert(!validateGpuPodSpec({rootfsModelGb:1,externalWeights:true,gpuMode:'full'}));assert(!validateGpuPodSpec({rootfsModelGb:1,externalWeights:true,gpuMode:'mig',vramBudgetGb:5,migProfile:'1g.5gb',migSupported:false}));
console.log("PASS: Reject missing or unsupported allocation");
}
