# Slim CUDA containers & external model weights

Keep the application image separate from large model artifacts. Pin compatible CUDA, driver and serving versions. Fetch approved weights from object storage or a volume before readiness, verify their digest and measure cold start.

The lab accepts a policy envelope {rootfsModelGb, externalWeights, gpuMode, vramBudgetGb}. It rejects more than 5 decimal GB of baked weights and requires an explicit full-device or supported MIG allocation with a positive VRAM budget. These fields describe admission policy; they are not Kubernetes PodSpec fields.

Task: Implement validateGpuPodSpec for the policy envelope. Test exactly 5 GB, above 5 GB, a full GPU with no budget and a supported MIG plan. Sketch the separate actual resource limits manifest.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Registry → artifact fetch → verified local volume → serving process.
State: Image digest, weight digest, device mode and declared memory budget.
Boundary: A small image does not imply that the model fits in VRAM.
Failure: A lightweight container starts but weight download or GPU allocation fails.
Control: Gate startup on verified weights and a supported resource plan.
Observability: Measure image size, artifact integrity, load duration and readiness.
Blast radius: Pods depending on the same artifact store or device pool.
Trade-off: External weights reduce rebuild duplication but introduce availability and cold-start work.

Limit: Five GB is a fictional organization threshold. A declared VRAM budget is not enforcement. S3 downloads, PVC access, host RAM and actual VRAM loading require separate real-tool tests.

Sources:
https://kubernetes.io/docs/tasks/manage-gpus/scheduling-gpus/
https://docs.nvidia.com/datacenter/cloud-native/gpu-operator/latest/gpu-operator-mig.html
