# GPU VRAM, CPU RAM & bandwidth boundaries

CPU RAM and GPU VRAM are different capacity pools. Weights, KV cache and runtime workspace compete for device memory. Moving data over PCIe or a network adds transfer cost; free host memory is not automatic free device memory.

Sum declared weights, cache, workspace and headroom in GiB, then compare with the allocated device capacity. Reject negative, missing and non-finite inputs before calculating. This is a planning arithmetic check, not a runtime profiler.

Task: Implement fitsGpuMemory. Draw independent CPU RAM and VRAM pools, then add a context/concurrency case that violates the declared device budget.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Weights and request state → host staging → device allocation → generation.
State: GiB for weights, KV cache, workspace, headroom and capacity.
Boundary: Host RAM cannot satisfy a device allocation without an explicit offload design.
Failure: A context increase exhausts device memory despite free host RAM.
Control: Reserve headroom and bound concurrency/context before admission.
Observability: Observe peak VRAM, queueing and transfer duration under representative load.
Blast radius: Concurrent requests sharing the exhausted device.
Trade-off: Offloading saves device space at the cost of transfers and latency.

Limit: Quantization, tensor layout, fragmentation and concurrency affect actual use. Measure device peak allocation and throughput for the selected model and hardware.

Sources:
https://docs.vllm.ai/en/latest/usage/metrics/
https://kubernetes.io/docs/tasks/manage-gpus/scheduling-gpus/
