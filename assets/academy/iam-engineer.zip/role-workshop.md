# Identity & Access Management Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Identity lifecycle and entitlements

Identity management follows joiner, mover and leaver events. An entitlement needs a business owner and expiry/review policy; group membership is not self-justifying.
Mental model: Keys are issued, changed and returned as a person's responsibilities change.
Case: A worker moving from Sales to Finance may need Sales access removed before new access is added.
Task: Create a synthetic three-worker entitlement table. Model hire, transfer and termination, with manager approval and effective date. Identify stale access after the transfer.
Acceptance: A before/after matrix with one accountable owner per entitlement.
Troubleshooting: Adding new roles without removing obsolete ones creates privilege accumulation.
Deliverable: lifecycle matrix and access request workflow

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Authentication protocols and application authorization

Single sign-on proves identity according to a protocol; the application must still validate tokens and enforce its own access rules. Token audience and issuer are not interchangeable.
Mental model: A passport identifies a traveler but does not grant access to every room.
Case: A token intended for application A must not be accepted by application B.
Task: Draw an OIDC sign-in flow using official Entra guidance. Create a validation checklist for issuer, audience, expiry and signature; use synthetic token metadata for positive/negative review.
Acceptance: A rejected wrong-audience case and a separate application-role decision.
Troubleshooting: Do not decode a token and treat its contents as verified without signature and claim validation.
Deliverable: SSO flow and token-validation test plan

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Access review and emergency access

Periodic review should remove unjustified access and test emergency procedures. A break-glass identity needs controlled use, monitoring and post-use review.
Mental model: An emergency master key is sealed, monitored and inspected after use.
Case: An inactive account retains a powerful entitlement with no current owner approval.
Task: Review a synthetic entitlement export, record retain/remove decisions with reasons and design a time-bounded emergency access procedure. Reconcile removals and define verification evidence.
Acceptance: Every privileged grant has a current justification or a tracked removal action.
Troubleshooting: A reviewer clicking approve on every row is not evidence of meaningful review.
Deliverable: access-review pack and emergency-access runbook

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
