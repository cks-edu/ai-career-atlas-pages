# Identity & Access Management Engineer

Software Engineering

Start with identity lifecycle and entitlements. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward access-review pack and emergency-access runbook.

## beginner

Create a synthetic three-worker entitlement table. Model hire, transfer and termination, with manager approval and effective date. Identify stale access after the transfer.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Authentication and authorization
Authentication establishes identity; authorization decides which action that identity may perform.
Mental model: An ID card tells who you are; the door policy says where you may enter.
Limit: A valid login does not authorize access to every record.
Example: Alice may read but not write; an unknown user is denied.
Recall: Where should an object ownership check happen?

### Identity lifecycle and entitlements
Identity management follows joiner, mover and leaver events. An entitlement needs a business owner and expiry/review policy; group membership is not self-justifying.
Mental model: Keys are issued, changed and returned as a person's responsibilities change.
Limit: Adding new roles without removing obsolete ones creates privilege accumulation.
Example: A worker moving from Sales to Finance may need Sales access removed before new access is added.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Adding new roles without removing obsolete ones creates privilege accumulation.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A worker moving from Sales to Finance may need Sales access removed before new access is added. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a synthetic three-worker entitlement table. Model hire, transfer and termination, with manager approval and effective date. Identify stale access after the transfer.
Expected: A before/after matrix with one accountable owner per entitlement.

6. Role workshop · debug and verify
Adding new roles without removing obsolete ones creates privilege accumulation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save lifecycle matrix and access request workflow. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A before/after matrix with one accountable owner per entitlement.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Identity lifecycle and entitlements: Adding new roles without removing obsolete ones creates privilege accumulation.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: lifecycle matrix and access request workflow
A before/after matrix with one accountable owner per entitlement.

Interview: Work through this Identity & Access Management Engineer case: A worker moving from Sales to Finance may need Sales access removed before new access is added. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Identity management follows joiner, mover and leaver events. An entitlement needs a business owner and expiry/review policy; group membership is not self-justifying. Expected evidence: A before/after matrix with one accountable owner per entitlement. Diagnosis: Adding new roles without removing obsolete ones creates privilege accumulation. State the limits of the mental model: Keys are issued, changed and returned as a person's responsibilities change.

Resume: Built lifecycle matrix and access request workflow using Microsoft Entra ID, OIDC and SAML integrations; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Draw an OIDC sign-in flow using official Entra guidance. Create a validation checklist for issuer, audience, expiry and signature; use synthetic token metadata for positive/negative review.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Code and data separation
Parameterized SQL keeps input values separate from SQL instructions.
Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.
Limit: Parameters protect values; dynamic table names still require explicit allowlists.
Example: The malicious-looking owner string is treated as a value and returns zero rows.
Recall: Why is escaping one example string weaker than using parameters?

### Authentication protocols and application authorization
Single sign-on proves identity according to a protocol; the application must still validate tokens and enforce its own access rules. Token audience and issuer are not interchangeable.
Mental model: A passport identifies a traveler but does not grant access to every room.
Limit: Do not decode a token and treat its contents as verified without signature and claim validation.
Example: A token intended for application A must not be accepted by application B.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not decode a token and treat its contents as verified without signature and claim validation.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A token intended for application A must not be accepted by application B. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Draw an OIDC sign-in flow using official Entra guidance. Create a validation checklist for issuer, audience, expiry and signature; use synthetic token metadata for positive/negative review.
Expected: A rejected wrong-audience case and a separate application-role decision.

6. Role workshop · debug and verify
Do not decode a token and treat its contents as verified without signature and claim validation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save SSO flow and token-validation test plan. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A rejected wrong-audience case and a separate application-role decision.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Authentication protocols and application authorization: Do not decode a token and treat its contents as verified without signature and claim validation.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: SSO flow and token-validation test plan
A rejected wrong-audience case and a separate application-role decision.

Interview: Work through this Identity & Access Management Engineer case: A token intended for application A must not be accepted by application B. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Single sign-on proves identity according to a protocol; the application must still validate tokens and enforce its own access rules. Token audience and issuer are not interchangeable. Expected evidence: A rejected wrong-audience case and a separate application-role decision. Diagnosis: Do not decode a token and treat its contents as verified without signature and claim validation. State the limits of the mental model: A passport identifies a traveler but does not grant access to every room.

Resume: Built SSO flow and token-validation test plan using Microsoft Entra ID, OIDC and SAML integrations; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Review a synthetic entitlement export, record retain/remove decisions with reasons and design a time-bounded emergency access procedure. Reconcile removals and define verification evidence.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Threat models and regression
State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.
Mental model: Mark doors and valuable rooms on a building map before choosing locks.
Limit: A threat model is a living hypothesis, not proof that the system is secure.
Example: Reader-write, unknown-read and unsupported-delete must all be denied.
Recall: How would a new export endpoint change the threat model?

### Access review and emergency access
Periodic review should remove unjustified access and test emergency procedures. A break-glass identity needs controlled use, monitoring and post-use review.
Mental model: An emergency master key is sealed, monitored and inspected after use.
Limit: A reviewer clicking approve on every row is not evidence of meaningful review.
Example: An inactive account retains a powerful entitlement with no current owner approval.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A reviewer clicking approve on every row is not evidence of meaningful review.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
An inactive account retains a powerful entitlement with no current owner approval. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Review a synthetic entitlement export, record retain/remove decisions with reasons and design a time-bounded emergency access procedure. Reconcile removals and define verification evidence.
Expected: Every privileged grant has a current justification or a tracked removal action.

6. Role workshop · debug and verify
A reviewer clicking approve on every row is not evidence of meaningful review. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save access-review pack and emergency-access runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Every privileged grant has a current justification or a tracked removal action.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Access review and emergency access: A reviewer clicking approve on every row is not evidence of meaningful review.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: access-review pack and emergency-access runbook
Every privileged grant has a current justification or a tracked removal action.

Interview: Work through this Identity & Access Management Engineer case: An inactive account retains a powerful entitlement with no current owner approval. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Periodic review should remove unjustified access and test emergency procedures. A break-glass identity needs controlled use, monitoring and post-use review. Expected evidence: Every privileged grant has a current justification or a tracked removal action. Diagnosis: A reviewer clicking approve on every row is not evidence of meaningful review. State the limits of the mental model: An emergency master key is sealed, monitored and inspected after use.

Resume: Built access-review pack and emergency-access runbook using Microsoft Entra ID, OIDC and SAML integrations; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Microsoft Entra identity documentation: https://learn.microsoft.com/en-us/entra/identity/
OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
