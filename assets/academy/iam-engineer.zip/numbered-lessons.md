# Identity & Access Management Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Authentication and authorization: Authentication establishes identity; authorization decides which action that identity may perform.

Apply authentication and authorization in Identity & Access Management Engineer: Use the concept to complete this role exercise: Separate identity, authentication, session and authorization responsibilities

Identity lifecycle and entitlements: Identity management follows joiner, mover and leaver events. An entitlement needs a business owner and expiry/review policy; group membership is not self-justifying.

### Authentication and authorization

Authentication establishes identity; authorization decides which action that identity may perform. In this role, work through: A worker moving from Sales to Finance may need Sales access removed before new access is added. The practical workshop develops this into: Create a synthetic three-worker entitlement table. Model hire, transfer and termination, with manager approval and effective date. Identify stale access after the transfer.

Mental model: An ID card tells who you are; the door policy says where you may enter.

Boundary: A valid login does not authorize access to every record.

Role application: Keys are issued, changed and returned as a person's responsibilities change.

Identity management follows joiner, mover and leaver events. An entitlement needs a business owner and expiry/review policy; group membership is not self-justifying.

Worked example: A worker moving from Sales to Finance may need Sales access removed before new access is added.

Shared foundation example: Alice may read but not write; an unknown user is denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Microsoft Entra ID, OIDC and SAML integrations (Commercial identity service / open standards); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Identity & Access Management Engineer: A worker moving from Sales to Finance may need Sales access removed before new access is added.

Predict the worked case

Read this case without running a tool: A worker moving from Sales to Finance may need Sales access removed before new access is added. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in authentication and authorization.

Connect the concept to the role

Apply this rule: Authentication establishes identity; authorization decides which action that identity may perform. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A valid login does not authorize access to every record.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies authentication and authorization to this case: A worker moving from Sales to Finance may need Sales access removed before new access is added. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A worker moving from Sales to Finance may need Sales access removed before new access is added. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Authentication and authorization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with authentication and authorization. Use the glossary below, then write your prediction for: A worker moving from Sales to Finance may need Sales access removed before new access is added. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Identity & Access Management Engineer role interview. Explain authentication and authorization using this case: A worker moving from Sales to Finance may need Sales access removed before new access is added. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate authentication and authorization to a system or workflow you know. Explain authentication and authorization using this case: A worker moving from Sales to Finance may need Sales access removed before new access is added. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Where should an object ownership check happen?

Interview: Explain authentication and authorization using this case: A worker moving from Sales to Finance may need Sales access removed before new access is added. State the evidence, one alternative and where the mental model stops.

Quiz: After the Identity lifecycle and entitlements rehearsal, check this foundation: A logged-in user requests another user’s private record. What must the service still check?

Whether this identity is permitted to perform this action on that record.

Only whether the session token has the correct syntax.

Only whether the record identifier exists.

Reference: Whether this identity is permitted to perform this action on that record. — Authentication establishes identity; authorization checks the action and resource.

Sources:

Microsoft Entra identity documentation: https://learn.microsoft.com/en-us/entra/identity/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Identity lifecycle and entitlements

Identity management follows joiner, mover and leaver events. An entitlement needs a business owner and expiry/review policy; group membership is not self-justifying. In this role, work through: A worker moving from Sales to Finance may need Sales access removed before new access is added. The practical workshop develops this into: Create a synthetic three-worker entitlement table. Model hire, transfer and termination, with manager approval and effective date. Identify stale access after the transfer.

Mental model: Keys are issued, changed and returned as a person's responsibilities change.

Boundary: Adding new roles without removing obsolete ones creates privilege accumulation.

Worked example: A worker moving from Sales to Finance may need Sales access removed before new access is added.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Microsoft Entra ID, OIDC and SAML integrations (Commercial identity service / open standards); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Identity & Access Management Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a synthetic three-worker entitlement table. Model hire, transfer and termination, with manager approval and effective date. Identify stale access after the transfer.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A worker moving from Sales to Finance may need Sales access removed before new access is added. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a synthetic three-worker entitlement table. Model hire, transfer and termination, with manager approval and effective date. Identify stale access after the transfer.

Expected: A before/after matrix with one accountable owner per entitlement.

Role workshop · debug and verify

Adding new roles without removing obsolete ones creates privilege accumulation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save lifecycle matrix and access request workflow. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A before/after matrix with one accountable owner per entitlement.

Expected: A before/after matrix with one accountable owner per entitlement.

Troubleshoot: The role exercise differs from the prediction: Adding new roles without removing obsolete ones creates privilege accumulation.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: lifecycle matrix and access request workflow; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with identity lifecycle and entitlements. Use the glossary below, then write your prediction for: A worker moving from Sales to Finance may need Sales access removed before new access is added. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Identity & Access Management Engineer role interview. Explain identity lifecycle and entitlements using this case: A worker moving from Sales to Finance may need Sales access removed before new access is added. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate identity lifecycle and entitlements to a system or workflow you know. Explain identity lifecycle and entitlements using this case: A worker moving from Sales to Finance may need Sales access removed before new access is added. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Adding new roles without removing obsolete ones creates privilege accumulation.

Interview: Explain identity lifecycle and entitlements using this case: A worker moving from Sales to Finance may need Sales access removed before new access is added. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A worker moving from Sales to Finance may need Sales access removed before new access is added.

A before/after matrix with one accountable owner per entitlement.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A before/after matrix with one accountable owner per entitlement. — Identity management follows joiner, mover and leaver events. An entitlement needs a business owner and expiry/review policy; group membership is not self-justifying. A before/after matrix with one accountable owner per entitlement.

Sources:

Microsoft Entra identity documentation: https://learn.microsoft.com/en-us/entra/identity/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Code and data separation: Parameterized SQL keeps input values separate from SQL instructions.

Apply code and data separation in Identity & Access Management Engineer: Use the concept to complete this role exercise: Write joiner/mover/leaver and role-assignment test cases

Authentication protocols and application authorization: Single sign-on proves identity according to a protocol; the application must still validate tokens and enforce its own access rules. Token audience and issuer are not interchangeable.

### Code and data separation

Parameterized SQL keeps input values separate from SQL instructions. In this role, work through: A token intended for application A must not be accepted by application B. The practical workshop develops this into: Draw an OIDC sign-in flow using official Entra guidance. Create a validation checklist for issuer, audience, expiry and signature; use synthetic token metadata for positive/negative review.

Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.

Boundary: Parameters protect values; dynamic table names still require explicit allowlists.

Role application: A passport identifies a traveler but does not grant access to every room.

Single sign-on proves identity according to a protocol; the application must still validate tokens and enforce its own access rules. Token audience and issuer are not interchangeable.

Worked example: A token intended for application A must not be accepted by application B.

Shared foundation example: The malicious-looking owner string is treated as a value and returns zero rows.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Microsoft Entra ID, OIDC and SAML integrations (Commercial identity service / open standards); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Identity & Access Management Engineer: A token intended for application A must not be accepted by application B.

Predict the worked case

Read this case without running a tool: A token intended for application A must not be accepted by application B. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in code and data separation.

Connect the concept to the role

Apply this rule: Parameterized SQL keeps input values separate from SQL instructions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Parameters protect values; dynamic table names still require explicit allowlists.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies code and data separation to this case: A token intended for application A must not be accepted by application B. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A token intended for application A must not be accepted by application B. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Code and data separation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with code and data separation. Use the glossary below, then write your prediction for: A token intended for application A must not be accepted by application B. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Identity & Access Management Engineer role interview. Explain code and data separation using this case: A token intended for application A must not be accepted by application B. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate code and data separation to a system or workflow you know. Explain code and data separation using this case: A token intended for application A must not be accepted by application B. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is escaping one example string weaker than using parameters?

Interview: Explain code and data separation using this case: A token intended for application A must not be accepted by application B. State the evidence, one alternative and where the mental model stops.

Quiz: After the Authentication protocols and application authorization rehearsal, check this foundation: A query binds a user value through a parameter. Can that same placeholder choose an arbitrary table name?

Yes, placeholders bind all SQL syntax.

No; structural identifiers need an allowlisted query design.

Yes, if the identifier arrives over HTTPS.

Reference: No; structural identifiers need an allowlisted query design. — Parameters bind values, not arbitrary SQL structure. Transport security does not change SQL semantics.

Sources:

Microsoft Entra identity documentation: https://learn.microsoft.com/en-us/entra/identity/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Authentication protocols and application authorization

Single sign-on proves identity according to a protocol; the application must still validate tokens and enforce its own access rules. Token audience and issuer are not interchangeable. In this role, work through: A token intended for application A must not be accepted by application B. The practical workshop develops this into: Draw an OIDC sign-in flow using official Entra guidance. Create a validation checklist for issuer, audience, expiry and signature; use synthetic token metadata for positive/negative review.

Mental model: A passport identifies a traveler but does not grant access to every room.

Boundary: Do not decode a token and treat its contents as verified without signature and claim validation.

Worked example: A token intended for application A must not be accepted by application B.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Microsoft Entra ID, OIDC and SAML integrations (Commercial identity service / open standards); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Identity & Access Management Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Draw an OIDC sign-in flow using official Entra guidance. Create a validation checklist for issuer, audience, expiry and signature; use synthetic token metadata for positive/negative review.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A token intended for application A must not be accepted by application B. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Draw an OIDC sign-in flow using official Entra guidance. Create a validation checklist for issuer, audience, expiry and signature; use synthetic token metadata for positive/negative review.

Expected: A rejected wrong-audience case and a separate application-role decision.

Role workshop · debug and verify

Do not decode a token and treat its contents as verified without signature and claim validation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save SSO flow and token-validation test plan. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A rejected wrong-audience case and a separate application-role decision.

Expected: A rejected wrong-audience case and a separate application-role decision.

Troubleshoot: The role exercise differs from the prediction: Do not decode a token and treat its contents as verified without signature and claim validation.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: SSO flow and token-validation test plan; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with authentication protocols and application authorization. Use the glossary below, then write your prediction for: A token intended for application A must not be accepted by application B. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Identity & Access Management Engineer role interview. Explain authentication protocols and application authorization using this case: A token intended for application A must not be accepted by application B. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate authentication protocols and application authorization to a system or workflow you know. Explain authentication protocols and application authorization using this case: A token intended for application A must not be accepted by application B. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not decode a token and treat its contents as verified without signature and claim validation.

Interview: Explain authentication protocols and application authorization using this case: A token intended for application A must not be accepted by application B. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A token intended for application A must not be accepted by application B.

Ignore the failing case and keep only the successful screenshot.

A rejected wrong-audience case and a separate application-role decision.

Treat any successful command as proof that all business and access rules passed.

Reference: A rejected wrong-audience case and a separate application-role decision. — Single sign-on proves identity according to a protocol; the application must still validate tokens and enforce its own access rules. Token audience and issuer are not interchangeable. A rejected wrong-audience case and a separate application-role decision.

Sources:

Microsoft Entra identity documentation: https://learn.microsoft.com/en-us/entra/identity/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Threat models and regression: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.

Apply threat models and regression in Identity & Access Management Engineer: Use the concept to complete this role exercise: Design privileged-access reviews, recovery and federation failure handling

Access review and emergency access: Periodic review should remove unjustified access and test emergency procedures. A break-glass identity needs controlled use, monitoring and post-use review.

### Threat models and regression

State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. In this role, work through: An inactive account retains a powerful entitlement with no current owner approval. The practical workshop develops this into: Review a synthetic entitlement export, record retain/remove decisions with reasons and design a time-bounded emergency access procedure. Reconcile removals and define verification evidence.

Mental model: Mark doors and valuable rooms on a building map before choosing locks.

Boundary: A threat model is a living hypothesis, not proof that the system is secure.

Role application: An emergency master key is sealed, monitored and inspected after use.

Periodic review should remove unjustified access and test emergency procedures. A break-glass identity needs controlled use, monitoring and post-use review.

Worked example: An inactive account retains a powerful entitlement with no current owner approval.

Shared foundation example: Reader-write, unknown-read and unsupported-delete must all be denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Microsoft Entra ID, OIDC and SAML integrations (Commercial identity service / open standards); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Identity & Access Management Engineer: An inactive account retains a powerful entitlement with no current owner approval.

Predict the worked case

Read this case without running a tool: An inactive account retains a powerful entitlement with no current owner approval. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in threat models and regression.

Connect the concept to the role

Apply this rule: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A threat model is a living hypothesis, not proof that the system is secure.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies threat models and regression to this case: An inactive account retains a powerful entitlement with no current owner approval. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An inactive account retains a powerful entitlement with no current owner approval. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Threat models and regression; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with threat models and regression. Use the glossary below, then write your prediction for: An inactive account retains a powerful entitlement with no current owner approval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Identity & Access Management Engineer role interview. Explain threat models and regression using this case: An inactive account retains a powerful entitlement with no current owner approval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate threat models and regression to a system or workflow you know. Explain threat models and regression using this case: An inactive account retains a powerful entitlement with no current owner approval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would a new export endpoint change the threat model?

Interview: Explain threat models and regression using this case: An inactive account retains a powerful entitlement with no current owner approval. State the evidence, one alternative and where the mental model stops.

Quiz: After the Access review and emergency access rehearsal, check this foundation: A denied action is fixed after a security defect. What helps detect its recurrence?

Document only the successful authorized path.

Remove the denied case because it now passes.

Add a repeatable negative test tied to the actor, action and trust boundary.

Reference: Add a repeatable negative test tied to the actor, action and trust boundary. — Regression checks preserve evidence for important misuse cases; the threat model explains why the control matters.

Sources:

Microsoft Entra identity documentation: https://learn.microsoft.com/en-us/entra/identity/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Access review and emergency access

Periodic review should remove unjustified access and test emergency procedures. A break-glass identity needs controlled use, monitoring and post-use review. In this role, work through: An inactive account retains a powerful entitlement with no current owner approval. The practical workshop develops this into: Review a synthetic entitlement export, record retain/remove decisions with reasons and design a time-bounded emergency access procedure. Reconcile removals and define verification evidence.

Mental model: An emergency master key is sealed, monitored and inspected after use.

Boundary: A reviewer clicking approve on every row is not evidence of meaningful review.

Worked example: An inactive account retains a powerful entitlement with no current owner approval.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Microsoft Entra ID, OIDC and SAML integrations (Commercial identity service / open standards); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Identity & Access Management Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Review a synthetic entitlement export, record retain/remove decisions with reasons and design a time-bounded emergency access procedure. Reconcile removals and define verification evidence.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

An inactive account retains a powerful entitlement with no current owner approval. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Review a synthetic entitlement export, record retain/remove decisions with reasons and design a time-bounded emergency access procedure. Reconcile removals and define verification evidence.

Expected: Every privileged grant has a current justification or a tracked removal action.

Role workshop · debug and verify

A reviewer clicking approve on every row is not evidence of meaningful review. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save access-review pack and emergency-access runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Every privileged grant has a current justification or a tracked removal action.

Expected: Every privileged grant has a current justification or a tracked removal action.

Troubleshoot: The role exercise differs from the prediction: A reviewer clicking approve on every row is not evidence of meaningful review.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: access-review pack and emergency-access runbook; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with access review and emergency access. Use the glossary below, then write your prediction for: An inactive account retains a powerful entitlement with no current owner approval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Identity & Access Management Engineer role interview. Explain access review and emergency access using this case: An inactive account retains a powerful entitlement with no current owner approval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate access review and emergency access to a system or workflow you know. Explain access review and emergency access using this case: An inactive account retains a powerful entitlement with no current owner approval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A reviewer clicking approve on every row is not evidence of meaningful review.

Interview: Explain access review and emergency access using this case: An inactive account retains a powerful entitlement with no current owner approval. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? An inactive account retains a powerful entitlement with no current owner approval.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Every privileged grant has a current justification or a tracked removal action.

Reference: Every privileged grant has a current justification or a tracked removal action. — Periodic review should remove unjustified access and test emergency procedures. A break-glass identity needs controlled use, monitoring and post-use review. Every privileged grant has a current justification or a tracked removal action.

Sources:

Microsoft Entra identity documentation: https://learn.microsoft.com/en-us/entra/identity/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
