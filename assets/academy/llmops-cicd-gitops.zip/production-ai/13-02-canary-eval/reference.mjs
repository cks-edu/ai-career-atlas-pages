function evaluateCanaryPromotion(b,c) {
  if(!b || !c || !Number.isFinite(b.p95TtftSeconds) || b.p95TtftSeconds<=0 || !Number.isFinite(c.p95TtftSeconds) || c.p95TtftSeconds<0 || !Number.isFinite(c.schemaValidity) || c.schemaValidity<0 || c.schemaValidity>1) return 'hold';
  return c.schemaValidity<0.99 || c.p95TtftSeconds>b.p95TtftSeconds*1.2 ? 'rollback' : 'promote';
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(evaluateCanaryPromotion({p95TtftSeconds:10},{p95TtftSeconds:12,schemaValidity:0.99})==='promote');
console.log("PASS: Honor inclusive thresholds");
}
{
assert(evaluateCanaryPromotion({p95TtftSeconds:10},{p95TtftSeconds:12.01,schemaValidity:1})==='rollback');assert(evaluateCanaryPromotion({p95TtftSeconds:10},{p95TtftSeconds:1,schemaValidity:0.989})==='rollback');
console.log("PASS: Block either regression");
}
{
assert(evaluateCanaryPromotion(null,{})==='hold');assert(evaluateCanaryPromotion({p95TtftSeconds:0},{p95TtftSeconds:1,schemaValidity:1})==='hold');
console.log("PASS: Hold missing evidence");
}
