# Automated eval gates block regressions

Evaluate behavior and latency under comparable conditions before promoting a canary. A high aggregate score cannot excuse a broken output contract. Missing or invalid measurements should hold the decision rather than pass.

The lab requires schema validity of at least 0.99 and P95 TTFT no more than 1.2 times the baseline. Exact boundaries pass. Invalid metrics return hold; valid regressions return rollback. The function never changes a cluster.

Task: Implement evaluateCanaryPromotion. Add an AnalysisTemplate design describing how an authorized controller consumes promote, rollback and hold without treating missing data as success.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Matched evaluation runs → metric validation → promotion or rollback recommendation.
State: Schema-valid fraction, P95 TTFT seconds and baseline identity.
Boundary: Passing syntax is separate from acceptable latency and answer behavior.
Failure: A canary produces valid-looking answers too slowly or violates the schema.
Control: Require both gates and hold unknown measurements.
Observability: Retain sample definition, metric values and the exact gate decision.
Blast radius: Traffic promoted to the failing canary.
Trade-off: Strict gates reduce regression risk but can delay beneficial releases with noisy samples.

Limit: These are example thresholds, not universal SLAs. Match sample populations, load, confidence, model configuration and units before applying the comparison. A separate authorized controller executes a recovery decision.

Sources:
https://argoproj.github.io/argo-rollouts/features/analysis/
https://docs.vllm.ai/en/latest/usage/metrics/
