function completeAiRelease(p) {
  return !!p && ['code','prompt','dataset','weights'].every(k=>/^sha256:[a-f0-9]{64}$/.test(p[k]||'')) && typeof p.evalRun==='string' && p.evalRun.trim().length>0;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const d='sha256:'+'a'.repeat(64);assert(completeAiRelease({code:d,prompt:d,dataset:d,weights:d,evalRun:'eval-7'}));
console.log("PASS: Accept a complete release");
}
{
const d='sha256:'+'a'.repeat(64);assert(!completeAiRelease({code:d,prompt:d,dataset:d,weights:'latest',evalRun:'e'}));assert(!completeAiRelease({code:d,prompt:d,dataset:d,weights:d}));
console.log("PASS: Reject mutable or missing references");
}
{
assert(!completeAiRelease(null));assert(!completeAiRelease({evalRun:'e'}));
console.log("PASS: Do not accept malformed manifests");
}
