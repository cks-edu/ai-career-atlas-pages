# Version code, prompts, datasets & weights together

An AI release is more than an application image. A changed prompt, dataset, tokenizer, model adapter or decoding configuration can change behavior while the container stays identical. Keep the release and evaluation inputs traceable.

Require exact SHA-256 identities for code, prompt, dataset and weights plus a named evaluation run. The fixture checks shape and completeness only; artifact existence, access and cryptographic provenance remain separate checks.

Task: Implement completeAiRelease. Create release.json and an evidence table identifying every evaluated artifact and the registry lookup you still need to perform.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Reviewed changes → immutable release manifest → evaluation run → registry.
State: Four artifact identities and the evaluation-run identifier.
Boundary: A mutable alias cannot identify exactly what was evaluated.
Failure: The weights alias changes after evaluation without a new release.
Control: Require immutable identities and retain the matched evaluation record.
Observability: Audit manifest diff, registry lookup and evaluated versus deployed identities.
Blast radius: Every environment promoted from the drifting alias.
Trade-off: Explicit manifests add bookkeeping while making rollback reproducible.

Limit: A well-formed digest does not prove trusted origin or quality. Resolve immutable artifacts through an authenticated registry and bind evaluation results to the complete release manifest.

Sources:
https://argo-cd.readthedocs.io/en/stable/user-guide/auto_sync/
https://argoproj.github.io/argo-rollouts/features/analysis/
