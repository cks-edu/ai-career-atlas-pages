# Shadow traffic & controlled canary rollout

Shadowing sends a copy for comparison without returning the candidate output to the user. It can still leak data or repeat side effects. Canary traffic serves actual users and needs a distinct allocation and rollback policy.

The fixture allows a shadow request only with approved data use and disabled writes; canary exposure must stay within the approved maximum percentage. Both use a synthetic decision envelope, not an Argo CRD.

Task: Implement allowAiRollout and write separate shadow and canary acceptance cases, including a rejected side effect and a failed data approval.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Approved request copy → isolated shadow or bounded canary → comparison.
State: Mode, write capability, data approval and exposure percentage.
Boundary: A copied request must not duplicate a real action.
Failure: A shadow agent executes a tool twice.
Control: Disable shadow writes and bound user-serving exposure.
Observability: Compare redacted outputs, request IDs and duplicate-action counts.
Blast radius: Copied data and users within the routed exposure.
Trade-off: Shadowing gives comparison evidence but costs capacity and requires data controls.

Limit: Do not replay payments, tool actions or private prompts into a shadow service by default. Native routing, consent, redaction and controller behavior require integration tests.

Sources:
https://argoproj.github.io/argo-rollouts/features/analysis/
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
