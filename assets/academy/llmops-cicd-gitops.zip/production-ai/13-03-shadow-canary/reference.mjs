function allowAiRollout(p) {
  if(!p || p.dataApproved!==true) return false;
  if(p.mode==='shadow') return p.writesEnabled===false;
  return p.mode==='canary' && [p.percent,p.maxPercent].every(n=>Number.isFinite(n)&&n>=0&&n<=100) && p.percent<=p.maxPercent;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(allowAiRollout({mode:'shadow',dataApproved:true,writesEnabled:false}));
console.log("PASS: Allow safe shadowing");
}
{
assert(!allowAiRollout({mode:'shadow',dataApproved:true,writesEnabled:true}));assert(!allowAiRollout({mode:'canary',dataApproved:true,percent:20,maxPercent:5}));
console.log("PASS: Deny side effects and excess exposure");
}
{
assert(allowAiRollout({mode:'canary',dataApproved:true,percent:5,maxPercent:5}));assert(!allowAiRollout(null));assert(!allowAiRollout({mode:'shadow',dataApproved:false,writesEnabled:false}));
console.log("PASS: Validate mode and approval");
}
