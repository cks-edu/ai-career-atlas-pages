# Immutable registries & bounded rollback

Rollback must identify the previous compatible bundle, not just an older image tag. Model, prompt, retrieval schema and application configuration may need to move together. GitOps controllers can revert an imperative cluster edit back to the undesired state.

Choose the newest healthy prior release that matches the current required data-schema contract and differs from the failed digest. The fixture selects an artifact; it does not grant deployment authority or promise instant warmup.

Task: Implement selectRollback for a newest-first fixture. Produce a rollback runbook naming the authoritative Git commit, bundle, schema, readiness checks and remaining model-load delay.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Failed canary → retained release catalogue → compatibility check → approved revert.
State: Healthy flag, immutable digest and schema contract.
Boundary: An older release is not necessarily compatible with current persisted data.
Failure: A rollback restores code that cannot read the new schema.
Control: Select a known healthy compatible bundle and rehearse its restoration.
Observability: Check release identities, readiness and post-revert user signals.
Blast radius: Users and downstream systems dependent on the schema.
Trade-off: Keeping compatible prior artifacts costs storage but enables recovery.

Limit: Keep artifacts available, permissions valid and capacity ready. Model loading and incompatible data changes can prevent an instant rollback. Reconcile the authoritative Git state through the approved recovery workflow.

Sources:
https://argo-cd.readthedocs.io/en/stable/user-guide/auto_sync/
https://argoproj.github.io/argo-rollouts/features/analysis/
