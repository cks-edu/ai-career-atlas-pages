function selectRollback(releases, failed, schema) {
  if(!Array.isArray(releases) || typeof schema!=='string' || !schema) return null;
  return releases.find(r=>r && /^sha256:[a-f0-9]{64}$/.test(r.digest||'') && r.digest!==failed && r.healthy===true && r.schema===schema)?.digest || null;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const a='sha256:'+'a'.repeat(64),b='sha256:'+'b'.repeat(64);assert(selectRollback([{digest:a,healthy:true,schema:'s1'}],b,'s1')===a);
console.log("PASS: Select retained compatible artifact");
}
{
assert(selectRollback([{digest:'latest',healthy:true,schema:'s1'}],'failed','s1')===null);assert(selectRollback([{digest:'sha256:'+'a'.repeat(64),healthy:true,schema:'s2'}],'failed','s1')===null);
console.log("PASS: Reject incompatibility and aliases");
}
{
assert(selectRollback([], 'f','s')===null);assert(selectRollback(null,'f','s')===null);
console.log("PASS: Handle absent evidence");
}
