# Inspect evaluation-gated rollout state

Requires an authorized learning cluster with the supported Argo Rollouts controller and your own rollout objects. Replace placeholders. An absent CRD means the controller/API is not installed; do not infer a completed rollout.

```sh
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get rollouts.argoproj.io
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get analysisruns.argoproj.io
```

Expected evidence: Retain the actual analysis phase, gate metric and immutable candidate identity. A local function recommendation is separate from a controller action.

Cleanup: these inspection commands create no resources. Stop only separately started learning servers and remove only your own temporary resources after retaining evidence. No cloud resources are provisioned by this pack.
