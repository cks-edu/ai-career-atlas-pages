# CI/CD for AI, GitOps & Automated Eval Gates — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## intermediate

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

Immutable reference: A content identity that cannot silently point to new bytes.

Evaluation run: A versioned result tied to declared inputs and configuration.

Canary: A limited exposure of a candidate release before wider promotion.

P95 TTFT: The 95th percentile time to first token for a declared sample population.

Shadowing: Evaluating a copy without returning candidate output to the user.

Exposure: The fraction of user traffic routed to the candidate.

GitOps: Reconciling declared version-controlled state through a controller.

Compatibility: The ability to use the retained data and protocol contracts correctly.

### Version code, prompts, datasets & weights together

An AI release is more than an application image. A changed prompt, dataset, tokenizer, model adapter or decoding configuration can change behavior while the container stays identical. Keep the release and evaluation inputs traceable.

Require exact SHA-256 identities for code, prompt, dataset and weights plus a named evaluation run. The fixture checks shape and completeness only; artifact existence, access and cryptographic provenance remain separate checks.

A well-formed digest does not prove trusted origin or quality. Resolve immutable artifacts through an authenticated registry and bind evaluation results to the complete release manifest.

Mental model: Reviewed changes → immutable release manifest → evaluation run → registry. Picture the boundary as a checked gate between stages.

Boundary: A well-formed digest does not prove trusted origin or quality. Resolve immutable artifacts through an authenticated registry and bind evaluation results to the complete release manifest.

Worked example: function completeAiRelease(p) {
  return !!p && ['code','prompt','dataset','weights'].every(k=>/^sha256:[a-f0-9]{64}$/.test(p[k]||'')) && typeof p.evalRun==='string' && p.evalRun.trim().length>0;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract llmops-cicd-gitops.zip, install Node.js LTS, then open production-ai/13-01-release-bundle.

Tools for this exercise: JavaScript · local isolated workbench; Argo CD / Argo Rollouts, GitHub Actions / model registry as documented optional extensions

Course tool and framework map: Argo CD / Argo Rollouts (Open source · cluster and runners have costs); GitHub Actions / model registry (Commercial hosted service with free allowances; registry licensing varies)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires an authorized learning cluster with the supported Argo Rollouts controller and your own rollout objects. Replace placeholders. An absent CRD means the controller/API is not installed; do not infer a completed rollout.

Implement completeAiRelease. Create release.json and an evidence table identifying every evaluated artifact and the registry lookup you still need to perform.

Terminal folder: production-ai/13-01-release-bundle

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Require exact SHA-256 identities for code, prompt, dataset and weights plus a named evaluation run. The fixture checks shape and completeness only; artifact existence, access and cryptographic provenance remain separate checks.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement completeAiRelease. Create release.json and an evidence table identifying every evaluated artifact and the registry lookup you still need to perform.

Expected: Accept a complete release

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Reject mutable or missing references; Do not accept malformed manifests

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect evaluation-gated rollout state

Requires an authorized learning cluster with the supported Argo Rollouts controller and your own rollout objects. Replace placeholders. An absent CRD means the controller/API is not installed; do not infer a completed rollout.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get rollouts.argoproj.io
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get analysisruns.argoproj.io
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Retain the actual analysis phase, gate metric and immutable candidate identity. A local function recommendation is separate from a controller action.

Expected: Accept a complete release; Reject mutable or missing references; Do not accept malformed manifests. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require immutable identities and retain the matched evaluation record. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/13-01-release-bundle/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Reviewed changes → immutable release manifest → evaluation run → registry. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A prompt changed after the model evaluation. What should happen? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A mutable alias cannot identify exactly what was evaluated. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A prompt changed after the model evaluation. What should happen?

Interview: A prompt changed after the model evaluation. What should happen? Explain the decision, a failing case and a production limitation.

Quiz: A prompt changed after the model evaluation. What should happen?

Reuse the old score without a version change.

Record a new release identity and evaluate that exact combination.

Change only the visible model label.

Reference: Record a new release identity and evaluate that exact combination. — Record a new release identity and evaluate that exact combination. A well-formed digest does not prove trusted origin or quality. Resolve immutable artifacts through an authenticated registry and bind evaluation results to the complete release manifest.

Sources:

Argo CD: automated sync policy: https://argo-cd.readthedocs.io/en/stable/user-guide/auto_sync/

Argo Rollouts: analysis and rollout gates: https://argoproj.github.io/argo-rollouts/features/analysis/

### Automated eval gates block regressions

Evaluate behavior and latency under comparable conditions before promoting a canary. A high aggregate score cannot excuse a broken output contract. Missing or invalid measurements should hold the decision rather than pass.

The lab requires schema validity of at least 0.99 and P95 TTFT no more than 1.2 times the baseline. Exact boundaries pass. Invalid metrics return hold; valid regressions return rollback. The function never changes a cluster.

These are example thresholds, not universal SLAs. Match sample populations, load, confidence, model configuration and units before applying the comparison. A separate authorized controller executes a recovery decision.

Mental model: Matched evaluation runs → metric validation → promotion or rollback recommendation. Picture the boundary as a checked gate between stages.

Boundary: These are example thresholds, not universal SLAs. Match sample populations, load, confidence, model configuration and units before applying the comparison. A separate authorized controller executes a recovery decision.

Worked example: function evaluateCanaryPromotion(b,c) {
  if(!b || !c || !Number.isFinite(b.p95TtftSeconds) || b.p95TtftSeconds<=0 || !Number.isFinite(c.p95TtftSeconds) || c.p95TtftSeconds<0 || !Number.isFinite(c.schemaValidity) || c.schemaValidity<0 || c.schemaValidity>1) return 'hold';
  return c.schemaValidity<0.99 || c.p95TtftSeconds>b.p95TtftSeconds*1.2 ? 'rollback' : 'promote';
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract llmops-cicd-gitops.zip, install Node.js LTS, then open production-ai/13-02-canary-eval.

Tools for this exercise: JavaScript · local isolated workbench; Argo CD / Argo Rollouts, GitHub Actions / model registry as documented optional extensions

Course tool and framework map: Argo CD / Argo Rollouts (Open source · cluster and runners have costs); GitHub Actions / model registry (Commercial hosted service with free allowances; registry licensing varies)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires an authorized learning cluster with the supported Argo Rollouts controller and your own rollout objects. Replace placeholders. An absent CRD means the controller/API is not installed; do not infer a completed rollout.

Implement evaluateCanaryPromotion. Add an AnalysisTemplate design describing how an authorized controller consumes promote, rollback and hold without treating missing data as success.

Terminal folder: production-ai/13-02-canary-eval

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The lab requires schema validity of at least 0.99 and P95 TTFT no more than 1.2 times the baseline. Exact boundaries pass. Invalid metrics return hold; valid regressions return rollback. The function never changes a cluster.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement evaluateCanaryPromotion. Add an AnalysisTemplate design describing how an authorized controller consumes promote, rollback and hold without treating missing data as success.

Expected: Honor inclusive thresholds

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Block either regression; Hold missing evidence

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect evaluation-gated rollout state

Requires an authorized learning cluster with the supported Argo Rollouts controller and your own rollout objects. Replace placeholders. An absent CRD means the controller/API is not installed; do not infer a completed rollout.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get rollouts.argoproj.io
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get analysisruns.argoproj.io
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Retain the actual analysis phase, gate metric and immutable candidate identity. A local function recommendation is separate from a controller action.

Expected: Honor inclusive thresholds; Block either regression; Hold missing evidence. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require both gates and hold unknown measurements. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/13-02-canary-eval/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Matched evaluation runs → metric validation → promotion or rollback recommendation. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A canary has 98.9% schema validity and faster TTFT under this policy. Promote? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Passing syntax is separate from acceptable latency and answer behavior. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A canary has 98.9% schema validity and faster TTFT under this policy. Promote?

Interview: A canary has 98.9% schema validity and faster TTFT under this policy. Promote? Explain the decision, a failing case and a production limitation.

Quiz: A canary has 98.9% schema validity and faster TTFT under this policy. Promote?

No, both independent gates must pass.

Yes, latency cancels invalid output.

Yes, because 98.9 rounds to 99.

Reference: No, both independent gates must pass. — No, both independent gates must pass. These are example thresholds, not universal SLAs. Match sample populations, load, confidence, model configuration and units before applying the comparison. A separate authorized controller executes a recovery decision.

Sources:

Argo Rollouts: analysis and rollout gates: https://argoproj.github.io/argo-rollouts/features/analysis/

vLLM: production metrics and units: https://docs.vllm.ai/en/latest/usage/metrics/

### Shadow traffic & controlled canary rollout

Shadowing sends a copy for comparison without returning the candidate output to the user. It can still leak data or repeat side effects. Canary traffic serves actual users and needs a distinct allocation and rollback policy.

The fixture allows a shadow request only with approved data use and disabled writes; canary exposure must stay within the approved maximum percentage. Both use a synthetic decision envelope, not an Argo CRD.

Do not replay payments, tool actions or private prompts into a shadow service by default. Native routing, consent, redaction and controller behavior require integration tests.

Mental model: Approved request copy → isolated shadow or bounded canary → comparison. Picture the boundary as a checked gate between stages.

Boundary: Do not replay payments, tool actions or private prompts into a shadow service by default. Native routing, consent, redaction and controller behavior require integration tests.

Worked example: function allowAiRollout(p) {
  if(!p || p.dataApproved!==true) return false;
  if(p.mode==='shadow') return p.writesEnabled===false;
  return p.mode==='canary' && [p.percent,p.maxPercent].every(n=>Number.isFinite(n)&&n>=0&&n<=100) && p.percent<=p.maxPercent;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract llmops-cicd-gitops.zip, install Node.js LTS, then open production-ai/13-03-shadow-canary.

Tools for this exercise: JavaScript · local isolated workbench; Argo CD / Argo Rollouts, GitHub Actions / model registry as documented optional extensions

Course tool and framework map: Argo CD / Argo Rollouts (Open source · cluster and runners have costs); GitHub Actions / model registry (Commercial hosted service with free allowances; registry licensing varies)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires an authorized learning cluster with the supported Argo Rollouts controller and your own rollout objects. Replace placeholders. An absent CRD means the controller/API is not installed; do not infer a completed rollout.

Implement allowAiRollout and write separate shadow and canary acceptance cases, including a rejected side effect and a failed data approval.

Terminal folder: production-ai/13-03-shadow-canary

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture allows a shadow request only with approved data use and disabled writes; canary exposure must stay within the approved maximum percentage. Both use a synthetic decision envelope, not an Argo CRD.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement allowAiRollout and write separate shadow and canary acceptance cases, including a rejected side effect and a failed data approval.

Expected: Allow safe shadowing

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Deny side effects and excess exposure; Validate mode and approval

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect evaluation-gated rollout state

Requires an authorized learning cluster with the supported Argo Rollouts controller and your own rollout objects. Replace placeholders. An absent CRD means the controller/API is not installed; do not infer a completed rollout.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get rollouts.argoproj.io
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get analysisruns.argoproj.io
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Retain the actual analysis phase, gate metric and immutable candidate identity. A local function recommendation is separate from a controller action.

Expected: Allow safe shadowing; Deny side effects and excess exposure; Validate mode and approval. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Disable shadow writes and bound user-serving exposure. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/13-03-shadow-canary/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Approved request copy → isolated shadow or bounded canary → comparison. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Why must a shadowed agent have tool writes disabled? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A copied request must not duplicate a real action. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Why must a shadowed agent have tool writes disabled?

Interview: Why must a shadowed agent have tool writes disabled? Explain the decision, a failing case and a production limitation.

Quiz: Why must a shadowed agent have tool writes disabled?

A shadow copy can repeat real side effects even if its text is hidden.

It cannot consume compute.

Shadow traffic automatically anonymizes every prompt.

Reference: A shadow copy can repeat real side effects even if its text is hidden. — A shadow copy can repeat real side effects even if its text is hidden. Do not replay payments, tool actions or private prompts into a shadow service by default. Native routing, consent, redaction and controller behavior require integration tests.

Sources:

Argo Rollouts: analysis and rollout gates: https://argoproj.github.io/argo-rollouts/features/analysis/

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

### Immutable registries & bounded rollback

Rollback must identify the previous compatible bundle, not just an older image tag. Model, prompt, retrieval schema and application configuration may need to move together. GitOps controllers can revert an imperative cluster edit back to the undesired state.

Choose the newest healthy prior release that matches the current required data-schema contract and differs from the failed digest. The fixture selects an artifact; it does not grant deployment authority or promise instant warmup.

Keep artifacts available, permissions valid and capacity ready. Model loading and incompatible data changes can prevent an instant rollback. Reconcile the authoritative Git state through the approved recovery workflow.

Mental model: Failed canary → retained release catalogue → compatibility check → approved revert. Picture the boundary as a checked gate between stages.

Boundary: Keep artifacts available, permissions valid and capacity ready. Model loading and incompatible data changes can prevent an instant rollback. Reconcile the authoritative Git state through the approved recovery workflow.

Worked example: function selectRollback(releases, failed, schema) {
  if(!Array.isArray(releases) || typeof schema!=='string' || !schema) return null;
  return releases.find(r=>r && /^sha256:[a-f0-9]{64}$/.test(r.digest||'') && r.digest!==failed && r.healthy===true && r.schema===schema)?.digest || null;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract llmops-cicd-gitops.zip, install Node.js LTS, then open production-ai/13-04-immutable-rollback.

Tools for this exercise: JavaScript · local isolated workbench; Argo CD / Argo Rollouts, GitHub Actions / model registry as documented optional extensions

Course tool and framework map: Argo CD / Argo Rollouts (Open source · cluster and runners have costs); GitHub Actions / model registry (Commercial hosted service with free allowances; registry licensing varies)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires an authorized learning cluster with the supported Argo Rollouts controller and your own rollout objects. Replace placeholders. An absent CRD means the controller/API is not installed; do not infer a completed rollout.

Implement selectRollback for a newest-first fixture. Produce a rollback runbook naming the authoritative Git commit, bundle, schema, readiness checks and remaining model-load delay.

Terminal folder: production-ai/13-04-immutable-rollback

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Choose the newest healthy prior release that matches the current required data-schema contract and differs from the failed digest. The fixture selects an artifact; it does not grant deployment authority or promise instant warmup.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement selectRollback for a newest-first fixture. Produce a rollback runbook naming the authoritative Git commit, bundle, schema, readiness checks and remaining model-load delay.

Expected: Select retained compatible artifact

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Reject incompatibility and aliases; Handle absent evidence

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Inspect evaluation-gated rollout state

Requires an authorized learning cluster with the supported Argo Rollouts controller and your own rollout objects. Replace placeholders. An absent CRD means the controller/API is not installed; do not infer a completed rollout.

```
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get rollouts.argoproj.io
kubectl --context YOUR_LEARNING_CONTEXT -n YOUR_LEARNING_NAMESPACE get analysisruns.argoproj.io
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Retain the actual analysis phase, gate metric and immutable candidate identity. A local function recommendation is separate from a controller action.

Expected: Select retained compatible artifact; Reject incompatibility and aliases; Handle absent evidence. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Select a known healthy compatible bundle and rehearse its restoration. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/13-04-immutable-rollback/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Failed canary → retained release catalogue → compatibility check → approved revert. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does an image rollback alone restore a compatible AI release? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: An older release is not necessarily compatible with current persisted data. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does an image rollback alone restore a compatible AI release?

Interview: Does an image rollback alone restore a compatible AI release? Explain the decision, a failing case and a production limitation.

Quiz: Does an image rollback alone restore a compatible AI release?

Always, prompts and schemas do not matter.

Only the visible tag needs changing.

No; restore the compatible evaluated bundle and verify readiness.

Reference: No; restore the compatible evaluated bundle and verify readiness. — No; restore the compatible evaluated bundle and verify readiness. Keep artifacts available, permissions valid and capacity ready. Model loading and incompatible data changes can prevent an instant rollback. Reconcile the authoritative Git state through the approved recovery workflow.

Sources:

Argo CD: automated sync policy: https://argo-cd.readthedocs.io/en/stable/user-guide/auto_sync/

Argo Rollouts: analysis and rollout gates: https://argoproj.github.io/argo-rollouts/features/analysis/
