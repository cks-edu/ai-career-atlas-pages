## intermediate — Conversion and quantization checks

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Target-device programming, model conversion and performance profiling.

### Conversion and quantization checks
Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result.
Mental model: Compressing a photograph may save space while losing details that matter.
Boundary: A smaller model can regress quality or run slower on an unsupported backend.
Worked example: After conversion, compare predictions and error by class, not only whether the runtime loads the file.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: On-device model parity and performance
Export a compact model and prove that on-device optimization preserves acceptable behavior. Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Recall: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. Identify one observation that would contradict your claim.

### Terms
Conversion and quantization checks: Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Export a compact model and prove that on-device optimization preserves acceptable behavior. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Export a compact model and prove that on-device optimization preserves acceptable behavior.
Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.
Deliverables: Exported model and parity tests; Target-device benchmark manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Edge / on-device AI. Use this scenario: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Review: Start with the task and permitted scope. Explain conversion and quantization checks: Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result. Show the input and observed output, then address Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Exported model and parity tests; Target-device benchmark manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

