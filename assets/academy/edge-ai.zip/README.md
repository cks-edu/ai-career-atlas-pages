# Edge / on-device AI

AI Engineering · Beginner → Intermediate → Advanced

Start with Device budgets. Edge AI runs on a local device with limited resources. A model file fitting on disk does not prove it fits in runtime memory. Then try Make a fictional device budget. The three levels build toward On-device model parity and performance. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Device budgets

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Device budgets
Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement.
Mental model: Packing for a bicycle trip differs from packing a moving truck.
Boundary: Hardware accelerators and supported operators vary by device.
Worked example: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A model fits memory but drains the device
The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Two configurations exceed the toy energy budget despite fitting device memory. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Profile on the intended device and compare model size, precision and execution provider.
Recall: Report task quality, warm/cold latency, memory and sustained energy on named hardware. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Device budgets: Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Edge AI runs on a local device with limited resources. A model file fitting on disk does not prove it fits in runtime memory.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Assume 1000 MB of usable memory. Reserve 300 MB for the app and 500 MB for model weights.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A memory budget and a device-test checklist.

3. Try step 2
Calculate the memory remaining for temporary computation and input/output buffers.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A memory budget and a device-test checklist.

4. Try step 3
Write what you would need to measure before deciding the workload can run, including latency and battery use.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A memory budget and a device-test checklist.

5. Explain and check your result
Only 200 MB remains under these assumptions; you do not claim successful execution without measuring peak memory. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A memory budget and a device-test checklist. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Apply this toy-case rule manually: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two configurations exceed the toy energy budget despite fitting device memory. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Edge / on-device AI.
Assume 1000 MB of usable memory. Reserve 300 MB for the app and 500 MB for model weights.
Calculate the memory remaining for temporary computation and input/output buffers.
Write what you would need to measure before deciding the workload can run, including latency and battery use.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A memory budget and a device-test checklist. Include beginner-worksheet.md and your completed On-device performance and quality matrix.
Check: Only 200 MB remains under these assumptions; you do not claim successful execution without measuring peak memory.

### Interview
Explain your beginner solution for Edge / on-device AI. Use this scenario: The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary.
Review: Start with the task and permitted scope. Explain device budgets: Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement. Show the input and observed output, then address Profile on the intended device and compare model size, precision and execution provider. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A memory budget and a device-test checklist. Include beginner-worksheet.md and your completed On-device performance and quality matrix.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Conversion and quantization checks

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Target-device programming, model conversion and performance profiling.

### Conversion and quantization checks
Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result.
Mental model: Compressing a photograph may save space while losing details that matter.
Boundary: A smaller model can regress quality or run slower on an unsupported backend.
Worked example: After conversion, compare predictions and error by class, not only whether the runtime loads the file.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: On-device model parity and performance
Export a compact model and prove that on-device optimization preserves acceptable behavior. Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Recall: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. Identify one observation that would contradict your claim.

### Terms
Conversion and quantization checks: Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Export a compact model and prove that on-device optimization preserves acceptable behavior. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Export a compact model and prove that on-device optimization preserves acceptable behavior.
Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.
Deliverables: Exported model and parity tests; Target-device benchmark manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Edge / on-device AI. Use this scenario: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Review: Start with the task and permitted scope. Explain conversion and quantization checks: Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result. Show the input and observed output, then address Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Exported model and parity tests; Target-device benchmark manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — On-device lifecycle

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### On-device lifecycle
Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network.
Mental model: An offline navigation device needs a usable map and a safe update process.
Boundary: Simulator results do not establish real battery use or thermal behavior.
Worked example: Interrupt a model download in a lab and verify the previous working model remains available after restart.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: On-device model parity and performance
Export a compact model and prove that on-device optimization preserves acceptable behavior. Benchmark warm and cold startup, memory and latency on the target device. Apply supported quantization only with a separate calibration set and re-run quality checks.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Recall: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. Identify one observation that would contradict your claim.

### Terms
On-device lifecycle: Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Export a compact model and prove that on-device optimization preserves acceptable behavior. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Benchmark warm and cold startup, memory and latency on the target device. Apply supported quantization only with a separate calibration set and re-run quality checks.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Export a compact model and prove that on-device optimization preserves acceptable behavior.
Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Benchmark warm and cold startup, memory and latency on the target device. Apply supported quantization only with a separate calibration set and re-run quality checks.
Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.
Add a signed model-update and rollback design without requiring online access for ordinary inference.
Deliverables: Exported model and parity tests; Target-device benchmark manifest; Optimization report and deployment guide. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A reviewer must reproduce one result and identify which capabilities you implemented. Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

### Interview
Explain your advanced solution for Edge / on-device AI. Use this scenario: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Review: Start with the task and permitted scope. Explain on-device lifecycle: Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network. Show the input and observed output, then address Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Exported model and parity tests; Target-device benchmark manifest; Optimization report and deployment guide. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
ONNX Runtime — Open source
Local exported-model inference and parity checks.
Alternative: Native framework inference or platform runtimes such as Core ML; supported operators and devices differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
ONNX Runtime: https://onnxruntime.ai/docs/
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html
