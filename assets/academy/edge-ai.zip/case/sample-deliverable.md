# SAMPLE — On-device performance and quality matrix
Role: Edge / on-device AI
Case: A model fits memory but drains the device
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary.

## Evidence table
| Record | energy_per_task (millijoules) | Decision |
|---|---:|---|
| case-1 | 200 | within_demo_bound |
| case-2 | 500 | within_demo_bound |
| case-3 | 510 | review |
| case-4 | 900 | review |
| case-5 | 350 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two configurations exceed the toy energy budget despite fitting device memory.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Profile on the intended device and compare model size, precision and execution provider.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in edge / on-device ai.
Before release: Report task quality, warm/cold latency, memory and sustained energy on named hardware.

## Design choice and trade-off
Treat hardware, operator support and update recovery as design constraints; preserve an offline fallback.
A smaller model may save energy while lowering quality; measure cost per accepted task rather than inference alone.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Offline image classifier: Results name the hardware and accuracy/latency trade-off.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
