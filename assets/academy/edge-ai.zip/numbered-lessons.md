# Edge / on-device AI — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Device budgets: Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

### Device budgets

Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement. In this role, work through: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Packing for a bicycle trip differs from packing a moving truck.

Boundary: Hardware accelerators and supported operators vary by device.

Worked example: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: ONNX Runtime (Open source); scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Edge / on-device AI: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness.

Predict the worked case

Read this case without running a tool: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in device budgets.

Connect the concept to the role

Apply this rule: Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Hardware accelerators and supported operators vary by device.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies device budgets to this case: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Device budgets; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with device budgets. Use the glossary below, then write your prediction for: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Edge / on-device AI role interview. Explain device budgets using this case: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate device budgets to a system or workflow you know. Explain device budgets using this case: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain device budgets using this case: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness.

Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement. — Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement. Hardware accelerators and supported operators vary by device.

Sources:

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

### Diagnose: A model fits memory but drains the device

The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Two configurations exceed the toy energy budget despite fitting device memory. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Profile on the intended device and compare model size, precision and execution provider. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Packing for a bicycle trip differs from packing a moving truck.

A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness.

Worked example: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Profile on the intended device and compare model size, precision and execution provider.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: ONNX Runtime (Open source); scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Two configurations exceed the toy energy budget despite fitting device memory. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Apply this toy-case rule manually: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Edge AI runs on a local device with limited resources. A model file fitting on disk does not prove it fits in runtime memory.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Assume 1000 MB of usable memory. Reserve 300 MB for the app and 500 MB for model weights.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A memory budget and a device-test checklist.

Preparation · Try step 2

Calculate the memory remaining for temporary computation and input/output buffers.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A memory budget and a device-test checklist.

Preparation · Try step 3

Write what you would need to measure before deciding the workload can run, including latency and battery use.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A memory budget and a device-test checklist.

Preparation · Explain and check your result

Only 200 MB remains under these assumptions; you do not claim successful execution without measuring peak memory. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A memory budget and a device-test checklist. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Apply this toy-case rule manually: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two configurations exceed the toy energy budget despite fitting device memory. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two configurations exceed the toy energy budget despite fitting device memory. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a model fits memory but drains the device. Use the glossary below, then write your prediction for: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Profile on the intended device and compare model size, precision and execution provider. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Edge / on-device AI role interview. Explain diagnose: a model fits memory but drains the device using this case: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Profile on the intended device and compare model size, precision and execution provider. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a model fits memory but drains the device to a system or workflow you know. Explain diagnose: a model fits memory but drains the device using this case: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Profile on the intended device and compare model size, precision and execution provider. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task quality, warm/cold latency, memory and sustained energy on named hardware. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a model fits memory but drains the device using this case: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Profile on the intended device and compare model size, precision and execution provider. State the evidence, one alternative and where the mental model stops.

Quiz: A model fits memory but drains the device: The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary.

Change the acceptance rule after seeing an inconvenient result.

Profile on the intended device and compare model size, precision and execution provider.

Omit failed cases and report only the successful demonstrations.

Reference: Profile on the intended device and compare model size, precision and execution provider. — Profile on the intended device and compare model size, precision and execution provider. Report task quality, warm/cold latency, memory and sustained energy on named hardware.

Sources:

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Target-device programming, model conversion and performance profiling.

Terms:

Conversion and quantization checks: Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### Conversion and quantization checks

Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result. In this role, work through: After conversion, compare predictions and error by class, not only whether the runtime loads the file. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Compressing a photograph may save space while losing details that matter.

Boundary: A smaller model can regress quality or run slower on an unsupported backend.

Worked example: After conversion, compare predictions and error by class, not only whether the runtime loads the file.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Target-device programming, model conversion and performance profiling.

Tools for this exercise: Document or text editor

Course tool and framework map: ONNX Runtime (Open source); scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Edge / on-device AI: After conversion, compare predictions and error by class, not only whether the runtime loads the file.

Predict the worked case

Read this case without running a tool: After conversion, compare predictions and error by class, not only whether the runtime loads the file. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in conversion and quantization checks.

Connect the concept to the role

Apply this rule: Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A smaller model can regress quality or run slower on an unsupported backend.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies conversion and quantization checks to this case: After conversion, compare predictions and error by class, not only whether the runtime loads the file. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After conversion, compare predictions and error by class, not only whether the runtime loads the file. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Conversion and quantization checks; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with conversion and quantization checks. Use the glossary below, then write your prediction for: After conversion, compare predictions and error by class, not only whether the runtime loads the file. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Edge / on-device AI role interview. Explain conversion and quantization checks using this case: After conversion, compare predictions and error by class, not only whether the runtime loads the file. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate conversion and quantization checks to a system or workflow you know. Explain conversion and quantization checks using this case: After conversion, compare predictions and error by class, not only whether the runtime loads the file. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain conversion and quantization checks using this case: After conversion, compare predictions and error by class, not only whether the runtime loads the file. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? After conversion, compare predictions and error by class, not only whether the runtime loads the file.

Treat a passing starter as proof of the whole role workflow.

Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result.

Ignore the failure because the tool produced an output.

Reference: Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result. — Compare converted or quantized models with a reference on representative inputs. Inspect numerical differences and unsupported operations before timing the result. A smaller model can regress quality or run slower on an unsupported backend.

Sources:

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

### Integrate: On-device model parity and performance

Export a compact model and prove that on-device optimization preserves acceptable behavior. Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model. In this role, work through: Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: Compressing a photograph may save space while losing details that matter.

After conversion, compare predictions and error by class, not only whether the runtime loads the file.

Worked example: Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: ONNX Runtime (Open source); scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent)

Export a compact model and prove that on-device optimization preserves acceptable behavior. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Export a compact model and prove that on-device optimization preserves acceptable behavior.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-intermediate-2.md: Exported model and parity tests; Target-device benchmark manifest. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: on-device model parity and performance. Use the glossary below, then write your prediction for: Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Edge / on-device AI role interview. Explain integrate: on-device model parity and performance using this case: Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: on-device model parity and performance to a system or workflow you know. Explain integrate: on-device model parity and performance using this case: Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. Identify one observation that would contradict your claim.

Interview: Explain integrate: on-device model parity and performance using this case: Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate On-device model parity and performance at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.

Reference: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. — Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.

Sources:

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

On-device lifecycle: Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### On-device lifecycle

Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network. In this role, work through: Interrupt a model download in a lab and verify the previous working model remains available after restart. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An offline navigation device needs a usable map and a safe update process.

Boundary: Simulator results do not establish real battery use or thermal behavior.

Worked example: Interrupt a model download in a lab and verify the previous working model remains available after restart.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: ONNX Runtime (Open source); scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Edge / on-device AI: Interrupt a model download in a lab and verify the previous working model remains available after restart.

Predict the worked case

Read this case without running a tool: Interrupt a model download in a lab and verify the previous working model remains available after restart. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in on-device lifecycle.

Connect the concept to the role

Apply this rule: Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Simulator results do not establish real battery use or thermal behavior.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies on-device lifecycle to this case: Interrupt a model download in a lab and verify the previous working model remains available after restart. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Interrupt a model download in a lab and verify the previous working model remains available after restart. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for On-device lifecycle; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with on-device lifecycle. Use the glossary below, then write your prediction for: Interrupt a model download in a lab and verify the previous working model remains available after restart. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Edge / on-device AI role interview. Explain on-device lifecycle using this case: Interrupt a model download in a lab and verify the previous working model remains available after restart. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate on-device lifecycle to a system or workflow you know. Explain on-device lifecycle using this case: Interrupt a model download in a lab and verify the previous working model remains available after restart. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain on-device lifecycle using this case: Interrupt a model download in a lab and verify the previous working model remains available after restart. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Interrupt a model download in a lab and verify the previous working model remains available after restart.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network.

Reference: Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network. — Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network. Simulator results do not establish real battery use or thermal behavior.

Sources:

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html

### Defend: On-device model parity and performance

Export a compact model and prove that on-device optimization preserves acceptable behavior. Benchmark warm and cold startup, memory and latency on the target device. Apply supported quantization only with a separate calibration set and re-run quality checks. In this role, work through: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: An offline navigation device needs a usable map and a safe update process.

Interrupt a model download in a lab and verify the previous working model remains available after restart.

Worked example: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: ONNX Runtime (Open source); scikit-learn (Open source · CPU); PyTorch (Open source · hardware dependent)

Export a compact model and prove that on-device optimization preserves acceptable behavior. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Export a compact model and prove that on-device optimization preserves acceptable behavior.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Benchmark warm and cold startup, memory and latency on the target device. Apply supported quantization only with a separate calibration set and re-run quality checks.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A reviewer must reproduce one result and identify which capabilities you implemented. Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-advanced-2.md: Exported model and parity tests; Target-device benchmark manifest; Optimization report and deployment guide. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: on-device model parity and performance. Use the glossary below, then write your prediction for: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Edge / on-device AI role interview. Explain defend: on-device model parity and performance using this case: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: on-device model parity and performance to a system or workflow you know. Explain defend: on-device model parity and performance using this case: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. Identify one observation that would contradict your claim.

Interview: Explain defend: on-device model parity and performance using this case: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate On-device model parity and performance at this level?

Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets. — Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets. Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.

Sources:

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html
