# Exported model and parity tests

Project: On-device model parity and performance
Status: blank work product — not completed evidence

## Purpose and audience
Export a compact model and prove that on-device optimization preserves acceptable behavior.

## Required content
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.

## Failure evidence
Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
