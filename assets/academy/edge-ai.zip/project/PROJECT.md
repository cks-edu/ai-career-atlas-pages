# On-device model parity and performance

Career: Edge / on-device AI
Reviewed: 2026-10-22

Export a compact model and prove that on-device optimization preserves acceptable behavior.

## Prerequisites
Target-device programming, model conversion and performance profiling.

## Included starter versus your implementation
A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Benchmark warm and cold startup, memory and latency on the target device. Apply supported quantization only with a separate calibration set and re-run quality checks.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Exported model and parity tests — artifact-1.md
2. Target-device benchmark manifest — artifact-2.md
3. Optimization report and deployment guide — artifact-3.md

## Troubleshooting
- Poor metrics: inspect class balance and split construction before tuning.
- Too-good metrics: check duplicate groups and target-derived features.
- Changed results: compare package versions, seeds and preprocessing.

## Extension
Add a signed model-update and rollback design without requiring online access for ordinary inference.

## Primary learning resources
- ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html — Open source; Local exported-model inference and parity checks.
- scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html — Open source · CPU; Pipelines, baselines, data splits and statistical evaluation.
- PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html — Open source · hardware dependent; Tensor operations, training and hardware-aware profiling.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
