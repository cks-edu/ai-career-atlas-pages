# Export and parity route

After implementing the saved training pipeline, install compatible versions of `skl2onnx` and `onnxruntime`. Follow the linked ONNX Runtime conversion example with the exact feature count and float32 input. Save preprocessing inside the exported pipeline where supported.

```sh
python -m pip install skl2onnx onnxruntime
```

Create `export_model.py` and `test_parity.py` as your implementation tasks. Compare label and probability outputs on the held-out batch; do not claim the conversion is complete merely because an ONNX file loads.
