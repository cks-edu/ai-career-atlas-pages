# Target-device benchmark manifest

Project: On-device model parity and performance
Status: blank work product — not completed evidence

## Purpose and audience
Export a compact model and prove that on-device optimization preserves acceptable behavior.

## Required content
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.

## Failure evidence
Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
