# On-device model parity and performance

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Export a compact model and prove that on-device optimization preserves acceptable behavior.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

## Limitations and next iteration
Add a signed model-update and rollback design without requiring online access for ordinary inference.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
