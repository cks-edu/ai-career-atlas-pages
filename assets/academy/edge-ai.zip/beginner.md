## beginner — Device budgets

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Device budgets
Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement.
Mental model: Packing for a bicycle trip differs from packing a moving truck.
Boundary: Hardware accelerators and supported operators vary by device.
Worked example: A model fits on a laptop but exceeds the phone's memory budget; record both environments and reduce the candidate before claiming readiness.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A model fits memory but drains the device
The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Two configurations exceed the toy energy budget despite fitting device memory. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Profile on the intended device and compare model size, precision and execution provider.
Recall: Report task quality, warm/cold latency, memory and sustained energy on named hardware. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Device budgets: Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Edge AI runs on a local device with limited resources. A model file fitting on disk does not prove it fits in runtime memory.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Assume 1000 MB of usable memory. Reserve 300 MB for the app and 500 MB for model weights.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A memory budget and a device-test checklist.

3. Try step 2
Calculate the memory remaining for temporary computation and input/output buffers.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A memory budget and a device-test checklist.

4. Try step 3
Write what you would need to measure before deciding the workload can run, including latency and battery use.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A memory budget and a device-test checklist.

5. Explain and check your result
Only 200 MB remains under these assumptions; you do not claim successful execution without measuring peak memory. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A memory budget and a device-test checklist. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary. Apply this toy-case rule manually: Review when energy_per_task > 500 (millijoules). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two configurations exceed the toy energy budget despite fitting device memory. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Edge / on-device AI.
Assume 1000 MB of usable memory. Reserve 300 MB for the app and 500 MB for model weights.
Calculate the memory remaining for temporary computation and input/output buffers.
Write what you would need to measure before deciding the workload can run, including latency and battery use.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A memory budget and a device-test checklist. Include beginner-worksheet.md and your completed On-device performance and quality matrix.
Check: Only 200 MB remains under these assumptions; you do not claim successful execution without measuring peak memory.

### Interview
Explain your beginner solution for Edge / on-device AI. Use this scenario: The device trial flags sustained inference consuming more than 500 mJ per accepted task under the stated measurement boundary.
Review: Start with the task and permitted scope. Explain device budgets: Specify memory, latency, power, storage and offline requirements on the actual target class. A desktop result is a starting point, not a device measurement. Show the input and observed output, then address Profile on the intended device and compare model size, precision and execution provider. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A memory budget and a device-test checklist. Include beginner-worksheet.md and your completed On-device performance and quality matrix.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

