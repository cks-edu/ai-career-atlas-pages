## advanced — On-device lifecycle

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### On-device lifecycle
Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network.
Mental model: An offline navigation device needs a usable map and a safe update process.
Boundary: Simulator results do not establish real battery use or thermal behavior.
Worked example: Interrupt a model download in a lab and verify the previous working model remains available after restart.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: On-device model parity and performance
Export a compact model and prove that on-device optimization preserves acceptable behavior. Benchmark warm and cold startup, memory and latency on the target device. Apply supported quantization only with a separate calibration set and re-run quality checks.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Recall: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. Identify one observation that would contradict your claim.

### Terms
On-device lifecycle: Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
quantization: Representing values with lower precision to change memory or compute needs; test resulting quality and runtime support.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Export a compact model and prove that on-device optimization preserves acceptable behavior. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Benchmark warm and cold startup, memory and latency on the target device. Apply supported quantization only with a separate calibration set and re-run quality checks.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Export a compact model and prove that on-device optimization preserves acceptable behavior.
Use the supplied classifier baseline and a fixed representative input batch. Record device, runtime, thread settings and intended offline constraints.
Train the baseline and export a supported estimator using skl2onnx or export a PyTorch model through its supported ONNX path. Save feature order and preprocessing with the artifact.
Run ONNX Runtime on the same fixed inputs and compare labels/probabilities within a justified tolerance. Reject incompatible operators rather than silently changing the model.
Benchmark warm and cold startup, memory and latency on the target device. Apply supported quantization only with a separate calibration set and re-run quality checks.
Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller.
Add a signed model-update and rollback design without requiring online access for ordinary inference.
Deliverables: Exported model and parity tests; Target-device benchmark manifest; Optimization report and deployment guide. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A reviewer must reproduce one result and identify which capabilities you implemented. Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.

### Interview
Explain your advanced solution for Edge / on-device AI. Use this scenario: Change the input shape or feature order and test offline startup with no network. The application must reject incompatible inputs and load only bundled assets.
Review: Start with the task and permitted scope. Explain on-device lifecycle: Measure cold start, repeated inference and recovery under realistic constraints. Plan model updates, rollback and data handling without assuming a constant network. Show the input and observed output, then address Report parity failures, quality change, artifact size and device-specific latency. Desktop CPU timing is not evidence for a phone or microcontroller. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Exported model and parity tests; Target-device benchmark manifest; Optimization report and deployment guide. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

