# Kubernetes / Container Platform Engineer

Software Engineering

Start with workload and service selectors. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward Kubernetes operations runbook and rollout evidence.

## beginner

Deploy the provided manifest in kind, inspect Pods and EndpointSlices, then change a copy's selector to a wrong value. Observe endpoints, repair it and verify HTTP through port-forward.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Desired state
A controller compares the current system with a declared target and works to reconcile the difference.
Mental model: A thermostat compares actual temperature with the set point.
Limit: It cannot fix every cause: a missing image or insufficient resources still needs action.
Example: One replica means the controller tries to keep one Pod running.
Recall: What happens when a Pod is deleted but its Deployment remains?

### Workload and Service selectors
A Deployment manages Pods while a Service selects endpoints by labels. Running Pods do not guarantee traffic routing if labels or ports disagree.
Mental model: A switchboard can route calls only to extensions listed under the correct department.
Limit: Inspect selector labels and targetPort before restarting healthy Pods.
Example: A Service selector app=wrong finds no matching workload even while the Pod runs.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Inspect selector labels and targetPort before restarting healthy Pods.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
A Service selector app=wrong finds no matching workload even while the Pod runs. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Deploy the provided manifest in kind, inspect Pods and EndpointSlices, then change a copy's selector to a wrong value. Observe endpoints, repair it and verify HTTP through port-forward.
Expected: Empty endpoints for the broken selector and working routing after repair.

6. Role workshop · debug and verify
Inspect selector labels and targetPort before restarting healthy Pods. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save manifest diff and routing diagnostic transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Empty endpoints for the broken selector and working routing after repair.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Workload and Service selectors: Inspect selector labels and targetPort before restarting healthy Pods.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: manifest diff and routing diagnostic transcript
Empty endpoints for the broken selector and working routing after repair.

Interview: Work through this Kubernetes / Container Platform Engineer case: A Service selector app=wrong finds no matching workload even while the Pod runs. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A Deployment manages Pods while a Service selects endpoints by labels. Running Pods do not guarantee traffic routing if labels or ports disagree. Expected evidence: Empty endpoints for the broken selector and working routing after repair. Diagnosis: Inspect selector labels and targetPort before restarting healthy Pods. State the limits of the mental model: A switchboard can route calls only to extensions listed under the correct department.

Resume: Built manifest diff and routing diagnostic transcript using Kubernetes, kind, kubectl and container runtimes; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create one failure at a time in the lab: overlarge request, then wrong probe port. Use describe/events to identify each cause and restore the working values.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Readiness and routing
Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.
Mental model: A shop can have lights on but still be closed to customers.
Limit: A health endpoint can be too shallow; it must reflect the service contract.
Example: This container listens on 8080; the Service accepts 80 and forwards to 8080.
Recall: Explain why a Running Pod might still receive no traffic.

### Scheduling, requests and probes
Requests affect scheduling and readiness controls traffic eligibility. A probe should reflect the service contract without causing avoidable cascading failure.
Mental model: A shop needs floor space before opening and a readiness sign before accepting customers.
Limit: Increasing replicas does not repair a probe aimed at the wrong port.
Example: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Increasing replicas does not repair a probe aimed at the wrong port.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

3. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

4. Role workshop · predict
An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create one failure at a time in the lab: overlarge request, then wrong probe port. Use describe/events to identify each cause and restore the working values.
Expected: Distinct evidence for unschedulable versus unready states.

6. Role workshop · debug and verify
Increasing replicas does not repair a probe aimed at the wrong port. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save scheduling/probe failure matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Distinct evidence for unschedulable versus unready states.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Scheduling, requests and probes: Increasing replicas does not repair a probe aimed at the wrong port.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: scheduling/probe failure matrix
Distinct evidence for unschedulable versus unready states.

Interview: Work through this Kubernetes / Container Platform Engineer case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Requests affect scheduling and readiness controls traffic eligibility. A probe should reflect the service contract without causing avoidable cascading failure. Expected evidence: Distinct evidence for unschedulable versus unready states. Diagnosis: Increasing replicas does not repair a probe aimed at the wrong port. State the limits of the mental model: A shop needs floor space before opening and a readiness sign before accepting customers.

Resume: Built scheduling/probe failure matrix using Kubernetes, kind, kubectl and container runtimes; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Inspect rollout strategy, rehearse a nonexistent image and undo it. Design a two-replica maintenance exercise with readiness and capacity checks; document what the single-node lab cannot demonstrate.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Rollback and service objectives
A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.
Mental model: A reversible road detour with traffic counters at both ends.
Limit: A rollback may not undo database changes; release safety includes schema compatibility.
Example: Change the image to a nonexistent tag, inspect events and undo the rollout.
Recall: Which checks must pass after undoing a bad image?

### Disruption and rollout recovery
Rolling updates, disruption budgets and capacity interact. A budget cannot create spare capacity or guarantee protection from every kind of failure.
Mental model: Keeping a minimum number of shop counters open requires enough staff and room.
Limit: A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages.
Example: A rollout with no spare capacity can stall even with a healthy old replica.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages.

1. Create the isolated local baseline
Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.
```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Deployment successfully rolled out; one healthy replica.

2. Observe routing
Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

3. Rehearse a failed release
Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.
```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

4. Role workshop · predict
A rollout with no spare capacity can stall even with a healthy old replica. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Inspect rollout strategy, rehearse a nonexistent image and undo it. Design a two-replica maintenance exercise with readiness and capacity checks; document what the single-node lab cannot demonstrate.
Expected: A recovered rollout and a realistic disruption plan.

6. Role workshop · debug and verify
A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Kubernetes operations runbook and rollout evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A recovered rollout and a realistic disruption plan.

Troubleshooting:
Cannot connect to Docker: Start your local Docker engine. Verify docker info before creating the cluster.
Image pull fails: Read Pod events; verify the exact image/tag and network access. Do not disable TLS verification.
Port forwarding refuses connection: Check rollout readiness and that port 8136 is free. Keep the port-forward process open.
A command targets the wrong cluster: Every command here explicitly uses kind-atlas-course. Do not remove the context argument when other clusters are configured.
Disruption and rollout recovery: A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages.
Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Portfolio: Kubernetes operations runbook and rollout evidence
A recovered rollout and a realistic disruption plan.

Interview: Work through this Kubernetes / Container Platform Engineer case: A rollout with no spare capacity can stall even with a healthy old replica. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Rolling updates, disruption budgets and capacity interact. A budget cannot create spare capacity or guarantee protection from every kind of failure. Expected evidence: A recovered rollout and a realistic disruption plan. Diagnosis: A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages. State the limits of the mental model: Keeping a minimum number of shop counters open requires enough staff and room.

Resume: Built Kubernetes operations runbook and rollout evidence using Kubernetes, kind, kubectl and container runtimes; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/
kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/
Docker: installation and getting started: https://docs.docker.com/get-started/
Google SRE book: https://sre.google/sre-book/table-of-contents/
Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/
