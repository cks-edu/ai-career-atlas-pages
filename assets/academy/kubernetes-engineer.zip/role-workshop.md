# Kubernetes / Container Platform Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Workload and Service selectors

A Deployment manages Pods while a Service selects endpoints by labels. Running Pods do not guarantee traffic routing if labels or ports disagree.
Mental model: A switchboard can route calls only to extensions listed under the correct department.
Case: A Service selector app=wrong finds no matching workload even while the Pod runs.
Task: Deploy the provided manifest in kind, inspect Pods and EndpointSlices, then change a copy's selector to a wrong value. Observe endpoints, repair it and verify HTTP through port-forward.
Acceptance: Empty endpoints for the broken selector and working routing after repair.
Troubleshooting: Inspect selector labels and targetPort before restarting healthy Pods.
Deliverable: manifest diff and routing diagnostic transcript

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Scheduling, requests and probes

Requests affect scheduling and readiness controls traffic eligibility. A probe should reflect the service contract without causing avoidable cascading failure.
Mental model: A shop needs floor space before opening and a readiness sign before accepting customers.
Case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready.
Task: Create one failure at a time in the lab: overlarge request, then wrong probe port. Use describe/events to identify each cause and restore the working values.
Acceptance: Distinct evidence for unschedulable versus unready states.
Troubleshooting: Increasing replicas does not repair a probe aimed at the wrong port.
Deliverable: scheduling/probe failure matrix

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Disruption and rollout recovery

Rolling updates, disruption budgets and capacity interact. A budget cannot create spare capacity or guarantee protection from every kind of failure.
Mental model: Keeping a minimum number of shop counters open requires enough staff and room.
Case: A rollout with no spare capacity can stall even with a healthy old replica.
Task: Inspect rollout strategy, rehearse a nonexistent image and undo it. Design a two-replica maintenance exercise with readiness and capacity checks; document what the single-node lab cannot demonstrate.
Acceptance: A recovered rollout and a realistic disruption plan.
Troubleshooting: A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages.
Deliverable: Kubernetes operations runbook and rollout evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
