# Kubernetes / Container Platform Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Desired state: A controller compares the current system with a declared target and works to reconcile the difference.

Apply desired state in Kubernetes / Container Platform Engineer: Use the concept to complete this role exercise: Explain Deployment, Pod and Service using the local lab

Workload and Service selectors: A Deployment manages Pods while a Service selects endpoints by labels. Running Pods do not guarantee traffic routing if labels or ports disagree.

### Desired state

A controller compares the current system with a declared target and works to reconcile the difference. In this role, work through: A Service selector app=wrong finds no matching workload even while the Pod runs. The practical workshop develops this into: Deploy the provided manifest in kind, inspect Pods and EndpointSlices, then change a copy's selector to a wrong value. Observe endpoints, repair it and verify HTTP through port-forward.

Mental model: A thermostat compares actual temperature with the set point.

Boundary: It cannot fix every cause: a missing image or insufficient resources still needs action.

Role application: A switchboard can route calls only to extensions listed under the correct department.

A Deployment manages Pods while a Service selects endpoints by labels. Running Pods do not guarantee traffic routing if labels or ports disagree.

Worked example: A Service selector app=wrong finds no matching workload even while the Pod runs.

Shared foundation example: One replica means the controller tries to keep one Pod running.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Kubernetes, kind, kubectl and container runtimes (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Kubernetes / Container Platform Engineer: A Service selector app=wrong finds no matching workload even while the Pod runs.

Predict the worked case

Read this case without running a tool: A Service selector app=wrong finds no matching workload even while the Pod runs. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in desired state.

Connect the concept to the role

Apply this rule: A controller compares the current system with a declared target and works to reconcile the difference. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: It cannot fix every cause: a missing image or insufficient resources still needs action.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies desired state to this case: A Service selector app=wrong finds no matching workload even while the Pod runs. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A Service selector app=wrong finds no matching workload even while the Pod runs. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Desired state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with desired state. Use the glossary below, then write your prediction for: A Service selector app=wrong finds no matching workload even while the Pod runs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Kubernetes / Container Platform Engineer role interview. Explain desired state using this case: A Service selector app=wrong finds no matching workload even while the Pod runs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate desired state to a system or workflow you know. Explain desired state using this case: A Service selector app=wrong finds no matching workload even while the Pod runs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens when a Pod is deleted but its Deployment remains?

Interview: Explain desired state using this case: A Service selector app=wrong finds no matching workload even while the Pod runs. State the evidence, one alternative and where the mental model stops.

Quiz: After the Workload and Service selectors rehearsal, check this foundation: A controller is told to run two replicas, but only one is ready. What does the declared target mean?

The controller attempts reconciliation; it is not a guarantee that both are healthy now.

Two healthy replicas must already exist.

The current replica count becomes the new desired target automatically.

Reference: The controller attempts reconciliation; it is not a guarantee that both are healthy now. — Desired and observed state differ during convergence or failure. Inspect readiness, events and constraints.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Workload and Service selectors

A Deployment manages Pods while a Service selects endpoints by labels. Running Pods do not guarantee traffic routing if labels or ports disagree. In this role, work through: A Service selector app=wrong finds no matching workload even while the Pod runs. The practical workshop develops this into: Deploy the provided manifest in kind, inspect Pods and EndpointSlices, then change a copy's selector to a wrong value. Observe endpoints, repair it and verify HTTP through port-forward.

Mental model: A switchboard can route calls only to extensions listed under the correct department.

Boundary: Inspect selector labels and targetPort before restarting healthy Pods.

Worked example: A Service selector app=wrong finds no matching workload even while the Pod runs.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Kubernetes, kind, kubectl and container runtimes (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Kubernetes / Container Platform Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Deploy the provided manifest in kind, inspect Pods and EndpointSlices, then change a copy's selector to a wrong value. Observe endpoints, repair it and verify HTTP through port-forward.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

A Service selector app=wrong finds no matching workload even while the Pod runs. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Deploy the provided manifest in kind, inspect Pods and EndpointSlices, then change a copy's selector to a wrong value. Observe endpoints, repair it and verify HTTP through port-forward.

Expected: Empty endpoints for the broken selector and working routing after repair.

Role workshop · debug and verify

Inspect selector labels and targetPort before restarting healthy Pods. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save manifest diff and routing diagnostic transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Empty endpoints for the broken selector and working routing after repair.

Expected: Empty endpoints for the broken selector and working routing after repair.

Troubleshoot: The role exercise differs from the prediction: Inspect selector labels and targetPort before restarting healthy Pods.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-beginner-2.md: manifest diff and routing diagnostic transcript; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with workload and service selectors. Use the glossary below, then write your prediction for: A Service selector app=wrong finds no matching workload even while the Pod runs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Kubernetes / Container Platform Engineer role interview. Explain workload and service selectors using this case: A Service selector app=wrong finds no matching workload even while the Pod runs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate workload and service selectors to a system or workflow you know. Explain workload and service selectors using this case: A Service selector app=wrong finds no matching workload even while the Pod runs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Inspect selector labels and targetPort before restarting healthy Pods.

Interview: Explain workload and service selectors using this case: A Service selector app=wrong finds no matching workload even while the Pod runs. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A Service selector app=wrong finds no matching workload even while the Pod runs.

Empty endpoints for the broken selector and working routing after repair.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Empty endpoints for the broken selector and working routing after repair. — A Deployment manages Pods while a Service selects endpoints by labels. Running Pods do not guarantee traffic routing if labels or ports disagree. Empty endpoints for the broken selector and working routing after repair.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Readiness and routing: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on.

Apply readiness and routing in Kubernetes / Container Platform Engineer: Use the concept to complete this role exercise: Diagnose scheduling, readiness, image and networking failures

Scheduling, requests and probes: Requests affect scheduling and readiness controls traffic eligibility. A probe should reflect the service contract without causing avoidable cascading failure.

### Readiness and routing

Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. In this role, work through: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. The practical workshop develops this into: Create one failure at a time in the lab: overlarge request, then wrong probe port. Use describe/events to identify each cause and restore the working values.

Mental model: A shop can have lights on but still be closed to customers.

Boundary: A health endpoint can be too shallow; it must reflect the service contract.

Role application: A shop needs floor space before opening and a readiness sign before accepting customers.

Requests affect scheduling and readiness controls traffic eligibility. A probe should reflect the service contract without causing avoidable cascading failure.

Worked example: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready.

Shared foundation example: This container listens on 8080; the Service accepts 80 and forwards to 8080.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Kubernetes, kind, kubectl and container runtimes (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Kubernetes / Container Platform Engineer: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready.

Predict the worked case

Read this case without running a tool: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in readiness and routing.

Connect the concept to the role

Apply this rule: Readiness describes whether a workload should receive traffic. Routing must point to the port the process actually listens on. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A health endpoint can be too shallow; it must reflect the service contract.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies readiness and routing to this case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Readiness and routing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with readiness and routing. Use the glossary below, then write your prediction for: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Kubernetes / Container Platform Engineer role interview. Explain readiness and routing using this case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate readiness and routing to a system or workflow you know. Explain readiness and routing using this case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain why a Running Pod might still receive no traffic.

Interview: Explain readiness and routing using this case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. State the evidence, one alternative and where the mental model stops.

Quiz: After the Scheduling, requests and probes rehearsal, check this foundation: A process listens on 8080. A Service accepts 80. Which target port should route to that listener?

80 because the Service port must equal the application port.

8080, matching the actual application listener.

443 because readiness always implies TLS.

Reference: 8080, matching the actual application listener. — Service and target ports can differ. Readiness must also reflect whether the workload can serve traffic.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Scheduling, requests and probes

Requests affect scheduling and readiness controls traffic eligibility. A probe should reflect the service contract without causing avoidable cascading failure. In this role, work through: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. The practical workshop develops this into: Create one failure at a time in the lab: overlarge request, then wrong probe port. Use describe/events to identify each cause and restore the working values.

Mental model: A shop needs floor space before opening and a readiness sign before accepting customers.

Boundary: Increasing replicas does not repair a probe aimed at the wrong port.

Worked example: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Kubernetes, kind, kubectl and container runtimes (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Kubernetes / Container Platform Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create one failure at a time in the lab: overlarge request, then wrong probe port. Use describe/events to identify each cause and restore the working values.

Read the declared configuration

Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.

Expected: A written prediction that you can compare with the actual result.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Role workshop · predict

An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create one failure at a time in the lab: overlarge request, then wrong probe port. Use describe/events to identify each cause and restore the working values.

Expected: Distinct evidence for unschedulable versus unready states.

Role workshop · debug and verify

Increasing replicas does not repair a probe aimed at the wrong port. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save scheduling/probe failure matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Distinct evidence for unschedulable versus unready states.

Expected: Distinct evidence for unschedulable versus unready states.

Troubleshoot: The role exercise differs from the prediction: Increasing replicas does not repair a probe aimed at the wrong port.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-intermediate-2.md: scheduling/probe failure matrix; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with scheduling, requests and probes. Use the glossary below, then write your prediction for: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Kubernetes / Container Platform Engineer role interview. Explain scheduling, requests and probes using this case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate scheduling, requests and probes to a system or workflow you know. Explain scheduling, requests and probes using this case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Increasing replicas does not repair a probe aimed at the wrong port.

Interview: Explain scheduling, requests and probes using this case: An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? An excessive memory request can leave a Pod Pending; a wrong readiness port leaves it unready.

Ignore the failing case and keep only the successful screenshot.

Distinct evidence for unschedulable versus unready states.

Treat any successful command as proof that all business and access rules passed.

Reference: Distinct evidence for unschedulable versus unready states. — Requests affect scheduling and readiness controls traffic eligibility. A probe should reflect the service contract without causing avoidable cascading failure. Distinct evidence for unschedulable versus unready states.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Rollback and service objectives: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path.

Apply rollback and service objectives in Kubernetes / Container Platform Engineer: Use the concept to complete this role exercise: Design cluster upgrades, tenancy, backup and recovery validation

Disruption and rollout recovery: Rolling updates, disruption budgets and capacity interact. A budget cannot create spare capacity or guarantee protection from every kind of failure.

### Rollback and service objectives

A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. In this role, work through: A rollout with no spare capacity can stall even with a healthy old replica. The practical workshop develops this into: Inspect rollout strategy, rehearse a nonexistent image and undo it. Design a two-replica maintenance exercise with readiness and capacity checks; document what the single-node lab cannot demonstrate.

Mental model: A reversible road detour with traffic counters at both ends.

Boundary: A rollback may not undo database changes; release safety includes schema compatibility.

Role application: Keeping a minimum number of shop counters open requires enough staff and room.

Rolling updates, disruption budgets and capacity interact. A budget cannot create spare capacity or guarantee protection from every kind of failure.

Worked example: A rollout with no spare capacity can stall even with a healthy old replica.

Shared foundation example: Change the image to a nonexistent tag, inspect events and undo the rollout.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Kubernetes, kind, kubectl and container runtimes (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Kubernetes / Container Platform Engineer: A rollout with no spare capacity can stall even with a healthy old replica.

Predict the worked case

Read this case without running a tool: A rollout with no spare capacity can stall even with a healthy old replica. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in rollback and service objectives.

Connect the concept to the role

Apply this rule: A release needs measurable user outcomes, a way to identify regressions and a tested recovery path. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A rollback may not undo database changes; release safety includes schema compatibility.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies rollback and service objectives to this case: A rollout with no spare capacity can stall even with a healthy old replica. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A rollout with no spare capacity can stall even with a healthy old replica. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Rollback and service objectives; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rollback and service objectives. Use the glossary below, then write your prediction for: A rollout with no spare capacity can stall even with a healthy old replica. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Kubernetes / Container Platform Engineer role interview. Explain rollback and service objectives using this case: A rollout with no spare capacity can stall even with a healthy old replica. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rollback and service objectives to a system or workflow you know. Explain rollback and service objectives using this case: A rollout with no spare capacity can stall even with a healthy old replica. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks must pass after undoing a bad image?

Interview: Explain rollback and service objectives using this case: A rollout with no spare capacity can stall even with a healthy old replica. State the evidence, one alternative and where the mental model stops.

Quiz: After the Disruption and rollout recovery rehearsal, check this foundation: A rollout undo completes. What additional evidence establishes user recovery?

The deployment command exited zero, so no more checks are needed.

The old image tag exists in the registry.

A representative user operation succeeds and dependent state remains compatible.

Reference: A representative user operation succeeds and dependent state remains compatible. — Control-plane convergence does not verify the business path or reverse external state changes.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/

### Disruption and rollout recovery

Rolling updates, disruption budgets and capacity interact. A budget cannot create spare capacity or guarantee protection from every kind of failure. In this role, work through: A rollout with no spare capacity can stall even with a healthy old replica. The practical workshop develops this into: Inspect rollout strategy, rehearse a nonexistent image and undo it. Design a two-replica maintenance exercise with readiness and capacity checks; document what the single-node lab cannot demonstrate.

Mental model: Keeping a minimum number of shop counters open requires enough staff and room.

Boundary: A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages.

Worked example: A rollout with no spare capacity can stall even with a healthy old replica.

Setup: Install Docker Engine or Docker Desktop, kind and kubectl using their official guides. Docker Desktop has subscription conditions. This lab creates a local cluster, downloads images and uses device memory; it creates no paid cloud resources. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Kubernetes, kind, kubectl and container runtimes (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Kubernetes / Container Platform Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Inspect rollout strategy, rehearse a nonexistent image and undo it. Design a two-replica maintenance exercise with readiness and capacity checks; document what the single-node lab cannot demonstrate.

Create the isolated local baseline

Use a new cluster named atlas-course. If it already exists, reuse only your own learning cluster or change the name consistently.

```
kind create cluster --name atlas-course --kubeconfig ./atlas-kubeconfig
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course create namespace atlas-lab
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course apply -f deployment.yaml
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Deployment successfully rolled out; one healthy replica.

Observe routing

Keep port-forward running; open http://127.0.0.1:8136 in a browser. Ctrl+C ends forwarding.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods,svc
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab describe deployment atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab port-forward service/atlas-web 8136:80
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: The nginx welcome page appears. Service port 80 routes to container port 8080.

Rehearse a failed release

Apply the deliberately nonexistent image only to this local lab. Inspect events, then undo it. A failed new Pod may coexist with the old healthy Pod.

```
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab set image deployment/atlas-web web=nginxinc/nginx-unprivileged:atlas-does-not-exist
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get pods
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab get events --sort-by=.metadata.creationTimestamp
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout undo deployment/atlas-web
kubectl --kubeconfig ./atlas-kubeconfig --context kind-atlas-course -n atlas-lab rollout status deployment/atlas-web --timeout=180s
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Image pull failure is visible; undo returns the Deployment to a healthy rollout.

Role workshop · predict

A rollout with no spare capacity can stall even with a healthy old replica. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Inspect rollout strategy, rehearse a nonexistent image and undo it. Design a two-replica maintenance exercise with readiness and capacity checks; document what the single-node lab cannot demonstrate.

Expected: A recovered rollout and a realistic disruption plan.

Role workshop · debug and verify

A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Kubernetes operations runbook and rollout evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A recovered rollout and a realistic disruption plan.

Expected: A recovered rollout and a realistic disruption plan.

Troubleshoot: The role exercise differs from the prediction: A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages.

Cleanup: Stop port-forward with Ctrl+C, then run kind delete cluster --name atlas-course --kubeconfig ./atlas-kubeconfig. Keep or remove this lab kubeconfig file after saving evidence. This deletes that local learning cluster and its lab data only.

Deliverable: lesson-advanced-2.md: Kubernetes operations runbook and rollout evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with disruption and rollout recovery. Use the glossary below, then write your prediction for: A rollout with no spare capacity can stall even with a healthy old replica. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Kubernetes / Container Platform Engineer role interview. Explain disruption and rollout recovery using this case: A rollout with no spare capacity can stall even with a healthy old replica. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate disruption and rollout recovery to a system or workflow you know. Explain disruption and rollout recovery using this case: A rollout with no spare capacity can stall even with a healthy old replica. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A PodDisruptionBudget primarily constrains voluntary evictions, not arbitrary outages.

Interview: Explain disruption and rollout recovery using this case: A rollout with no spare capacity can stall even with a healthy old replica. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A rollout with no spare capacity can stall even with a healthy old replica.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A recovered rollout and a realistic disruption plan.

Reference: A recovered rollout and a realistic disruption plan. — Rolling updates, disruption budgets and capacity interact. A budget cannot create spare capacity or guarantee protection from every kind of failure. A recovered rollout and a realistic disruption plan.

Sources:

Kubernetes: resource quotas: https://kubernetes.io/docs/concepts/policy/resource-quotas/

Kubernetes basics: https://kubernetes.io/docs/tutorials/kubernetes-basics/

kind: local Kubernetes quick start: https://kind.sigs.k8s.io/docs/user/quick-start/

Docker: installation and getting started: https://docs.docker.com/get-started/

Google SRE book: https://sre.google/sre-book/table-of-contents/
