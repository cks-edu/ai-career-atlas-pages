# Android Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

UI state: The visible interface is a projection of state. User actions update state and trigger a new view.

Apply ui state in Android Developer: Use the concept to complete this role exercise: Create an Empty Activity and display one task with Compose

Compose state and recomposition: Compose draws UI from state. Hoist shared state to the owner that coordinates it, and separate a transient text field from the saved list of tasks.

### UI state

The visible interface is a projection of state. User actions update state and trigger a new view. In this role, work through: Typing A changes the input; tapping Add once changes task count from 0 to 1. The practical workshop develops this into: Create an Empty Activity, add a labeled text field and button, and keep list state outside the row composable. Test blank input, one add and rotation; record which state survives and why.

Mental model: A scoreboard reflects the current score rather than owning the game rules.

Boundary: Rendering frameworks differ; re-rendering does not automatically persist data.

Role application: The scoreboard reads the game state; repainting the scoreboard must not score another goal.

Compose draws UI from state. Hoist shared state to the owner that coordinates it, and separate a transient text field from the saved list of tasks.

Worked example: Typing A changes the input; tapping Add once changes task count from 0 to 1.

Shared foundation example: Adding one task changes count from zero to one.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Android Studio, Kotlin and Jetpack Compose (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Android Developer: Typing A changes the input; tapping Add once changes task count from 0 to 1.

Predict the worked case

Read this case without running a tool: Typing A changes the input; tapping Add once changes task count from 0 to 1. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in ui state.

Connect the concept to the role

Apply this rule: The visible interface is a projection of state. User actions update state and trigger a new view. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Rendering frameworks differ; re-rendering does not automatically persist data.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies ui state to this case: Typing A changes the input; tapping Add once changes task count from 0 to 1. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Typing A changes the input; tapping Add once changes task count from 0 to 1. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for UI state; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with ui state. Use the glossary below, then write your prediction for: Typing A changes the input; tapping Add once changes task count from 0 to 1. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Android Developer role interview. Explain ui state using this case: Typing A changes the input; tapping Add once changes task count from 0 to 1. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate ui state to a system or workflow you know. Explain ui state using this case: Typing A changes the input; tapping Add once changes task count from 0 to 1. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which state must survive app restart?

Interview: Explain ui state using this case: Typing A changes the input; tapping Add once changes task count from 0 to 1. State the evidence, one alternative and where the mental model stops.

Quiz: After the Compose state and recomposition rehearsal, check this foundation: A screen shows an old count after the underlying list changes. What should you inspect first?

How the view derives from state and receives change notifications.

Whether a screenshot contains the desired count.

Whether an unrelated server restart changes the display.

Reference: How the view derives from state and receives change notifications. — Trace the action, state update and rendered projection before adding a second conflicting source of truth.

Sources:

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

Flutter learning pathway: https://docs.flutter.dev/learn

### Compose state and recomposition

Compose draws UI from state. Hoist shared state to the owner that coordinates it, and separate a transient text field from the saved list of tasks. In this role, work through: Typing A changes the input; tapping Add once changes task count from 0 to 1. The practical workshop develops this into: Create an Empty Activity, add a labeled text field and button, and keep list state outside the row composable. Test blank input, one add and rotation; record which state survives and why.

Mental model: The scoreboard reads the game state; repainting the scoreboard must not score another goal.

Boundary: Repeated items after redraw suggest mutation during composition; move it to the event handler.

Worked example: Typing A changes the input; tapping Add once changes task count from 0 to 1.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Android Studio, Kotlin and Jetpack Compose (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Android Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create an Empty Activity, add a labeled text field and button, and keep list state outside the row composable. Test blank input, one add and rotation; record which state survives and why.

Start the native template

In Android Studio choose New Project → Empty Activity, keep Kotlin/Compose, and run the unmodified template on an emulator. Locate MainActivity.kt.

Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

Build a small task screen

Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.

Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

Exercise lifecycle boundaries

Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.

Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Role workshop · predict

Typing A changes the input; tapping Add once changes task count from 0 to 1. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create an Empty Activity, add a labeled text field and button, and keep list state outside the row composable. Test blank input, one add and rotation; record which state survives and why.

Expected: No task is created merely by recomposition; blank input is explained.

Role workshop · debug and verify

Repeated items after redraw suggest mutation during composition; move it to the event handler. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save MainActivity changes and a state ownership diagram. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: No task is created merely by recomposition; blank input is explained.

Expected: No task is created merely by recomposition; blank input is explained.

Troubleshoot: The role exercise differs from the prediction: Repeated items after redraw suggest mutation during composition; move it to the event handler.

Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Deliverable: lesson-beginner-2.md: MainActivity changes and a state ownership diagram; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with compose state and recomposition. Use the glossary below, then write your prediction for: Typing A changes the input; tapping Add once changes task count from 0 to 1. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Android Developer role interview. Explain compose state and recomposition using this case: Typing A changes the input; tapping Add once changes task count from 0 to 1. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate compose state and recomposition to a system or workflow you know. Explain compose state and recomposition using this case: Typing A changes the input; tapping Add once changes task count from 0 to 1. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Repeated items after redraw suggest mutation during composition; move it to the event handler.

Interview: Explain compose state and recomposition using this case: Typing A changes the input; tapping Add once changes task count from 0 to 1. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Typing A changes the input; tapping Add once changes task count from 0 to 1.

No task is created merely by recomposition; blank input is explained.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: No task is created merely by recomposition; blank input is explained. — Compose draws UI from state. Hoist shared state to the owner that coordinates it, and separate a transient text field from the saved list of tasks. No task is created merely by recomposition; blank input is explained.

Sources:

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

Flutter learning pathway: https://docs.flutter.dev/learn

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Local persistence and offline work: Save data explicitly and show whether it is local, queued or synchronized.

Apply local persistence and offline work in Android Developer: Use the concept to complete this role exercise: Save tasks with Room and test large text and TalkBack labels

Room persistence: Room maps local records to a SQLite database. A primary key defines identity and a DAO defines operations; UI observation does not replace a transaction for related writes.

### Local persistence and offline work

Save data explicitly and show whether it is local, queued or synchronized. In this role, work through: Save task ID 1, terminate the app, reopen and find exactly that task. The practical workshop develops this into: Follow the Android persistence lesson to add Entity, DAO and database. Observe tasks through the recommended lifecycle-aware approach. Test restart, empty storage and invalid input; use only a disposable emulator.

Mental model: An outbox keeps letters until the courier is available.

Boundary: Local storage can be removed or unavailable; it is not cloud backup.

Role application: A notebook keeps the score after the display is switched off.

Room maps local records to a SQLite database. A primary key defines identity and a DAO defines operations; UI observation does not replace a transaction for related writes.

Worked example: Save task ID 1, terminate the app, reopen and find exactly that task.

Shared foundation example: Create a task offline, restart and verify it remains marked unsent.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Android Studio, Kotlin and Jetpack Compose (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Android Developer: Save task ID 1, terminate the app, reopen and find exactly that task.

Predict the worked case

Read this case without running a tool: Save task ID 1, terminate the app, reopen and find exactly that task. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in local persistence and offline work.

Connect the concept to the role

Apply this rule: Save data explicitly and show whether it is local, queued or synchronized. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Local storage can be removed or unavailable; it is not cloud backup.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies local persistence and offline work to this case: Save task ID 1, terminate the app, reopen and find exactly that task. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Save task ID 1, terminate the app, reopen and find exactly that task. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Local persistence and offline work; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with local persistence and offline work. Use the glossary below, then write your prediction for: Save task ID 1, terminate the app, reopen and find exactly that task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Android Developer role interview. Explain local persistence and offline work using this case: Save task ID 1, terminate the app, reopen and find exactly that task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate local persistence and offline work to a system or workflow you know. Explain local persistence and offline work using this case: Save task ID 1, terminate the app, reopen and find exactly that task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why must the user see a queued status?

Interview: Explain local persistence and offline work using this case: Save task ID 1, terminate the app, reopen and find exactly that task. State the evidence, one alternative and where the mental model stops.

Quiz: After the Room persistence rehearsal, check this foundation: A record is saved locally while offline. Which status is justified before server acknowledgment?

Synchronized because it survives local restart.

Saved locally / pending synchronization.

Rejected because offline work cannot be stored.

Reference: Saved locally / pending synchronization. — Local durability and remote acknowledgment are different states. Communicate them separately.

Sources:

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

Flutter learning pathway: https://docs.flutter.dev/learn

### Room persistence

Room maps local records to a SQLite database. A primary key defines identity and a DAO defines operations; UI observation does not replace a transaction for related writes. In this role, work through: Save task ID 1, terminate the app, reopen and find exactly that task. The practical workshop develops this into: Follow the Android persistence lesson to add Entity, DAO and database. Observe tasks through the recommended lifecycle-aware approach. Test restart, empty storage and invalid input; use only a disposable emulator.

Mental model: A notebook keeps the score after the display is switched off.

Boundary: Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage.

Worked example: Save task ID 1, terminate the app, reopen and find exactly that task.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Android Studio, Kotlin and Jetpack Compose (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Android Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Follow the Android persistence lesson to add Entity, DAO and database. Observe tasks through the recommended lifecycle-aware approach. Test restart, empty storage and invalid input; use only a disposable emulator.

Start the native template

In Android Studio choose New Project → Empty Activity, keep Kotlin/Compose, and run the unmodified template on an emulator. Locate MainActivity.kt.

Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

Build a small task screen

Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.

Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

Exercise lifecycle boundaries

Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.

Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Role workshop · predict

Save task ID 1, terminate the app, reopen and find exactly that task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Follow the Android persistence lesson to add Entity, DAO and database. Observe tasks through the recommended lifecycle-aware approach. Test restart, empty storage and invalid input; use only a disposable emulator.

Expected: Saved tasks survive process restart; no database work blocks the main thread in the exercised flow.

Role workshop · debug and verify

Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Room schema, DAO tests and restart evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Saved tasks survive process restart; no database work blocks the main thread in the exercised flow.

Expected: Saved tasks survive process restart; no database work blocks the main thread in the exercised flow.

Troubleshoot: The role exercise differs from the prediction: Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage.

Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Deliverable: lesson-intermediate-2.md: Room schema, DAO tests and restart evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with room persistence. Use the glossary below, then write your prediction for: Save task ID 1, terminate the app, reopen and find exactly that task. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Android Developer role interview. Explain room persistence using this case: Save task ID 1, terminate the app, reopen and find exactly that task. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate room persistence to a system or workflow you know. Explain room persistence using this case: Save task ID 1, terminate the app, reopen and find exactly that task. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage.

Interview: Explain room persistence using this case: Save task ID 1, terminate the app, reopen and find exactly that task. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Save task ID 1, terminate the app, reopen and find exactly that task.

Ignore the failing case and keep only the successful screenshot.

Saved tasks survive process restart; no database work blocks the main thread in the exercised flow.

Treat any successful command as proof that all business and access rules passed.

Reference: Saved tasks survive process restart; no database work blocks the main thread in the exercised flow. — Room maps local records to a SQLite database. A primary key defines identity and a DAO defines operations; UI observation does not replace a transaction for related writes. Saved tasks survive process restart; no database work blocks the main thread in the exercised flow.

Sources:

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

Flutter learning pathway: https://docs.flutter.dev/learn

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Lifecycle and synchronization: Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately.

Apply lifecycle and synchronization in Android Developer: Use the concept to complete this role exercise: Implement a queued sync state and test process restart during synchronization

Offline sync conflict policy: A durable queue records intended changes while offline. A stable operation ID protects retries, while version checks detect two devices changing the same record.

### Lifecycle and synchronization

Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately. In this role, work through: Task t1 edited at version 1 conflicts with a server already at version 2. The practical workshop develops this into: Add queued/sending/failed/synced states to a fake repository. Interrupt after simulated server acceptance, restart and retry the same operation ID. Add a version conflict that requires an explicit user choice.

Mental model: A bookmark preserves your place when a reading session is interrupted.

Boundary: A bookmark cannot decide how to merge two different edits.

Role application: An outbox keeps the letter and its tracking number until delivery is confirmed.

A durable queue records intended changes while offline. A stable operation ID protects retries, while version checks detect two devices changing the same record.

Worked example: Task t1 edited at version 1 conflicts with a server already at version 2.

Shared foundation example: Retry the same task ID after reconnecting and verify one remote record.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Android Studio, Kotlin and Jetpack Compose (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Android Developer: Task t1 edited at version 1 conflicts with a server already at version 2.

Predict the worked case

Read this case without running a tool: Task t1 edited at version 1 conflicts with a server already at version 2. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in lifecycle and synchronization.

Connect the concept to the role

Apply this rule: Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A bookmark cannot decide how to merge two different edits.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies lifecycle and synchronization to this case: Task t1 edited at version 1 conflicts with a server already at version 2. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Task t1 edited at version 1 conflicts with a server already at version 2. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Lifecycle and synchronization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with lifecycle and synchronization. Use the glossary below, then write your prediction for: Task t1 edited at version 1 conflicts with a server already at version 2. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Android Developer role interview. Explain lifecycle and synchronization using this case: Task t1 edited at version 1 conflicts with a server already at version 2. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate lifecycle and synchronization to a system or workflow you know. Explain lifecycle and synchronization using this case: Task t1 edited at version 1 conflicts with a server already at version 2. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What happens if two devices change the same title offline?

Interview: Explain lifecycle and synchronization using this case: Task t1 edited at version 1 conflicts with a server already at version 2. State the evidence, one alternative and where the mental model stops.

Quiz: After the Offline sync conflict policy rehearsal, check this foundation: An app reconnects after an interrupted upload. Which retry behavior avoids creating a new logical record?

Generate a new record ID on every attempt.

Delete local state before checking the response.

Reuse the stable record ID and apply an explicit conflict policy.

Reference: Reuse the stable record ID and apply an explicit conflict policy. — Stable identity helps replay; concurrent edits still need a deliberate resolution strategy.

Sources:

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

Flutter learning pathway: https://docs.flutter.dev/learn

### Offline sync conflict policy

A durable queue records intended changes while offline. A stable operation ID protects retries, while version checks detect two devices changing the same record. In this role, work through: Task t1 edited at version 1 conflicts with a server already at version 2. The practical workshop develops this into: Add queued/sending/failed/synced states to a fake repository. Interrupt after simulated server acceptance, restart and retry the same operation ID. Add a version conflict that requires an explicit user choice.

Mental model: An outbox keeps the letter and its tracking number until delivery is confirmed.

Boundary: A new ID on every retry creates duplicates; persist the original ID with the queued operation.

Worked example: Task t1 edited at version 1 conflicts with a server already at version 2.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Android Studio, Kotlin and Jetpack Compose (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Android Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add queued/sending/failed/synced states to a fake repository. Interrupt after simulated server acceptance, restart and retry the same operation ID. Add a version conflict that requires an explicit user choice.

Start the native template

In Android Studio choose New Project → Empty Activity, keep Kotlin/Compose, and run the unmodified template on an emulator. Locate MainActivity.kt.

Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

Build a small task screen

Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.

Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

Exercise lifecycle boundaries

Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.

Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Role workshop · predict

Task t1 edited at version 1 conflicts with a server already at version 2. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add queued/sending/failed/synced states to a fake repository. Interrupt after simulated server acceptance, restart and retry the same operation ID. Add a version conflict that requires an explicit user choice.

Expected: One server effect after retry; conflict remains visible instead of silently overwriting data.

Role workshop · debug and verify

A new ID on every retry creates duplicates; persist the original ID with the queued operation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save sync state machine, fake-server tests and device-test limitations. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: One server effect after retry; conflict remains visible instead of silently overwriting data.

Expected: One server effect after retry; conflict remains visible instead of silently overwriting data.

Troubleshoot: The role exercise differs from the prediction: A new ID on every retry creates duplicates; persist the original ID with the queued operation.

Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Deliverable: lesson-advanced-2.md: sync state machine, fake-server tests and device-test limitations; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with offline sync conflict policy. Use the glossary below, then write your prediction for: Task t1 edited at version 1 conflicts with a server already at version 2. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Android Developer role interview. Explain offline sync conflict policy using this case: Task t1 edited at version 1 conflicts with a server already at version 2. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate offline sync conflict policy to a system or workflow you know. Explain offline sync conflict policy using this case: Task t1 edited at version 1 conflicts with a server already at version 2. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A new ID on every retry creates duplicates; persist the original ID with the queued operation.

Interview: Explain offline sync conflict policy using this case: Task t1 edited at version 1 conflicts with a server already at version 2. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Task t1 edited at version 1 conflicts with a server already at version 2.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

One server effect after retry; conflict remains visible instead of silently overwriting data.

Reference: One server effect after retry; conflict remains visible instead of silently overwriting data. — A durable queue records intended changes while offline. A stable operation ID protects retries, while version checks detect two devices changing the same record. One server effect after retry; conflict remains visible instead of silently overwriting data.

Sources:

Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course

Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui

Flutter learning pathway: https://docs.flutter.dev/learn
