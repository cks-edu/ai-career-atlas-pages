# Android Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Compose state and recomposition

Compose draws UI from state. Hoist shared state to the owner that coordinates it, and separate a transient text field from the saved list of tasks.
Mental model: The scoreboard reads the game state; repainting the scoreboard must not score another goal.
Case: Typing A changes the input; tapping Add once changes task count from 0 to 1.
Task: Create an Empty Activity, add a labeled text field and button, and keep list state outside the row composable. Test blank input, one add and rotation; record which state survives and why.
Acceptance: No task is created merely by recomposition; blank input is explained.
Troubleshooting: Repeated items after redraw suggest mutation during composition; move it to the event handler.
Deliverable: MainActivity changes and a state ownership diagram

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Room persistence

Room maps local records to a SQLite database. A primary key defines identity and a DAO defines operations; UI observation does not replace a transaction for related writes.
Mental model: A notebook keeps the score after the display is switched off.
Case: Save task ID 1, terminate the app, reopen and find exactly that task.
Task: Follow the Android persistence lesson to add Entity, DAO and database. Observe tasks through the recommended lifecycle-aware approach. Test restart, empty storage and invalid input; use only a disposable emulator.
Acceptance: Saved tasks survive process restart; no database work blocks the main thread in the exercised flow.
Troubleshooting: Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage.
Deliverable: Room schema, DAO tests and restart evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Offline sync conflict policy

A durable queue records intended changes while offline. A stable operation ID protects retries, while version checks detect two devices changing the same record.
Mental model: An outbox keeps the letter and its tracking number until delivery is confirmed.
Case: Task t1 edited at version 1 conflicts with a server already at version 2.
Task: Add queued/sending/failed/synced states to a fake repository. Interrupt after simulated server acceptance, restart and retry the same operation ID. Add a version conflict that requires an explicit user choice.
Acceptance: One server effect after retry; conflict remains visible instead of silently overwriting data.
Troubleshooting: A new ID on every retry creates duplicates; persist the original ID with the queued operation.
Deliverable: sync state machine, fake-server tests and device-test limitations

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
