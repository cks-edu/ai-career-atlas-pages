# Android Developer

Software Engineering

Begin with ui state. Create an Empty Activity and display one task with Compose. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Create an Empty Activity and display one task with Compose

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app.

### UI state
The visible interface is a projection of state. User actions update state and trigger a new view.
Mental model: A scoreboard reflects the current score rather than owning the game rules.
Limit: Rendering frameworks differ; re-rendering does not automatically persist data.
Example: Adding one task changes count from zero to one.
Recall: Which state must survive app restart?

### Apply ui state in Android Developer
Use the concept to complete this role exercise: Create an Empty Activity and display one task with Compose
Mental model: A scoreboard reflects the current score rather than owning the game rules.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Adding one task changes count from zero to one. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Start the native template
In Android Studio choose New Project → Empty Activity, keep Kotlin/Compose, and run the unmodified template on an emulator. Locate MainActivity.kt.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Apply this level’s extension
Create an Empty Activity and display one task with Compose
Expected: Record each row of checklist.md with input, expected result, observed result and evidence.

4. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: android-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Create an Empty Activity and display one task with Compose? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: The visible interface is a projection of state. User actions update state and trigger a new view. For this role, explicitly address: Create an Empty Activity and display one task with Compose.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Save tasks with Room and test large text and TalkBack labels

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app.

### Local persistence and offline work
Save data explicitly and show whether it is local, queued or synchronized.
Mental model: An outbox keeps letters until the courier is available.
Limit: Local storage can be removed or unavailable; it is not cloud backup.
Example: Create a task offline, restart and verify it remains marked unsent.
Recall: Why must the user see a queued status?

### Apply local persistence and offline work in Android Developer
Use the concept to complete this role exercise: Save tasks with Room and test large text and TalkBack labels
Mental model: An outbox keeps letters until the courier is available.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Create a task offline, restart and verify it remains marked unsent. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Start the native template
In Android Studio choose New Project → Empty Activity, keep Kotlin/Compose, and run the unmodified template on an emulator. Locate MainActivity.kt.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Apply this level’s extension
Save tasks with Room and test large text and TalkBack labels
Expected: Record each row of checklist.md with input, expected result, observed result and evidence.

4. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: android-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Save tasks with Room and test large text and TalkBack labels? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Save data explicitly and show whether it is local, queued or synchronized. For this role, explicitly address: Save tasks with Room and test large text and TalkBack labels.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Implement a queued sync state and test process restart during synchronization

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app.

### Lifecycle and synchronization
Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately.
Mental model: A bookmark preserves your place when a reading session is interrupted.
Limit: A bookmark cannot decide how to merge two different edits.
Example: Retry the same task ID after reconnecting and verify one remote record.
Recall: What happens if two devices change the same title offline?

### Apply lifecycle and synchronization in Android Developer
Use the concept to complete this role exercise: Implement a queued sync state and test process restart during synchronization
Mental model: A bookmark preserves your place when a reading session is interrupted.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Retry the same task ID after reconnecting and verify one remote record. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Start the native template
In Android Studio choose New Project → Empty Activity, keep Kotlin/Compose, and run the unmodified template on an emulator. Locate MainActivity.kt.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Apply this level’s extension
Implement a queued sync state and test process restart during synchronization
Expected: Record each row of checklist.md with input, expected result, observed result and evidence.

4. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: android-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Implement a queued sync state and test process restart during synchronization? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately. For this role, explicitly address: Implement a queued sync state and test process restart during synchronization.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course
Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui
Flutter learning pathway: https://docs.flutter.dev/learn
