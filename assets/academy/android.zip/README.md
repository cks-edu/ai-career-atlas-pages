# Android Developer

Software Engineering

Start with compose state and recomposition. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward sync state machine, fake-server tests and device-test limitations.

## beginner

Create an Empty Activity, add a labeled text field and button, and keep list state outside the row composable. Test blank input, one add and rotation; record which state survives and why.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### UI state
The visible interface is a projection of state. User actions update state and trigger a new view.
Mental model: A scoreboard reflects the current score rather than owning the game rules.
Limit: Rendering frameworks differ; re-rendering does not automatically persist data.
Example: Adding one task changes count from zero to one.
Recall: Which state must survive app restart?

### Compose state and recomposition
Compose draws UI from state. Hoist shared state to the owner that coordinates it, and separate a transient text field from the saved list of tasks.
Mental model: The scoreboard reads the game state; repainting the scoreboard must not score another goal.
Limit: Repeated items after redraw suggest mutation during composition; move it to the event handler.
Example: Typing A changes the input; tapping Add once changes task count from 0 to 1.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Repeated items after redraw suggest mutation during composition; move it to the event handler.

1. Start the native template
In Android Studio choose New Project → Empty Activity, keep Kotlin/Compose, and run the unmodified template on an emulator. Locate MainActivity.kt.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
Typing A changes the input; tapping Add once changes task count from 0 to 1. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create an Empty Activity, add a labeled text field and button, and keep list state outside the row composable. Test blank input, one add and rotation; record which state survives and why.
Expected: No task is created merely by recomposition; blank input is explained.

6. Role workshop · debug and verify
Repeated items after redraw suggest mutation during composition; move it to the event handler. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save MainActivity changes and a state ownership diagram. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: No task is created merely by recomposition; blank input is explained.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Compose state and recomposition: Repeated items after redraw suggest mutation during composition; move it to the event handler.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: MainActivity changes and a state ownership diagram
No task is created merely by recomposition; blank input is explained.

Interview: Work through this Android Developer case: Typing A changes the input; tapping Add once changes task count from 0 to 1. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Compose draws UI from state. Hoist shared state to the owner that coordinates it, and separate a transient text field from the saved list of tasks. Expected evidence: No task is created merely by recomposition; blank input is explained. Diagnosis: Repeated items after redraw suggest mutation during composition; move it to the event handler. State the limits of the mental model: The scoreboard reads the game state; repainting the scoreboard must not score another goal.

Resume: Built MainActivity changes and a state ownership diagram using Android Studio, Kotlin and Jetpack Compose; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Follow the Android persistence lesson to add Entity, DAO and database. Observe tasks through the recommended lifecycle-aware approach. Test restart, empty storage and invalid input; use only a disposable emulator.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Local persistence and offline work
Save data explicitly and show whether it is local, queued or synchronized.
Mental model: An outbox keeps letters until the courier is available.
Limit: Local storage can be removed or unavailable; it is not cloud backup.
Example: Create a task offline, restart and verify it remains marked unsent.
Recall: Why must the user see a queued status?

### Room persistence
Room maps local records to a SQLite database. A primary key defines identity and a DAO defines operations; UI observation does not replace a transaction for related writes.
Mental model: A notebook keeps the score after the display is switched off.
Limit: Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage.
Example: Save task ID 1, terminate the app, reopen and find exactly that task.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage.

1. Start the native template
In Android Studio choose New Project → Empty Activity, keep Kotlin/Compose, and run the unmodified template on an emulator. Locate MainActivity.kt.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
Save task ID 1, terminate the app, reopen and find exactly that task. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Follow the Android persistence lesson to add Entity, DAO and database. Observe tasks through the recommended lifecycle-aware approach. Test restart, empty storage and invalid input; use only a disposable emulator.
Expected: Saved tasks survive process restart; no database work blocks the main thread in the exercised flow.

6. Role workshop · debug and verify
Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Room schema, DAO tests and restart evidence. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Saved tasks survive process restart; no database work blocks the main thread in the exercised flow.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Room persistence: Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: Room schema, DAO tests and restart evidence
Saved tasks survive process restart; no database work blocks the main thread in the exercised flow.

Interview: Work through this Android Developer case: Save task ID 1, terminate the app, reopen and find exactly that task. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Room maps local records to a SQLite database. A primary key defines identity and a DAO defines operations; UI observation does not replace a transaction for related writes. Expected evidence: Saved tasks survive process restart; no database work blocks the main thread in the exercised flow. Diagnosis: Rotation alone does not prove persistence; force-stop and reopen to distinguish memory from storage. State the limits of the mental model: A notebook keeps the score after the display is switched off.

Resume: Built Room schema, DAO tests and restart evidence using Android Studio, Kotlin and Jetpack Compose; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Add queued/sending/failed/synced states to a fake repository. Interrupt after simulated server acceptance, restart and retry the same operation ID. Add a version conflict that requires an explicit user choice.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Lifecycle and synchronization
Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately.
Mental model: A bookmark preserves your place when a reading session is interrupted.
Limit: A bookmark cannot decide how to merge two different edits.
Example: Retry the same task ID after reconnecting and verify one remote record.
Recall: What happens if two devices change the same title offline?

### Offline sync conflict policy
A durable queue records intended changes while offline. A stable operation ID protects retries, while version checks detect two devices changing the same record.
Mental model: An outbox keeps the letter and its tracking number until delivery is confirmed.
Limit: A new ID on every retry creates duplicates; persist the original ID with the queued operation.
Example: Task t1 edited at version 1 conflicts with a server already at version 2.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A new ID on every retry creates duplicates; persist the original ID with the queued operation.

1. Start the native template
In Android Studio choose New Project → Empty Activity, keep Kotlin/Compose, and run the unmodified template on an emulator. Locate MainActivity.kt.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
Task t1 edited at version 1 conflicts with a server already at version 2. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add queued/sending/failed/synced states to a fake repository. Interrupt after simulated server acceptance, restart and retry the same operation ID. Add a version conflict that requires an explicit user choice.
Expected: One server effect after retry; conflict remains visible instead of silently overwriting data.

6. Role workshop · debug and verify
A new ID on every retry creates duplicates; persist the original ID with the queued operation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save sync state machine, fake-server tests and device-test limitations. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One server effect after retry; conflict remains visible instead of silently overwriting data.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Offline sync conflict policy: A new ID on every retry creates duplicates; persist the original ID with the queued operation.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: sync state machine, fake-server tests and device-test limitations
One server effect after retry; conflict remains visible instead of silently overwriting data.

Interview: Work through this Android Developer case: Task t1 edited at version 1 conflicts with a server already at version 2. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A durable queue records intended changes while offline. A stable operation ID protects retries, while version checks detect two devices changing the same record. Expected evidence: One server effect after retry; conflict remains visible instead of silently overwriting data. Diagnosis: A new ID on every retry creates duplicates; persist the original ID with the queued operation. State the limits of the mental model: An outbox keeps the letter and its tracking number until delivery is confirmed.

Resume: Built sync state machine, fake-server tests and device-test limitations using Android Studio, Kotlin and Jetpack Compose; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course
Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui
Flutter learning pathway: https://docs.flutter.dev/learn
