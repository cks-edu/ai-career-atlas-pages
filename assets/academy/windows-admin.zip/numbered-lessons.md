# Windows / Endpoint Administrator — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Layered diagnosis: Check local process, address resolution, connection and application response separately.

Apply layered diagnosis in Windows / Endpoint Administrator: Use the concept to complete this role exercise: Collect OS, IP and connectivity evidence without changing settings

PowerShell inventory: Read-only inventory establishes device and network context before remediation. Objects returned by PowerShell are more reliable to filter than screenshots of arbitrary console text.

### Layered diagnosis

Check local process, address resolution, connection and application response separately. In this role, work through: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. The practical workshop develops this into: On an authorized Windows lab run those commands and Test-NetConnection for an approved endpoint. Record only non-sensitive fields, OS version and the failed user action.

Mental model: Follow a letter from address book to road to reception desk.

Boundary: Layers interact; one successful check does not establish every other layer.

Role application: An equipment register lists exact models and conditions before repair.

Read-only inventory establishes device and network context before remediation. Objects returned by PowerShell are more reliable to filter than screenshots of arbitrary console text.

Worked example: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint.

Shared foundation example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Windows, PowerShell and Microsoft Intune (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Windows / Endpoint Administrator: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint.

Predict the worked case

Read this case without running a tool: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in layered diagnosis.

Connect the concept to the role

Apply this rule: Check local process, address resolution, connection and application response separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Layers interact; one successful check does not establish every other layer.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies layered diagnosis to this case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Layered diagnosis; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with layered diagnosis. Use the glossary below, then write your prediction for: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Windows / Endpoint Administrator role interview. Explain layered diagnosis using this case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate layered diagnosis to a system or workflow you know. Explain layered diagnosis using this case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is a 404 different from connection refused?

Interview: Explain layered diagnosis using this case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. State the evidence, one alternative and where the mental model stops.

Quiz: After the PowerShell inventory rehearsal, check this foundation: A request returns HTTP 500 rather than connection refused. Which next step best follows the evidence?

Inspect application and upstream error evidence for that request.

Assume DNS failed before any server response.

Immediately rewrite the local firewall policy.

Reference: Inspect application and upstream error evidence for that request. — An HTTP response points beyond the basic connection boundary; identify its origin before diagnosing the application.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### PowerShell inventory

Read-only inventory establishes device and network context before remediation. Objects returned by PowerShell are more reliable to filter than screenshots of arbitrary console text. In this role, work through: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. The practical workshop develops this into: On an authorized Windows lab run those commands and Test-NetConnection for an approved endpoint. Record only non-sensitive fields, OS version and the failed user action.

Mental model: An equipment register lists exact models and conditions before repair.

Boundary: A blocked ICMP probe does not prove all TCP services are unavailable; test the required port.

Worked example: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Windows, PowerShell and Microsoft Intune (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Windows / Endpoint Administrator workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

On an authorized Windows lab run those commands and Test-NetConnection for an approved endpoint. Record only non-sensitive fields, OS version and the failed user action.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

On an authorized Windows lab run those commands and Test-NetConnection for an approved endpoint. Record only non-sensitive fields, OS version and the failed user action.

```
Get-ComputerInfo
Get-NetIPConfiguration
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: An inventory that separates local configuration from reachability.

Role workshop · debug and verify

A blocked ICMP probe does not prove all TCP services are unavailable; test the required port. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save redacted endpoint baseline. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: An inventory that separates local configuration from reachability.

Expected: An inventory that separates local configuration from reachability.

Troubleshoot: The role exercise differs from the prediction: A blocked ICMP probe does not prove all TCP services are unavailable; test the required port.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: redacted endpoint baseline; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with powershell inventory. Use the glossary below, then write your prediction for: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Windows / Endpoint Administrator role interview. Explain powershell inventory using this case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate powershell inventory to a system or workflow you know. Explain powershell inventory using this case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A blocked ICMP probe does not prove all TCP services are unavailable; test the required port.

Interview: Explain powershell inventory using this case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint.

An inventory that separates local configuration from reachability.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: An inventory that separates local configuration from reachability. — Read-only inventory establishes device and network context before remediation. Objects returned by PowerShell are more reliable to filter than screenshots of arbitrary console text. An inventory that separates local configuration from reachability.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Least privilege and change scope: Use only the rights required for the task and record exactly what you intend to change.

Apply least privilege and change scope in Windows / Endpoint Administrator: Use the concept to complete this role exercise: Describe a staged endpoint configuration change and rollback

Staged endpoint policy: Endpoint policy should target a test group before broad rollout. Describe assignment, conflict behavior and a rollback route; a portal assignment is not proof the device applied it.

### Least privilege and change scope

Use only the rights required for the task and record exactly what you intend to change. In this role, work through: A proposed configuration reaches the test device but must be verified locally. The practical workshop develops this into: Write a pilot-ring plan for a benign setting, including current value, target value and validation command. In an authorized Intune test tenant apply only to lab devices and capture reported versus observed state.

Mental model: Borrow a key to one room rather than the master key.

Boundary: Permissions cannot replace backups or ownership of a change.

Role application: Try the new classroom rule in one room and confirm students received it.

Endpoint policy should target a test group before broad rollout. Describe assignment, conflict behavior and a rollback route; a portal assignment is not proof the device applied it.

Worked example: A proposed configuration reaches the test device but must be verified locally.

Shared foundation example: Run the loopback diagnostic without changing DNS or firewall settings.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Windows, PowerShell and Microsoft Intune (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Windows / Endpoint Administrator: A proposed configuration reaches the test device but must be verified locally.

Predict the worked case

Read this case without running a tool: A proposed configuration reaches the test device but must be verified locally. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in least privilege and change scope.

Connect the concept to the role

Apply this rule: Use only the rights required for the task and record exactly what you intend to change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Permissions cannot replace backups or ownership of a change.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies least privilege and change scope to this case: A proposed configuration reaches the test device but must be verified locally. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A proposed configuration reaches the test device but must be verified locally. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Least privilege and change scope; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with least privilege and change scope. Use the glossary below, then write your prediction for: A proposed configuration reaches the test device but must be verified locally. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Windows / Endpoint Administrator role interview. Explain least privilege and change scope using this case: A proposed configuration reaches the test device but must be verified locally. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate least privilege and change scope to a system or workflow you know. Explain least privilege and change scope using this case: A proposed configuration reaches the test device but must be verified locally. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What information should a change ticket contain before modifying a network setting?

Interview: Explain least privilege and change scope using this case: A proposed configuration reaches the test device but must be verified locally. State the evidence, one alternative and where the mental model stops.

Quiz: After the Staged endpoint policy rehearsal, check this foundation: A diagnostic only needs to read a local log. Which access is appropriate?

Permanent administrator rights for convenience.

The narrow read permission required for that log.

Write access to every service configuration.

Reference: The narrow read permission required for that log. — Match permissions to the task. Extra privileges add risk without evidence that they are required.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Staged endpoint policy

Endpoint policy should target a test group before broad rollout. Describe assignment, conflict behavior and a rollback route; a portal assignment is not proof the device applied it. In this role, work through: A proposed configuration reaches the test device but must be verified locally. The practical workshop develops this into: Write a pilot-ring plan for a benign setting, including current value, target value and validation command. In an authorized Intune test tenant apply only to lab devices and capture reported versus observed state.

Mental model: Try the new classroom rule in one room and confirm students received it.

Boundary: If state differs, inspect enrollment, sync and competing policy before broadening assignment.

Worked example: A proposed configuration reaches the test device but must be verified locally.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Windows, PowerShell and Microsoft Intune (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Windows / Endpoint Administrator workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a pilot-ring plan for a benign setting, including current value, target value and validation command. In an authorized Intune test tenant apply only to lab devices and capture reported versus observed state.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A proposed configuration reaches the test device but must be verified locally. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a pilot-ring plan for a benign setting, including current value, target value and validation command. In an authorized Intune test tenant apply only to lab devices and capture reported versus observed state.

```
Get-NetIPConfiguration
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: An explicit distinction between assigned, delivered and effective policy.

Role workshop · debug and verify

If state differs, inspect enrollment, sync and competing policy before broadening assignment. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save policy rollout plan and verification matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: An explicit distinction between assigned, delivered and effective policy.

Expected: An explicit distinction between assigned, delivered and effective policy.

Troubleshoot: The role exercise differs from the prediction: If state differs, inspect enrollment, sync and competing policy before broadening assignment.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: policy rollout plan and verification matrix; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with staged endpoint policy. Use the glossary below, then write your prediction for: A proposed configuration reaches the test device but must be verified locally. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Windows / Endpoint Administrator role interview. Explain staged endpoint policy using this case: A proposed configuration reaches the test device but must be verified locally. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate staged endpoint policy to a system or workflow you know. Explain staged endpoint policy using this case: A proposed configuration reaches the test device but must be verified locally. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If state differs, inspect enrollment, sync and competing policy before broadening assignment.

Interview: Explain staged endpoint policy using this case: A proposed configuration reaches the test device but must be verified locally. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A proposed configuration reaches the test device but must be verified locally.

Ignore the failing case and keep only the successful screenshot.

An explicit distinction between assigned, delivered and effective policy.

Treat any successful command as proof that all business and access rules passed.

Reference: An explicit distinction between assigned, delivered and effective policy. — Endpoint policy should target a test group before broad rollout. Describe assignment, conflict behavior and a rollback route; a portal assignment is not proof the device applied it. An explicit distinction between assigned, delivered and effective policy.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Recovery evidence: A recovery is complete when the original user operation works and important side effects have been checked.

Apply recovery evidence in Windows / Endpoint Administrator: Use the concept to complete this role exercise: Plan access, update rings and recovery validation for a device fleet

Patch and recovery operations: Update rings reduce simultaneous exposure but require health signals and a recovery plan. Include disk encryption recovery access and user data considerations in operational planning.

### Recovery evidence

A recovery is complete when the original user operation works and important side effects have been checked. In this role, work through: A pilot update causing application failure should stop promotion to the next ring. The practical workshop develops this into: Create a two-ring rollout schedule, health checks and a stop threshold. Rehearse recovery on a disposable VM snapshot and document which production protections snapshots do not replace.

Mental model: Repair a tap, then test water flow and inspect for leaks.

Boundary: One successful retry does not establish long-term reliability.

Role application: Stagger renovations so the whole building is not unavailable at once.

Update rings reduce simultaneous exposure but require health signals and a recovery plan. Include disk encryption recovery access and user data considerations in operational planning.

Worked example: A pilot update causing application failure should stop promotion to the next ring.

Shared foundation example: After correcting a path, record HTTP status, timestamp and the user-visible result.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Windows, PowerShell and Microsoft Intune (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Windows / Endpoint Administrator: A pilot update causing application failure should stop promotion to the next ring.

Predict the worked case

Read this case without running a tool: A pilot update causing application failure should stop promotion to the next ring. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in recovery evidence.

Connect the concept to the role

Apply this rule: A recovery is complete when the original user operation works and important side effects have been checked. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: One successful retry does not establish long-term reliability.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies recovery evidence to this case: A pilot update causing application failure should stop promotion to the next ring. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A pilot update causing application failure should stop promotion to the next ring. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Recovery evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with recovery evidence. Use the glossary below, then write your prediction for: A pilot update causing application failure should stop promotion to the next ring. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Windows / Endpoint Administrator role interview. Explain recovery evidence using this case: A pilot update causing application failure should stop promotion to the next ring. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate recovery evidence to a system or workflow you know. Explain recovery evidence using this case: A pilot update causing application failure should stop promotion to the next ring. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would you record for the next person handling the incident?

Interview: Explain recovery evidence using this case: A pilot update causing application failure should stop promotion to the next ring. State the evidence, one alternative and where the mental model stops.

Quiz: After the Patch and recovery operations rehearsal, check this foundation: A repair command succeeds after an outage. Which check most directly tests recovery?

Confirm that a process exists.

Confirm the runbook file was opened.

Repeat the original user operation and inspect important side effects.

Reference: Repeat the original user operation and inspect important side effects. — Recovery must be measured at the affected operation, not inferred solely from a successful repair command.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/

### Patch and recovery operations

Update rings reduce simultaneous exposure but require health signals and a recovery plan. Include disk encryption recovery access and user data considerations in operational planning. In this role, work through: A pilot update causing application failure should stop promotion to the next ring. The practical workshop develops this into: Create a two-ring rollout schedule, health checks and a stop threshold. Rehearse recovery on a disposable VM snapshot and document which production protections snapshots do not replace.

Mental model: Stagger renovations so the whole building is not unavailable at once.

Boundary: A successful OS boot is insufficient if the user's business application still fails.

Worked example: A pilot update causing application failure should stop promotion to the next ring.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Windows, PowerShell and Microsoft Intune (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Windows / Endpoint Administrator workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a two-ring rollout schedule, health checks and a stop threshold. Rehearse recovery on a disposable VM snapshot and document which production protections snapshots do not replace.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 diagnose.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A pilot update causing application failure should stop promotion to the next ring. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a two-ring rollout schedule, health checks and a stop threshold. Rehearse recovery on a disposable VM snapshot and document which production protections snapshots do not replace.

```
Get-ComputerInfo
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: A measured lab recovery and an explicit promotion decision.

Role workshop · debug and verify

A successful OS boot is insufficient if the user's business application still fails. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save endpoint operations runbook and pilot report. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A measured lab recovery and an explicit promotion decision.

Expected: A measured lab recovery and an explicit promotion decision.

Troubleshoot: The role exercise differs from the prediction: A successful OS boot is insufficient if the user's business application still fails.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: endpoint operations runbook and pilot report; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with patch and recovery operations. Use the glossary below, then write your prediction for: A pilot update causing application failure should stop promotion to the next ring. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Windows / Endpoint Administrator role interview. Explain patch and recovery operations using this case: A pilot update causing application failure should stop promotion to the next ring. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate patch and recovery operations to a system or workflow you know. Explain patch and recovery operations using this case: A pilot update causing application failure should stop promotion to the next ring. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful OS boot is insufficient if the user's business application still fails.

Interview: Explain patch and recovery operations using this case: A pilot update causing application failure should stop promotion to the next ring. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A pilot update causing application failure should stop promotion to the next ring.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A measured lab recovery and an explicit promotion decision.

Reference: A measured lab recovery and an explicit promotion decision. — Update rings reduce simultaneous exposure but require health signals and a recovery plan. Include disk encryption recovery access and user data considerations in operational planning. A measured lab recovery and an explicit promotion decision.

Sources:

Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting

Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html

Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
