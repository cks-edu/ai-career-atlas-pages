# Windows / Endpoint Administrator

Software Engineering

Start with powershell inventory. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward endpoint operations runbook and pilot report.

## beginner

On an authorized Windows lab run those commands and Test-NetConnection for an approved endpoint. Record only non-sensitive fields, OS version and the failed user action.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Layered diagnosis
Check local process, address resolution, connection and application response separately.
Mental model: Follow a letter from address book to road to reception desk.
Limit: Layers interact; one successful check does not establish every other layer.
Example: localhost resolves to loopback; a 404 means an HTTP server answered but did not find the path.
Recall: Why is a 404 different from connection refused?

### PowerShell inventory
Read-only inventory establishes device and network context before remediation. Objects returned by PowerShell are more reliable to filter than screenshots of arbitrary console text.
Mental model: An equipment register lists exact models and conditions before repair.
Limit: A blocked ICMP probe does not prove all TCP services are unavailable; test the required port.
Example: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A blocked ICMP probe does not prove all TCP services are unavailable; test the required port.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
On an authorized Windows lab run those commands and Test-NetConnection for an approved endpoint. Record only non-sensitive fields, OS version and the failed user action.
```
Get-ComputerInfo
Get-NetIPConfiguration
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: An inventory that separates local configuration from reachability.

6. Role workshop · debug and verify
A blocked ICMP probe does not prove all TCP services are unavailable; test the required port. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save redacted endpoint baseline. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: An inventory that separates local configuration from reachability.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
PowerShell inventory: A blocked ICMP probe does not prove all TCP services are unavailable; test the required port.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: redacted endpoint baseline
An inventory that separates local configuration from reachability.

Interview: Work through this Windows / Endpoint Administrator case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Read-only inventory establishes device and network context before remediation. Objects returned by PowerShell are more reliable to filter than screenshots of arbitrary console text. Expected evidence: An inventory that separates local configuration from reachability. Diagnosis: A blocked ICMP probe does not prove all TCP services are unavailable; test the required port. State the limits of the mental model: An equipment register lists exact models and conditions before repair.

Resume: Built redacted endpoint baseline using Windows, PowerShell and Microsoft Intune; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Write a pilot-ring plan for a benign setting, including current value, target value and validation command. In an authorized Intune test tenant apply only to lab devices and capture reported versus observed state.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Least privilege and change scope
Use only the rights required for the task and record exactly what you intend to change.
Mental model: Borrow a key to one room rather than the master key.
Limit: Permissions cannot replace backups or ownership of a change.
Example: Run the loopback diagnostic without changing DNS or firewall settings.
Recall: What information should a change ticket contain before modifying a network setting?

### Staged endpoint policy
Endpoint policy should target a test group before broad rollout. Describe assignment, conflict behavior and a rollback route; a portal assignment is not proof the device applied it.
Mental model: Try the new classroom rule in one room and confirm students received it.
Limit: If state differs, inspect enrollment, sync and competing policy before broadening assignment.
Example: A proposed configuration reaches the test device but must be verified locally.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If state differs, inspect enrollment, sync and competing policy before broadening assignment.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A proposed configuration reaches the test device but must be verified locally. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a pilot-ring plan for a benign setting, including current value, target value and validation command. In an authorized Intune test tenant apply only to lab devices and capture reported versus observed state.
```
Get-NetIPConfiguration
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: An explicit distinction between assigned, delivered and effective policy.

6. Role workshop · debug and verify
If state differs, inspect enrollment, sync and competing policy before broadening assignment. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save policy rollout plan and verification matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: An explicit distinction between assigned, delivered and effective policy.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Staged endpoint policy: If state differs, inspect enrollment, sync and competing policy before broadening assignment.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: policy rollout plan and verification matrix
An explicit distinction between assigned, delivered and effective policy.

Interview: Work through this Windows / Endpoint Administrator case: A proposed configuration reaches the test device but must be verified locally. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Endpoint policy should target a test group before broad rollout. Describe assignment, conflict behavior and a rollback route; a portal assignment is not proof the device applied it. Expected evidence: An explicit distinction between assigned, delivered and effective policy. Diagnosis: If state differs, inspect enrollment, sync and competing policy before broadening assignment. State the limits of the mental model: Try the new classroom rule in one room and confirm students received it.

Resume: Built policy rollout plan and verification matrix using Windows, PowerShell and Microsoft Intune; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Create a two-ring rollout schedule, health checks and a stop threshold. Rehearse recovery on a disposable VM snapshot and document which production protections snapshots do not replace.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Recovery evidence
A recovery is complete when the original user operation works and important side effects have been checked.
Mental model: Repair a tap, then test water flow and inspect for leaks.
Limit: One successful retry does not establish long-term reliability.
Example: After correcting a path, record HTTP status, timestamp and the user-visible result.
Recall: What would you record for the next person handling the incident?

### Patch and recovery operations
Update rings reduce simultaneous exposure but require health signals and a recovery plan. Include disk encryption recovery access and user data considerations in operational planning.
Mental model: Stagger renovations so the whole building is not unavailable at once.
Limit: A successful OS boot is insufficient if the user's business application still fails.
Example: A pilot update causing application failure should stop promotion to the next ring.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A successful OS boot is insufficient if the user's business application still fails.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 diagnose.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Loopback resolution succeeds. Later levels verify /health; advanced identifies a 404 as an application-path failure.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A pilot update causing application failure should stop promotion to the next ring. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a two-ring rollout schedule, health checks and a stop threshold. Rehearse recovery on a disposable VM snapshot and document which production protections snapshots do not replace.
```
Get-ComputerInfo
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: A measured lab recovery and an explicit promotion decision.

6. Role workshop · debug and verify
A successful OS boot is insufficient if the user's business application still fails. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save endpoint operations runbook and pilot report. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A measured lab recovery and an explicit promotion decision.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Patch and recovery operations: A successful OS boot is insufficient if the user's business application still fails.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: endpoint operations runbook and pilot report
A measured lab recovery and an explicit promotion decision.

Interview: Work through this Windows / Endpoint Administrator case: A pilot update causing application failure should stop promotion to the next ring. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Update rings reduce simultaneous exposure but require health signals and a recovery plan. Include disk encryption recovery access and user data considerations in operational planning. Expected evidence: A measured lab recovery and an explicit promotion decision. Diagnosis: A successful OS boot is insufficient if the user's business application still fails. State the limits of the mental model: Stagger renovations so the whole building is not unavailable at once.

Resume: Built endpoint operations runbook and pilot report using Windows, PowerShell and Microsoft Intune; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Microsoft: troubleshoot TCP/IP connectivity: https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting
Linux administrator documentation: https://www.kernel.org/doc/html/latest/admin-guide/index.html
Python tutorial (after programming foundations): https://docs.python.org/3/tutorial/
