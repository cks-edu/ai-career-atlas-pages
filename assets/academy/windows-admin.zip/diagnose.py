import socket,sys,json,http.server,threading,urllib.request
stage=sys.argv[1] if len(sys.argv)>1 else 'beginner'
assert socket.gethostbyname('localhost') in ('127.0.0.1','::1')
print('Local name lookup: OK')
if stage!='beginner':
 class Handler(http.server.BaseHTTPRequestHandler):
  def do_GET(self):
   self.send_response(200 if self.path=='/health' else 404);self.end_headers();self.wfile.write(b'healthy' if self.path=='/health' else b'missing')
  def log_message(self,*a):pass
 server=http.server.HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
 try:
  base='http://127.0.0.1:'+str(server.server_port)
  assert urllib.request.urlopen(base+'/health').read()==b'healthy'
  print('Local service health: OK')
  if stage=='advanced':
   try:urllib.request.urlopen(base+'/missing');raise AssertionError('Expected a 404')
   except urllib.error.HTTPError as e:assert e.code==404
   print('Failure isolated: network connected; application route missing')
 finally:server.shutdown();server.server_close();thread.join()
print('PASS it '+stage)
