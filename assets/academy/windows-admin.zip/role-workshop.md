# Windows / Endpoint Administrator — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
PowerShell inventory

Read-only inventory establishes device and network context before remediation. Objects returned by PowerShell are more reliable to filter than screenshots of arbitrary console text.
Mental model: An equipment register lists exact models and conditions before repair.
Case: Get-NetIPConfiguration and Get-ComputerInfo describe different parts of the endpoint.
Task: On an authorized Windows lab run those commands and Test-NetConnection for an approved endpoint. Record only non-sensitive fields, OS version and the failed user action.
Acceptance: An inventory that separates local configuration from reachability.
Troubleshooting: A blocked ICMP probe does not prove all TCP services are unavailable; test the required port.
Deliverable: redacted endpoint baseline

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Staged endpoint policy

Endpoint policy should target a test group before broad rollout. Describe assignment, conflict behavior and a rollback route; a portal assignment is not proof the device applied it.
Mental model: Try the new classroom rule in one room and confirm students received it.
Case: A proposed configuration reaches the test device but must be verified locally.
Task: Write a pilot-ring plan for a benign setting, including current value, target value and validation command. In an authorized Intune test tenant apply only to lab devices and capture reported versus observed state.
Acceptance: An explicit distinction between assigned, delivered and effective policy.
Troubleshooting: If state differs, inspect enrollment, sync and competing policy before broadening assignment.
Deliverable: policy rollout plan and verification matrix

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Patch and recovery operations

Update rings reduce simultaneous exposure but require health signals and a recovery plan. Include disk encryption recovery access and user data considerations in operational planning.
Mental model: Stagger renovations so the whole building is not unavailable at once.
Case: A pilot update causing application failure should stop promotion to the next ring.
Task: Create a two-ring rollout schedule, health checks and a stop threshold. Rehearse recovery on a disposable VM snapshot and document which production protections snapshots do not replace.
Acceptance: A measured lab recovery and an explicit promotion decision.
Troubleshooting: A successful OS boot is insufficient if the user's business application still fails.
Deliverable: endpoint operations runbook and pilot report

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
