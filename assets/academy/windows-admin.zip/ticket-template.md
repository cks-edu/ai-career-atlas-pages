# Support record
Reported symptom:
User impact and scope:
Observed evidence (no passwords):
Hypothesis:
Least-disruptive next check:
Result:
Recovery and verification:
Owner / escalation:
Prevention:
