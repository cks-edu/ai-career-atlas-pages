# Analytics Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Metric contracts and grain

A metric needs a population, numerator, denominator, time zone and grain. A meaningful number can still be wrong if different teams use different definitions.
Mental model: A scoreboard is useful only when everyone agrees what counts as a point.
Case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30.
Task: Create the three-row SQL fixture. Write a metric contract for paid revenue, including cancellation and date handling, then implement the query and an expected-value assertion.
Acceptance: Revenue 30 with a written inclusion rule and one row per order.
Troubleshooting: If revenue is 35, inspect the status filter rather than adjusting the expected value.
Deliverable: metric-contract.md and SQL assertion

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Tested transformations

Build models in stages with explicit keys and relationships. Uniqueness, not-null and relationship tests detect different failures; none proves that the business definition is correct.
Mental model: A chain of labeled containers makes it possible to find the station that contaminated a batch.
Case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible.
Task: Create staging and reporting SQL models, add a duplicate and a missing customer reference, and write queries that return violating rows. Use dbt Core optionally after following its official setup.
Acceptance: Both defects are visible with their IDs; the clean fixture yields no violations.
Troubleshooting: A test on the final total can miss offsetting errors; inspect row-level constraints too.
Deliverable: model SQL, lineage diagram and violation tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Metric change governance

Changing a metric definition is a product change for downstream consumers. Run old and new definitions side by side and communicate why values differ before switching.
Mental model: Changing the scoreboard rules requires notifying every team using the score.
Case: Including refunded orders changes gross revenue while net revenue should subtract refunds.
Task: Create an old/new comparison table for a fixed fixture, list affected dashboards and write a versioned metric decision. Add a reconciliation check and a rollback switch in the publishing plan.
Acceptance: Every observed delta is explained by a known rule change; consumers have an owner and migration action.
Troubleshooting: An unexplained delta is a release blocker even if both SQL queries execute successfully.
Deliverable: metric migration pack and consumer impact table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
