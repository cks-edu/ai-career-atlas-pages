# Analytics Engineer

Software Engineering

Start with metric contracts and grain. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward metric migration pack and consumer impact table.

## beginner

Create the three-row SQL fixture. Write a metric contract for paid revenue, including cancellation and date handling, then implement the query and an expected-value assertion.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Metric contracts and grain
A metric needs a population, numerator, denominator, time zone and grain. A meaningful number can still be wrong if different teams use different definitions.
Mental model: A scoreboard is useful only when everyone agrees what counts as a point.
Limit: If revenue is 35, inspect the status filter rather than adjusting the expected value.
Example: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If revenue is 35, inspect the status filter rather than adjusting the expected value.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create the three-row SQL fixture. Write a metric contract for paid revenue, including cancellation and date handling, then implement the query and an expected-value assertion.
Expected: Revenue 30 with a written inclusion rule and one row per order.

6. Role workshop · debug and verify
If revenue is 35, inspect the status filter rather than adjusting the expected value. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save metric-contract.md and SQL assertion. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Revenue 30 with a written inclusion rule and one row per order.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Metric contracts and grain: If revenue is 35, inspect the status filter rather than adjusting the expected value.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: metric-contract.md and SQL assertion
Revenue 30 with a written inclusion rule and one row per order.

Interview: Work through this Analytics Engineer case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A metric needs a population, numerator, denominator, time zone and grain. A meaningful number can still be wrong if different teams use different definitions. Expected evidence: Revenue 30 with a written inclusion rule and one row per order. Diagnosis: If revenue is 35, inspect the status filter rather than adjusting the expected value. State the limits of the mental model: A scoreboard is useful only when everyone agrees what counts as a point.

Resume: Built metric-contract.md and SQL assertion using SQL and PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create staging and reporting SQL models, add a duplicate and a missing customer reference, and write queries that return violating rows. Use dbt Core optionally after following its official setup.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Tested transformations
Build models in stages with explicit keys and relationships. Uniqueness, not-null and relationship tests detect different failures; none proves that the business definition is correct.
Mental model: A chain of labeled containers makes it possible to find the station that contaminated a batch.
Limit: A test on the final total can miss offsetting errors; inspect row-level constraints too.
Example: A duplicate order key fails uniqueness even if aggregate revenue looks plausible.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A test on the final total can miss offsetting errors; inspect row-level constraints too.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A duplicate order key fails uniqueness even if aggregate revenue looks plausible. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create staging and reporting SQL models, add a duplicate and a missing customer reference, and write queries that return violating rows. Use dbt Core optionally after following its official setup.
Expected: Both defects are visible with their IDs; the clean fixture yields no violations.

6. Role workshop · debug and verify
A test on the final total can miss offsetting errors; inspect row-level constraints too. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save model SQL, lineage diagram and violation tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Both defects are visible with their IDs; the clean fixture yields no violations.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Tested transformations: A test on the final total can miss offsetting errors; inspect row-level constraints too.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: model SQL, lineage diagram and violation tests
Both defects are visible with their IDs; the clean fixture yields no violations.

Interview: Work through this Analytics Engineer case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Build models in stages with explicit keys and relationships. Uniqueness, not-null and relationship tests detect different failures; none proves that the business definition is correct. Expected evidence: Both defects are visible with their IDs; the clean fixture yields no violations. Diagnosis: A test on the final total can miss offsetting errors; inspect row-level constraints too. State the limits of the mental model: A chain of labeled containers makes it possible to find the station that contaminated a batch.

Resume: Built model SQL, lineage diagram and violation tests using SQL and PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Create an old/new comparison table for a fixed fixture, list affected dashboards and write a versioned metric decision. Add a reconciliation check and a rollback switch in the publishing plan.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Metric change governance
Changing a metric definition is a product change for downstream consumers. Run old and new definitions side by side and communicate why values differ before switching.
Mental model: Changing the scoreboard rules requires notifying every team using the score.
Limit: An unexplained delta is a release blocker even if both SQL queries execute successfully.
Example: Including refunded orders changes gross revenue while net revenue should subtract refunds.
Recall: Explain the expected result before running the exercise, then diagnose this failure: An unexplained delta is a release blocker even if both SQL queries execute successfully.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 pipeline.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Including refunded orders changes gross revenue while net revenue should subtract refunds. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create an old/new comparison table for a fixed fixture, list affected dashboards and write a versioned metric decision. Add a reconciliation check and a rollback switch in the publishing plan.
Expected: Every observed delta is explained by a known rule change; consumers have an owner and migration action.

6. Role workshop · debug and verify
An unexplained delta is a release blocker even if both SQL queries execute successfully. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save metric migration pack and consumer impact table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Every observed delta is explained by a known rule change; consumers have an owner and migration action.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Metric change governance: An unexplained delta is a release blocker even if both SQL queries execute successfully.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: metric migration pack and consumer impact table
Every observed delta is explained by a known rule change; consumers have an owner and migration action.

Interview: Work through this Analytics Engineer case: Including refunded orders changes gross revenue while net revenue should subtract refunds. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Changing a metric definition is a product change for downstream consumers. Run old and new definitions side by side and communicate why values differ before switching. Expected evidence: Every observed delta is explained by a known rule change; consumers have an owner and migration action. Diagnosis: An unexplained delta is a release blocker even if both SQL queries execute successfully. State the limits of the mental model: Changing the scoreboard rules requires notifying every team using the score.

Resume: Built metric migration pack and consumer impact table using SQL and PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
dbt: data tests: https://docs.getdbt.com/docs/build/data-tests
