# Analytics Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Keys and constraints: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.

Apply keys and constraints in Analytics Engineer: Use the concept to complete this role exercise: Define a metric with numerator, denominator and time window

Metric contracts and grain: A metric needs a population, numerator, denominator, time zone and grain. A meaningful number can still be wrong if different teams use different definitions.

### Keys and constraints

A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. In this role, work through: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. The practical workshop develops this into: Create the three-row SQL fixture. Write a metric contract for paid revenue, including cancellation and date handling, then implement the query and an expected-value assertion.

Mental model: Numbered library cards: one identity per member.

Boundary: A unique key alone does not prove the data is correct or fresh.

Role application: A scoreboard is useful only when everyone agrees what counts as a point.

A metric needs a population, numerator, denominator, time zone and grain. A meaningful number can still be wrong if different teams use different definitions.

Worked example: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30.

Shared foundation example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: SQL and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Analytics Engineer: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30.

Predict the worked case

Read this case without running a tool: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in keys and constraints.

Connect the concept to the role

Apply this rule: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A unique key alone does not prove the data is correct or fresh.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies keys and constraints to this case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Keys and constraints; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with keys and constraints. Use the glossary below, then write your prediction for: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Analytics Engineer role interview. Explain keys and constraints using this case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate keys and constraints to a system or workflow you know. Explain keys and constraints using this case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Choose a key for an imported order and explain why row position is unsafe.

Interview: Explain keys and constraints using this case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. State the evidence, one alternative and where the mental model stops.

Quiz: After the Metric contracts and grain rehearsal, check this foundation: Two clients concurrently insert the same business key. Which control protects stored uniqueness?

A database uniqueness constraint plus explicit duplicate handling.

A pre-insert lookup alone in each client.

A distinct timestamp on every retry.

Reference: A database uniqueness constraint plus explicit duplicate handling. — A lookup can race. A storage constraint rejects duplicate keys at the boundary; decide how the caller handles rejection.

Sources:

dbt: data tests: https://docs.getdbt.com/docs/build/data-tests

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Metric contracts and grain

A metric needs a population, numerator, denominator, time zone and grain. A meaningful number can still be wrong if different teams use different definitions. In this role, work through: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. The practical workshop develops this into: Create the three-row SQL fixture. Write a metric contract for paid revenue, including cancellation and date handling, then implement the query and an expected-value assertion.

Mental model: A scoreboard is useful only when everyone agrees what counts as a point.

Boundary: If revenue is 35, inspect the status filter rather than adjusting the expected value.

Worked example: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQL and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Analytics Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create the three-row SQL fixture. Write a metric contract for paid revenue, including cancellation and date handling, then implement the query and an expected-value assertion.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create the three-row SQL fixture. Write a metric contract for paid revenue, including cancellation and date handling, then implement the query and an expected-value assertion.

Expected: Revenue 30 with a written inclusion rule and one row per order.

Role workshop · debug and verify

If revenue is 35, inspect the status filter rather than adjusting the expected value. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save metric-contract.md and SQL assertion. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Revenue 30 with a written inclusion rule and one row per order.

Expected: Revenue 30 with a written inclusion rule and one row per order.

Troubleshoot: The role exercise differs from the prediction: If revenue is 35, inspect the status filter rather than adjusting the expected value.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: metric-contract.md and SQL assertion; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with metric contracts and grain. Use the glossary below, then write your prediction for: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Analytics Engineer role interview. Explain metric contracts and grain using this case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate metric contracts and grain to a system or workflow you know. Explain metric contracts and grain using this case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If revenue is 35, inspect the status filter rather than adjusting the expected value.

Interview: Explain metric contracts and grain using this case: Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Two paid orders worth 10 and 20 plus one canceled order worth 5 give paid revenue 30.

Revenue 30 with a written inclusion rule and one row per order.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Revenue 30 with a written inclusion rule and one row per order. — A metric needs a population, numerator, denominator, time zone and grain. A meaningful number can still be wrong if different teams use different definitions. Revenue 30 with a written inclusion rule and one row per order.

Sources:

dbt: data tests: https://docs.getdbt.com/docs/build/data-tests

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Idempotent processing: Repeating the same operation should have the same intended effect as applying it once.

Apply idempotent processing in Analytics Engineer: Use the concept to complete this role exercise: Build a tested transformation with explicit grain

Tested transformations: Build models in stages with explicit keys and relationships. Uniqueness, not-null and relationship tests detect different failures; none proves that the business definition is correct.

### Idempotent processing

Repeating the same operation should have the same intended effect as applying it once. In this role, work through: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. The practical workshop develops this into: Create staging and reporting SQL models, add a duplicate and a missing customer reference, and write queries that return violating rows. Use dbt Core optionally after following its official setup.

Mental model: Stamp a numbered ticket once, even if it is shown again.

Boundary: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Role application: A chain of labeled containers makes it possible to find the station that contaminated a batch.

Build models in stages with explicit keys and relationships. Uniqueness, not-null and relationship tests detect different failures; none proves that the business definition is correct.

Worked example: A duplicate order key fails uniqueness even if aggregate revenue looks plausible.

Shared foundation example: Replaying the fixture leaves two accepted orders and a total of 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: SQL and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Analytics Engineer: A duplicate order key fails uniqueness even if aggregate revenue looks plausible.

Predict the worked case

Read this case without running a tool: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in idempotent processing.

Connect the concept to the role

Apply this rule: Repeating the same operation should have the same intended effect as applying it once. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies idempotent processing to this case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Idempotent processing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotent processing. Use the glossary below, then write your prediction for: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Analytics Engineer role interview. Explain idempotent processing using this case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotent processing to a system or workflow you know. Explain idempotent processing using this case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you distinguish a replay from a correction to order a?

Interview: Explain idempotent processing using this case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. State the evidence, one alternative and where the mental model stops.

Quiz: After the Tested transformations rehearsal, check this foundation: A client retries an operation after losing the response. Which identifier best supports deduplication?

A new random key for every delivery attempt.

The same stable business-operation key for the retry.

The timestamp when the retry is received.

Reference: The same stable business-operation key for the retry. — Stable identity connects deliveries to one intended operation. Store deduplication state atomically with the effect.

Sources:

dbt: data tests: https://docs.getdbt.com/docs/build/data-tests

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Tested transformations

Build models in stages with explicit keys and relationships. Uniqueness, not-null and relationship tests detect different failures; none proves that the business definition is correct. In this role, work through: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. The practical workshop develops this into: Create staging and reporting SQL models, add a duplicate and a missing customer reference, and write queries that return violating rows. Use dbt Core optionally after following its official setup.

Mental model: A chain of labeled containers makes it possible to find the station that contaminated a batch.

Boundary: A test on the final total can miss offsetting errors; inspect row-level constraints too.

Worked example: A duplicate order key fails uniqueness even if aggregate revenue looks plausible.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQL and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Analytics Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create staging and reporting SQL models, add a duplicate and a missing customer reference, and write queries that return violating rows. Use dbt Core optionally after following its official setup.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A duplicate order key fails uniqueness even if aggregate revenue looks plausible. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create staging and reporting SQL models, add a duplicate and a missing customer reference, and write queries that return violating rows. Use dbt Core optionally after following its official setup.

Expected: Both defects are visible with their IDs; the clean fixture yields no violations.

Role workshop · debug and verify

A test on the final total can miss offsetting errors; inspect row-level constraints too. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save model SQL, lineage diagram and violation tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Both defects are visible with their IDs; the clean fixture yields no violations.

Expected: Both defects are visible with their IDs; the clean fixture yields no violations.

Troubleshoot: The role exercise differs from the prediction: A test on the final total can miss offsetting errors; inspect row-level constraints too.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: model SQL, lineage diagram and violation tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with tested transformations. Use the glossary below, then write your prediction for: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Analytics Engineer role interview. Explain tested transformations using this case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate tested transformations to a system or workflow you know. Explain tested transformations using this case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A test on the final total can miss offsetting errors; inspect row-level constraints too.

Interview: Explain tested transformations using this case: A duplicate order key fails uniqueness even if aggregate revenue looks plausible. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A duplicate order key fails uniqueness even if aggregate revenue looks plausible.

Ignore the failing case and keep only the successful screenshot.

Both defects are visible with their IDs; the clean fixture yields no violations.

Treat any successful command as proof that all business and access rules passed.

Reference: Both defects are visible with their IDs; the clean fixture yields no violations. — Build models in stages with explicit keys and relationships. Uniqueness, not-null and relationship tests detect different failures; none proves that the business definition is correct. Both defects are visible with their IDs; the clean fixture yields no violations.

Sources:

dbt: data tests: https://docs.getdbt.com/docs/build/data-tests

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Transaction and recovery: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.

Apply transaction and recovery in Analytics Engineer: Use the concept to complete this role exercise: Document a metric change, downstream impact and rollback

Metric change governance: Changing a metric definition is a product change for downstream consumers. Run old and new definitions side by side and communicate why values differ before switching.

### Transaction and recovery

A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. In this role, work through: Including refunded orders changes gross revenue while net revenue should subtract refunds. The practical workshop develops this into: Create an old/new comparison table for a fixed fixture, list affected dashboards and write a versioned metric decision. Add a reconciliation check and a rollback switch in the publishing plan.

Mental model: An envelope of changes: seal all of it or discard it.

Boundary: Transactions do not replace backups; their scope depends on the database.

Role application: Changing the scoreboard rules requires notifying every team using the score.

Changing a metric definition is a product change for downstream consumers. Run old and new definitions side by side and communicate why values differ before switching.

Worked example: Including refunded orders changes gross revenue while net revenue should subtract refunds.

Shared foundation example: Update an amount to 99, roll back, then verify the total is still 30.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: SQL and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Analytics Engineer: Including refunded orders changes gross revenue while net revenue should subtract refunds.

Predict the worked case

Read this case without running a tool: Including refunded orders changes gross revenue while net revenue should subtract refunds. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transaction and recovery.

Connect the concept to the role

Apply this rule: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Transactions do not replace backups; their scope depends on the database.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transaction and recovery to this case: Including refunded orders changes gross revenue while net revenue should subtract refunds. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Including refunded orders changes gross revenue while net revenue should subtract refunds. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Transaction and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transaction and recovery. Use the glossary below, then write your prediction for: Including refunded orders changes gross revenue while net revenue should subtract refunds. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Analytics Engineer role interview. Explain transaction and recovery using this case: Including refunded orders changes gross revenue while net revenue should subtract refunds. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transaction and recovery to a system or workflow you know. Explain transaction and recovery using this case: Including refunded orders changes gross revenue while net revenue should subtract refunds. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which checks would prove a restored database is usable?

Interview: Explain transaction and recovery using this case: Including refunded orders changes gross revenue while net revenue should subtract refunds. State the evidence, one alternative and where the mental model stops.

Quiz: After the Metric change governance rehearsal, check this foundation: Two database writes must succeed together. The second fails before commit. What should a transaction do?

Retain the first write and report full success.

Retry both writes after committing the first.

Roll back the uncommitted transaction and verify its state.

Reference: Roll back the uncommitted transaction and verify its state. — Atomicity prevents a partially committed group. It does not undo external effects outside the transaction.

Sources:

dbt: data tests: https://docs.getdbt.com/docs/build/data-tests

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html

### Metric change governance

Changing a metric definition is a product change for downstream consumers. Run old and new definitions side by side and communicate why values differ before switching. In this role, work through: Including refunded orders changes gross revenue while net revenue should subtract refunds. The practical workshop develops this into: Create an old/new comparison table for a fixed fixture, list affected dashboards and write a versioned metric decision. Add a reconciliation check and a rollback switch in the publishing plan.

Mental model: Changing the scoreboard rules requires notifying every team using the score.

Boundary: An unexplained delta is a release blocker even if both SQL queries execute successfully.

Worked example: Including refunded orders changes gross revenue while net revenue should subtract refunds.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SQL and PostgreSQL (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Analytics Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create an old/new comparison table for a fixed fixture, list affected dashboards and write a versioned metric decision. Add a reconciliation check and a rollback switch in the publishing plan.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 pipeline.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: accepted=2 total=30 rejected=c; later levels preserve the count on replay and the total after rollback.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Including refunded orders changes gross revenue while net revenue should subtract refunds. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create an old/new comparison table for a fixed fixture, list affected dashboards and write a versioned metric decision. Add a reconciliation check and a rollback switch in the publishing plan.

Expected: Every observed delta is explained by a known rule change; consumers have an owner and migration action.

Role workshop · debug and verify

An unexplained delta is a release blocker even if both SQL queries execute successfully. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save metric migration pack and consumer impact table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Every observed delta is explained by a known rule change; consumers have an owner and migration action.

Expected: Every observed delta is explained by a known rule change; consumers have an owner and migration action.

Troubleshoot: The role exercise differs from the prediction: An unexplained delta is a release blocker even if both SQL queries execute successfully.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: metric migration pack and consumer impact table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with metric change governance. Use the glossary below, then write your prediction for: Including refunded orders changes gross revenue while net revenue should subtract refunds. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Analytics Engineer role interview. Explain metric change governance using this case: Including refunded orders changes gross revenue while net revenue should subtract refunds. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate metric change governance to a system or workflow you know. Explain metric change governance using this case: Including refunded orders changes gross revenue while net revenue should subtract refunds. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: An unexplained delta is a release blocker even if both SQL queries execute successfully.

Interview: Explain metric change governance using this case: Including refunded orders changes gross revenue while net revenue should subtract refunds. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Including refunded orders changes gross revenue while net revenue should subtract refunds.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Every observed delta is explained by a known rule change; consumers have an owner and migration action.

Reference: Every observed delta is explained by a known rule change; consumers have an owner and migration action. — Changing a metric definition is a product change for downstream consumers. Run old and new definitions side by side and communicate why values differ before switching. Every observed delta is explained by a known rule change; consumers have an owner and migration action.

Sources:

dbt: data tests: https://docs.getdbt.com/docs/build/data-tests

PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
