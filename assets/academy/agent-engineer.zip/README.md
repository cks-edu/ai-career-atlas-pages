# Agent / agentic AI engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Workflow and agency. A workflow follows steps you specify; an agent can choose steps or tools. Choosing an action is different from being allowed to perform it. Then try Plan a safe appointment assistant. The three levels build toward Recoverable service-desk agent. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Workflow and agency

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Workflow and agency
A fixed workflow follows predefined steps; an agent selects actions from observations. Use a fixed path where it already solves the task and bound the choices where selection is useful.
Mental model: A train follows rails; a taxi chooses streets within its permitted area.
Boundary: More autonomy adds failure modes and is not automatically more capable.
Worked example: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The duplicate booking retry
The booking workflow permits exactly one committed booking for each approved request ID. Two request IDs produced multiple bookings; retries were treated as new business actions. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Add an idempotency record keyed by approved action and request ID before external effects.
Recall: Retry and resume the same approved action; a different action must require new authorization. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Workflow and agency: A fixed workflow follows predefined steps; an agent selects actions from observations. Use a fixed path where it already solves the task and bound the choices where selection is useful.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A workflow follows steps you specify; an agent can choose steps or tools. Choosing an action is different from being allowed to perform it.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use this fictional request: “Find a time for a study meeting tomorrow.” List the information still missing.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A workflow diagram with approval points and a missing-information list.

3. Try step 2
Draw steps for checking availability, proposing a time and asking for confirmation.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A workflow diagram with approval points and a missing-information list.

4. Try step 3
Mark which steps need fixed rules, which could use language understanding, and which must wait for the user.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A workflow diagram with approval points and a missing-information list.

5. Explain and check your result
The assistant cannot send an invitation or change a calendar merely because it generated that action. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A workflow diagram with approval points and a missing-information list. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The booking workflow permits exactly one committed booking for each approved request ID. Apply this toy-case rule manually: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two request IDs produced multiple bookings; retries were treated as new business actions. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Agent / agentic AI engineer.
Use this fictional request: “Find a time for a study meeting tomorrow.” List the information still missing.
Draw steps for checking availability, proposing a time and asking for confirmation.
Mark which steps need fixed rules, which could use language understanding, and which must wait for the user.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A workflow diagram with approval points and a missing-information list. Include beginner-worksheet.md and your completed Action-state diagram and retry proof.
Check: The assistant cannot send an invitation or change a calendar merely because it generated that action.

### Interview
Explain your beginner solution for Agent / agentic AI engineer. Use this scenario: The booking workflow permits exactly one committed booking for each approved request ID.
Review: Start with the task and permitted scope. Explain workflow and agency: A fixed workflow follows predefined steps; an agent selects actions from observations. Use a fixed path where it already solves the task and bound the choices where selection is useful. Show the input and observed output, then address Add an idempotency record keyed by approved action and request ID before external effects. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A workflow diagram with approval points and a missing-information list. Include beginner-worksheet.md and your completed Action-state diagram and retry proof.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Tool authorization boundaries

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: API design, state machines, database transactions and authorization; model APIs are an additional layer.

### Tool authorization boundaries
Treat a proposed tool call as untrusted input. Validate arguments and authorize the user, resource and action outside the model before executing it.
Mental model: A receptionist can request a key but cannot grant themselves building access.
Boundary: A system prompt is not an enforcement mechanism.
Worked example: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Recoverable service-desk agent
Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects. Implement two allowlisted tools: read account status and request an access review. Validate tool arguments and authorize the user, resource and action independently of model text.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials.
Recall: Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. Identify one observation that would contradict your claim.

### Terms
Tool authorization boundaries: Treat a proposed tool call as untrusted input. Validate arguments and authorize the user, resource and action outside the model before executing it.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Extend the API starter with propose, approve and execute endpoints. Give every action an immutable ID and store state transitions in SQLite before execution.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement two allowlisted tools: read account status and request an access review. Validate tool arguments and authorize the user, resource and action independently of model text.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The booking workflow permits exactly one committed booking for each approved request ID. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects.
Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials.
Extend the API starter with propose, approve and execute endpoints. Give every action an immutable ID and store state transitions in SQLite before execution.
Implement two allowlisted tools: read account status and request an access review. Validate tool arguments and authorize the user, resource and action independently of model text.
Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success.
Deliverables: Workflow code and action-ledger schema; Authorization and crash-recovery tests. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Agent / agentic AI engineer. Use this scenario: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.
Review: Start with the task and permitted scope. Explain tool authorization boundaries: Treat a proposed tool call as untrusted input. Validate arguments and authorize the user, resource and action outside the model before executing it. Show the input and observed output, then address Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Workflow code and action-ledger schema; Authorization and crash-recovery tests. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Durable action identity

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Durable action identity
Persist action status and stable IDs so retries can distinguish work not started from work already completed. Store evidence of side effects before acknowledging success.
Mental model: A bank receipt identifies one transfer even if the customer presses refresh.
Boundary: A database transaction cannot atomically include every external provider; reconciliation may still be required.
Worked example: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Recoverable service-desk agent
Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects. Add an idempotency key and durable result lookup around execution. Implement a worker that resumes approved pending actions after restart; optionally migrate the workflow to Temporal using its official SDK guide.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.
Recall: Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. Identify one observation that would contradict your claim.

### Terms
Durable action identity: Persist action status and stable IDs so retries can distinguish work not started from work already completed. Store evidence of side effects before acknowledging success.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Extend the API starter with propose, approve and execute endpoints. Give every action an immutable ID and store state transitions in SQLite before execution.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement two allowlisted tools: read account status and request an access review. Validate tool arguments and authorize the user, resource and action independently of model text.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add an idempotency key and durable result lookup around execution. Implement a worker that resumes approved pending actions after restart; optionally migrate the workflow to Temporal using its official SDK guide.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects.
Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials.
Extend the API starter with propose, approve and execute endpoints. Give every action an immutable ID and store state transitions in SQLite before execution.
Implement two allowlisted tools: read account status and request an access review. Validate tool arguments and authorize the user, resource and action independently of model text.
Add an idempotency key and durable result lookup around execution. Implement a worker that resumes approved pending actions after restart; optionally migrate the workflow to Temporal using its official SDK guide.
Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.
Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success.
Add compensation for a reversible action and explain why an irreversible external action needs reconciliation rather than blind retry.
Deliverables: Workflow code and action-ledger schema; Authorization and crash-recovery tests; Sequence diagram with approval and retry boundaries. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. A reviewer must reproduce one result and identify which capabilities you implemented. Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.

### Interview
Explain your advanced solution for Agent / agentic AI engineer. Use this scenario: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.
Review: Start with the task and permitted scope. Explain durable action identity: Persist action status and stable IDs so retries can distinguish work not started from work already completed. Store evidence of side effects before acknowledging success. Show the input and observed output, then address Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Workflow code and action-ledger schema; Authorization and crash-recovery tests; Sequence diagram with approval and retry boundaries. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
FastAPI — Open source · local
Typed API, validation and local service tests.
Alternative: Django REST Framework (open source); compare validation, async support and existing team skills.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Open Policy Agent — Open source · local CLI
Rego policy decisions and allow/deny regression tests.
Alternative: Cedar (open source) for authorization policy; policy language, integration and decisions must be tested again.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Temporal — Open source · hosted service optional
Durable workflow and worker recovery extension.
Alternative: An explicit persistent state machine and queue for a small workflow; managed workflow services have provider-specific semantics and costs.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
FastAPI: https://fastapi.tiangolo.com/tutorial/
Open Policy Agent: https://www.openpolicyagent.org/docs/policy-testing
Temporal: https://docs.temporal.io/
Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
Temporal: https://docs.temporal.io/
Open Policy Agent: https://www.openpolicyagent.org/docs
