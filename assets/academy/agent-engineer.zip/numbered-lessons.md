# Agent / agentic AI engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Workflow and agency: A fixed workflow follows predefined steps; an agent selects actions from observations. Use a fixed path where it already solves the task and bound the choices where selection is useful.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Workflow and agency

A fixed workflow follows predefined steps; an agent selects actions from observations. Use a fixed path where it already solves the task and bound the choices where selection is useful. In this role, work through: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A train follows rails; a taxi chooses streets within its permitted area.

Boundary: More autonomy adds failure modes and is not automatically more capable.

Worked example: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Open Policy Agent (Open source · local CLI); Temporal (Open source · hosted service optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Agent / agentic AI engineer: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund.

Predict the worked case

Read this case without running a tool: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in workflow and agency.

Connect the concept to the role

Apply this rule: A fixed workflow follows predefined steps; an agent selects actions from observations. Use a fixed path where it already solves the task and bound the choices where selection is useful. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More autonomy adds failure modes and is not automatically more capable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies workflow and agency to this case: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Workflow and agency; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with workflow and agency. Use the glossary below, then write your prediction for: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent / agentic AI engineer role interview. Explain workflow and agency using this case: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate workflow and agency to a system or workflow you know. Explain workflow and agency using this case: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain workflow and agency using this case: A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund.

A fixed workflow follows predefined steps; an agent selects actions from observations. Use a fixed path where it already solves the task and bound the choices where selection is useful.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: A fixed workflow follows predefined steps; an agent selects actions from observations. Use a fixed path where it already solves the task and bound the choices where selection is useful. — A fixed workflow follows predefined steps; an agent selects actions from observations. Use a fixed path where it already solves the task and bound the choices where selection is useful. More autonomy adds failure modes and is not automatically more capable.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Open Policy Agent: https://www.openpolicyagent.org/docs/policy-testing

Temporal: https://docs.temporal.io/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Temporal: https://docs.temporal.io/

Open Policy Agent: https://www.openpolicyagent.org/docs

### Diagnose: The duplicate booking retry

The booking workflow permits exactly one committed booking for each approved request ID. Two request IDs produced multiple bookings; retries were treated as new business actions. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Add an idempotency record keyed by approved action and request ID before external effects. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A train follows rails; a taxi chooses streets within its permitted area.

A support workflow always retrieves policy then asks for confirmation; an agent may choose a search tool but cannot approve a refund.

Worked example: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Add an idempotency record keyed by approved action and request ID before external effects.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: FastAPI (Open source · local); Open Policy Agent (Open source · local CLI); Temporal (Open source · hosted service optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The booking workflow permits exactly one committed booking for each approved request ID. Two request IDs produced multiple bookings; retries were treated as new business actions. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The booking workflow permits exactly one committed booking for each approved request ID. Apply this toy-case rule manually: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A workflow follows steps you specify; an agent can choose steps or tools. Choosing an action is different from being allowed to perform it.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use this fictional request: “Find a time for a study meeting tomorrow.” List the information still missing.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A workflow diagram with approval points and a missing-information list.

Preparation · Try step 2

Draw steps for checking availability, proposing a time and asking for confirmation.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A workflow diagram with approval points and a missing-information list.

Preparation · Try step 3

Mark which steps need fixed rules, which could use language understanding, and which must wait for the user.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A workflow diagram with approval points and a missing-information list.

Preparation · Explain and check your result

The assistant cannot send an invitation or change a calendar merely because it generated that action. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A workflow diagram with approval points and a missing-information list. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The booking workflow permits exactly one committed booking for each approved request ID. Apply this toy-case rule manually: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two request IDs produced multiple bookings; retries were treated as new business actions. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two request IDs produced multiple bookings; retries were treated as new business actions. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the duplicate booking retry. Use the glossary below, then write your prediction for: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Add an idempotency record keyed by approved action and request ID before external effects. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent / agentic AI engineer role interview. Explain diagnose: the duplicate booking retry using this case: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Add an idempotency record keyed by approved action and request ID before external effects. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the duplicate booking retry to a system or workflow you know. Explain diagnose: the duplicate booking retry using this case: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Add an idempotency record keyed by approved action and request ID before external effects. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Retry and resume the same approved action; a different action must require new authorization. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the duplicate booking retry using this case: Review when commits_for_request >= 2 (count). This is a declared toy-case contract, not an industry standard. Add an idempotency record keyed by approved action and request ID before external effects. State the evidence, one alternative and where the mental model stops.

Quiz: The duplicate booking retry: The booking workflow permits exactly one committed booking for each approved request ID.

Change the acceptance rule after seeing an inconvenient result.

Add an idempotency record keyed by approved action and request ID before external effects.

Omit failed cases and report only the successful demonstrations.

Reference: Add an idempotency record keyed by approved action and request ID before external effects. — Add an idempotency record keyed by approved action and request ID before external effects. Retry and resume the same approved action; a different action must require new authorization.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Open Policy Agent: https://www.openpolicyagent.org/docs/policy-testing

Temporal: https://docs.temporal.io/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Temporal: https://docs.temporal.io/

Open Policy Agent: https://www.openpolicyagent.org/docs

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: API design, state machines, database transactions and authorization; model APIs are an additional layer.

Terms:

Tool authorization boundaries: Treat a proposed tool call as untrusted input. Validate arguments and authorize the user, resource and action outside the model before executing it.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Tool authorization boundaries

Treat a proposed tool call as untrusted input. Validate arguments and authorize the user, resource and action outside the model before executing it. In this role, work through: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A receptionist can request a key but cannot grant themselves building access.

Boundary: A system prompt is not an enforcement mechanism.

Worked example: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: API design, state machines, database transactions and authorization; model APIs are an additional layer.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Open Policy Agent (Open source · local CLI); Temporal (Open source · hosted service optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Agent / agentic AI engineer: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it.

Predict the worked case

Read this case without running a tool: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in tool authorization boundaries.

Connect the concept to the role

Apply this rule: Treat a proposed tool call as untrusted input. Validate arguments and authorize the user, resource and action outside the model before executing it. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A system prompt is not an enforcement mechanism.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies tool authorization boundaries to this case: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Tool authorization boundaries; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with tool authorization boundaries. Use the glossary below, then write your prediction for: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent / agentic AI engineer role interview. Explain tool authorization boundaries using this case: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate tool authorization boundaries to a system or workflow you know. Explain tool authorization boundaries using this case: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain tool authorization boundaries using this case: The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it.

Treat a passing starter as proof of the whole role workflow.

Treat a proposed tool call as untrusted input. Validate arguments and authorize the user, resource and action outside the model before executing it.

Ignore the failure because the tool produced an output.

Reference: Treat a proposed tool call as untrusted input. Validate arguments and authorize the user, resource and action outside the model before executing it. — Treat a proposed tool call as untrusted input. Validate arguments and authorize the user, resource and action outside the model before executing it. A system prompt is not an enforcement mechanism.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Open Policy Agent: https://www.openpolicyagent.org/docs/policy-testing

Temporal: https://docs.temporal.io/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Temporal: https://docs.temporal.io/

Open Policy Agent: https://www.openpolicyagent.org/docs

### Integrate: Recoverable service-desk agent

Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects. Implement two allowlisted tools: read account status and request an access review. Validate tool arguments and authorize the user, resource and action independently of model text. In this role, work through: Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A receptionist can request a key but cannot grant themselves building access.

The model requests delete_ticket(42). A read-only session denies it even if the prompt says the manager approved it.

Worked example: Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Open Policy Agent (Open source · local CLI); Temporal (Open source · hosted service optional)

Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Extend the API starter with propose, approve and execute endpoints. Give every action an immutable ID and store state transitions in SQLite before execution.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement two allowlisted tools: read account status and request an access review. Validate tool arguments and authorize the user, resource and action independently of model text.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The booking workflow permits exactly one committed booking for each approved request ID. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-intermediate-2.md: Workflow code and action-ledger schema; Authorization and crash-recovery tests. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: recoverable service-desk agent. Use the glossary below, then write your prediction for: Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent / agentic AI engineer role interview. Explain integrate: recoverable service-desk agent using this case: Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: recoverable service-desk agent to a system or workflow you know. Explain integrate: recoverable service-desk agent using this case: Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. Identify one observation that would contradict your claim.

Interview: Explain integrate: recoverable service-desk agent using this case: Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Recoverable service-desk agent at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success.

Reference: Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. — Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Open Policy Agent: https://www.openpolicyagent.org/docs/policy-testing

Temporal: https://docs.temporal.io/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Temporal: https://docs.temporal.io/

Open Policy Agent: https://www.openpolicyagent.org/docs

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Durable action identity: Persist action status and stable IDs so retries can distinguish work not started from work already completed. Store evidence of side effects before acknowledging success.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Durable action identity

Persist action status and stable IDs so retries can distinguish work not started from work already completed. Store evidence of side effects before acknowledging success. In this role, work through: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A bank receipt identifies one transfer even if the customer presses refresh.

Boundary: A database transaction cannot atomically include every external provider; reconciliation may still be required.

Worked example: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Open Policy Agent (Open source · local CLI); Temporal (Open source · hosted service optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Agent / agentic AI engineer: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed.

Predict the worked case

Read this case without running a tool: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in durable action identity.

Connect the concept to the role

Apply this rule: Persist action status and stable IDs so retries can distinguish work not started from work already completed. Store evidence of side effects before acknowledging success. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A database transaction cannot atomically include every external provider; reconciliation may still be required.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies durable action identity to this case: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Durable action identity; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with durable action identity. Use the glossary below, then write your prediction for: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent / agentic AI engineer role interview. Explain durable action identity using this case: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate durable action identity to a system or workflow you know. Explain durable action identity using this case: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain durable action identity using this case: After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Persist action status and stable IDs so retries can distinguish work not started from work already completed. Store evidence of side effects before acknowledging success.

Reference: Persist action status and stable IDs so retries can distinguish work not started from work already completed. Store evidence of side effects before acknowledging success. — Persist action status and stable IDs so retries can distinguish work not started from work already completed. Store evidence of side effects before acknowledging success. A database transaction cannot atomically include every external provider; reconciliation may still be required.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Open Policy Agent: https://www.openpolicyagent.org/docs/policy-testing

Temporal: https://docs.temporal.io/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Temporal: https://docs.temporal.io/

Open Policy Agent: https://www.openpolicyagent.org/docs

### Defend: Recoverable service-desk agent

Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects. Add an idempotency key and durable result lookup around execution. Implement a worker that resumes approved pending actions after restart; optionally migrate the workflow to Temporal using its official SDK guide. In this role, work through: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A bank receipt identifies one transfer even if the customer presses refresh.

After a timeout, query the prior action ID before issuing another refund. Return the stored result if the action completed.

Worked example: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Open Policy Agent (Open source · local CLI); Temporal (Open source · hosted service optional)

Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Create ten fictional requests, a local inventory of accounts and an append-only action ledger. Use simulated account changes; do not connect real administration credentials.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Extend the API starter with propose, approve and execute endpoints. Give every action an immutable ID and store state transitions in SQLite before execution.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement two allowlisted tools: read account status and request an access review. Validate tool arguments and authorize the user, resource and action independently of model text.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add an idempotency key and durable result lookup around execution. Implement a worker that resumes approved pending actions after restart; optionally migrate the workflow to Temporal using its official SDK guide.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. A reviewer must reproduce one result and identify which capabilities you implemented. Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-advanced-2.md: Workflow code and action-ledger schema; Authorization and crash-recovery tests; Sequence diagram with approval and retry boundaries. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: recoverable service-desk agent. Use the glossary below, then write your prediction for: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Agent / agentic AI engineer role interview. Explain defend: recoverable service-desk agent using this case: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: recoverable service-desk agent to a system or workflow you know. Explain defend: recoverable service-desk agent using this case: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success. Identify one observation that would contradict your claim.

Interview: Explain defend: recoverable service-desk agent using this case: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Recoverable service-desk agent at this level?

Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state. — Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state. Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Open Policy Agent: https://www.openpolicyagent.org/docs/policy-testing

Temporal: https://docs.temporal.io/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

Temporal: https://docs.temporal.io/

Open Policy Agent: https://www.openpolicyagent.org/docs
