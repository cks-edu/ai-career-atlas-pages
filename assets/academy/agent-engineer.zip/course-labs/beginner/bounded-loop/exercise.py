def run(results,max_steps=3):
    if max_steps<1: raise ValueError('Positive budget required')
    for step,result in enumerate(results,1):
        if step>max_steps: return 'budget_exhausted'
        if result=='resolved': return 'resolved'
    return 'budget_exhausted'
assert run(['retry','retry','retry','resolved'])=='budget_exhausted'
assert run(['retry','resolved'])=='resolved'
print('PASS: bounded work and honest stopping status')
