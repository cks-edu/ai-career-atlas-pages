# Stop a loop before it consumes the budget

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://docs.langchain.com/oss/python/langgraph/workflows-agents
https://opentelemetry.io/docs/concepts/observability-primer/
