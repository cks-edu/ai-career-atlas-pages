from typing import TypedDict
from langgraph.graph import StateGraph, START, END
class State(TypedDict):
    validated: bool
builder = StateGraph(State)
builder.add_node("validate", lambda state: {"validated": True})
builder.add_edge(START, "validate")
builder.add_edge("validate", END)
graph = builder.compile()
assert graph.invoke({"validated": False})["validated"] is True
print("PASS: real LangGraph execution; no model or external tool")
