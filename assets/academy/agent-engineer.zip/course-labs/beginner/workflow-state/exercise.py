allowed={('new','validate'):'ready',('ready','finish'):'done'}
def step(state,event):
    if (state,event) not in allowed: raise ValueError('Invalid transition')
    return allowed[(state,event)]
assert step(step('new','validate'),'finish')=='done'
try: step('new','finish')
except ValueError: pass
else: raise AssertionError('Inspection was skipped')
print('PASS: allowed transitions only')
