import json
def dispatch(name,text):
    args=json.loads(text)
    if name!='status' or type(args) is not dict or set(args)!={'account_id'}: raise ValueError('Contract')
    if type(args['account_id']) is not str or not args['account_id'].startswith('acct-'): raise ValueError('ID')
    return {'account_id':args['account_id'],'status':'demo'}
assert dispatch('status','{"account_id":"acct-7"}')['status']=='demo'
for name,args in [('shell','{}'),('status','{"account_id":7}'),('status','{"account_id":"acct-7","admin":true}')]:
    try: dispatch(name,args)
    except ValueError: continue
    raise AssertionError('Bad call accepted')
print('PASS: tool name, shape and ID type')
