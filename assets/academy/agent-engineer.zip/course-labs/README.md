# Agent / agentic AI engineer — core lessons

Build an agent workflow from explicit state and checked tool requests through budgets, checkpoints, exact-action approval, repeated-call safety and operational traces. New core lessons lead into the preserved API and portfolio workshops. Model generation is optional; execution authority always stays in the application.

Download and extract this course practice ZIP. New core lesson files are in course-labs/<level>/<lesson-slug>/. Each lesson names its runtime, exact file and run command. The browser records your evidence; it does not execute Java, Python, containers or cloud commands for you.

Read numbered-lessons.md for the exact sequence, examples, checks and source links. The original course files and lessons are preserved. Change a copy of each reference example and add at least one failing case; unchanged reference assertions are preparation, not proof of your independent work.

Portfolio direction: A synthetic support agent with validated proposals, scoped approval, persistent operation IDs, safe recovery and failure traces.
