import hashlib,json
def digest(action):
    return hashlib.sha256(json.dumps(action,sort_keys=True,separators=(',',':')).encode()).hexdigest()
action={'tool':'request_review','target':'acct-7','version':1}
approved=digest(action)
assert digest(dict(action))==approved
changed={**action,'target':'acct-8'}
assert digest(changed)!=approved
print('PASS: changed action needs a new approval')
