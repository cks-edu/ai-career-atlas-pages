import json
state={'run_id':'run-1','stage':'validated','steps':1}
saved=json.dumps(state,sort_keys=True)
state['stage']='crashed'
restored=json.loads(saved)
assert restored['stage']=='validated'
assert restored['run_id']=='run-1'
restored['stage']='awaiting_approval'
print(json.dumps(restored,sort_keys=True))
