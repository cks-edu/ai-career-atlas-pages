results={};effects=[]
def execute(operation_id,payload):
    if operation_id in results:
        previous,result=results[operation_id]
        if previous!=payload: raise ValueError('Conflicting operation ID')
        return result
    result={'review_id':len(effects)+1}
    effects.append(dict(payload));results[operation_id]=(dict(payload),result)
    return result
assert execute('op-1',{'account':'7'})==execute('op-1',{'account':'7'})
assert len(effects)==1
try: execute('op-1',{'account':'8'})
except ValueError: pass
else: raise AssertionError('Conflict accepted')
print('PASS: one effect; changed replay rejected')
