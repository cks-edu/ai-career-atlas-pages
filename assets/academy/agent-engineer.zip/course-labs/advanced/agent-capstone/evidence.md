# Capstone: an approval-based support agent

## Input and setup
Runtime, folder and changed input:

## Observed versus expected
Prediction, actual command output and comparison:

## Failure and recovery
Failing input, evidence, cause, repair and new check:

## Limitation
What this does not establish:

## Sources
https://docs.langchain.com/oss/python/langgraph/workflows-agents
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
https://genai.owasp.org/llmrisk/llm01-prompt-injection/
