request={'run_id':'r1','step':2,'tool':'status','outcome':'denied','token':'secret','prompt':'private'}
allowed={'run_id','step','tool','outcome'}
event={k:v for k,v in request.items() if k in allowed}
assert set(event)==allowed
assert 'secret' not in str(event) and 'private' not in str(event)
print(event)
