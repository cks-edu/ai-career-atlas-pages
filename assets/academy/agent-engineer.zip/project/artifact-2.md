# Authorization and crash-recovery tests

Project: Recoverable service-desk agent
Status: blank work product — not completed evidence

## Purpose and audience
Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects.

## Required content
Implement two allowlisted tools: read account status and request an access review. Validate tool arguments and authorize the user, resource and action independently of model text.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success.

## Failure evidence
Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
