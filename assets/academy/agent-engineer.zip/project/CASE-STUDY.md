# Recoverable service-desk agent

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build an agent that proposes service-desk actions and can recover after a crash without duplicating side effects.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Run normal, denied, expired-approval, duplicate and interrupted cases. Report task success, duplicate side effects and manual escalations; a tool call is not itself task success.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Crash the worker after writing its result but before acknowledging completion. Restart and replay the same action. The ledger must contain one effective change and a recoverable final state.

## Limitations and next iteration
Add compensation for a reversible action and explain why an irreversible external action needs reconciliation rather than blind retry.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
