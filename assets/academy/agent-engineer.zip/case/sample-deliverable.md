# SAMPLE — Action-state diagram and retry proof
Role: Agent / agentic AI engineer
Case: The duplicate booking retry
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The booking workflow permits exactly one committed booking for each approved request ID.

## Evidence table
| Record | commits_for_request (count) | Decision |
|---|---:|---|
| case-1 | 1 | within_demo_bound |
| case-2 | 2 | review |
| case-3 | 1 | within_demo_bound |
| case-4 | 3 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-2, case-4.
Two request IDs produced multiple bookings; retries were treated as new business actions.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Add an idempotency record keyed by approved action and request ID before external effects.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in agent / agentic ai engineer.
Before release: Retry and resume the same approved action; a different action must require new authorization.

## Design choice and trade-off
Separate proposed and approved actions; use durable state and idempotent external operations.
A durable workflow can retry safely only when the external operation has a reliable deduplication boundary.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Travel approval agent: Retries and interrupted sessions preserve one approved booking.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
