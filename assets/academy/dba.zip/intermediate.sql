\set ON_ERROR_STOP on
BEGIN;
UPDATE learning.tickets SET status='closed' WHERE id=1;
ROLLBACK;
DO $$ BEGIN IF (SELECT status FROM learning.tickets WHERE id=1) <> 'open' THEN RAISE EXCEPTION 'Rollback did not preserve original status'; END IF; END $$;
CREATE INDEX IF NOT EXISTS ticket_status ON learning.tickets(status);
EXPLAIN SELECT * FROM learning.tickets WHERE status='open';
SELECT 'PASS postgres intermediate' AS result;
