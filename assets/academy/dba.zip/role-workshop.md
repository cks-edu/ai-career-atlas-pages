# Database Administrator — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Constraints and database ownership

Database constraints protect data regardless of the client. Give tables stable keys and enforce required fields before trusting application validation.
Mental model: The archive rejects invalid filing even when a different clerk delivers it.
Case: A duplicate ticket ID or missing required title must be rejected by PostgreSQL.
Task: Run the included beginner SQL in the disposable container. Attempt duplicate-key and NULL inserts separately, record SQL errors, then query the two original records.
Acceptance: Both invalid writes fail and the baseline count remains two.
Troubleshooting: If a NULL succeeds, inspect the actual table definition rather than the intended migration file.
Deliverable: constraint audit with SQL and observed errors

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Query plans and locks

EXPLAIN describes a chosen plan, not a universal promise that an index is faster. Locks protect concurrent changes and can make a healthy query wait behind another transaction.
Mental model: A road map shows the route; a locked gate explains why the vehicle is not moving.
Case: With two rows a sequential scan can be sensible; a second update may wait for the first transaction.
Task: Run the intermediate script, then use two psql sessions on the lab database. Hold an UPDATE transaction in one, set a short lock_timeout in the other and attempt the same row. Roll back both sessions.
Acceptance: The second operation reports a lock timeout; data returns to its initial state after rollback.
Troubleshooting: Do not kill arbitrary sessions; identify the lab transaction and release it with rollback.
Deliverable: plan comparison and two-session blocking timeline

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Restore verification

A backup artifact is not recovery evidence until it restores into an independent target and passes business and constraint checks. Recovery time and recoverable data age are different measures.
Mental model: A spare key is useful only if it opens the intended door.
Case: The restored learning schema contains two tickets and still rejects duplicate IDs.
Task: Run the advanced dump/restore guide into atlas_restore. Record start/end times, compare source/restored rows and repeat one constraint failure. Preserve the source database throughout.
Acceptance: Matching records and enforced constraints; measured restore time with environment details.
Troubleshooting: A dump of one schema does not automatically include every role or external dependency; inventory what was outside scope.
Deliverable: restore transcript, RTO/RPO assumptions and backup inventory

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
