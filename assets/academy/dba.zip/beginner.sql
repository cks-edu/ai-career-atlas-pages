\set ON_ERROR_STOP on
CREATE SCHEMA IF NOT EXISTS learning;
CREATE TABLE IF NOT EXISTS learning.tickets(id integer PRIMARY KEY, title text NOT NULL, status text NOT NULL CHECK(status IN ('open','closed')));
INSERT INTO learning.tickets VALUES(1,'Read SQL','open'),(2,'Try a backup','open') ON CONFLICT(id) DO NOTHING;
SELECT count(*) AS ticket_count FROM learning.tickets;
DO $$ BEGIN IF (SELECT count(*) FROM learning.tickets) <> 2 THEN RAISE EXCEPTION 'Expected two starter rows'; END IF; END $$;
SELECT 'PASS postgres beginner' AS result;
