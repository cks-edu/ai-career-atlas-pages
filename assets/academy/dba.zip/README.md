# Database Administrator

Software Engineering

Start with constraints and database ownership. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward restore transcript, RTO/RPO assumptions and backup inventory.

## beginner

Run the included beginner SQL in the disposable container. Attempt duplicate-key and NULL inserts separately, record SQL errors, then query the two original records.

Setup: Install Docker using the official guide and verify docker info. Use the disposable container atlas-course-pg only; never use these reset commands on a real database. SQL files are included. No network port is exposed. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Constraints and database ownership
Database constraints protect data regardless of the client. Give tables stable keys and enforce required fields before trusting application validation.
Mental model: The archive rejects invalid filing even when a different clerk delivers it.
Limit: If a NULL succeeds, inspect the actual table definition rather than the intended migration file.
Example: A duplicate ticket ID or missing required title must be rejected by PostgreSQL.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If a NULL succeeds, inspect the actual table definition rather than the intended migration file.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Start a disposable PostgreSQL server
Use a fresh container name. The password is a public, disposable lab value; the server is not exposed to the host network. Wait for pg_isready to report accepting connections.
```
docker run --name atlas-course-pg -e POSTGRES_PASSWORD=local-lab-only -d postgres:16
docker exec atlas-course-pg pg_isready -U postgres
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The final readiness check reports accepting connections.

3. Load and inspect the baseline
Copy the SQL files into the container. The beginner script creates two synthetic tickets and checks the count.
```
docker cp beginner.sql atlas-course-pg:/tmp/beginner.sql
docker cp intermediate.sql atlas-course-pg:/tmp/intermediate.sql
docker cp advanced.sql atlas-course-pg:/tmp/advanced.sql
docker exec atlas-course-pg psql -U postgres -f /tmp/beginner.sql
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: ticket_count = 2 and PASS postgres beginner.

4. Record recovery evidence
Create a table with keys and constraints
Expected: A run log with source/restored counts, constraint checks and a distinction between a logical dump and point-in-time recovery.

5. Role workshop · predict
A duplicate ticket ID or missing required title must be rejected by PostgreSQL. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

6. Role workshop · build
Run the included beginner SQL in the disposable container. Attempt duplicate-key and NULL inserts separately, record SQL errors, then query the two original records.
Expected: Both invalid writes fail and the baseline count remains two.

7. Role workshop · debug and verify
If a NULL succeeds, inspect the actual table definition rather than the intended migration file. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

8. Role workshop · package the evidence
Save constraint audit with SQL and observed errors. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Both invalid writes fail and the baseline count remains two.

Troubleshooting:
Container name already exists: Reuse only your own earlier lab container, or choose a new name consistently. Do not remove an unfamiliar container.
Server is still starting: Run docker exec atlas-course-pg pg_isready -U postgres again after inspecting docker logs atlas-course-pg.
atlas_restore already exists: Choose a new restore database name and use it consistently; do not overwrite the previous evidence.
Restore has errors: Keep ON_ERROR_STOP enabled, inspect the first failing SQL statement, and restore into a new empty lab database.
Constraints and database ownership: If a NULL succeeds, inspect the actual table definition rather than the intended migration file.
Cleanup: After keeping the backup and evidence, run docker rm -f atlas-course-pg. This removes this disposable lab container and its database; keep your host backup file if needed.

Portfolio: constraint audit with SQL and observed errors
Both invalid writes fail and the baseline count remains two.

Interview: Work through this Database Administrator case: A duplicate ticket ID or missing required title must be rejected by PostgreSQL. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Database constraints protect data regardless of the client. Give tables stable keys and enforce required fields before trusting application validation. Expected evidence: Both invalid writes fail and the baseline count remains two. Diagnosis: If a NULL succeeds, inspect the actual table definition rather than the intended migration file. State the limits of the mental model: The archive rejects invalid filing even when a different clerk delivers it.

Resume: Built constraint audit with SQL and observed errors using PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Run the intermediate script, then use two psql sessions on the lab database. Hold an UPDATE transaction in one, set a short lock_timeout in the other and attempt the same row. Roll back both sessions.

Setup: Install Docker using the official guide and verify docker info. Use the disposable container atlas-course-pg only; never use these reset commands on a real database. SQL files are included. No network port is exposed. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Query plans and locks
EXPLAIN describes a chosen plan, not a universal promise that an index is faster. Locks protect concurrent changes and can make a healthy query wait behind another transaction.
Mental model: A road map shows the route; a locked gate explains why the vehicle is not moving.
Limit: Do not kill arbitrary sessions; identify the lab transaction and release it with rollback.
Example: With two rows a sequential scan can be sensible; a second update may wait for the first transaction.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not kill arbitrary sessions; identify the lab transaction and release it with rollback.

1. Start a disposable PostgreSQL server
Use a fresh container name. The password is a public, disposable lab value; the server is not exposed to the host network. Wait for pg_isready to report accepting connections.
```
docker run --name atlas-course-pg -e POSTGRES_PASSWORD=local-lab-only -d postgres:16
docker exec atlas-course-pg pg_isready -U postgres
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The final readiness check reports accepting connections.

2. Load and inspect the baseline
Copy the SQL files into the container. The beginner script creates two synthetic tickets and checks the count.
```
docker cp beginner.sql atlas-course-pg:/tmp/beginner.sql
docker cp intermediate.sql atlas-course-pg:/tmp/intermediate.sql
docker cp advanced.sql atlas-course-pg:/tmp/advanced.sql
docker exec atlas-course-pg psql -U postgres -f /tmp/beginner.sql
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: ticket_count = 2 and PASS postgres beginner.

3. Prove rollback and inspect a plan
The script rolls back a change, creates an index and shows a query plan. With two rows a sequential scan can be the correct choice.
```
docker exec atlas-course-pg psql -U postgres -f /tmp/intermediate.sql
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS postgres intermediate; ticket 1 remains open.

4. Record recovery evidence
Inspect a query plan and test transaction rollback
Expected: A run log with source/restored counts, constraint checks and a distinction between a logical dump and point-in-time recovery.

5. Role workshop · predict
With two rows a sequential scan can be sensible; a second update may wait for the first transaction. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

6. Role workshop · build
Run the intermediate script, then use two psql sessions on the lab database. Hold an UPDATE transaction in one, set a short lock_timeout in the other and attempt the same row. Roll back both sessions.
Expected: The second operation reports a lock timeout; data returns to its initial state after rollback.

7. Role workshop · debug and verify
Do not kill arbitrary sessions; identify the lab transaction and release it with rollback. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

8. Role workshop · package the evidence
Save plan comparison and two-session blocking timeline. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The second operation reports a lock timeout; data returns to its initial state after rollback.

Troubleshooting:
Container name already exists: Reuse only your own earlier lab container, or choose a new name consistently. Do not remove an unfamiliar container.
Server is still starting: Run docker exec atlas-course-pg pg_isready -U postgres again after inspecting docker logs atlas-course-pg.
atlas_restore already exists: Choose a new restore database name and use it consistently; do not overwrite the previous evidence.
Restore has errors: Keep ON_ERROR_STOP enabled, inspect the first failing SQL statement, and restore into a new empty lab database.
Query plans and locks: Do not kill arbitrary sessions; identify the lab transaction and release it with rollback.
Cleanup: After keeping the backup and evidence, run docker rm -f atlas-course-pg. This removes this disposable lab container and its database; keep your host backup file if needed.

Portfolio: plan comparison and two-session blocking timeline
The second operation reports a lock timeout; data returns to its initial state after rollback.

Interview: Work through this Database Administrator case: With two rows a sequential scan can be sensible; a second update may wait for the first transaction. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: EXPLAIN describes a chosen plan, not a universal promise that an index is faster. Locks protect concurrent changes and can make a healthy query wait behind another transaction. Expected evidence: The second operation reports a lock timeout; data returns to its initial state after rollback. Diagnosis: Do not kill arbitrary sessions; identify the lab transaction and release it with rollback. State the limits of the mental model: A road map shows the route; a locked gate explains why the vehicle is not moving.

Resume: Built plan comparison and two-session blocking timeline using PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run the advanced dump/restore guide into atlas_restore. Record start/end times, compare source/restored rows and repeat one constraint failure. Preserve the source database throughout.

Setup: Install Docker using the official guide and verify docker info. Use the disposable container atlas-course-pg only; never use these reset commands on a real database. SQL files are included. No network port is exposed. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Restore verification
A backup artifact is not recovery evidence until it restores into an independent target and passes business and constraint checks. Recovery time and recoverable data age are different measures.
Mental model: A spare key is useful only if it opens the intended door.
Limit: A dump of one schema does not automatically include every role or external dependency; inventory what was outside scope.
Example: The restored learning schema contains two tickets and still rejects duplicate IDs.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A dump of one schema does not automatically include every role or external dependency; inventory what was outside scope.

1. Start a disposable PostgreSQL server
Use a fresh container name. The password is a public, disposable lab value; the server is not exposed to the host network. Wait for pg_isready to report accepting connections.
```
docker run --name atlas-course-pg -e POSTGRES_PASSWORD=local-lab-only -d postgres:16
docker exec atlas-course-pg pg_isready -U postgres
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The final readiness check reports accepting connections.

2. Load and inspect the baseline
Copy the SQL files into the container. The beginner script creates two synthetic tickets and checks the count.
```
docker cp beginner.sql atlas-course-pg:/tmp/beginner.sql
docker cp intermediate.sql atlas-course-pg:/tmp/intermediate.sql
docker cp advanced.sql atlas-course-pg:/tmp/advanced.sql
docker exec atlas-course-pg psql -U postgres -f /tmp/beginner.sql
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: ticket_count = 2 and PASS postgres beginner.

3. Prove rollback and inspect a plan
The script rolls back a change, creates an index and shows a query plan. With two rows a sequential scan can be the correct choice.
```
docker exec atlas-course-pg psql -U postgres -f /tmp/intermediate.sql
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS postgres intermediate; ticket 1 remains open.

4. Restore into a separate database
Write the dump inside the container to avoid host-shell encoding differences. Restore into a new database, then verify the data. Preserve the source database for comparison.
```
docker exec atlas-course-pg pg_dump -U postgres -d postgres -n learning -f /tmp/learning.sql
docker cp atlas-course-pg:/tmp/learning.sql ./learning-backup.sql
docker exec atlas-course-pg createdb -U postgres atlas_restore
docker exec atlas-course-pg psql -U postgres -d atlas_restore -v ON_ERROR_STOP=1 -f /tmp/learning.sql
docker exec atlas-course-pg psql -U postgres -d atlas_restore -f /tmp/advanced.sql
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS postgres advanced on the restored database.

5. Record recovery evidence
Back up and restore into a different database; verify row counts and constraints
Expected: A run log with source/restored counts, constraint checks and a distinction between a logical dump and point-in-time recovery.

6. Role workshop · predict
The restored learning schema contains two tickets and still rejects duplicate IDs. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

7. Role workshop · build
Run the advanced dump/restore guide into atlas_restore. Record start/end times, compare source/restored rows and repeat one constraint failure. Preserve the source database throughout.
Expected: Matching records and enforced constraints; measured restore time with environment details.

8. Role workshop · debug and verify
A dump of one schema does not automatically include every role or external dependency; inventory what was outside scope. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

9. Role workshop · package the evidence
Save restore transcript, RTO/RPO assumptions and backup inventory. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Matching records and enforced constraints; measured restore time with environment details.

Troubleshooting:
Container name already exists: Reuse only your own earlier lab container, or choose a new name consistently. Do not remove an unfamiliar container.
Server is still starting: Run docker exec atlas-course-pg pg_isready -U postgres again after inspecting docker logs atlas-course-pg.
atlas_restore already exists: Choose a new restore database name and use it consistently; do not overwrite the previous evidence.
Restore has errors: Keep ON_ERROR_STOP enabled, inspect the first failing SQL statement, and restore into a new empty lab database.
Restore verification: A dump of one schema does not automatically include every role or external dependency; inventory what was outside scope.
Cleanup: After keeping the backup and evidence, run docker rm -f atlas-course-pg. This removes this disposable lab container and its database; keep your host backup file if needed.

Portfolio: restore transcript, RTO/RPO assumptions and backup inventory
Matching records and enforced constraints; measured restore time with environment details.

Interview: Work through this Database Administrator case: The restored learning schema contains two tickets and still rejects duplicate IDs. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A backup artifact is not recovery evidence until it restores into an independent target and passes business and constraint checks. Recovery time and recoverable data age are different measures. Expected evidence: Matching records and enforced constraints; measured restore time with environment details. Diagnosis: A dump of one schema does not automatically include every role or external dependency; inventory what was outside scope. State the limits of the mental model: A spare key is useful only if it opens the intended door.

Resume: Built restore transcript, RTO/RPO assumptions and backup inventory using PostgreSQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
