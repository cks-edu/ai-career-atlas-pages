# Database Administrator

Software Engineering

Begin with keys and constraints. Create a table with keys and constraints. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Create a table with keys and constraints

Setup: Install Docker using the official guide and verify docker info. Use the disposable container atlas-course-pg only; never use these reset commands on a real database. SQL files are included. No network port is exposed.

### Keys and constraints
A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs.
Mental model: Numbered library cards: one identity per member.
Limit: A unique key alone does not prove the data is correct or fresh.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10.
Recall: Choose a key for an imported order and explain why row position is unsafe.

### Apply keys and constraints in Database Administrator
Use the concept to complete this role exercise: Create a table with keys and constraints
Mental model: Numbered library cards: one identity per member.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Orders a=10 and b=20 total 30; duplicate a should not add another 10. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Read the declared configuration
Open the supplied YAML or SQL. Identify the resource/table name, expected count and a field that could cause a failure.
Expected: A written prediction that you can compare with the actual result.

2. Start a disposable PostgreSQL server
Use a fresh container name. The password is a public, disposable lab value; the server is not exposed to the host network. Wait for pg_isready to report accepting connections.
```
docker run --name atlas-course-pg -e POSTGRES_PASSWORD=local-lab-only -d postgres:16
docker exec atlas-course-pg pg_isready -U postgres
```
Expected: The final readiness check reports accepting connections.

3. Load and inspect the baseline
Copy the SQL files into the container. The beginner script creates two synthetic tickets and checks the count.
```
docker cp beginner.sql atlas-course-pg:/tmp/beginner.sql
docker cp intermediate.sql atlas-course-pg:/tmp/intermediate.sql
docker cp advanced.sql atlas-course-pg:/tmp/advanced.sql
docker exec atlas-course-pg psql -U postgres -f /tmp/beginner.sql
```
Expected: ticket_count = 2 and PASS postgres beginner.

4. Record recovery evidence
Create a table with keys and constraints
Expected: A run log with source/restored counts, constraint checks and a distinction between a logical dump and point-in-time recovery.

Troubleshooting:
Container name already exists: Reuse only your own earlier lab container, or choose a new name consistently. Do not remove an unfamiliar container.
Server is still starting: Run docker exec atlas-course-pg pg_isready -U postgres again after inspecting docker logs atlas-course-pg.
atlas_restore already exists: Choose a new restore database name and use it consistently; do not overwrite the previous evidence.
Restore has errors: Keep ON_ERROR_STOP enabled, inspect the first failing SQL statement, and restore into a new empty lab database.
Cleanup: After keeping the backup and evidence, run docker rm -f atlas-course-pg. This removes this disposable lab container and its database; keep your host backup file if needed.

Portfolio: dba-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Create a table with keys and constraints? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A key identifies a record. Constraints prevent invalid stored states, even when input comes from multiple programs. For this role, explicitly address: Create a table with keys and constraints.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Inspect a query plan and test transaction rollback

Setup: Install Docker using the official guide and verify docker info. Use the disposable container atlas-course-pg only; never use these reset commands on a real database. SQL files are included. No network port is exposed.

### Idempotent processing
Repeating the same operation should have the same intended effect as applying it once.
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This requires stable identity and a defined update policy; dropping all duplicates can hide corrections.
Example: Replaying the fixture leaves two accepted orders and a total of 30.
Recall: How would you distinguish a replay from a correction to order a?

### Apply idempotent processing in Database Administrator
Use the concept to complete this role exercise: Inspect a query plan and test transaction rollback
Mental model: Stamp a numbered ticket once, even if it is shown again.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Replaying the fixture leaves two accepted orders and a total of 30. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Start a disposable PostgreSQL server
Use a fresh container name. The password is a public, disposable lab value; the server is not exposed to the host network. Wait for pg_isready to report accepting connections.
```
docker run --name atlas-course-pg -e POSTGRES_PASSWORD=local-lab-only -d postgres:16
docker exec atlas-course-pg pg_isready -U postgres
```
Expected: The final readiness check reports accepting connections.

2. Load and inspect the baseline
Copy the SQL files into the container. The beginner script creates two synthetic tickets and checks the count.
```
docker cp beginner.sql atlas-course-pg:/tmp/beginner.sql
docker cp intermediate.sql atlas-course-pg:/tmp/intermediate.sql
docker cp advanced.sql atlas-course-pg:/tmp/advanced.sql
docker exec atlas-course-pg psql -U postgres -f /tmp/beginner.sql
```
Expected: ticket_count = 2 and PASS postgres beginner.

3. Prove rollback and inspect a plan
The script rolls back a change, creates an index and shows a query plan. With two rows a sequential scan can be the correct choice.
```
docker exec atlas-course-pg psql -U postgres -f /tmp/intermediate.sql
```
Expected: PASS postgres intermediate; ticket 1 remains open.

4. Record recovery evidence
Inspect a query plan and test transaction rollback
Expected: A run log with source/restored counts, constraint checks and a distinction between a logical dump and point-in-time recovery.

Troubleshooting:
Container name already exists: Reuse only your own earlier lab container, or choose a new name consistently. Do not remove an unfamiliar container.
Server is still starting: Run docker exec atlas-course-pg pg_isready -U postgres again after inspecting docker logs atlas-course-pg.
atlas_restore already exists: Choose a new restore database name and use it consistently; do not overwrite the previous evidence.
Restore has errors: Keep ON_ERROR_STOP enabled, inspect the first failing SQL statement, and restore into a new empty lab database.
Cleanup: After keeping the backup and evidence, run docker rm -f atlas-course-pg. This removes this disposable lab container and its database; keep your host backup file if needed.

Portfolio: dba-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Inspect a query plan and test transaction rollback? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Repeating the same operation should have the same intended effect as applying it once. For this role, explicitly address: Inspect a query plan and test transaction rollback.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Back up and restore into a different database; verify row counts and constraints

Setup: Install Docker using the official guide and verify docker info. Use the disposable container atlas-course-pg only; never use these reset commands on a real database. SQL files are included. No network port is exposed.

### Transaction and recovery
A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified.
Mental model: An envelope of changes: seal all of it or discard it.
Limit: Transactions do not replace backups; their scope depends on the database.
Example: Update an amount to 99, roll back, then verify the total is still 30.
Recall: Which checks would prove a restored database is usable?

### Apply transaction and recovery in Database Administrator
Use the concept to complete this role exercise: Back up and restore into a different database; verify row counts and constraints
Mental model: An envelope of changes: seal all of it or discard it.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: Update an amount to 99, roll back, then verify the total is still 30. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Start a disposable PostgreSQL server
Use a fresh container name. The password is a public, disposable lab value; the server is not exposed to the host network. Wait for pg_isready to report accepting connections.
```
docker run --name atlas-course-pg -e POSTGRES_PASSWORD=local-lab-only -d postgres:16
docker exec atlas-course-pg pg_isready -U postgres
```
Expected: The final readiness check reports accepting connections.

2. Load and inspect the baseline
Copy the SQL files into the container. The beginner script creates two synthetic tickets and checks the count.
```
docker cp beginner.sql atlas-course-pg:/tmp/beginner.sql
docker cp intermediate.sql atlas-course-pg:/tmp/intermediate.sql
docker cp advanced.sql atlas-course-pg:/tmp/advanced.sql
docker exec atlas-course-pg psql -U postgres -f /tmp/beginner.sql
```
Expected: ticket_count = 2 and PASS postgres beginner.

3. Prove rollback and inspect a plan
The script rolls back a change, creates an index and shows a query plan. With two rows a sequential scan can be the correct choice.
```
docker exec atlas-course-pg psql -U postgres -f /tmp/intermediate.sql
```
Expected: PASS postgres intermediate; ticket 1 remains open.

4. Restore into a separate database
Write the dump inside the container to avoid host-shell encoding differences. Restore into a new database, then verify the data. Preserve the source database for comparison.
```
docker exec atlas-course-pg pg_dump -U postgres -d postgres -n learning -f /tmp/learning.sql
docker cp atlas-course-pg:/tmp/learning.sql ./learning-backup.sql
docker exec atlas-course-pg createdb -U postgres atlas_restore
docker exec atlas-course-pg psql -U postgres -d atlas_restore -v ON_ERROR_STOP=1 -f /tmp/learning.sql
docker exec atlas-course-pg psql -U postgres -d atlas_restore -f /tmp/advanced.sql
```
Expected: PASS postgres advanced on the restored database.

5. Record recovery evidence
Back up and restore into a different database; verify row counts and constraints
Expected: A run log with source/restored counts, constraint checks and a distinction between a logical dump and point-in-time recovery.

Troubleshooting:
Container name already exists: Reuse only your own earlier lab container, or choose a new name consistently. Do not remove an unfamiliar container.
Server is still starting: Run docker exec atlas-course-pg pg_isready -U postgres again after inspecting docker logs atlas-course-pg.
atlas_restore already exists: Choose a new restore database name and use it consistently; do not overwrite the previous evidence.
Restore has errors: Keep ON_ERROR_STOP enabled, inspect the first failing SQL statement, and restore into a new empty lab database.
Cleanup: After keeping the backup and evidence, run docker rm -f atlas-course-pg. This removes this disposable lab container and its database; keep your host backup file if needed.

Portfolio: dba-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Back up and restore into a different database; verify row counts and constraints? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A transaction groups changes that commit together or roll back. A backup is useful only if restoration is verified. For this role, explicitly address: Back up and restore into a different database; verify row counts and constraints.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
PostgreSQL 16: SQL dumps and restore: https://www.postgresql.org/docs/16/backup-dump.html
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
PostgreSQL 16 tutorial: https://www.postgresql.org/docs/16/tutorial.html
