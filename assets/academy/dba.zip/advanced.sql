\set ON_ERROR_STOP on
DO $$ BEGIN IF (SELECT count(*) FROM learning.tickets) <> 2 THEN RAISE EXCEPTION 'Restore is missing rows'; END IF; IF EXISTS(SELECT 1 FROM learning.tickets WHERE status<>'open') THEN RAISE EXCEPTION 'Unexpected restored state'; END IF; END $$;
SELECT 'PASS postgres advanced' AS result;
