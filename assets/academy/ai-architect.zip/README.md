# AI solutions architect

AI Engineering · Beginner → Intermediate → Advanced

Start with Constraints before components. A system design connects user needs with technical and operational constraints. A mandatory requirement is different from a preference. Then try Separate needs from preferences. The three levels build toward Build-versus-buy AI architecture dossier. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Constraints before components

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Constraints before components
Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified.
Mental model: A bridge design starts with its load and span, not a favorite material.
Boundary: An architecture drawing is a proposal until boundaries are tested.
Worked example: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Capacity assumptions fail review
The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Two designs have insufficient tested headroom; a cost estimate used average traffic. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Recalculate with peak request shape and test capacity before choosing deployment size.
Recall: Measure latency and error rates at the proposed peak, then exercise the fallback route. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Constraints before components: Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A system design connects user needs with technical and operational constraints. A mandatory requirement is different from a preference.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional document assistant with these requests: only staff can access it; answers must cite approved documents; blue buttons would be nice; document deletion must remove search copies.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A requirement table and a small system diagram.

3. Try step 2
Put each request into a table with mandatory/preferred, reason and verification method.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A requirement table and a small system diagram.

4. Try step 3
Sketch the user, application, document store and model; mark where access checks happen.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A requirement table and a small system diagram.

5. Explain and check your result
Access, citations and deletion have concrete checks; visual preferences are not treated as security requirements. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A requirement table and a small system diagram. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Apply this toy-case rule manually: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two designs have insufficient tested headroom; a cost estimate used average traffic. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI solutions architect.
Use a fictional document assistant with these requests: only staff can access it; answers must cite approved documents; blue buttons would be nice; document deletion must remove search copies.
Put each request into a table with mandatory/preferred, reason and verification method.
Sketch the user, application, document store and model; mark where access checks happen.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A requirement table and a small system diagram. Include beginner-worksheet.md and your completed Architecture decision record and capacity worksheet.
Check: Access, citations and deletion have concrete checks; visual preferences are not treated as security requirements.

### Interview
Explain your beginner solution for AI solutions architect. Use this scenario: The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity.
Review: Start with the task and permitted scope. Explain constraints before components: Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified. Show the input and observed output, then address Recalculate with peak request shape and test capacity before choosing deployment size. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A requirement table and a small system diagram. Include beginner-worksheet.md and your completed Architecture decision record and capacity worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Architecture trade-offs

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Broad system design, identity/networking/data experience and customer communication; typically requires prior delivery experience.

### Architecture trade-offs
Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it.
Mental model: Choose a route using distance, tolls and reliability rather than color on the map.
Boundary: No option dominates for every organization or volume.
Worked example: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Build-versus-buy AI architecture dossier
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Recall: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. Identify one observation that would contradict your claim.

### Terms
Architecture trade-offs: Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it.
API: Application programming interface: the agreed way one program requests work or data from another.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints.
Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.
Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.
Deliverables: Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI solutions architect. Use this scenario: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Review: Start with the task and permitted scope. Explain architecture trade-offs: Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it. Show the input and observed output, then address Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Failure-aware system design

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Failure-aware system design
Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery.
Mental model: Watertight compartments prevent one leak from sinking the entire ship.
Boundary: A fallback may preserve availability while reducing usefulness; make that visible.
Worked example: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Build-versus-buy AI architecture dossier
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Score the options against weighted requirements, then write two ADRs: data residency/identity and model/retrieval hosting. Include an exit strategy and ownership for each critical dependency.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Recall: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. Identify one observation that would contradict your claim.

### Terms
Failure-aware system design: Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery.
API: Application programming interface: the agreed way one program requests work or data from another.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Score the options against weighted requirements, then write two ADRs: data residency/identity and model/retrieval hosting. Include an exit strategy and ownership for each critical dependency.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints.
Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.
Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Score the options against weighted requirements, then write two ADRs: data residency/identity and model/retrieval hosting. Include an exit strategy and ownership for each critical dependency.
Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.
Implement one bounded proof of concept using the adjacent engineering handbook and replace assumptions with measured results.
Deliverables: Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis; ADR pack and migration/exit runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A reviewer must reproduce one result and identify which capabilities you implemented. Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.

### Interview
Explain your advanced solution for AI solutions architect. Use this scenario: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Review: Start with the task and permitted scope. Explain failure-aware system design: Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery. Show the input and observed output, then address Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis; ADR pack and migration/exit runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
diagrams.net — Open source editor · browser/desktop
Architecture diagrams, process maps and trust boundaries.
Alternative: Mermaid (open source) for text diagrams or Microsoft Visio (commercial); choose an editable format teammates can use.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

NIST AI RMF — Public framework · not a certification
Organize governance questions and evidence; project recommendations are editorial.
Alternative: OECD AI Principles provide another public perspective; frameworks complement one another and are not automatic certifications.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
diagrams.net: https://www.drawio.com/docs/getting-started/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework
Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html
Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry
Google Cloud AI platform documentation: https://docs.cloud.google.com/gemini-enterprise-agent-platform/machine-learning
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
