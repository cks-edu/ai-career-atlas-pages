## beginner — Constraints before components

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Constraints before components
Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified.
Mental model: A bridge design starts with its load and span, not a favorite material.
Boundary: An architecture drawing is a proposal until boundaries are tested.
Worked example: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Capacity assumptions fail review
The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Two designs have insufficient tested headroom; a cost estimate used average traffic. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Recalculate with peak request shape and test capacity before choosing deployment size.
Recall: Measure latency and error rates at the proposed peak, then exercise the fallback route. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Constraints before components: Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A system design connects user needs with technical and operational constraints. A mandatory requirement is different from a preference.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional document assistant with these requests: only staff can access it; answers must cite approved documents; blue buttons would be nice; document deletion must remove search copies.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A requirement table and a small system diagram.

3. Try step 2
Put each request into a table with mandatory/preferred, reason and verification method.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A requirement table and a small system diagram.

4. Try step 3
Sketch the user, application, document store and model; mark where access checks happen.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A requirement table and a small system diagram.

5. Explain and check your result
Access, citations and deletion have concrete checks; visual preferences are not treated as security requirements. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A requirement table and a small system diagram. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Apply this toy-case rule manually: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two designs have insufficient tested headroom; a cost estimate used average traffic. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI solutions architect.
Use a fictional document assistant with these requests: only staff can access it; answers must cite approved documents; blue buttons would be nice; document deletion must remove search copies.
Put each request into a table with mandatory/preferred, reason and verification method.
Sketch the user, application, document store and model; mark where access checks happen.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A requirement table and a small system diagram. Include beginner-worksheet.md and your completed Architecture decision record and capacity worksheet.
Check: Access, citations and deletion have concrete checks; visual preferences are not treated as security requirements.

### Interview
Explain your beginner solution for AI solutions architect. Use this scenario: The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity.
Review: Start with the task and permitted scope. Explain constraints before components: Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified. Show the input and observed output, then address Recalculate with peak request shape and test capacity before choosing deployment size. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A requirement table and a small system diagram. Include beginner-worksheet.md and your completed Architecture decision record and capacity worksheet.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

