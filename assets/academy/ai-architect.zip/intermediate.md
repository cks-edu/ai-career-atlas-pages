## intermediate — Architecture trade-offs

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Broad system design, identity/networking/data experience and customer communication; typically requires prior delivery experience.

### Architecture trade-offs
Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it.
Mental model: Choose a route using distance, tolls and reliability rather than color on the map.
Boundary: No option dominates for every organization or volume.
Worked example: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Build-versus-buy AI architecture dossier
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Recall: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. Identify one observation that would contradict your claim.

### Terms
Architecture trade-offs: Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it.
API: Application programming interface: the agreed way one program requests work or data from another.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints.
Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.
Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.
Deliverables: Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI solutions architect. Use this scenario: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Review: Start with the task and permitted scope. Explain architecture trade-offs: Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it. Show the input and observed output, then address Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

