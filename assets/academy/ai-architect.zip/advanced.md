## advanced — Failure-aware system design

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Failure-aware system design
Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery.
Mental model: Watertight compartments prevent one leak from sinking the entire ship.
Boundary: A fallback may preserve availability while reducing usefulness; make that visible.
Worked example: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Build-versus-buy AI architecture dossier
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Score the options against weighted requirements, then write two ADRs: data residency/identity and model/retrieval hosting. Include an exit strategy and ownership for each critical dependency.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Recall: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. Identify one observation that would contradict your claim.

### Terms
Failure-aware system design: Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery.
API: Application programming interface: the agreed way one program requests work or data from another.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Score the options against weighted requirements, then write two ADRs: data residency/identity and model/retrieval hosting. Include an exit strategy and ownership for each critical dependency.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints.
Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.
Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.
Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.
Score the options against weighted requirements, then write two ADRs: data residency/identity and model/retrieval hosting. Include an exit strategy and ownership for each critical dependency.
Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.
Implement one bounded proof of concept using the adjacent engineering handbook and replace assumptions with measured results.
Deliverables: Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis; ADR pack and migration/exit runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A reviewer must reproduce one result and identify which capabilities you implemented. Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.

### Interview
Explain your advanced solution for AI solutions architect. Use this scenario: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.
Review: Start with the task and permitted scope. Explain failure-aware system design: Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery. Show the input and observed output, then address Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis; ADR pack and migration/exit runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

