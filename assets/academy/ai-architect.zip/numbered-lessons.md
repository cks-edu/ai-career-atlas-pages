# AI solutions architect — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Constraints before components: Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Constraints before components

Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified. In this role, work through: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A bridge design starts with its load and span, not a favorite material.

Boundary: An architecture drawing is a proposal until boundaries are tested.

Worked example: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI solutions architect: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval.

Predict the worked case

Read this case without running a tool: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in constraints before components.

Connect the concept to the role

Apply this rule: Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An architecture drawing is a proposal until boundaries are tested.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies constraints before components to this case: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Constraints before components; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with constraints before components. Use the glossary below, then write your prediction for: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions architect role interview. Explain constraints before components using this case: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate constraints before components to a system or workflow you know. Explain constraints before components using this case: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain constraints before components using this case: A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval.

Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified. — Begin with user outcomes, data sensitivity, latency, availability and budget constraints. Use those to decide whether retrieval, generation or a deterministic service is justified. An architecture drawing is a proposal until boundaries are tested.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

Google Cloud AI platform documentation: https://docs.cloud.google.com/gemini-enterprise-agent-platform/machine-learning

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Diagnose: Capacity assumptions fail review

The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Two designs have insufficient tested headroom; a cost estimate used average traffic. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Recalculate with peak request shape and test capacity before choosing deployment size. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A bridge design starts with its load and span, not a favorite material.

A public FAQ can use public sources; a payroll assistant needs identity and document-level authorization before retrieval.

Worked example: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Recalculate with peak request shape and test capacity before choosing deployment size.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Two designs have insufficient tested headroom; a cost estimate used average traffic. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Apply this toy-case rule manually: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A system design connects user needs with technical and operational constraints. A mandatory requirement is different from a preference.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use a fictional document assistant with these requests: only staff can access it; answers must cite approved documents; blue buttons would be nice; document deletion must remove search copies.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A requirement table and a small system diagram.

Preparation · Try step 2

Put each request into a table with mandatory/preferred, reason and verification method.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A requirement table and a small system diagram.

Preparation · Try step 3

Sketch the user, application, document store and model; mark where access checks happen.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A requirement table and a small system diagram.

Preparation · Explain and check your result

Access, citations and deletion have concrete checks; visual preferences are not treated as security requirements. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A requirement table and a small system diagram. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Apply this toy-case rule manually: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two designs have insufficient tested headroom; a cost estimate used average traffic. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two designs have insufficient tested headroom; a cost estimate used average traffic. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: capacity assumptions fail review. Use the glossary below, then write your prediction for: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Recalculate with peak request shape and test capacity before choosing deployment size. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions architect role interview. Explain diagnose: capacity assumptions fail review using this case: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Recalculate with peak request shape and test capacity before choosing deployment size. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: capacity assumptions fail review to a system or workflow you know. Explain diagnose: capacity assumptions fail review using this case: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Recalculate with peak request shape and test capacity before choosing deployment size. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Measure latency and error rates at the proposed peak, then exercise the fallback route. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: capacity assumptions fail review using this case: Review when capacity_percent > 80 (percent). This is a declared toy-case contract, not an industry standard. Recalculate with peak request shape and test capacity before choosing deployment size. State the evidence, one alternative and where the mental model stops.

Quiz: Capacity assumptions fail review: The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity.

Change the acceptance rule after seeing an inconvenient result.

Recalculate with peak request shape and test capacity before choosing deployment size.

Omit failed cases and report only the successful demonstrations.

Reference: Recalculate with peak request shape and test capacity before choosing deployment size. — Recalculate with peak request shape and test capacity before choosing deployment size. Measure latency and error rates at the proposed peak, then exercise the fallback route.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

Google Cloud AI platform documentation: https://docs.cloud.google.com/gemini-enterprise-agent-platform/machine-learning

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Broad system design, identity/networking/data experience and customer communication; typically requires prior delivery experience.

Terms:

Architecture trade-offs: Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it.

API: Application programming interface: the agreed way one program requests work or data from another.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Architecture trade-offs

Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it. In this role, work through: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Choose a route using distance, tolls and reliability rather than color on the map.

Boundary: No option dominates for every organization or volume.

Worked example: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Broad system design, identity/networking/data experience and customer communication; typically requires prior delivery experience.

Tools for this exercise: Document or text editor

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI solutions architect: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency.

Predict the worked case

Read this case without running a tool: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in architecture trade-offs.

Connect the concept to the role

Apply this rule: Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: No option dominates for every organization or volume.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies architecture trade-offs to this case: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Architecture trade-offs; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with architecture trade-offs. Use the glossary below, then write your prediction for: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions architect role interview. Explain architecture trade-offs using this case: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate architecture trade-offs to a system or workflow you know. Explain architecture trade-offs using this case: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain architecture trade-offs using this case: Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency.

Treat a passing starter as proof of the whole role workflow.

Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it.

Ignore the failure because the tool produced an output.

Reference: Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it. — Compare feasible designs using explicit criteria and assumptions. Record why an option was selected and the evidence that would make you reconsider it. No option dominates for every organization or volume.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

Google Cloud AI platform documentation: https://docs.cloud.google.com/gemini-enterprise-agent-platform/machine-learning

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Integrate: Build-versus-buy AI architecture dossier

Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices. In this role, work through: Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: Choose a route using distance, tolls and reliability rather than color on the map.

Compare local serving with a hosted API using memory needs, data handling, operating effort and measured workload latency.

Worked example: Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: build-versus-buy ai architecture dossier. Use the glossary below, then write your prediction for: Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions architect role interview. Explain integrate: build-versus-buy ai architecture dossier using this case: Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: build-versus-buy ai architecture dossier to a system or workflow you know. Explain integrate: build-versus-buy ai architecture dossier using this case: Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. Identify one observation that would contradict your claim.

Interview: Explain integrate: build-versus-buy ai architecture dossier using this case: Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Build-versus-buy AI architecture dossier at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.

Reference: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. — Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

Google Cloud AI platform documentation: https://docs.cloud.google.com/gemini-enterprise-agent-platform/machine-learning

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Failure-aware system design: Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery.

API: Application programming interface: the agreed way one program requests work or data from another.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Failure-aware system design

Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery. In this role, work through: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Watertight compartments prevent one leak from sinking the entire ship.

Boundary: A fallback may preserve availability while reducing usefulness; make that visible.

Worked example: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI solutions architect: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory.

Predict the worked case

Read this case without running a tool: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in failure-aware system design.

Connect the concept to the role

Apply this rule: Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A fallback may preserve availability while reducing usefulness; make that visible.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies failure-aware system design to this case: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Failure-aware system design; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure-aware system design. Use the glossary below, then write your prediction for: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions architect role interview. Explain failure-aware system design using this case: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure-aware system design to a system or workflow you know. Explain failure-aware system design using this case: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain failure-aware system design using this case: If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery.

Reference: Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery. — Map failures across dependencies and identify safe degraded behavior. Include data/version compatibility when defining rollback and recovery. A fallback may preserve availability while reducing usefulness; make that visible.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

Google Cloud AI platform documentation: https://docs.cloud.google.com/gemini-enterprise-agent-platform/machine-learning

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Defend: Build-versus-buy AI architecture dossier

Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Score the options against weighted requirements, then write two ADRs: data residency/identity and model/retrieval hosting. Include an exit strategy and ownership for each critical dependency. In this role, work through: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: Watertight compartments prevent one leak from sinking the entire ship.

If vector search fails, show unavailable evidence and a support route; do not ask the model to invent an answer from memory.

Worked example: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: diagrams.net (Open source editor · browser/desktop); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Create a requirements register for 500 daily requests, two languages and a private policy corpus. Mark these as planning assumptions; define stakeholder priorities and prohibited data flows.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Draw three candidate architectures in diagrams.net: hosted model API, managed cloud retrieval and self-hosted inference. Mark trust boundaries, storage, identity and failure dependencies.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Use a Calc workbook with request volume, token assumptions, retry factor, storage, support effort and current vendor unit prices. Cite dated price pages; model low/base/high scenarios without presenting estimates as invoices.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Score the options against weighted requirements, then write two ADRs: data residency/identity and model/retrieval hosting. Include an exit strategy and ownership for each critical dependency.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. A reviewer must reproduce one result and identify which capabilities you implemented. Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Architecture diagrams and threat boundaries; Cost workbook with sources and sensitivity analysis; ADR pack and migration/exit runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: build-versus-buy ai architecture dossier. Use the glossary below, then write your prediction for: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI solutions architect role interview. Explain defend: build-versus-buy ai architecture dossier using this case: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: build-versus-buy ai architecture dossier to a system or workflow you know. Explain defend: build-versus-buy ai architecture dossier using this case: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence. Identify one observation that would contradict your claim.

Interview: Explain defend: build-versus-buy ai architecture dossier using this case: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Build-versus-buy AI architecture dossier at this level?

Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model. — Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model. Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.

Sources:

diagrams.net: https://www.drawio.com/docs/getting-started/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

Amazon Bedrock: https://docs.aws.amazon.com/bedrock/latest/userguide/what-is-bedrock.html

Microsoft Foundry: https://learn.microsoft.com/en-us/azure/foundry/what-is-foundry

Google Cloud AI platform documentation: https://docs.cloud.google.com/gemini-enterprise-agent-platform/machine-learning

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
