# SAMPLE — Architecture decision record and capacity worksheet
Role: AI solutions architect
Case: Capacity assumptions fail review
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The architecture brief requires projected peak traffic to remain at or below 80% of tested sustainable capacity.

## Evidence table
| Record | capacity_percent (percent) | Decision |
|---|---:|---|
| case-1 | 40 | within_demo_bound |
| case-2 | 80 | within_demo_bound |
| case-3 | 92 | review |
| case-4 | 115 | review |
| case-5 | 65 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two designs have insufficient tested headroom; a cost estimate used average traffic.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Recalculate with peak request shape and test capacity before choosing deployment size.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai solutions architect.
Before release: Measure latency and error rates at the proposed peak, then exercise the fallback route.

## Design choice and trade-off
Make traffic, quality, identity and recovery assumptions explicit; validate the riskiest dependency first.
Reserved headroom costs money but reduces overload risk; capacity must be measured for the intended workload.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Enterprise AI decision pack: Decisions link to requirements and measured evidence.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
