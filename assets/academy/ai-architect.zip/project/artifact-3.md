# ADR pack and migration/exit runbook

Project: Build-versus-buy AI architecture dossier
Status: blank work product — not completed evidence

## Purpose and audience
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints.

## Required content
Score the options against weighted requirements, then write two ADRs: data residency/identity and model/retrieval hosting. Include an exit strategy and ownership for each critical dependency.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.

## Failure evidence
Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
