# Build-versus-buy AI architecture dossier

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Produce a defensible architecture decision for a fictional multilingual support assistant under explicit latency, privacy and budget constraints.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Have a peer trace each requirement to a component, test and owner. Check arithmetic, sensitivity to assumptions and unresolved constraints; a diagram is not deployment evidence.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Change the scenario to a provider outage plus a tenfold traffic burst. Walk through degradation, queue limits, data exposure risk and the revised cost model.

## Limitations and next iteration
Implement one bounded proof of concept using the adjacent engineering handbook and replace assumptions with measured results.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
