# SAMPLE — Model evaluation and threshold decision report
Role: Machine learning engineer
Case: The classifier fails high-cost cases
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives.

## Evidence table
| Record | false_negatives (out of ten positives) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | within_demo_bound |
| case-3 | 2 | review |
| case-4 | 4 | review |
| case-5 | 0 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two batches exceed the stated missed-positive tolerance; accuracy alone hid the failure cost.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Review threshold and features on validation data, then evaluate once on untouched test cases.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in machine learning engineer.
Before release: Compare recall, false positives and calibration by meaningful slice.

## Design choice and trade-off
Define the cost of errors before selecting metrics; separate training, validation and test decisions.
Raising recall can increase false positives and review workload; make the operational cost visible.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Churn prediction service: Compare calibration and recall against a simple baseline.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
