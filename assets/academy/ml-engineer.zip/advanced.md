## advanced — Deployment and outcome monitoring

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Deployment and outcome monitoring
Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed.
Mental model: A weather station must keep its sensor settings with each forecast.
Boundary: Labels may arrive late or selectively, making apparent performance incomplete.
Worked example: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Monitored classification service
Build a reproducible classifier with a documented abstention and retraining policy. Expose predictions through FastAPI with strict feature names and ranges. Record feature summaries and prediction distributions without logging sensitive raw records.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Recall: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. Identify one observation that would contradict your claim.

### Terms
Deployment and outcome monitoring: Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a reproducible classifier with a documented abstention and retraining policy. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Expose predictions through FastAPI with strict feature names and ranges. Record feature summaries and prediction distributions without logging sensitive raw records.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build a reproducible classifier with a documented abstention and retraining policy.
Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Expose predictions through FastAPI with strict feature names and ranges. Record feature summaries and prediction distributions without logging sensitive raw records.
Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.
Add delayed ground-truth feedback and a reviewed retraining gate.
Deliverables: Training and serving code; Model/data cards and calibration plots; Drift investigation and retraining runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A reviewer must reproduce one result and identify which capabilities you implemented. Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.

### Interview
Explain your advanced solution for Machine learning engineer. Use this scenario: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Review: Start with the task and permitted scope. Explain deployment and outcome monitoring: Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed. Show the input and observed output, then address Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Training and serving code; Model/data cards and calibration plots; Drift investigation and retraining runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

