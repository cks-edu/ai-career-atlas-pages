# Machine learning engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Generalization and holdouts. A baseline is a simple method used for comparison. Evaluate it on examples it did not use to learn. Then try Calculate a simple prediction baseline. The three levels build toward Monitored classification service. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Generalization and holdouts

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Generalization and holdouts
Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors.
Mental model: Practice on one set of questions and test understanding with unseen questions.
Boundary: A random split may be misleading for time-dependent or linked records.
Worked example: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The classifier fails high-cost cases
A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Two batches exceed the stated missed-positive tolerance; accuracy alone hid the failure cost. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Review threshold and features on validation data, then evaluate once on untouched test cases.
Recall: Compare recall, false positives and calibration by meaningful slice. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Generalization and holdouts: Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
recall: Of actually positive items, the fraction the method finds under the chosen labels.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A baseline is a simple method used for comparison. Evaluate it on examples it did not use to learn.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use training values 2, 4 and 6. Calculate their mean (add the values, then divide by their count) and use it as a constant prediction.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worked baseline calculation with separate training and test rows.

3. Try step 2
Test that prediction against new values 3 and 7. For each, calculate absolute error: the distance between prediction and actual value, ignoring the sign. Average the two errors.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worked baseline calculation with separate training and test rows.

4. Try step 3
Explain why choosing the constant after looking at the test values would weaken the evaluation.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worked baseline calculation with separate training and test rows.

5. Explain and check your result
The prediction is 4, errors are 1 and 3, and mean absolute error is 2; test values did not choose the prediction. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A worked baseline calculation with separate training and test rows. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Apply this toy-case rule manually: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two batches exceed the stated missed-positive tolerance; accuracy alone hid the failure cost. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Machine learning engineer.
Use training values 2, 4 and 6. Calculate their mean (add the values, then divide by their count) and use it as a constant prediction.
Test that prediction against new values 3 and 7. For each, calculate absolute error: the distance between prediction and actual value, ignoring the sign. Average the two errors.
Explain why choosing the constant after looking at the test values would weaken the evaluation.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A worked baseline calculation with separate training and test rows. Include beginner-worksheet.md and your completed Model evaluation and threshold decision report.
Check: The prediction is 4, errors are 1 and 3, and mean absolute error is 2; test values did not choose the prediction.

### Interview
Explain your beginner solution for Machine learning engineer. Use this scenario: A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives.
Review: Start with the task and permitted scope. Explain generalization and holdouts: Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors. Show the input and observed output, then address Review threshold and features on validation data, then evaluate once on untouched test cases. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A worked baseline calculation with separate training and test rows. Include beginner-worksheet.md and your completed Model evaluation and threshold decision report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Fitted preprocessing pipelines

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, SQL, statistics, linear algebra and software testing; bridge gaps with small supervised-learning tasks.

### Fitted preprocessing pipelines
Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model.
Mental model: Prepare a measuring instrument once, then use the same calibration for comparisons.
Boundary: Pipelines prevent some leakage, not errors in how the dataset was collected or split.
Worked example: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Monitored classification service
Build a reproducible classifier with a documented abstention and retraining policy. Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Recall: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. Identify one observation that would contradict your claim.

### Terms
Fitted preprocessing pipelines: Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a reproducible classifier with a documented abstention and retraining policy. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build a reproducible classifier with a documented abstention and retraining policy.
Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.
Deliverables: Training and serving code; Model/data cards and calibration plots. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Machine learning engineer. Use this scenario: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Review: Start with the task and permitted scope. Explain fitted preprocessing pipelines: Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model. Show the input and observed output, then address Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Training and serving code; Model/data cards and calibration plots. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Deployment and outcome monitoring

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Deployment and outcome monitoring
Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed.
Mental model: A weather station must keep its sensor settings with each forecast.
Boundary: Labels may arrive late or selectively, making apparent performance incomplete.
Worked example: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Monitored classification service
Build a reproducible classifier with a documented abstention and retraining policy. Expose predictions through FastAPI with strict feature names and ranges. Record feature summaries and prediction distributions without logging sensitive raw records.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Recall: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. Identify one observation that would contradict your claim.

### Terms
Deployment and outcome monitoring: Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a reproducible classifier with a documented abstention and retraining policy. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Expose predictions through FastAPI with strict feature names and ranges. Record feature summaries and prediction distributions without logging sensitive raw records.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build a reproducible classifier with a documented abstention and retraining policy.
Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Expose predictions through FastAPI with strict feature names and ranges. Record feature summaries and prediction distributions without logging sensitive raw records.
Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.
Add delayed ground-truth feedback and a reviewed retraining gate.
Deliverables: Training and serving code; Model/data cards and calibration plots; Drift investigation and retraining runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A reviewer must reproduce one result and identify which capabilities you implemented. Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.

### Interview
Explain your advanced solution for Machine learning engineer. Use this scenario: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Review: Start with the task and permitted scope. Explain deployment and outcome monitoring: Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed. Show the input and observed output, then address Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Training and serving code; Model/data cards and calibration plots; Drift investigation and retraining runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

FastAPI — Open source · local
Typed API, validation and local service tests.
Alternative: Django REST Framework (open source); compare validation, async support and existing team skills.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
FastAPI: https://fastapi.tiangolo.com/tutorial/
Google ML Crash Course: https://developers.google.com/machine-learning/crash-course
scikit-learn: https://scikit-learn.org/stable/user_guide.html
MLflow: https://mlflow.org/docs/latest/
