## intermediate — Fitted preprocessing pipelines

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, SQL, statistics, linear algebra and software testing; bridge gaps with small supervised-learning tasks.

### Fitted preprocessing pipelines
Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model.
Mental model: Prepare a measuring instrument once, then use the same calibration for comparisons.
Boundary: Pipelines prevent some leakage, not errors in how the dataset was collected or split.
Worked example: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Monitored classification service
Build a reproducible classifier with a documented abstention and retraining policy. Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.
Worked example: Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Recall: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. Identify one observation that would contradict your claim.

### Terms
Fitted preprocessing pipelines: Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
recall: Of actually positive items, the fraction the method finds under the chosen labels.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Lab
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a reproducible classifier with a documented abstention and retraining policy. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

2. Prepare the project inputs
Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Poor metrics: inspect class balance and split construction before tuning.
Too-good metrics: check duplicate groups and target-derived features.
Changed results: compare package versions, seeds and preprocessing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

### Portfolio
Build a reproducible classifier with a documented abstention and retraining policy.
Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.
Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.
Deliverables: Training and serving code; Model/data cards and calibration plots. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Machine learning engineer. Use this scenario: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.
Review: Start with the task and permitted scope. Explain fitted preprocessing pipelines: Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model. Show the input and observed output, then address Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Training and serving code; Model/data cards and calibration plots. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

