"""Actual CPU training baseline on sklearn's bundled wine dataset; not domain proof."""
import json
from pathlib import Path
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix

def run():
    x,y=load_wine(return_X_y=True)
    x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=.25,stratify=y,random_state=42)
    results={}
    for name,model in [('dummy',DummyClassifier(strategy='most_frequent')),('logistic',make_pipeline(StandardScaler(),LogisticRegression(max_iter=1000,random_state=42)))]:
        model.fit(x_train,y_train);pred=model.predict(x_test)
        results[name]={'accuracy':float(accuracy_score(y_test,pred)),'macro_f1':float(f1_score(y_test,pred,average='macro')),'confusion_matrix':confusion_matrix(y_test,pred).tolist()}
    return {'dataset':'sklearn wine','seed':42,'train_rows':len(y_train),'test_rows':len(y_test),'results':results}
if __name__=='__main__':
    result=run();Path('output').mkdir(exist_ok=True)
    Path('output/metrics.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
