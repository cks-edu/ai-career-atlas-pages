# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Training and serving code.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
