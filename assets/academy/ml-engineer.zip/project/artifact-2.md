# Model/data cards and calibration plots

Project: Monitored classification service
Status: blank work product — not completed evidence

## Purpose and audience
Build a reproducible classifier with a documented abstention and retraining policy.

## Required content
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.

## Failure evidence
Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
