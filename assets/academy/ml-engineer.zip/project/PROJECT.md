# Monitored classification service

Career: Machine learning engineer
Reviewed: 2026-10-22

Build a reproducible classifier with a documented abstention and retraining policy.

## Prerequisites
Python, SQL, statistics, linear algebra and software testing; bridge gaps with small supervised-learning tasks.

## Included starter versus your implementation
A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Expose predictions through FastAPI with strict feature names and ranges. Record feature summaries and prediction distributions without logging sensitive raw records.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Training and serving code — artifact-1.md
2. Model/data cards and calibration plots — artifact-2.md
3. Drift investigation and retraining runbook — artifact-3.md

## Troubleshooting
- Poor metrics: inspect class balance and split construction before tuning.
- Too-good metrics: check duplicate groups and target-derived features.
- Changed results: compare package versions, seeds and preprocessing.

## Extension
Add delayed ground-truth feedback and a reviewed retraining gate.

## Primary learning resources
- scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html — Open source · CPU; Pipelines, baselines, data splits and statistical evaluation.
- MLflow: https://mlflow.org/docs/latest/ml/tracking/quickstart/ — Open source · hosted offerings optional; Record experiments, parameters and evaluation artifacts.
- FastAPI: https://fastapi.tiangolo.com/tutorial/ — Open source · local; Typed API, validation and local service tests.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
