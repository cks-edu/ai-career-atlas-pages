import unittest
from train import run
class TrainingTests(unittest.TestCase):
    def test_baseline(self):
        result=run();self.assertEqual(result['train_rows']+result['test_rows'],178)
        self.assertGreater(result['results']['logistic']['macro_f1'],result['results']['dummy']['macro_f1'])
        self.assertEqual(sum(map(sum,result['results']['logistic']['confusion_matrix'])),result['test_rows'])
if __name__=='__main__': unittest.main()
