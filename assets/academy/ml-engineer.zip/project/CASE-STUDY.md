# Monitored classification service

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build a reproducible classifier with a documented abstention and retraining policy.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.

## Limitations and next iteration
Add delayed ground-truth feedback and a reviewed retraining gate.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
