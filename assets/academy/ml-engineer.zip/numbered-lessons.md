# Machine learning engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Generalization and holdouts: Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

### Generalization and holdouts

Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors. In this role, work through: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Practice on one set of questions and test understanding with unseen questions.

Boundary: A random split may be misleading for time-dependent or linked records.

Worked example: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); FastAPI (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Machine learning engineer: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix.

Predict the worked case

Read this case without running a tool: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in generalization and holdouts.

Connect the concept to the role

Apply this rule: Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A random split may be misleading for time-dependent or linked records.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies generalization and holdouts to this case: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Generalization and holdouts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with generalization and holdouts. Use the glossary below, then write your prediction for: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Machine learning engineer role interview. Explain generalization and holdouts using this case: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate generalization and holdouts to a system or workflow you know. Explain generalization and holdouts using this case: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain generalization and holdouts using this case: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix.

Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors. — Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors. A random split may be misleading for time-dependent or linked records.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FastAPI: https://fastapi.tiangolo.com/tutorial/

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

MLflow: https://mlflow.org/docs/latest/

### Diagnose: The classifier fails high-cost cases

A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Two batches exceed the stated missed-positive tolerance; accuracy alone hid the failure cost. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Review threshold and features on validation data, then evaluate once on untouched test cases. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Practice on one set of questions and test understanding with unseen questions.

Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix.

Worked example: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Review threshold and features on validation data, then evaluate once on untouched test cases.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); FastAPI (Open source · local)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Two batches exceed the stated missed-positive tolerance; accuracy alone hid the failure cost. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Apply this toy-case rule manually: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A baseline is a simple method used for comparison. Evaluate it on examples it did not use to learn.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use training values 2, 4 and 6. Calculate their mean (add the values, then divide by their count) and use it as a constant prediction.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A worked baseline calculation with separate training and test rows.

Preparation · Try step 2

Test that prediction against new values 3 and 7. For each, calculate absolute error: the distance between prediction and actual value, ignoring the sign. Average the two errors.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A worked baseline calculation with separate training and test rows.

Preparation · Try step 3

Explain why choosing the constant after looking at the test values would weaken the evaluation.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A worked baseline calculation with separate training and test rows.

Preparation · Explain and check your result

The prediction is 4, errors are 1 and 3, and mean absolute error is 2; test values did not choose the prediction. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A worked baseline calculation with separate training and test rows. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Apply this toy-case rule manually: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two batches exceed the stated missed-positive tolerance; accuracy alone hid the failure cost. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two batches exceed the stated missed-positive tolerance; accuracy alone hid the failure cost. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the classifier fails high-cost cases. Use the glossary below, then write your prediction for: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Review threshold and features on validation data, then evaluate once on untouched test cases. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Machine learning engineer role interview. Explain diagnose: the classifier fails high-cost cases using this case: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Review threshold and features on validation data, then evaluate once on untouched test cases. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the classifier fails high-cost cases to a system or workflow you know. Explain diagnose: the classifier fails high-cost cases using this case: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Review threshold and features on validation data, then evaluate once on untouched test cases. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Compare recall, false positives and calibration by meaningful slice. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the classifier fails high-cost cases using this case: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Review threshold and features on validation data, then evaluate once on untouched test cases. State the evidence, one alternative and where the mental model stops.

Quiz: The classifier fails high-cost cases: A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives.

Change the acceptance rule after seeing an inconvenient result.

Review threshold and features on validation data, then evaluate once on untouched test cases.

Omit failed cases and report only the successful demonstrations.

Reference: Review threshold and features on validation data, then evaluate once on untouched test cases. — Review threshold and features on validation data, then evaluate once on untouched test cases. Compare recall, false positives and calibration by meaningful slice.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FastAPI: https://fastapi.tiangolo.com/tutorial/

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

MLflow: https://mlflow.org/docs/latest/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, SQL, statistics, linear algebra and software testing; bridge gaps with small supervised-learning tasks.

Terms:

Fitted preprocessing pipelines: Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Fitted preprocessing pipelines

Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model. In this role, work through: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Prepare a measuring instrument once, then use the same calibration for comparisons.

Boundary: Pipelines prevent some leakage, not errors in how the dataset was collected or split.

Worked example: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, SQL, statistics, linear algebra and software testing; bridge gaps with small supervised-learning tasks.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); FastAPI (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Machine learning engineer: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs.

Predict the worked case

Read this case without running a tool: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in fitted preprocessing pipelines.

Connect the concept to the role

Apply this rule: Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Pipelines prevent some leakage, not errors in how the dataset was collected or split.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies fitted preprocessing pipelines to this case: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Fitted preprocessing pipelines; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with fitted preprocessing pipelines. Use the glossary below, then write your prediction for: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Machine learning engineer role interview. Explain fitted preprocessing pipelines using this case: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate fitted preprocessing pipelines to a system or workflow you know. Explain fitted preprocessing pipelines using this case: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain fitted preprocessing pipelines using this case: Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs.

Treat a passing starter as proof of the whole role workflow.

Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model.

Ignore the failure because the tool produced an output.

Reference: Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model. — Fit transformations only on training data and reuse them unchanged for validation and inference. Bundle compatible transforms with the model. Pipelines prevent some leakage, not errors in how the dataset was collected or split.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FastAPI: https://fastapi.tiangolo.com/tutorial/

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

MLflow: https://mlflow.org/docs/latest/

### Integrate: Monitored classification service

Build a reproducible classifier with a documented abstention and retraining policy. Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set. In this role, work through: Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: Prepare a measuring instrument once, then use the same calibration for comparisons.

Fit a scaler on training rows, then transform held-out rows with its stored parameters; do not refit on test inputs.

Worked example: Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); FastAPI (Open source · local)

Build a reproducible classifier with a documented abstention and retraining policy. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Build a reproducible classifier with a documented abstention and retraining policy.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-intermediate-2.md: Training and serving code; Model/data cards and calibration plots. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: monitored classification service. Use the glossary below, then write your prediction for: Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Machine learning engineer role interview. Explain integrate: monitored classification service using this case: Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: monitored classification service to a system or workflow you know. Explain integrate: monitored classification service using this case: Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. Identify one observation that would contradict your claim.

Interview: Explain integrate: monitored classification service using this case: Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Monitored classification service at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.

Reference: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. — Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FastAPI: https://fastapi.tiangolo.com/tutorial/

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

MLflow: https://mlflow.org/docs/latest/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Deployment and outcome monitoring: Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

holdout: Examples kept separate from training and tuning so they can provide a less biased evaluation.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

recall: Of actually positive items, the fraction the method finds under the chosen labels.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Deployment and outcome monitoring

Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed. In this role, work through: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A weather station must keep its sensor settings with each forecast.

Boundary: Labels may arrive late or selectively, making apparent performance incomplete.

Worked example: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); FastAPI (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Machine learning engineer: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed.

Predict the worked case

Read this case without running a tool: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in deployment and outcome monitoring.

Connect the concept to the role

Apply this rule: Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Labels may arrive late or selectively, making apparent performance incomplete.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies deployment and outcome monitoring to this case: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Deployment and outcome monitoring; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with deployment and outcome monitoring. Use the glossary below, then write your prediction for: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Machine learning engineer role interview. Explain deployment and outcome monitoring using this case: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate deployment and outcome monitoring to a system or workflow you know. Explain deployment and outcome monitoring using this case: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain deployment and outcome monitoring using this case: A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed.

Reference: Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed. — Define an inference contract and monitor inputs, predictions and eventual outcomes. Preserve model and feature versions so a regression can be diagnosed. Labels may arrive late or selectively, making apparent performance incomplete.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FastAPI: https://fastapi.tiangolo.com/tutorial/

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

MLflow: https://mlflow.org/docs/latest/

### Defend: Monitored classification service

Build a reproducible classifier with a documented abstention and retraining policy. Expose predictions through FastAPI with strict feature names and ranges. Record feature summaries and prediction distributions without logging sensitive raw records. In this role, work through: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Role application: A weather station must keep its sensor settings with each forecast.

A new feature pipeline changes missing-value handling. Compare predictions and actual labels before deciding whether the model or data process regressed.

Worked example: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.

Setup: Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional); FastAPI (Open source · local)

Build a reproducible classifier with a documented abstention and retraining policy. A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain. Laptop CPU only for the baseline. External datasets, MLflow and serving extensions are separate; check dataset rights before publication.

Build a reproducible classifier with a documented abstention and retraining policy.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and the bundled wine dataset. This trains an actual CPU baseline; domain-specific data selection and validation remain your work. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python train.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A scikit-learn preprocessing pipeline, dummy/logistic baselines, fixed holdout and metric output. This is a mechanism baseline, not a model for the project domain.

Prepare the project inputs

Start from the bundled dataset, then choose a licensed classification dataset. Record target definition, data limitations and the unit of independence before splitting.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run train.py, retain its untouched test split and compare LogisticRegression with DummyClassifier. Put all learned preprocessing inside a Pipeline.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Add probability calibration using training-only folds. Choose an abstention threshold on validation data, then evaluate it once on the held-out set.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Expose predictions through FastAPI with strict feature names and ranges. Record feature summaries and prediction distributions without logging sensitive raw records.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. A reviewer must reproduce one result and identify which capabilities you implemented. Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/metrics.json and the dependency lock as evidence; deactivate the environment. Do not load untrusted serialized models.

Deliverable: lesson-advanced-2.md: Training and serving code; Model/data cards and calibration plots; Drift investigation and retraining runbook. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: monitored classification service. Use the glossary below, then write your prediction for: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Machine learning engineer role interview. Explain defend: monitored classification service using this case: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: monitored classification service to a system or workflow you know. Explain defend: monitored classification service using this case: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss. Identify one observation that would contradict your claim.

Interview: Explain defend: monitored classification service using this case: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Monitored classification service at this level?

Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution. — Reorder input columns and inject missing values. Reject schema mismatches and compare behavior under a shifted input distribution. Report per-class precision/recall, calibration, coverage versus error and latency. Distribution drift is a diagnostic signal, not automatic proof of performance loss.

Sources:

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

FastAPI: https://fastapi.tiangolo.com/tutorial/

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

MLflow: https://mlflow.org/docs/latest/
