## beginner — Generalization and holdouts

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Generalization and holdouts
Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors.
Mental model: Practice on one set of questions and test understanding with unseen questions.
Boundary: A random split may be misleading for time-dependent or linked records.
Worked example: Compare a majority-class predictor and a learned model on the same untouched split; report class counts and confusion matrix.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The classifier fails high-cost cases
A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Two batches exceed the stated missed-positive tolerance; accuracy alone hid the failure cost. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Review threshold and features on validation data, then evaluate once on untouched test cases.
Recall: Compare recall, false positives and calibration by meaningful slice. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Generalization and holdouts: Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
recall: Of actually positive items, the fraction the method finds under the chosen labels.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A baseline is a simple method used for comparison. Evaluate it on examples it did not use to learn.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use training values 2, 4 and 6. Calculate their mean (add the values, then divide by their count) and use it as a constant prediction.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worked baseline calculation with separate training and test rows.

3. Try step 2
Test that prediction against new values 3 and 7. For each, calculate absolute error: the distance between prediction and actual value, ignoring the sign. Average the two errors.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worked baseline calculation with separate training and test rows.

4. Try step 3
Explain why choosing the constant after looking at the test values would weaken the evaluation.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A worked baseline calculation with separate training and test rows.

5. Explain and check your result
The prediction is 4, errors are 1 and 3, and mean absolute error is 2; test values did not choose the prediction. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A worked baseline calculation with separate training and test rows. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives. Apply this toy-case rule manually: Review when false_negatives >= 2 (out of ten positives). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two batches exceed the stated missed-positive tolerance; accuracy alone hid the failure cost. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Machine learning engineer.
Use training values 2, 4 and 6. Calculate their mean (add the values, then divide by their count) and use it as a constant prediction.
Test that prediction against new values 3 and 7. For each, calculate absolute error: the distance between prediction and actual value, ignoring the sign. Average the two errors.
Explain why choosing the constant after looking at the test values would weaken the evaluation.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A worked baseline calculation with separate training and test rows. Include beginner-worksheet.md and your completed Model evaluation and threshold decision report.
Check: The prediction is 4, errors are 1 and 3, and mean absolute error is 2; test values did not choose the prediction.

### Interview
Explain your beginner solution for Machine learning engineer. Use this scenario: A toy risk-screening pilot escalates any batch with more than one missed positive in ten labeled positives.
Review: Start with the task and permitted scope. Explain generalization and holdouts: Fit a model on training examples and assess it on separate examples that reflect its intended use. Start with a simple baseline and inspect errors. Show the input and observed output, then address Review threshold and features on validation data, then evaluate once on untouched test cases. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A worked baseline calculation with separate training and test rows. Include beginner-worksheet.md and your completed Model evaluation and threshold decision report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

