# AI product manager

AI Engineering · Beginner → Intermediate → Advanced

Start with Problem and non-AI baseline. A product starts with a user problem, not a model choice. Compare manual work, fixed rules and AI assistance before deciding what to build. Then try Compare ways to answer library questions. The three levels build toward Evidence-led AI product launch case. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Problem and non-AI baseline

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Problem and non-AI baseline
Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable.
Mental model: Choose a destination before selecting the vehicle.
Boundary: A convenient demo does not establish recurring customer demand.
Worked example: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Usage grows while the task fails
The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Two cohorts fail the product’s task-quality gate despite increased engagement. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Hold expansion, investigate failure types and revise the product hypothesis or workflow.
Recall: Compare task success, review effort, latency and operating cost against the manual baseline. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Problem and non-AI baseline: Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A product starts with a user problem, not a model choice. Compare manual work, fixed rules and AI assistance before deciding what to build.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use the fictional need “Students want reliable answers about library rules.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-option comparison and a pilot success statement.

3. Try step 2
Compare a printed FAQ, keyword search and an AI assistant in a table with benefit, likely failure and human support needed.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-option comparison and a pilot success statement.

4. Try step 3
Choose a small pilot and define how you would check answer correctness and whether students finish their task.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-option comparison and a pilot success statement.

5. Explain and check your result
Your choice has a reason, a test and a fallback; using AI is not itself the success measure. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A three-option comparison and a pilot success statement. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Apply this toy-case rule manually: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two cohorts fail the product’s task-quality gate despite increased engagement. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI product manager.
Use the fictional need “Students want reliable answers about library rules.”
Compare a printed FAQ, keyword search and an AI assistant in a table with benefit, likely failure and human support needed.
Choose a small pilot and define how you would check answer correctness and whether students finish their task.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A three-option comparison and a pilot success statement. Include beginner-worksheet.md and your completed Product launch decision memo.
Check: Your choice has a reason, a test and a fallback; using AI is not itself the success measure.

### Interview
Explain your beginner solution for AI product manager. Use this scenario: The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume.
Review: Start with the task and permitted scope. Explain problem and non-ai baseline: Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable. Show the input and observed output, then address Hold expansion, investigate failure types and revise the product hypothesis or workflow. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A three-option comparison and a pilot success statement. Include beginner-worksheet.md and your completed Product launch decision memo.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Discovery evidence and prototypes

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Product discovery, prioritization, metrics and technical collaboration. Domain-heavy products can require scientific or professional credentials.

### Discovery evidence and prototypes
Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows.
Mental model: A prototype is a rehearsal that reveals where the script breaks.
Boundary: Solo role-play must be labeled simulated research, not customer evidence.
Worked example: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Evidence-led AI product launch case
Take a fictional AI feature from problem discovery to a measured launch decision. Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.
Recall: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. Identify one observation that would contradict your claim.

### Terms
Discovery evidence and prototypes: Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
PRD: Product requirements document: the problem, users, scope, acceptance criteria, constraints and responsibilities.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Take a fictional AI feature from problem discovery to a measured launch decision. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a research guide and synthesize observations in the evidence register. Separate participant quotes, interpretations and assumptions; select one problem with a clear non-AI alternative.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Take a fictional AI feature from problem discovery to a measured launch decision.
Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.
Create a research guide and synthesize observations in the evidence register. Separate participant quotes, interpretations and assumptions; select one problem with a clear non-AI alternative.
Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.
Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample.
Deliverables: PRD and opportunity/evidence map; Tested prototype and research report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI product manager. Use this scenario: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.
Review: Start with the task and permitted scope. Explain discovery evidence and prototypes: Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows. Show the input and observed output, then address Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [PRD and opportunity/evidence map; Tested prototype and research report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Launch decisions and guardrails

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Launch decisions and guardrails
Balance task quality, review effort, cost and risk with explicit ownership. Define hold and rollback conditions before observing a favorable headline metric.
Mental model: A pilot launch has a checklist and a person authorized to call it off.
Boundary: Small exploratory tests do not establish revenue impact or statistical significance.
Worked example: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Evidence-led AI product launch case
Take a fictional AI feature from problem discovery to a measured launch decision. Run a small task-based usability test, document observed failures and prioritize changes. Create an experiment plan and launch checklist with ownership for quality and incidents.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.
Recall: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. Identify one observation that would contradict your claim.

### Terms
Launch decisions and guardrails: Balance task quality, review effort, cost and risk with explicit ownership. Define hold and rollback conditions before observing a favorable headline metric.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
PRD: Product requirements document: the problem, users, scope, acceptance criteria, constraints and responsibilities.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Take a fictional AI feature from problem discovery to a measured launch decision. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a research guide and synthesize observations in the evidence register. Separate participant quotes, interpretations and assumptions; select one problem with a clear non-AI alternative.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run a small task-based usability test, document observed failures and prioritize changes. Create an experiment plan and launch checklist with ownership for quality and incidents.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Take a fictional AI feature from problem discovery to a measured launch decision.
Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.
Create a research guide and synthesize observations in the evidence register. Separate participant quotes, interpretations and assumptions; select one problem with a clear non-AI alternative.
Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.
Run a small task-based usability test, document observed failures and prioritize changes. Create an experiment plan and launch checklist with ownership for quality and incidents.
Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.
Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample.
Build a minimal live pilot with an engineer and replace assumptions with measured outcomes.
Deliverables: PRD and opportunity/evidence map; Tested prototype and research report; Prioritized roadmap and launch decision memo. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. A reviewer must reproduce one result and identify which capabilities you implemented. Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.

### Interview
Explain your advanced solution for AI product manager. Use this scenario: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.
Review: Start with the task and permitted scope. Explain launch decisions and guardrails: Balance task quality, review effort, cost and risk with explicit ownership. Define hold and rollback conditions before observing a favorable headline metric. Show the input and observed output, then address Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [PRD and opportunity/evidence map; Tested prototype and research report; Prioritized roadmap and launch decision memo. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Penpot — Open source · hosted account or self-hosting
Connect prototype boards and test interaction flows; Figma is an alternative.
Alternative: Figma (commercial hosted service with plan-specific access); paper prototypes are sufficient for the first exercise.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

NIST AI RMF — Public framework · not a certification
Organize governance questions and evidence; project recommendations are editorial.
Alternative: OECD AI Principles provide another public perspective; frameworks complement one another and are not automatic certifications.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
Figma learning resources: https://help.figma.com/
