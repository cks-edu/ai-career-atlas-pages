## beginner — Problem and non-AI baseline

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Problem and non-AI baseline
Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable.
Mental model: Choose a destination before selecting the vehicle.
Boundary: A convenient demo does not establish recurring customer demand.
Worked example: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Usage grows while the task fails
The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Two cohorts fail the product’s task-quality gate despite increased engagement. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Hold expansion, investigate failure types and revise the product hypothesis or workflow.
Recall: Compare task success, review effort, latency and operating cost against the manual baseline. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Problem and non-AI baseline: Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A product starts with a user problem, not a model choice. Compare manual work, fixed rules and AI assistance before deciding what to build.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use the fictional need “Students want reliable answers about library rules.”
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-option comparison and a pilot success statement.

3. Try step 2
Compare a printed FAQ, keyword search and an AI assistant in a table with benefit, likely failure and human support needed.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-option comparison and a pilot success statement.

4. Try step 3
Choose a small pilot and define how you would check answer correctness and whether students finish their task.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-option comparison and a pilot success statement.

5. Explain and check your result
Your choice has a reason, a test and a fallback; using AI is not itself the success measure. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A three-option comparison and a pilot success statement. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Apply this toy-case rule manually: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two cohorts fail the product’s task-quality gate despite increased engagement. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI product manager.
Use the fictional need “Students want reliable answers about library rules.”
Compare a printed FAQ, keyword search and an AI assistant in a table with benefit, likely failure and human support needed.
Choose a small pilot and define how you would check answer correctness and whether students finish their task.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A three-option comparison and a pilot success statement. Include beginner-worksheet.md and your completed Product launch decision memo.
Check: Your choice has a reason, a test and a fallback; using AI is not itself the success measure.

### Interview
Explain your beginner solution for AI product manager. Use this scenario: The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume.
Review: Start with the task and permitted scope. Explain problem and non-ai baseline: Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable. Show the input and observed output, then address Hold expansion, investigate failure types and revise the product hypothesis or workflow. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A three-option comparison and a pilot success statement. Include beginner-worksheet.md and your completed Product launch decision memo.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

