# AI product manager — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Problem and non-AI baseline: Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

### Problem and non-AI baseline

Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable. In this role, work through: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Choose a destination before selecting the vehicle.

Boundary: A convenient demo does not establish recurring customer demand.

Worked example: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI product manager: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated.

Predict the worked case

Read this case without running a tool: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in problem and non-ai baseline.

Connect the concept to the role

Apply this rule: Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A convenient demo does not establish recurring customer demand.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies problem and non-ai baseline to this case: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Problem and non-AI baseline; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with problem and non-ai baseline. Use the glossary below, then write your prediction for: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product manager role interview. Explain problem and non-ai baseline using this case: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate problem and non-ai baseline to a system or workflow you know. Explain problem and non-ai baseline using this case: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain problem and non-ai baseline using this case: For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated.

Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable. — Define the user task and current alternative before selecting AI. Separate user benefit from feature usage and decide which failure would make the feature unacceptable. A convenient demo does not establish recurring customer demand.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

Figma learning resources: https://help.figma.com/

### Diagnose: Usage grows while the task fails

The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Two cohorts fail the product’s task-quality gate despite increased engagement. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Hold expansion, investigate failure types and revise the product hypothesis or workflow. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Choose a destination before selecting the vehicle.

For meeting summaries, compare a manual template with AI assistance using correction time and missed decisions, not only number of summaries generated.

Worked example: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Hold expansion, investigate failure types and revise the product hypothesis or workflow.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Two cohorts fail the product’s task-quality gate despite increased engagement. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Apply this toy-case rule manually: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A product starts with a user problem, not a model choice. Compare manual work, fixed rules and AI assistance before deciding what to build.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use the fictional need “Students want reliable answers about library rules.”

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-option comparison and a pilot success statement.

Preparation · Try step 2

Compare a printed FAQ, keyword search and an AI assistant in a table with benefit, likely failure and human support needed.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-option comparison and a pilot success statement.

Preparation · Try step 3

Choose a small pilot and define how you would check answer correctness and whether students finish their task.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A three-option comparison and a pilot success statement.

Preparation · Explain and check your result

Your choice has a reason, a test and a fallback; using AI is not itself the success measure. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A three-option comparison and a pilot success statement. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Apply this toy-case rule manually: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two cohorts fail the product’s task-quality gate despite increased engagement. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two cohorts fail the product’s task-quality gate despite increased engagement. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: usage grows while the task fails. Use the glossary below, then write your prediction for: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Hold expansion, investigate failure types and revise the product hypothesis or workflow. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product manager role interview. Explain diagnose: usage grows while the task fails using this case: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Hold expansion, investigate failure types and revise the product hypothesis or workflow. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: usage grows while the task fails to a system or workflow you know. Explain diagnose: usage grows while the task fails using this case: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Hold expansion, investigate failure types and revise the product hypothesis or workflow. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Compare task success, review effort, latency and operating cost against the manual baseline. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: usage grows while the task fails using this case: Review when failed_tasks >= 3 (out of ten attempts). This is a declared toy-case contract, not an industry standard. Hold expansion, investigate failure types and revise the product hypothesis or workflow. State the evidence, one alternative and where the mental model stops.

Quiz: Usage grows while the task fails: The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume.

Change the acceptance rule after seeing an inconvenient result.

Hold expansion, investigate failure types and revise the product hypothesis or workflow.

Omit failed cases and report only the successful demonstrations.

Reference: Hold expansion, investigate failure types and revise the product hypothesis or workflow. — Hold expansion, investigate failure types and revise the product hypothesis or workflow. Compare task success, review effort, latency and operating cost against the manual baseline.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

Figma learning resources: https://help.figma.com/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Product discovery, prioritization, metrics and technical collaboration. Domain-heavy products can require scientific or professional credentials.

Terms:

Discovery evidence and prototypes: Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

PRD: Product requirements document: the problem, users, scope, acceptance criteria, constraints and responsibilities.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Discovery evidence and prototypes

Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows. In this role, work through: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A prototype is a rehearsal that reveals where the script breaks.

Boundary: Solo role-play must be labeled simulated research, not customer evidence.

Worked example: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Product discovery, prioritization, metrics and technical collaboration. Domain-heavy products can require scientific or professional credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI product manager: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting.

Predict the worked case

Read this case without running a tool: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in discovery evidence and prototypes.

Connect the concept to the role

Apply this rule: Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Solo role-play must be labeled simulated research, not customer evidence.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies discovery evidence and prototypes to this case: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Discovery evidence and prototypes; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with discovery evidence and prototypes. Use the glossary below, then write your prediction for: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product manager role interview. Explain discovery evidence and prototypes using this case: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate discovery evidence and prototypes to a system or workflow you know. Explain discovery evidence and prototypes using this case: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain discovery evidence and prototypes using this case: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting.

Treat a passing starter as proof of the whole role workflow.

Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows.

Ignore the failure because the tool produced an output.

Reference: Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows. — Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows. Solo role-play must be labeled simulated research, not customer evidence.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

Figma learning resources: https://help.figma.com/

### Integrate: Evidence-led AI product launch case

Take a fictional AI feature from problem discovery to a measured launch decision. Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails. In this role, work through: Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A prototype is a rehearsal that reveals where the script breaks.

A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting.

Worked example: Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Take a fictional AI feature from problem discovery to a measured launch decision. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Take a fictional AI feature from problem discovery to a measured launch decision.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a research guide and synthesize observations in the evidence register. Separate participant quotes, interpretations and assumptions; select one problem with a clear non-AI alternative.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: PRD and opportunity/evidence map; Tested prototype and research report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: evidence-led ai product launch case. Use the glossary below, then write your prediction for: Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product manager role interview. Explain integrate: evidence-led ai product launch case using this case: Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: evidence-led ai product launch case to a system or workflow you know. Explain integrate: evidence-led ai product launch case using this case: Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. Identify one observation that would contradict your claim.

Interview: Explain integrate: evidence-led ai product launch case using this case: Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Evidence-led AI product launch case at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample.

Reference: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. — Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

Figma learning resources: https://help.figma.com/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Launch decisions and guardrails: Balance task quality, review effort, cost and risk with explicit ownership. Define hold and rollback conditions before observing a favorable headline metric.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

PRD: Product requirements document: the problem, users, scope, acceptance criteria, constraints and responsibilities.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Launch decisions and guardrails

Balance task quality, review effort, cost and risk with explicit ownership. Define hold and rollback conditions before observing a favorable headline metric. In this role, work through: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A pilot launch has a checklist and a person authorized to call it off.

Boundary: Small exploratory tests do not establish revenue impact or statistical significance.

Worked example: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI product manager: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate.

Predict the worked case

Read this case without running a tool: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in launch decisions and guardrails.

Connect the concept to the role

Apply this rule: Balance task quality, review effort, cost and risk with explicit ownership. Define hold and rollback conditions before observing a favorable headline metric. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Small exploratory tests do not establish revenue impact or statistical significance.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies launch decisions and guardrails to this case: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Launch decisions and guardrails; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with launch decisions and guardrails. Use the glossary below, then write your prediction for: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product manager role interview. Explain launch decisions and guardrails using this case: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate launch decisions and guardrails to a system or workflow you know. Explain launch decisions and guardrails using this case: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain launch decisions and guardrails using this case: Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Balance task quality, review effort, cost and risk with explicit ownership. Define hold and rollback conditions before observing a favorable headline metric.

Reference: Balance task quality, review effort, cost and risk with explicit ownership. Define hold and rollback conditions before observing a favorable headline metric. — Balance task quality, review effort, cost and risk with explicit ownership. Define hold and rollback conditions before observing a favorable headline metric. Small exploratory tests do not establish revenue impact or statistical significance.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

Figma learning resources: https://help.figma.com/

### Defend: Evidence-led AI product launch case

Take a fictional AI feature from problem discovery to a measured launch decision. Run a small task-based usability test, document observed failures and prioritize changes. Create an experiment plan and launch checklist with ownership for quality and incidents. In this role, work through: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A pilot launch has a checklist and a person authorized to call it off.

Usage rises while summary errors increase; hold expansion under the declared quality guardrail and investigate.

Worked example: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Penpot (Open source · hosted account or self-hosting); LibreOffice Calc (Open source · no account needed); NIST AI RMF (Public framework · not a certification)

Take a fictional AI feature from problem discovery to a measured launch decision. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Take a fictional AI feature from problem discovery to a measured launch decision.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a research guide and synthesize observations in the evidence register. Separate participant quotes, interpretations and assumptions; select one problem with a clear non-AI alternative.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Run a small task-based usability test, document observed failures and prioritize changes. Create an experiment plan and launch checklist with ownership for quality and incidents.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. A reviewer must reproduce one result and identify which capabilities you implemented. Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: PRD and opportunity/evidence map; Tested prototype and research report; Prioritized roadmap and launch decision memo. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: evidence-led ai product launch case. Use the glossary below, then write your prediction for: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product manager role interview. Explain defend: evidence-led ai product launch case using this case: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: evidence-led ai product launch case to a system or workflow you know. Explain defend: evidence-led ai product launch case using this case: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. Identify one observation that would contradict your claim.

Interview: Explain defend: evidence-led ai product launch case using this case: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Evidence-led AI product launch case at this level?

Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone. — Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone. Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample.

Sources:

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

Figma learning resources: https://help.figma.com/
