# PRD and opportunity/evidence map

Project: Evidence-led AI product launch case
Status: blank work product — not completed evidence

## Purpose and audience
Take a fictional AI feature from problem discovery to a measured launch decision.

## Required content
Create a research guide and synthesize observations in the evidence register. Separate participant quotes, interpretations and assumptions; select one problem with a clear non-AI alternative.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample.

## Failure evidence
Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
