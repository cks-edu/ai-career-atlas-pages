# Product requirements template

## Problem and evidence
User, job, observed difficulty, source IDs.

## Scope and non-goals
One bounded workflow; explicitly excluded actions.

## User journey
Input, review, correction, failure, undo.

## Acceptance and guardrails
Task outcome, quality floor, accessibility, cost assumptions.

## Experiment
Hypothesis, primary metric, guardrails, sample limitations, stop rule.

## Rollout and ownership
Pilot audience, incident owner, rollback condition.

## Open questions
Evidence needed before launch.
