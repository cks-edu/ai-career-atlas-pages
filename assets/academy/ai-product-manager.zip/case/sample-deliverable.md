# SAMPLE — Product launch decision memo
Role: AI product manager
Case: Usage grows while the task fails
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume.

## Evidence table
| Record | failed_tasks (out of ten attempts) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 6 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two cohorts fail the product’s task-quality gate despite increased engagement.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Hold expansion, investigate failure types and revise the product hypothesis or workflow.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai product manager.
Before release: Compare task success, review effort, latency and operating cost against the manual baseline.

## Design choice and trade-off
Define outcome and guardrail metrics before the pilot; include evidence that would stop the launch.
More interaction can indicate confusion rather than value; include qualitative task observation.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
AI product discovery dossier: Claims are traceable and assumptions are separated from research.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
