## intermediate — Discovery evidence and prototypes

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Product discovery, prioritization, metrics and technical collaboration. Domain-heavy products can require scientific or professional credentials.

### Discovery evidence and prototypes
Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows.
Mental model: A prototype is a rehearsal that reveals where the script breaks.
Boundary: Solo role-play must be labeled simulated research, not customer evidence.
Worked example: A source-review screen is tested with a wrong summary; observe whether users notice and correct it without prompting.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Evidence-led AI product launch case
Take a fictional AI feature from problem discovery to a measured launch decision. Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.
Recall: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. Identify one observation that would contradict your claim.

### Terms
Discovery evidence and prototypes: Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
PRD: Product requirements document: the problem, users, scope, acceptance criteria, constraints and responsibilities.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Take a fictional AI feature from problem discovery to a measured launch decision. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a research guide and synthesize observations in the evidence register. Separate participant quotes, interpretations and assumptions; select one problem with a clear non-AI alternative.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The pilot gate flags more than two failed critical tasks in ten observed attempts, regardless of message volume. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Take a fictional AI feature from problem discovery to a measured launch decision.
Choose an internal meeting-summary feature. Write three user jobs and recruit consenting peers for exploratory interviews, or label a solo role-play as simulated research.
Create a research guide and synthesize observations in the evidence register. Separate participant quotes, interpretations and assumptions; select one problem with a clear non-AI alternative.
Build a Penpot prototype showing source review, correction and failure states. Write a PRD with scope, non-goals, quality metrics, cost assumptions and rollout guardrails.
Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample.
Deliverables: PRD and opportunity/evidence map; Tested prototype and research report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI product manager. Use this scenario: Present a scenario where adoption rises but summary errors increase. Revise the launch decision using the declared guardrail rather than celebrating usage alone.
Review: Start with the task and permitted scope. Explain discovery evidence and prototypes: Use interviews and task-based prototypes to examine assumptions. Keep participant statements separate from your interpretation and show failure states as well as ideal flows. Show the input and observed output, then address Report observed task success, error severity and evidence strength. Do not fabricate customer traction, revenue or statistical significance from a small exploratory sample. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [PRD and opportunity/evidence map; Tested prototype and research report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

