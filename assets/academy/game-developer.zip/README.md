# Game Developer

Software Engineering

Start with coordinates and frame updates. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward performance capture, replay fixture and optimization report.

## beginner

Open movement.html, test each boundary and trace coordinates. Recreate the movement in the official Godot 2D tutorial and use the appropriate frame delta for motion.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### State machines
A state machine defines allowed states and how events change them.
Mental model: Traffic lights change according to explicit rules.
Limit: Real timing, interrupts and hardware noise require additional engineering.
Example: A fan turns on at 30, stays on at 28 and turns off at 25.
Recall: What state would you use when a sensor reading is unavailable?

### Coordinates and frame updates
Game state includes position, velocity and input. Separate input sampling from simulation updates so rendering frequency does not accidentally determine movement speed.
Mental model: A film can show more frames without making the character run faster in the story.
Limit: Faster motion on a high-refresh display suggests movement added per frame without time scaling.
Example: A square must remain within a 400 by 200 play area.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Faster motion on a high-refresh display suggests movement added per frame without time scaling.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
A square must remain within a 400 by 200 play area. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Open movement.html, test each boundary and trace coordinates. Recreate the movement in the official Godot 2D tutorial and use the appropriate frame delta for motion.
Expected: The player stays within bounds and movement behavior is documented.

6. Role workshop · debug and verify
Faster motion on a high-refresh display suggests movement added per frame without time scaling. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save movement prototype and boundary tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The player stays within bounds and movement behavior is documented.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Coordinates and frame updates: Faster motion on a high-refresh display suggests movement added per frame without time scaling.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: movement prototype and boundary tests
The player stays within bounds and movement behavior is documented.

Interview: Work through this Game Developer case: A square must remain within a 400 by 200 play area. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Game state includes position, velocity and input. Separate input sampling from simulation updates so rendering frequency does not accidentally determine movement speed. Expected evidence: The player stays within bounds and movement behavior is documented. Diagnosis: Faster motion on a high-refresh display suggests movement added per frame without time scaling. State the limits of the mental model: A film can show more frames without making the character run faster in the story.

Resume: Built movement prototype and boundary tests using Godot; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Add a restart action to the Godot sample. List state to reset, trigger a collision and restart three times, checking entity count and active timers each time.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Memory and ownership
Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.
Mental model: A borrowed library book must not be used after it is returned.
Limit: Languages enforce different parts of this discipline; concurrency adds other hazards.
Example: A fixed array of four readings is traversed with indices zero through three.
Recall: Why is index four invalid in a four-element array?

### Collision and restart state
A restart should reset all relevant state, including timers, score and spawned entities. Collision response needs a clear ownership and ordering policy.
Mental model: Resetting a board game means putting back every piece, not only the score marker.
Limit: Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership.
Example: After losing with score 3, restart begins with score 0 and one player.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
After losing with score 3, restart begins with score 0 and one player. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add a restart action to the Godot sample. List state to reset, trigger a collision and restart three times, checking entity count and active timers each time.
Expected: No duplicate player, hidden timer or carried-over score after restart.

6. Role workshop · debug and verify
Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save restart checklist and playable project. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: No duplicate player, hidden timer or carried-over score after restart.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Collision and restart state: Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: restart checklist and playable project
No duplicate player, hidden timer or carried-over score after restart.

Interview: Work through this Game Developer case: After losing with score 3, restart begins with score 0 and one player. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A restart should reset all relevant state, including timers, score and spawned entities. Collision response needs a clear ownership and ordering policy. Expected evidence: No duplicate player, hidden timer or carried-over score after restart. Diagnosis: Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership. State the limits of the mental model: Resetting a board game means putting back every piece, not only the score marker.

Resume: Built restart checklist and playable project using Godot; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Profile a fixed scene, record frame-time distribution and add a bounded spawn budget. Replay a saved input sequence and compare final state on the same environment.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Determinism and timing
A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.
Mental model: A rehearsal follows a script; a live performance adds timing constraints.
Limit: A host simulation does not validate hardware or real-time deadlines.
Example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.
Recall: What measurements would be required on actual hardware?

### Frame budgets and deterministic replay
Frame-time spikes matter more than an average frame rate alone. Deterministic replay requires controlled inputs and time assumptions; physics may vary across platforms.
Mental model: A smooth performance depends on avoiding long pauses, not just finishing quickly on average.
Limit: Do not promise cross-platform bit-for-bit physics from one local run.
Example: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not promise cross-platform bit-for-bit physics from one local run.

1. Predict the state sequence
Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.
Expected: Expected states: 0, 1, 1, 0.

2. Compile and run
Read warnings as well as the final output. Do not bypass a failed assertion.
```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Four temperatures and states, then PASS systems: hysteresis.

3. Change one boundary
Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.
Expected: An expanded test table and assertions cover the changed rules.

4. Role workshop · predict
A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Profile a fixed scene, record frame-time distribution and add a bounded spawn budget. Replay a saved input sequence and compare final state on the same environment.
Expected: Measured bottleneck evidence and a stated scope for replay determinism.

6. Role workshop · debug and verify
Do not promise cross-platform bit-for-bit physics from one local run. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save performance capture, replay fixture and optimization report. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Measured bottleneck evidence and a stated scope for replay determinism.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Frame budgets and deterministic replay: Do not promise cross-platform bit-for-bit physics from one local run.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: performance capture, replay fixture and optimization report
Measured bottleneck evidence and a stated scope for replay determinism.

Interview: Work through this Game Developer case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Frame-time spikes matter more than an average frame rate alone. Deterministic replay requires controlled inputs and time assumptions; physics may vary across platforms. Expected evidence: Measured bottleneck evidence and a stated scope for replay determinism. Diagnosis: Do not promise cross-platform bit-for-bit physics from one local run. State the limits of the mental model: A smooth performance depends on avoiding long pauses, not just finishing quickly on average.

Resume: Built performance capture, replay fixture and optimization report using Godot; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html
Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html
The Rust Programming Language: https://doc.rust-lang.org/book/
