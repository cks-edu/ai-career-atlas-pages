# Game Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

State machines: A state machine defines allowed states and how events change them.

Apply state machines in Game Developer: Use the concept to complete this role exercise: Run the movement demo and explain coordinates

Coordinates and frame updates: Game state includes position, velocity and input. Separate input sampling from simulation updates so rendering frequency does not accidentally determine movement speed.

### State machines

A state machine defines allowed states and how events change them. In this role, work through: A square must remain within a 400 by 200 play area. The practical workshop develops this into: Open movement.html, test each boundary and trace coordinates. Recreate the movement in the official Godot 2D tutorial and use the appropriate frame delta for motion.

Mental model: Traffic lights change according to explicit rules.

Boundary: Real timing, interrupts and hardware noise require additional engineering.

Role application: A film can show more frames without making the character run faster in the story.

Game state includes position, velocity and input. Separate input sampling from simulation updates so rendering frequency does not accidentally determine movement speed.

Worked example: A square must remain within a 400 by 200 play area.

Shared foundation example: A fan turns on at 30, stays on at 28 and turns off at 25.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Godot (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Game Developer: A square must remain within a 400 by 200 play area.

Predict the worked case

Read this case without running a tool: A square must remain within a 400 by 200 play area. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in state machines.

Connect the concept to the role

Apply this rule: A state machine defines allowed states and how events change them. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Real timing, interrupts and hardware noise require additional engineering.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies state machines to this case: A square must remain within a 400 by 200 play area. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A square must remain within a 400 by 200 play area. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for State machines; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with state machines. Use the glossary below, then write your prediction for: A square must remain within a 400 by 200 play area. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Game Developer role interview. Explain state machines using this case: A square must remain within a 400 by 200 play area. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate state machines to a system or workflow you know. Explain state machines using this case: A square must remain within a 400 by 200 play area. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What state would you use when a sensor reading is unavailable?

Interview: Explain state machines using this case: A square must remain within a 400 by 200 play area. State the evidence, one alternative and where the mental model stops.

Quiz: After the Coordinates and frame updates rehearsal, check this foundation: An event is valid only in one workflow state. How should it be handled in another state?

Apply the declared transition policy, including rejection or no-op where defined.

Always jump to the final state to complete the flow.

Ignore the current state and repeat the last action.

Reference: Apply the declared transition policy, including rejection or no-op where defined. — A transition depends on the current state and event, not only the event name.

Sources:

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

### Coordinates and frame updates

Game state includes position, velocity and input. Separate input sampling from simulation updates so rendering frequency does not accidentally determine movement speed. In this role, work through: A square must remain within a 400 by 200 play area. The practical workshop develops this into: Open movement.html, test each boundary and trace coordinates. Recreate the movement in the official Godot 2D tutorial and use the appropriate frame delta for motion.

Mental model: A film can show more frames without making the character run faster in the story.

Boundary: Faster motion on a high-refresh display suggests movement added per frame without time scaling.

Worked example: A square must remain within a 400 by 200 play area.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Godot (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Game Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Open movement.html, test each boundary and trace coordinates. Recreate the movement in the official Godot 2D tutorial and use the appropriate frame delta for motion.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

A square must remain within a 400 by 200 play area. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Open movement.html, test each boundary and trace coordinates. Recreate the movement in the official Godot 2D tutorial and use the appropriate frame delta for motion.

Expected: The player stays within bounds and movement behavior is documented.

Role workshop · debug and verify

Faster motion on a high-refresh display suggests movement added per frame without time scaling. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save movement prototype and boundary tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The player stays within bounds and movement behavior is documented.

Expected: The player stays within bounds and movement behavior is documented.

Troubleshoot: The role exercise differs from the prediction: Faster motion on a high-refresh display suggests movement added per frame without time scaling.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: movement prototype and boundary tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with coordinates and frame updates. Use the glossary below, then write your prediction for: A square must remain within a 400 by 200 play area. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Game Developer role interview. Explain coordinates and frame updates using this case: A square must remain within a 400 by 200 play area. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate coordinates and frame updates to a system or workflow you know. Explain coordinates and frame updates using this case: A square must remain within a 400 by 200 play area. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Faster motion on a high-refresh display suggests movement added per frame without time scaling.

Interview: Explain coordinates and frame updates using this case: A square must remain within a 400 by 200 play area. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A square must remain within a 400 by 200 play area.

The player stays within bounds and movement behavior is documented.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: The player stays within bounds and movement behavior is documented. — Game state includes position, velocity and input. Separate input sampling from simulation updates so rendering frequency does not accidentally determine movement speed. The player stays within bounds and movement behavior is documented.

Sources:

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Memory and ownership: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity.

Apply memory and ownership in Game Developer: Use the concept to complete this role exercise: Build the official Godot 2D project and add a restart action

Collision and restart state: A restart should reset all relevant state, including timers, score and spawned entities. Collision response needs a clear ownership and ordering policy.

### Memory and ownership

Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. In this role, work through: After losing with score 3, restart begins with score 0 and one player. The practical workshop develops this into: Add a restart action to the Godot sample. List state to reset, trigger a collision and restart three times, checking entity count and active timers each time.

Mental model: A borrowed library book must not be used after it is returned.

Boundary: Languages enforce different parts of this discipline; concurrency adds other hazards.

Role application: Resetting a board game means putting back every piece, not only the score marker.

A restart should reset all relevant state, including timers, score and spawned entities. Collision response needs a clear ownership and ordering policy.

Worked example: After losing with score 3, restart begins with score 0 and one player.

Shared foundation example: A fixed array of four readings is traversed with indices zero through three.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Godot (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Game Developer: After losing with score 3, restart begins with score 0 and one player.

Predict the worked case

Read this case without running a tool: After losing with score 3, restart begins with score 0 and one player. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in memory and ownership.

Connect the concept to the role

Apply this rule: Memory stores data with a lifetime. Code must avoid using data after its owner has released it or writing beyond capacity. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Languages enforce different parts of this discipline; concurrency adds other hazards.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies memory and ownership to this case: After losing with score 3, restart begins with score 0 and one player. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: After losing with score 3, restart begins with score 0 and one player. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Memory and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with memory and ownership. Use the glossary below, then write your prediction for: After losing with score 3, restart begins with score 0 and one player. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Game Developer role interview. Explain memory and ownership using this case: After losing with score 3, restart begins with score 0 and one player. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate memory and ownership to a system or workflow you know. Explain memory and ownership using this case: After losing with score 3, restart begins with score 0 and one player. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is index four invalid in a four-element array?

Interview: Explain memory and ownership using this case: After losing with score 3, restart begins with score 0 and one player. State the evidence, one alternative and where the mental model stops.

Quiz: After the Collision and restart state rehearsal, check this foundation: A buffer has capacity four and zero-based indices. Which index range is valid?

1 through 4 inclusive.

0 through 3 inclusive.

0 through 4 inclusive.

Reference: 0 through 3 inclusive. — Capacity is the number of elements; the last valid zero-based index is capacity minus one. Lifetime checks are separate.

Sources:

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

### Collision and restart state

A restart should reset all relevant state, including timers, score and spawned entities. Collision response needs a clear ownership and ordering policy. In this role, work through: After losing with score 3, restart begins with score 0 and one player. The practical workshop develops this into: Add a restart action to the Godot sample. List state to reset, trigger a collision and restart three times, checking entity count and active timers each time.

Mental model: Resetting a board game means putting back every piece, not only the score marker.

Boundary: Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership.

Worked example: After losing with score 3, restart begins with score 0 and one player.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Godot (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Game Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add a restart action to the Godot sample. List state to reset, trigger a collision and restart three times, checking entity count and active timers each time.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

After losing with score 3, restart begins with score 0 and one player. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add a restart action to the Godot sample. List state to reset, trigger a collision and restart three times, checking entity count and active timers each time.

Expected: No duplicate player, hidden timer or carried-over score after restart.

Role workshop · debug and verify

Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save restart checklist and playable project. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: No duplicate player, hidden timer or carried-over score after restart.

Expected: No duplicate player, hidden timer or carried-over score after restart.

Troubleshoot: The role exercise differs from the prediction: Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: restart checklist and playable project; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with collision and restart state. Use the glossary below, then write your prediction for: After losing with score 3, restart begins with score 0 and one player. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Game Developer role interview. Explain collision and restart state using this case: After losing with score 3, restart begins with score 0 and one player. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate collision and restart state to a system or workflow you know. Explain collision and restart state using this case: After losing with score 3, restart begins with score 0 and one player. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership.

Interview: Explain collision and restart state using this case: After losing with score 3, restart begins with score 0 and one player. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? After losing with score 3, restart begins with score 0 and one player.

Ignore the failing case and keep only the successful screenshot.

No duplicate player, hidden timer or carried-over score after restart.

Treat any successful command as proof that all business and access rules passed.

Reference: No duplicate player, hidden timer or carried-over score after restart. — A restart should reset all relevant state, including timers, score and spawned entities. Collision response needs a clear ownership and ordering policy. No duplicate player, hidden timer or carried-over score after restart.

Sources:

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Determinism and timing: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits.

Apply determinism and timing in Game Developer: Use the concept to complete this role exercise: Profile frame time and design deterministic replay and asset budgets

Frame budgets and deterministic replay: Frame-time spikes matter more than an average frame rate alone. Deterministic replay requires controlled inputs and time assumptions; physics may vary across platforms.

### Determinism and timing

A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. In this role, work through: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. The practical workshop develops this into: Profile a fixed scene, record frame-time distribution and add a bounded spawn budget. Replay a saved input sequence and compare final state on the same environment.

Mental model: A rehearsal follows a script; a live performance adds timing constraints.

Boundary: A host simulation does not validate hardware or real-time deadlines.

Role application: A smooth performance depends on avoiding long pauses, not just finishing quickly on average.

Frame-time spikes matter more than an average frame rate alone. Deterministic replay requires controlled inputs and time assumptions; physics may vary across platforms.

Worked example: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable.

Shared foundation example: Replay 24,30,28,25 and expect fan states 0,1,1,0 every time.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Godot (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Game Developer: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable.

Predict the worked case

Read this case without running a tool: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in determinism and timing.

Connect the concept to the role

Apply this rule: A deterministic test repeats the same result for the same input. Real systems also need measured timing and resource limits. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A host simulation does not validate hardware or real-time deadlines.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies determinism and timing to this case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Determinism and timing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with determinism and timing. Use the glossary below, then write your prediction for: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Game Developer role interview. Explain determinism and timing using this case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate determinism and timing to a system or workflow you know. Explain determinism and timing using this case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What measurements would be required on actual hardware?

Interview: Explain determinism and timing using this case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. State the evidence, one alternative and where the mental model stops.

Quiz: After the Frame budgets and deterministic replay rehearsal, check this foundation: A replay produces the expected output every time. What is still needed for a real-time deadline claim?

No further evidence if results are deterministic.

Only a larger input file.

Measured timing under the intended resource and load conditions.

Reference: Measured timing under the intended resource and load conditions. — Repeatable results do not establish latency or worst-case timing on the target system.

Sources:

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/

### Frame budgets and deterministic replay

Frame-time spikes matter more than an average frame rate alone. Deterministic replay requires controlled inputs and time assumptions; physics may vary across platforms. In this role, work through: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. The practical workshop develops this into: Profile a fixed scene, record frame-time distribution and add a bounded spawn budget. Replay a saved input sequence and compare final state on the same environment.

Mental model: A smooth performance depends on avoiding long pauses, not just finishing quickly on average.

Boundary: Do not promise cross-platform bit-for-bit physics from one local run.

Worked example: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable.

Setup: Use a host C compiler (Clang or GCC). macOS may require Xcode Command Line Tools; Linux may require its compiler package; Windows can use an approved WSL environment. This is a host simulation, not hardware firmware. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Godot (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Game Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Profile a fixed scene, record frame-time distribution and add a bounded spawn budget. Replay a saved input sequence and compare final state on the same environment.

Predict the state sequence

Open sensor.c. Write the expected fan state for 24, 30, 28 and 25 before compiling.

Expected: Expected states: 0, 1, 1, 0.

Compile and run

Read warnings as well as the final output. Do not bypass a failed assertion.

```
cc -Wall -Wextra -std=c11 sensor.c -o sensor
./sensor
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Four temperatures and states, then PASS systems: hysteresis.

Change one boundary

Add readings exactly at 30 and 25. Intermediate: add an invalid-sensor state. Advanced: test all transition pairs and state what timing you have not measured.

Expected: An expanded test table and assertions cover the changed rules.

Role workshop · predict

A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Profile a fixed scene, record frame-time distribution and add a bounded spawn budget. Replay a saved input sequence and compare final state on the same environment.

Expected: Measured bottleneck evidence and a stated scope for replay determinism.

Role workshop · debug and verify

Do not promise cross-platform bit-for-bit physics from one local run. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save performance capture, replay fixture and optimization report. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Measured bottleneck evidence and a stated scope for replay determinism.

Expected: Measured bottleneck evidence and a stated scope for replay determinism.

Troubleshoot: The role exercise differs from the prediction: Do not promise cross-platform bit-for-bit physics from one local run.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: performance capture, replay fixture and optimization report; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with frame budgets and deterministic replay. Use the glossary below, then write your prediction for: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Game Developer role interview. Explain frame budgets and deterministic replay using this case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate frame budgets and deterministic replay to a system or workflow you know. Explain frame budgets and deterministic replay using this case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not promise cross-platform bit-for-bit physics from one local run.

Interview: Explain frame budgets and deterministic replay using this case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Measured bottleneck evidence and a stated scope for replay determinism.

Reference: Measured bottleneck evidence and a stated scope for replay determinism. — Frame-time spikes matter more than an average frame rate alone. Deterministic replay requires controlled inputs and time assumptions; physics may vary across platforms. Measured bottleneck evidence and a stated scope for replay determinism.

Sources:

Godot: your first 2D game: https://docs.godotengine.org/en/stable/getting_started/first_2d_game/index.html

Zephyr: setup and first embedded application: https://docs.zephyrproject.org/latest/develop/getting_started/index.html

The Rust Programming Language: https://doc.rust-lang.org/book/
