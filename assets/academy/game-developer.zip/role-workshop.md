# Game Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Coordinates and frame updates

Game state includes position, velocity and input. Separate input sampling from simulation updates so rendering frequency does not accidentally determine movement speed.
Mental model: A film can show more frames without making the character run faster in the story.
Case: A square must remain within a 400 by 200 play area.
Task: Open movement.html, test each boundary and trace coordinates. Recreate the movement in the official Godot 2D tutorial and use the appropriate frame delta for motion.
Acceptance: The player stays within bounds and movement behavior is documented.
Troubleshooting: Faster motion on a high-refresh display suggests movement added per frame without time scaling.
Deliverable: movement prototype and boundary tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Collision and restart state

A restart should reset all relevant state, including timers, score and spawned entities. Collision response needs a clear ownership and ordering policy.
Mental model: Resetting a board game means putting back every piece, not only the score marker.
Case: After losing with score 3, restart begins with score 0 and one player.
Task: Add a restart action to the Godot sample. List state to reset, trigger a collision and restart three times, checking entity count and active timers each time.
Acceptance: No duplicate player, hidden timer or carried-over score after restart.
Troubleshooting: Objects surviving scene reset may be owned outside the scene; inspect lifecycle ownership.
Deliverable: restart checklist and playable project

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Frame budgets and deterministic replay

Frame-time spikes matter more than an average frame rate alone. Deterministic replay requires controlled inputs and time assumptions; physics may vary across platforms.
Mental model: A smooth performance depends on avoiding long pauses, not just finishing quickly on average.
Case: A burst of spawned entities can exceed the frame budget even when the average FPS looks acceptable.
Task: Profile a fixed scene, record frame-time distribution and add a bounded spawn budget. Replay a saved input sequence and compare final state on the same environment.
Acceptance: Measured bottleneck evidence and a stated scope for replay determinism.
Troubleshooting: Do not promise cross-platform bit-for-bit physics from one local run.
Deliverable: performance capture, replay fixture and optimization report

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
