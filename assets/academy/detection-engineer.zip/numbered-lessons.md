# Detection Engineer / SIEM Specialist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Authentication and authorization: Authentication establishes identity; authorization decides which action that identity may perform.

Apply authentication and authorization in Detection Engineer / SIEM Specialist: Use the concept to complete this role exercise: Define one suspicious event pattern and a benign counterexample

Detection hypotheses: A detection hypothesis states observable behavior, data needed and the reason it matters. Start from behavior rather than collecting logs without a question.

### Authentication and authorization

Authentication establishes identity; authorization decides which action that identity may perform. In this role, work through: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. The practical workshop develops this into: Write a hypothesis, required fields and a synthetic event fixture with both suspicious and benign sequences. Specify time normalization and entity keys.

Mental model: An ID card tells who you are; the door policy says where you may enter.

Boundary: A valid login does not authorize access to every record.

Role application: A sensor is placed where it can observe the event of interest.

A detection hypothesis states observable behavior, data needed and the reason it matters. Start from behavior rather than collecting logs without a question.

Worked example: Repeated denied access followed by a privileged success is more informative than a raw denial count alone.

Shared foundation example: Alice may read but not write; an unknown user is denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Microsoft Sentinel and KQL (Commercial service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Detection Engineer / SIEM Specialist: Repeated denied access followed by a privileged success is more informative than a raw denial count alone.

Predict the worked case

Read this case without running a tool: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in authentication and authorization.

Connect the concept to the role

Apply this rule: Authentication establishes identity; authorization decides which action that identity may perform. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A valid login does not authorize access to every record.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies authentication and authorization to this case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Authentication and authorization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with authentication and authorization. Use the glossary below, then write your prediction for: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Detection Engineer / SIEM Specialist role interview. Explain authentication and authorization using this case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate authentication and authorization to a system or workflow you know. Explain authentication and authorization using this case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Where should an object ownership check happen?

Interview: Explain authentication and authorization using this case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. State the evidence, one alternative and where the mental model stops.

Quiz: After the Detection hypotheses rehearsal, check this foundation: A logged-in user requests another user’s private record. What must the service still check?

Whether this identity is permitted to perform this action on that record.

Only whether the session token has the correct syntax.

Only whether the record identifier exists.

Reference: Whether this identity is permitted to perform this action on that record. — Authentication establishes identity; authorization checks the action and resource.

Sources:

Microsoft Sentinel documentation: https://learn.microsoft.com/en-us/azure/sentinel/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Detection hypotheses

A detection hypothesis states observable behavior, data needed and the reason it matters. Start from behavior rather than collecting logs without a question. In this role, work through: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. The practical workshop develops this into: Write a hypothesis, required fields and a synthetic event fixture with both suspicious and benign sequences. Specify time normalization and entity keys.

Mental model: A sensor is placed where it can observe the event of interest.

Boundary: If the required identity field is absent, the hypothesis cannot be reliably tested.

Worked example: Repeated denied access followed by a privileged success is more informative than a raw denial count alone.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Microsoft Sentinel and KQL (Commercial service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Detection Engineer / SIEM Specialist workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a hypothesis, required fields and a synthetic event fixture with both suspicious and benign sequences. Specify time normalization and entity keys.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Repeated denied access followed by a privileged success is more informative than a raw denial count alone. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a hypothesis, required fields and a synthetic event fixture with both suspicious and benign sequences. Specify time normalization and entity keys.

Expected: A queryable dataset and a falsifiable detection condition.

Role workshop · debug and verify

If the required identity field is absent, the hypothesis cannot be reliably tested. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save detection specification and fixtures. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A queryable dataset and a falsifiable detection condition.

Expected: A queryable dataset and a falsifiable detection condition.

Troubleshoot: The role exercise differs from the prediction: If the required identity field is absent, the hypothesis cannot be reliably tested.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: detection specification and fixtures; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with detection hypotheses. Use the glossary below, then write your prediction for: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Detection Engineer / SIEM Specialist role interview. Explain detection hypotheses using this case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate detection hypotheses to a system or workflow you know. Explain detection hypotheses using this case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If the required identity field is absent, the hypothesis cannot be reliably tested.

Interview: Explain detection hypotheses using this case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Repeated denied access followed by a privileged success is more informative than a raw denial count alone.

A queryable dataset and a falsifiable detection condition.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A queryable dataset and a falsifiable detection condition. — A detection hypothesis states observable behavior, data needed and the reason it matters. Start from behavior rather than collecting logs without a question. A queryable dataset and a falsifiable detection condition.

Sources:

Microsoft Sentinel documentation: https://learn.microsoft.com/en-us/azure/sentinel/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Code and data separation: Parameterized SQL keeps input values separate from SQL instructions.

Apply code and data separation in Detection Engineer / SIEM Specialist: Use the concept to complete this role exercise: Write a synthetic-log detection test with false-positive cases

Rule tests and tuning: A rule needs regression cases for intended matches and known benign lookalikes. Precision and recall depend on labeled data and scope; a tiny fixture is not a production accuracy estimate.

### Code and data separation

Parameterized SQL keeps input values separate from SQL instructions. In this role, work through: A password typo sequence should not automatically equal a credential attack. The practical workshop develops this into: Implement the sequence in Python or a SIEM query, run labeled fixtures and record true/false matches and misses. Tune one condition and compare both versions.

Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.

Boundary: Parameters protect values; dynamic table names still require explicit allowlists.

Role application: A sieve must be tested with both the objects to catch and those to let through.

A rule needs regression cases for intended matches and known benign lookalikes. Precision and recall depend on labeled data and scope; a tiny fixture is not a production accuracy estimate.

Worked example: A password typo sequence should not automatically equal a credential attack.

Shared foundation example: The malicious-looking owner string is treated as a value and returns zero rows.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Microsoft Sentinel and KQL (Commercial service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Detection Engineer / SIEM Specialist: A password typo sequence should not automatically equal a credential attack.

Predict the worked case

Read this case without running a tool: A password typo sequence should not automatically equal a credential attack. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in code and data separation.

Connect the concept to the role

Apply this rule: Parameterized SQL keeps input values separate from SQL instructions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Parameters protect values; dynamic table names still require explicit allowlists.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies code and data separation to this case: A password typo sequence should not automatically equal a credential attack. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A password typo sequence should not automatically equal a credential attack. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Code and data separation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with code and data separation. Use the glossary below, then write your prediction for: A password typo sequence should not automatically equal a credential attack. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Detection Engineer / SIEM Specialist role interview. Explain code and data separation using this case: A password typo sequence should not automatically equal a credential attack. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate code and data separation to a system or workflow you know. Explain code and data separation using this case: A password typo sequence should not automatically equal a credential attack. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is escaping one example string weaker than using parameters?

Interview: Explain code and data separation using this case: A password typo sequence should not automatically equal a credential attack. State the evidence, one alternative and where the mental model stops.

Quiz: After the Rule tests and tuning rehearsal, check this foundation: A query binds a user value through a parameter. Can that same placeholder choose an arbitrary table name?

Yes, placeholders bind all SQL syntax.

No; structural identifiers need an allowlisted query design.

Yes, if the identifier arrives over HTTPS.

Reference: No; structural identifiers need an allowlisted query design. — Parameters bind values, not arbitrary SQL structure. Transport security does not change SQL semantics.

Sources:

Microsoft Sentinel documentation: https://learn.microsoft.com/en-us/azure/sentinel/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Rule tests and tuning

A rule needs regression cases for intended matches and known benign lookalikes. Precision and recall depend on labeled data and scope; a tiny fixture is not a production accuracy estimate. In this role, work through: A password typo sequence should not automatically equal a credential attack. The practical workshop develops this into: Implement the sequence in Python or a SIEM query, run labeled fixtures and record true/false matches and misses. Tune one condition and compare both versions.

Mental model: A sieve must be tested with both the objects to catch and those to let through.

Boundary: Do not tune only against the positive example; rerun benign cases after every change.

Worked example: A password typo sequence should not automatically equal a credential attack.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Microsoft Sentinel and KQL (Commercial service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Detection Engineer / SIEM Specialist workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Implement the sequence in Python or a SIEM query, run labeled fixtures and record true/false matches and misses. Tune one condition and compare both versions.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A password typo sequence should not automatically equal a credential attack. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Implement the sequence in Python or a SIEM query, run labeled fixtures and record true/false matches and misses. Tune one condition and compare both versions.

Expected: A transparent confusion table for the fixture, with limitations.

Role workshop · debug and verify

Do not tune only against the positive example; rerun benign cases after every change. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save versioned detection and regression suite. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A transparent confusion table for the fixture, with limitations.

Expected: A transparent confusion table for the fixture, with limitations.

Troubleshoot: The role exercise differs from the prediction: Do not tune only against the positive example; rerun benign cases after every change.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: versioned detection and regression suite; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with rule tests and tuning. Use the glossary below, then write your prediction for: A password typo sequence should not automatically equal a credential attack. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Detection Engineer / SIEM Specialist role interview. Explain rule tests and tuning using this case: A password typo sequence should not automatically equal a credential attack. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate rule tests and tuning to a system or workflow you know. Explain rule tests and tuning using this case: A password typo sequence should not automatically equal a credential attack. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not tune only against the positive example; rerun benign cases after every change.

Interview: Explain rule tests and tuning using this case: A password typo sequence should not automatically equal a credential attack. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A password typo sequence should not automatically equal a credential attack.

Ignore the failing case and keep only the successful screenshot.

A transparent confusion table for the fixture, with limitations.

Treat any successful command as proof that all business and access rules passed.

Reference: A transparent confusion table for the fixture, with limitations. — A rule needs regression cases for intended matches and known benign lookalikes. Precision and recall depend on labeled data and scope; a tiny fixture is not a production accuracy estimate. A transparent confusion table for the fixture, with limitations.

Sources:

Microsoft Sentinel documentation: https://learn.microsoft.com/en-us/azure/sentinel/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Threat models and regression: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.

Apply threat models and regression in Detection Engineer / SIEM Specialist: Use the concept to complete this role exercise: Plan rule versioning, triage evidence, alert ownership and data-retention cost

Detection deployment and observability: A rule can fail because its data disappears, its schema changes or its alert path breaks. Monitor the detection pipeline itself and define ownership for triage.

### Threat models and regression

State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. In this role, work through: A field rename from user to principal can make a query return zero matches silently. The practical workshop develops this into: Inject a schema-change fixture, add a missing-field/data-freshness check and write a staged enablement plan. Test alert routing with synthetic events and document suppression/rollback.

Mental model: Mark doors and valuable rooms on a building map before choosing locks.

Boundary: A threat model is a living hypothesis, not proof that the system is secure.

Role application: An alarm needs both a sensor and a working bell.

A rule can fail because its data disappears, its schema changes or its alert path breaks. Monitor the detection pipeline itself and define ownership for triage.

Worked example: A field rename from user to principal can make a query return zero matches silently.

Shared foundation example: Reader-write, unknown-read and unsupported-delete must all be denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Microsoft Sentinel and KQL (Commercial service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Detection Engineer / SIEM Specialist: A field rename from user to principal can make a query return zero matches silently.

Predict the worked case

Read this case without running a tool: A field rename from user to principal can make a query return zero matches silently. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in threat models and regression.

Connect the concept to the role

Apply this rule: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A threat model is a living hypothesis, not proof that the system is secure.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies threat models and regression to this case: A field rename from user to principal can make a query return zero matches silently. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A field rename from user to principal can make a query return zero matches silently. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Threat models and regression; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with threat models and regression. Use the glossary below, then write your prediction for: A field rename from user to principal can make a query return zero matches silently. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Detection Engineer / SIEM Specialist role interview. Explain threat models and regression using this case: A field rename from user to principal can make a query return zero matches silently. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate threat models and regression to a system or workflow you know. Explain threat models and regression using this case: A field rename from user to principal can make a query return zero matches silently. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would a new export endpoint change the threat model?

Interview: Explain threat models and regression using this case: A field rename from user to principal can make a query return zero matches silently. State the evidence, one alternative and where the mental model stops.

Quiz: After the Detection deployment and observability rehearsal, check this foundation: A denied action is fixed after a security defect. What helps detect its recurrence?

Document only the successful authorized path.

Remove the denied case because it now passes.

Add a repeatable negative test tied to the actor, action and trust boundary.

Reference: Add a repeatable negative test tied to the actor, action and trust boundary. — Regression checks preserve evidence for important misuse cases; the threat model explains why the control matters.

Sources:

Microsoft Sentinel documentation: https://learn.microsoft.com/en-us/azure/sentinel/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Detection deployment and observability

A rule can fail because its data disappears, its schema changes or its alert path breaks. Monitor the detection pipeline itself and define ownership for triage. In this role, work through: A field rename from user to principal can make a query return zero matches silently. The practical workshop develops this into: Inject a schema-change fixture, add a missing-field/data-freshness check and write a staged enablement plan. Test alert routing with synthetic events and document suppression/rollback.

Mental model: An alarm needs both a sensor and a working bell.

Boundary: Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health.

Worked example: A field rename from user to principal can make a query return zero matches silently.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Microsoft Sentinel and KQL (Commercial service); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Detection Engineer / SIEM Specialist workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Inject a schema-change fixture, add a missing-field/data-freshness check and write a staged enablement plan. Test alert routing with synthetic events and document suppression/rollback.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A field rename from user to principal can make a query return zero matches silently. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Inject a schema-change fixture, add a missing-field/data-freshness check and write a staged enablement plan. Test alert routing with synthetic events and document suppression/rollback.

Expected: A visible pipeline-health failure and an owned alert path.

Role workshop · debug and verify

Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save detection release pack and health dashboard specification. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A visible pipeline-health failure and an owned alert path.

Expected: A visible pipeline-health failure and an owned alert path.

Troubleshoot: The role exercise differs from the prediction: Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: detection release pack and health dashboard specification; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with detection deployment and observability. Use the glossary below, then write your prediction for: A field rename from user to principal can make a query return zero matches silently. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Detection Engineer / SIEM Specialist role interview. Explain detection deployment and observability using this case: A field rename from user to principal can make a query return zero matches silently. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate detection deployment and observability to a system or workflow you know. Explain detection deployment and observability using this case: A field rename from user to principal can make a query return zero matches silently. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health.

Interview: Explain detection deployment and observability using this case: A field rename from user to principal can make a query return zero matches silently. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A field rename from user to principal can make a query return zero matches silently.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A visible pipeline-health failure and an owned alert path.

Reference: A visible pipeline-health failure and an owned alert path. — A rule can fail because its data disappears, its schema changes or its alert path breaks. Monitor the detection pipeline itself and define ownership for triage. A visible pipeline-health failure and an owned alert path.

Sources:

Microsoft Sentinel documentation: https://learn.microsoft.com/en-us/azure/sentinel/

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
