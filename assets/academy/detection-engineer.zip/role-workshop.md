# Detection Engineer / SIEM Specialist — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Detection hypotheses

A detection hypothesis states observable behavior, data needed and the reason it matters. Start from behavior rather than collecting logs without a question.
Mental model: A sensor is placed where it can observe the event of interest.
Case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone.
Task: Write a hypothesis, required fields and a synthetic event fixture with both suspicious and benign sequences. Specify time normalization and entity keys.
Acceptance: A queryable dataset and a falsifiable detection condition.
Troubleshooting: If the required identity field is absent, the hypothesis cannot be reliably tested.
Deliverable: detection specification and fixtures

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Rule tests and tuning

A rule needs regression cases for intended matches and known benign lookalikes. Precision and recall depend on labeled data and scope; a tiny fixture is not a production accuracy estimate.
Mental model: A sieve must be tested with both the objects to catch and those to let through.
Case: A password typo sequence should not automatically equal a credential attack.
Task: Implement the sequence in Python or a SIEM query, run labeled fixtures and record true/false matches and misses. Tune one condition and compare both versions.
Acceptance: A transparent confusion table for the fixture, with limitations.
Troubleshooting: Do not tune only against the positive example; rerun benign cases after every change.
Deliverable: versioned detection and regression suite

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Detection deployment and observability

A rule can fail because its data disappears, its schema changes or its alert path breaks. Monitor the detection pipeline itself and define ownership for triage.
Mental model: An alarm needs both a sensor and a working bell.
Case: A field rename from user to principal can make a query return zero matches silently.
Task: Inject a schema-change fixture, add a missing-field/data-freshness check and write a staged enablement plan. Test alert routing with synthetic events and document suppression/rollback.
Acceptance: A visible pipeline-health failure and an owned alert path.
Troubleshooting: Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health.
Deliverable: detection release pack and health dashboard specification

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
