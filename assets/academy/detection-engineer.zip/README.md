# Detection Engineer / SIEM Specialist

Software Engineering

Start with detection hypotheses. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward detection release pack and health dashboard specification.

## beginner

Write a hypothesis, required fields and a synthetic event fixture with both suspicious and benign sequences. Specify time normalization and entity keys.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Authentication and authorization
Authentication establishes identity; authorization decides which action that identity may perform.
Mental model: An ID card tells who you are; the door policy says where you may enter.
Limit: A valid login does not authorize access to every record.
Example: Alice may read but not write; an unknown user is denied.
Recall: Where should an object ownership check happen?

### Detection hypotheses
A detection hypothesis states observable behavior, data needed and the reason it matters. Start from behavior rather than collecting logs without a question.
Mental model: A sensor is placed where it can observe the event of interest.
Limit: If the required identity field is absent, the hypothesis cannot be reliably tested.
Example: Repeated denied access followed by a privileged success is more informative than a raw denial count alone.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If the required identity field is absent, the hypothesis cannot be reliably tested.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Repeated denied access followed by a privileged success is more informative than a raw denial count alone. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a hypothesis, required fields and a synthetic event fixture with both suspicious and benign sequences. Specify time normalization and entity keys.
Expected: A queryable dataset and a falsifiable detection condition.

6. Role workshop · debug and verify
If the required identity field is absent, the hypothesis cannot be reliably tested. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save detection specification and fixtures. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A queryable dataset and a falsifiable detection condition.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Detection hypotheses: If the required identity field is absent, the hypothesis cannot be reliably tested.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: detection specification and fixtures
A queryable dataset and a falsifiable detection condition.

Interview: Work through this Detection Engineer / SIEM Specialist case: Repeated denied access followed by a privileged success is more informative than a raw denial count alone. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A detection hypothesis states observable behavior, data needed and the reason it matters. Start from behavior rather than collecting logs without a question. Expected evidence: A queryable dataset and a falsifiable detection condition. Diagnosis: If the required identity field is absent, the hypothesis cannot be reliably tested. State the limits of the mental model: A sensor is placed where it can observe the event of interest.

Resume: Built detection specification and fixtures using Microsoft Sentinel and KQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Implement the sequence in Python or a SIEM query, run labeled fixtures and record true/false matches and misses. Tune one condition and compare both versions.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Code and data separation
Parameterized SQL keeps input values separate from SQL instructions.
Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.
Limit: Parameters protect values; dynamic table names still require explicit allowlists.
Example: The malicious-looking owner string is treated as a value and returns zero rows.
Recall: Why is escaping one example string weaker than using parameters?

### Rule tests and tuning
A rule needs regression cases for intended matches and known benign lookalikes. Precision and recall depend on labeled data and scope; a tiny fixture is not a production accuracy estimate.
Mental model: A sieve must be tested with both the objects to catch and those to let through.
Limit: Do not tune only against the positive example; rerun benign cases after every change.
Example: A password typo sequence should not automatically equal a credential attack.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not tune only against the positive example; rerun benign cases after every change.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A password typo sequence should not automatically equal a credential attack. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Implement the sequence in Python or a SIEM query, run labeled fixtures and record true/false matches and misses. Tune one condition and compare both versions.
Expected: A transparent confusion table for the fixture, with limitations.

6. Role workshop · debug and verify
Do not tune only against the positive example; rerun benign cases after every change. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save versioned detection and regression suite. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A transparent confusion table for the fixture, with limitations.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Rule tests and tuning: Do not tune only against the positive example; rerun benign cases after every change.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: versioned detection and regression suite
A transparent confusion table for the fixture, with limitations.

Interview: Work through this Detection Engineer / SIEM Specialist case: A password typo sequence should not automatically equal a credential attack. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A rule needs regression cases for intended matches and known benign lookalikes. Precision and recall depend on labeled data and scope; a tiny fixture is not a production accuracy estimate. Expected evidence: A transparent confusion table for the fixture, with limitations. Diagnosis: Do not tune only against the positive example; rerun benign cases after every change. State the limits of the mental model: A sieve must be tested with both the objects to catch and those to let through.

Resume: Built versioned detection and regression suite using Microsoft Sentinel and KQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Inject a schema-change fixture, add a missing-field/data-freshness check and write a staged enablement plan. Test alert routing with synthetic events and document suppression/rollback.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Threat models and regression
State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.
Mental model: Mark doors and valuable rooms on a building map before choosing locks.
Limit: A threat model is a living hypothesis, not proof that the system is secure.
Example: Reader-write, unknown-read and unsupported-delete must all be denied.
Recall: How would a new export endpoint change the threat model?

### Detection deployment and observability
A rule can fail because its data disappears, its schema changes or its alert path breaks. Monitor the detection pipeline itself and define ownership for triage.
Mental model: An alarm needs both a sensor and a working bell.
Limit: Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health.
Example: A field rename from user to principal can make a query return zero matches silently.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A field rename from user to principal can make a query return zero matches silently. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Inject a schema-change fixture, add a missing-field/data-freshness check and write a staged enablement plan. Test alert routing with synthetic events and document suppression/rollback.
Expected: A visible pipeline-health failure and an owned alert path.

6. Role workshop · debug and verify
Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save detection release pack and health dashboard specification. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A visible pipeline-health failure and an owned alert path.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Detection deployment and observability: Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: detection release pack and health dashboard specification
A visible pipeline-health failure and an owned alert path.

Interview: Work through this Detection Engineer / SIEM Specialist case: A field rename from user to principal can make a query return zero matches silently. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A rule can fail because its data disappears, its schema changes or its alert path breaks. Monitor the detection pipeline itself and define ownership for triage. Expected evidence: A visible pipeline-health failure and an owned alert path. Diagnosis: Zero alerts can mean no attacks or a broken rule; inspect ingestion and query health. State the limits of the mental model: An alarm needs both a sensor and a working bell.

Resume: Built detection release pack and health dashboard specification using Microsoft Sentinel and KQL; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Microsoft Sentinel documentation: https://learn.microsoft.com/en-us/azure/sentinel/
OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
