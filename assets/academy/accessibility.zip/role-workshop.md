# Accessibility Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Names, roles and keyboard focus

Accessible names tell assistive technology what a control does. Semantic HTML supplies roles and keyboard behavior, while visible focus lets keyboard users follow their position.
Mental model: Every door needs a readable sign and a reachable handle.
Case: Tab reaches the title input and Add button in a meaningful order.
Task: Inspect the reference accessibility tree, verify label association, then complete the task flow without a mouse. Record each focused control and its announced name.
Acceptance: No unreachable action or unnamed control in the exercised flow.
Troubleshooting: A clickable div needs extra behavior; prefer a native button before adding custom keyboard handlers.
Deliverable: keyboard and accessible-name audit

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Errors and status announcements

An error should identify the field and explain how to recover. Dynamic success messages need an appropriate announcement without moving focus unexpectedly.
Mental model: A receptionist should tell you what to correct without dragging you to another desk.
Case: Blank input announces the title error; a successful add announces completion while keeping usable focus.
Task: Add associated error text and a polite status region. Test with a supported screen reader and keyboard, including correction after failure. Note the browser/assistive technology combination.
Acceptance: Errors are understandable and completion is conveyed without duplicate announcements.
Troubleshooting: If every keystroke is announced, the live region may be too broad; limit it to status updates.
Deliverable: screen-reader transcript and remediation diff

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Reflow and inclusive release evidence

Automated accessibility checks catch only part of the problem. Combine zoom, contrast, keyboard and assistive-technology testing with human review of meaning and task completion.
Mental model: A spellchecker cannot judge whether the whole instruction is understandable.
Case: At 400% zoom, essential controls remain reachable without two-dimensional scrolling for ordinary text.
Task: Run a tool such as axe-core, then manually test zoom, long titles, focus order and error recovery. Prioritize by user impact and retest fixes. Record the exact browser, zoom level and assistive technology used.
Acceptance: A report distinguishes automated findings, manual findings and untested combinations.
Troubleshooting: A zero automated-violation count is not a complete accessibility claim.
Deliverable: accessibility conformance evidence and retest matrix

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
