# Accessibility Engineer

Software Engineering

Start with names, roles and keyboard focus. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward accessibility conformance evidence and retest matrix.

## beginner

Inspect the reference accessibility tree, verify label association, then complete the task flow without a mouse. Record each focused control and its announced name.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Observable behavior
A test compares a defined observation with an expected result for a chosen input.
Mental model: A recipe with a taste check rather than a photograph of ingredients.
Limit: Passing examples do not prove every possible input works.
Example: An empty task must not be added and the error must be understandable.
Recall: Write a test case with input, action and expected observation.

### Names, roles and keyboard focus
Accessible names tell assistive technology what a control does. Semantic HTML supplies roles and keyboard behavior, while visible focus lets keyboard users follow their position.
Mental model: Every door needs a readable sign and a reachable handle.
Limit: A clickable div needs extra behavior; prefer a native button before adding custom keyboard handlers.
Example: Tab reaches the title input and Add button in a meaningful order.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A clickable div needs extra behavior; prefer a native button before adding custom keyboard handlers.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web beginner

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Tab reaches the title input and Add button in a meaningful order. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Inspect the reference accessibility tree, verify label association, then complete the task flow without a mouse. Record each focused control and its announced name.
Expected: No unreachable action or unnamed control in the exercised flow.

6. Role workshop · debug and verify
A clickable div needs extra behavior; prefer a native button before adding custom keyboard handlers. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save keyboard and accessible-name audit. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: No unreachable action or unnamed control in the exercised flow.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Names, roles and keyboard focus: A clickable div needs extra behavior; prefer a native button before adding custom keyboard handlers.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: keyboard and accessible-name audit
No unreachable action or unnamed control in the exercised flow.

Interview: Work through this Accessibility Engineer case: Tab reaches the title input and Add button in a meaningful order. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Accessible names tell assistive technology what a control does. Semantic HTML supplies roles and keyboard behavior, while visible focus lets keyboard users follow their position. Expected evidence: No unreachable action or unnamed control in the exercised flow. Diagnosis: A clickable div needs extra behavior; prefer a native button before adding custom keyboard handlers. State the limits of the mental model: Every door needs a readable sign and a reachable handle.

Resume: Built keyboard and accessible-name audit using Browser accessibility tree and keyboard testing; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Add associated error text and a polite status region. Test with a supported screen reader and keyboard, including correction after failure. Note the browser/assistive technology combination.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Test boundaries
Unit checks isolate a rule; integration checks exercise cooperating parts; end-to-end checks exercise a user flow.
Mental model: Check a component, then an assembled bicycle, then a ride.
Limit: More end-to-end tests can be slower and harder to diagnose; keep focused checks too.
Example: Validate title alone, then HTTP request, then keyboard submission in the browser.
Recall: Which layer should identify whether a failure is parsing or rendering?

### Errors and status announcements
An error should identify the field and explain how to recover. Dynamic success messages need an appropriate announcement without moving focus unexpectedly.
Mental model: A receptionist should tell you what to correct without dragging you to another desk.
Limit: If every keystroke is announced, the live region may be too broad; limit it to status updates.
Example: Blank input announces the title error; a successful add announces completion while keeping usable focus.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If every keystroke is announced, the live region may be too broad; limit it to status updates.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web intermediate

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
Blank input announces the title error; a successful add announces completion while keeping usable focus. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add associated error text and a polite status region. Test with a supported screen reader and keyboard, including correction after failure. Note the browser/assistive technology combination.
Expected: Errors are understandable and completion is conveyed without duplicate announcements.

6. Role workshop · debug and verify
If every keystroke is announced, the live region may be too broad; limit it to status updates. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save screen-reader transcript and remediation diff. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Errors are understandable and completion is conveyed without duplicate announcements.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Errors and status announcements: If every keystroke is announced, the live region may be too broad; limit it to status updates.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: screen-reader transcript and remediation diff
Errors are understandable and completion is conveyed without duplicate announcements.

Interview: Work through this Accessibility Engineer case: Blank input announces the title error; a successful add announces completion while keeping usable focus. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An error should identify the field and explain how to recover. Dynamic success messages need an appropriate announcement without moving focus unexpectedly. Expected evidence: Errors are understandable and completion is conveyed without duplicate announcements. Diagnosis: If every keystroke is announced, the live region may be too broad; limit it to status updates. State the limits of the mental model: A receptionist should tell you what to correct without dragging you to another desk.

Resume: Built screen-reader transcript and remediation diff using Browser accessibility tree and keyboard testing; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run a tool such as axe-core, then manually test zoom, long titles, focus order and error recovery. Prioritize by user impact and retest fixes. Record the exact browser, zoom level and assistive technology used.

Setup: Install a supported Node.js LTS (reference checked with Node 24). Run node --version. No npm installation is needed for this reference. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Risk-based release
Test the most harmful plausible failures and record what remains untested. Include accessibility and recovery.
Mental model: Inspect brakes before polishing the paint.
Limit: Risk ranking is judgment informed by users, not an excuse to skip known defects.
Example: Test invalid input, double submission, keyboard focus and server restart; record results.
Recall: What evidence would make you hold a release despite a high pass count?

### Reflow and inclusive release evidence
Automated accessibility checks catch only part of the problem. Combine zoom, contrast, keyboard and assistive-technology testing with human review of meaning and task completion.
Mental model: A spellchecker cannot judge whether the whole instruction is understandable.
Limit: A zero automated-violation count is not a complete accessibility claim.
Example: At 400% zoom, essential controls remain reachable without two-dimensional scrolling for ordinary text.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A zero automated-violation count is not a complete accessibility claim.

1. Read the rule
Open app.mjs. Find title() and predict the result for " Learn ", blank text and 81 letters.
Expected: Trimmed title succeeds; blank and overlong titles are rejected.

2. Run focused checks
Run the supplied checks before editing.
```
node app.mjs test advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: PASS web advanced

3. Use the browser
Start the server, open http://127.0.0.1:8135, submit Read docs, then inspect the Network panel. Stop with Ctrl+C.
```
node app.mjs
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The task appears; POST returns 201. Restart clears tasks because storage is in memory.

4. Role workshop · predict
At 400% zoom, essential controls remain reachable without two-dimensional scrolling for ordinary text. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run a tool such as axe-core, then manually test zoom, long titles, focus order and error recovery. Prioritize by user impact and retest fixes. Record the exact browser, zoom level and assistive technology used.
Expected: A report distinguishes automated findings, manual findings and untested combinations.

6. Role workshop · debug and verify
A zero automated-violation count is not a complete accessibility claim. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save accessibility conformance evidence and retest matrix. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A report distinguishes automated findings, manual findings and untested combinations.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
EADDRINUSE on 8135: Another program uses this port. Stop your previous lab terminal with Ctrl+C, or change 8135 in your own copy and open that new port.
The list is empty after restart: Expected: the reference has no database. Add persistence only after defining schema and recovery tests.
Reflow and inclusive release evidence: A zero automated-violation count is not a complete accessibility claim.
Cleanup: Stop only your lab server with Ctrl+C. In-memory tasks disappear. Keep the source and evidence.

Portfolio: accessibility conformance evidence and retest matrix
A report distinguishes automated findings, manual findings and untested combinations.

Interview: Work through this Accessibility Engineer case: At 400% zoom, essential controls remain reachable without two-dimensional scrolling for ordinary text. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Automated accessibility checks catch only part of the problem. Combine zoom, contrast, keyboard and assistive-technology testing with human review of meaning and task completion. Expected evidence: A report distinguishes automated findings, manual findings and untested combinations. Diagnosis: A zero automated-violation count is not a complete accessibility claim. State the limits of the mental model: A spellchecker cannot judge whether the whole instruction is understandable.

Resume: Built accessibility conformance evidence and retest matrix using Browser accessibility tree and keyboard testing; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
Playwright: installation and first tests: https://playwright.dev/docs/intro
Node.js: getting started: https://nodejs.org/en/learn/getting-started/introduction-to-nodejs
