# Verify a pinned learning image with an approved identity

Install Cosign using its official guide; replace all placeholders with your authorized artifact and trust policy. This is a verification operation, not signing, admission deployment or a promise of safe model behavior. Verify model blobs separately where required. Do not disable verification to obtain a pass.

```sh
cosign verify --certificate-identity YOUR_APPROVED_IDENTITY --certificate-oidc-issuer YOUR_APPROVED_ISSUER YOUR_REGISTRY_IMAGE@sha256:YOUR_EXACT_DIGEST
```

Expected evidence: Keep the actual verification output and exact artifact binding. A missing signature or wrong identity must stop admission.

Cleanup: these inspection commands create no resources. Stop only separately started learning servers and remove only your own temporary resources after retaining evidence. No cloud resources are provisioned by this pack.
