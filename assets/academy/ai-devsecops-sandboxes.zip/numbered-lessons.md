# AI DevSecOps, Model Supply Chain & Agent Sandboxes — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## advanced

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

Pickle: Python object serialization that can execute code when deserializing.

SafeTensors: A tensor storage format designed to avoid pickle object execution.

Digest: A content hash identifying bytes, not an origin guarantee.

Signer policy: The identities, issuers or keys authorized for a release.

RuntimeClass: A Kubernetes runtime configuration selection, whose handler must actually exist.

MicroVM: A small virtual-machine boundary with its own operational requirements.

Egress: Outgoing network traffic.

Admission policy envelope: A teaching representation of requirements, separate from native Kubernetes schemas.

### SafeTensors & unsafe deserialization boundaries

Pickle can reconstruct executable Python objects during loading. A tensor-only format such as SafeTensors reduces that deserialization attack surface. A file suffix, model card or public download count does not establish trusted provenance.

The fixture accepts only a trusted inventory report declaring a tensor-only format and matching .safetensors artifact path. It rejects pickle and ambiguous .bin paths under this lab policy. The inventory report is supplied by a trusted scanner in a native workflow, not by model output.

SafeTensors does not certify model behavior, tokenizer code or surrounding loaders. Do not load untrusted serialized objects to discover whether they are safe; isolate analysis and verify actual format and provenance.

Mental model: Approved artifact inventory → format policy → restricted tensor loader. Picture the boundary as a checked gate between stages.

Boundary: SafeTensors does not certify model behavior, tokenizer code or surrounding loaders. Do not load untrusted serialized objects to discover whether they are safe; isolate analysis and verify actual format and provenance.

Worked example: function tensorFormatAllowed(p) {
  return !!p && p.inventoryTrusted===true && p.format==='safetensors' && typeof p.path==='string' && p.path.endsWith('.safetensors');
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-devsecops-sandboxes.zip, install Node.js LTS, then open production-ai/15-01-safe-weight-format.

Tools for this exercise: JavaScript · local isolated workbench; SafeTensors / Cosign / Kyverno, gVisor / Firecracker / NetworkPolicy as documented optional extensions

Course tool and framework map: SafeTensors / Cosign / Kyverno (Open-source tools · trust policy and hosting still required); gVisor / Firecracker / NetworkPolicy (Open source · platform-specific setup)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Install Cosign using its official guide; replace all placeholders with your authorized artifact and trust policy. This is a verification operation, not signing, admission deployment or a promise of safe model behavior. Verify model blobs separately where required. Do not disable verification to obtain a pass.

Implement tensorFormatAllowed without opening or deserializing unsafe fixtures. Draw the difference between filename, format, signature and model behavior.

Terminal folder: production-ai/15-01-safe-weight-format

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture accepts only a trusted inventory report declaring a tensor-only format and matching .safetensors artifact path. It rejects pickle and ambiguous .bin paths under this lab policy. The inventory report is supplied by a trusted scanner in a native workflow, not by model output.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement tensorFormatAllowed without opening or deserializing unsafe fixtures. Draw the difference between filename, format, signature and model behavior.

Expected: Accept an approved tensor inventory

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Deny unsafe or ambiguous paths; Reject untrusted assertions

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Verify a pinned learning image with an approved identity

Install Cosign using its official guide; replace all placeholders with your authorized artifact and trust policy. This is a verification operation, not signing, admission deployment or a promise of safe model behavior. Verify model blobs separately where required. Do not disable verification to obtain a pass.

```
cosign verify --certificate-identity YOUR_APPROVED_IDENTITY --certificate-oidc-issuer YOUR_APPROVED_ISSUER YOUR_REGISTRY_IMAGE@sha256:YOUR_EXACT_DIGEST
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Keep the actual verification output and exact artifact binding. A missing signature or wrong identity must stop admission.

Expected: Accept an approved tensor inventory; Deny unsafe or ambiguous paths; Reject untrusted assertions. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Deny executable formats and review the loader and provenance. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/15-01-safe-weight-format/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Approved artifact inventory → format policy → restricted tensor loader. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does renaming model.pkl to model.safetensors remove deserialization risk? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Downloading weights is separate from executing loader code. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does renaming model.pkl to model.safetensors remove deserialization risk?

Interview: Does renaming model.pkl to model.safetensors remove deserialization risk? Explain the decision, a failing case and a production limitation.

Quiz: Does renaming model.pkl to model.safetensors remove deserialization risk?

Yes, extensions convert formats.

No; verify actual format and the trusted loader path.

Only if the file is popular.

Reference: No; verify actual format and the trusted loader path. — No; verify actual format and the trusted loader path. SafeTensors does not certify model behavior, tokenizer code or surrounding loaders. Do not load untrusted serialized objects to discover whether they are safe; isolate analysis and verify actual format and provenance.

Sources:

Hugging Face: SafeTensors format: https://huggingface.co/docs/safetensors/index

Sigstore: verify signatures and signer identity: https://docs.sigstore.dev/cosign/verifying/verify/

### Cosign signatures & trusted admission evidence

A digest identifies bytes; a valid signature binds them to an identity under a trust policy. Checking that a string resembles sha256 is not signature verification. Admission must consume verification results from a trusted verifier, bound to the exact deployed artifact.

The fixture checks a trusted verifier result against the requested digest and approved signer identity. verified=true alone is insufficient. In a native pipeline use Cosign with the required identity/issuer or key policy and configure a supported Kyverno image validation policy.

This function does not perform cryptography. Kyverno APIs evolve; check your installed version and current image-validation policy documentation. Weight blobs and container images may need separate attestations.

Mental model: Artifact digest → trusted signature verifier → signer policy → admission. Picture the boundary as a checked gate between stages.

Boundary: This function does not perform cryptography. Kyverno APIs evolve; check your installed version and current image-validation policy documentation. Weight blobs and container images may need separate attestations.

Worked example: function verifiedModelArtifact(p) {
  return !!p && /^sha256:[a-f0-9]{64}$/.test(p.digest||'') && p.verification?.trustedSource===true && p.verification.verified===true && p.verification.digest===p.digest && typeof p.allowedSigner==='string' && p.allowedSigner.length>0 && p.verification.signer===p.allowedSigner;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-devsecops-sandboxes.zip, install Node.js LTS, then open production-ai/15-02-signed-admission.

Tools for this exercise: JavaScript · local isolated workbench; SafeTensors / Cosign / Kyverno, gVisor / Firecracker / NetworkPolicy as documented optional extensions

Course tool and framework map: SafeTensors / Cosign / Kyverno (Open-source tools · trust policy and hosting still required); gVisor / Firecracker / NetworkPolicy (Open source · platform-specific setup)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Install Cosign using its official guide; replace all placeholders with your authorized artifact and trust policy. This is a verification operation, not signing, admission deployment or a promise of safe model behavior. Verify model blobs separately where required. Do not disable verification to obtain a pass.

Implement verifiedModelArtifact. Document the separate Cosign verification step and how the admission controller receives authenticated evidence; include wrong-digest and wrong-signer cases.

Terminal folder: production-ai/15-02-signed-admission

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture checks a trusted verifier result against the requested digest and approved signer identity. verified=true alone is insufficient. In a native pipeline use Cosign with the required identity/issuer or key policy and configure a supported Kyverno image validation policy.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement verifiedModelArtifact. Document the separate Cosign verification step and how the admission controller receives authenticated evidence; include wrong-digest and wrong-signer cases.

Expected: Bind exact artifact and signer

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Deny changed bytes; Deny self-reported verification

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Verify a pinned learning image with an approved identity

Install Cosign using its official guide; replace all placeholders with your authorized artifact and trust policy. This is a verification operation, not signing, admission deployment or a promise of safe model behavior. Verify model blobs separately where required. Do not disable verification to obtain a pass.

```
cosign verify --certificate-identity YOUR_APPROVED_IDENTITY --certificate-oidc-issuer YOUR_APPROVED_ISSUER YOUR_REGISTRY_IMAGE@sha256:YOUR_EXACT_DIGEST
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Keep the actual verification output and exact artifact binding. A missing signature or wrong identity must stop admission.

Expected: Bind exact artifact and signer; Deny changed bytes; Deny self-reported verification. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Bind trusted verification evidence to exact digest and signer policy. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/15-02-signed-admission/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Artifact digest → trusted signature verifier → signer policy → admission. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Is a valid-looking SHA-256 string sufficient for admission? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A model response cannot declare its own provenance trustworthy. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Is a valid-looking SHA-256 string sufficient for admission?

Interview: Is a valid-looking SHA-256 string sufficient for admission? Explain the decision, a failing case and a production limitation.

Quiz: Is a valid-looking SHA-256 string sufficient for admission?

No; verify provenance under a trusted signer policy for those exact bytes.

Yes; a hash is a signature.

Yes; let the model set verified=true.

Reference: No; verify provenance under a trusted signer policy for those exact bytes. — No; verify provenance under a trusted signer policy for those exact bytes. This function does not perform cryptography. Kyverno APIs evolve; check your installed version and current image-validation policy documentation. Weight blobs and container images may need separate attestations.

Sources:

Sigstore: verify signatures and signer identity: https://docs.sigstore.dev/cosign/verifying/verify/

Kyverno: image validation policy: https://kyverno.io/docs/policy-types/image-validating-policy/

### gVisor & Firecracker agent isolation

An agent that executes code needs a runtime boundary independent of its prompt. gVisor and Firecracker have different architectures and deployment requirements. Neither removes the need for minimal credentials, resource limits and network controls.

This lab requires a gvisor RuntimeClass label for an agent fixture and separately denies privileged mode, host networking and a mounted service-account token. The label is only policy intent; a native test must confirm it maps to the configured runtime.

A RuntimeClass name does not prove an isolation mechanism is installed or correctly configured. Firecracker microVM integration is a different option, not a drop-in RuntimeClass assumption.

Mental model: Approved code task → constrained agent runtime → bounded output. Picture the boundary as a checked gate between stages.

Boundary: A RuntimeClass name does not prove an isolation mechanism is installed or correctly configured. Firecracker microVM integration is a different option, not a drop-in RuntimeClass assumption.

Worked example: function isolatedAgentSpec(p) {
  return !!p && p.runtimeClassName==='gvisor' && p.privileged===false && p.hostNetwork===false && p.automountServiceAccountToken===false;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-devsecops-sandboxes.zip, install Node.js LTS, then open production-ai/15-03-agent-runtime.

Tools for this exercise: JavaScript · local isolated workbench; SafeTensors / Cosign / Kyverno, gVisor / Firecracker / NetworkPolicy as documented optional extensions

Course tool and framework map: SafeTensors / Cosign / Kyverno (Open-source tools · trust policy and hosting still required); gVisor / Firecracker / NetworkPolicy (Open source · platform-specific setup)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Install Cosign using its official guide; replace all placeholders with your authorized artifact and trust policy. This is a verification operation, not signing, admission deployment or a promise of safe model behavior. Verify model blobs separately where required. Do not disable verification to obtain a pass.

Implement isolatedAgentSpec. Make an enforcement checklist covering the RuntimeClass handler, host privileges, credentials, filesystem, CPU/memory/time limits and an observed denied action.

Terminal folder: production-ai/15-03-agent-runtime

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This lab requires a gvisor RuntimeClass label for an agent fixture and separately denies privileged mode, host networking and a mounted service-account token. The label is only policy intent; a native test must confirm it maps to the configured runtime.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement isolatedAgentSpec. Make an enforcement checklist covering the RuntimeClass handler, host privileges, credentials, filesystem, CPU/memory/time limits and an observed denied action.

Expected: Accept constrained intent

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Deny host capability; Deny absent controls

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Verify a pinned learning image with an approved identity

Install Cosign using its official guide; replace all placeholders with your authorized artifact and trust policy. This is a verification operation, not signing, admission deployment or a promise of safe model behavior. Verify model blobs separately where required. Do not disable verification to obtain a pass.

```
cosign verify --certificate-identity YOUR_APPROVED_IDENTITY --certificate-oidc-issuer YOUR_APPROVED_ISSUER YOUR_REGISTRY_IMAGE@sha256:YOUR_EXACT_DIGEST
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Keep the actual verification output and exact artifact binding. A missing signature or wrong identity must stop admission.

Expected: Accept constrained intent; Deny host capability; Deny absent controls. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require the configured sandbox and remove unnecessary privileges. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/15-03-agent-runtime/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Approved code task → constrained agent runtime → bounded output. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does runtimeClassName: gvisor alone prove effective isolation? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A safe-looking prompt is not an operating-system isolation boundary. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does runtimeClassName: gvisor alone prove effective isolation?

Interview: Does runtimeClassName: gvisor alone prove effective isolation? Explain the decision, a failing case and a production limitation.

Quiz: Does runtimeClassName: gvisor alone prove effective isolation?

Yes, the label is the boundary.

Yes, even if the runtime is absent.

No; validate the configured runtime and independent privilege controls.

Reference: No; validate the configured runtime and independent privilege controls. — No; validate the configured runtime and independent privilege controls. A RuntimeClass name does not prove an isolation mechanism is installed or correctly configured. Firecracker microVM integration is a different option, not a drop-in RuntimeClass assumption.

Sources:

gVisor: security model and boundaries: https://gvisor.dev/docs/architecture_guide/security/

Firecracker: production security considerations: https://github.com/firecracker-microvm/firecracker/blob/main/docs/prod-host-setup.md

### Agent/MCP egress policy & metadata protection

Code-executing agents and MCP tools must reach only approved destinations. Default-deny networking and explicit egress controls help limit data exfiltration and metadata credential access. A domain allowlist needs DNS and resolved-address controls; substring matching is not enough.

The combined admission fixture rejects pickle mounts, mismatched signature evidence, missing gVisor intent and any policy allowing metadata access. It requires declared default-deny egress and an exact destination allowlist excluding 169.254.169.254. These are a policy envelope, not a NetworkPolicy API.

NetworkPolicy enforcement depends on the CNI and has implementation limits around host traffic, IP translation and other paths. The fixture cannot prove a live network block or cryptographic signature; test enforcement and trusted evidence separately.

Mental model: Agent/tool request → admission evidence → runtime → enforced egress. Picture the boundary as a checked gate between stages.

Boundary: NetworkPolicy enforcement depends on the CNI and has implementation limits around host traffic, IP translation and other paths. The fixture cannot prove a live network block or cryptographic signature; test enforcement and trusted evidence separately.

Worked example: function verifyAiWorkloadSecurity(p) {
  if(!p || !Array.isArray(p.modelMounts) || p.modelMounts.length===0 || p.modelMounts.some(x=>typeof x!=='string' || !x.endsWith('.safetensors'))) return false;
  const v=p.verification;
  return /^sha256:[a-f0-9]{64}$/.test(p.digest||'') && v?.trustedSource===true && v.verified===true && v.digest===p.digest && v.signer===p.allowedSigner && typeof p.allowedSigner==='string' && p.allowedSigner.length>0 && p.runtimeClassName==='gvisor' && p.privileged===false && p.egress?.defaultDeny===true && p.egress.metadataBlocked===true && Array.isArray(p.egress.allowedDestinations) && p.egress.allowedDestinations.every(x=>typeof x==='string' && x.length>0 && x!=='169.254.169.254');
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract ai-devsecops-sandboxes.zip, install Node.js LTS, then open production-ai/15-04-egress-admission.

Tools for this exercise: JavaScript · local isolated workbench; SafeTensors / Cosign / Kyverno, gVisor / Firecracker / NetworkPolicy as documented optional extensions

Course tool and framework map: SafeTensors / Cosign / Kyverno (Open-source tools · trust policy and hosting still required); gVisor / Firecracker / NetworkPolicy (Open source · platform-specific setup)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Install Cosign using its official guide; replace all placeholders with your authorized artifact and trust policy. This is a verification operation, not signing, admission deployment or a promise of safe model behavior. Verify model blobs separately where required. Do not disable verification to obtain a pass.

Implement verifyAiWorkloadSecurity. Test each independent rejection separately and design a native default-deny egress verification record without using real credentials.

Terminal folder: production-ai/15-04-egress-admission

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The combined admission fixture rejects pickle mounts, mismatched signature evidence, missing gVisor intent and any policy allowing metadata access. It requires declared default-deny egress and an exact destination allowlist excluding 169.254.169.254. These are a policy envelope, not a NetworkPolicy API.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement verifyAiWorkloadSecurity. Test each independent rejection separately and design a native default-deny egress verification record without using real credentials.

Expected: Accept a declared complete policy

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Deny unsafe mounts and network policy; Reject unverified and metadata access

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Verify a pinned learning image with an approved identity

Install Cosign using its official guide; replace all placeholders with your authorized artifact and trust policy. This is a verification operation, not signing, admission deployment or a promise of safe model behavior. Verify model blobs separately where required. Do not disable verification to obtain a pass.

```
cosign verify --certificate-identity YOUR_APPROVED_IDENTITY --certificate-oidc-issuer YOUR_APPROVED_ISSUER YOUR_REGISTRY_IMAGE@sha256:YOUR_EXACT_DIGEST
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Keep the actual verification output and exact artifact binding. A missing signature or wrong identity must stop admission.

Expected: Accept a declared complete policy; Deny unsafe mounts and network policy; Reject unverified and metadata access. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Deny unsafe mounts and metadata; enforce reviewed runtime and default-deny egress. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/15-04-egress-admission/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Agent/tool request → admission evidence → runtime → enforced egress. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. What proves the metadata endpoint is blocked in a deployed sandbox? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A prompt-level prohibition cannot block a network socket. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: What proves the metadata endpoint is blocked in a deployed sandbox?

Interview: What proves the metadata endpoint is blocked in a deployed sandbox? Explain the decision, a failing case and a production limitation.

Quiz: What proves the metadata endpoint is blocked in a deployed sandbox?

A browser policy return value alone.

An authorized runtime network test against the enforced policy.

A model promising never to contact it.

Reference: An authorized runtime network test against the enforced policy. — An authorized runtime network test against the enforced policy. NetworkPolicy enforcement depends on the CNI and has implementation limits around host traffic, IP translation and other paths. The fixture cannot prove a live network block or cryptographic signature; test enforcement and trusted evidence separately.

Sources:

Kubernetes: NetworkPolicies and implementation limits: https://kubernetes.io/docs/concepts/services-networking/network-policies/

Sigstore: verify signatures and signer identity: https://docs.sigstore.dev/cosign/verifying/verify/

gVisor: security model and boundaries: https://gvisor.dev/docs/architecture_guide/security/
