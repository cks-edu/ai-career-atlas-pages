function verifiedModelArtifact(p) {
  return !!p && /^sha256:[a-f0-9]{64}$/.test(p.digest||'') && p.verification?.trustedSource===true && p.verification.verified===true && p.verification.digest===p.digest && typeof p.allowedSigner==='string' && p.allowedSigner.length>0 && p.verification.signer===p.allowedSigner;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const d='sha256:'+'a'.repeat(64);assert(verifiedModelArtifact({digest:d,allowedSigner:'release-team',verification:{trustedSource:true,verified:true,digest:d,signer:'release-team'}}));
console.log("PASS: Bind exact artifact and signer");
}
{
const d='sha256:'+'a'.repeat(64);assert(!verifiedModelArtifact({digest:d,allowedSigner:'team',verification:{trustedSource:true,verified:true,digest:'sha256:'+'b'.repeat(64),signer:'team'}}));
console.log("PASS: Deny changed bytes");
}
{
assert(!verifiedModelArtifact({digest:'sha256:'+'a'.repeat(64),allowedSigner:'team',verification:{trustedSource:false,verified:true,signer:'team'}}));assert(!verifiedModelArtifact(null));
console.log("PASS: Deny self-reported verification");
}
