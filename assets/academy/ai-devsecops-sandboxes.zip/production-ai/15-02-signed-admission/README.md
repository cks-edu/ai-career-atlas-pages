# Cosign signatures & trusted admission evidence

A digest identifies bytes; a valid signature binds them to an identity under a trust policy. Checking that a string resembles sha256 is not signature verification. Admission must consume verification results from a trusted verifier, bound to the exact deployed artifact.

The fixture checks a trusted verifier result against the requested digest and approved signer identity. verified=true alone is insufficient. In a native pipeline use Cosign with the required identity/issuer or key policy and configure a supported Kyverno image validation policy.

Task: Implement verifiedModelArtifact. Document the separate Cosign verification step and how the admission controller receives authenticated evidence; include wrong-digest and wrong-signer cases.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Artifact digest → trusted signature verifier → signer policy → admission.
State: Requested digest, verified digest and approved signer.
Boundary: A model response cannot declare its own provenance trustworthy.
Failure: A signature for different bytes is reused to admit an altered model.
Control: Bind trusted verification evidence to exact digest and signer policy.
Observability: Record verification result, issuer/key policy and rejection cause.
Blast radius: Workloads admitted through the compromised trust boundary.
Trade-off: Strict verification can block urgent deployments when signing infrastructure is unavailable.

Limit: This function does not perform cryptography. Kyverno APIs evolve; check your installed version and current image-validation policy documentation. Weight blobs and container images may need separate attestations.

Sources:
https://docs.sigstore.dev/cosign/verifying/verify/
https://kyverno.io/docs/policy-types/image-validating-policy/
