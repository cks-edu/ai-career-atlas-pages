function isolatedAgentSpec(p) {
  return !!p && p.runtimeClassName==='gvisor' && p.privileged===false && p.hostNetwork===false && p.automountServiceAccountToken===false;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(isolatedAgentSpec({runtimeClassName:'gvisor',privileged:false,hostNetwork:false,automountServiceAccountToken:false}));
console.log("PASS: Accept constrained intent");
}
{
assert(!isolatedAgentSpec({runtimeClassName:'gvisor',privileged:true,hostNetwork:false,automountServiceAccountToken:false}));assert(!isolatedAgentSpec({runtimeClassName:'gvisor',privileged:false,hostNetwork:true,automountServiceAccountToken:false}));
console.log("PASS: Deny host capability");
}
{
assert(!isolatedAgentSpec({runtimeClassName:'gvisor'}));assert(!isolatedAgentSpec(null));
console.log("PASS: Deny absent controls");
}
