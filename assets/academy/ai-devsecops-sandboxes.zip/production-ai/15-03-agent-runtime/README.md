# gVisor & Firecracker agent isolation

An agent that executes code needs a runtime boundary independent of its prompt. gVisor and Firecracker have different architectures and deployment requirements. Neither removes the need for minimal credentials, resource limits and network controls.

This lab requires a gvisor RuntimeClass label for an agent fixture and separately denies privileged mode, host networking and a mounted service-account token. The label is only policy intent; a native test must confirm it maps to the configured runtime.

Task: Implement isolatedAgentSpec. Make an enforcement checklist covering the RuntimeClass handler, host privileges, credentials, filesystem, CPU/memory/time limits and an observed denied action.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Approved code task → constrained agent runtime → bounded output.
State: Runtime selection, host privileges and credential mount policy.
Boundary: A safe-looking prompt is not an operating-system isolation boundary.
Failure: An agent process inherits host access or reusable credentials.
Control: Require the configured sandbox and remove unnecessary privileges.
Observability: Inspect actual runtime handlers, blocked syscalls and credential exposure tests.
Blast radius: The sandbox host and reachable credentialed services.
Trade-off: Stronger isolation can increase compatibility work and execution overhead.

Limit: A RuntimeClass name does not prove an isolation mechanism is installed or correctly configured. Firecracker microVM integration is a different option, not a drop-in RuntimeClass assumption.

Sources:
https://gvisor.dev/docs/architecture_guide/security/
https://github.com/firecracker-microvm/firecracker/blob/main/docs/prod-host-setup.md
