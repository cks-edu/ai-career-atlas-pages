function verifyAiWorkloadSecurity(p) {
  if(!p || !Array.isArray(p.modelMounts) || p.modelMounts.length===0 || p.modelMounts.some(x=>typeof x!=='string' || !x.endsWith('.safetensors'))) return false;
  const v=p.verification;
  return /^sha256:[a-f0-9]{64}$/.test(p.digest||'') && v?.trustedSource===true && v.verified===true && v.digest===p.digest && v.signer===p.allowedSigner && typeof p.allowedSigner==='string' && p.allowedSigner.length>0 && p.runtimeClassName==='gvisor' && p.privileged===false && p.egress?.defaultDeny===true && p.egress.metadataBlocked===true && Array.isArray(p.egress.allowedDestinations) && p.egress.allowedDestinations.every(x=>typeof x==='string' && x.length>0 && x!=='169.254.169.254');
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const d='sha256:'+'a'.repeat(64);const p={modelMounts:['m.safetensors'],digest:d,allowedSigner:'team',verification:{trustedSource:true,verified:true,digest:d,signer:'team'},runtimeClassName:'gvisor',privileged:false,egress:{defaultDeny:true,metadataBlocked:true,allowedDestinations:['approved-service']}};assert(verifyAiWorkloadSecurity(p));
console.log("PASS: Accept a declared complete policy");
}
{
const d='sha256:'+'a'.repeat(64);const p={modelMounts:['m.pkl'],digest:d,allowedSigner:'team',verification:{trustedSource:true,verified:true,digest:d,signer:'team'},runtimeClassName:'gvisor',privileged:false,egress:{defaultDeny:true,metadataBlocked:true,allowedDestinations:[]}};assert(!verifyAiWorkloadSecurity(p));assert(!verifyAiWorkloadSecurity({...p,modelMounts:['m.safetensors'],egress:{defaultDeny:false,metadataBlocked:true,allowedDestinations:[]}}));
console.log("PASS: Deny unsafe mounts and network policy");
}
{
assert(!verifyAiWorkloadSecurity(null));const p={modelMounts:['m.safetensors'],digest:'sha256:'+'a'.repeat(64),allowedSigner:'team',verification:{trustedSource:false,verified:true},runtimeClassName:'gvisor',privileged:false,egress:{defaultDeny:true,metadataBlocked:true,allowedDestinations:['169.254.169.254']}};assert(!verifyAiWorkloadSecurity(p));
console.log("PASS: Reject unverified and metadata access");
}
