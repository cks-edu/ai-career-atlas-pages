# Agent/MCP egress policy & metadata protection

Code-executing agents and MCP tools must reach only approved destinations. Default-deny networking and explicit egress controls help limit data exfiltration and metadata credential access. A domain allowlist needs DNS and resolved-address controls; substring matching is not enough.

The combined admission fixture rejects pickle mounts, mismatched signature evidence, missing gVisor intent and any policy allowing metadata access. It requires declared default-deny egress and an exact destination allowlist excluding 169.254.169.254. These are a policy envelope, not a NetworkPolicy API.

Task: Implement verifyAiWorkloadSecurity. Test each independent rejection separately and design a native default-deny egress verification record without using real credentials.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Agent/tool request → admission evidence → runtime → enforced egress.
State: Model mounts, trusted digest verification, runtime and destination policy.
Boundary: A prompt-level prohibition cannot block a network socket.
Failure: Untrusted code reaches cloud metadata and steals credentials.
Control: Deny unsafe mounts and metadata; enforce reviewed runtime and default-deny egress.
Observability: Test blocked metadata IP, IPv6/alternate paths and denied destination logs.
Blast radius: All services reachable with any stolen workload identity.
Trade-off: Narrow egress reduces capability and needs managed update workflows.

Limit: NetworkPolicy enforcement depends on the CNI and has implementation limits around host traffic, IP translation and other paths. The fixture cannot prove a live network block or cryptographic signature; test enforcement and trusted evidence separately.

Sources:
https://kubernetes.io/docs/concepts/services-networking/network-policies/
https://docs.sigstore.dev/cosign/verifying/verify/
https://gvisor.dev/docs/architecture_guide/security/
