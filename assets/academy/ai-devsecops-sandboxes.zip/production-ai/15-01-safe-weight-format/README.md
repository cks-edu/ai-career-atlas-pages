# SafeTensors & unsafe deserialization boundaries

Pickle can reconstruct executable Python objects during loading. A tensor-only format such as SafeTensors reduces that deserialization attack surface. A file suffix, model card or public download count does not establish trusted provenance.

The fixture accepts only a trusted inventory report declaring a tensor-only format and matching .safetensors artifact path. It rejects pickle and ambiguous .bin paths under this lab policy. The inventory report is supplied by a trusted scanner in a native workflow, not by model output.

Task: Implement tensorFormatAllowed without opening or deserializing unsafe fixtures. Draw the difference between filename, format, signature and model behavior.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Approved artifact inventory → format policy → restricted tensor loader.
State: Format report and exact artifact path.
Boundary: Downloading weights is separate from executing loader code.
Failure: A public pickle model executes a payload in a credentialed process.
Control: Deny executable formats and review the loader and provenance.
Observability: Retain scanner, digest, loader version and rejected-artifact results.
Blast radius: Credentials and network resources reachable from the loading process.
Trade-off: Restricting formats narrows compatibility while reducing one execution path.

Limit: SafeTensors does not certify model behavior, tokenizer code or surrounding loaders. Do not load untrusted serialized objects to discover whether they are safe; isolate analysis and verify actual format and provenance.

Sources:
https://huggingface.co/docs/safetensors/index
https://docs.sigstore.dev/cosign/verifying/verify/
