function tensorFormatAllowed(p) {
  return !!p && p.inventoryTrusted===true && p.format==='safetensors' && typeof p.path==='string' && p.path.endsWith('.safetensors');
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(tensorFormatAllowed({inventoryTrusted:true,format:'safetensors',path:'model.safetensors'}));
console.log("PASS: Accept an approved tensor inventory");
}
{
assert(!tensorFormatAllowed({inventoryTrusted:true,format:'pickle',path:'model.pkl'}));assert(!tensorFormatAllowed({inventoryTrusted:true,format:'safetensors',path:'model.bin'}));
console.log("PASS: Deny unsafe or ambiguous paths");
}
{
assert(!tensorFormatAllowed({inventoryTrusted:false,format:'safetensors',path:'model.safetensors'}));assert(!tensorFormatAllowed(null));
console.log("PASS: Reject untrusted assertions");
}
