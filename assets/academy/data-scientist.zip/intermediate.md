## intermediate — Missingness and selection

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, Python or R, probability and clear communication of uncertainty.

### Missingness and selection
Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct.
Mental model: A survey of people inside a store misses everyone who chose not to enter.
Boundary: Filling missing values does not recover unobserved experiences.
Worked example: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI feature experiment and decision dashboard
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Recall: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. Identify one observation that would contradict your claim.

### Terms
Missingness and selection: Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The forecasting protocol flags any training window containing observations from its future evaluation interval. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact.
Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.
Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.
Deliverables: Analysis SQL and reproducible dataset generator; Experiment plan and dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Data scientist / decision scientist. Use this scenario: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Review: Start with the task and permitted scope. Explain missingness and selection: Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct. Show the input and observed output, then address Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Analysis SQL and reproducible dataset generator; Experiment plan and dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

