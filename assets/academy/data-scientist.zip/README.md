# Data scientist / decision scientist

AI Engineering · Beginner → Intermediate → Advanced

Start with Decision framing. Start with the decision a person needs to make. A model score is useful only if it helps evaluate that decision. Then try Frame a stock-planning decision. The three levels build toward AI feature experiment and decision dashboard. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Decision framing

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Decision framing
Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns.
Mental model: A map is useful only when you know the destination.
Boundary: An interesting correlation may not support the proposed action.
Worked example: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A forecast judged on familiar dates
The forecasting protocol flags any training window containing observations from its future evaluation interval. Three splits include future data and invalidate the out-of-time evaluation claim. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild rolling time splits and fit transformations on training windows only.
Recall: Recompute errors by horizon against a seasonal-naive baseline. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Decision framing: Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Start with the decision a person needs to make. A model score is useful only if it helps evaluate that decision.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine a library deciding how many copies of a book to buy. Write the decision and the date by which it must be made.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A decision brief linking data, baseline, errors and action.

3. Try step 2
List data available before that date, a simple baseline such as last month’s loans, and the cost of buying too many or too few.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A decision brief linking data, baseline, errors and action.

4. Try step 3
Define one measure of usefulness and one reason the past might not predict next month.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A decision brief linking data, baseline, errors and action.

5. Explain and check your result
No future borrowing data is used to make today’s choice, and both kinds of wrong decision are described. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A decision brief linking data, baseline, errors and action. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The forecasting protocol flags any training window containing observations from its future evaluation interval. Apply this toy-case rule manually: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three splits include future data and invalidate the out-of-time evaluation claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Data scientist / decision scientist.
Imagine a library deciding how many copies of a book to buy. Write the decision and the date by which it must be made.
List data available before that date, a simple baseline such as last month’s loans, and the cost of buying too many or too few.
Define one measure of usefulness and one reason the past might not predict next month.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A decision brief linking data, baseline, errors and action. Include beginner-worksheet.md and your completed Rolling-validation notebook report.
Check: No future borrowing data is used to make today’s choice, and both kinds of wrong decision are described.

### Interview
Explain your beginner solution for Data scientist / decision scientist. Use this scenario: The forecasting protocol flags any training window containing observations from its future evaluation interval.
Review: Start with the task and permitted scope. Explain decision framing: Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns. Show the input and observed output, then address Rebuild rolling time splits and fit transformations on training windows only. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A decision brief linking data, baseline, errors and action. Include beginner-worksheet.md and your completed Rolling-validation notebook report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Missingness and selection

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, Python or R, probability and clear communication of uncertainty.

### Missingness and selection
Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct.
Mental model: A survey of people inside a store misses everyone who chose not to enter.
Boundary: Filling missing values does not recover unobserved experiences.
Worked example: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI feature experiment and decision dashboard
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Recall: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. Identify one observation that would contradict your claim.

### Terms
Missingness and selection: Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The forecasting protocol flags any training window containing observations from its future evaluation interval. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact.
Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.
Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.
Deliverables: Analysis SQL and reproducible dataset generator; Experiment plan and dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Data scientist / decision scientist. Use this scenario: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Review: Start with the task and permitted scope. Explain missingness and selection: Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct. Show the input and observed output, then address Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Analysis SQL and reproducible dataset generator; Experiment plan and dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Uncertainty and causal claims

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Uncertainty and causal claims
Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change.
Mental model: Two umbrellas seen together may both be responding to rain.
Boundary: A more complex model does not automatically remove confounding.
Worked example: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI feature experiment and decision dashboard
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. Create a Calc dashboard with sample sizes, effect estimate, uncertainty and adverse outcomes. Write a ship/iterate/stop recommendation based on the declared decision rule.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Recall: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. Identify one observation that would contradict your claim.

### Terms
Uncertainty and causal claims: Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create a Calc dashboard with sample sizes, effect estimate, uncertainty and adverse outcomes. Write a ship/iterate/stop recommendation based on the declared decision rule.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact.
Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.
Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Create a Calc dashboard with sample sizes, effect estimate, uncertainty and adverse outcomes. Write a ship/iterate/stop recommendation based on the declared decision rule.
Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.
Run a consented usability pilot and keep its descriptive evidence separate from randomized causal estimates.
Deliverables: Analysis SQL and reproducible dataset generator; Experiment plan and dashboard; Decision memo with validity threats. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.

### Interview
Explain your advanced solution for Data scientist / decision scientist. Use this scenario: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Review: Start with the task and permitted scope. Explain uncertainty and causal claims: Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change. Show the input and observed output, then address Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Analysis SQL and reproducible dataset generator; Experiment plan and dashboard; Decision memo with validity threats. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
DuckDB — Open source · local
CSV ingestion, SQL transforms and reproducible analysis.
Alternative: SQLite (public domain) for embedded transactional SQL or PostgreSQL (open source) for a shared service.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
DuckDB: https://duckdb.org/docs/stable/clients/python/overview
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Google ML Crash Course: https://developers.google.com/machine-learning/crash-course
scikit-learn: https://scikit-learn.org/stable/user_guide.html
PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
