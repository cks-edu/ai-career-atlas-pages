# SAMPLE — Rolling-validation notebook report
Role: Data scientist / decision scientist
Case: A forecast judged on familiar dates
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The forecasting protocol flags any training window containing observations from its future evaluation interval.

## Evidence table
| Record | future_rows (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 5 | review |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three splits include future data and invalidate the out-of-time evaluation claim.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Rebuild rolling time splits and fit transformations on training windows only.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in data scientist / decision scientist.
Before release: Recompute errors by horizon against a seasonal-naive baseline.

## Design choice and trade-off
Align split boundaries with the decision time; preserve uncertainty in business recommendations.
Longer training windows add data but may blur regime changes; evaluate on the periods that match deployment.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Demand forecasting report: Publish forecast errors by horizon and actionable limitations.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
