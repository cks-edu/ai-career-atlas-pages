## advanced — Uncertainty and causal claims

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Uncertainty and causal claims
Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change.
Mental model: Two umbrellas seen together may both be responding to rain.
Boundary: A more complex model does not automatically remove confounding.
Worked example: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI feature experiment and decision dashboard
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. Create a Calc dashboard with sample sizes, effect estimate, uncertainty and adverse outcomes. Write a ship/iterate/stop recommendation based on the declared decision rule.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.
Worked example: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Recall: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. Identify one observation that would contradict your claim.

### Terms
Uncertainty and causal claims: Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

2. Prepare the project inputs
Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create a Calc dashboard with sample sizes, effect estimate, uncertainty and adverse outcomes. Write a ship/iterate/stop recommendation based on the declared decision rule.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing CSV: run from the extracted folder.
Conflicting IDs: inspect raw records instead of dropping an arbitrary row.
Wrong totals: check units, duplicate joins and whether failures are included.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

### Portfolio
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact.
Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.
Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.
Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.
Create a Calc dashboard with sample sizes, effect estimate, uncertainty and adverse outcomes. Write a ship/iterate/stop recommendation based on the declared decision rule.
Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.
Run a consented usability pilot and keep its descriptive evidence separate from randomized causal estimates.
Deliverables: Analysis SQL and reproducible dataset generator; Experiment plan and dashboard; Decision memo with validity threats. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.

### Interview
Explain your advanced solution for Data scientist / decision scientist. Use this scenario: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.
Review: Start with the task and permitted scope. Explain uncertainty and causal claims: Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change. Show the input and observed output, then address Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Analysis SQL and reproducible dataset generator; Experiment plan and dashboard; Decision memo with validity threats. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

