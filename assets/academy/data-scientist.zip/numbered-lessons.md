# Data scientist / decision scientist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Decision framing: Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

### Decision framing

Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns. In this role, work through: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A map is useful only when you know the destination.

Boundary: An interesting correlation may not support the proposed action.

Worked example: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Data scientist / decision scientist: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts.

Predict the worked case

Read this case without running a tool: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in decision framing.

Connect the concept to the role

Apply this rule: Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An interesting correlation may not support the proposed action.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies decision framing to this case: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Decision framing; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with decision framing. Use the glossary below, then write your prediction for: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data scientist / decision scientist role interview. Explain decision framing using this case: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate decision framing to a system or workflow you know. Explain decision framing using this case: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain decision framing using this case: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts.

Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns. — Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns. An interesting correlation may not support the proposed action.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

### Diagnose: A forecast judged on familiar dates

The forecasting protocol flags any training window containing observations from its future evaluation interval. Three splits include future data and invalidate the out-of-time evaluation claim. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild rolling time splits and fit transformations on training windows only. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A map is useful only when you know the destination.

Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts.

Worked example: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild rolling time splits and fit transformations on training windows only.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); LibreOffice Calc (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The forecasting protocol flags any training window containing observations from its future evaluation interval. Three splits include future data and invalidate the out-of-time evaluation claim. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The forecasting protocol flags any training window containing observations from its future evaluation interval. Apply this toy-case rule manually: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Start with the decision a person needs to make. A model score is useful only if it helps evaluate that decision.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine a library deciding how many copies of a book to buy. Write the decision and the date by which it must be made.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A decision brief linking data, baseline, errors and action.

Preparation · Try step 2

List data available before that date, a simple baseline such as last month’s loans, and the cost of buying too many or too few.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A decision brief linking data, baseline, errors and action.

Preparation · Try step 3

Define one measure of usefulness and one reason the past might not predict next month.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A decision brief linking data, baseline, errors and action.

Preparation · Explain and check your result

No future borrowing data is used to make today’s choice, and both kinds of wrong decision are described. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A decision brief linking data, baseline, errors and action. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The forecasting protocol flags any training window containing observations from its future evaluation interval. Apply this toy-case rule manually: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three splits include future data and invalidate the out-of-time evaluation claim. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three splits include future data and invalidate the out-of-time evaluation claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a forecast judged on familiar dates. Use the glossary below, then write your prediction for: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild rolling time splits and fit transformations on training windows only. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data scientist / decision scientist role interview. Explain diagnose: a forecast judged on familiar dates using this case: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild rolling time splits and fit transformations on training windows only. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a forecast judged on familiar dates to a system or workflow you know. Explain diagnose: a forecast judged on familiar dates using this case: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild rolling time splits and fit transformations on training windows only. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Recompute errors by horizon against a seasonal-naive baseline. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a forecast judged on familiar dates using this case: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild rolling time splits and fit transformations on training windows only. State the evidence, one alternative and where the mental model stops.

Quiz: A forecast judged on familiar dates: The forecasting protocol flags any training window containing observations from its future evaluation interval.

Change the acceptance rule after seeing an inconvenient result.

Rebuild rolling time splits and fit transformations on training windows only.

Omit failed cases and report only the successful demonstrations.

Reference: Rebuild rolling time splits and fit transformations on training windows only. — Rebuild rolling time splits and fit transformations on training windows only. Recompute errors by horizon against a seasonal-naive baseline.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, Python or R, probability and clear communication of uncertainty.

Terms:

Missingness and selection: Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Missingness and selection

Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct. In this role, work through: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A survey of people inside a store misses everyone who chose not to enter.

Boundary: Filling missing values does not recover unobserved experiences.

Worked example: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: SQL, Python or R, probability and clear communication of uncertainty.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Data scientist / decision scientist: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction.

Predict the worked case

Read this case without running a tool: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in missingness and selection.

Connect the concept to the role

Apply this rule: Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Filling missing values does not recover unobserved experiences.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies missingness and selection to this case: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Missingness and selection; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with missingness and selection. Use the glossary below, then write your prediction for: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data scientist / decision scientist role interview. Explain missingness and selection using this case: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate missingness and selection to a system or workflow you know. Explain missingness and selection using this case: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain missingness and selection using this case: A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction.

Treat a passing starter as proof of the whole role workflow.

Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct.

Ignore the failure because the tool produced an output.

Reference: Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct. — Inspect who appears in the dataset and which fields or outcomes are absent. Missing records can bias a conclusion even when every visible row is correct. Filling missing values does not recover unobserved experiences.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

### Integrate: AI feature experiment and decision dashboard

Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices. In this role, work through: Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: A survey of people inside a store misses everyone who chose not to enter.

A satisfaction dataset excludes abandoned sessions; report that exclusion before describing overall satisfaction.

Worked example: Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); LibreOffice Calc (Open source · no account needed)

Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The forecasting protocol flags any training window containing observations from its future evaluation interval. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-intermediate-2.md: Analysis SQL and reproducible dataset generator; Experiment plan and dashboard. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: ai feature experiment and decision dashboard. Use the glossary below, then write your prediction for: Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data scientist / decision scientist role interview. Explain integrate: ai feature experiment and decision dashboard using this case: Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: ai feature experiment and decision dashboard to a system or workflow you know. Explain integrate: ai feature experiment and decision dashboard using this case: Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. Identify one observation that would contradict your claim.

Interview: Explain integrate: ai feature experiment and decision dashboard using this case: Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI feature experiment and decision dashboard at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.

Reference: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. — Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Uncertainty and causal claims: Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Uncertainty and causal claims

Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change. In this role, work through: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Two umbrellas seen together may both be responding to rain.

Boundary: A more complex model does not automatically remove confounding.

Worked example: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); LibreOffice Calc (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Data scientist / decision scientist: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison.

Predict the worked case

Read this case without running a tool: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in uncertainty and causal claims.

Connect the concept to the role

Apply this rule: Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A more complex model does not automatically remove confounding.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies uncertainty and causal claims to this case: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Uncertainty and causal claims; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with uncertainty and causal claims. Use the glossary below, then write your prediction for: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data scientist / decision scientist role interview. Explain uncertainty and causal claims using this case: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate uncertainty and causal claims to a system or workflow you know. Explain uncertainty and causal claims using this case: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain uncertainty and causal claims using this case: Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change.

Reference: Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change. — Report sample sizes, variability and plausible confounding. Observational association does not establish that an intervention caused a change. A more complex model does not automatically remove confounding.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html

### Defend: AI feature experiment and decision dashboard

Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. Create a Calc dashboard with sample sizes, effect estimate, uncertainty and adverse outcomes. Write a ship/iterate/stop recommendation based on the declared decision rule. In this role, work through: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Role application: Two umbrellas seen together may both be responding to rain.

Ticket resolution improves after a model launch while staffing also increases. Describe the association and propose a stronger comparison.

Worked example: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.

Setup: Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: DuckDB (Open source · local); scikit-learn (Open source · CPU); LibreOffice Calc (Open source · no account needed)

Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact. DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below. Runs on a laptop. Large corpora and external billing exports are optional; no live data or cloud account is included.

Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and DuckDB. The included usage table demonstrates ingestion mechanics; replace it with the project-specific schema at milestone 2. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python pipeline.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: DuckDB CSV ingestion, exact duplicate removal, conflicting-ID rejection and tenant aggregation. You create the domain tables, metrics and workflow described below.

Prepare the project inputs

Create or simulate randomized assignment for 400 fictional sessions with treatment, task success, completion time and missing outcomes. Label all simulated results.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Use DuckDB to validate one assignment per session and test for duplicate/missing records. Define primary metric and guardrails before looking at outcomes.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build an intent-to-treat comparison and a confidence interval using a documented method. Segment only on pre-treatment attributes and label exploratory slices.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Create a Calc dashboard with sample sizes, effect estimate, uncertainty and adverse outcomes. Write a ship/iterate/stop recommendation based on the declared decision rule.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The database is in memory. Keep output/summary.json as baseline evidence and deactivate the environment.

Deliverable: lesson-advanced-2.md: Analysis SQL and reproducible dataset generator; Experiment plan and dashboard; Decision memo with validity threats. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: ai feature experiment and decision dashboard. Use the glossary below, then write your prediction for: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Data scientist / decision scientist role interview. Explain defend: ai feature experiment and decision dashboard using this case: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: ai feature experiment and decision dashboard to a system or workflow you know. Explain defend: ai feature experiment and decision dashboard using this case: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product. Identify one observation that would contradict your claim.

Interview: Explain defend: ai feature experiment and decision dashboard using this case: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI feature experiment and decision dashboard at this level?

Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail. — Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail. Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.

Sources:

DuckDB: https://duckdb.org/docs/stable/clients/python/overview

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Google ML Crash Course: https://developers.google.com/machine-learning/crash-course

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PostgreSQL: https://www.postgresql.org/docs/current/tutorial.html
