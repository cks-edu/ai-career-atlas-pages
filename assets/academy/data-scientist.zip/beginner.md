## beginner — Decision framing

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Decision framing
Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns.
Mental model: A map is useful only when you know the destination.
Boundary: An interesting correlation may not support the proposed action.
Worked example: Analyze whether a support team should change staffing by hour; distinguish ticket arrival from resolution and repeated contacts.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A forecast judged on familiar dates
The forecasting protocol flags any training window containing observations from its future evaluation interval. Three splits include future data and invalidate the out-of-time evaluation claim. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild rolling time splits and fit transformations on training windows only.
Recall: Recompute errors by horizon against a seasonal-naive baseline. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Decision framing: Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Start with the decision a person needs to make. A model score is useful only if it helps evaluate that decision.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine a library deciding how many copies of a book to buy. Write the decision and the date by which it must be made.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A decision brief linking data, baseline, errors and action.

3. Try step 2
List data available before that date, a simple baseline such as last month’s loans, and the cost of buying too many or too few.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A decision brief linking data, baseline, errors and action.

4. Try step 3
Define one measure of usefulness and one reason the past might not predict next month.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A decision brief linking data, baseline, errors and action.

5. Explain and check your result
No future borrowing data is used to make today’s choice, and both kinds of wrong decision are described. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A decision brief linking data, baseline, errors and action. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The forecasting protocol flags any training window containing observations from its future evaluation interval. Apply this toy-case rule manually: Review when future_rows >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three splits include future data and invalidate the out-of-time evaluation claim. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Data scientist / decision scientist.
Imagine a library deciding how many copies of a book to buy. Write the decision and the date by which it must be made.
List data available before that date, a simple baseline such as last month’s loans, and the cost of buying too many or too few.
Define one measure of usefulness and one reason the past might not predict next month.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A decision brief linking data, baseline, errors and action. Include beginner-worksheet.md and your completed Rolling-validation notebook report.
Check: No future borrowing data is used to make today’s choice, and both kinds of wrong decision are described.

### Interview
Explain your beginner solution for Data scientist / decision scientist. Use this scenario: The forecasting protocol flags any training window containing observations from its future evaluation interval.
Review: Start with the task and permitted scope. Explain decision framing: Specify who will act on an analysis and what choice it informs. Define the unit of analysis and outcome before exploring many patterns. Show the input and observed output, then address Rebuild rolling time splits and fit transformations on training windows only. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A decision brief linking data, baseline, errors and action. Include beginner-worksheet.md and your completed Rolling-validation notebook report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

