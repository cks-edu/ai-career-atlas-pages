# Decision memo with validity threats

Project: AI feature experiment and decision dashboard
Status: blank work product — not completed evidence

## Purpose and audience
Analyze whether a fictional AI feature improves a defined outcome without confusing usage with impact.

## Required content
Create a Calc dashboard with sample sizes, effect estimate, uncertainty and adverse outcomes. Write a ship/iterate/stop recommendation based on the declared decision rule.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report assignment balance, missingness, effect size and interval. Simulated data cannot demonstrate real customer benefit or causal impact in a live product.

## Failure evidence
Introduce unequal missingness and a sample-ratio mismatch. Show how the recommendation changes when the experiment’s assumptions fail.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
