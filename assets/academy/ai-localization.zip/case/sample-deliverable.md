# SAMPLE — Bilingual evaluation sheet and terminology guide
Role: AI localization / language specialist
Case: Fluency hides a changed meaning
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The localization brief treats any mistranslated critical instruction as a release blocker.

## Evidence table
| Record | critical_meaning_errors (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 1 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three fluent outputs alter a consequential instruction, so fluency scoring alone is insufficient.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Revise terminology and examples with qualified language reviewers; preserve disputed items for adjudication.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai localization / language specialist.
Before release: Use unseen local tasks and report meaning, register and cultural-fit errors separately.

## Design choice and trade-off
Use locally grounded examples and a calibrated rubric; record dialect scope and reviewer disagreement.
A literal translation can preserve words while losing task intent; context and audience determine acceptability.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Bilingual assistant evaluation: Publish terminology, error categories and sample limitations.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
