## beginner — Locale and audience requirements

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Locale and audience requirements
Localization adapts meaning, formats and conventions for a defined audience. Record locale, tone, terminology and accessibility needs instead of treating language names as complete specifications.
Mental model: The same recipe needs different units and familiar ingredients for different kitchens.
Boundary: One fluent speaker cannot represent all regional or cultural contexts.
Worked example: A date such as 04/05 is ambiguous; define the locale and use an unambiguous display in the sample.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Fluency hides a changed meaning
The localization brief treats any mistranslated critical instruction as a release blocker. Three fluent outputs alter a consequential instruction, so fluency scoring alone is insufficient. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when critical_meaning_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise terminology and examples with qualified language reviewers; preserve disputed items for adjudication.
Recall: Use unseen local tasks and report meaning, register and cultural-fit errors separately. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Locale and audience requirements: Localization adapts meaning, formats and conventions for a defined audience. Record locale, tone, terminology and accessibility needs instead of treating language names as complete specifications.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Localization adapts meaning, tone and context for a particular audience. A correct literal translation may still be confusing in use.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use “Your request timed out. Please try again.” Choose a language and audience you know well, or work within your strongest language.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two message versions and a short editorial rationale.

3. Try step 2
Rewrite it in a suitable tone, explain any technical term and give a clear next action.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two message versions and a short editorial rationale.

4. Try step 3
Compare with a literal version and note choices that need a fluent local reviewer.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two message versions and a short editorial rationale.

5. Explain and check your result
The action and meaning remain accurate; you label language or cultural questions outside your expertise. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Two message versions and a short editorial rationale. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The localization brief treats any mistranslated critical instruction as a release blocker. Apply this toy-case rule manually: Review when critical_meaning_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three fluent outputs alter a consequential instruction, so fluency scoring alone is insufficient. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI localization / language specialist.
Use “Your request timed out. Please try again.” Choose a language and audience you know well, or work within your strongest language.
Rewrite it in a suitable tone, explain any technical term and give a clear next action.
Compare with a literal version and note choices that need a fluent local reviewer.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Two message versions and a short editorial rationale. Include beginner-worksheet.md and your completed Bilingual evaluation sheet and terminology guide.
Check: The action and meaning remain accurate; you label language or cultural questions outside your expertise.

### Interview
Explain your beginner solution for AI localization / language specialist. Use this scenario: The localization brief treats any mistranslated critical instruction as a release blocker.
Review: Start with the task and permitted scope. Explain locale and audience requirements: Localization adapts meaning, formats and conventions for a defined audience. Record locale, tone, terminology and accessibility needs instead of treating language names as complete specifications. Show the input and observed output, then address Revise terminology and examples with qualified language reviewers; preserve disputed items for adjudication. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Two message versions and a short editorial rationale. Include beginner-worksheet.md and your completed Bilingual evaluation sheet and terminology guide.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

