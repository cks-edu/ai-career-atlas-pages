# Multilingual AI release quality pack

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Evaluate and improve localized AI content with a reproducible severity rubric.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Include a fluent translation that reverses a negation and another that changes a date or unit. These must block release regardless of overall fluency.

## Limitations and next iteration
Add a speech or right-to-left interface variant and test layout/context effects separately.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
