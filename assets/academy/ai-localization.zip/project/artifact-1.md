# Glossary/style guide and annotated corpus

Project: Multilingual AI release quality pack
Status: blank work product — not completed evidence

## Purpose and audience
Evaluate and improve localized AI content with a reproducible severity rubric.

## Required content
Import tasks into Label Studio or Calc using stable source IDs. Write a glossary, style guide and severity definitions with examples.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone.

## Failure evidence
Include a fluent translation that reverses a negation and another that changes a date or unit. These must block release regardless of overall fluency.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
