# Language-quality report and release recommendation

Project: Multilingual AI release quality pack
Status: blank work product — not completed evidence

## Purpose and audience
Evaluate and improve localized AI content with a reproducible severity rubric.

## Required content
Produce corrected translations and a release checklist. Link each correction to an error type, source meaning and reviewer rationale.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone.

## Failure evidence
Include a fluent translation that reverses a negation and another that changes a date or unit. These must block release regardless of overall fluency.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
