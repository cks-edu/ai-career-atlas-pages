# AI localization / language specialist

AI Engineering · Beginner → Intermediate → Advanced

Start with Locale and audience requirements. Localization adapts meaning, tone and context for a particular audience. A correct literal translation may still be confusing in use. Then try Adapt an assistant message. The three levels build toward Multilingual AI release quality pack. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Locale and audience requirements

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Locale and audience requirements
Localization adapts meaning, formats and conventions for a defined audience. Record locale, tone, terminology and accessibility needs instead of treating language names as complete specifications.
Mental model: The same recipe needs different units and familiar ingredients for different kitchens.
Boundary: One fluent speaker cannot represent all regional or cultural contexts.
Worked example: A date such as 04/05 is ambiguous; define the locale and use an unambiguous display in the sample.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Fluency hides a changed meaning
The localization brief treats any mistranslated critical instruction as a release blocker. Three fluent outputs alter a consequential instruction, so fluency scoring alone is insufficient. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when critical_meaning_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Revise terminology and examples with qualified language reviewers; preserve disputed items for adjudication.
Recall: Use unseen local tasks and report meaning, register and cultural-fit errors separately. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Locale and audience requirements: Localization adapts meaning, formats and conventions for a defined audience. Record locale, tone, terminology and accessibility needs instead of treating language names as complete specifications.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Localization adapts meaning, tone and context for a particular audience. A correct literal translation may still be confusing in use.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use “Your request timed out. Please try again.” Choose a language and audience you know well, or work within your strongest language.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two message versions and a short editorial rationale.

3. Try step 2
Rewrite it in a suitable tone, explain any technical term and give a clear next action.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two message versions and a short editorial rationale.

4. Try step 3
Compare with a literal version and note choices that need a fluent local reviewer.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two message versions and a short editorial rationale.

5. Explain and check your result
The action and meaning remain accurate; you label language or cultural questions outside your expertise. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Two message versions and a short editorial rationale. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The localization brief treats any mistranslated critical instruction as a release blocker. Apply this toy-case rule manually: Review when critical_meaning_errors >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three fluent outputs alter a consequential instruction, so fluency scoring alone is insufficient. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI localization / language specialist.
Use “Your request timed out. Please try again.” Choose a language and audience you know well, or work within your strongest language.
Rewrite it in a suitable tone, explain any technical term and give a clear next action.
Compare with a literal version and note choices that need a fluent local reviewer.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Two message versions and a short editorial rationale. Include beginner-worksheet.md and your completed Bilingual evaluation sheet and terminology guide.
Check: The action and meaning remain accurate; you label language or cultural questions outside your expertise.

### Interview
Explain your beginner solution for AI localization / language specialist. Use this scenario: The localization brief treats any mistranslated critical instruction as a release blocker.
Review: Start with the task and permitted scope. Explain locale and audience requirements: Localization adapts meaning, formats and conventions for a defined audience. Record locale, tone, terminology and accessibility needs instead of treating language names as complete specifications. Show the input and observed output, then address Revise terminology and examples with qualified language reviewers; preserve disputed items for adjudication. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Two message versions and a short editorial rationale. Include beginner-worksheet.md and your completed Bilingual evaluation sheet and terminology guide.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Error rubrics and severity

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong target-language and cultural competence, editorial judgment and rubric-based review.

### Error rubrics and severity
Classify translation errors by type and impact using agreed examples. Separate awkward style from changed meaning or unsafe instructions.
Mental model: A proofreader marks a cosmetic typo differently from a wrong medicine amount.
Boundary: Severity depends on the product and should be agreed with qualified reviewers.
Worked example: A button translated as delete instead of save is a critical meaning error; record source text, target text and rationale.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Multilingual AI release quality pack
Evaluate and improve localized AI content with a reproducible severity rubric. Blind candidate identity and have two qualified reviewers score an overlap set independently. Keep original labels, disagreements and adjudicated outcomes.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Create 30 source strings and candidate translations for two languages you or qualified collaborators can review. Include numbers, negation, terminology and cultural context.
Recall: Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone. Identify one observation that would contradict your claim.

### Terms
Error rubrics and severity: Classify translation errors by type and impact using agreed examples. Separate awkward style from changed meaning or unsafe instructions.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Evaluate and improve localized AI content with a reproducible severity rubric. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Create 30 source strings and candidate translations for two languages you or qualified collaborators can review. Include numbers, negation, terminology and cultural context.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Import tasks into Label Studio or Calc using stable source IDs. Write a glossary, style guide and severity definitions with examples.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Blind candidate identity and have two qualified reviewers score an overlap set independently. Keep original labels, disagreements and adjudicated outcomes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The localization brief treats any mistranslated critical instruction as a release blocker. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Evaluate and improve localized AI content with a reproducible severity rubric.
Create 30 source strings and candidate translations for two languages you or qualified collaborators can review. Include numbers, negation, terminology and cultural context.
Import tasks into Label Studio or Calc using stable source IDs. Write a glossary, style guide and severity definitions with examples.
Blind candidate identity and have two qualified reviewers score an overlap set independently. Keep original labels, disagreements and adjudicated outcomes.
Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone.
Deliverables: Glossary/style guide and annotated corpus; Adjudication log and corrected release set. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI localization / language specialist. Use this scenario: Include a fluent translation that reverses a negation and another that changes a date or unit. These must block release regardless of overall fluency.
Review: Start with the task and permitted scope. Explain error rubrics and severity: Classify translation errors by type and impact using agreed examples. Separate awkward style from changed meaning or unsafe instructions. Show the input and observed output, then address Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Glossary/style guide and annotated corpus; Adjudication log and corrected release set. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Linguistic evaluation operations

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Linguistic evaluation operations
Sample by locale and task, calibrate reviewers and preserve disagreements. Track revision decisions and retest terminology across related screens.
Mental model: An editorial team uses a shared style guide but keeps an escalation desk for disputes.
Boundary: Automated scores and back-translation cannot replace competent target-language review.
Worked example: Two reviewers disagree about formality; consult the audience brief, record the decision and update the glossary.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Multilingual AI release quality pack
Evaluate and improve localized AI content with a reproducible severity rubric. Produce corrected translations and a release checklist. Link each correction to an error type, source meaning and reviewer rationale.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Include a fluent translation that reverses a negation and another that changes a date or unit. These must block release regardless of overall fluency.
Recall: Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone. Identify one observation that would contradict your claim.

### Terms
Linguistic evaluation operations: Sample by locale and task, calibrate reviewers and preserve disagreements. Track revision decisions and retest terminology across related screens.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
adjudication: A documented resolution of reviewer disagreement, usually by a qualified reviewer.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Evaluate and improve localized AI content with a reproducible severity rubric. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. Label Studio import JSON and labeling XML are included; adapt labels to your rubric.

2. Prepare the project inputs
Create 30 source strings and candidate translations for two languages you or qualified collaborators can review. Include numbers, negation, terminology and cultural context.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Import tasks into Label Studio or Calc using stable source IDs. Write a glossary, style guide and severity definitions with examples.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Blind candidate identity and have two qualified reviewers score an overlap set independently. Keep original labels, disagreements and adjudicated outcomes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Produce corrected translations and a release checklist. Link each correction to an error type, source meaning and reviewer rationale.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Include a fluent translation that reverses a negation and another that changes a date or unit. These must block release regardless of overall fluency.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# Optional Label Studio route; spreadsheet route remains available.
python3 -m venv .venv
source .venv/bin/activate
python -m pip install label-studio
label-studio start --host http://localhost:8080 --port 8080
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Evaluate and improve localized AI content with a reproducible severity rubric.
Create 30 source strings and candidate translations for two languages you or qualified collaborators can review. Include numbers, negation, terminology and cultural context.
Import tasks into Label Studio or Calc using stable source IDs. Write a glossary, style guide and severity definitions with examples.
Blind candidate identity and have two qualified reviewers score an overlap set independently. Keep original labels, disagreements and adjudicated outcomes.
Produce corrected translations and a release checklist. Link each correction to an error type, source meaning and reviewer rationale.
Include a fluent translation that reverses a negation and another that changes a date or unit. These must block release regardless of overall fluency.
Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone.
Add a speech or right-to-left interface variant and test layout/context effects separately.
Deliverables: Glossary/style guide and annotated corpus; Adjudication log and corrected release set; Language-quality report and release recommendation. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone. A reviewer must reproduce one result and identify which capabilities you implemented. Include a fluent translation that reverses a negation and another that changes a date or unit. These must block release regardless of overall fluency.

### Interview
Explain your advanced solution for AI localization / language specialist. Use this scenario: Include a fluent translation that reverses a negation and another that changes a date or unit. These must block release regardless of overall fluency.
Review: Start with the task and permitted scope. Explain linguistic evaluation operations: Sample by locale and task, calibrate reviewers and preserve disagreements. Track revision decisions and retest terminology across related screens. Show the input and observed output, then address Report critical errors per segment, terminology consistency and reviewer agreement by language. Machine translation quality claims require language competence, not back-translation alone. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Glossary/style guide and annotated corpus; Adjudication log and corrected release set; Language-quality report and release recommendation. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Label Studio — Open source Community · commercial editions optional
Configure annotation tasks and export reviewer judgments.
Alternative: A reviewed CSV workbook for small batches, or a commercial annotation platform; access, adjudication and export matter more than brand.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Writer / Impress — Open source · no account needed
Edit reports, workshop decks and export PDF deliverables.
Alternative: Microsoft Word/PowerPoint (commercial) or Google Docs/Slides (hosted); retain editable and accessible exports.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Label Studio: https://labelstud.io/guide/quick_start
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/
Label Studio: https://labelstud.io/guide/
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
Hugging Face Audio Course: https://huggingface.co/learn/audio-course/chapter0/introduction
