# AI adoption / enablement specialist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Readiness and barriers: Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Readiness and barriers

Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit. In this role, work through: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Buying bicycles does not mean everyone can ride or has a safe route.

Boundary: A survey of confidence is not a direct skill assessment.

Worked example: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed); Penpot (Open source · hosted account or self-hosting)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI adoption / enablement specialist: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions.

Predict the worked case

Read this case without running a tool: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in readiness and barriers.

Connect the concept to the role

Apply this rule: Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A survey of confidence is not a direct skill assessment.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies readiness and barriers to this case: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Readiness and barriers; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with readiness and barriers. Use the glossary below, then write your prediction for: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI adoption / enablement specialist role interview. Explain readiness and barriers using this case: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate readiness and barriers to a system or workflow you know. Explain readiness and barriers using this case: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain readiness and barriers using this case: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions.

Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit. — Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit. A survey of confidence is not a direct skill assessment.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

### Diagnose: Attendance is mistaken for capability

The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Two cohorts need follow-up despite attending the training; attendance did not establish verification skill. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Add task-specific verification exercises and coaching before broadening independent use. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Buying bicycles does not mean everyone can ride or has a safe route.

A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions.

Worked example: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Add task-specific verification exercises and coaching before broadening independent use.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed); Penpot (Open source · hosted account or self-hosting)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Two cohorts need follow-up despite attending the training; attendance did not establish verification skill. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Apply this toy-case rule manually: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Interest in AI is not the same as readiness to use it. Choose one useful task and find out what prevents people from doing it well.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine a school office considering an assistant for drafting routine announcements.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An interview script and a one-task training plan.

Preparation · Try step 2

Write five questions about current work, errors, sensitive information, review responsibility and staff confidence.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An interview script and a one-task training plan.

Preparation · Try step 3

Draft a small training exercise using fictional information, with a human review step and a way to check whether staff learned it.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An interview script and a one-task training plan.

Preparation · Explain and check your result

Success describes a reviewed, accurate announcement rather than just tool sign-ups; interview answers are not fabricated. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: An interview script and a one-task training plan. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Apply this toy-case rule manually: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two cohorts need follow-up despite attending the training; attendance did not establish verification skill. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two cohorts need follow-up despite attending the training; attendance did not establish verification skill. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: attendance is mistaken for capability. Use the glossary below, then write your prediction for: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Add task-specific verification exercises and coaching before broadening independent use. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI adoption / enablement specialist role interview. Explain diagnose: attendance is mistaken for capability using this case: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Add task-specific verification exercises and coaching before broadening independent use. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: attendance is mistaken for capability to a system or workflow you know. Explain diagnose: attendance is mistaken for capability using this case: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Add task-specific verification exercises and coaching before broadening independent use. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Repeat a new task with seeded errors and record reasoning, not copied answers. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: attendance is mistaken for capability using this case: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Add task-specific verification exercises and coaching before broadening independent use. State the evidence, one alternative and where the mental model stops.

Quiz: Attendance is mistaken for capability: The workshop gate flags more than two participants in ten unable to verify a seeded AI error.

Change the acceptance rule after seeing an inconvenient result.

Add task-specific verification exercises and coaching before broadening independent use.

Omit failed cases and report only the successful demonstrations.

Reference: Add task-specific verification exercises and coaching before broadening independent use. — Add task-specific verification exercises and coaching before broadening independent use. Repeat a new task with seeded errors and record reasoning, not copied answers.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Facilitation, workflow understanding, clear communication and basic AI risk literacy.

Terms:

Practice-based enablement: Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Practice-based enablement

Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used. In this role, work through: Learners draft a summary, check it against the original and mark unsupported statements before sharing it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A swimming lesson includes supervised practice, not only a lecture about water.

Boundary: Completion of a workshop does not prove sustained workplace performance.

Worked example: Learners draft a summary, check it against the original and mark unsupported statements before sharing it.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Facilitation, workflow understanding, clear communication and basic AI risk literacy.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed); Penpot (Open source · hosted account or self-hosting)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI adoption / enablement specialist: Learners draft a summary, check it against the original and mark unsupported statements before sharing it.

Predict the worked case

Read this case without running a tool: Learners draft a summary, check it against the original and mark unsupported statements before sharing it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in practice-based enablement.

Connect the concept to the role

Apply this rule: Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Completion of a workshop does not prove sustained workplace performance.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies practice-based enablement to this case: Learners draft a summary, check it against the original and mark unsupported statements before sharing it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Learners draft a summary, check it against the original and mark unsupported statements before sharing it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Practice-based enablement; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with practice-based enablement. Use the glossary below, then write your prediction for: Learners draft a summary, check it against the original and mark unsupported statements before sharing it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI adoption / enablement specialist role interview. Explain practice-based enablement using this case: Learners draft a summary, check it against the original and mark unsupported statements before sharing it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate practice-based enablement to a system or workflow you know. Explain practice-based enablement using this case: Learners draft a summary, check it against the original and mark unsupported statements before sharing it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain practice-based enablement using this case: Learners draft a summary, check it against the original and mark unsupported statements before sharing it. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Learners draft a summary, check it against the original and mark unsupported statements before sharing it.

Treat a passing starter as proof of the whole role workflow.

Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used.

Ignore the failure because the tool produced an output.

Reference: Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used. — Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used. Completion of a workshop does not prove sustained workplace performance.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

### Integrate: Role-based AI enablement pilot

Design and test an enablement programme that measures task competence rather than attendance. Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities. In this role, work through: Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A swimming lesson includes supervised practice, not only a lecture about water.

Learners draft a summary, check it against the original and mark unsupported statements before sharing it.

Worked example: Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed); Penpot (Open source · hosted account or self-hosting)

Design and test an enablement programme that measures task competence rather than attendance. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design and test an enablement programme that measures task competence rather than attendance.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: role-based ai enablement pilot. Use the glossary below, then write your prediction for: Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI adoption / enablement specialist role interview. Explain integrate: role-based ai enablement pilot using this case: Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: role-based ai enablement pilot to a system or workflow you know. Explain integrate: role-based ai enablement pilot using this case: Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. Identify one observation that would contradict your claim.

Interview: Explain integrate: role-based ai enablement pilot using this case: Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Role-based AI enablement pilot at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.

Reference: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. — Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Adoption outcome measurement: Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Adoption outcome measurement

Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable. In this role, work through: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Count successful journeys and repairs, not just how often the bicycle leaves the shed.

Boundary: Participation and self-reported confidence can be affected by selection bias.

Worked example: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed); Penpot (Open source · hosted account or self-hosting)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI adoption / enablement specialist: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful.

Predict the worked case

Read this case without running a tool: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in adoption outcome measurement.

Connect the concept to the role

Apply this rule: Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Participation and self-reported confidence can be affected by selection bias.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies adoption outcome measurement to this case: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Adoption outcome measurement; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with adoption outcome measurement. Use the glossary below, then write your prediction for: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI adoption / enablement specialist role interview. Explain adoption outcome measurement using this case: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate adoption outcome measurement to a system or workflow you know. Explain adoption outcome measurement using this case: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain adoption outcome measurement using this case: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable.

Reference: Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable. — Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable. Participation and self-reported confidence can be affected by selection bias.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

### Defend: Role-based AI enablement pilot

Design and test an enablement programme that measures task competence rather than attendance. Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support. In this role, work through: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: Count successful journeys and repairs, not just how often the bicycle leaves the shed.

Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful.

Worked example: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Writer / Impress (Open source · no account needed); LibreOffice Calc (Open source · no account needed); Penpot (Open source · hosted account or self-hosting)

Design and test an enablement programme that measures task competence rather than attendance. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Design and test an enablement programme that measures task competence rather than attendance.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A reviewer must reproduce one result and identify which capabilities you implemented. A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results; Adoption plan with support and follow-up measures. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: role-based ai enablement pilot. Use the glossary below, then write your prediction for: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI adoption / enablement specialist role interview. Explain defend: role-based ai enablement pilot using this case: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: role-based ai enablement pilot to a system or workflow you know. Explain defend: role-based ai enablement pilot using this case: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. Identify one observation that would contradict your claim.

Interview: Explain defend: role-based ai enablement pilot using this case: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Role-based AI enablement pilot at this level?

A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed. — A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed. Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.

Sources:

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/
