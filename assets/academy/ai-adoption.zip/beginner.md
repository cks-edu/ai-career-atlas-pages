## beginner — Readiness and barriers

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Readiness and barriers
Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit.
Mental model: Buying bicycles does not mean everyone can ride or has a safe route.
Boundary: A survey of confidence is not a direct skill assessment.
Worked example: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Attendance is mistaken for capability
The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Two cohorts need follow-up despite attending the training; attendance did not establish verification skill. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Add task-specific verification exercises and coaching before broadening independent use.
Recall: Repeat a new task with seeded errors and record reasoning, not copied answers. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Readiness and barriers: Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Interest in AI is not the same as readiness to use it. Choose one useful task and find out what prevents people from doing it well.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine a school office considering an assistant for drafting routine announcements.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An interview script and a one-task training plan.

3. Try step 2
Write five questions about current work, errors, sensitive information, review responsibility and staff confidence.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An interview script and a one-task training plan.

4. Try step 3
Draft a small training exercise using fictional information, with a human review step and a way to check whether staff learned it.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An interview script and a one-task training plan.

5. Explain and check your result
Success describes a reviewed, accurate announcement rather than just tool sign-ups; interview answers are not fabricated. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An interview script and a one-task training plan. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Apply this toy-case rule manually: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two cohorts need follow-up despite attending the training; attendance did not establish verification skill. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI adoption / enablement specialist.
Imagine a school office considering an assistant for drafting routine announcements.
Write five questions about current work, errors, sensitive information, review responsibility and staff confidence.
Draft a small training exercise using fictional information, with a human review step and a way to check whether staff learned it.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An interview script and a one-task training plan. Include beginner-worksheet.md and your completed Enablement plan and learning assessment.
Check: Success describes a reviewed, accurate announcement rather than just tool sign-ups; interview answers are not fabricated.

### Interview
Explain your beginner solution for AI adoption / enablement specialist. Use this scenario: The workshop gate flags more than two participants in ten unable to verify a seeded AI error.
Review: Start with the task and permitted scope. Explain readiness and barriers: Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit. Show the input and observed output, then address Add task-specific verification exercises and coaching before broadening independent use. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An interview script and a one-task training plan. Include beginner-worksheet.md and your completed Enablement plan and learning assessment.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

