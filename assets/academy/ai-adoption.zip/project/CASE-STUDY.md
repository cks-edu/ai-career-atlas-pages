# Role-based AI enablement pilot

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Design and test an enablement programme that measures task competence rather than attendance.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

## Limitations and next iteration
Repeat the assessment after a delay using new cases to test retention rather than memorization.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
