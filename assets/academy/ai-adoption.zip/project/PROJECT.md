# Role-based AI enablement pilot

Career: AI adoption / enablement specialist
Reviewed: 2026-10-22

Design and test an enablement programme that measures task competence rather than attendance.

## Prerequisites
Facilitation, workflow understanding, clear communication and basic AI risk literacy.

## Included starter versus your implementation
Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Facilitator deck and learner workbook — artifact-1.md
2. Baseline/post-task rubric and anonymized results — artifact-2.md
3. Adoption plan with support and follow-up measures — artifact-3.md

## Troubleshooting
- CSV appears in one column: select comma as the separator during import.
- Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
- No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.

## Extension
Repeat the assessment after a delay using new cases to test retention rather than memorization.

## Primary learning resources
- LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/ — Open source · no account needed; Edit reports, workshop decks and export PDF deliverables.
- LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html — Open source · no account needed; Import CSV evidence, build review registers and calculate summaries.
- Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/ — Open source · hosted account or self-hosting; Connect prototype boards and test interaction flows; Figma is an alternative.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
