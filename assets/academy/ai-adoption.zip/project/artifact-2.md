# Baseline/post-task rubric and anonymized results

Project: Role-based AI enablement pilot
Status: blank work product — not completed evidence

## Purpose and audience
Design and test an enablement programme that measures task competence rather than attendance.

## Required content
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.

## Failure evidence
A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
