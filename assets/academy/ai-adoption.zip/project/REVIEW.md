# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Facilitator deck and learner workbook.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
