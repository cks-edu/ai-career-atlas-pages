# Adoption plan with support and follow-up measures

Project: Role-based AI enablement pilot
Status: blank work product — not completed evidence

## Purpose and audience
Design and test an enablement programme that measures task competence rather than attendance.

## Required content
Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.

## Failure evidence
A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
