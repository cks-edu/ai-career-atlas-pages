# AI adoption / enablement specialist

AI Engineering · Beginner → Intermediate → Advanced

Start with Readiness and barriers. Interest in AI is not the same as readiness to use it. Choose one useful task and find out what prevents people from doing it well. Then try Plan a mock readiness conversation. The three levels build toward Role-based AI enablement pilot. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Readiness and barriers

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Readiness and barriers
Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit.
Mental model: Buying bicycles does not mean everyone can ride or has a safe route.
Boundary: A survey of confidence is not a direct skill assessment.
Worked example: A team has assistant access but cannot use customer data; design a synthetic practice task and an escalation route for data questions.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Attendance is mistaken for capability
The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Two cohorts need follow-up despite attending the training; attendance did not establish verification skill. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Add task-specific verification exercises and coaching before broadening independent use.
Recall: Repeat a new task with seeded errors and record reasoning, not copied answers. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Readiness and barriers: Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Interest in AI is not the same as readiness to use it. Choose one useful task and find out what prevents people from doing it well.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine a school office considering an assistant for drafting routine announcements.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An interview script and a one-task training plan.

3. Try step 2
Write five questions about current work, errors, sensitive information, review responsibility and staff confidence.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An interview script and a one-task training plan.

4. Try step 3
Draft a small training exercise using fictional information, with a human review step and a way to check whether staff learned it.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An interview script and a one-task training plan.

5. Explain and check your result
Success describes a reviewed, accurate announcement rather than just tool sign-ups; interview answers are not fabricated. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An interview script and a one-task training plan. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Apply this toy-case rule manually: Review when missed_seeded_errors >= 3 (out of ten learners). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two cohorts need follow-up despite attending the training; attendance did not establish verification skill. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI adoption / enablement specialist.
Imagine a school office considering an assistant for drafting routine announcements.
Write five questions about current work, errors, sensitive information, review responsibility and staff confidence.
Draft a small training exercise using fictional information, with a human review step and a way to check whether staff learned it.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An interview script and a one-task training plan. Include beginner-worksheet.md and your completed Enablement plan and learning assessment.
Check: Success describes a reviewed, accurate announcement rather than just tool sign-ups; interview answers are not fabricated.

### Interview
Explain your beginner solution for AI adoption / enablement specialist. Use this scenario: The workshop gate flags more than two participants in ten unable to verify a seeded AI error.
Review: Start with the task and permitted scope. Explain readiness and barriers: Assess the tasks, skills, access and concerns of each learner group. Do not assume a licensed tool automatically creates a useful habit. Show the input and observed output, then address Add task-specific verification exercises and coaching before broadening independent use. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An interview script and a one-task training plan. Include beginner-worksheet.md and your completed Enablement plan and learning assessment.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Practice-based enablement

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Facilitation, workflow understanding, clear communication and basic AI risk literacy.

### Practice-based enablement
Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used.
Mental model: A swimming lesson includes supervised practice, not only a lecture about water.
Boundary: Completion of a workshop does not prove sustained workplace performance.
Worked example: Learners draft a summary, check it against the original and mark unsupported statements before sharing it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Role-based AI enablement pilot
Design and test an enablement programme that measures task competence rather than attendance. Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Recall: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. Identify one observation that would contradict your claim.

### Terms
Practice-based enablement: Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and test an enablement programme that measures task competence rather than attendance. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and test an enablement programme that measures task competence rather than attendance.
Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.
Deliverables: Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI adoption / enablement specialist. Use this scenario: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Review: Start with the task and permitted scope. Explain practice-based enablement: Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used. Show the input and observed output, then address Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Adoption outcome measurement

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Adoption outcome measurement
Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable.
Mental model: Count successful journeys and repairs, not just how often the bicycle leaves the shed.
Boundary: Participation and self-reported confidence can be affected by selection bias.
Worked example: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Role-based AI enablement pilot
Design and test an enablement programme that measures task competence rather than attendance. Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Recall: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. Identify one observation that would contradict your claim.

### Terms
Adoption outcome measurement: Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and test an enablement programme that measures task competence rather than attendance. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and test an enablement programme that measures task competence rather than attendance.
Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support.
A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.
Repeat the assessment after a delay using new cases to test retention rather than memorization.
Deliverables: Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results; Adoption plan with support and follow-up measures. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A reviewer must reproduce one result and identify which capabilities you implemented. A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

### Interview
Explain your advanced solution for AI adoption / enablement specialist. Use this scenario: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Review: Start with the task and permitted scope. Explain adoption outcome measurement: Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable. Show the input and observed output, then address Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results; Adoption plan with support and follow-up measures. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
LibreOffice Writer / Impress — Open source · no account needed
Edit reports, workshop decks and export PDF deliverables.
Alternative: Microsoft Word/PowerPoint (commercial) or Google Docs/Slides (hosted); retain editable and accessible exports.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Penpot — Open source · hosted account or self-hosting
Connect prototype boards and test interaction flows; Figma is an alternative.
Alternative: Figma (commercial hosted service with plan-specific access); paper prototypes are sufficient for the first exercise.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
Google Technical Writing: https://developers.google.com/tech-writing
Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/
