## intermediate — Practice-based enablement

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Facilitation, workflow understanding, clear communication and basic AI risk literacy.

### Practice-based enablement
Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used.
Mental model: A swimming lesson includes supervised practice, not only a lecture about water.
Boundary: Completion of a workshop does not prove sustained workplace performance.
Worked example: Learners draft a summary, check it against the original and mark unsupported statements before sharing it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Role-based AI enablement pilot
Design and test an enablement programme that measures task competence rather than attendance. Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Recall: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. Identify one observation that would contradict your claim.

### Terms
Practice-based enablement: Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and test an enablement programme that measures task competence rather than attendance. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The workshop gate flags more than two participants in ten unable to verify a seeded AI error. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and test an enablement programme that measures task competence rather than attendance.
Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.
Deliverables: Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI adoption / enablement specialist. Use this scenario: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Review: Start with the task and permitted scope. Explain practice-based enablement: Teach a bounded task, show a worked example, let people attempt it and review their evidence. Include verification and situations where the tool should not be used. Show the input and observed output, then address Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

