# SAMPLE — Enablement plan and learning assessment
Role: AI adoption / enablement specialist
Case: Attendance is mistaken for capability
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The workshop gate flags more than two participants in ten unable to verify a seeded AI error.

## Evidence table
| Record | missed_seeded_errors (out of ten learners) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 6 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two cohorts need follow-up despite attending the training; attendance did not establish verification skill.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Add task-specific verification exercises and coaching before broadening independent use.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai adoption / enablement specialist.
Before release: Repeat a new task with seeded errors and record reasoning, not copied answers.

## Design choice and trade-off
Teach role-specific workflows and escalation; measure task competence after training.
A short workshop can build awareness, but sustained adoption requires practice, support and measurable outcomes.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Role-based AI workshop: Assessment measures task competence rather than tool enthusiasm.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
