## advanced — Adoption outcome measurement

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Adoption outcome measurement
Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable.
Mental model: Count successful journeys and repairs, not just how often the bicycle leaves the shed.
Boundary: Participation and self-reported confidence can be affected by selection bias.
Worked example: Usage doubles but review time increases; revise training or the task selection before declaring the rollout successful.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Role-based AI enablement pilot
Design and test an enablement programme that measures task competence rather than attendance. Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Recall: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. Identify one observation that would contradict your claim.

### Terms
Adoption outcome measurement: Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Design and test an enablement programme that measures task competence rather than attendance. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Design and test an enablement programme that measures task competence rather than attendance.
Choose a fictional operations team and three tasks: summarization, drafting and verification. Define permitted data and create deliberately flawed AI outputs for practice.
Write a baseline assessment with task instructions, scoring anchors and critical errors. Run it with consenting peers or document a solo rehearsal as simulated.
Create a 45-minute workshop in Impress with demonstrations, guided practice, failure examples and escalation guidance. Adapt examples to the team’s actual responsibilities.
Run a post-workshop task using new examples. Collect difficulties and revise the materials; create a manager checklist for reinforcement and support.
A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence.
Repeat the assessment after a delay using new cases to test retention rather than memorization.
Deliverables: Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results; Adoption plan with support and follow-up measures. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A reviewer must reproduce one result and identify which capabilities you implemented. A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.

### Interview
Explain your advanced solution for AI adoption / enablement specialist. Use this scenario: A learner produces a polished answer containing a seeded factual error. Require verification evidence and revise training if the error is repeatedly missed.
Review: Start with the task and permitted scope. Explain adoption outcome measurement: Track task quality and time alongside usage and support burden. Segment results by role and investigate whether the workflow is sustainable. Show the input and observed output, then address Report task-level improvement, critical-error detection and unresolved barriers. Attendance, satisfaction and tool logins are not substitutes for competence. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Facilitator deck and learner workbook; Baseline/post-task rubric and anonymized results; Adoption plan with support and follow-up measures. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

