# Sample coverage and scaling report

Project: Distributed training reproducibility study
Status: blank work product — not completed evidence

## Purpose and audience
Compare single-process and distributed training while preserving sample coverage and recovery semantics.

## Required content
Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments.

## Failure evidence
Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
