## beginner — Data and model parallelism

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Data and model parallelism
Data parallelism trains copies on different batches and combines gradients; model parallelism splits model computation. Choose based on memory and communication constraints.
Mental model: Several cooks make portions of one recipe, or divide the recipe's stages between stations.
Boundary: More devices do not guarantee faster training when communication dominates.
Worked example: Two workers each process half a batch, then synchronize gradients before updating compatible model copies.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: One worker determines the step
The toy training run flags worker step times above 120 ms under a fixed workload. Two workers exceed the step bound; synchronized training waits for slow participants. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when step_time > 120 (milliseconds). This is a declared toy-case contract, not an industry standard. Compare data loading and collective timing per worker before changing parallelism.
Recall: Rerun identical data and batch settings and compare step distribution and convergence. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Data and model parallelism: Data parallelism trains copies on different batches and combines gradients; model parallelism splits model computation. Choose based on memory and communication constraints.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Data parallelism copies the model and divides examples between workers. Workers must combine learning updates; extra workers do not remove all communication costs.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Draw two workers, each with the same fictional model. Number eight training examples from 1 to 8.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two annotated diagrams and a short comparison.

3. Try step 2
Assign four different examples to each worker and mark where their updates must be combined.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two annotated diagrams and a short comparison.

4. Try step 3
Compare this with dividing the model itself across workers; write what is copied versus split.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two annotated diagrams and a short comparison.

5. Explain and check your result
Data parallelism has a complete model copy on each worker; you identify the need to combine updates. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Two annotated diagrams and a short comparison. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The toy training run flags worker step times above 120 ms under a fixed workload. Apply this toy-case rule manually: Review when step_time > 120 (milliseconds). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two workers exceed the step bound; synchronized training waits for slow participants. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Distributed-training engineer.
Draw two workers, each with the same fictional model. Number eight training examples from 1 to 8.
Assign four different examples to each worker and mark where their updates must be combined.
Compare this with dividing the model itself across workers; write what is copied versus split.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Two annotated diagrams and a short comparison. Include beginner-worksheet.md and your completed Scaling efficiency and straggler report.
Check: Data parallelism has a complete model copy on each worker; you identify the need to combine updates.

### Interview
Explain your beginner solution for Distributed-training engineer. Use this scenario: The toy training run flags worker step times above 120 ms under a fixed workload.
Review: Start with the task and permitted scope. Explain data and model parallelism: Data parallelism trains copies on different batches and combines gradients; model parallelism splits model computation. Choose based on memory and communication constraints. Show the input and observed output, then address Compare data loading and collective timing per worker before changing parallelism. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Two annotated diagrams and a short comparison. Include beginner-worksheet.md and your completed Scaling efficiency and straggler report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

