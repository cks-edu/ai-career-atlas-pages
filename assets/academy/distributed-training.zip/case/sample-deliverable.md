# SAMPLE — Scaling efficiency and straggler report
Role: Distributed-training engineer
Case: One worker determines the step
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The toy training run flags worker step times above 120 ms under a fixed workload.

## Evidence table
| Record | step_time (milliseconds) | Decision |
|---|---:|---|
| case-1 | 90 | within_demo_bound |
| case-2 | 120 | within_demo_bound |
| case-3 | 121 | review |
| case-4 | 220 | review |
| case-5 | 95 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two workers exceed the step bound; synchronized training waits for slow participants.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Compare data loading and collective timing per worker before changing parallelism.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in distributed-training engineer.
Before release: Rerun identical data and batch settings and compare step distribution and convergence.

## Design choice and trade-off
Separate compute, input and communication timing; preserve optimizer and random state on restart.
Adding workers can increase synchronization cost; report useful speedup under comparable training conditions.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Restartable training job: Report lost work, recovery time and numerical differences.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
