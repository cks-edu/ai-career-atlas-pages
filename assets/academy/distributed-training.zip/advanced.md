## advanced — Checkpoint recovery state

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Checkpoint recovery state
A usable training checkpoint includes the state needed to resume the intended experiment, including optimizer and progress information. Validate recovery with a deliberate interruption.
Mental model: A game save needs inventory and position, not only a screenshot.
Boundary: Different hardware or nondeterministic operations may prevent bitwise-identical recovery.
Worked example: Restart from a checkpoint and compare subsequent loss and data position with a declared reproducibility tolerance.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Distributed training reproducibility study
Compare single-process and distributed training while preserving sample coverage and recovery semantics. Save model, optimizer, scheduler, epoch and RNG state at checkpoint boundaries. Resume a stopped run and compare with an uninterrupted baseline at the same effective batch size.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Recall: Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. Identify one observation that would contradict your claim.

### Terms
Checkpoint recovery state: A usable training checkpoint includes the state needed to resume the intended experiment, including optimizer and progress information. Validate recovery with a deliberate interruption.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Compare single-process and distributed training while preserving sample coverage and recovery semantics. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py to establish the environment. Implement train_ddp.py using DistributedDataParallel, init_process_group and a DistributedSampler with set_epoch each epoch.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Save model, optimizer, scheduler, epoch and RNG state at checkpoint boundaries. Resume a stopped run and compare with an uninterrupted baseline at the same effective batch size.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Compare single-process and distributed training while preserving sample coverage and recovery semantics.
Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Run tensor_probe.py to establish the environment. Implement train_ddp.py using DistributedDataParallel, init_process_group and a DistributedSampler with set_epoch each epoch.
Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Save model, optimizer, scheduler, epoch and RNG state at checkpoint boundaries. Resume a stopped run and compare with an uninterrupted baseline at the same effective batch size.
Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments.
Introduce gradient accumulation and analyze communication versus compute bottlenecks with a profiler.
Deliverables: Distributed trainer and launch configuration; Sample coverage and scaling report; Checkpoint recovery demonstration. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. A reviewer must reproduce one result and identify which capabilities you implemented. Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.

### Interview
Explain your advanced solution for Distributed-training engineer. Use this scenario: Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Review: Start with the task and permitted scope. Explain checkpoint recovery state: A usable training checkpoint includes the state needed to resume the intended experiment, including optimizer and progress information. Validate recovery with a deliberate interruption. Show the input and observed output, then address Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Distributed trainer and launch configuration; Sample coverage and scaling report; Checkpoint recovery demonstration. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

