# Distributed-training engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Data and model parallelism. Data parallelism copies the model and divides examples between workers. Workers must combine learning updates; extra workers do not remove all communication costs. Then try Split a tiny training batch. The three levels build toward Distributed training reproducibility study. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Data and model parallelism

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Data and model parallelism
Data parallelism trains copies on different batches and combines gradients; model parallelism splits model computation. Choose based on memory and communication constraints.
Mental model: Several cooks make portions of one recipe, or divide the recipe's stages between stations.
Boundary: More devices do not guarantee faster training when communication dominates.
Worked example: Two workers each process half a batch, then synchronize gradients before updating compatible model copies.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: One worker determines the step
The toy training run flags worker step times above 120 ms under a fixed workload. Two workers exceed the step bound; synchronized training waits for slow participants. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when step_time > 120 (milliseconds). This is a declared toy-case contract, not an industry standard. Compare data loading and collective timing per worker before changing parallelism.
Recall: Rerun identical data and batch settings and compare step distribution and convergence. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Data and model parallelism: Data parallelism trains copies on different batches and combines gradients; model parallelism splits model computation. Choose based on memory and communication constraints.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Data parallelism copies the model and divides examples between workers. Workers must combine learning updates; extra workers do not remove all communication costs.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Draw two workers, each with the same fictional model. Number eight training examples from 1 to 8.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two annotated diagrams and a short comparison.

3. Try step 2
Assign four different examples to each worker and mark where their updates must be combined.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two annotated diagrams and a short comparison.

4. Try step 3
Compare this with dividing the model itself across workers; write what is copied versus split.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Two annotated diagrams and a short comparison.

5. Explain and check your result
Data parallelism has a complete model copy on each worker; you identify the need to combine updates. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Two annotated diagrams and a short comparison. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The toy training run flags worker step times above 120 ms under a fixed workload. Apply this toy-case rule manually: Review when step_time > 120 (milliseconds). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two workers exceed the step bound; synchronized training waits for slow participants. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Distributed-training engineer.
Draw two workers, each with the same fictional model. Number eight training examples from 1 to 8.
Assign four different examples to each worker and mark where their updates must be combined.
Compare this with dividing the model itself across workers; write what is copied versus split.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Two annotated diagrams and a short comparison. Include beginner-worksheet.md and your completed Scaling efficiency and straggler report.
Check: Data parallelism has a complete model copy on each worker; you identify the need to combine updates.

### Interview
Explain your beginner solution for Distributed-training engineer. Use this scenario: The toy training run flags worker step times above 120 ms under a fixed workload.
Review: Start with the task and permitted scope. Explain data and model parallelism: Data parallelism trains copies on different batches and combines gradients; model parallelism splits model computation. Choose based on memory and communication constraints. Show the input and observed output, then address Compare data loading and collective timing per worker before changing parallelism. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Two annotated diagrams and a short comparison. Include beginner-worksheet.md and your completed Scaling efficiency and straggler report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Collective coordination

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong Linux/networking, PyTorch training and GPU fundamentals; large-scale roles usually require prior systems experience.

### Collective coordination
Collective operations require participants to call compatible operations in a consistent order. A mismatch can leave workers waiting rather than producing a clear local error.
Mental model: Every musician must reach the same bar before the conductor continues.
Boundary: A single-process CPU probe cannot validate multi-node networking.
Worked example: One rank skips backward after an input error while another enters a collective; inspect per-rank logs and fail the job coherently.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Distributed training reproducibility study
Compare single-process and distributed training while preserving sample coverage and recovery semantics. Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Recall: Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. Identify one observation that would contradict your claim.

### Terms
Collective coordination: Collective operations require participants to call compatible operations in a consistent order. A mismatch can leave workers waiting rather than producing a clear local error.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Compare single-process and distributed training while preserving sample coverage and recovery semantics. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py to establish the environment. Implement train_ddp.py using DistributedDataParallel, init_process_group and a DistributedSampler with set_epoch each epoch.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The toy training run flags worker step times above 120 ms under a fixed workload. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Compare single-process and distributed training while preserving sample coverage and recovery semantics.
Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Run tensor_probe.py to establish the environment. Implement train_ddp.py using DistributedDataParallel, init_process_group and a DistributedSampler with set_epoch each epoch.
Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments.
Deliverables: Distributed trainer and launch configuration; Sample coverage and scaling report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Distributed-training engineer. Use this scenario: Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Review: Start with the task and permitted scope. Explain collective coordination: Collective operations require participants to call compatible operations in a consistent order. A mismatch can leave workers waiting rather than producing a clear local error. Show the input and observed output, then address Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Distributed trainer and launch configuration; Sample coverage and scaling report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Checkpoint recovery state

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Checkpoint recovery state
A usable training checkpoint includes the state needed to resume the intended experiment, including optimizer and progress information. Validate recovery with a deliberate interruption.
Mental model: A game save needs inventory and position, not only a screenshot.
Boundary: Different hardware or nondeterministic operations may prevent bitwise-identical recovery.
Worked example: Restart from a checkpoint and compare subsequent loss and data position with a declared reproducibility tolerance.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Distributed training reproducibility study
Compare single-process and distributed training while preserving sample coverage and recovery semantics. Save model, optimizer, scheduler, epoch and RNG state at checkpoint boundaries. Resume a stopped run and compare with an uninterrupted baseline at the same effective batch size.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Recall: Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. Identify one observation that would contradict your claim.

### Terms
Checkpoint recovery state: A usable training checkpoint includes the state needed to resume the intended experiment, including optimizer and progress information. Validate recovery with a deliberate interruption.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Compare single-process and distributed training while preserving sample coverage and recovery semantics. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py to establish the environment. Implement train_ddp.py using DistributedDataParallel, init_process_group and a DistributedSampler with set_epoch each epoch.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Save model, optimizer, scheduler, epoch and RNG state at checkpoint boundaries. Resume a stopped run and compare with an uninterrupted baseline at the same effective batch size.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Compare single-process and distributed training while preserving sample coverage and recovery semantics.
Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Run tensor_probe.py to establish the environment. Implement train_ddp.py using DistributedDataParallel, init_process_group and a DistributedSampler with set_epoch each epoch.
Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Save model, optimizer, scheduler, epoch and RNG state at checkpoint boundaries. Resume a stopped run and compare with an uninterrupted baseline at the same effective batch size.
Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments.
Introduce gradient accumulation and analyze communication versus compute bottlenecks with a profiler.
Deliverables: Distributed trainer and launch configuration; Sample coverage and scaling report; Checkpoint recovery demonstration. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. A reviewer must reproduce one result and identify which capabilities you implemented. Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.

### Interview
Explain your advanced solution for Distributed-training engineer. Use this scenario: Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Review: Start with the task and permitted scope. Explain checkpoint recovery state: A usable training checkpoint includes the state needed to resume the intended experiment, including optimizer and progress information. Validate recovery with a deliberate interruption. Show the input and observed output, then address Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Distributed trainer and launch configuration; Sample coverage and scaling report; Checkpoint recovery demonstration. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Ray — Open source · managed service optional
Distributed workload orchestration extension.
Alternative: PyTorch distributed primitives (open source) for a narrower training task; compare scheduling and operational complexity.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
Ray: https://docs.ray.io/en/latest/
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
NVIDIA CUDA Programming Guide: https://docs.nvidia.com/cuda/cuda-programming-guide/index.html
Ray: https://docs.ray.io/en/latest/
