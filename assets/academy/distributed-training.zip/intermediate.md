## intermediate — Collective coordination

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Strong Linux/networking, PyTorch training and GPU fundamentals; large-scale roles usually require prior systems experience.

### Collective coordination
Collective operations require participants to call compatible operations in a consistent order. A mismatch can leave workers waiting rather than producing a clear local error.
Mental model: Every musician must reach the same bar before the conductor continues.
Boundary: A single-process CPU probe cannot validate multi-node networking.
Worked example: One rank skips backward after an input error while another enters a collective; inspect per-rank logs and fail the job coherently.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Distributed training reproducibility study
Compare single-process and distributed training while preserving sample coverage and recovery semantics. Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Recall: Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. Identify one observation that would contradict your claim.

### Terms
Collective coordination: Collective operations require participants to call compatible operations in a consistent order. A mismatch can leave workers waiting rather than producing a clear local error.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Compare single-process and distributed training while preserving sample coverage and recovery semantics. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run tensor_probe.py to establish the environment. Implement train_ddp.py using DistributedDataParallel, init_process_group and a DistributedSampler with set_epoch each epoch.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The toy training run flags worker step times above 120 ms under a fixed workload. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Compare single-process and distributed training while preserving sample coverage and recovery semantics.
Use a small deterministic synthetic dataset and a CPU distributed smoke test first. Multi-GPU measurements require supported hardware and a recorded interconnect configuration.
Run tensor_probe.py to establish the environment. Implement train_ddp.py using DistributedDataParallel, init_process_group and a DistributedSampler with set_epoch each epoch.
Launch with torchrun --standalone --nproc-per-node=2 train_ddp.py using a compatible backend; use gloo for CPU and follow the PyTorch guide for GPU NCCL. Count unique sample IDs per epoch.
Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments.
Deliverables: Distributed trainer and launch configuration; Sample coverage and scaling report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Distributed-training engineer. Use this scenario: Terminate one worker in a disposable run. Capture the launcher error, restart from the last complete checkpoint and check for omitted or duplicated training steps.
Review: Start with the task and permitted scope. Explain collective coordination: Collective operations require participants to call compatible operations in a consistent order. A mismatch can leave workers waiting rather than producing a clear local error. Show the input and observed output, then address Report scaling efficiency, time per step, validation variance and checkpoint recovery difference. Do not compare different effective batch sizes as if they were identical experiments. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Distributed trainer and launch configuration; Sample coverage and scaling report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

