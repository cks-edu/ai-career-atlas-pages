# Mainframe / COBOL Developer

Software Engineering

Start with batch jobs and return codes. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward batch restart runbook and reconciliation table.

## beginner

Use IBM Z Xplore's provided learning environment and job exercises. Record dataset names, step order and return codes; keep an offline input/output contract with synthetic records.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Boundaries and ownership
A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.
Mental model: Departments own different ledgers and exchange agreed forms.
Limit: Drawing more boxes does not make a system more reliable.
Example: The order service owns orders; a notification consumer handles messages.
Recall: Which component owns the truth about whether an order exists?

### Batch jobs and return codes
A batch job declares ordered work, input/output datasets and execution requirements. A step completing is not enough; inspect return codes and the resulting business records.
Mental model: A factory batch has a work order, materials and an inspection result for each station.
Limit: Do not treat every nonzero return code identically; interpret it using the program/job contract.
Example: A file-processing job should distinguish no input, valid input and invalid records.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not treat every nonzero return code identically; interpret it using the program/job contract.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A file-processing job should distinguish no input, valid input and invalid records. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use IBM Z Xplore's provided learning environment and job exercises. Record dataset names, step order and return codes; keep an offline input/output contract with synthetic records.
Expected: A traceable job flow and evidence from the authorized lab.

6. Role workshop · debug and verify
Do not treat every nonzero return code identically; interpret it using the program/job contract. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save batch job worksheet and lab transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A traceable job flow and evidence from the authorized lab.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Batch jobs and return codes: Do not treat every nonzero return code identically; interpret it using the program/job contract.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: batch job worksheet and lab transcript
A traceable job flow and evidence from the authorized lab.

Interview: Work through this Mainframe / COBOL Developer case: A file-processing job should distinguish no input, valid input and invalid records. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A batch job declares ordered work, input/output datasets and execution requirements. A step completing is not enough; inspect return codes and the resulting business records. Expected evidence: A traceable job flow and evidence from the authorized lab. Diagnosis: Do not treat every nonzero return code identically; interpret it using the program/job contract. State the limits of the mental model: A factory batch has a work order, materials and an inspection result for each station.

Resume: Built batch job worksheet and lab transcript using IBM Z, COBOL, JCL and Db2; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create three synthetic fixed-width records and a field-position map. Parse them locally or in the IBM exercise, test a short record and a nonnumeric amount, and preserve rejection reasons.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transactional outbox
Write business data and the event to publish in one local transaction, then deliver the event separately.
Mental model: Record a sale and its mailing slip in the same ledger before dispatch.
Limit: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.
Example: The reference stores order-1 and its pending event together.
Recall: Why can publishing first lose consistency if the database write fails?

### Record layouts and decimal data
Fixed-width records encode fields by position and format. Business decimal values need defined scale; trimming or converting casually can change meaning.
Mental model: A form with numbered boxes relies on every value occupying the correct boxes.
Limit: Off-by-one offsets can produce plausible but wrong values; verify each field boundary.
Example: An amount stored as 00012345 with scale 2 represents 123.45.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Off-by-one offsets can produce plausible but wrong values; verify each field boundary.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
An amount stored as 00012345 with scale 2 represents 123.45. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create three synthetic fixed-width records and a field-position map. Parse them locally or in the IBM exercise, test a short record and a nonnumeric amount, and preserve rejection reasons.
Expected: Correct decimal interpretation and rejected malformed records.

6. Role workshop · debug and verify
Off-by-one offsets can produce plausible but wrong values; verify each field boundary. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save record-layout specification and parsing tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Correct decimal interpretation and rejected malformed records.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Record layouts and decimal data: Off-by-one offsets can produce plausible but wrong values; verify each field boundary.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: record-layout specification and parsing tests
Correct decimal interpretation and rejected malformed records.

Interview: Work through this Mainframe / COBOL Developer case: An amount stored as 00012345 with scale 2 represents 123.45. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Fixed-width records encode fields by position and format. Business decimal values need defined scale; trimming or converting casually can change meaning. Expected evidence: Correct decimal interpretation and rejected malformed records. Diagnosis: Off-by-one offsets can produce plausible but wrong values; verify each field boundary. State the limits of the mental model: A form with numbered boxes relies on every value occupying the correct boxes.

Resume: Built record-layout specification and parsing tests using IBM Z, COBOL, JCL and Db2; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run a synthetic tabletop or provided lab with a checkpoint, compare source/output IDs and totals, and write restart instructions including cleanup of partial output.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Failure semantics
Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.
Mental model: Track a parcel even when the receipt acknowledgment is lost.
Limit: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.
Example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.
Recall: How would you recover a permanently failing event without blocking all orders?

### Restartable batch processing
A failed batch needs a checkpoint and reconciliation policy so rerun does not duplicate outputs or skip unfinished records. Dataset disposition and downstream effects matter.
Mental model: A factory restart must know which items were finished before the power failed.
Limit: Deleting partial output before recording its state can destroy recovery evidence.
Example: Failure after record 2 of 5 should resume or replay according to a documented key policy.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Deleting partial output before recording its state can destroy recovery evidence.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Failure after record 2 of 5 should resume or replay according to a documented key policy. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run a synthetic tabletop or provided lab with a checkpoint, compare source/output IDs and totals, and write restart instructions including cleanup of partial output.
Expected: All five records accounted for exactly as the chosen business policy requires.

6. Role workshop · debug and verify
Deleting partial output before recording its state can destroy recovery evidence. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save batch restart runbook and reconciliation table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: All five records accounted for exactly as the chosen business policy requires.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Restartable batch processing: Deleting partial output before recording its state can destroy recovery evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: batch restart runbook and reconciliation table
All five records accounted for exactly as the chosen business policy requires.

Interview: Work through this Mainframe / COBOL Developer case: Failure after record 2 of 5 should resume or replay according to a documented key policy. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A failed batch needs a checkpoint and reconciliation policy so rerun does not duplicate outputs or skip unfinished records. Dataset disposition and downstream effects matter. Expected evidence: All five records accounted for exactly as the chosen business policy requires. Diagnosis: Deleting partial output before recording its state can destroy recovery evidence. State the limits of the mental model: A factory restart must know which items were finished before the power failed.

Resume: Built batch restart runbook and reconciliation table using IBM Z, COBOL, JCL and Db2; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
IBM Z Xplore learning platform: https://www.ibm.com/products/z/resources/zxplore
AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html
Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/
Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
