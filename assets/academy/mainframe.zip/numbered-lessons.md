# Mainframe / COBOL Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Boundaries and ownership: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.

Apply boundaries and ownership in Mainframe / COBOL Developer: Use the concept to complete this role exercise: Complete IBM Z Xplore foundations and explain dataset versus file

Batch jobs and return codes: A batch job declares ordered work, input/output datasets and execution requirements. A step completing is not enough; inspect return codes and the resulting business records.

### Boundaries and ownership

A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. In this role, work through: A file-processing job should distinguish no input, valid input and invalid records. The practical workshop develops this into: Use IBM Z Xplore's provided learning environment and job exercises. Record dataset names, step order and return codes; keep an offline input/output contract with synthetic records.

Mental model: Departments own different ledgers and exchange agreed forms.

Boundary: Drawing more boxes does not make a system more reliable.

Role application: A factory batch has a work order, materials and an inspection result for each station.

A batch job declares ordered work, input/output datasets and execution requirements. A step completing is not enough; inspect return codes and the resulting business records.

Worked example: A file-processing job should distinguish no input, valid input and invalid records.

Shared foundation example: The order service owns orders; a notification consumer handles messages.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: IBM Z, COBOL, JCL and Db2 (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Mainframe / COBOL Developer: A file-processing job should distinguish no input, valid input and invalid records.

Predict the worked case

Read this case without running a tool: A file-processing job should distinguish no input, valid input and invalid records. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in boundaries and ownership.

Connect the concept to the role

Apply this rule: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Drawing more boxes does not make a system more reliable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies boundaries and ownership to this case: A file-processing job should distinguish no input, valid input and invalid records. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A file-processing job should distinguish no input, valid input and invalid records. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Boundaries and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with boundaries and ownership. Use the glossary below, then write your prediction for: A file-processing job should distinguish no input, valid input and invalid records. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Mainframe / COBOL Developer role interview. Explain boundaries and ownership using this case: A file-processing job should distinguish no input, valid input and invalid records. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate boundaries and ownership to a system or workflow you know. Explain boundaries and ownership using this case: A file-processing job should distinguish no input, valid input and invalid records. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which component owns the truth about whether an order exists?

Interview: Explain boundaries and ownership using this case: A file-processing job should distinguish no input, valid input and invalid records. State the evidence, one alternative and where the mental model stops.

Quiz: After the Batch jobs and return codes rehearsal, check this foundation: Two services both write one business record using incompatible rules. What should be clarified first?

The owning service and the contract through which others request changes.

Which service can issue writes faster.

Whether both services can share unrestricted credentials.

Reference: The owning service and the contract through which others request changes. — Ownership defines responsibility for invariants. Sharing write access does not resolve conflicting business rules.

Sources:

IBM Z Xplore learning platform: https://www.ibm.com/products/z/resources/zxplore

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Batch jobs and return codes

A batch job declares ordered work, input/output datasets and execution requirements. A step completing is not enough; inspect return codes and the resulting business records. In this role, work through: A file-processing job should distinguish no input, valid input and invalid records. The practical workshop develops this into: Use IBM Z Xplore's provided learning environment and job exercises. Record dataset names, step order and return codes; keep an offline input/output contract with synthetic records.

Mental model: A factory batch has a work order, materials and an inspection result for each station.

Boundary: Do not treat every nonzero return code identically; interpret it using the program/job contract.

Worked example: A file-processing job should distinguish no input, valid input and invalid records.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: IBM Z, COBOL, JCL and Db2 (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Mainframe / COBOL Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Use IBM Z Xplore's provided learning environment and job exercises. Record dataset names, step order and return codes; keep an offline input/output contract with synthetic records.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A file-processing job should distinguish no input, valid input and invalid records. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Use IBM Z Xplore's provided learning environment and job exercises. Record dataset names, step order and return codes; keep an offline input/output contract with synthetic records.

Expected: A traceable job flow and evidence from the authorized lab.

Role workshop · debug and verify

Do not treat every nonzero return code identically; interpret it using the program/job contract. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save batch job worksheet and lab transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A traceable job flow and evidence from the authorized lab.

Expected: A traceable job flow and evidence from the authorized lab.

Troubleshoot: The role exercise differs from the prediction: Do not treat every nonzero return code identically; interpret it using the program/job contract.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: batch job worksheet and lab transcript; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with batch jobs and return codes. Use the glossary below, then write your prediction for: A file-processing job should distinguish no input, valid input and invalid records. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Mainframe / COBOL Developer role interview. Explain batch jobs and return codes using this case: A file-processing job should distinguish no input, valid input and invalid records. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate batch jobs and return codes to a system or workflow you know. Explain batch jobs and return codes using this case: A file-processing job should distinguish no input, valid input and invalid records. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not treat every nonzero return code identically; interpret it using the program/job contract.

Interview: Explain batch jobs and return codes using this case: A file-processing job should distinguish no input, valid input and invalid records. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A file-processing job should distinguish no input, valid input and invalid records.

A traceable job flow and evidence from the authorized lab.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A traceable job flow and evidence from the authorized lab. — A batch job declares ordered work, input/output datasets and execution requirements. A step completing is not enough; inspect return codes and the resulting business records. A traceable job flow and evidence from the authorized lab.

Sources:

IBM Z Xplore learning platform: https://www.ibm.com/products/z/resources/zxplore

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Transactional outbox: Write business data and the event to publish in one local transaction, then deliver the event separately.

Apply transactional outbox in Mainframe / COBOL Developer: Use the concept to complete this role exercise: Write a batch-job contract with input, output and return-code checks

Record layouts and decimal data: Fixed-width records encode fields by position and format. Business decimal values need defined scale; trimming or converting casually can change meaning.

### Transactional outbox

Write business data and the event to publish in one local transaction, then deliver the event separately. In this role, work through: An amount stored as 00012345 with scale 2 represents 123.45. The practical workshop develops this into: Create three synthetic fixed-width records and a field-position map. Parse them locally or in the IBM exercise, test a short record and a nonnumeric amount, and preserve rejection reasons.

Mental model: Record a sale and its mailing slip in the same ledger before dispatch.

Boundary: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Role application: A form with numbered boxes relies on every value occupying the correct boxes.

Fixed-width records encode fields by position and format. Business decimal values need defined scale; trimming or converting casually can change meaning.

Worked example: An amount stored as 00012345 with scale 2 represents 123.45.

Shared foundation example: The reference stores order-1 and its pending event together.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: IBM Z, COBOL, JCL and Db2 (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Mainframe / COBOL Developer: An amount stored as 00012345 with scale 2 represents 123.45.

Predict the worked case

Read this case without running a tool: An amount stored as 00012345 with scale 2 represents 123.45. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transactional outbox.

Connect the concept to the role

Apply this rule: Write business data and the event to publish in one local transaction, then deliver the event separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transactional outbox to this case: An amount stored as 00012345 with scale 2 represents 123.45. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An amount stored as 00012345 with scale 2 represents 123.45. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Transactional outbox; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transactional outbox. Use the glossary below, then write your prediction for: An amount stored as 00012345 with scale 2 represents 123.45. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Mainframe / COBOL Developer role interview. Explain transactional outbox using this case: An amount stored as 00012345 with scale 2 represents 123.45. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transactional outbox to a system or workflow you know. Explain transactional outbox using this case: An amount stored as 00012345 with scale 2 represents 123.45. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why can publishing first lose consistency if the database write fails?

Interview: Explain transactional outbox using this case: An amount stored as 00012345 with scale 2 represents 123.45. State the evidence, one alternative and where the mental model stops.

Quiz: After the Record layouts and decimal data rehearsal, check this foundation: Business data commits but publishing its event fails. Which design closes this local write/publish gap?

Publish first, then hope the business write succeeds.

Commit the data and pending outbox entry in one local transaction.

Use a longer broker timeout without recording pending work.

Reference: Commit the data and pending outbox entry in one local transaction. — The outbox preserves a durable publication intent. Delivery can still repeat, so consumers need suitable deduplication.

Sources:

IBM Z Xplore learning platform: https://www.ibm.com/products/z/resources/zxplore

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Record layouts and decimal data

Fixed-width records encode fields by position and format. Business decimal values need defined scale; trimming or converting casually can change meaning. In this role, work through: An amount stored as 00012345 with scale 2 represents 123.45. The practical workshop develops this into: Create three synthetic fixed-width records and a field-position map. Parse them locally or in the IBM exercise, test a short record and a nonnumeric amount, and preserve rejection reasons.

Mental model: A form with numbered boxes relies on every value occupying the correct boxes.

Boundary: Off-by-one offsets can produce plausible but wrong values; verify each field boundary.

Worked example: An amount stored as 00012345 with scale 2 represents 123.45.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: IBM Z, COBOL, JCL and Db2 (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Mainframe / COBOL Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create three synthetic fixed-width records and a field-position map. Parse them locally or in the IBM exercise, test a short record and a nonnumeric amount, and preserve rejection reasons.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

An amount stored as 00012345 with scale 2 represents 123.45. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create three synthetic fixed-width records and a field-position map. Parse them locally or in the IBM exercise, test a short record and a nonnumeric amount, and preserve rejection reasons.

Expected: Correct decimal interpretation and rejected malformed records.

Role workshop · debug and verify

Off-by-one offsets can produce plausible but wrong values; verify each field boundary. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save record-layout specification and parsing tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Correct decimal interpretation and rejected malformed records.

Expected: Correct decimal interpretation and rejected malformed records.

Troubleshoot: The role exercise differs from the prediction: Off-by-one offsets can produce plausible but wrong values; verify each field boundary.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: record-layout specification and parsing tests; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with record layouts and decimal data. Use the glossary below, then write your prediction for: An amount stored as 00012345 with scale 2 represents 123.45. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Mainframe / COBOL Developer role interview. Explain record layouts and decimal data using this case: An amount stored as 00012345 with scale 2 represents 123.45. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate record layouts and decimal data to a system or workflow you know. Explain record layouts and decimal data using this case: An amount stored as 00012345 with scale 2 represents 123.45. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Off-by-one offsets can produce plausible but wrong values; verify each field boundary.

Interview: Explain record layouts and decimal data using this case: An amount stored as 00012345 with scale 2 represents 123.45. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? An amount stored as 00012345 with scale 2 represents 123.45.

Ignore the failing case and keep only the successful screenshot.

Correct decimal interpretation and rejected malformed records.

Treat any successful command as proof that all business and access rules passed.

Reference: Correct decimal interpretation and rejected malformed records. — Fixed-width records encode fields by position and format. Business decimal values need defined scale; trimming or converting casually can change meaning. Correct decimal interpretation and rejected malformed records.

Sources:

IBM Z Xplore learning platform: https://www.ibm.com/products/z/resources/zxplore

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Failure semantics: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.

Apply failure semantics in Mainframe / COBOL Developer: Use the concept to complete this role exercise: Plan restart checkpoints, reconciliation and backward-compatible modernization

Restartable batch processing: A failed batch needs a checkpoint and reconciliation policy so rerun does not duplicate outputs or skip unfinished records. Dataset disposition and downstream effects matter.

### Failure semantics

Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. In this role, work through: Failure after record 2 of 5 should resume or replay according to a documented key policy. The practical workshop develops this into: Run a synthetic tabletop or provided lab with a checkpoint, compare source/output IDs and totals, and write restart instructions including cleanup of partial output.

Mental model: Track a parcel even when the receipt acknowledgment is lost.

Boundary: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Role application: A factory restart must know which items were finished before the power failed.

A failed batch needs a checkpoint and reconciliation policy so rerun does not duplicate outputs or skip unfinished records. Dataset disposition and downstream effects matter.

Worked example: Failure after record 2 of 5 should resume or replay according to a documented key policy.

Shared foundation example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: IBM Z, COBOL, JCL and Db2 (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Mainframe / COBOL Developer: Failure after record 2 of 5 should resume or replay according to a documented key policy.

Predict the worked case

Read this case without running a tool: Failure after record 2 of 5 should resume or replay according to a documented key policy. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in failure semantics.

Connect the concept to the role

Apply this rule: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies failure semantics to this case: Failure after record 2 of 5 should resume or replay according to a documented key policy. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Failure after record 2 of 5 should resume or replay according to a documented key policy. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Failure semantics; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure semantics. Use the glossary below, then write your prediction for: Failure after record 2 of 5 should resume or replay according to a documented key policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Mainframe / COBOL Developer role interview. Explain failure semantics using this case: Failure after record 2 of 5 should resume or replay according to a documented key policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure semantics to a system or workflow you know. Explain failure semantics using this case: Failure after record 2 of 5 should resume or replay according to a documented key policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you recover a permanently failing event without blocking all orders?

Interview: Explain failure semantics using this case: Failure after record 2 of 5 should resume or replay according to a documented key policy. State the evidence, one alternative and where the mental model stops.

Quiz: After the Restartable batch processing rehearsal, check this foundation: A consumer commits its effect and crashes before acknowledging. What must the design handle?

The broker can infer the effect and guarantee no replay.

The effect must be automatically rolled back by the broker.

The message can be delivered again after the effect already happened.

Reference: The message can be delivered again after the effect already happened. — Acknowledgment and the business effect are separate boundaries. Model the crash window and make replay safe.

Sources:

IBM Z Xplore learning platform: https://www.ibm.com/products/z/resources/zxplore

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Restartable batch processing

A failed batch needs a checkpoint and reconciliation policy so rerun does not duplicate outputs or skip unfinished records. Dataset disposition and downstream effects matter. In this role, work through: Failure after record 2 of 5 should resume or replay according to a documented key policy. The practical workshop develops this into: Run a synthetic tabletop or provided lab with a checkpoint, compare source/output IDs and totals, and write restart instructions including cleanup of partial output.

Mental model: A factory restart must know which items were finished before the power failed.

Boundary: Deleting partial output before recording its state can destroy recovery evidence.

Worked example: Failure after record 2 of 5 should resume or replay according to a documented key policy.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: IBM Z, COBOL, JCL and Db2 (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Mainframe / COBOL Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run a synthetic tabletop or provided lab with a checkpoint, compare source/output IDs and totals, and write restart instructions including cleanup of partial output.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Failure after record 2 of 5 should resume or replay according to a documented key policy. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run a synthetic tabletop or provided lab with a checkpoint, compare source/output IDs and totals, and write restart instructions including cleanup of partial output.

Expected: All five records accounted for exactly as the chosen business policy requires.

Role workshop · debug and verify

Deleting partial output before recording its state can destroy recovery evidence. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save batch restart runbook and reconciliation table. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: All five records accounted for exactly as the chosen business policy requires.

Expected: All five records accounted for exactly as the chosen business policy requires.

Troubleshoot: The role exercise differs from the prediction: Deleting partial output before recording its state can destroy recovery evidence.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: batch restart runbook and reconciliation table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with restartable batch processing. Use the glossary below, then write your prediction for: Failure after record 2 of 5 should resume or replay according to a documented key policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Mainframe / COBOL Developer role interview. Explain restartable batch processing using this case: Failure after record 2 of 5 should resume or replay according to a documented key policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate restartable batch processing to a system or workflow you know. Explain restartable batch processing using this case: Failure after record 2 of 5 should resume or replay according to a documented key policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Deleting partial output before recording its state can destroy recovery evidence.

Interview: Explain restartable batch processing using this case: Failure after record 2 of 5 should resume or replay according to a documented key policy. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Failure after record 2 of 5 should resume or replay according to a documented key policy.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

All five records accounted for exactly as the chosen business policy requires.

Reference: All five records accounted for exactly as the chosen business policy requires. — A failed batch needs a checkpoint and reconciliation policy so rerun does not duplicate outputs or skip unfinished records. Dataset disposition and downstream effects matter. All five records accounted for exactly as the chosen business policy requires.

Sources:

IBM Z Xplore learning platform: https://www.ibm.com/products/z/resources/zxplore

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
