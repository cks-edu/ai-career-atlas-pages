# Mainframe / COBOL Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Batch jobs and return codes

A batch job declares ordered work, input/output datasets and execution requirements. A step completing is not enough; inspect return codes and the resulting business records.
Mental model: A factory batch has a work order, materials and an inspection result for each station.
Case: A file-processing job should distinguish no input, valid input and invalid records.
Task: Use IBM Z Xplore's provided learning environment and job exercises. Record dataset names, step order and return codes; keep an offline input/output contract with synthetic records.
Acceptance: A traceable job flow and evidence from the authorized lab.
Troubleshooting: Do not treat every nonzero return code identically; interpret it using the program/job contract.
Deliverable: batch job worksheet and lab transcript

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Record layouts and decimal data

Fixed-width records encode fields by position and format. Business decimal values need defined scale; trimming or converting casually can change meaning.
Mental model: A form with numbered boxes relies on every value occupying the correct boxes.
Case: An amount stored as 00012345 with scale 2 represents 123.45.
Task: Create three synthetic fixed-width records and a field-position map. Parse them locally or in the IBM exercise, test a short record and a nonnumeric amount, and preserve rejection reasons.
Acceptance: Correct decimal interpretation and rejected malformed records.
Troubleshooting: Off-by-one offsets can produce plausible but wrong values; verify each field boundary.
Deliverable: record-layout specification and parsing tests

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Restartable batch processing

A failed batch needs a checkpoint and reconciliation policy so rerun does not duplicate outputs or skip unfinished records. Dataset disposition and downstream effects matter.
Mental model: A factory restart must know which items were finished before the power failed.
Case: Failure after record 2 of 5 should resume or replay according to a documented key policy.
Task: Run a synthetic tabletop or provided lab with a checkpoint, compare source/output IDs and totals, and write restart instructions including cleanup of partial output.
Acceptance: All five records accounted for exactly as the chosen business policy requires.
Troubleshooting: Deleting partial output before recording its state can destroy recovery evidence.
Deliverable: batch restart runbook and reconciliation table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
