## beginner — Technical literacy for policy

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Technical literacy for policy
Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit.
Mental model: Rules for a factory require understanding which machines do which jobs.
Boundary: A simplified system diagram cannot capture every implementation or business relationship.
Worked example: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A policy claim loses its jurisdiction
The research brief requires every legal or institutional claim to record jurisdiction and publication date. Three claims lack the context needed to evaluate whether the source applies. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law.
Recall: A reviewer can trace every material claim to the relevant dated primary text. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Technical literacy for policy: Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Policy analysis examines who is affected and who can make decisions. Describe what a system actually does before debating how it should be governed.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional city library considering an AI FAQ assistant whose answers staff review.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page brief with affected groups and open questions.

3. Try step 2
Describe its purpose, data, limits and the people affected, including visitors who cannot use the online service.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page brief with affected groups and open questions.

4. Try step 3
Write two questions the library’s decision makers should answer before a pilot, and name evidence that would help.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page brief with affected groups and open questions.

5. Explain and check your result
The brief distinguishes proposed use from proven benefit and does not invent legal obligations. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A one-page brief with affected groups and open questions. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The research brief requires every legal or institutional claim to record jurisdiction and publication date. Apply this toy-case rule manually: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three claims lack the context needed to evaluate whether the source applies. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI policy researcher / programme specialist.
Use a fictional city library considering an AI FAQ assistant whose answers staff review.
Describe its purpose, data, limits and the people affected, including visitors who cannot use the online service.
Write two questions the library’s decision makers should answer before a pilot, and name evidence that would help.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A one-page brief with affected groups and open questions. Include beginner-worksheet.md and your completed Policy options brief and source register.
Check: The brief distinguishes proposed use from proven benefit and does not invent legal obligations.

### Interview
Explain your beginner solution for AI policy researcher / programme specialist. Use this scenario: The research brief requires every legal or institutional claim to record jurisdiction and publication date.
Review: Start with the task and permitted scope. Explain technical literacy for policy: Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit. Show the input and observed output, then address Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A one-page brief with affected groups and open questions. Include beginner-worksheet.md and your completed Policy options brief and source register.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

