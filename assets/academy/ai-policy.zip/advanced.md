## advanced — Policy option comparison

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Policy option comparison
Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible.
Mental model: A city compares several transport plans rather than voting on a slogan.
Boundary: A classroom options memo is not current legal advice or proof an intervention will work.
Worked example: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Evidence-based AI policy options brief
Research a narrow AI policy question and present traceable options for a specified audience. Write a two-page brief and a longer methods appendix. Include a stakeholder map and an explicit separation of factual findings from your recommendations.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.
Recall: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. Identify one observation that would contradict your claim.

### Terms
Policy option comparison: Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Research a narrow AI policy question and present traceable options for a specified audience. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a Zotero collection and source register with author, jurisdiction, publication date, binding/nonbinding status and relevant sections. Distinguish proposals from enacted requirements.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Write a two-page brief and a longer methods appendix. Include a stakeholder map and an explicit separation of factual findings from your recommendations.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Research a narrow AI policy question and present traceable options for a specified audience.
Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.
Create a Zotero collection and source register with author, jurisdiction, publication date, binding/nonbinding status and relevant sections. Distinguish proposals from enacted requirements.
Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps.
Write a two-page brief and a longer methods appendix. Include a stakeholder map and an explicit separation of factual findings from your recommendations.
Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.
Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.
Update the brief after a genuine policy change and publish a dated change log; obtain expert review for real advice.
Deliverables: Policy options brief and source library; Claim-evidence matrix; Stakeholder/implementation analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.

### Interview
Explain your advanced solution for AI policy researcher / programme specialist. Use this scenario: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.
Review: Start with the task and permitted scope. Explain policy option comparison: Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible. Show the input and observed output, then address Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Policy options brief and source library; Claim-evidence matrix; Stakeholder/implementation analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

