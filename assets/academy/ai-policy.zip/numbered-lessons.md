# AI policy researcher / programme specialist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Technical literacy for policy: Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Technical literacy for policy

Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit. In this role, work through: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Rules for a factory require understanding which machines do which jobs.

Boundary: A simplified system diagram cannot capture every implementation or business relationship.

Worked example: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Zotero (Open source · optional paid storage); LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI policy researcher / programme specialist: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service.

Predict the worked case

Read this case without running a tool: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in technical literacy for policy.

Connect the concept to the role

Apply this rule: Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A simplified system diagram cannot capture every implementation or business relationship.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies technical literacy for policy to this case: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Technical literacy for policy; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with technical literacy for policy. Use the glossary below, then write your prediction for: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI policy researcher / programme specialist role interview. Explain technical literacy for policy using this case: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate technical literacy for policy to a system or workflow you know. Explain technical literacy for policy using this case: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain technical literacy for policy using this case: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service.

Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit. — Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit. A simplified system diagram cannot capture every implementation or business relationship.

Sources:

Zotero: https://www.zotero.org/support/quick_start_guide

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

### Diagnose: A policy claim loses its jurisdiction

The research brief requires every legal or institutional claim to record jurisdiction and publication date. Three claims lack the context needed to evaluate whether the source applies. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Rules for a factory require understanding which machines do which jobs.

A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service.

Worked example: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Zotero (Open source · optional paid storage); LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The research brief requires every legal or institutional claim to record jurisdiction and publication date. Three claims lack the context needed to evaluate whether the source applies. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The research brief requires every legal or institutional claim to record jurisdiction and publication date. Apply this toy-case rule manually: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Policy analysis examines who is affected and who can make decisions. Describe what a system actually does before debating how it should be governed.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Use a fictional city library considering an AI FAQ assistant whose answers staff review.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page brief with affected groups and open questions.

Preparation · Try step 2

Describe its purpose, data, limits and the people affected, including visitors who cannot use the online service.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page brief with affected groups and open questions.

Preparation · Try step 3

Write two questions the library’s decision makers should answer before a pilot, and name evidence that would help.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page brief with affected groups and open questions.

Preparation · Explain and check your result

The brief distinguishes proposed use from proven benefit and does not invent legal obligations. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A one-page brief with affected groups and open questions. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The research brief requires every legal or institutional claim to record jurisdiction and publication date. Apply this toy-case rule manually: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three claims lack the context needed to evaluate whether the source applies. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three claims lack the context needed to evaluate whether the source applies. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a policy claim loses its jurisdiction. Use the glossary below, then write your prediction for: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI policy researcher / programme specialist role interview. Explain diagnose: a policy claim loses its jurisdiction using this case: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a policy claim loses its jurisdiction to a system or workflow you know. Explain diagnose: a policy claim loses its jurisdiction using this case: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: A reviewer can trace every material claim to the relevant dated primary text. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a policy claim loses its jurisdiction using this case: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law. State the evidence, one alternative and where the mental model stops.

Quiz: A policy claim loses its jurisdiction: The research brief requires every legal or institutional claim to record jurisdiction and publication date.

Change the acceptance rule after seeing an inconvenient result.

Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law.

Omit failed cases and report only the successful demonstrations.

Reference: Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law. — Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law. A reviewer can trace every material claim to the relevant dated primary text.

Sources:

Zotero: https://www.zotero.org/support/quick_start_guide

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Policy analysis, research methods and clear writing; local expertise, language or postgraduate credentials may be required.

Terms:

Evidence appraisal: Record the claim, source, date, method and limitations for each piece of evidence. Separate primary research, stakeholder opinion and your own interpretation.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Evidence appraisal

Record the claim, source, date, method and limitations for each piece of evidence. Separate primary research, stakeholder opinion and your own interpretation. In this role, work through: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A court file distinguishes witness testimony from verified records and arguments.

Boundary: A credible publisher can still publish evidence with limited applicability.

Worked example: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Policy analysis, research methods and clear writing; local expertise, language or postgraduate credentials may be required.

Tools for this exercise: Document or text editor

Course tool and framework map: Zotero (Open source · optional paid storage); LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI policy researcher / programme specialist: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling.

Predict the worked case

Read this case without running a tool: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in evidence appraisal.

Connect the concept to the role

Apply this rule: Record the claim, source, date, method and limitations for each piece of evidence. Separate primary research, stakeholder opinion and your own interpretation. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A credible publisher can still publish evidence with limited applicability.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies evidence appraisal to this case: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Evidence appraisal; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with evidence appraisal. Use the glossary below, then write your prediction for: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI policy researcher / programme specialist role interview. Explain evidence appraisal using this case: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate evidence appraisal to a system or workflow you know. Explain evidence appraisal using this case: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain evidence appraisal using this case: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling.

Treat a passing starter as proof of the whole role workflow.

Record the claim, source, date, method and limitations for each piece of evidence. Separate primary research, stakeholder opinion and your own interpretation.

Ignore the failure because the tool produced an output.

Reference: Record the claim, source, date, method and limitations for each piece of evidence. Separate primary research, stakeholder opinion and your own interpretation. — Record the claim, source, date, method and limitations for each piece of evidence. Separate primary research, stakeholder opinion and your own interpretation. A credible publisher can still publish evidence with limited applicability.

Sources:

Zotero: https://www.zotero.org/support/quick_start_guide

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

### Integrate: Evidence-based AI policy options brief

Research a narrow AI policy question and present traceable options for a specified audience. Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps. In this role, work through: Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A court file distinguishes witness testimony from verified records and arguments.

A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling.

Worked example: Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Zotero (Open source · optional paid storage); LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed)

Research a narrow AI policy question and present traceable options for a specified audience. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Research a narrow AI policy question and present traceable options for a specified audience.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a Zotero collection and source register with author, jurisdiction, publication date, binding/nonbinding status and relevant sections. Distinguish proposals from enacted requirements.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The research brief requires every legal or institutional claim to record jurisdiction and publication date. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Policy options brief and source library; Claim-evidence matrix. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: evidence-based ai policy options brief. Use the glossary below, then write your prediction for: Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI policy researcher / programme specialist role interview. Explain integrate: evidence-based ai policy options brief using this case: Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: evidence-based ai policy options brief to a system or workflow you know. Explain integrate: evidence-based ai policy options brief using this case: Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. Identify one observation that would contradict your claim.

Interview: Explain integrate: evidence-based ai policy options brief using this case: Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Evidence-based AI policy options brief at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.

Reference: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. — Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.

Sources:

Zotero: https://www.zotero.org/support/quick_start_guide

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Policy option comparison: Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Policy option comparison

Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible. In this role, work through: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A city compares several transport plans rather than voting on a slogan.

Boundary: A classroom options memo is not current legal advice or proof an intervention will work.

Worked example: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Zotero (Open source · optional paid storage); LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI policy researcher / programme specialist: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review.

Predict the worked case

Read this case without running a tool: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in policy option comparison.

Connect the concept to the role

Apply this rule: Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A classroom options memo is not current legal advice or proof an intervention will work.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies policy option comparison to this case: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Policy option comparison; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with policy option comparison. Use the glossary below, then write your prediction for: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI policy researcher / programme specialist role interview. Explain policy option comparison using this case: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate policy option comparison to a system or workflow you know. Explain policy option comparison using this case: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain policy option comparison using this case: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible.

Reference: Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible. — Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible. A classroom options memo is not current legal advice or proof an intervention will work.

Sources:

Zotero: https://www.zotero.org/support/quick_start_guide

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing

### Defend: Evidence-based AI policy options brief

Research a narrow AI policy question and present traceable options for a specified audience. Write a two-page brief and a longer methods appendix. Include a stakeholder map and an explicit separation of factual findings from your recommendations. In this role, work through: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A city compares several transport plans rather than voting on a slogan.

Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review.

Worked example: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Zotero (Open source · optional paid storage); LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed)

Research a narrow AI policy question and present traceable options for a specified audience. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Research a narrow AI policy question and present traceable options for a specified audience.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create a Zotero collection and source register with author, jurisdiction, publication date, binding/nonbinding status and relevant sections. Distinguish proposals from enacted requirements.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Write a two-page brief and a longer methods appendix. Include a stakeholder map and an explicit separation of factual findings from your recommendations.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Policy options brief and source library; Claim-evidence matrix; Stakeholder/implementation analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: evidence-based ai policy options brief. Use the glossary below, then write your prediction for: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI policy researcher / programme specialist role interview. Explain defend: evidence-based ai policy options brief using this case: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: evidence-based ai policy options brief to a system or workflow you know. Explain defend: evidence-based ai policy options brief using this case: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. Identify one observation that would contradict your claim.

Interview: Explain defend: evidence-based ai policy options brief using this case: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Evidence-based AI policy options brief at this level?

Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions. — Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions. Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.

Sources:

Zotero: https://www.zotero.org/support/quick_start_guide

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Google Technical Writing: https://developers.google.com/tech-writing
