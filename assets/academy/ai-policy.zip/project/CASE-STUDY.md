# Evidence-based AI policy options brief

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Research a narrow AI policy question and present traceable options for a specified audience.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.

## Limitations and next iteration
Update the brief after a genuine policy change and publish a dated change log; obtain expert review for real advice.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
