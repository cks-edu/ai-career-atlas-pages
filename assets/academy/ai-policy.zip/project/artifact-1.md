# Policy options brief and source library

Project: Evidence-based AI policy options brief
Status: blank work product — not completed evidence

## Purpose and audience
Research a narrow AI policy question and present traceable options for a specified audience.

## Required content
Create a Zotero collection and source register with author, jurisdiction, publication date, binding/nonbinding status and relevant sections. Distinguish proposals from enacted requirements.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.

## Failure evidence
Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
