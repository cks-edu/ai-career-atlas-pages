# AI policy researcher / programme specialist

AI Engineering · Beginner → Intermediate → Advanced

Start with Technical literacy for policy. Policy analysis examines who is affected and who can make decisions. Describe what a system actually does before debating how it should be governed. Then try Write a plain-language policy brief. The three levels build toward Evidence-based AI policy options brief. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Technical literacy for policy

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Technical literacy for policy
Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit.
Mental model: Rules for a factory require understanding which machines do which jobs.
Boundary: A simplified system diagram cannot capture every implementation or business relationship.
Worked example: A policy brief distinguishes collecting training examples from sending a user's question to a hosted inference service.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A policy claim loses its jurisdiction
The research brief requires every legal or institutional claim to record jurisdiction and publication date. Three claims lack the context needed to evaluate whether the source applies. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law.
Recall: A reviewer can trace every material claim to the relevant dated primary text. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Technical literacy for policy: Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Policy analysis examines who is affected and who can make decisions. Describe what a system actually does before debating how it should be governed.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Use a fictional city library considering an AI FAQ assistant whose answers staff review.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page brief with affected groups and open questions.

3. Try step 2
Describe its purpose, data, limits and the people affected, including visitors who cannot use the online service.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page brief with affected groups and open questions.

4. Try step 3
Write two questions the library’s decision makers should answer before a pilot, and name evidence that would help.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page brief with affected groups and open questions.

5. Explain and check your result
The brief distinguishes proposed use from proven benefit and does not invent legal obligations. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A one-page brief with affected groups and open questions. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The research brief requires every legal or institutional claim to record jurisdiction and publication date. Apply this toy-case rule manually: Review when missing_context >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three claims lack the context needed to evaluate whether the source applies. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI policy researcher / programme specialist.
Use a fictional city library considering an AI FAQ assistant whose answers staff review.
Describe its purpose, data, limits and the people affected, including visitors who cannot use the online service.
Write two questions the library’s decision makers should answer before a pilot, and name evidence that would help.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A one-page brief with affected groups and open questions. Include beginner-worksheet.md and your completed Policy options brief and source register.
Check: The brief distinguishes proposed use from proven benefit and does not invent legal obligations.

### Interview
Explain your beginner solution for AI policy researcher / programme specialist. Use this scenario: The research brief requires every legal or institutional claim to record jurisdiction and publication date.
Review: Start with the task and permitted scope. Explain technical literacy for policy: Explain what an AI system actually does, its data dependencies and where people make decisions. Keep distinctions such as training, inference and deployment explicit. Show the input and observed output, then address Annotate primary sources and mark unsupported claims as unresolved rather than presenting them as current law. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A one-page brief with affected groups and open questions. Include beginner-worksheet.md and your completed Policy options brief and source register.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Evidence appraisal

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Policy analysis, research methods and clear writing; local expertise, language or postgraduate credentials may be required.

### Evidence appraisal
Record the claim, source, date, method and limitations for each piece of evidence. Separate primary research, stakeholder opinion and your own interpretation.
Mental model: A court file distinguishes witness testimony from verified records and arguments.
Boundary: A credible publisher can still publish evidence with limited applicability.
Worked example: A vendor survey reports adoption among its customers; do not generalize it to all employers without examining sampling.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Evidence-based AI policy options brief
Research a narrow AI policy question and present traceable options for a specified audience. Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.
Recall: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. Identify one observation that would contradict your claim.

### Terms
Evidence appraisal: Record the claim, source, date, method and limitations for each piece of evidence. Separate primary research, stakeholder opinion and your own interpretation.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Research a narrow AI policy question and present traceable options for a specified audience. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a Zotero collection and source register with author, jurisdiction, publication date, binding/nonbinding status and relevant sections. Distinguish proposals from enacted requirements.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The research brief requires every legal or institutional claim to record jurisdiction and publication date. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Research a narrow AI policy question and present traceable options for a specified audience.
Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.
Create a Zotero collection and source register with author, jurisdiction, publication date, binding/nonbinding status and relevant sections. Distinguish proposals from enacted requirements.
Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps.
Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.
Deliverables: Policy options brief and source library; Claim-evidence matrix. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI policy researcher / programme specialist. Use this scenario: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.
Review: Start with the task and permitted scope. Explain evidence appraisal: Record the claim, source, date, method and limitations for each piece of evidence. Separate primary research, stakeholder opinion and your own interpretation. Show the input and observed output, then address Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Policy options brief and source library; Claim-evidence matrix. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Policy option comparison

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Policy option comparison
Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible.
Mental model: A city compares several transport plans rather than voting on a slogan.
Boundary: A classroom options memo is not current legal advice or proof an intervention will work.
Worked example: Compare voluntary guidance, procurement conditions and a reporting requirement for a fictional jurisdiction, labeling legal assumptions for review.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Evidence-based AI policy options brief
Research a narrow AI policy question and present traceable options for a specified audience. Write a two-page brief and a longer methods appendix. Include a stakeholder map and an explicit separation of factual findings from your recommendations.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.
Recall: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. Identify one observation that would contradict your claim.

### Terms
Policy option comparison: Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
precision: Of items predicted positive, the fraction that are actually positive under the chosen labels.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Research a narrow AI policy question and present traceable options for a specified audience. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create a Zotero collection and source register with author, jurisdiction, publication date, binding/nonbinding status and relevant sections. Distinguish proposals from enacted requirements.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Write a two-page brief and a longer methods appendix. Include a stakeholder map and an explicit separation of factual findings from your recommendations.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Research a narrow AI policy question and present traceable options for a specified audience.
Choose one jurisdiction and a dated question, such as procurement transparency for public-sector AI. Collect primary laws, regulator guidance and official consultations; record status and date.
Create a Zotero collection and source register with author, jurisdiction, publication date, binding/nonbinding status and relevant sections. Distinguish proposals from enacted requirements.
Build a claim-evidence matrix in Calc. Draft three policy options with affected groups, implementation burden, enforcement mechanism and evidence gaps.
Write a two-page brief and a longer methods appendix. Include a stakeholder map and an explicit separation of factual findings from your recommendations.
Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.
Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score.
Update the brief after a genuine policy change and publish a dated change log; obtain expert review for real advice.
Deliverables: Policy options brief and source library; Claim-evidence matrix; Stakeholder/implementation analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. A reviewer must reproduce one result and identify which capabilities you implemented. Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.

### Interview
Explain your advanced solution for AI policy researcher / programme specialist. Use this scenario: Introduce an outdated consultation summary that conflicts with a newer official text. Resolve the timeline and revise the claim; do not silently combine jurisdictions.
Review: Start with the task and permitted scope. Explain policy option comparison: Compare several interventions, including a baseline, using effectiveness, feasibility, costs and distributional effects. Make uncertainty and implementation ownership visible. Show the input and observed output, then address Ask a peer to verify five central claims against original sources. Record unsupported claims, source conflicts and uncertainty rather than assigning a false precision score. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Policy options brief and source library; Claim-evidence matrix; Stakeholder/implementation analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Zotero — Open source · optional paid storage
Organize references and trace policy claims to original sources.
Alternative: A structured bibliography spreadsheet for a small review or EndNote (commercial); preserve source dates and citation metadata.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Writer / Impress — Open source · no account needed
Edit reports, workshop decks and export PDF deliverables.
Alternative: Microsoft Word/PowerPoint (commercial) or Google Docs/Slides (hosted); retain editable and accessible exports.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Zotero: https://www.zotero.org/support/quick_start_guide
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/
UNESCO Recommendation on AI Ethics: https://www.unesco.org/en/artificial-intelligence/recommendation-ethics
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
Google Technical Writing: https://developers.google.com/tech-writing
