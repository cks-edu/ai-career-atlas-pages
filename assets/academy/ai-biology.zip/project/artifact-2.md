# Dataset/model cards

Project: Molecular property modeling with scaffold validation
Status: blank work product — not completed evidence

## Purpose and audience
Build a molecular-property baseline with chemical validity and leakage-aware evaluation.

## Required content
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.

## Failure evidence
Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
