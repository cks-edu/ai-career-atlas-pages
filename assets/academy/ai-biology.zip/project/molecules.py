"""RDKit parsing smoke test; no biological efficacy or safety prediction."""
import json
from rdkit import Chem
from rdkit.Chem import Descriptors
rows=[]
for text in ['CCO','CC(=O)O','c1ccccc1','not-a-smiles']:
    molecule=Chem.MolFromSmiles(text)
    rows.append({'input':text,'valid':molecule is not None,'canonical':Chem.MolToSmiles(molecule) if molecule else None,'molecular_weight':Descriptors.MolWt(molecule) if molecule else None})
print(json.dumps(rows,indent=2))
