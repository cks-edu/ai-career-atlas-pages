# Molecular property modeling with scaffold validation

Career: AI for biology / drug discovery
Reviewed: 2026-10-22

Build a molecular-property baseline with chemical validity and leakage-aware evaluation.

## Prerequisites
Relevant scientific training plus statistical modeling; many discovery-scientist roles require postgraduate research.

## Included starter versus your implementation
Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks.

CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python molecules.py
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Inspect applicability domain, activity cliffs and uncertainty. Write a model card linking target, units, assay conditions and known sources of bias.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. RDKit featurization and scaffold-split code — artifact-1.md
2. Dataset/model cards — artifact-2.md
3. Leakage and applicability-domain report — artifact-3.md

## Troubleshooting
- RDKit install fails: use a supported Python version and the official install guide.
- Invalid molecule: quarantine and document it rather than forcing a parse.
- Inflated result: inspect canonical duplicates, scaffolds and assay shift.

## Extension
Validate on a separate measurement source and discuss assay shift before making scientific claims.

## Primary learning resources
- RDKit: https://www.rdkit.org/docs/GettingStartedInPython.html — Open source; Molecule parsing, descriptors and scaffold-aware validation.
- scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html — Open source · CPU; Pipelines, baselines, data splits and statistical evaluation.
- MLflow: https://mlflow.org/docs/latest/ml/tracking/quickstart/ — Open source · hosted offerings optional; Record experiments, parameters and evaluation artifacts.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
