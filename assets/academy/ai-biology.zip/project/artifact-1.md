# RDKit featurization and scaffold-split code

Project: Molecular property modeling with scaffold validation
Status: blank work product — not completed evidence

## Purpose and audience
Build a molecular-property baseline with chemical validity and leakage-aware evaluation.

## Required content
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.

## Failure evidence
Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
