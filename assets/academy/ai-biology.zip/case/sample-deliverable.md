# SAMPLE — Molecular data audit and applicability report
Role: AI for biology / drug discovery
Case: A scaffold appears in both partitions
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The molecular-property protocol forbids the same scaffold family in training and held-out evaluation.

## Evidence table
| Record | shared_scaffolds (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 2 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three evaluations leak scaffold families and overstate out-of-family generalization.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Rebuild scaffold-aware splits before fitting preprocessing and comparing models.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai for biology / drug discovery.
Before release: Report performance by chemical domain and assay conditions; involve a qualified scientific reviewer.

## Design choice and trade-off
Preserve assay units and provenance; distinguish prediction from experimental validation.
Strong computational scores do not establish efficacy or safety and may not transfer to new chemistry.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Molecular property benchmark: Report leakage checks and performance outside familiar scaffolds.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
