## beginner — Scientific endpoints and provenance

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Scientific endpoints and provenance
Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions.
Mental model: Two thermometers are comparable only when you know what and how they measured.
Boundary: A computational prediction is not experimental or clinical validation.
Worked example: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A scaffold appears in both partitions
The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Three evaluations leak scaffold families and overstate out-of-family generalization. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild scaffold-aware splits before fitting preprocessing and comparing models.
Recall: Report performance by chemical domain and assay conditions; involve a qualified scientific reviewer. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Scientific endpoints and provenance: Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
assay: An experimental measurement procedure; conditions and units matter when comparing biological results.
scaffold: In chemistry, a molecular core used in some grouping/splitting strategies; in software, a starter structure to extend.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A prediction target must match the actual experiment. Conditions and repeated measurements affect what a result means.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine predicting growth of a harmless fictional culture after 24 hours. Define the measurement unit, temperature and starting amount.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An experimental data dictionary and a comparability checklist.

3. Try step 2
Create a blank table for sample ID, conditions, repeat number and measured outcome.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An experimental data dictionary and a comparability checklist.

4. Try step 3
List factors that would make rows incomparable and questions for a qualified subject reviewer.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An experimental data dictionary and a comparability checklist.

5. Explain and check your result
The target and conditions are explicit; this paper exercise does not claim biological validity or instruct a wet-lab procedure. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An experimental data dictionary and a comparability checklist. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Apply this toy-case rule manually: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three evaluations leak scaffold families and overstate out-of-family generalization. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI for biology / drug discovery.
Imagine predicting growth of a harmless fictional culture after 24 hours. Define the measurement unit, temperature and starting amount.
Create a blank table for sample ID, conditions, repeat number and measured outcome.
List factors that would make rows incomparable and questions for a qualified subject reviewer.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An experimental data dictionary and a comparability checklist. Include beginner-worksheet.md and your completed Molecular data audit and applicability report.
Check: The target and conditions are explicit; this paper exercise does not claim biological validity or instruct a wet-lab procedure.

### Interview
Explain your beginner solution for AI for biology / drug discovery. Use this scenario: The molecular-property protocol forbids the same scaffold family in training and held-out evaluation.
Review: Start with the task and permitted scope. Explain scientific endpoints and provenance: Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions. Show the input and observed output, then address Rebuild scaffold-aware splits before fitting preprocessing and comparing models. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An experimental data dictionary and a comparability checklist. Include beginner-worksheet.md and your completed Molecular data audit and applicability report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

