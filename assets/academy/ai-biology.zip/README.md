# AI for biology / drug discovery

AI Engineering · Beginner → Intermediate → Advanced

Start with Scientific endpoints and provenance. A prediction target must match the actual experiment. Conditions and repeated measurements affect what a result means. Then try Define a fictional biological measurement. The three levels build toward Molecular property modeling with scaffold validation. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Scientific endpoints and provenance

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Scientific endpoints and provenance
Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions.
Mental model: Two thermometers are comparable only when you know what and how they measured.
Boundary: A computational prediction is not experimental or clinical validation.
Worked example: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A scaffold appears in both partitions
The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Three evaluations leak scaffold families and overstate out-of-family generalization. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild scaffold-aware splits before fitting preprocessing and comparing models.
Recall: Report performance by chemical domain and assay conditions; involve a qualified scientific reviewer. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Scientific endpoints and provenance: Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
assay: An experimental measurement procedure; conditions and units matter when comparing biological results.
scaffold: In chemistry, a molecular core used in some grouping/splitting strategies; in software, a starter structure to extend.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A prediction target must match the actual experiment. Conditions and repeated measurements affect what a result means.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine predicting growth of a harmless fictional culture after 24 hours. Define the measurement unit, temperature and starting amount.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An experimental data dictionary and a comparability checklist.

3. Try step 2
Create a blank table for sample ID, conditions, repeat number and measured outcome.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An experimental data dictionary and a comparability checklist.

4. Try step 3
List factors that would make rows incomparable and questions for a qualified subject reviewer.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An experimental data dictionary and a comparability checklist.

5. Explain and check your result
The target and conditions are explicit; this paper exercise does not claim biological validity or instruct a wet-lab procedure. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An experimental data dictionary and a comparability checklist. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Apply this toy-case rule manually: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three evaluations leak scaffold families and overstate out-of-family generalization. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI for biology / drug discovery.
Imagine predicting growth of a harmless fictional culture after 24 hours. Define the measurement unit, temperature and starting amount.
Create a blank table for sample ID, conditions, repeat number and measured outcome.
List factors that would make rows incomparable and questions for a qualified subject reviewer.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An experimental data dictionary and a comparability checklist. Include beginner-worksheet.md and your completed Molecular data audit and applicability report.
Check: The target and conditions are explicit; this paper exercise does not claim biological validity or instruct a wet-lab procedure.

### Interview
Explain your beginner solution for AI for biology / drug discovery. Use this scenario: The molecular-property protocol forbids the same scaffold family in training and held-out evaluation.
Review: Start with the task and permitted scope. Explain scientific endpoints and provenance: Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions. Show the input and observed output, then address Rebuild scaffold-aware splits before fitting preprocessing and comparing models. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An experimental data dictionary and a comparability checklist. Include beginner-worksheet.md and your completed Molecular data audit and applicability report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Molecular splits and baselines

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Relevant scientific training plus statistical modeling; many discovery-scientist roles require postgraduate research.

### Molecular splits and baselines
Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions.
Mental model: Testing on a close relative of every training example can make an exam too easy.
Boundary: A scaffold split addresses one generalization concern, not every source of bias.
Worked example: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Molecular property modeling with scaffold validation
Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.
Worked example: Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Recall: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. Identify one observation that would contradict your claim.

### Terms
Molecular splits and baselines: Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
assay: An experimental measurement procedure; conditions and units matter when comparing biological results.
scaffold: In chemistry, a molecular core used in some grouping/splitting strategies; in software, a starter structure to extend.

### Lab
Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks. CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python molecules.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks.

2. Prepare the project inputs
Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
RDKit install fails: use a supported Python version and the official install guide.
Invalid molecule: quarantine and document it rather than forcing a parse.
Inflated result: inspect canonical duplicates, scaffolds and assay shift.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.

### Portfolio
Build a molecular-property baseline with chemical validity and leakage-aware evaluation.
Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.
Deliverables: RDKit featurization and scaffold-split code; Dataset/model cards. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI for biology / drug discovery. Use this scenario: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Review: Start with the task and permitted scope. Explain molecular splits and baselines: Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions. Show the input and observed output, then address Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [RDKit featurization and scaffold-split code; Dataset/model cards. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Responsible scientific conclusions

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Responsible scientific conclusions
Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy.
Mental model: A map points to places to explore; it does not prove what will be found there.
Boundary: No course result supports human use, treatment claims or bypassing laboratory oversight.
Worked example: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Molecular property modeling with scaffold validation
Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Inspect applicability domain, activity cliffs and uncertainty. Write a model card linking target, units, assay conditions and known sources of bias.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.
Worked example: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Recall: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. Identify one observation that would contradict your claim.

### Terms
Responsible scientific conclusions: Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
assay: An experimental measurement procedure; conditions and units matter when comparing biological results.
scaffold: In chemistry, a molecular core used in some grouping/splitting strategies; in software, a starter structure to extend.

### Lab
Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks. CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python molecules.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks.

2. Prepare the project inputs
Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Inspect applicability domain, activity cliffs and uncertainty. Write a model card linking target, units, assay conditions and known sources of bias.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
RDKit install fails: use a supported Python version and the official install guide.
Invalid molecule: quarantine and document it rather than forcing a parse.
Inflated result: inspect canonical duplicates, scaffolds and assay shift.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.

### Portfolio
Build a molecular-property baseline with chemical validity and leakage-aware evaluation.
Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Inspect applicability domain, activity cliffs and uncertainty. Write a model card linking target, units, assay conditions and known sources of bias.
Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.
Validate on a separate measurement source and discuss assay shift before making scientific claims.
Deliverables: RDKit featurization and scaffold-split code; Dataset/model cards; Leakage and applicability-domain report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A reviewer must reproduce one result and identify which capabilities you implemented. Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.

### Interview
Explain your advanced solution for AI for biology / drug discovery. Use this scenario: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Review: Start with the task and permitted scope. Explain responsible scientific conclusions: Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy. Show the input and observed output, then address Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [RDKit featurization and scaffold-split code; Dataset/model cards; Leakage and applicability-domain report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
RDKit — Open source
Molecule parsing, descriptors and scaffold-aware validation.
Alternative: Open Babel (open source) for selected cheminformatics tasks; molecular representations and outputs require domain validation.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

scikit-learn — Open source · CPU
Pipelines, baselines, data splits and statistical evaluation.
Alternative: XGBoost (open source) for tree-based tasks or PyTorch for neural models; begin with a simple comparable baseline.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
RDKit: https://www.rdkit.org/docs/GettingStartedInPython.html
scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
RDKit documentation: https://www.rdkit.org/docs/
scikit-learn: https://scikit-learn.org/stable/user_guide.html
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
