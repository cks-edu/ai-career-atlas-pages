## intermediate — Molecular splits and baselines

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Relevant scientific training plus statistical modeling; many discovery-scientist roles require postgraduate research.

### Molecular splits and baselines
Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions.
Mental model: Testing on a close relative of every training example can make an exam too easy.
Boundary: A scaffold split addresses one generalization concern, not every source of bias.
Worked example: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Molecular property modeling with scaffold validation
Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.
Worked example: Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Recall: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. Identify one observation that would contradict your claim.

### Terms
Molecular splits and baselines: Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
assay: An experimental measurement procedure; conditions and units matter when comparing biological results.
scaffold: In chemistry, a molecular core used in some grouping/splitting strategies; in software, a starter structure to extend.

### Lab
Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks. CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python molecules.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks.

2. Prepare the project inputs
Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
RDKit install fails: use a supported Python version and the official install guide.
Invalid molecule: quarantine and document it rather than forcing a parse.
Inflated result: inspect canonical duplicates, scaffolds and assay shift.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.

### Portfolio
Build a molecular-property baseline with chemical validity and leakage-aware evaluation.
Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.
Deliverables: RDKit featurization and scaffold-split code; Dataset/model cards. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI for biology / drug discovery. Use this scenario: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Review: Start with the task and permitted scope. Explain molecular splits and baselines: Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions. Show the input and observed output, then address Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [RDKit featurization and scaffold-split code; Dataset/model cards. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

