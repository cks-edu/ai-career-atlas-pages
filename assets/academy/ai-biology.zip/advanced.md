## advanced — Responsible scientific conclusions

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Responsible scientific conclusions
Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy.
Mental model: A map points to places to explore; it does not prove what will be found there.
Boundary: No course result supports human use, treatment claims or bypassing laboratory oversight.
Worked example: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Molecular property modeling with scaffold validation
Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Inspect applicability domain, activity cliffs and uncertainty. Write a model card linking target, units, assay conditions and known sources of bias.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.
Worked example: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Recall: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. Identify one observation that would contradict your claim.

### Terms
Responsible scientific conclusions: Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
assay: An experimental measurement procedure; conditions and units matter when comparing biological results.
scaffold: In chemistry, a molecular core used in some grouping/splitting strategies; in software, a starter structure to extend.

### Lab
Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks. CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python molecules.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks.

2. Prepare the project inputs
Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Inspect applicability domain, activity cliffs and uncertainty. Write a model card linking target, units, assay conditions and known sources of bias.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
RDKit install fails: use a supported Python version and the official install guide.
Invalid molecule: quarantine and document it rather than forcing a parse.
Inflated result: inspect canonical duplicates, scaffolds and assay shift.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.

### Portfolio
Build a molecular-property baseline with chemical validity and leakage-aware evaluation.
Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.
Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.
Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.
Inspect applicability domain, activity cliffs and uncertainty. Write a model card linking target, units, assay conditions and known sources of bias.
Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.
Validate on a separate measurement source and discuss assay shift before making scientific claims.
Deliverables: RDKit featurization and scaffold-split code; Dataset/model cards; Leakage and applicability-domain report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A reviewer must reproduce one result and identify which capabilities you implemented. Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.

### Interview
Explain your advanced solution for AI for biology / drug discovery. Use this scenario: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.
Review: Start with the task and permitted scope. Explain responsible scientific conclusions: Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy. Show the input and observed output, then address Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [RDKit featurization and scaffold-split code; Dataset/model cards; Leakage and applicability-domain report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

