# AI for biology / drug discovery — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Scientific endpoints and provenance: Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

assay: An experimental measurement procedure; conditions and units matter when comparing biological results.

scaffold: In chemistry, a molecular core used in some grouping/splitting strategies; in software, a starter structure to extend.

### Scientific endpoints and provenance

Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions. In this role, work through: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Two thermometers are comparable only when you know what and how they measured.

Boundary: A computational prediction is not experimental or clinical validation.

Worked example: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: RDKit (Open source); scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI for biology / drug discovery: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy.

Predict the worked case

Read this case without running a tool: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in scientific endpoints and provenance.

Connect the concept to the role

Apply this rule: Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A computational prediction is not experimental or clinical validation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies scientific endpoints and provenance to this case: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Scientific endpoints and provenance; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with scientific endpoints and provenance. Use the glossary below, then write your prediction for: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for biology / drug discovery role interview. Explain scientific endpoints and provenance using this case: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate scientific endpoints and provenance to a system or workflow you know. Explain scientific endpoints and provenance using this case: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain scientific endpoints and provenance using this case: Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy.

Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions. — Define the biological endpoint, assay context and data origin before modeling. Similar column names can represent different experimental conditions. A computational prediction is not experimental or clinical validation.

Sources:

RDKit: https://www.rdkit.org/docs/GettingStartedInPython.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

RDKit documentation: https://www.rdkit.org/docs/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Diagnose: A scaffold appears in both partitions

The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Three evaluations leak scaffold families and overstate out-of-family generalization. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild scaffold-aware splits before fitting preprocessing and comparing models. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Two thermometers are comparable only when you know what and how they measured.

Do not combine activity values from different assays without recording units, conditions and a defensible normalization strategy.

Worked example: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild scaffold-aware splits before fitting preprocessing and comparing models.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: RDKit (Open source); scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Three evaluations leak scaffold families and overstate out-of-family generalization. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Apply this toy-case rule manually: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A prediction target must match the actual experiment. Conditions and repeated measurements affect what a result means.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine predicting growth of a harmless fictional culture after 24 hours. Define the measurement unit, temperature and starting amount.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An experimental data dictionary and a comparability checklist.

Preparation · Try step 2

Create a blank table for sample ID, conditions, repeat number and measured outcome.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An experimental data dictionary and a comparability checklist.

Preparation · Try step 3

List factors that would make rows incomparable and questions for a qualified subject reviewer.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An experimental data dictionary and a comparability checklist.

Preparation · Explain and check your result

The target and conditions are explicit; this paper exercise does not claim biological validity or instruct a wet-lab procedure. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: An experimental data dictionary and a comparability checklist. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Apply this toy-case rule manually: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three evaluations leak scaffold families and overstate out-of-family generalization. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three evaluations leak scaffold families and overstate out-of-family generalization. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a scaffold appears in both partitions. Use the glossary below, then write your prediction for: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild scaffold-aware splits before fitting preprocessing and comparing models. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for biology / drug discovery role interview. Explain diagnose: a scaffold appears in both partitions using this case: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild scaffold-aware splits before fitting preprocessing and comparing models. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a scaffold appears in both partitions to a system or workflow you know. Explain diagnose: a scaffold appears in both partitions using this case: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild scaffold-aware splits before fitting preprocessing and comparing models. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report performance by chemical domain and assay conditions; involve a qualified scientific reviewer. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a scaffold appears in both partitions using this case: Review when shared_scaffolds >= 1 (count). This is a declared toy-case contract, not an industry standard. Rebuild scaffold-aware splits before fitting preprocessing and comparing models. State the evidence, one alternative and where the mental model stops.

Quiz: A scaffold appears in both partitions: The molecular-property protocol forbids the same scaffold family in training and held-out evaluation.

Change the acceptance rule after seeing an inconvenient result.

Rebuild scaffold-aware splits before fitting preprocessing and comparing models.

Omit failed cases and report only the successful demonstrations.

Reference: Rebuild scaffold-aware splits before fitting preprocessing and comparing models. — Rebuild scaffold-aware splits before fitting preprocessing and comparing models. Report performance by chemical domain and assay conditions; involve a qualified scientific reviewer.

Sources:

RDKit: https://www.rdkit.org/docs/GettingStartedInPython.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

RDKit documentation: https://www.rdkit.org/docs/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Relevant scientific training plus statistical modeling; many discovery-scientist roles require postgraduate research.

Terms:

Molecular splits and baselines: Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

assay: An experimental measurement procedure; conditions and units matter when comparing biological results.

scaffold: In chemistry, a molecular core used in some grouping/splitting strategies; in software, a starter structure to extend.

### Molecular splits and baselines

Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions. In this role, work through: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Testing on a close relative of every training example can make an exam too easy.

Boundary: A scaffold split addresses one generalization concern, not every source of bias.

Worked example: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Relevant scientific training plus statistical modeling; many discovery-scientist roles require postgraduate research.

Tools for this exercise: Document or text editor

Course tool and framework map: RDKit (Open source); scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI for biology / drug discovery: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data.

Predict the worked case

Read this case without running a tool: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in molecular splits and baselines.

Connect the concept to the role

Apply this rule: Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A scaffold split addresses one generalization concern, not every source of bias.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies molecular splits and baselines to this case: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Molecular splits and baselines; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with molecular splits and baselines. Use the glossary below, then write your prediction for: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for biology / drug discovery role interview. Explain molecular splits and baselines using this case: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate molecular splits and baselines to a system or workflow you know. Explain molecular splits and baselines using this case: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain molecular splits and baselines using this case: Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data.

Treat a passing starter as proof of the whole role workflow.

Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions.

Ignore the failure because the tool produced an output.

Reference: Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions. — Use representations and splits that test the intended generalization. Compare simple baselines and inspect duplicate compounds or related scaffolds across partitions. A scaffold split addresses one generalization concern, not every source of bias.

Sources:

RDKit: https://www.rdkit.org/docs/GettingStartedInPython.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

RDKit documentation: https://www.rdkit.org/docs/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Integrate: Molecular property modeling with scaffold validation

Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines. In this role, work through: Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.

Role application: Testing on a close relative of every training example can make an exam too easy.

Compare a random split with a scaffold-based split and report how the conclusion changes, using authorized public data.

Worked example: Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.

Setup: Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: RDKit (Open source); scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional)

Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks. CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.

Build a molecular-property baseline with chemical validity and leakage-aware evaluation.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python molecules.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks.

Prepare the project inputs

Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The molecular-property protocol forbids the same scaffold family in training and held-out evaluation. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.

Deliverable: lesson-intermediate-2.md: RDKit featurization and scaffold-split code; Dataset/model cards. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: molecular property modeling with scaffold validation. Use the glossary below, then write your prediction for: Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for biology / drug discovery role interview. Explain integrate: molecular property modeling with scaffold validation using this case: Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: molecular property modeling with scaffold validation to a system or workflow you know. Explain integrate: molecular property modeling with scaffold validation using this case: Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. Identify one observation that would contradict your claim.

Interview: Explain integrate: molecular property modeling with scaffold validation using this case: Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Molecular property modeling with scaffold validation at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.

Reference: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. — Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.

Sources:

RDKit: https://www.rdkit.org/docs/GettingStartedInPython.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

RDKit documentation: https://www.rdkit.org/docs/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Responsible scientific conclusions: Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

assay: An experimental measurement procedure; conditions and units matter when comparing biological results.

scaffold: In chemistry, a molecular core used in some grouping/splitting strategies; in software, a starter structure to extend.

### Responsible scientific conclusions

Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy. In this role, work through: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A map points to places to explore; it does not prove what will be found there.

Boundary: No course result supports human use, treatment claims or bypassing laboratory oversight.

Worked example: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: RDKit (Open source); scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI for biology / drug discovery: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review.

Predict the worked case

Read this case without running a tool: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in responsible scientific conclusions.

Connect the concept to the role

Apply this rule: Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: No course result supports human use, treatment claims or bypassing laboratory oversight.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies responsible scientific conclusions to this case: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Responsible scientific conclusions; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with responsible scientific conclusions. Use the glossary below, then write your prediction for: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for biology / drug discovery role interview. Explain responsible scientific conclusions using this case: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate responsible scientific conclusions to a system or workflow you know. Explain responsible scientific conclusions using this case: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain responsible scientific conclusions using this case: A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy.

Reference: Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy. — Report prediction uncertainty, applicability limits and evidence needed for further investigation. Keep computational hypotheses separate from claims of safety or efficacy. No course result supports human use, treatment claims or bypassing laboratory oversight.

Sources:

RDKit: https://www.rdkit.org/docs/GettingStartedInPython.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

RDKit documentation: https://www.rdkit.org/docs/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Defend: Molecular property modeling with scaffold validation

Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Inspect applicability domain, activity cliffs and uncertainty. Write a model card linking target, units, assay conditions and known sources of bias. In this role, work through: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.

Role application: A map points to places to explore; it does not prove what will be found there.

A candidate ranks highly in the model; label it a computational hypothesis and document required independent experimental review.

Worked example: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.

Setup: Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: RDKit (Open source); scikit-learn (Open source · CPU); MLflow (Open source · hosted offerings optional)

Build a molecular-property baseline with chemical validity and leakage-aware evaluation. Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks. CPU-only parser baseline. No biological experiment, therapeutic recommendation or efficacy result is supplied.

Build a molecular-property baseline with chemical validity and leakage-aware evaluation.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use a supported Python environment and RDKit; scientific interpretation requires appropriate domain knowledge. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python molecules.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Four SMILES parsing examples with canonicalization and molecular weights, including an invalid input. Dataset acquisition, scaffold splits and modeling are advanced tasks.

Prepare the project inputs

Use the bundled SMILES sanity fixtures, then select a licensed molecular-property dataset with documented assay/measurement context. Do not infer therapeutic efficacy from a proxy target.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run molecules.py to parse SMILES and compute descriptors with RDKit. Log invalid molecules and avoid silently dropping them from the denominator.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create scaffold-based train/validation/test splits and compare with a random split as a diagnostic. Fit preprocessing on training data only and compare simple baselines.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Inspect applicability domain, activity cliffs and uncertainty. Write a model card linking target, units, assay conditions and known sources of bias.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. A reviewer must reproduce one result and identify which capabilities you implemented. Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: The probe exits without writing external data. Preserve dataset licenses and the invalid-input report.

Deliverable: lesson-advanced-2.md: RDKit featurization and scaffold-split code; Dataset/model cards; Leakage and applicability-domain report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: molecular property modeling with scaffold validation. Use the glossary below, then write your prediction for: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI for biology / drug discovery role interview. Explain defend: molecular property modeling with scaffold validation using this case: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: molecular property modeling with scaffold validation to a system or workflow you know. Explain defend: molecular property modeling with scaffold validation using this case: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy. Identify one observation that would contradict your claim.

Interview: Explain defend: molecular property modeling with scaffold validation using this case: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Molecular property modeling with scaffold validation at this level?

Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs. — Insert duplicate structures under different SMILES strings and an invalid molecule. Canonicalize for duplicate detection and quarantine invalid inputs. Report metrics by scaffold novelty, invalid rate and split overlap. This is a computational methods portfolio, not evidence of drug safety or efficacy.

Sources:

RDKit: https://www.rdkit.org/docs/GettingStartedInPython.html

scikit-learn: https://scikit-learn.org/stable/common_pitfalls.html

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

RDKit documentation: https://www.rdkit.org/docs/

scikit-learn: https://scikit-learn.org/stable/user_guide.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
