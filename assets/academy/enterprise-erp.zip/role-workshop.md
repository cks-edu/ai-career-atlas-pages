# ERP / SAP Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Procurement objects and approval authority

A purchase request expresses intent; approval authorizes it; receipt records what arrived. Keep quantity, unit price, currency and approver separate. The synthetic policy in this lab requires a different approver from the requester and is not a universal SAP rule.
Mental model: A purchase travels with three documents: the request, the authorization and the delivery receipt.
Case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1.
Task: Open fixture.json and map each field to its business owner. Run the beginner reference, then change PO1 quantity to 3 and update your predicted total before running again. Review the explicit authorization decision separately from arithmetic.
Acceptance: Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture.
Troubleshooting: A correct total does not prove approval was authorized. Inspect requester/approver identity and preserve a rejection reason.
Deliverable: procurement data dictionary, input/output evidence and approval matrix

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Receipts, replay and reconciliation

A receiving event records quantity against a purchase order. Replayed delivery events must not increase received quantity twice, while a new receipt needs its own identity. Match business keys and quantities, not only event counts.
Mental model: A delivery slip has a tracking number; photocopying it must not create another delivery.
Case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline.
Task: Run intermediate, inspect the receipt-ID deduplication and inject --broken to count the replay twice. Repair the event-key check in a copy and add a genuinely new partial receipt with a unique ID.
Acceptance: Baseline received quantity 2; the broken run fails on duplicate receipt accounting.
Troubleshooting: A new random receipt ID on retry defeats deduplication; retain the originating event identity.
Deliverable: receipt reconciliation tests and an integration contract

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Cutover and business recovery

Transporting code/configuration does not undo posted business events. A release rehearsal must reconcile open orders, received quantities and invoice amounts before and after promotion, and define a forward correction for business discrepancies.
Mental model: Changing the forms in the office does not recall goods already delivered.
Case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise.
Task: Run advanced, record the invoice variance and write a cutover checklist with source/target counts, amount totals and open items. In authorized SAP learning access, pair this with an ABAP console exercise and document the chosen product/edition before attempting RAP or transport steps.
Acceptance: The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs.
Troubleshooting: Do not clear a reconciliation failure by changing the expected total without explaining the business correction.
Deliverable: SAP extension/cutover portfolio pack with explicit local-versus-tenant evidence

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
