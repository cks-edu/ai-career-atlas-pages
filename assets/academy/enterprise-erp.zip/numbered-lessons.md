# ERP / SAP Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Acceptance criteria: Describe an observable result that determines whether a requirement has been met.

Business object and process: ERP systems connect business records such as purchase orders to controlled processes. Identify the business meaning and owner of each field before coding.

ERP: Enterprise resource planning: software coordinating business processes and records.

ABAP: SAP programming language used in the authorized ABAP environment exercise.

ADT: ABAP Development Tools: Eclipse-based tools for editing and running ABAP development objects.

RAP: ABAP RESTful Application Programming Model: a model for business objects and services in supported ABAP environments.

Procurement objects and approval authority: A purchase request expresses intent; approval authorizes it; receipt records what arrived. Keep quantity, unit price, currency and approver separate. The synthetic policy in this lab requires a different approver from the requester and is not a universal SAP rule.

### Acceptance criteria

Describe an observable result that determines whether a requirement has been met. In this role, work through: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. The practical workshop develops this into: Open fixture.json and map each field to its business owner. Run the beginner reference, then change PO1 quantity to 3 and update your predicted total before running again. Review the explicit authorization decision separately from arithmetic.

Mental model: A delivery receipt lists what must arrive, not just that a truck drove.

Boundary: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Role application: A purchase travels with three documents: the request, the authorization and the delivery receipt.

A purchase request expresses intent; approval authorizes it; receipt records what arrived. Keep quantity, unit price, currency and approver separate. The synthetic policy in this lab requires a different approver from the requester and is not a universal SAP rule.

Worked example: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1.

Shared foundation example: Given an empty title, submitting a request shows an error and creates no ticket.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: SAP learning environment and platform tools (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for ERP / SAP Developer: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1.

Predict the worked case

Read this case without running a tool: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in acceptance criteria.

Connect the concept to the role

Apply this rule: Describe an observable result that determines whether a requirement has been met. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies acceptance criteria to this case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Acceptance criteria; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with acceptance criteria. Use the glossary below, then write your prediction for: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ERP / SAP Developer role interview. Explain acceptance criteria using this case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate acceptance criteria to a system or workflow you know. Explain acceptance criteria using this case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Turn “make it easier” into a measurable task outcome.

Interview: Explain acceptance criteria using this case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. State the evidence, one alternative and where the mental model stops.

Quiz: After the Procurement objects and approval authority rehearsal, check this foundation: A requirement says “make this workflow easier.” What makes its acceptance testable?

A defined user task and observable result, reviewed with the relevant stakeholder.

A count of implementation files without a user outcome.

A statement that the chosen tool is widely used.

Reference: A defined user task and observable result, reviewed with the relevant stakeholder. — Acceptance criteria describe observable outcomes. Stakeholder review is still needed to ensure the outcome solves the right problem.

Sources:

SAP: first ABAP console application: https://developers.sap.com/tutorials/abap-environment-console-application

SAP: prepare a RAP travel service: https://developers.sap.com/tutorials/fiori-tools-rap-prepare-service

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Procurement objects and approval authority

A purchase request expresses intent; approval authorizes it; receipt records what arrived. Keep quantity, unit price, currency and approver separate. The synthetic policy in this lab requires a different approver from the requester and is not a universal SAP rule. In this role, work through: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. The practical workshop develops this into: Open fixture.json and map each field to its business owner. Run the beginner reference, then change PO1 quantity to 3 and update your predicted total before running again. Review the explicit authorization decision separately from arithmetic.

Mental model: A purchase travels with three documents: the request, the authorization and the delivery receipt.

Boundary: A correct total does not prove approval was authorized. Inspect requester/approver identity and preserve a rejection reason.

Worked example: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SAP learning environment and platform tools (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Open fixture.json and map each field to its business owner. Run the beginner reference, then change PO1 quantity to 3 and update your predicted total before running again. Review the explicit authorization decision separately from arithmetic.

Inspect the business fixture

PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Open fixture.json and map each field to its business owner. Run the beginner reference, then change PO1 quantity to 3 and update your predicted total before running again. Review the explicit authorization decision separately from arithmetic.

```
python3 enterprise_lab.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py beginner --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Authorized SAP setup

Use the linked SAP console tutorial for the ABAP environment requirements and ADT connection. In a permitted development package create your own Z class implementing IF_OO_ADT_CLASSRUN. Run a console calculation for quantity 2 × price 50. Record system edition and access terms; trial capacity and eligibility can vary.

```
CLASS zcl_atlas_lab DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
ENDCLASS.

CLASS zcl_atlas_lab IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.
    DATA quantity TYPE i VALUE 2.
    DATA price TYPE p LENGTH 8 DECIMALS 2 VALUE '50.00'.
    DATA total TYPE p LENGTH 8 DECIMALS 2.
    total = quantity * price.
    out->write( total ).
  ENDMETHOD.
ENDCLASS.

```

ABAP source, not a terminal command. Create the same class name in your own permitted package, paste into its editor, activate and run as an ABAP console application. Rename the class consistently if the name is occupied. Expected formatted amount: 100.00 (display formatting may vary).

Expected: Console displays 100 and the package/class identifiers are recorded. This does not post a purchase order.

Assemble the portfolio evidence

Create procurement data dictionary, input/output evidence and approval matrix. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture.

Expected: Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture.

Troubleshoot: The role exercise differs from the prediction: A correct total does not prove approval was authorized. Inspect requester/approver identity and preserve a rejection reason.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-beginner-2.md: procurement data dictionary, input/output evidence and approval matrix; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with procurement objects and approval authority. Use the glossary below, then write your prediction for: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ERP / SAP Developer role interview. Explain procurement objects and approval authority using this case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate procurement objects and approval authority to a system or workflow you know. Explain procurement objects and approval authority using this case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A correct total does not prove approval was authorized. Inspect requester/approver identity and preserve a rejection reason.

Interview: Explain procurement objects and approval authority using this case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1.

Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture. — A purchase request expresses intent; approval authorizes it; receipt records what arrived. Keep quantity, unit price, currency and approver separate. The synthetic policy in this lab requires a different approver from the requester and is not a universal SAP rule. Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture.

Sources:

SAP: first ABAP console application: https://developers.sap.com/tutorials/abap-environment-console-application

SAP: prepare a RAP travel service: https://developers.sap.com/tutorials/fiori-tools-rap-prepare-service

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Traceability: Connect a user need to the proposed change, its test and its evidence.

Extension and integration boundary: An extension adds behavior without assuming that modifying the vendor core is safe. Define supported APIs, validation and error handling.

ERP: Enterprise resource planning: software coordinating business processes and records.

ABAP: SAP programming language used in the authorized ABAP environment exercise.

ADT: ABAP Development Tools: Eclipse-based tools for editing and running ABAP development objects.

RAP: ABAP RESTful Application Programming Model: a model for business objects and services in supported ABAP environments.

Receipts, replay and reconciliation: A receiving event records quantity against a purchase order. Replayed delivery events must not increase received quantity twice, while a new receipt needs its own identity. Match business keys and quantities, not only event counts.

### Traceability

Connect a user need to the proposed change, its test and its evidence. In this role, work through: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. The practical workshop develops this into: Run intermediate, inspect the receipt-ID deduplication and inject --broken to count the replay twice. Repair the event-key check in a copy and add a genuinely new partial receipt with a unique ID.

Mental model: Labels connect a parcel to its order and delivery receipt.

Boundary: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Role application: A delivery slip has a tracking number; photocopying it must not create another delivery.

A receiving event records quantity against a purchase order. Replayed delivery events must not increase received quantity twice, while a new receipt needs its own identity. Match business keys and quantities, not only event counts.

Worked example: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline.

Shared foundation example: Need R1 points to screen S1, test T1 and a recorded observation.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: SAP learning environment and platform tools (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for ERP / SAP Developer: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline.

Predict the worked case

Read this case without running a tool: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in traceability.

Connect the concept to the role

Apply this rule: Connect a user need to the proposed change, its test and its evidence. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies traceability to this case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Traceability; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with traceability. Use the glossary below, then write your prediction for: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ERP / SAP Developer role interview. Explain traceability using this case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate traceability to a system or workflow you know. Explain traceability using this case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you identify which tests are affected by a changed requirement?

Interview: Explain traceability using this case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. State the evidence, one alternative and where the mental model stops.

Quiz: After the Receipts, replay and reconciliation rehearsal, check this foundation: A requirement changes. What evidence helps identify affected checks?

The total number of screenshots in the project.

Links from the requirement to its design, test cases and recorded results.

Only the latest file modification time.

Reference: Links from the requirement to its design, test cases and recorded results. — Traceability connects a need to the change and its verification; documents without those links do not establish impact.

Sources:

SAP: first ABAP console application: https://developers.sap.com/tutorials/abap-environment-console-application

SAP: prepare a RAP travel service: https://developers.sap.com/tutorials/fiori-tools-rap-prepare-service

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Receipts, replay and reconciliation

A receiving event records quantity against a purchase order. Replayed delivery events must not increase received quantity twice, while a new receipt needs its own identity. Match business keys and quantities, not only event counts. In this role, work through: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. The practical workshop develops this into: Run intermediate, inspect the receipt-ID deduplication and inject --broken to count the replay twice. Repair the event-key check in a copy and add a genuinely new partial receipt with a unique ID.

Mental model: A delivery slip has a tracking number; photocopying it must not create another delivery.

Boundary: A new random receipt ID on retry defeats deduplication; retain the originating event identity.

Worked example: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SAP learning environment and platform tools (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run intermediate, inspect the receipt-ID deduplication and inject --broken to count the replay twice. Repair the event-key check in a copy and add a genuinely new partial receipt with a unique ID.

Inspect the business fixture

Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run intermediate, inspect the receipt-ID deduplication and inject --broken to count the replay twice. Repair the event-key check in a copy and add a genuinely new partial receipt with a unique ID.

```
python3 enterprise_lab.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Baseline received quantity 2; the broken run fails on duplicate receipt accounting.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py intermediate --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · ABAP integration extension

Port the receipt-ID deduplication rule to an internal table and add duplicate/new receipt cases. For a RAP UI, follow the separate SAP travel-service tutorial in its documented environment before adapting a business object. Do not assume the tutorial object is a real procurement API.

Expected: A duplicate receipt has no second effect in your test; supported APIs and authorization checks for a real integration are listed separately.

Assemble the portfolio evidence

Create receipt reconciliation tests and an integration contract. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: Baseline received quantity 2; the broken run fails on duplicate receipt accounting.

Expected: Baseline received quantity 2; the broken run fails on duplicate receipt accounting.

Troubleshoot: The role exercise differs from the prediction: A new random receipt ID on retry defeats deduplication; retain the originating event identity.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-intermediate-2.md: receipt reconciliation tests and an integration contract; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with receipts, replay and reconciliation. Use the glossary below, then write your prediction for: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ERP / SAP Developer role interview. Explain receipts, replay and reconciliation using this case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate receipts, replay and reconciliation to a system or workflow you know. Explain receipts, replay and reconciliation using this case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A new random receipt ID on retry defeats deduplication; retain the originating event identity.

Interview: Explain receipts, replay and reconciliation using this case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline.

Ignore the failing case and keep only the successful screenshot.

Baseline received quantity 2; the broken run fails on duplicate receipt accounting.

Treat any successful command as proof that all business and access rules passed.

Reference: Baseline received quantity 2; the broken run fails on duplicate receipt accounting. — A receiving event records quantity against a purchase order. Replayed delivery events must not increase received quantity twice, while a new receipt needs its own identity. Match business keys and quantities, not only event counts. Baseline received quantity 2; the broken run fails on duplicate receipt accounting.

Sources:

SAP: first ABAP console application: https://developers.sap.com/tutorials/abap-environment-console-application

SAP: prepare a RAP travel service: https://developers.sap.com/tutorials/fiori-tools-rap-prepare-service

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Release decision and ownership: Document the evidence, remaining risk, responsible owner and recovery trigger for a change.

Transport and reconciliation: Promote reviewed changes between environments and compare business totals before and after a cutover.

ERP: Enterprise resource planning: software coordinating business processes and records.

ABAP: SAP programming language used in the authorized ABAP environment exercise.

ADT: ABAP Development Tools: Eclipse-based tools for editing and running ABAP development objects.

RAP: ABAP RESTful Application Programming Model: a model for business objects and services in supported ABAP environments.

Cutover and business recovery: Transporting code/configuration does not undo posted business events. A release rehearsal must reconcile open orders, received quantities and invoice amounts before and after promotion, and define a forward correction for business discrepancies.

### Release decision and ownership

Document the evidence, remaining risk, responsible owner and recovery trigger for a change. In this role, work through: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. The practical workshop develops this into: Run advanced, record the invoice variance and write a cutover checklist with source/target counts, amount totals and open items. In authorized SAP learning access, pair this with an ABAP console exercise and document the chosen product/edition before attempting RAP or transport steps.

Mental model: A flight checklist has an accountable pilot and reasons to delay departure.

Boundary: A checklist supports judgment; it does not transfer accountability to a tool.

Role application: Changing the forms in the office does not recall goods already delivered.

Transporting code/configuration does not undo posted business events. A release rehearsal must reconcile open orders, received quantities and invoice amounts before and after promotion, and define a forward correction for business discrepancies.

Worked example: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise.

Shared foundation example: Hold a release if unauthorized users can export records, even if basic navigation works.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: SAP learning environment and platform tools (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for ERP / SAP Developer: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise.

Predict the worked case

Read this case without running a tool: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in release decision and ownership.

Connect the concept to the role

Apply this rule: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A checklist supports judgment; it does not transfer accountability to a tool.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies release decision and ownership to this case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Release decision and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with release decision and ownership. Use the glossary below, then write your prediction for: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ERP / SAP Developer role interview. Explain release decision and ownership using this case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate release decision and ownership to a system or workflow you know. Explain release decision and ownership using this case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would make a conditional approval expire?

Interview: Explain release decision and ownership using this case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. State the evidence, one alternative and where the mental model stops.

Quiz: After the Cutover and business recovery rehearsal, check this foundation: A release has a known access-control defect but basic navigation passes. What should the decision include?

Only the navigation pass count.

An anonymous approval with no recovery trigger.

The defect evidence, impact, accountable owner and explicit release or hold criteria.

Reference: The defect evidence, impact, accountable owner and explicit release or hold criteria. — A release decision needs evidence and ownership. Basic checks do not cancel a serious unresolved risk.

Sources:

SAP: first ABAP console application: https://developers.sap.com/tutorials/abap-environment-console-application

SAP: prepare a RAP travel service: https://developers.sap.com/tutorials/fiori-tools-rap-prepare-service

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Cutover and business recovery

Transporting code/configuration does not undo posted business events. A release rehearsal must reconcile open orders, received quantities and invoice amounts before and after promotion, and define a forward correction for business discrepancies. In this role, work through: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. The practical workshop develops this into: Run advanced, record the invoice variance and write a cutover checklist with source/target counts, amount totals and open items. In authorized SAP learning access, pair this with an ABAP console exercise and document the chosen product/edition before attempting RAP or transport steps.

Mental model: Changing the forms in the office does not recall goods already delivered.

Boundary: Do not clear a reconciliation failure by changing the expected total without explaining the business correction.

Worked example: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: SAP learning environment and platform tools (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. 

Run advanced, record the invoice variance and write a cutover checklist with source/target counts, amount totals and open items. In authorized SAP learning access, pair this with an ABAP console exercise and document the chosen product/edition before attempting RAP or transport steps.

Inspect the business fixture

An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run advanced, record the invoice variance and write a cutover checklist with source/target counts, amount totals and open items. In authorized SAP learning access, pair this with an ABAP console exercise and document the chosen product/edition before attempting RAP or transport steps.

```
python3 enterprise_lab.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py advanced --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · SAP change rehearsal

Identify the transport/change mechanism supported by your SAP edition with the environment owner. Inventory class, data model, authorization and service dependencies; promote only to a permitted test system, rerun receipt/variance cases and reconcile open items. If no second system exists, label this portion a tabletop.

Expected: A manifest and post-change evidence distinguish executed checks from proposed cutover steps.

Assemble the portfolio evidence

Create SAP extension/cutover portfolio pack with explicit local-versus-tenant evidence. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs.

Expected: The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs.

Troubleshoot: The role exercise differs from the prediction: Do not clear a reconciliation failure by changing the expected total without explaining the business correction.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-advanced-2.md: SAP extension/cutover portfolio pack with explicit local-versus-tenant evidence; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cutover and business recovery. Use the glossary below, then write your prediction for: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the ERP / SAP Developer role interview. Explain cutover and business recovery using this case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cutover and business recovery to a system or workflow you know. Explain cutover and business recovery using this case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not clear a reconciliation failure by changing the expected total without explaining the business correction.

Interview: Explain cutover and business recovery using this case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs.

Reference: The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs. — Transporting code/configuration does not undo posted business events. A release rehearsal must reconcile open orders, received quantities and invoice amounts before and after promotion, and define a forward correction for business discrepancies. The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs.

Sources:

SAP: first ABAP console application: https://developers.sap.com/tutorials/abap-environment-console-application

SAP: prepare a RAP travel service: https://developers.sap.com/tutorials/fiori-tools-rap-prepare-service

SAP Learning Journeys: https://learning.sap.com/learning-journeys
