CLASS zcl_atlas_lab DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
ENDCLASS.

CLASS zcl_atlas_lab IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.
    DATA quantity TYPE i VALUE 2.
    DATA price TYPE p LENGTH 8 DECIMALS 2 VALUE '50.00'.
    DATA total TYPE p LENGTH 8 DECIMALS 2.
    total = quantity * price.
    out->write( total ).
  ENDMETHOD.
ENDCLASS.
