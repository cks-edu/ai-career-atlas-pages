# ERP / SAP Developer

Software Engineering

Start with procurement objects and approval authority. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward SAP extension/cutover portfolio pack with explicit local-versus-tenant evidence.

## beginner

Open fixture.json and map each field to its business owner. Run the beginner reference, then change PO1 quantity to 3 and update your predicted total before running again. Review the explicit authorization decision separately from arithmetic.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Procurement objects and approval authority
A purchase request expresses intent; approval authorizes it; receipt records what arrived. Keep quantity, unit price, currency and approver separate. The synthetic policy in this lab requires a different approver from the requester and is not a universal SAP rule.
Mental model: A purchase travels with three documents: the request, the authorization and the delivery receipt.
Limit: A correct total does not prove approval was authorized. Inspect requester/approver identity and preserve a rejection reason.
Example: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A correct total does not prove approval was authorized. Inspect requester/approver identity and preserve a rejection reason.

1. Inspect the business fixture
PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Open fixture.json and map each field to its business owner. Run the beginner reference, then change PO1 quantity to 3 and update your predicted total before running again. Review the explicit authorization decision separately from arithmetic.
```
python3 enterprise_lab.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py beginner --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Authorized SAP setup
Use the linked SAP console tutorial for the ABAP environment requirements and ADT connection. In a permitted development package create your own Z class implementing IF_OO_ADT_CLASSRUN. Run a console calculation for quantity 2 × price 50. Record system edition and access terms; trial capacity and eligibility can vary.
```
CLASS zcl_atlas_lab DEFINITION PUBLIC FINAL CREATE PUBLIC.
  PUBLIC SECTION.
    INTERFACES if_oo_adt_classrun.
ENDCLASS.

CLASS zcl_atlas_lab IMPLEMENTATION.
  METHOD if_oo_adt_classrun~main.
    DATA quantity TYPE i VALUE 2.
    DATA price TYPE p LENGTH 8 DECIMALS 2 VALUE '50.00'.
    DATA total TYPE p LENGTH 8 DECIMALS 2.
    total = quantity * price.
    out->write( total ).
  ENDMETHOD.
ENDCLASS.

```
ABAP source, not a terminal command. Create the same class name in your own permitted package, paste into its editor, activate and run as an ABAP console application. Rename the class consistently if the name is occupied. Expected formatted amount: 100.00 (display formatting may vary).
Expected: Console displays 100 and the package/class identifiers are recorded. This does not post a purchase order.

6. Assemble the portfolio evidence
Create procurement data dictionary, input/output evidence and approval matrix. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: A correct total does not prove approval was authorized. Inspect requester/approver identity and preserve a rejection reason.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: procurement data dictionary, input/output evidence and approval matrix
Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture.

Interview: Work through this ERP / SAP Developer case: PO1 requests 2 units at 50 each: total 100. PO2 has quantity -1 and is rejected. The requester cannot approve PO1. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A purchase request expresses intent; approval authorizes it; receipt records what arrived. Keep quantity, unit price, currency and approver separate. The synthetic policy in this lab requires a different approver from the requester and is not a universal SAP rule. Expected evidence: Baseline total 100; PO2 rejected; self-approval denied. Changed quantity produces total 150 in the model, so the baseline assertion intentionally needs a revised expected fixture. Diagnosis: A correct total does not prove approval was authorized. Inspect requester/approver identity and preserve a rejection reason. State the limits of the mental model: A purchase travels with three documents: the request, the authorization and the delivery receipt.

Resume: Built procurement data dictionary, input/output evidence and approval matrix using SAP learning environment and platform tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Run intermediate, inspect the receipt-ID deduplication and inject --broken to count the replay twice. Repair the event-key check in a copy and add a genuinely new partial receipt with a unique ID.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Receipts, replay and reconciliation
A receiving event records quantity against a purchase order. Replayed delivery events must not increase received quantity twice, while a new receipt needs its own identity. Match business keys and quantities, not only event counts.
Mental model: A delivery slip has a tracking number; photocopying it must not create another delivery.
Limit: A new random receipt ID on retry defeats deduplication; retain the originating event identity.
Example: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A new random receipt ID on retry defeats deduplication; retain the originating event identity.

1. Inspect the business fixture
Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run intermediate, inspect the receipt-ID deduplication and inject --broken to count the replay twice. Repair the event-key check in a copy and add a genuinely new partial receipt with a unique ID.
```
python3 enterprise_lab.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Baseline received quantity 2; the broken run fails on duplicate receipt accounting.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py intermediate --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · ABAP integration extension
Port the receipt-ID deduplication rule to an internal table and add duplicate/new receipt cases. For a RAP UI, follow the separate SAP travel-service tutorial in its documented environment before adapting a business object. Do not assume the tutorial object is a real procurement API.
Expected: A duplicate receipt has no second effect in your test; supported APIs and authorization checks for a real integration are listed separately.

6. Assemble the portfolio evidence
Create receipt reconciliation tests and an integration contract. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: Baseline received quantity 2; the broken run fails on duplicate receipt accounting.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: A new random receipt ID on retry defeats deduplication; retain the originating event identity.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: receipt reconciliation tests and an integration contract
Baseline received quantity 2; the broken run fails on duplicate receipt accounting.

Interview: Work through this ERP / SAP Developer case: Receipt r1 for PO1 arrives twice; only 2 units are received in the baseline. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A receiving event records quantity against a purchase order. Replayed delivery events must not increase received quantity twice, while a new receipt needs its own identity. Match business keys and quantities, not only event counts. Expected evidence: Baseline received quantity 2; the broken run fails on duplicate receipt accounting. Diagnosis: A new random receipt ID on retry defeats deduplication; retain the originating event identity. State the limits of the mental model: A delivery slip has a tracking number; photocopying it must not create another delivery.

Resume: Built receipt reconciliation tests and an integration contract using SAP learning environment and platform tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run advanced, record the invoice variance and write a cutover checklist with source/target counts, amount totals and open items. In authorized SAP learning access, pair this with an ABAP console exercise and document the chosen product/edition before attempting RAP or transport steps.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Cutover and business recovery
Transporting code/configuration does not undo posted business events. A release rehearsal must reconcile open orders, received quantities and invoice amounts before and after promotion, and define a forward correction for business discrepancies.
Mental model: Changing the forms in the office does not recall goods already delivered.
Limit: Do not clear a reconciliation failure by changing the expected total without explaining the business correction.
Example: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not clear a reconciliation failure by changing the expected total without explaining the business correction.

1. Inspect the business fixture
An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. Open fixture.json, identify keys, dates and invalid rows, and write your prediction before reading expected.json.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run advanced, record the invoice variance and write a cutover checklist with source/target counts, amount totals and open items. In authorized SAP learning access, pair this with an ABAP console exercise and document the chosen product/edition before attempting RAP or transport steps.
```
python3 enterprise_lab.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py advanced --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · SAP change rehearsal
Identify the transport/change mechanism supported by your SAP edition with the environment owner. Inventory class, data model, authorization and service dependencies; promote only to a permitted test system, rerun receipt/variance cases and reconcile open items. If no second system exists, label this portion a tabletop.
Expected: A manifest and post-change evidence distinguish executed checks from proposed cutover steps.

6. Assemble the portfolio evidence
Create SAP extension/cutover portfolio pack with explicit local-versus-tenant evidence. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: Do not clear a reconciliation failure by changing the expected total without explaining the business correction.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: SAP extension/cutover portfolio pack with explicit local-versus-tenant evidence
The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs.

Interview: Work through this ERP / SAP Developer case: An invoice for 120 against an approved amount of 100 creates a variance of 20 and a review hold in this exercise. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Transporting code/configuration does not undo posted business events. A release rehearsal must reconcile open orders, received quantities and invoice amounts before and after promotion, and define a forward correction for business discrepancies. Expected evidence: The mismatch remains visible and is held for review; no automatic posting or production SAP change occurs. Diagnosis: Do not clear a reconciliation failure by changing the expected total without explaining the business correction. State the limits of the mental model: Changing the forms in the office does not recall goods already delivered.

Resume: Built SAP extension/cutover portfolio pack with explicit local-versus-tenant evidence using SAP learning environment and platform tools; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
SAP Learning Journeys: https://learning.sap.com/learning-journeys
SAP: first ABAP console application: https://developers.sap.com/tutorials/abap-environment-console-application
SAP: prepare a RAP travel service: https://developers.sap.com/tutorials/fiori-tools-rap-prepare-service
