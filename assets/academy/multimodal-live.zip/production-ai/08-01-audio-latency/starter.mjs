function audioBudget(stages,jitter,target) { return stages[0] < target; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(audioBudget([40,60,120,80],50,500));
console.log("PASS: Complete path plus reserve fits");
}
{
assert(!audioBudget([100,100,150,100],100,500)); assert(audioBudget([100,100,100,100],100,500));
console.log("PASS: Jitter reserve can exceed the target");
}
{
assert(!audioBudget([40,NaN],50,500)); assert(!audioBudget([40],-1,500));
console.log("PASS: Invalid measurements are not zero");
}
