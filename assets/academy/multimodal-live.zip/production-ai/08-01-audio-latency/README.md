# Audio transport and a measured latency target

Voice interaction includes microphone capture, transport, recognition, model work and speech output. WebRTC provides real-time media capabilities; WebSockets provide ordered bidirectional messages but do not supply a complete audio stack. Choose transport for the actual environment and measure the whole turn.

This worksheet checks a supplied capture-to-audio budget. A sub-500ms target is an illustrative product requirement, not a guarantee made by either transport. Count all measured stages and reserve jitter headroom.

Task: Implement audioBudget and build a stage worksheet. Compare when WebRTC media handling or a WebSocket application protocol is appropriate.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Microphone → transport → recognition/model → speech output.
State: Each stage consumes part of a declared turn budget.
Boundary: A fast model cannot erase capture or network delay.
Failure: Transport and recognition consume the entire conversational budget.
Control: Include all stages and a jitter reserve before accepting the target.
Observability: Measure capture-to-first-audio, turn-end delay and interruptions.
Blast radius: All conversations on the affected path.
Trade-off: Buffering smooths jitter but increases perceived latency.

Limit: Network, devices, turn detection and provider behavior vary. A policy sum is not a real latency measurement or codec implementation.

Sources:
https://developer.mozilla.org/en-US/docs/Web/API/WebRTC_API
https://docs.livekit.io/agents/logic/turns/
