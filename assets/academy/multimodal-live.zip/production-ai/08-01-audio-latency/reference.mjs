function audioBudget(stages, jitter, target) {
  return Array.isArray(stages) && [...stages,jitter,target].every(n=>Number.isFinite(n) && n>=0) && stages.reduce((a,b)=>a+b,0)+jitter <= target;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(audioBudget([40,60,120,80],50,500));
console.log("PASS: Complete path plus reserve fits");
}
{
assert(!audioBudget([100,100,150,100],100,500)); assert(audioBudget([100,100,100,100],100,500));
console.log("PASS: Jitter reserve can exceed the target");
}
{
assert(!audioBudget([40,NaN],50,500)); assert(!audioBudget([40],-1,500));
console.log("PASS: Invalid measurements are not zero");
}
