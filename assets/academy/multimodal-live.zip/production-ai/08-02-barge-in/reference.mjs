function handleAudioEvent(state, event) {
  if (event.type !== 'USER_SPEECH_START') return state;
  return {...state,ttsQueue:[],assistantDraft:'',status:'listening'};
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(handleAudioEvent({ttsQueue:['a'],assistantDraft:'draft'},{type:'USER_SPEECH_START'}).ttsQueue.length===0);
console.log("PASS: Barge-in clears queued speech");
}
{
const r=handleAudioEvent({ttsQueue:['a'],assistantDraft:'unsaid',committed:['spoken']},{type:'USER_SPEECH_START'}); assert(r.assistantDraft==='' && r.committed[0]==='spoken' && r.status==='listening');
console.log("PASS: Draft is removed; committed text remains");
}
{
const s={ttsQueue:['a'],assistantDraft:'draft',status:'speaking'}; assert(handleAudioEvent(s,{type:'NOISE'}).ttsQueue.length===1 && handleAudioEvent(s,{type:'NOISE'}).status==='speaking');
console.log("PASS: Unrelated events do not destroy state");
}
