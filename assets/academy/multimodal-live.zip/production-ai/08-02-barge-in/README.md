# Barge-in: stop audio and keep transcript state honest

When a person starts speaking, the assistant may need to stop its own speech immediately. Clearing the visible transcript alone leaves queued audio playing. Coordinate output cancellation and transcript state so unsaid draft text is not recorded as a completed assistant turn.

On USER_SPEECH_START the reducer clears outbound TTS, removes the uncommitted draft and enters listening. Committed transcript remains. Real audio playback also needs an actual stop/flush call and cancellation of in-flight generation.

Task: Implement handleAudioEvent. Add a late audio packet case in your extension using a turn ID, and document the actual playback stop action.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Speech-start signal → stop playback → clear draft → listening.
State: Audio queue, committed transcript and draft have separate ownership.
Boundary: Unspoken generated text is not a committed assistant turn.
Failure: The queue keeps speaking after the user interrupts.
Control: Flush outbound TTS and truncate only uncommitted assistant state.
Observability: Trace interruption time, playback stop and late-packet drops.
Blast radius: The current conversation turn.
Trade-off: Sensitive detection supports interruption but may react to background noise.

Limit: The reducer does not access a microphone or stop a real audio device. False speech detections and late packets need separately measured policies.

Sources:
https://docs.livekit.io/agents/logic/turns/
https://developer.mozilla.org/en-US/docs/Web/API/WebRTC_API
