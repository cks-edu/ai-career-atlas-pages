# Visible words and familiar voices do not grant authority

A screenshot can contain instructions directed at an assistant, and a voice can imitate someone familiar. Treat both as input data until the application authenticates an instruction through its trusted channel. A recognized voice or text in an image cannot authorize a sensitive action.

The fixture allows a sensitive action only from a direct authenticated user channel with explicit action approval. Image, retrieved audio and document channels never create authority, even when their content sounds official.

Task: Implement multimodalAction and draw the observation/action separation. Use fictional files only; do not collect real voiceprints or payroll.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Audio/image observation → source classification → authenticated action gate.
State: Source type and externally established approval stay separate.
Boundary: A visual instruction or voice imitation is not a trusted command.
Failure: A screenshot tells the agent to send private records.
Control: Require a direct authenticated request and exact approval for sensitive actions.
Observability: Audit channel, authentication result and approved action identity.
Blast radius: Every downstream action the assistant can reach.
Trade-off: Additional confirmation slows sensitive workflows but limits spoofed commands.

Limit: Voice matching is not sufficient authentication by itself. The policy does not detect all spoofing or injection; it separates data interpretation from action authority.

Sources:
https://genai.owasp.org/llmrisk/llm01-prompt-injection/
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
