function multimodalAction(source, authenticated, approved) {
  return source === 'direct-user' && authenticated === true && approved === true;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(multimodalAction('direct-user',true,true));
console.log("PASS: A reviewed authenticated request passes");
}
{
assert(!multimodalAction('image',true,true)); assert(!multimodalAction('audio-file',true,true));
console.log("PASS: Image and audio data cannot authorize actions");
}
{
assert(!multimodalAction('direct-user',false,true)); assert(!multimodalAction('direct-user',true,false));
console.log("PASS: Missing authentication or approval blocks");
}
