function validBox(c, allowedImages) {
  if (!c || !allowedImages.includes(c.imageId) || !Array.isArray(c.box) || c.box.length !== 4) return false;
  const [x1,y1,x2,y2]=c.box;
  return c.box.every(n=>Number.isFinite(n) && n>=0 && n<=1) && x1<x2 && y1<y2;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(validBox({imageId:'i1',box:[.1,.1,.8,.8]},['i1']));
console.log("PASS: A permitted positive-area region passes");
}
{
assert(!validBox({imageId:'private',box:[0,0,1,1]},['i1'])); assert(!validBox({imageId:'i1',box:[0,0,2,1]},['i1']));
console.log("PASS: Unknown images and out-of-bounds regions fail");
}
{
assert(!validBox({imageId:'i1',box:[.5,0,.5,1]},['i1'])); assert(!validBox({imageId:'i1',box:[0,NaN,1,1]},['i1']));
console.log("PASS: Zero area and malformed boxes fail");
}
