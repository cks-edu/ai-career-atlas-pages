# Vision evidence needs a bounded region and source identity

A visual answer should point to the image region it used and acknowledge what is not visible. Higher-resolution images can consume more processing; cropping or tiling changes available evidence. A bounding box is a location, not proof that a caption is correct.

Validate normalized boxes with coordinates from 0 to 1, positive area and a permitted image ID. Only pass valid citations to the UI. Real image orientation, crop transforms and model-specific token accounting require additional checks.

Task: Implement validBox. Draw two cropped image coordinates and explain how the UI would map them back to the original.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Permitted image → crop/tile mapping → model result → bounded citation.
State: Image ID and normalized coordinates identify the cited region.
Boundary: A valid coordinate cannot authorize another person’s image.
Failure: A hallucinated citation points outside the visible image.
Control: Check source membership and strict positive-area bounds.
Observability: Retain crop transforms, source revision and citation failures.
Blast radius: Claims depending on the image region.
Trade-off: Cropping reduces work but can remove context needed to interpret a scene.

Limit: A valid box does not establish that the region supports the claim. It also does not prove the image is authentic or safe to use.

Sources:
https://json-schema.org/understanding-json-schema/reference/object
https://www.nist.gov/itl/ai-risk-management-framework
