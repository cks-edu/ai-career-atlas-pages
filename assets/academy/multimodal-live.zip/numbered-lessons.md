# Real-Time Multimodal Voice & Vision Agents — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## intermediate

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

WebRTC: Browser interfaces for real-time media and peer connectivity.

jitter: Variation in timing that may require buffering or adaptation.

VAD: Voice activity detection: a signal estimating whether speech is present.

TTS: Text-to-speech generation and its queued audio output.

bounding box: A rectangular image region, with its coordinate system declared.

grounding: Connecting a claim to evidence that actually supports it.

spoofing: Imitating a source or identity to induce misplaced trust.

trust boundary: The point at which an input needs a stronger authorization or validation rule.

### Audio transport and a measured latency target

Voice interaction includes microphone capture, transport, recognition, model work and speech output. WebRTC provides real-time media capabilities; WebSockets provide ordered bidirectional messages but do not supply a complete audio stack. Choose transport for the actual environment and measure the whole turn.

This worksheet checks a supplied capture-to-audio budget. A sub-500ms target is an illustrative product requirement, not a guarantee made by either transport. Count all measured stages and reserve jitter headroom.

Network, devices, turn detection and provider behavior vary. A policy sum is not a real latency measurement or codec implementation.

Mental model: Microphone → transport → recognition/model → speech output. Picture the boundary as a checked gate between stages.

Boundary: Network, devices, turn detection and provider behavior vary. A policy sum is not a real latency measurement or codec implementation.

Worked example: function audioBudget(stages, jitter, target) {
  return Array.isArray(stages) && [...stages,jitter,target].every(n=>Number.isFinite(n) && n>=0) && stages.reduce((a,b)=>a+b,0)+jitter <= target;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract multimodal-live.zip, install Node.js LTS, then open production-ai/08-01-audio-latency.

Tools for this exercise: JavaScript · local isolated workbench; WebRTC / WebSocket, LiveKit Agents as documented optional extensions

Course tool and framework map: WebRTC / WebSocket (Open web standards); LiveKit Agents (Open source · optional commercial cloud)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement audioBudget and build a stage worksheet. Compare when WebRTC media handling or a WebSocket application protocol is appropriate.

Terminal folder: production-ai/08-01-audio-latency

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

This worksheet checks a supplied capture-to-audio budget. A sub-500ms target is an illustrative product requirement, not a guarantee made by either transport. Count all measured stages and reserve jitter headroom.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement audioBudget and build a stage worksheet. Compare when WebRTC media handling or a WebSocket application protocol is appropriate.

Expected: Complete path plus reserve fits

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Jitter reserve can exceed the target; Invalid measurements are not zero

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Complete path plus reserve fits; Jitter reserve can exceed the target; Invalid measurements are not zero. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Include all stages and a jitter reserve before accepting the target. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/08-01-audio-latency/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Microphone → transport → recognition/model → speech output. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does selecting WebRTC guarantee a sub-500ms conversational response? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A fast model cannot erase capture or network delay. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does selecting WebRTC guarantee a sub-500ms conversational response?

Interview: Does selecting WebRTC guarantee a sub-500ms conversational response? Explain the decision, a failing case and a production limitation.

Quiz: Does selecting WebRTC guarantee a sub-500ms conversational response?

Yes, regardless of the model.

No; measure capture, network, processing and playback together.

Yes, if the UI says real-time.

Reference: No; measure capture, network, processing and playback together. — Transport is one part of the path. A complete, measured latency budget is needed for a product claim.

Sources:

MDN: WebRTC: https://developer.mozilla.org/en-US/docs/Web/API/WebRTC_API

LiveKit: interruptions and turn handling: https://docs.livekit.io/agents/logic/turns/

### Barge-in: stop audio and keep transcript state honest

When a person starts speaking, the assistant may need to stop its own speech immediately. Clearing the visible transcript alone leaves queued audio playing. Coordinate output cancellation and transcript state so unsaid draft text is not recorded as a completed assistant turn.

On USER_SPEECH_START the reducer clears outbound TTS, removes the uncommitted draft and enters listening. Committed transcript remains. Real audio playback also needs an actual stop/flush call and cancellation of in-flight generation.

The reducer does not access a microphone or stop a real audio device. False speech detections and late packets need separately measured policies.

Mental model: Speech-start signal → stop playback → clear draft → listening. Picture the boundary as a checked gate between stages.

Boundary: The reducer does not access a microphone or stop a real audio device. False speech detections and late packets need separately measured policies.

Worked example: function handleAudioEvent(state, event) {
  if (event.type !== 'USER_SPEECH_START') return state;
  return {...state,ttsQueue:[],assistantDraft:'',status:'listening'};
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract multimodal-live.zip, install Node.js LTS, then open production-ai/08-02-barge-in.

Tools for this exercise: JavaScript · local isolated workbench; WebRTC / WebSocket, LiveKit Agents as documented optional extensions

Course tool and framework map: WebRTC / WebSocket (Open web standards); LiveKit Agents (Open source · optional commercial cloud)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement handleAudioEvent. Add a late audio packet case in your extension using a turn ID, and document the actual playback stop action.

Terminal folder: production-ai/08-02-barge-in

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

On USER_SPEECH_START the reducer clears outbound TTS, removes the uncommitted draft and enters listening. Committed transcript remains. Real audio playback also needs an actual stop/flush call and cancellation of in-flight generation.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement handleAudioEvent. Add a late audio packet case in your extension using a turn ID, and document the actual playback stop action.

Expected: Barge-in clears queued speech

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Draft is removed; committed text remains; Unrelated events do not destroy state

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: Barge-in clears queued speech; Draft is removed; committed text remains; Unrelated events do not destroy state. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Flush outbound TTS and truncate only uncommitted assistant state. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/08-02-barge-in/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Speech-start signal → stop playback → clear draft → listening. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. What must change on a genuine user interruption? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Unspoken generated text is not a committed assistant turn. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: What must change on a genuine user interruption?

Interview: What must change on a genuine user interruption? Explain the decision, a failing case and a production limitation.

Quiz: What must change on a genuine user interruption?

Only the color of the microphone icon.

Mark all generated words as spoken.

Stop/flush output and discard only uncommitted assistant content.

Reference: Stop/flush output and discard only uncommitted assistant content. — Playback and transcript state must agree. A generated draft is not evidence that the person heard it.

Sources:

LiveKit: interruptions and turn handling: https://docs.livekit.io/agents/logic/turns/

MDN: WebRTC: https://developer.mozilla.org/en-US/docs/Web/API/WebRTC_API

### Vision evidence needs a bounded region and source identity

A visual answer should point to the image region it used and acknowledge what is not visible. Higher-resolution images can consume more processing; cropping or tiling changes available evidence. A bounding box is a location, not proof that a caption is correct.

Validate normalized boxes with coordinates from 0 to 1, positive area and a permitted image ID. Only pass valid citations to the UI. Real image orientation, crop transforms and model-specific token accounting require additional checks.

A valid box does not establish that the region supports the claim. It also does not prove the image is authentic or safe to use.

Mental model: Permitted image → crop/tile mapping → model result → bounded citation. Picture the boundary as a checked gate between stages.

Boundary: A valid box does not establish that the region supports the claim. It also does not prove the image is authentic or safe to use.

Worked example: function validBox(c, allowedImages) {
  if (!c || !allowedImages.includes(c.imageId) || !Array.isArray(c.box) || c.box.length !== 4) return false;
  const [x1,y1,x2,y2]=c.box;
  return c.box.every(n=>Number.isFinite(n) && n>=0 && n<=1) && x1<x2 && y1<y2;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract multimodal-live.zip, install Node.js LTS, then open production-ai/08-03-vision-grounding.

Tools for this exercise: JavaScript · local isolated workbench; WebRTC / WebSocket, LiveKit Agents as documented optional extensions

Course tool and framework map: WebRTC / WebSocket (Open web standards); LiveKit Agents (Open source · optional commercial cloud)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement validBox. Draw two cropped image coordinates and explain how the UI would map them back to the original.

Terminal folder: production-ai/08-03-vision-grounding

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Validate normalized boxes with coordinates from 0 to 1, positive area and a permitted image ID. Only pass valid citations to the UI. Real image orientation, crop transforms and model-specific token accounting require additional checks.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement validBox. Draw two cropped image coordinates and explain how the UI would map them back to the original.

Expected: A permitted positive-area region passes

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Unknown images and out-of-bounds regions fail; Zero area and malformed boxes fail

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A permitted positive-area region passes; Unknown images and out-of-bounds regions fail; Zero area and malformed boxes fail. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Check source membership and strict positive-area bounds. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/08-03-vision-grounding/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Permitted image → crop/tile mapping → model result → bounded citation. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. A vision citation has valid coordinates. What remains to check? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A valid coordinate cannot authorize another person’s image. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: A vision citation has valid coordinates. What remains to check?

Interview: A vision citation has valid coordinates. What remains to check? Explain the decision, a failing case and a production limitation.

Quiz: A vision citation has valid coordinates. What remains to check?

Whether the region actually supports the claim.

Nothing; boxes prove correctness.

Whether the answer sounds confident.

Reference: Whether the region actually supports the claim. — Coordinate validity and semantic grounding are distinct checks. Inspect the cited evidence and keep uncertainty explicit.

Sources:

JSON Schema: object validation: https://json-schema.org/understanding-json-schema/reference/object

NIST: AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

### Visible words and familiar voices do not grant authority

A screenshot can contain instructions directed at an assistant, and a voice can imitate someone familiar. Treat both as input data until the application authenticates an instruction through its trusted channel. A recognized voice or text in an image cannot authorize a sensitive action.

The fixture allows a sensitive action only from a direct authenticated user channel with explicit action approval. Image, retrieved audio and document channels never create authority, even when their content sounds official.

Voice matching is not sufficient authentication by itself. The policy does not detect all spoofing or injection; it separates data interpretation from action authority.

Mental model: Audio/image observation → source classification → authenticated action gate. Picture the boundary as a checked gate between stages.

Boundary: Voice matching is not sufficient authentication by itself. The policy does not detect all spoofing or injection; it separates data interpretation from action authority.

Worked example: function multimodalAction(source, authenticated, approved) {
  return source === 'direct-user' && authenticated === true && approved === true;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract multimodal-live.zip, install Node.js LTS, then open production-ai/08-04-multimodal-trust.

Tools for this exercise: JavaScript · local isolated workbench; WebRTC / WebSocket, LiveKit Agents as documented optional extensions

Course tool and framework map: WebRTC / WebSocket (Open web standards); LiveKit Agents (Open source · optional commercial cloud)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Implement multimodalAction and draw the observation/action separation. Use fictional files only; do not collect real voiceprints or payroll.

Terminal folder: production-ai/08-04-multimodal-trust

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fixture allows a sensitive action only from a direct authenticated user channel with explicit action approval. Image, retrieved audio and document channels never create authority, even when their content sounds official.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement multimodalAction and draw the observation/action separation. Use fictional files only; do not collect real voiceprints or payroll.

Expected: A reviewed authenticated request passes

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Image and audio data cannot authorize actions; Missing authentication or approval blocks

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Expected: A reviewed authenticated request passes; Image and audio data cannot authorize actions; Missing authentication or approval blocks. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require a direct authenticated request and exact approval for sensitive actions. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/08-04-multimodal-trust/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Audio/image observation → source classification → authenticated action gate. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. An uploaded audio file sounds like the manager and asks to export payroll. What should the agent do? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A visual instruction or voice imitation is not a trusted command. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: An uploaded audio file sounds like the manager and asks to export payroll. What should the agent do?

Interview: An uploaded audio file sounds like the manager and asks to export payroll. What should the agent do? Explain the decision, a failing case and a production limitation.

Quiz: An uploaded audio file sounds like the manager and asks to export payroll. What should the agent do?

Treat the familiar voice as approval.

Require authenticated authorization through the trusted action channel.

Let the model decide whether the voice is sincere.

Reference: Require authenticated authorization through the trusted action channel. — Content resemblance does not establish identity or permission. Sensitive execution must use the application’s trusted authorization process.

Sources:

OWASP: prompt injection: https://genai.owasp.org/llmrisk/llm01-prompt-injection/

OWASP: authorization checks: https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
