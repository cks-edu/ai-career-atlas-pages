# Real-Time Multimodal Voice & Vision Agents

Coordinate audio, visual evidence and interruption state.

Use the in-browser Practise workbench, or extract the course ZIP and install a currently supported Node.js LTS from nodejs.org. Run each reference.mjs from its numbered production-ai folder; run starter.mjs to see the failing initial checks. No packages or model files are required.

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Mental model: follow Path → State → Boundary → Failure → Control → Observability → Blast radius → Trade-off; inspect each lesson’s concrete version before changing code.

Tools and alternatives:
WebRTC / WebSocket — Open web standards. Media or message transport under a measured protocol. Alternative: Compare transport requirements; they are not drop-in equivalents.
LiveKit Agents — Open source · optional commercial cloud. Optional real audio turn and interruption orchestration. Alternative: A separately designed WebRTC/media backend or managed voice service.

Project: Build an independently changed learning artifact for Real-Time Multimodal Voice & Vision Agents. Coordinate audio, visual evidence and interruption state. Use synthetic data and make the tested scope explicit.
Draw the eight-node path and identify data, authority and resource boundaries.
Implement your own changed policy using the four lessons; retain valid and invalid cases.
Inject a declared failure, capture the result, repair it and run the regression checks.
Write an ADR with options, trade-offs, source/runtime versions, limitations and a rollback/recovery decision.

The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.
