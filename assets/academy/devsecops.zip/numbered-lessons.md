# DevSecOps Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Authentication and authorization: Authentication establishes identity; authorization decides which action that identity may perform.

Apply authentication and authorization in DevSecOps Engineer: Use the concept to complete this role exercise: Identify trust boundaries in a build and release flow

Build trust boundaries: Pull-request code, dependency installers and release credentials have different trust levels. Do not let untrusted code execute with secrets merely because it runs in CI.

### Authentication and authorization

Authentication establishes identity; authorization decides which action that identity may perform. In this role, work through: A forked contribution should run validation without release credentials. The practical workshop develops this into: Draw the workflow's triggers, inputs, permissions and secrets. Set read-only default permissions and separate untrusted validation from authorized publishing. Review any privileged pull-request trigger.

Mental model: An ID card tells who you are; the door policy says where you may enter.

Boundary: A valid login does not authorize access to every record.

Role application: A visitor's package should not be opened in the vault.

Pull-request code, dependency installers and release credentials have different trust levels. Do not let untrusted code execute with secrets merely because it runs in CI.

Worked example: A forked contribution should run validation without release credentials.

Shared foundation example: Alice may read but not write; an unknown user is denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: GitHub Actions and OWASP guidance (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for DevSecOps Engineer: A forked contribution should run validation without release credentials.

Predict the worked case

Read this case without running a tool: A forked contribution should run validation without release credentials. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in authentication and authorization.

Connect the concept to the role

Apply this rule: Authentication establishes identity; authorization decides which action that identity may perform. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A valid login does not authorize access to every record.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies authentication and authorization to this case: A forked contribution should run validation without release credentials. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A forked contribution should run validation without release credentials. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Authentication and authorization; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with authentication and authorization. Use the glossary below, then write your prediction for: A forked contribution should run validation without release credentials. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the DevSecOps Engineer role interview. Explain authentication and authorization using this case: A forked contribution should run validation without release credentials. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate authentication and authorization to a system or workflow you know. Explain authentication and authorization using this case: A forked contribution should run validation without release credentials. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Where should an object ownership check happen?

Interview: Explain authentication and authorization using this case: A forked contribution should run validation without release credentials. State the evidence, one alternative and where the mental model stops.

Quiz: After the Build trust boundaries rehearsal, check this foundation: A logged-in user requests another user’s private record. What must the service still check?

Whether this identity is permitted to perform this action on that record.

Only whether the session token has the correct syntax.

Only whether the record identifier exists.

Reference: Whether this identity is permitted to perform this action on that record. — Authentication establishes identity; authorization checks the action and resource.

Sources:

GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Build trust boundaries

Pull-request code, dependency installers and release credentials have different trust levels. Do not let untrusted code execute with secrets merely because it runs in CI. In this role, work through: A forked contribution should run validation without release credentials. The practical workshop develops this into: Draw the workflow's triggers, inputs, permissions and secrets. Set read-only default permissions and separate untrusted validation from authorized publishing. Review any privileged pull-request trigger.

Mental model: A visitor's package should not be opened in the vault.

Boundary: Secret masking is not an access control; prevent exposure rather than relying on redaction.

Worked example: A forked contribution should run validation without release credentials.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: GitHub Actions and OWASP guidance (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required DevSecOps Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Draw the workflow's triggers, inputs, permissions and secrets. Set read-only default permissions and separate untrusted validation from authorized publishing. Review any privileged pull-request trigger.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A forked contribution should run validation without release credentials. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Draw the workflow's triggers, inputs, permissions and secrets. Set read-only default permissions and separate untrusted validation from authorized publishing. Review any privileged pull-request trigger.

Expected: A threat model showing exactly which job can publish and why.

Role workshop · debug and verify

Secret masking is not an access control; prevent exposure rather than relying on redaction. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save CI trust-boundary review. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A threat model showing exactly which job can publish and why.

Expected: A threat model showing exactly which job can publish and why.

Troubleshoot: The role exercise differs from the prediction: Secret masking is not an access control; prevent exposure rather than relying on redaction.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: CI trust-boundary review; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with build trust boundaries. Use the glossary below, then write your prediction for: A forked contribution should run validation without release credentials. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the DevSecOps Engineer role interview. Explain build trust boundaries using this case: A forked contribution should run validation without release credentials. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate build trust boundaries to a system or workflow you know. Explain build trust boundaries using this case: A forked contribution should run validation without release credentials. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Secret masking is not an access control; prevent exposure rather than relying on redaction.

Interview: Explain build trust boundaries using this case: A forked contribution should run validation without release credentials. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A forked contribution should run validation without release credentials.

A threat model showing exactly which job can publish and why.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A threat model showing exactly which job can publish and why. — Pull-request code, dependency installers and release credentials have different trust levels. Do not let untrusted code execute with secrets merely because it runs in CI. A threat model showing exactly which job can publish and why.

Sources:

GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Code and data separation: Parameterized SQL keeps input values separate from SQL instructions.

Apply code and data separation in DevSecOps Engineer: Use the concept to complete this role exercise: Define minimal CI token permissions and dependency checks

Dependency and artifact evidence: A dependency scan reports known findings, not complete safety. Record dependency versions and artifact identity so fixes and releases can be traced.

### Code and data separation

Parameterized SQL keeps input values separate from SQL instructions. In this role, work through: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. The practical workshop develops this into: Create a lockfile-based build, inventory dependencies and run an appropriate scanner in a sandbox. Record one finding or a clean result with scanner version; define exception owner and expiry.

Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.

Boundary: Parameters protect values; dynamic table names still require explicit allowlists.

Role application: A food label lists ingredients; inspection still checks handling and contamination.

A dependency scan reports known findings, not complete safety. Record dependency versions and artifact identity so fixes and releases can be traced.

Worked example: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact.

Shared foundation example: The malicious-looking owner string is treated as a value and returns zero rows.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: GitHub Actions and OWASP guidance (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for DevSecOps Engineer: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact.

Predict the worked case

Read this case without running a tool: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in code and data separation.

Connect the concept to the role

Apply this rule: Parameterized SQL keeps input values separate from SQL instructions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Parameters protect values; dynamic table names still require explicit allowlists.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies code and data separation to this case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Code and data separation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with code and data separation. Use the glossary below, then write your prediction for: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the DevSecOps Engineer role interview. Explain code and data separation using this case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate code and data separation to a system or workflow you know. Explain code and data separation using this case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why is escaping one example string weaker than using parameters?

Interview: Explain code and data separation using this case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. State the evidence, one alternative and where the mental model stops.

Quiz: After the Dependency and artifact evidence rehearsal, check this foundation: A query binds a user value through a parameter. Can that same placeholder choose an arbitrary table name?

Yes, placeholders bind all SQL syntax.

No; structural identifiers need an allowlisted query design.

Yes, if the identifier arrives over HTTPS.

Reference: No; structural identifiers need an allowlisted query design. — Parameters bind values, not arbitrary SQL structure. Transport security does not change SQL semantics.

Sources:

GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Dependency and artifact evidence

A dependency scan reports known findings, not complete safety. Record dependency versions and artifact identity so fixes and releases can be traced. In this role, work through: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. The practical workshop develops this into: Create a lockfile-based build, inventory dependencies and run an appropriate scanner in a sandbox. Record one finding or a clean result with scanner version; define exception owner and expiry.

Mental model: A food label lists ingredients; inspection still checks handling and contamination.

Boundary: Ignoring all findings to make CI green removes the gate's meaning; scope any exception.

Worked example: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: GitHub Actions and OWASP guidance (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required DevSecOps Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a lockfile-based build, inventory dependencies and run an appropriate scanner in a sandbox. Record one finding or a clean result with scanner version; define exception owner and expiry.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a lockfile-based build, inventory dependencies and run an appropriate scanner in a sandbox. Record one finding or a clean result with scanner version; define exception owner and expiry.

Expected: A traceable decision without claiming zero findings means zero risk.

Role workshop · debug and verify

Ignoring all findings to make CI green removes the gate's meaning; scope any exception. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save dependency inventory and exception policy. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A traceable decision without claiming zero findings means zero risk.

Expected: A traceable decision without claiming zero findings means zero risk.

Troubleshoot: The role exercise differs from the prediction: Ignoring all findings to make CI green removes the gate's meaning; scope any exception.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: dependency inventory and exception policy; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with dependency and artifact evidence. Use the glossary below, then write your prediction for: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the DevSecOps Engineer role interview. Explain dependency and artifact evidence using this case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate dependency and artifact evidence to a system or workflow you know. Explain dependency and artifact evidence using this case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Ignoring all findings to make CI green removes the gate's meaning; scope any exception.

Interview: Explain dependency and artifact evidence using this case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact.

Ignore the failing case and keep only the successful screenshot.

A traceable decision without claiming zero findings means zero risk.

Treat any successful command as proof that all business and access rules passed.

Reference: A traceable decision without claiming zero findings means zero risk. — A dependency scan reports known findings, not complete safety. Record dependency versions and artifact identity so fixes and releases can be traced. A traceable decision without claiming zero findings means zero risk.

Sources:

GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Threat models and regression: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.

Apply threat models and regression in DevSecOps Engineer: Use the concept to complete this role exercise: Design artifact provenance, secret rotation and a compromised-runner response

Compromised runner response: A compromised build environment may affect credentials and artifact integrity. Recovery includes stopping publication, rotating exposed credentials and rebuilding from a trusted environment.

### Threat models and regression

State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. In this role, work through: A suspicious runner accessed a release token during a build window. The practical workshop develops this into: Run a tabletop incident: list affected jobs/artifacts, revoke the hypothetical token, identify trusted source revisions and define provenance checks for a clean rebuild. Use synthetic credentials only.

Mental model: Mark doors and valuable rooms on a building map before choosing locks.

Boundary: A threat model is a living hypothesis, not proof that the system is secure.

Role application: If the packing station is compromised, inspect both the keys and every parcel it produced.

A compromised build environment may affect credentials and artifact integrity. Recovery includes stopping publication, rotating exposed credentials and rebuilding from a trusted environment.

Worked example: A suspicious runner accessed a release token during a build window.

Shared foundation example: Reader-write, unknown-read and unsupported-delete must all be denied.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: GitHub Actions and OWASP guidance (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for DevSecOps Engineer: A suspicious runner accessed a release token during a build window.

Predict the worked case

Read this case without running a tool: A suspicious runner accessed a release token during a build window. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in threat models and regression.

Connect the concept to the role

Apply this rule: State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A threat model is a living hypothesis, not proof that the system is secure.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies threat models and regression to this case: A suspicious runner accessed a release token during a build window. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A suspicious runner accessed a release token during a build window. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Threat models and regression; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with threat models and regression. Use the glossary below, then write your prediction for: A suspicious runner accessed a release token during a build window. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the DevSecOps Engineer role interview. Explain threat models and regression using this case: A suspicious runner accessed a release token during a build window. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate threat models and regression to a system or workflow you know. Explain threat models and regression using this case: A suspicious runner accessed a release token during a build window. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would a new export endpoint change the threat model?

Interview: Explain threat models and regression using this case: A suspicious runner accessed a release token during a build window. State the evidence, one alternative and where the mental model stops.

Quiz: After the Compromised runner response rehearsal, check this foundation: A denied action is fixed after a security defect. What helps detect its recurrence?

Document only the successful authorized path.

Remove the denied case because it now passes.

Add a repeatable negative test tied to the actor, action and trust boundary.

Reference: Add a repeatable negative test tied to the actor, action and trust boundary. — Regression checks preserve evidence for important misuse cases; the threat model explains why the control matters.

Sources:

GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Compromised runner response

A compromised build environment may affect credentials and artifact integrity. Recovery includes stopping publication, rotating exposed credentials and rebuilding from a trusted environment. In this role, work through: A suspicious runner accessed a release token during a build window. The practical workshop develops this into: Run a tabletop incident: list affected jobs/artifacts, revoke the hypothetical token, identify trusted source revisions and define provenance checks for a clean rebuild. Use synthetic credentials only.

Mental model: If the packing station is compromised, inspect both the keys and every parcel it produced.

Boundary: Deleting logs before scoping the incident destroys useful evidence; preserve them first.

Worked example: A suspicious runner accessed a release token during a build window.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: GitHub Actions and OWASP guidance (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required DevSecOps Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Run a tabletop incident: list affected jobs/artifacts, revoke the hypothetical token, identify trusted source revisions and define provenance checks for a clean rebuild. Use synthetic credentials only.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 access.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A suspicious runner accessed a release token during a build window. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Run a tabletop incident: list affected jobs/artifacts, revoke the hypothetical token, identify trusted source revisions and define provenance checks for a clean rebuild. Use synthetic credentials only.

Expected: A containment-to-recovery sequence with owners and evidence preservation.

Role workshop · debug and verify

Deleting logs before scoping the incident destroys useful evidence; preserve them first. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save supply-chain incident playbook and rebuild criteria. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A containment-to-recovery sequence with owners and evidence preservation.

Expected: A containment-to-recovery sequence with owners and evidence preservation.

Troubleshoot: The role exercise differs from the prediction: Deleting logs before scoping the incident destroys useful evidence; preserve them first.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: supply-chain incident playbook and rebuild criteria; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with compromised runner response. Use the glossary below, then write your prediction for: A suspicious runner accessed a release token during a build window. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the DevSecOps Engineer role interview. Explain compromised runner response using this case: A suspicious runner accessed a release token during a build window. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate compromised runner response to a system or workflow you know. Explain compromised runner response using this case: A suspicious runner accessed a release token during a build window. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Deleting logs before scoping the incident destroys useful evidence; preserve them first.

Interview: Explain compromised runner response using this case: A suspicious runner accessed a release token during a build window. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A suspicious runner accessed a release token during a build window.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A containment-to-recovery sequence with owners and evidence preservation.

Reference: A containment-to-recovery sequence with owners and evidence preservation. — A compromised build environment may affect credentials and artifact integrity. Recovery includes stopping publication, rotating exposed credentials and rebuilding from a trusted environment. A containment-to-recovery sequence with owners and evidence preservation.

Sources:

GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
