# DevSecOps Engineer

Software Engineering

Start with build trust boundaries. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward supply-chain incident playbook and rebuild criteria.

## beginner

Draw the workflow's triggers, inputs, permissions and secrets. Set read-only default permissions and separate untrusted validation from authorized publishing. Review any privileged pull-request trigger.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Authentication and authorization
Authentication establishes identity; authorization decides which action that identity may perform.
Mental model: An ID card tells who you are; the door policy says where you may enter.
Limit: A valid login does not authorize access to every record.
Example: Alice may read but not write; an unknown user is denied.
Recall: Where should an object ownership check happen?

### Build trust boundaries
Pull-request code, dependency installers and release credentials have different trust levels. Do not let untrusted code execute with secrets merely because it runs in CI.
Mental model: A visitor's package should not be opened in the vault.
Limit: Secret masking is not an access control; prevent exposure rather than relying on redaction.
Example: A forked contribution should run validation without release credentials.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Secret masking is not an access control; prevent exposure rather than relying on redaction.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A forked contribution should run validation without release credentials. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Draw the workflow's triggers, inputs, permissions and secrets. Set read-only default permissions and separate untrusted validation from authorized publishing. Review any privileged pull-request trigger.
Expected: A threat model showing exactly which job can publish and why.

6. Role workshop · debug and verify
Secret masking is not an access control; prevent exposure rather than relying on redaction. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save CI trust-boundary review. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A threat model showing exactly which job can publish and why.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Build trust boundaries: Secret masking is not an access control; prevent exposure rather than relying on redaction.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: CI trust-boundary review
A threat model showing exactly which job can publish and why.

Interview: Work through this DevSecOps Engineer case: A forked contribution should run validation without release credentials. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Pull-request code, dependency installers and release credentials have different trust levels. Do not let untrusted code execute with secrets merely because it runs in CI. Expected evidence: A threat model showing exactly which job can publish and why. Diagnosis: Secret masking is not an access control; prevent exposure rather than relying on redaction. State the limits of the mental model: A visitor's package should not be opened in the vault.

Resume: Built CI trust-boundary review using GitHub Actions and OWASP guidance; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Create a lockfile-based build, inventory dependencies and run an appropriate scanner in a sandbox. Record one finding or a clean result with scanner version; define exception owner and expiry.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Code and data separation
Parameterized SQL keeps input values separate from SQL instructions.
Mental model: A form field inside a sealed envelope, not a new instruction to the clerk.
Limit: Parameters protect values; dynamic table names still require explicit allowlists.
Example: The malicious-looking owner string is treated as a value and returns zero rows.
Recall: Why is escaping one example string weaker than using parameters?

### Dependency and artifact evidence
A dependency scan reports known findings, not complete safety. Record dependency versions and artifact identity so fixes and releases can be traced.
Mental model: A food label lists ingredients; inspection still checks handling and contamination.
Limit: Ignoring all findings to make CI green removes the gate's meaning; scope any exception.
Example: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Ignoring all findings to make CI green removes the gate's meaning; scope any exception.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a lockfile-based build, inventory dependencies and run an appropriate scanner in a sandbox. Record one finding or a clean result with scanner version; define exception owner and expiry.
Expected: A traceable decision without claiming zero findings means zero risk.

6. Role workshop · debug and verify
Ignoring all findings to make CI green removes the gate's meaning; scope any exception. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save dependency inventory and exception policy. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A traceable decision without claiming zero findings means zero risk.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Dependency and artifact evidence: Ignoring all findings to make CI green removes the gate's meaning; scope any exception.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: dependency inventory and exception policy
A traceable decision without claiming zero findings means zero risk.

Interview: Work through this DevSecOps Engineer case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A dependency scan reports known findings, not complete safety. Record dependency versions and artifact identity so fixes and releases can be traced. Expected evidence: A traceable decision without claiming zero findings means zero risk. Diagnosis: Ignoring all findings to make CI green removes the gate's meaning; scope any exception. State the limits of the mental model: A food label lists ingredients; inspection still checks handling and contamination.

Resume: Built dependency inventory and exception policy using GitHub Actions and OWASP guidance; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run a tabletop incident: list affected jobs/artifacts, revoke the hypothetical token, identify trusted source revisions and define provenance checks for a clean rebuild. Use synthetic credentials only.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Threat models and regression
State assets, actors, trust boundaries and misuse cases; convert important controls into repeatable checks.
Mental model: Mark doors and valuable rooms on a building map before choosing locks.
Limit: A threat model is a living hypothesis, not proof that the system is secure.
Example: Reader-write, unknown-read and unsupported-delete must all be denied.
Recall: How would a new export endpoint change the threat model?

### Compromised runner response
A compromised build environment may affect credentials and artifact integrity. Recovery includes stopping publication, rotating exposed credentials and rebuilding from a trusted environment.
Mental model: If the packing station is compromised, inspect both the keys and every parcel it produced.
Limit: Deleting logs before scoping the incident destroys useful evidence; preserve them first.
Example: A suspicious runner accessed a release token during a build window.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Deleting logs before scoping the incident destroys useful evidence; preserve them first.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 access.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: Reader read is allowed; reader write and unknown user are denied. Later levels reject the SQL fixture and test four authorization cases.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A suspicious runner accessed a release token during a build window. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run a tabletop incident: list affected jobs/artifacts, revoke the hypothetical token, identify trusted source revisions and define provenance checks for a clean rebuild. Use synthetic credentials only.
Expected: A containment-to-recovery sequence with owners and evidence preservation.

6. Role workshop · debug and verify
Deleting logs before scoping the incident destroys useful evidence; preserve them first. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save supply-chain incident playbook and rebuild criteria. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A containment-to-recovery sequence with owners and evidence preservation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Compromised runner response: Deleting logs before scoping the incident destroys useful evidence; preserve them first.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: supply-chain incident playbook and rebuild criteria
A containment-to-recovery sequence with owners and evidence preservation.

Interview: Work through this DevSecOps Engineer case: A suspicious runner accessed a release token during a build window. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A compromised build environment may affect credentials and artifact integrity. Recovery includes stopping publication, rotating exposed credentials and rebuilding from a trusted environment. Expected evidence: A containment-to-recovery sequence with owners and evidence preservation. Diagnosis: Deleting logs before scoping the incident destroys useful evidence; preserve them first. State the limits of the mental model: If the packing station is compromised, inspect both the keys and every parcel it produced.

Resume: Built supply-chain incident playbook and rebuild criteria using GitHub Actions and OWASP guidance; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
OWASP Web Security Testing Guide: https://owasp.org/projects/web-security-testing-guide
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
GitHub Actions: secure use: https://docs.github.com/en/actions/reference/security/secure-use
