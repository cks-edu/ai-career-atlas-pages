# DevSecOps Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Build trust boundaries

Pull-request code, dependency installers and release credentials have different trust levels. Do not let untrusted code execute with secrets merely because it runs in CI.
Mental model: A visitor's package should not be opened in the vault.
Case: A forked contribution should run validation without release credentials.
Task: Draw the workflow's triggers, inputs, permissions and secrets. Set read-only default permissions and separate untrusted validation from authorized publishing. Review any privileged pull-request trigger.
Acceptance: A threat model showing exactly which job can publish and why.
Troubleshooting: Secret masking is not an access control; prevent exposure rather than relying on redaction.
Deliverable: CI trust-boundary review

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Dependency and artifact evidence

A dependency scan reports known findings, not complete safety. Record dependency versions and artifact identity so fixes and releases can be traced.
Mental model: A food label lists ingredients; inspection still checks handling and contamination.
Case: A vulnerable dependency finding needs affected usage, a fix plan and a verified rebuilt artifact.
Task: Create a lockfile-based build, inventory dependencies and run an appropriate scanner in a sandbox. Record one finding or a clean result with scanner version; define exception owner and expiry.
Acceptance: A traceable decision without claiming zero findings means zero risk.
Troubleshooting: Ignoring all findings to make CI green removes the gate's meaning; scope any exception.
Deliverable: dependency inventory and exception policy

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Compromised runner response

A compromised build environment may affect credentials and artifact integrity. Recovery includes stopping publication, rotating exposed credentials and rebuilding from a trusted environment.
Mental model: If the packing station is compromised, inspect both the keys and every parcel it produced.
Case: A suspicious runner accessed a release token during a build window.
Task: Run a tabletop incident: list affected jobs/artifacts, revoke the hypothetical token, identify trusted source revisions and define provenance checks for a clean rebuild. Use synthetic credentials only.
Acceptance: A containment-to-recovery sequence with owners and evidence preservation.
Troubleshooting: Deleting logs before scoping the incident destroys useful evidence; preserve them first.
Deliverable: supply-chain incident playbook and rebuild criteria

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
