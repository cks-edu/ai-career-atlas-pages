# C# / .NET Developer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Boundaries and ownership: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.

Apply boundaries and ownership in C# / .NET Developer: Use the concept to complete this role exercise: Create a console application using the linked Microsoft tutorial

Records and explicit validation: A C# record expresses data shape and value equality; it does not automatically validate business constraints. Keep a checked construction path for user input.

### Boundaries and ownership

A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. In this role, work through: Ticket(" A ") becomes A; an empty title fails before storage. The practical workshop develops this into: Create AtlasTickets using dotnet new console. Define a Ticket record and a factory that trims and validates titles. Add executable checks for valid, blank and oversized titles; return a nonzero exit on failed checks.

Mental model: Departments own different ledgers and exchange agreed forms.

Boundary: Drawing more boxes does not make a system more reliable.

Role application: A typed envelope still needs its contents inspected.

A C# record expresses data shape and value equality; it does not automatically validate business constraints. Keep a checked construction path for user input.

Worked example: Ticket(" A ") becomes A; an empty title fails before storage.

Shared foundation example: The order service owns orders; a notification consumer handles messages.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: .NET SDK and ASP.NET Core (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for C# / .NET Developer: Ticket(" A ") becomes A; an empty title fails before storage.

Predict the worked case

Read this case without running a tool: Ticket(" A ") becomes A; an empty title fails before storage. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in boundaries and ownership.

Connect the concept to the role

Apply this rule: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Drawing more boxes does not make a system more reliable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies boundaries and ownership to this case: Ticket(" A ") becomes A; an empty title fails before storage. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Ticket(" A ") becomes A; an empty title fails before storage. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Boundaries and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with boundaries and ownership. Use the glossary below, then write your prediction for: Ticket(" A ") becomes A; an empty title fails before storage. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C# / .NET Developer role interview. Explain boundaries and ownership using this case: Ticket(" A ") becomes A; an empty title fails before storage. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate boundaries and ownership to a system or workflow you know. Explain boundaries and ownership using this case: Ticket(" A ") becomes A; an empty title fails before storage. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which component owns the truth about whether an order exists?

Interview: Explain boundaries and ownership using this case: Ticket(" A ") becomes A; an empty title fails before storage. State the evidence, one alternative and where the mental model stops.

Quiz: After the Records and explicit validation rehearsal, check this foundation: Two services both write one business record using incompatible rules. What should be clarified first?

The owning service and the contract through which others request changes.

Which service can issue writes faster.

Whether both services can share unrestricted credentials.

Reference: The owning service and the contract through which others request changes. — Ownership defines responsibility for invariants. Sharing write access does not resolve conflicting business rules.

Sources:

Microsoft: cancel asynchronous tasks: https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/cancel-async-tasks-after-a-period-of-time

Microsoft: create a .NET console application: https://learn.microsoft.com/en-us/dotnet/core/tutorials/create-console-app

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Records and explicit validation

A C# record expresses data shape and value equality; it does not automatically validate business constraints. Keep a checked construction path for user input. In this role, work through: Ticket(" A ") becomes A; an empty title fails before storage. The practical workshop develops this into: Create AtlasTickets using dotnet new console. Define a Ticket record and a factory that trims and validates titles. Add executable checks for valid, blank and oversized titles; return a nonzero exit on failed checks.

Mental model: A typed envelope still needs its contents inspected.

Boundary: Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime.

Worked example: Ticket(" A ") becomes A; an empty title fails before storage.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: .NET SDK and ASP.NET Core (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required C# / .NET Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create AtlasTickets using dotnet new console. Define a Ticket record and a factory that trims and validates titles. Add executable checks for valid, blank and oversized titles; return a nonzero exit on failed checks.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Ticket(" A ") becomes A; an empty title fails before storage. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create AtlasTickets using dotnet new console. Define a Ticket record and a factory that trims and validates titles. Add executable checks for valid, blank and oversized titles; return a nonzero exit on failed checks.

```
dotnet new console -n AtlasTickets
cd AtlasTickets
dotnet run
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: The three checks distinguish type correctness from business validity.

Role workshop · debug and verify

Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save Program.cs and a documented dotnet run transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: The three checks distinguish type correctness from business validity.

Expected: The three checks distinguish type correctness from business validity.

Troubleshoot: The role exercise differs from the prediction: Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: Program.cs and a documented dotnet run transcript; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with records and explicit validation. Use the glossary below, then write your prediction for: Ticket(" A ") becomes A; an empty title fails before storage. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C# / .NET Developer role interview. Explain records and explicit validation using this case: Ticket(" A ") becomes A; an empty title fails before storage. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate records and explicit validation to a system or workflow you know. Explain records and explicit validation using this case: Ticket(" A ") becomes A; an empty title fails before storage. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime.

Interview: Explain records and explicit validation using this case: Ticket(" A ") becomes A; an empty title fails before storage. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Ticket(" A ") becomes A; an empty title fails before storage.

The three checks distinguish type correctness from business validity.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: The three checks distinguish type correctness from business validity. — A C# record expresses data shape and value equality; it does not automatically validate business constraints. Keep a checked construction path for user input. The three checks distinguish type correctness from business validity.

Sources:

Microsoft: cancel asynchronous tasks: https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/cancel-async-tasks-after-a-period-of-time

Microsoft: create a .NET console application: https://learn.microsoft.com/en-us/dotnet/core/tutorials/create-console-app

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Transactional outbox: Write business data and the event to publish in one local transaction, then deliver the event separately.

Apply transactional outbox in C# / .NET Developer: Use the concept to complete this role exercise: Implement a typed ticket DTO and validate its fields

Cancellation in asynchronous work: Pass a CancellationToken through asynchronous boundaries. Handle cancellation separately from unexpected exceptions and dispose the token source when the operation ends.

### Transactional outbox

Write business data and the event to publish in one local transaction, then deliver the event separately. In this role, work through: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. The practical workshop develops this into: Add an async operation using Task.Delay(delay, token), create CancellationTokenSource, call CancelAfter and catch OperationCanceledException. Test a fast successful case and a canceled case without broad catch-and-success behavior.

Mental model: Record a sale and its mailing slip in the same ledger before dispatch.

Boundary: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Role application: A stop request must reach every worker in the chain, not just the front desk.

Pass a CancellationToken through asynchronous boundaries. Handle cancellation separately from unexpected exceptions and dispose the token source when the operation ends.

Worked example: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work.

Shared foundation example: The reference stores order-1 and its pending event together.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: .NET SDK and ASP.NET Core (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for C# / .NET Developer: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work.

Predict the worked case

Read this case without running a tool: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transactional outbox.

Connect the concept to the role

Apply this rule: Write business data and the event to publish in one local transaction, then deliver the event separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transactional outbox to this case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Transactional outbox; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transactional outbox. Use the glossary below, then write your prediction for: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C# / .NET Developer role interview. Explain transactional outbox using this case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transactional outbox to a system or workflow you know. Explain transactional outbox using this case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why can publishing first lose consistency if the database write fails?

Interview: Explain transactional outbox using this case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. State the evidence, one alternative and where the mental model stops.

Quiz: After the Cancellation in asynchronous work rehearsal, check this foundation: Business data commits but publishing its event fails. Which design closes this local write/publish gap?

Publish first, then hope the business write succeeds.

Commit the data and pending outbox entry in one local transaction.

Use a longer broker timeout without recording pending work.

Reference: Commit the data and pending outbox entry in one local transaction. — The outbox preserves a durable publication intent. Delivery can still repeat, so consumers need suitable deduplication.

Sources:

Microsoft: cancel asynchronous tasks: https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/cancel-async-tasks-after-a-period-of-time

Microsoft: create a .NET console application: https://learn.microsoft.com/en-us/dotnet/core/tutorials/create-console-app

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Cancellation in asynchronous work

Pass a CancellationToken through asynchronous boundaries. Handle cancellation separately from unexpected exceptions and dispose the token source when the operation ends. In this role, work through: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. The practical workshop develops this into: Add an async operation using Task.Delay(delay, token), create CancellationTokenSource, call CancelAfter and catch OperationCanceledException. Test a fast successful case and a canceled case without broad catch-and-success behavior.

Mental model: A stop request must reach every worker in the chain, not just the front desk.

Boundary: If work completes despite cancellation, inspect whether the token was passed to the operation being awaited.

Worked example: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: .NET SDK and ASP.NET Core (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required C# / .NET Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add an async operation using Task.Delay(delay, token), create CancellationTokenSource, call CancelAfter and catch OperationCanceledException. Test a fast successful case and a canceled case without broad catch-and-success behavior.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add an async operation using Task.Delay(delay, token), create CancellationTokenSource, call CancelAfter and catch OperationCanceledException. Test a fast successful case and a canceled case without broad catch-and-success behavior.

```
dotnet run
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: One success and one explicit canceled result; resources are disposed.

Role workshop · debug and verify

If work completes despite cancellation, inspect whether the token was passed to the operation being awaited. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save async example and cancellation cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: One success and one explicit canceled result; resources are disposed.

Expected: One success and one explicit canceled result; resources are disposed.

Troubleshoot: The role exercise differs from the prediction: If work completes despite cancellation, inspect whether the token was passed to the operation being awaited.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: async example and cancellation cases; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with cancellation in asynchronous work. Use the glossary below, then write your prediction for: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C# / .NET Developer role interview. Explain cancellation in asynchronous work using this case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate cancellation in asynchronous work to a system or workflow you know. Explain cancellation in asynchronous work using this case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: If work completes despite cancellation, inspect whether the token was passed to the operation being awaited.

Interview: Explain cancellation in asynchronous work using this case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work.

Ignore the failing case and keep only the successful screenshot.

One success and one explicit canceled result; resources are disposed.

Treat any successful command as proof that all business and access rules passed.

Reference: One success and one explicit canceled result; resources are disposed. — Pass a CancellationToken through asynchronous boundaries. Handle cancellation separately from unexpected exceptions and dispose the token source when the operation ends. One success and one explicit canceled result; resources are disposed.

Sources:

Microsoft: cancel asynchronous tasks: https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/cancel-async-tasks-after-a-period-of-time

Microsoft: create a .NET console application: https://learn.microsoft.com/en-us/dotnet/core/tutorials/create-console-app

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Failure semantics: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.

Apply failure semantics in C# / .NET Developer: Use the concept to complete this role exercise: Design cancellation, asynchronous I/O and a compatible API change

API evolution and durable state: Changing a DTO can break deployed clients even when code compiles. Treat JSON fields, default values and database migrations as separately versioned contracts.

### Failure semantics

Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. In this role, work through: Old JSON contains title only; new JSON optionally contains priority. The practical workshop develops this into: Write old and new JSON fixtures, deserialize both with System.Text.Json, validate defaults, and serialize a stable response. Describe a migration that adds a nullable column before making it mandatory.

Mental model: Track a parcel even when the receipt acknowledgment is lost.

Boundary: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Role application: An updated form must still accept mail sent using the previous edition.

Changing a DTO can break deployed clients even when code compiles. Treat JSON fields, default values and database migrations as separately versioned contracts.

Worked example: Old JSON contains title only; new JSON optionally contains priority.

Shared foundation example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: .NET SDK and ASP.NET Core (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for C# / .NET Developer: Old JSON contains title only; new JSON optionally contains priority.

Predict the worked case

Read this case without running a tool: Old JSON contains title only; new JSON optionally contains priority. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in failure semantics.

Connect the concept to the role

Apply this rule: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies failure semantics to this case: Old JSON contains title only; new JSON optionally contains priority. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Old JSON contains title only; new JSON optionally contains priority. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Failure semantics; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure semantics. Use the glossary below, then write your prediction for: Old JSON contains title only; new JSON optionally contains priority. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C# / .NET Developer role interview. Explain failure semantics using this case: Old JSON contains title only; new JSON optionally contains priority. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure semantics to a system or workflow you know. Explain failure semantics using this case: Old JSON contains title only; new JSON optionally contains priority. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you recover a permanently failing event without blocking all orders?

Interview: Explain failure semantics using this case: Old JSON contains title only; new JSON optionally contains priority. State the evidence, one alternative and where the mental model stops.

Quiz: After the API evolution and durable state rehearsal, check this foundation: A consumer commits its effect and crashes before acknowledging. What must the design handle?

The broker can infer the effect and guarantee no replay.

The effect must be automatically rolled back by the broker.

The message can be delivered again after the effect already happened.

Reference: The message can be delivered again after the effect already happened. — Acknowledgment and the business effect are separate boundaries. Model the crash window and make replay safe.

Sources:

Microsoft: cancel asynchronous tasks: https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/cancel-async-tasks-after-a-period-of-time

Microsoft: create a .NET console application: https://learn.microsoft.com/en-us/dotnet/core/tutorials/create-console-app

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### API evolution and durable state

Changing a DTO can break deployed clients even when code compiles. Treat JSON fields, default values and database migrations as separately versioned contracts. In this role, work through: Old JSON contains title only; new JSON optionally contains priority. The practical workshop develops this into: Write old and new JSON fixtures, deserialize both with System.Text.Json, validate defaults, and serialize a stable response. Describe a migration that adds a nullable column before making it mandatory.

Mental model: An updated form must still accept mail sent using the previous edition.

Boundary: A new required property can break old callers; add a compatibility test before changing the schema.

Worked example: Old JSON contains title only; new JSON optionally contains priority.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: .NET SDK and ASP.NET Core (Open source); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required C# / .NET Developer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write old and new JSON fixtures, deserialize both with System.Text.Json, validate defaults, and serialize a stable response. Describe a migration that adds a nullable column before making it mandatory.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Old JSON contains title only; new JSON optionally contains priority. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write old and new JSON fixtures, deserialize both with System.Text.Json, validate defaults, and serialize a stable response. Describe a migration that adds a nullable column before making it mandatory.

```
dotnet run
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy.

Role workshop · debug and verify

A new required property can break old callers; add a compatibility test before changing the schema. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save DTO fixtures, compatibility checks and rollout ADR. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy.

Expected: Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy.

Troubleshoot: The role exercise differs from the prediction: A new required property can break old callers; add a compatibility test before changing the schema.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: DTO fixtures, compatibility checks and rollout ADR; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with api evolution and durable state. Use the glossary below, then write your prediction for: Old JSON contains title only; new JSON optionally contains priority. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the C# / .NET Developer role interview. Explain api evolution and durable state using this case: Old JSON contains title only; new JSON optionally contains priority. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate api evolution and durable state to a system or workflow you know. Explain api evolution and durable state using this case: Old JSON contains title only; new JSON optionally contains priority. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A new required property can break old callers; add a compatibility test before changing the schema.

Interview: Explain api evolution and durable state using this case: Old JSON contains title only; new JSON optionally contains priority. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Old JSON contains title only; new JSON optionally contains priority.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy.

Reference: Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy. — Changing a DTO can break deployed clients even when code compiles. Treat JSON fields, default values and database migrations as separately versioned contracts. Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy.

Sources:

Microsoft: cancel asynchronous tasks: https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/cancel-async-tasks-after-a-period-of-time

Microsoft: create a .NET console application: https://learn.microsoft.com/en-us/dotnet/core/tutorials/create-console-app

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
