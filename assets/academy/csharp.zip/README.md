# C# / .NET Developer

Software Engineering

Begin with boundaries and ownership. Create a console application using the linked Microsoft tutorial. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Create a console application using the linked Microsoft tutorial

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required.

### Boundaries and ownership
A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.
Mental model: Departments own different ledgers and exchange agreed forms.
Limit: Drawing more boxes does not make a system more reliable.
Example: The order service owns orders; a notification consumer handles messages.
Recall: Which component owns the truth about whether an order exists?

### Apply boundaries and ownership in C# / .NET Developer
Use the concept to complete this role exercise: Create a console application using the linked Microsoft tutorial
Mental model: Departments own different ledgers and exchange agreed forms.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: The order service owns orders; a notification consumer handles messages. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py beginner
```
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Start your language-native extension
Install the supported toolchain using the course source. Use a new empty directory for the commands. The shared reference teaches behavior; port the behavior into this native project.
```
dotnet new console -n AtlasTickets
cd AtlasTickets
dotnet run
```
Expected: Hello, World!

4. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

5. Apply the role exercise
Create a console application using the linked Microsoft tutorial
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: csharp-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Create a console application using the linked Microsoft tutorial? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. For this role, explicitly address: Create a console application using the linked Microsoft tutorial.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Implement a typed ticket DTO and validate its fields

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required.

### Transactional outbox
Write business data and the event to publish in one local transaction, then deliver the event separately.
Mental model: Record a sale and its mailing slip in the same ledger before dispatch.
Limit: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.
Example: The reference stores order-1 and its pending event together.
Recall: Why can publishing first lose consistency if the database write fails?

### Apply transactional outbox in C# / .NET Developer
Use the concept to complete this role exercise: Implement a typed ticket DTO and validate its fields
Mental model: Record a sale and its mailing slip in the same ledger before dispatch.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: The reference stores order-1 and its pending event together. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py intermediate
```
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Start your language-native extension
Install the supported toolchain using the course source. Use a new empty directory for the commands. The shared reference teaches behavior; port the behavior into this native project.
```
dotnet new console -n AtlasTickets
cd AtlasTickets
dotnet run
```
Expected: Hello, World!

4. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

5. Apply the role exercise
Implement a typed ticket DTO and validate its fields
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: csharp-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Implement a typed ticket DTO and validate its fields? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Write business data and the event to publish in one local transaction, then deliver the event separately. For this role, explicitly address: Implement a typed ticket DTO and validate its fields.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Design cancellation, asynchronous I/O and a compatible API change

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required.

### Failure semantics
Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.
Mental model: Track a parcel even when the receipt acknowledgment is lost.
Limit: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.
Example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.
Recall: How would you recover a permanently failing event without blocking all orders?

### Apply failure semantics in C# / .NET Developer
Use the concept to complete this role exercise: Design cancellation, asynchronous I/O and a compatible API change
Mental model: Track a parcel even when the receipt acknowledgment is lost.
Limit: This analogy explains the boundary; the role-specific tool still needs its own configuration and tests.
Example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt. Now record how the same idea appears in your role exercise.
Recall: Explain your chosen implementation, a rejected alternative and one failure case.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py advanced
```
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Start your language-native extension
Install the supported toolchain using the course source. Use a new empty directory for the commands. The shared reference teaches behavior; port the behavior into this native project.
```
dotnet new console -n AtlasTickets
cd AtlasTickets
dotnet run
```
Expected: Hello, World!

4. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

5. Apply the role exercise
Design cancellation, asynchronous I/O and a compatible API change
Expected: Save a role-specific code change, test or decision artifact and explain one remaining limitation.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: csharp-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Design cancellation, asynchronous I/O and a compatible API change? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. For this role, explicitly address: Design cancellation, asynchronous I/O and a compatible API change.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Microsoft: create a .NET console application: https://learn.microsoft.com/en-us/dotnet/core/tutorials/create-console-app
AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html
Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/
Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
