# C# / .NET Developer

Software Engineering

Start with records and explicit validation. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward DTO fixtures, compatibility checks and rollout ADR.

## beginner

Create AtlasTickets using dotnet new console. Define a Ticket record and a factory that trims and validates titles. Add executable checks for valid, blank and oversized titles; return a nonzero exit on failed checks.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Boundaries and ownership
A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.
Mental model: Departments own different ledgers and exchange agreed forms.
Limit: Drawing more boxes does not make a system more reliable.
Example: The order service owns orders; a notification consumer handles messages.
Recall: Which component owns the truth about whether an order exists?

### Records and explicit validation
A C# record expresses data shape and value equality; it does not automatically validate business constraints. Keep a checked construction path for user input.
Mental model: A typed envelope still needs its contents inspected.
Limit: Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime.
Example: Ticket(" A ") becomes A; an empty title fails before storage.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Ticket(" A ") becomes A; an empty title fails before storage. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create AtlasTickets using dotnet new console. Define a Ticket record and a factory that trims and validates titles. Add executable checks for valid, blank and oversized titles; return a nonzero exit on failed checks.
```
dotnet new console -n AtlasTickets
cd AtlasTickets
dotnet run
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: The three checks distinguish type correctness from business validity.

6. Role workshop · debug and verify
Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save Program.cs and a documented dotnet run transcript. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: The three checks distinguish type correctness from business validity.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Records and explicit validation: Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: Program.cs and a documented dotnet run transcript
The three checks distinguish type correctness from business validity.

Interview: Work through this C# / .NET Developer case: Ticket(" A ") becomes A; an empty title fails before storage. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A C# record expresses data shape and value equality; it does not automatically validate business constraints. Keep a checked construction path for user input. Expected evidence: The three checks distinguish type correctness from business validity. Diagnosis: Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime. State the limits of the mental model: A typed envelope still needs its contents inspected.

Resume: Built Program.cs and a documented dotnet run transcript using .NET SDK and ASP.NET Core; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Add an async operation using Task.Delay(delay, token), create CancellationTokenSource, call CancelAfter and catch OperationCanceledException. Test a fast successful case and a canceled case without broad catch-and-success behavior.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transactional outbox
Write business data and the event to publish in one local transaction, then deliver the event separately.
Mental model: Record a sale and its mailing slip in the same ledger before dispatch.
Limit: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.
Example: The reference stores order-1 and its pending event together.
Recall: Why can publishing first lose consistency if the database write fails?

### Cancellation in asynchronous work
Pass a CancellationToken through asynchronous boundaries. Handle cancellation separately from unexpected exceptions and dispose the token source when the operation ends.
Mental model: A stop request must reach every worker in the chain, not just the front desk.
Limit: If work completes despite cancellation, inspect whether the token was passed to the operation being awaited.
Example: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work.
Recall: Explain the expected result before running the exercise, then diagnose this failure: If work completes despite cancellation, inspect whether the token was passed to the operation being awaited.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add an async operation using Task.Delay(delay, token), create CancellationTokenSource, call CancelAfter and catch OperationCanceledException. Test a fast successful case and a canceled case without broad catch-and-success behavior.
```
dotnet run
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: One success and one explicit canceled result; resources are disposed.

6. Role workshop · debug and verify
If work completes despite cancellation, inspect whether the token was passed to the operation being awaited. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save async example and cancellation cases. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One success and one explicit canceled result; resources are disposed.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cancellation in asynchronous work: If work completes despite cancellation, inspect whether the token was passed to the operation being awaited.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: async example and cancellation cases
One success and one explicit canceled result; resources are disposed.

Interview: Work through this C# / .NET Developer case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Pass a CancellationToken through asynchronous boundaries. Handle cancellation separately from unexpected exceptions and dispose the token source when the operation ends. Expected evidence: One success and one explicit canceled result; resources are disposed. Diagnosis: If work completes despite cancellation, inspect whether the token was passed to the operation being awaited. State the limits of the mental model: A stop request must reach every worker in the chain, not just the front desk.

Resume: Built async example and cancellation cases using .NET SDK and ASP.NET Core; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Write old and new JSON fixtures, deserialize both with System.Text.Json, validate defaults, and serialize a stable response. Describe a migration that adds a nullable column before making it mandatory.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Failure semantics
Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.
Mental model: Track a parcel even when the receipt acknowledgment is lost.
Limit: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.
Example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.
Recall: How would you recover a permanently failing event without blocking all orders?

### API evolution and durable state
Changing a DTO can break deployed clients even when code compiles. Treat JSON fields, default values and database migrations as separately versioned contracts.
Mental model: An updated form must still accept mail sent using the previous edition.
Limit: A new required property can break old callers; add a compatibility test before changing the schema.
Example: Old JSON contains title only; new JSON optionally contains priority.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A new required property can break old callers; add a compatibility test before changing the schema.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Old JSON contains title only; new JSON optionally contains priority. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write old and new JSON fixtures, deserialize both with System.Text.Json, validate defaults, and serialize a stable response. Describe a migration that adds a nullable column before making it mandatory.
```
dotnet run
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy.

6. Role workshop · debug and verify
A new required property can break old callers; add a compatibility test before changing the schema. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save DTO fixtures, compatibility checks and rollout ADR. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
API evolution and durable state: A new required property can break old callers; add a compatibility test before changing the schema.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: DTO fixtures, compatibility checks and rollout ADR
Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy.

Interview: Work through this C# / .NET Developer case: Old JSON contains title only; new JSON optionally contains priority. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Changing a DTO can break deployed clients even when code compiles. Treat JSON fields, default values and database migrations as separately versioned contracts. Expected evidence: Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy. Diagnosis: A new required property can break old callers; add a compatibility test before changing the schema. State the limits of the mental model: An updated form must still accept mail sent using the previous edition.

Resume: Built DTO fixtures, compatibility checks and rollout ADR using .NET SDK and ASP.NET Core; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Microsoft: create a .NET console application: https://learn.microsoft.com/en-us/dotnet/core/tutorials/create-console-app
AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html
Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/
Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
Microsoft: cancel asynchronous tasks: https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/cancel-async-tasks-after-a-period-of-time
