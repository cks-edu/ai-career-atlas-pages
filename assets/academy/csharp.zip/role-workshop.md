# C# / .NET Developer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Records and explicit validation

A C# record expresses data shape and value equality; it does not automatically validate business constraints. Keep a checked construction path for user input.
Mental model: A typed envelope still needs its contents inspected.
Case: Ticket(" A ") becomes A; an empty title fails before storage.
Task: Create AtlasTickets using dotnet new console. Define a Ticket record and a factory that trims and validates titles. Add executable checks for valid, blank and oversized titles; return a nonzero exit on failed checks.
Acceptance: The three checks distinguish type correctness from business validity.
Troubleshooting: Nullable annotations help analysis but do not validate an HTTP payload; check values at runtime.
Deliverable: Program.cs and a documented dotnet run transcript

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Cancellation in asynchronous work

Pass a CancellationToken through asynchronous boundaries. Handle cancellation separately from unexpected exceptions and dispose the token source when the operation ends.
Mental model: A stop request must reach every worker in the chain, not just the front desk.
Case: A 500 ms Task.Delay with a token canceled after 50 ms must not report completed work.
Task: Add an async operation using Task.Delay(delay, token), create CancellationTokenSource, call CancelAfter and catch OperationCanceledException. Test a fast successful case and a canceled case without broad catch-and-success behavior.
Acceptance: One success and one explicit canceled result; resources are disposed.
Troubleshooting: If work completes despite cancellation, inspect whether the token was passed to the operation being awaited.
Deliverable: async example and cancellation cases

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
API evolution and durable state

Changing a DTO can break deployed clients even when code compiles. Treat JSON fields, default values and database migrations as separately versioned contracts.
Mental model: An updated form must still accept mail sent using the previous edition.
Case: Old JSON contains title only; new JSON optionally contains priority.
Task: Write old and new JSON fixtures, deserialize both with System.Text.Json, validate defaults, and serialize a stable response. Describe a migration that adds a nullable column before making it mandatory.
Acceptance: Both versions produce valid tickets during the compatibility window; unknown or invalid values have an explicit policy.
Troubleshooting: A new required property can break old callers; add a compatibility test before changing the schema.
Deliverable: DTO fixtures, compatibility checks and rollout ADR

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
