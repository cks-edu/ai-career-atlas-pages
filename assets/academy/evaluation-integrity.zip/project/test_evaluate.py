import unittest,json
from pathlib import Path
from evaluate import score
class EvaluationTests(unittest.TestCase):
    def test_missing_counted(self):
        result=score(json.loads(Path('cases.json').read_text()));self.assertEqual(result['correct'],1);self.assertEqual(result['count'],3);self.assertEqual(result['slices']['missing']['missing'],1)
    def test_duplicate(self):
        row={'id':'x','slice':'s','expected':'yes','prediction':'yes'}
        with self.assertRaises(ValueError): score([row,row])
if __name__=='__main__': unittest.main()
