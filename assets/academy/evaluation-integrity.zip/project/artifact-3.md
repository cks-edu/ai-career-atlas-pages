# Benchmark integrity report

Project: Tamper-resistant benchmark scoring
Status: blank work product — not completed evidence

## Purpose and audience
Separate task execution from scoring and detect benchmark shortcuts.

## Required content
Run honest, shortcut and tampering baselines. Blind manual review where exact scoring is insufficient and document evaluator access boundaries.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.

## Failure evidence
Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
