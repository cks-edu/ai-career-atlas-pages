# Tamper-resistant benchmark scoring

Career: Evaluation integrity & reward-hacking analysis
Reviewed: 2026-10-22

Separate task execution from scoring and detect benchmark shortcuts.

## Prerequisites
Benchmark design, reproducibility and adversarial reasoning. Usually part of evaluation or research infrastructure roles.

## Included starter versus your implementation
A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+; the scoring skeleton needs only the standard library.

```sh
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Extend evaluate.py to hash input fixtures, candidate artifacts and evaluator version. Store immutable run records before calculating summaries.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Run honest, shortcut and tampering baselines. Blind manual review where exact scoring is insufficient and document evaluator access boundaries.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Separate runner/scorer implementation — artifact-1.md
2. Integrity tests and artifact hashes — artifact-2.md
3. Benchmark integrity report — artifact-3.md

## Troubleshooting
- Missing predictions: keep them in the denominator.
- Metric disagrees with humans: inspect rubric validity before optimizing the model.
- Scores change: compare candidate, dataset and evaluator versions separately.

## Extension
Add fresh task variants and compare whether gains survive removal of shortcut opportunities.

## Primary learning resources
- Python: https://docs.python.org/3/library/venv.html — Open source · local; Isolated environments and reproducible scripts.
- GitHub Actions: https://docs.github.com/en/actions — Commercial hosted service · usage limits; CI checks and reviewable build artifacts; paid usage may apply.
- MLflow: https://mlflow.org/docs/latest/ml/tracking/quickstart/ — Open source · hosted offerings optional; Record experiments, parameters and evaluation artifacts.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
