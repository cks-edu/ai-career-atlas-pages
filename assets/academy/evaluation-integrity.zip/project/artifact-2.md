# Integrity tests and artifact hashes

Project: Tamper-resistant benchmark scoring
Status: blank work product — not completed evidence

## Purpose and audience
Separate task execution from scoring and detect benchmark shortcuts.

## Required content
Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.

## Failure evidence
Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
