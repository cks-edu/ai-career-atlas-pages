"""Deterministic scoring skeleton; replace exact match for your task and validate it."""
import hashlib,json
from pathlib import Path

def score(rows):
    if not rows: raise ValueError('No cases')
    ids=[r['id'] for r in rows]
    if len(set(ids))!=len(ids): raise ValueError('Duplicate case IDs')
    slices={}
    for row in rows:
        if not isinstance(row.get('expected'),str) or not row['expected']: raise ValueError('Missing reference')
        s=slices.setdefault(row['slice'],{'count':0,'correct':0,'missing':0})
        s['count']+=1;s['correct']+=int(row.get('prediction')==row['expected']);s['missing']+=int(row.get('prediction') is None)
    return {'count':len(rows),'correct':sum(x['correct'] for x in slices.values()),'slices':slices}
if __name__=='__main__':
    raw=Path('cases.json').read_bytes();result=score(json.loads(raw));result['cases_sha256']=hashlib.sha256(raw).hexdigest()
    Path('output').mkdir(exist_ok=True);Path('output/evaluation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
