# Separate runner/scorer implementation

Project: Tamper-resistant benchmark scoring
Status: blank work product — not completed evidence

## Purpose and audience
Separate task execution from scoring and detect benchmark shortcuts.

## Required content
Extend evaluate.py to hash input fixtures, candidate artifacts and evaluator version. Store immutable run records before calculating summaries.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.

## Failure evidence
Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
