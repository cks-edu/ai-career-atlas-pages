# Start here

Read PROJECT.md, inspect the included files, then follow the eight milestones. Blank artifacts are not completed portfolio evidence.
