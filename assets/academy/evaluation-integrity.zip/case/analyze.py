"""Local synthetic evidence replay. No model calls, network or paid resources."""
import argparse,csv,json,math
from pathlib import Path

def validate(policy):
    if not isinstance(policy,dict) or set(policy)!={'field','operator','threshold'}:
        raise ValueError('Use exactly field, operator and threshold')
    if not isinstance(policy['field'],str) or policy['operator'] not in ('>=','>'):
        raise ValueError('Invalid field or operator')
    if isinstance(policy['threshold'],bool) or not isinstance(policy['threshold'],(int,float)) or not math.isfinite(policy['threshold']):
        raise ValueError('Threshold must be a finite number')
    return policy

def classify(rows,policy):
    validate(policy)
    result=[]
    for row in rows:
        value=float(row[policy['field']])
        if not math.isfinite(value): raise ValueError('Evidence values must be finite')
        flag=value>=policy['threshold'] if policy['operator']=='>=' else value>policy['threshold']
        result.append({'id':row['id'],'value':value,'decision':'review' if flag else 'within_demo_bound'})
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--policy',default='policy.json');parser.add_argument('--data',default='evidence.csv');args=parser.parse_args()
    with open(args.data,newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
    policy=json.loads(Path(args.policy).read_text(encoding='utf-8'))
    report=classify(rows,policy)
    print(json.dumps({'synthetic':True,'records':report,'review_count':sum(r['decision']=='review' for r in report)},indent=2))
