"""Run from the extracted pack directory. Intentionally fails until policy.json is repaired."""
import csv,json,unittest
from pathlib import Path
from analyze import classify,validate
ROOT=Path(__file__).resolve().parent
contract=json.loads((ROOT/'contract.json').read_text())
policy=json.loads((ROOT/'policy.json').read_text())
class ContractTests(unittest.TestCase):
    def test_fixture_decisions(self):
        with (ROOT/'evidence.csv').open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
        self.assertEqual([r['decision'] for r in classify(rows,policy)],contract['decisions'])
    def test_boundary(self):
        expected=contract['policy']; t=expected['threshold']; delta=max(abs(t)*0.001,0.000001)
        rows=[{'id':str(i),expected['field']:v} for i,v in enumerate([t-delta,t,t+delta])]
        target=['within_demo_bound','review' if expected['operator']=='>=' else 'within_demo_bound','review']
        self.assertEqual([r['decision'] for r in classify(rows,policy)],target)
    def test_bad_threshold_rejected(self):
        for value in [True,'1',float('nan'),float('inf')]:
            with self.assertRaises(ValueError): validate({**policy,'threshold':value})
    def test_missing_evidence_rejected(self):
        with self.assertRaises(KeyError): classify([{'id':'missing'}],policy)
if __name__=='__main__': unittest.main(verbosity=2)
