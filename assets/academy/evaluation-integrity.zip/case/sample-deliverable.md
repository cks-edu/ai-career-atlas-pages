# SAMPLE — Benchmark provenance and contamination report
Role: Evaluation integrity & reward-hacking analysis
Case: An impressive score uses leaked tasks
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus.

## Evidence table
| Record | known_overlaps (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 3 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three benchmark subsets have known overlap and cannot support the claimed uncontaminated comparison.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in evaluation integrity & reward-hacking analysis.
Before release: Test seeded overlaps and paraphrases, stating detector limitations.

## Design choice and trade-off
Keep evaluation provenance separate and reviewable; use independent outcome verifiers.
No detected overlap is not proof of a clean benchmark; similarity tests have blind spots.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
False-success benchmark: Publish a reproducible false-pass reduction.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
