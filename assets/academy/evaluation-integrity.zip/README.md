# Evaluation integrity & reward-hacking analysis

AI Engineering · Beginner → Intermediate → Advanced

Start with Evaluator trust boundaries. An evaluation loses credibility if the system being tested can alter its score. Keep scoring authority separate from generated claims. Then try Find a scoring conflict. The three levels build toward Tamper-resistant benchmark scoring. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Evaluator trust boundaries

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Evaluator trust boundaries
Separate the candidate's outputs from expected answers and grading logic. Treat evidence supplied by the candidate as a claim to verify.
Mental model: A student submits an answer sheet but cannot edit the marking key.
Boundary: A protected answer key can still be incomplete or incorrect.
Worked example: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: An impressive score uses leaked tasks
The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus. Three benchmark subsets have known overlap and cannot support the claimed uncontaminated comparison. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks.
Recall: Test seeded overlaps and paraphrases, stating detector limitations. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Evaluator trust boundaries: Separate the candidate's outputs from expected answers and grading logic. Treat evidence supplied by the candidate as a claim to verify.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An evaluation loses credibility if the system being tested can alter its score. Keep scoring authority separate from generated claims.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine an agent edits solution.py and can also edit score.json, which the evaluator trusts as the final grade.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after evaluation diagram and a trust-boundary note.

3. Try step 2
Draw who can write each file and identify the trust problem.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after evaluation diagram and a trust-boundary note.

4. Try step 3
Redesign the process so an independent evaluator runs protected checks and records the score outside the agent’s writable area.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after evaluation diagram and a trust-boundary note.

5. Explain and check your result
The agent cannot award itself success by changing score.json or its own written explanation. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A before/after evaluation diagram and a trust-boundary note. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus. Apply this toy-case rule manually: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three benchmark subsets have known overlap and cannot support the claimed uncontaminated comparison. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Evaluation integrity & reward-hacking analysis.
Imagine an agent edits solution.py and can also edit score.json, which the evaluator trusts as the final grade.
Draw who can write each file and identify the trust problem.
Redesign the process so an independent evaluator runs protected checks and records the score outside the agent’s writable area.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A before/after evaluation diagram and a trust-boundary note. Include beginner-worksheet.md and your completed Benchmark provenance and contamination report.
Check: The agent cannot award itself success by changing score.json or its own written explanation.

### Interview
Explain your beginner solution for Evaluation integrity & reward-hacking analysis. Use this scenario: The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus.
Review: Start with the task and permitted scope. Explain evaluator trust boundaries: Separate the candidate's outputs from expected answers and grading logic. Treat evidence supplied by the candidate as a claim to verify. Show the input and observed output, then address Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A before/after evaluation diagram and a trust-boundary note. Include beginner-worksheet.md and your completed Benchmark provenance and contamination report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — False-pass construction

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Benchmark design, reproducibility and adversarial reasoning. Usually part of evaluation or research infrastructure roles.

### False-pass construction
Create cases that look successful while violating the actual task. Use them to test whether the grader checks outcomes or merely superficial markers.
Mental model: A counterfeit ticket tests whether the gate checks validity or only its color.
Boundary: Known false-pass tests do not enumerate all possible gaming strategies.
Worked example: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Tamper-resistant benchmark scoring
Separate task execution from scoring and detect benchmark shortcuts. Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory.
Recall: Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. Identify one observation that would contradict your claim.

### Terms
False-pass construction: Create cases that look successful while violating the actual task. Use them to test whether the grader checks outcomes or merely superficial markers.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Separate task execution from scoring and detect benchmark shortcuts. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Extend evaluate.py to hash input fixtures, candidate artifacts and evaluator version. Store immutable run records before calculating summaries.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Separate task execution from scoring and detect benchmark shortcuts.
Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory.
Extend evaluate.py to hash input fixtures, candidate artifacts and evaluator version. Store immutable run records before calculating summaries.
Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration.
Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.
Deliverables: Separate runner/scorer implementation; Integrity tests and artifact hashes. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Evaluation integrity & reward-hacking analysis. Use this scenario: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.
Review: Start with the task and permitted scope. Explain false-pass construction: Create cases that look successful while violating the actual task. Use them to test whether the grader checks outcomes or merely superficial markers. Show the input and observed output, then address Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Separate runner/scorer implementation; Integrity tests and artifact hashes. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Metric resilience

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Metric resilience
Inspect how optimizing a score could harm the intended outcome. Add independent checks, holdouts and review of suspiciously easy gains.
Mental model: A school counting attendance alone may reward sitting in class without learning.
Boundary: Adding more metrics can still leave correlated blind spots.
Worked example: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Tamper-resistant benchmark scoring
Separate task execution from scoring and detect benchmark shortcuts. Run honest, shortcut and tampering baselines. Blind manual review where exact scoring is insufficient and document evaluator access boundaries.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.
Worked example: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.
Recall: Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. Identify one observation that would contradict your claim.

### Terms
Metric resilience: Inspect how optimizing a score could harm the intended outcome. Add independent checks, holdouts and review of suspiciously easy gains.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Lab
Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Separate task execution from scoring and detect benchmark shortcuts. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

2. Prepare the project inputs
Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Extend evaluate.py to hash input fixtures, candidate artifacts and evaluator version. Store immutable run records before calculating summaries.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Run honest, shortcut and tampering baselines. Blind manual review where exact scoring is insufficient and document evaluator access boundaries.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Missing predictions: keep them in the denominator.
Metric disagrees with humans: inspect rubric validity before optimizing the model.
Scores change: compare candidate, dataset and evaluator versions separately.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

### Portfolio
Separate task execution from scoring and detect benchmark shortcuts.
Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory.
Extend evaluate.py to hash input fixtures, candidate artifacts and evaluator version. Store immutable run records before calculating summaries.
Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration.
Run honest, shortcut and tampering baselines. Blind manual review where exact scoring is insufficient and document evaluator access boundaries.
Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.
Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.
Add fresh task variants and compare whether gains survive removal of shortcut opportunities.
Deliverables: Separate runner/scorer implementation; Integrity tests and artifact hashes; Benchmark integrity report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. A reviewer must reproduce one result and identify which capabilities you implemented. Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.

### Interview
Explain your advanced solution for Evaluation integrity & reward-hacking analysis. Use this scenario: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.
Review: Start with the task and permitted scope. Explain metric resilience: Inspect how optimizing a score could harm the intended outcome. Add independent checks, holdouts and review of suspiciously easy gains. Show the input and observed output, then address Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Separate runner/scorer implementation; Integrity tests and artifact hashes; Benchmark integrity report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
Python — Open source · local
Isolated environments and reproducible scripts.
Alternative: A spreadsheet for manual evidence exercises, or another supported programming language for implementation; reproduce the same acceptance checks.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

GitHub Actions — Commercial hosted service · usage limits
CI checks and reviewable build artifacts; paid usage may apply.
Alternative: GitLab CI (open-core/commercial offerings) or Jenkins (open source); runners and compute still need operating resources.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

MLflow — Open source · hosted offerings optional
Record experiments, parameters and evaluation artifacts.
Alternative: A versioned Git/CSV experiment manifest for a small project; Weights & Biases offers commercial hosted tracking with plan-specific terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
Python: https://docs.python.org/3/library/venv.html
GitHub Actions: https://docs.github.com/en/actions
MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/
Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
GitHub Actions: https://docs.github.com/en/actions
MLflow: https://mlflow.org/docs/latest/
