# Evaluation integrity & reward-hacking analysis — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Evaluator trust boundaries: Separate the candidate's outputs from expected answers and grading logic. Treat evidence supplied by the candidate as a claim to verify.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Evaluator trust boundaries

Separate the candidate's outputs from expected answers and grading logic. Treat evidence supplied by the candidate as a claim to verify. In this role, work through: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A student submits an answer sheet but cannot edit the marking key.

Boundary: A protected answer key can still be incomplete or incorrect.

Worked example: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); GitHub Actions (Commercial hosted service · usage limits); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Evaluation integrity & reward-hacking analysis: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state.

Predict the worked case

Read this case without running a tool: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in evaluator trust boundaries.

Connect the concept to the role

Apply this rule: Separate the candidate's outputs from expected answers and grading logic. Treat evidence supplied by the candidate as a claim to verify. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A protected answer key can still be incomplete or incorrect.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies evaluator trust boundaries to this case: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Evaluator trust boundaries; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with evaluator trust boundaries. Use the glossary below, then write your prediction for: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Evaluation integrity & reward-hacking analysis role interview. Explain evaluator trust boundaries using this case: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate evaluator trust boundaries to a system or workflow you know. Explain evaluator trust boundaries using this case: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain evaluator trust boundaries using this case: An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state.

Separate the candidate's outputs from expected answers and grading logic. Treat evidence supplied by the candidate as a claim to verify.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Separate the candidate's outputs from expected answers and grading logic. Treat evidence supplied by the candidate as a claim to verify. — Separate the candidate's outputs from expected answers and grading logic. Treat evidence supplied by the candidate as a claim to verify. A protected answer key can still be incomplete or incorrect.

Sources:

Python: https://docs.python.org/3/library/venv.html

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

### Diagnose: An impressive score uses leaked tasks

The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus. Three benchmark subsets have known overlap and cannot support the claimed uncontaminated comparison. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A student submits an answer sheet but cannot edit the marking key.

An agent writes passed=true in its workspace; the evaluator instead checks an independently stored expected state.

Worked example: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: Python (Open source · local); GitHub Actions (Commercial hosted service · usage limits); MLflow (Open source · hosted offerings optional)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus. Three benchmark subsets have known overlap and cannot support the claimed uncontaminated comparison. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus. Apply this toy-case rule manually: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An evaluation loses credibility if the system being tested can alter its score. Keep scoring authority separate from generated claims.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine an agent edits solution.py and can also edit score.json, which the evaluator trusts as the final grade.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after evaluation diagram and a trust-boundary note.

Preparation · Try step 2

Draw who can write each file and identify the trust problem.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after evaluation diagram and a trust-boundary note.

Preparation · Try step 3

Redesign the process so an independent evaluator runs protected checks and records the score outside the agent’s writable area.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A before/after evaluation diagram and a trust-boundary note.

Preparation · Explain and check your result

The agent cannot award itself success by changing score.json or its own written explanation. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A before/after evaluation diagram and a trust-boundary note. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus. Apply this toy-case rule manually: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three benchmark subsets have known overlap and cannot support the claimed uncontaminated comparison. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three benchmark subsets have known overlap and cannot support the claimed uncontaminated comparison. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: an impressive score uses leaked tasks. Use the glossary below, then write your prediction for: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Evaluation integrity & reward-hacking analysis role interview. Explain diagnose: an impressive score uses leaked tasks using this case: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: an impressive score uses leaked tasks to a system or workflow you know. Explain diagnose: an impressive score uses leaked tasks using this case: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Test seeded overlaps and paraphrases, stating detector limitations. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: an impressive score uses leaked tasks using this case: Review when known_overlaps >= 1 (count). This is a declared toy-case contract, not an industry standard. Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks. State the evidence, one alternative and where the mental model stops.

Quiz: An impressive score uses leaked tasks: The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus.

Change the acceptance rule after seeing an inconvenient result.

Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks.

Omit failed cases and report only the successful demonstrations.

Reference: Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks. — Quarantine overlaps, report affected results and evaluate on independently sourced held-out tasks. Test seeded overlaps and paraphrases, stating detector limitations.

Sources:

Python: https://docs.python.org/3/library/venv.html

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Benchmark design, reproducibility and adversarial reasoning. Usually part of evaluation or research infrastructure roles.

Terms:

False-pass construction: Create cases that look successful while violating the actual task. Use them to test whether the grader checks outcomes or merely superficial markers.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### False-pass construction

Create cases that look successful while violating the actual task. Use them to test whether the grader checks outcomes or merely superficial markers. In this role, work through: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A counterfeit ticket tests whether the gate checks validity or only its color.

Boundary: Known false-pass tests do not enumerate all possible gaming strategies.

Worked example: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Benchmark design, reproducibility and adversarial reasoning. Usually part of evaluation or research infrastructure roles.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); GitHub Actions (Commercial hosted service · usage limits); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Evaluation integrity & reward-hacking analysis: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it.

Predict the worked case

Read this case without running a tool: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in false-pass construction.

Connect the concept to the role

Apply this rule: Create cases that look successful while violating the actual task. Use them to test whether the grader checks outcomes or merely superficial markers. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Known false-pass tests do not enumerate all possible gaming strategies.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies false-pass construction to this case: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for False-pass construction; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with false-pass construction. Use the glossary below, then write your prediction for: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Evaluation integrity & reward-hacking analysis role interview. Explain false-pass construction using this case: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate false-pass construction to a system or workflow you know. Explain false-pass construction using this case: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain false-pass construction using this case: A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it.

Treat a passing starter as proof of the whole role workflow.

Create cases that look successful while violating the actual task. Use them to test whether the grader checks outcomes or merely superficial markers.

Ignore the failure because the tool produced an output.

Reference: Create cases that look successful while violating the actual task. Use them to test whether the grader checks outcomes or merely superficial markers. — Create cases that look successful while violating the actual task. Use them to test whether the grader checks outcomes or merely superficial markers. Known false-pass tests do not enumerate all possible gaming strategies.

Sources:

Python: https://docs.python.org/3/library/venv.html

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

### Integrate: Tamper-resistant benchmark scoring

Separate task execution from scoring and detect benchmark shortcuts. Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration. In this role, work through: Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: A counterfeit ticket tests whether the gate checks validity or only its color.

A patch prints the expected success phrase without changing data; the grader must inspect the data and reject it.

Worked example: Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); GitHub Actions (Commercial hosted service · usage limits); MLflow (Open source · hosted offerings optional)

Separate task execution from scoring and detect benchmark shortcuts. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Separate task execution from scoring and detect benchmark shortcuts.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Extend evaluate.py to hash input fixtures, candidate artifacts and evaluator version. Store immutable run records before calculating summaries.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The benchmark protocol forbids exact task identifiers shared with the disclosed tuning corpus. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-intermediate-2.md: Separate runner/scorer implementation; Integrity tests and artifact hashes. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: tamper-resistant benchmark scoring. Use the glossary below, then write your prediction for: Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Evaluation integrity & reward-hacking analysis role interview. Explain integrate: tamper-resistant benchmark scoring using this case: Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: tamper-resistant benchmark scoring to a system or workflow you know. Explain integrate: tamper-resistant benchmark scoring using this case: Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. Identify one observation that would contradict your claim.

Interview: Explain integrate: tamper-resistant benchmark scoring using this case: Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Tamper-resistant benchmark scoring at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.

Reference: Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. — Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.

Sources:

Python: https://docs.python.org/3/library/venv.html

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Metric resilience: Inspect how optimizing a score could harm the intended outcome. Add independent checks, holdouts and review of suspiciously easy gains.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rubric: Written scoring criteria with examples, boundaries and a way to handle uncertainty.

### Metric resilience

Inspect how optimizing a score could harm the intended outcome. Add independent checks, holdouts and review of suspiciously easy gains. In this role, work through: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A school counting attendance alone may reward sitting in class without learning.

Boundary: Adding more metrics can still leave correlated blind spots.

Worked example: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: Python (Open source · local); GitHub Actions (Commercial hosted service · usage limits); MLflow (Open source · hosted offerings optional)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Evaluation integrity & reward-hacking analysis: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions.

Predict the worked case

Read this case without running a tool: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in metric resilience.

Connect the concept to the role

Apply this rule: Inspect how optimizing a score could harm the intended outcome. Add independent checks, holdouts and review of suspiciously easy gains. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Adding more metrics can still leave correlated blind spots.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies metric resilience to this case: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Metric resilience; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with metric resilience. Use the glossary below, then write your prediction for: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Evaluation integrity & reward-hacking analysis role interview. Explain metric resilience using this case: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate metric resilience to a system or workflow you know. Explain metric resilience using this case: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain metric resilience using this case: An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Inspect how optimizing a score could harm the intended outcome. Add independent checks, holdouts and review of suspiciously easy gains.

Reference: Inspect how optimizing a score could harm the intended outcome. Add independent checks, holdouts and review of suspiciously easy gains. — Inspect how optimizing a score could harm the intended outcome. Add independent checks, holdouts and review of suspiciously easy gains. Adding more metrics can still leave correlated blind spots.

Sources:

Python: https://docs.python.org/3/library/venv.html

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/

### Defend: Tamper-resistant benchmark scoring

Separate task execution from scoring and detect benchmark shortcuts. Run honest, shortcut and tampering baselines. Blind manual review where exact scoring is insufficient and document evaluator access boundaries. In this role, work through: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Role application: A school counting attendance alone may reward sitting in class without learning.

An agent increases pass rate by skipping hard tasks; include every assigned task in the denominator and report abstentions.

Worked example: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.

Setup: Use Python 3.11+; the scoring skeleton needs only the standard library. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Python (Open source · local); GitHub Actions (Commercial hosted service · usage limits); MLflow (Open source · hosted offerings optional)

Separate task execution from scoring and detect benchmark shortcuts. A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process. No live model calls or benchmark results are included. Model APIs or human review may add cost; the fixture is not an advanced benchmark by itself.

Separate task execution from scoring and detect benchmark shortcuts.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; the scoring skeleton needs only the standard library. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python evaluate.py
python -m unittest -v
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A three-case exact-match scoring skeleton with missing-output and duplicate-ID tests. You author the role-specific corpus, evaluator, outcome checks and review process.

Prepare the project inputs

Create ten local file-transformation tasks with private outcome assertions and a public task description. Keep reference answers outside the writable task directory.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Extend evaluate.py to hash input fixtures, candidate artifacts and evaluator version. Store immutable run records before calculating summaries.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create a scorer that reads final artifacts without trusting candidate success messages. Add tests for missing output, extra files and attempts to modify scoring configuration.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Run honest, shortcut and tampering baselines. Blind manual review where exact scoring is insufficient and document evaluator access boundaries.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. A reviewer must reproduce one result and identify which capabilities you implemented. Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Preserve raw cases and output/evaluation.json. Deactivate the environment when finished.

Deliverable: lesson-advanced-2.md: Separate runner/scorer implementation; Integrity tests and artifact hashes; Benchmark integrity report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: tamper-resistant benchmark scoring. Use the glossary below, then write your prediction for: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Evaluation integrity & reward-hacking analysis role interview. Explain defend: tamper-resistant benchmark scoring using this case: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: tamper-resistant benchmark scoring to a system or workflow you know. Explain defend: tamper-resistant benchmark scoring using this case: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked. Identify one observation that would contradict your claim.

Interview: Explain defend: tamper-resistant benchmark scoring using this case: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Tamper-resistant benchmark scoring at this level?

Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases. — Have a candidate write a fake metrics file or copy an exposed reference answer. The scorer must ignore self-reported success and detect contaminated cases. Report verified outcomes, detected tampering, ambiguous cases and evaluator sensitivity. A hidden test can still be invalid or leaked.

Sources:

Python: https://docs.python.org/3/library/venv.html

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/ml/getting-started/quickstart/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

GitHub Actions: https://docs.github.com/en/actions

MLflow: https://mlflow.org/docs/latest/
