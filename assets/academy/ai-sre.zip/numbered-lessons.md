# AI site reliability engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

AI service indicators: Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

SLO: Service-level objective: a target for a defined user-facing indicator over a stated measurement window.

### AI service indicators

Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator. In this role, work through: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An open hospital door is not the same as receiving treatment.

Boundary: Semantic quality may need sampled review and uncertain labels.

Worked example: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: kind (Open source · local containers); Prometheus (Open source); OpenTelemetry (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI site reliability engineer: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately.

Predict the worked case

Read this case without running a tool: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in ai service indicators.

Connect the concept to the role

Apply this rule: Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Semantic quality may need sampled review and uncertain labels.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies ai service indicators to this case: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for AI service indicators; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with ai service indicators. Use the glossary below, then write your prediction for: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI site reliability engineer role interview. Explain ai service indicators using this case: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate ai service indicators to a system or workflow you know. Explain ai service indicators using this case: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain ai service indicators using this case: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately.

Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator. — Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator. Semantic quality may need sampled review and uncertain labels.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Prometheus: https://prometheus.io/docs/introduction/overview/

OpenTelemetry: https://opentelemetry.io/docs/

Google SRE books: https://sre.google/books/

OpenTelemetry: https://opentelemetry.io/docs/

Prometheus: https://prometheus.io/docs/introduction/overview/

### Diagnose: HTTP success conceals failed tasks

The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Three successful HTTP responses violate the user-task contract. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an outcome probe alongside availability metrics and define an owned mitigation. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: An open hospital door is not the same as receiving treatment.

Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately.

Worked example: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an outcome probe alongside availability metrics and define an owned mitigation.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: kind (Open source · local containers); Prometheus (Open source); OpenTelemetry (Open source)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Three successful HTTP responses violate the user-task contract. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Apply this toy-case rule manually: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Reliability describes whether users can complete their task. An HTTP success response alone does not show that an AI answer is useful.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Make five rows: three correct answers under 2 seconds; one incorrect answer in 1 second with HTTP 200 (a successful web response); one timeout. Assume all three correct answers also have HTTP 200.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row scorecard and a plain-language reliability rule.

Preparation · Try step 2

Calculate HTTP success and correct-on-time task success separately.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row scorecard and a plain-language reliability rule.

Preparation · Try step 3

Write a rule defining “correct on time” and name who would review answer correctness.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row scorecard and a plain-language reliability rule.

Preparation · Explain and check your result

HTTP success is 4/5; correct-on-time success is 3/5. You identify how correctness was judged. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A five-row scorecard and a plain-language reliability rule. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Apply this toy-case rule manually: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three successful HTTP responses violate the user-task contract. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three successful HTTP responses violate the user-task contract. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: http success conceals failed tasks. Use the glossary below, then write your prediction for: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an outcome probe alongside availability metrics and define an owned mitigation. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI site reliability engineer role interview. Explain diagnose: http success conceals failed tasks using this case: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an outcome probe alongside availability metrics and define an owned mitigation. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: http success conceals failed tasks to a system or workflow you know. Explain diagnose: http success conceals failed tasks using this case: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an outcome probe alongside availability metrics and define an owned mitigation. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Verify good and deliberately incorrect outputs through the ordinary caller route. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: http success conceals failed tasks using this case: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an outcome probe alongside availability metrics and define an owned mitigation. State the evidence, one alternative and where the mental model stops.

Quiz: HTTP success conceals failed tasks: The service’s synthetic probe flags any response containing a wrong critical field, even with status 200.

Change the acceptance rule after seeing an inconvenient result.

Add an outcome probe alongside availability metrics and define an owned mitigation.

Omit failed cases and report only the successful demonstrations.

Reference: Add an outcome probe alongside availability metrics and define an owned mitigation. — Add an outcome probe alongside availability metrics and define an owned mitigation. Verify good and deliberately incorrect outputs through the ordinary caller route.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Prometheus: https://prometheus.io/docs/introduction/overview/

OpenTelemetry: https://opentelemetry.io/docs/

Google SRE books: https://sre.google/books/

OpenTelemetry: https://opentelemetry.io/docs/

Prometheus: https://prometheus.io/docs/introduction/overview/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Existing SRE skills transfer strongly. Add model-serving metrics, evaluation limitations, provider quotas and agent/retrieval failure modes. Senior work includes reliability policy and cross-team incident leadership.

Terms:

Failure isolation: Use request IDs to connect errors across retrieval, inference and tools. Separate dependency failure from overload, authorization and incorrect application behavior.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

Pod: A Kubernetes unit containing one or more containers scheduled together.

namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

SLO: Service-level objective: a target for a defined user-facing indicator over a stated measurement window.

### Failure isolation

Use request IDs to connect errors across retrieval, inference and tools. Separate dependency failure from overload, authorization and incorrect application behavior. In this role, work through: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Follow a parcel's tracking number through each sorting office.

Boundary: Correlation across metrics does not by itself establish causation.

Worked example: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Existing SRE skills transfer strongly. Add model-serving metrics, evaluation limitations, provider quotas and agent/retrieval failure modes. Senior work includes reliability policy and cross-team incident leadership.

Tools for this exercise: Document or text editor

Course tool and framework map: kind (Open source · local containers); Prometheus (Open source); OpenTelemetry (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI site reliability engineer: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database.

Predict the worked case

Read this case without running a tool: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in failure isolation.

Connect the concept to the role

Apply this rule: Use request IDs to connect errors across retrieval, inference and tools. Separate dependency failure from overload, authorization and incorrect application behavior. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Correlation across metrics does not by itself establish causation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies failure isolation to this case: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Failure isolation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure isolation. Use the glossary below, then write your prediction for: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI site reliability engineer role interview. Explain failure isolation using this case: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure isolation to a system or workflow you know. Explain failure isolation using this case: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain failure isolation using this case: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database.

Treat a passing starter as proof of the whole role workflow.

Use request IDs to connect errors across retrieval, inference and tools. Separate dependency failure from overload, authorization and incorrect application behavior.

Ignore the failure because the tool produced an output.

Reference: Use request IDs to connect errors across retrieval, inference and tools. Separate dependency failure from overload, authorization and incorrect application behavior. — Use request IDs to connect errors across retrieval, inference and tools. Separate dependency failure from overload, authorization and incorrect application behavior. Correlation across metrics does not by itself establish causation.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Prometheus: https://prometheus.io/docs/introduction/overview/

OpenTelemetry: https://opentelemetry.io/docs/

Google SRE books: https://sre.google/books/

OpenTelemetry: https://opentelemetry.io/docs/

Prometheus: https://prometheus.io/docs/introduction/overview/

### Integrate: AI endpoint reliability game day

Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model. In this role, work through: Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Role application: Follow a parcel's tracking number through each sorting office.

A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database.

Worked example: Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.

Setup: Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: kind (Open source · local containers); Prometheus (Open source); OpenTelemetry (Open source)

Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Define user-visible reliability for an AI endpoint and prove recovery from controlled failures.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Prepare the project inputs

Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Instrument requests, duration and errors in a copy of the service, then expose metrics. Build availability and latency panels with a clearly defined denominator.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Deliverable: lesson-intermediate-2.md: SLO document and dashboard exports; Fault timeline with command evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: ai endpoint reliability game day. Use the glossary below, then write your prediction for: Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI site reliability engineer role interview. Explain integrate: ai endpoint reliability game day using this case: Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: ai endpoint reliability game day to a system or workflow you know. Explain integrate: ai endpoint reliability game day using this case: Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. Identify one observation that would contradict your claim.

Interview: Explain integrate: ai endpoint reliability game day using this case: Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI endpoint reliability game day at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.

Reference: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. — Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Prometheus: https://prometheus.io/docs/introduction/overview/

OpenTelemetry: https://opentelemetry.io/docs/

Google SRE books: https://sre.google/books/

OpenTelemetry: https://opentelemetry.io/docs/

Prometheus: https://prometheus.io/docs/introduction/overview/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Error budgets and recovery: Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

baseline: A simple reference method used to judge whether a more complex approach helps.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

Pod: A Kubernetes unit containing one or more containers scheduled together.

namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

SLO: Service-level objective: a target for a defined user-facing indicator over a stated measurement window.

### Error budgets and recovery

Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate. In this role, work through: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A reserve fund absorbs surprises but must not be spent faster than it replenishes.

Boundary: An SLO is an agreed operating target, not a universal percentage.

Worked example: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: kind (Open source · local containers); Prometheus (Open source); OpenTelemetry (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI site reliability engineer: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes.

Predict the worked case

Read this case without running a tool: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in error budgets and recovery.

Connect the concept to the role

Apply this rule: Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: An SLO is an agreed operating target, not a universal percentage.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies error budgets and recovery to this case: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Error budgets and recovery; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with error budgets and recovery. Use the glossary below, then write your prediction for: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI site reliability engineer role interview. Explain error budgets and recovery using this case: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate error budgets and recovery to a system or workflow you know. Explain error budgets and recovery using this case: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain error budgets and recovery using this case: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate.

Reference: Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate. — Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate. An SLO is an agreed operating target, not a universal percentage.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Prometheus: https://prometheus.io/docs/introduction/overview/

OpenTelemetry: https://opentelemetry.io/docs/

Google SRE books: https://sre.google/books/

OpenTelemetry: https://opentelemetry.io/docs/

Prometheus: https://prometheus.io/docs/introduction/overview/

### Defend: AI endpoint reliability game day

Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. Write alert conditions, an incident timeline template and rollback commands. Run a baseline load and store the exact request mix and environment. In this role, work through: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Role application: A reserve fund absorbs surprises but must not be spent faster than it replenishes.

When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes.

Worked example: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.

Setup: Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: kind (Open source · local containers); Prometheus (Open source); OpenTelemetry (Open source)

Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

Define user-visible reliability for an AI endpoint and prove recovery from controlled failures.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

Prepare the project inputs

Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Instrument requests, duration and errors in a copy of the service, then expose metrics. Build availability and latency panels with a clearly defined denominator.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Write alert conditions, an incident timeline template and rollback commands. Run a baseline load and store the exact request mix and environment.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. A reviewer must reproduce one result and identify which capabilities you implemented. Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

Deliverable: lesson-advanced-2.md: SLO document and dashboard exports; Fault timeline with command evidence; On-call runbook and postmortem. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: ai endpoint reliability game day. Use the glossary below, then write your prediction for: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI site reliability engineer role interview. Explain defend: ai endpoint reliability game day using this case: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: ai endpoint reliability game day to a system or workflow you know. Explain defend: ai endpoint reliability game day using this case: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. Identify one observation that would contradict your claim.

Interview: Explain defend: ai endpoint reliability game day using this case: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI endpoint reliability game day at this level?

Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment. — Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment. Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.

Sources:

kind: https://kind.sigs.k8s.io/docs/user/quick-start/

Prometheus: https://prometheus.io/docs/introduction/overview/

OpenTelemetry: https://opentelemetry.io/docs/

Google SRE books: https://sre.google/books/

OpenTelemetry: https://opentelemetry.io/docs/

Prometheus: https://prometheus.io/docs/introduction/overview/
