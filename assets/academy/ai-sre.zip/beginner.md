## beginner — AI service indicators

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### AI service indicators
Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator.
Mental model: An open hospital door is not the same as receiving treatment.
Boundary: Semantic quality may need sampled review and uncertain labels.
Worked example: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: HTTP success conceals failed tasks
The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Three successful HTTP responses violate the user-task contract. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an outcome probe alongside availability metrics and define an owned mitigation.
Recall: Verify good and deliberately incorrect outputs through the ordinary caller route. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
AI service indicators: Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
SLO: Service-level objective: a target for a defined user-facing indicator over a stated measurement window.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Reliability describes whether users can complete their task. An HTTP success response alone does not show that an AI answer is useful.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Make five rows: three correct answers under 2 seconds; one incorrect answer in 1 second with HTTP 200 (a successful web response); one timeout. Assume all three correct answers also have HTTP 200.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row scorecard and a plain-language reliability rule.

3. Try step 2
Calculate HTTP success and correct-on-time task success separately.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row scorecard and a plain-language reliability rule.

4. Try step 3
Write a rule defining “correct on time” and name who would review answer correctness.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row scorecard and a plain-language reliability rule.

5. Explain and check your result
HTTP success is 4/5; correct-on-time success is 3/5. You identify how correctness was judged. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A five-row scorecard and a plain-language reliability rule. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Apply this toy-case rule manually: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three successful HTTP responses violate the user-task contract. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI site reliability engineer.
Make five rows: three correct answers under 2 seconds; one incorrect answer in 1 second with HTTP 200 (a successful web response); one timeout. Assume all three correct answers also have HTTP 200.
Calculate HTTP success and correct-on-time task success separately.
Write a rule defining “correct on time” and name who would review answer correctness.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A five-row scorecard and a plain-language reliability rule. Include beginner-worksheet.md and your completed Outcome SLO proposal and incident note.
Check: HTTP success is 4/5; correct-on-time success is 3/5. You identify how correctness was judged.

### Interview
Explain your beginner solution for AI site reliability engineer. Use this scenario: The service’s synthetic probe flags any response containing a wrong critical field, even with status 200.
Review: Start with the task and permitted scope. Explain ai service indicators: Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator. Show the input and observed output, then address Add an outcome probe alongside availability metrics and define an owned mitigation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A five-row scorecard and a plain-language reliability rule. Include beginner-worksheet.md and your completed Outcome SLO proposal and incident note.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

