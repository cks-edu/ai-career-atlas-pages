# SAMPLE — Outcome SLO proposal and incident note
Role: AI site reliability engineer
Case: HTTP success conceals failed tasks
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The service’s synthetic probe flags any response containing a wrong critical field, even with status 200.

## Evidence table
| Record | wrong_critical_fields (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 1 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three successful HTTP responses violate the user-task contract.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Add an outcome probe alongside availability metrics and define an owned mitigation.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai site reliability engineer.
Before release: Verify good and deliberately incorrect outputs through the ordinary caller route.

## Design choice and trade-off
Measure user-visible outcomes and dependency health separately; tie alerts to actionable ownership.
Deep probes cost more and sample only selected behaviors; pair them with broader sampled review.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Build availability and quality indicators: Retain three scenario reports and metric definitions. Separate availability, latency and quality evidence. Write a short runbook for the degraded scenario with an owner and rollback trigger.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
