# AI site reliability engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with AI service indicators. Reliability describes whether users can complete their task. An HTTP success response alone does not show that an AI answer is useful. Then try Define success for five fictional requests. The three levels build toward AI endpoint reliability game day. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — AI service indicators

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### AI service indicators
Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator.
Mental model: An open hospital door is not the same as receiving treatment.
Boundary: Semantic quality may need sampled review and uncertain labels.
Worked example: Count valid supported answers delivered before the deadline over all eligible requests; track transport success separately.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: HTTP success conceals failed tasks
The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Three successful HTTP responses violate the user-task contract. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Add an outcome probe alongside availability metrics and define an owned mitigation.
Recall: Verify good and deliberately incorrect outputs through the ordinary caller route. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
AI service indicators: Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
SLO: Service-level objective: a target for a defined user-facing indicator over a stated measurement window.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Reliability describes whether users can complete their task. An HTTP success response alone does not show that an AI answer is useful.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Make five rows: three correct answers under 2 seconds; one incorrect answer in 1 second with HTTP 200 (a successful web response); one timeout. Assume all three correct answers also have HTTP 200.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row scorecard and a plain-language reliability rule.

3. Try step 2
Calculate HTTP success and correct-on-time task success separately.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row scorecard and a plain-language reliability rule.

4. Try step 3
Write a rule defining “correct on time” and name who would review answer correctness.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A five-row scorecard and a plain-language reliability rule.

5. Explain and check your result
HTTP success is 4/5; correct-on-time success is 3/5. You identify how correctness was judged. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A five-row scorecard and a plain-language reliability rule. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Apply this toy-case rule manually: Review when wrong_critical_fields >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three successful HTTP responses violate the user-task contract. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI site reliability engineer.
Make five rows: three correct answers under 2 seconds; one incorrect answer in 1 second with HTTP 200 (a successful web response); one timeout. Assume all three correct answers also have HTTP 200.
Calculate HTTP success and correct-on-time task success separately.
Write a rule defining “correct on time” and name who would review answer correctness.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A five-row scorecard and a plain-language reliability rule. Include beginner-worksheet.md and your completed Outcome SLO proposal and incident note.
Check: HTTP success is 4/5; correct-on-time success is 3/5. You identify how correctness was judged.

### Interview
Explain your beginner solution for AI site reliability engineer. Use this scenario: The service’s synthetic probe flags any response containing a wrong critical field, even with status 200.
Review: Start with the task and permitted scope. Explain ai service indicators: Define reliability from the user's task, not just server uptime. State the denominator, measurement window and owner for each indicator. Show the input and observed output, then address Add an outcome probe alongside availability metrics and define an owned mitigation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A five-row scorecard and a plain-language reliability rule. Include beginner-worksheet.md and your completed Outcome SLO proposal and incident note.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Failure isolation

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Existing SRE skills transfer strongly. Add model-serving metrics, evaluation limitations, provider quotas and agent/retrieval failure modes. Senior work includes reliability policy and cross-team incident leadership.

### Failure isolation
Use request IDs to connect errors across retrieval, inference and tools. Separate dependency failure from overload, authorization and incorrect application behavior.
Mental model: Follow a parcel's tracking number through each sorting office.
Boundary: Correlation across metrics does not by itself establish causation.
Worked example: A healthy API has growing p95 latency. Compare queue depth and model execution time before scaling the retrieval database.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI endpoint reliability game day
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.
Recall: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. Identify one observation that would contradict your claim.

### Terms
Failure isolation: Use request IDs to connect errors across retrieval, inference and tools. Separate dependency failure from overload, authorization and incorrect application behavior.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
p95: The 95th percentile: about 95% of measured values are at or below it. Always state sample size and how failed requests are handled.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.
SLO: Service-level objective: a target for a defined user-facing indicator over a stated measurement window.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Instrument requests, duration and errors in a copy of the service, then expose metrics. Build availability and latency panels with a clearly defined denominator.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The service’s synthetic probe flags any response containing a wrong critical field, even with status 200. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures.
Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.
Instrument requests, duration and errors in a copy of the service, then expose metrics. Build availability and latency panels with a clearly defined denominator.
Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model.
Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.
Deliverables: SLO document and dashboard exports; Fault timeline with command evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI site reliability engineer. Use this scenario: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.
Review: Start with the task and permitted scope. Explain failure isolation: Use request IDs to connect errors across retrieval, inference and tools. Separate dependency failure from overload, authorization and incorrect application behavior. Show the input and observed output, then address Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [SLO document and dashboard exports; Fault timeline with command evidence. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Error budgets and recovery

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Error budgets and recovery
Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate.
Mental model: A reserve fund absorbs surprises but must not be spent faster than it replenishes.
Boundary: An SLO is an agreed operating target, not a universal percentage.
Worked example: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI endpoint reliability game day
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. Write alert conditions, an incident timeline template and rollback commands. Run a baseline load and store the exact request mix and environment.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.
Recall: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. Identify one observation that would contradict your claim.

### Terms
Error budgets and recovery: Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.
SLO: Service-level objective: a target for a defined user-facing indicator over a stated measurement window.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Instrument requests, duration and errors in a copy of the service, then expose metrics. Build availability and latency panels with a clearly defined denominator.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Write alert conditions, an incident timeline template and rollback commands. Run a baseline load and store the exact request mix and environment.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures.
Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.
Instrument requests, duration and errors in a copy of the service, then expose metrics. Build availability and latency panels with a clearly defined denominator.
Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model.
Write alert conditions, an incident timeline template and rollback commands. Run a baseline load and store the exact request mix and environment.
Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.
Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.
Add multi-window burn-rate alerts and a quality-regression drill independent of infrastructure health.
Deliverables: SLO document and dashboard exports; Fault timeline with command evidence; On-call runbook and postmortem. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. A reviewer must reproduce one result and identify which capabilities you implemented. Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.

### Interview
Explain your advanced solution for AI site reliability engineer. Use this scenario: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.
Review: Start with the task and permitted scope. Explain error budgets and recovery: Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate. Show the input and observed output, then address Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [SLO document and dashboard exports; Fault timeline with command evidence; On-call runbook and postmortem. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
kind — Open source · local containers
Disposable Kubernetes cluster; requires a compatible container runtime.
Alternative: minikube (open source); managed Kubernetes is a separate commercial hosting choice, not required for a first lab.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Prometheus — Open source
Metrics collection and alert evidence.
Alternative: VictoriaMetrics has open-source and commercial editions; a managed monitoring service has separate retention and cost terms.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

OpenTelemetry — Open source
Request traces and dependency-level diagnostics.
Alternative: Vendor-specific SDKs are alternatives, but assess portability and data export before adopting one.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
kind: https://kind.sigs.k8s.io/docs/user/quick-start/
Prometheus: https://prometheus.io/docs/introduction/overview/
OpenTelemetry: https://opentelemetry.io/docs/
Google SRE books: https://sre.google/books/
OpenTelemetry: https://opentelemetry.io/docs/
Prometheus: https://prometheus.io/docs/introduction/overview/
