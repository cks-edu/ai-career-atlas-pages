# SLO document and dashboard exports

Project: AI endpoint reliability game day
Status: blank work product — not completed evidence

## Purpose and audience
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures.

## Required content
Instrument requests, duration and errors in a copy of the service, then expose metrics. Build availability and latency panels with a clearly defined denominator.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.

## Failure evidence
Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
