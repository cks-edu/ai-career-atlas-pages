# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect SLO document and dashboard exports.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
