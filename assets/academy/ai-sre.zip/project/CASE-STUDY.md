# AI endpoint reliability game day

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.

## Limitations and next iteration
Add multi-window burn-rate alerts and a quality-regression drill independent of infrastructure health.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
