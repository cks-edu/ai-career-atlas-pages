## advanced — Error budgets and recovery

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Error budgets and recovery
Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate.
Mental model: A reserve fund absorbs surprises but must not be spent faster than it replenishes.
Boundary: An SLO is an agreed operating target, not a universal percentage.
Worked example: When bad responses consume the remaining budget rapidly, pause rollout, restore the known configuration and verify user outcomes.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI endpoint reliability game day
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. Write alert conditions, an incident timeline template and rollback commands. Run a baseline load and store the exact request mix and environment.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.
Worked example: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.
Recall: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. Identify one observation that would contradict your claim.

### Terms
Error budgets and recovery: Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
baseline: A simple reference method used to judge whether a more complex approach helps.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
Pod: A Kubernetes unit containing one or more containers scheduled together.
namespace: A Kubernetes scope for named resources. It does not alone provide all security isolation.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.
SLO: Service-level objective: a target for a defined user-facing indicator over a stated measurement window.

### Lab
Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures. A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox. Local container runtime and several GB of available memory required. Docker Desktop licensing depends on use. Cloud clusters and GPU plugins are separate extensions.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install kind, kubectl and a compatible Docker runtime using official guides. Use a disposable cluster named atlas-portfolio; do not reuse a production context. These POSIX-shell commands use a separate atlas-kubeconfig file. Reuse that file in every new terminal; do not switch your production context. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
export KUBECONFIG="$PWD/atlas-kubeconfig"
kind create cluster --name atlas-portfolio --kubeconfig "$KUBECONFIG"
kubectl --context kind-atlas-portfolio apply -f service.yaml
kubectl --context kind-atlas-portfolio -n atlas-portfolio rollout status deployment/review-service --timeout=120s
kubectl --context kind-atlas-portfolio -n atlas-portfolio get pods
kubectl --context kind-atlas-portfolio -n atlas-portfolio port-forward deployment/review-service 8011:8000 --address 127.0.0.1
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A namespaced, non-root HTTP deployment with readiness and resource limits. It serves an empty scratch directory; it is not an AI endpoint or a hostile-code sandbox.

2. Prepare the project inputs
Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Instrument requests, duration and errors in a copy of the service, then expose metrics. Build availability and latency panels with a clearly defined denominator.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Write alert conditions, an incident timeline template and rollback commands. Run a baseline load and store the exact request mix and environment.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
kubectl --context kind-atlas-portfolio -n atlas-portfolio describe deployment review-service
kubectl --context kind-atlas-portfolio -n atlas-portfolio get events --sort-by=.metadata.creationTimestamp
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
ImagePullBackOff: inspect kubectl describe pod and image availability.
Pending: inspect resource requests and node capacity.
NetworkPolicy appears ineffective: verify the CNI enforces it before making isolation claims.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop port-forward with Ctrl+C. Export evidence, then run kind delete cluster --name atlas-portfolio only for this disposable lab cluster.

### Portfolio
Define user-visible reliability for an AI endpoint and prove recovery from controlled failures.
Deploy the included local HTTP service in kind. Define an illustrative SLO for successful responses within a latency target; record that the starter is not a model server.
Instrument requests, duration and errors in a copy of the service, then expose metrics. Build availability and latency panels with a clearly defined denominator.
Add readiness checks and a bounded timeout to a client. Separate transport availability from answer quality using a small fixed evaluation set when you attach a real model.
Write alert conditions, an incident timeline template and rollback commands. Run a baseline load and store the exact request mix and environment.
Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.
Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO.
Add multi-window burn-rate alerts and a quality-regression drill independent of infrastructure health.
Deliverables: SLO document and dashboard exports; Fault timeline with command evidence; On-call runbook and postmortem. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. A reviewer must reproduce one result and identify which capabilities you implemented. Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.

### Interview
Explain your advanced solution for AI site reliability engineer. Use this scenario: Use only the lab namespace: roll out an invalid image, recover with rollout undo, then test a deliberately slow dependency. Verify alerts clear after recovery, not merely after acknowledgment.
Review: Start with the task and permitted scope. Explain error budgets and recovery: Set a service objective and an allowed failure budget over a defined window. Use burn and impact to decide whether to pause changes, mitigate or investigate. Show the input and observed output, then address Report detection time, recovery time, failed requests and residual quality failures. Evaluate alert usefulness and false positives against the defined SLO. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [SLO document and dashboard exports; Fault timeline with command evidence; On-call runbook and postmortem. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

