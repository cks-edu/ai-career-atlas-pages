# GenAI Observability, OpenTelemetry & GPU FinOps — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## advanced

Prerequisite: Complete the relevant core module first, or reproduce its checks. Read JavaScript functions and object state before editing the sandbox. Real-tool extensions require their documented environment.

Terms:

Semantic convention: A versioned shared meaning for telemetry names and values.

PII: Information that can identify a person; assess context and applicable policy.

TTFT: Time to first token, with a documented timing start.

TPOT: Request average time per output token after the first token.

DCGM: NVIDIA GPU management and telemetry tooling.

SM utilization: A compute activity signal; it is distinct from allocated memory.

Chargeback: Attributing a defined cost pool to accountable consumers.

Spot interruption: A provider may reclaim discounted capacity; recovery must be designed.

### GenAI OpenTelemetry without private payloads

A trace should explain timing and decisions without copying private prompts, responses or credentials. OpenTelemetry gen_ai conventions have attribute-specific maturity and versioning; pin the conventions used by your instrumentation.

Copy only an explicit allowlist of operation, model and nonnegative token counts into a new object. Do not stringify the entire input. The example uses selected gen_ai attributes; validate your installed SDK and semantic-convention version.

An allowlist reduces accidental collection but is not a full privacy review. Tenant identifiers, baggage, exporter configuration, retention and access controls also need review.

Mental model: AI request → selected attributes → trace exporter → restricted telemetry store. Picture the boundary as a checked gate between stages.

Boundary: An allowlist reduces accidental collection but is not a full privacy review. Tenant identifiers, baggage, exporter configuration, retention and access controls also need review.

Worked example: function safeGenAiAttributes(p) {
  const out={}; if(!p || typeof p!=='object') return out;
  for(const k of ['gen_ai.operation.name','gen_ai.request.model']) if(typeof p[k]==='string' && p[k].length<=100) out[k]=p[k];
  for(const k of ['gen_ai.usage.input_tokens','gen_ai.usage.output_tokens']) if(Number.isSafeInteger(p[k]) && p[k]>=0) out[k]=p[k];
  return out;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract genai-observability-finops.zip, install Node.js LTS, then open production-ai/14-01-private-genai-traces.

Tools for this exercise: JavaScript · local isolated workbench; OpenTelemetry / Prometheus / DCGM Exporter, Karpenter / cloud GPU capacity as documented optional extensions

Course tool and framework map: OpenTelemetry / Prometheus / DCGM Exporter (Open-source projects · telemetry storage has costs); Karpenter / cloud GPU capacity (Open source controller · commercial cloud instances)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires your learning inference server. Inspect only authorized redacted telemetry. Compare documented units and versions before constructing a KEDA Prometheus query. DCGM requires compatible NVIDIA hardware and an independently configured exporter.

Implement safeGenAiAttributes. Add a private response and secret baggage key to your fixture and demonstrate that neither reaches the returned object.

Terminal folder: production-ai/14-01-private-genai-traces

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Copy only an explicit allowlist of operation, model and nonnegative token counts into a new object. Do not stringify the entire input. The example uses selected gen_ai attributes; validate your installed SDK and semantic-convention version.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement safeGenAiAttributes. Add a private response and secret baggage key to your fixture and demonstrate that neither reaches the returned object.

Expected: Keep approved attributes

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Drop content and credentials; Reject invalid counts

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Read bounded inference signals

Requires your learning inference server. Inspect only authorized redacted telemetry. Compare documented units and versions before constructing a KEDA Prometheus query. DCGM requires compatible NVIDIA hardware and an independently configured exporter.

```
curl --fail --max-time 10 http://127.0.0.1:8000/metrics > metrics-local.txt
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record available queue, TTFT and KV metrics with units and sample time. Explain missing signals instead of substituting guessed values.

Expected: Keep approved attributes; Drop content and credentials; Reject invalid counts. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Use an allowlist and test exporter redaction end to end. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/14-01-private-genai-traces/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: AI request → selected attributes → trace exporter → restricted telemetry store. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Which trace fields should be enabled by default in this fixture? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Observability is not permission to record raw user data. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Which trace fields should be enabled by default in this fixture?

Interview: Which trace fields should be enabled by default in this fixture? Explain the decision, a failing case and a production limitation.

Quiz: Which trace fields should be enabled by default in this fixture?

The entire request object.

Only the explicitly approved attributes.

Raw authorization headers.

Reference: Only the explicitly approved attributes. — Only the explicitly approved attributes. An allowlist reduces accidental collection but is not a full privacy review. Tenant identifiers, baggage, exporter configuration, retention and access controls also need review.

Sources:

OpenTelemetry: GenAI semantic conventions: https://opentelemetry.io/docs/specs/semconv/gen-ai/

### TTFT, ITL, TPOT & cache pressure

TTFT measures time to the first output token. ITL measures gaps between streamed outputs; an output event can contain multiple tokens. Request-level TPOT averages generation time after the first token over remaining tokens. These measurements are related but not interchangeable.

Calculate TPOT from end-to-end seconds minus TTFT, divided by outputTokens minus one. Report null when there are fewer than two output tokens or timing is invalid. Keep the KV-cache fraction separate from latency.

This teaching formula requires consistent start/end definitions and token counts. Aggregate quantiles cannot be combined by subtracting separate P95 values. Read the engine version’s metric definition.

Mental model: Request arrival → first token → subsequent outputs → completion. Picture the boundary as a checked gate between stages.

Boundary: This teaching formula requires consistent start/end definitions and token counts. Aggregate quantiles cannot be combined by subtracting separate P95 values. Read the engine version’s metric definition.

Worked example: function requestTpot(p) {
  if(!p || !Number.isSafeInteger(p.outputTokens) || p.outputTokens<2 || !Number.isFinite(p.ttftSeconds) || !Number.isFinite(p.totalSeconds) || p.ttftSeconds<0 || p.totalSeconds<p.ttftSeconds) return null;
  return (p.totalSeconds-p.ttftSeconds)/(p.outputTokens-1);
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract genai-observability-finops.zip, install Node.js LTS, then open production-ai/14-02-latency-definitions.

Tools for this exercise: JavaScript · local isolated workbench; OpenTelemetry / Prometheus / DCGM Exporter, Karpenter / cloud GPU capacity as documented optional extensions

Course tool and framework map: OpenTelemetry / Prometheus / DCGM Exporter (Open-source projects · telemetry storage has costs); Karpenter / cloud GPU capacity (Open source controller · commercial cloud instances)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires your learning inference server. Inspect only authorized redacted telemetry. Compare documented units and versions before constructing a KEDA Prometheus query. DCGM requires compatible NVIDIA hardware and an independently configured exporter.

Implement requestTpot and annotate a synthetic five-token timeline. Explain why chunk gaps and request TPOT can differ.

Terminal folder: production-ai/14-02-latency-definitions

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

Calculate TPOT from end-to-end seconds minus TTFT, divided by outputTokens minus one. Report null when there are fewer than two output tokens or timing is invalid. Keep the KV-cache fraction separate from latency.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement requestTpot and annotate a synthetic five-token timeline. Explain why chunk gaps and request TPOT can differ.

Expected: Calculate request average

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Avoid undefined one-token average; Validate measurement inputs

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Read bounded inference signals

Requires your learning inference server. Inspect only authorized redacted telemetry. Compare documented units and versions before constructing a KEDA Prometheus query. DCGM requires compatible NVIDIA hardware and an independently configured exporter.

```
curl --fail --max-time 10 http://127.0.0.1:8000/metrics > metrics-local.txt
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record available queue, TTFT and KV metrics with units and sample time. Explain missing signals instead of substituting guessed values.

Expected: Calculate request average; Avoid undefined one-token average; Validate measurement inputs. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Name measurement boundaries and compute per-request values before aggregation. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/14-02-latency-definitions/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Request arrival → first token → subsequent outputs → completion. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Can you calculate P95 TPOT by subtracting P95 TTFT from P95 total latency? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: A stream event is not necessarily one token. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Can you calculate P95 TPOT by subtracting P95 TTFT from P95 total latency?

Interview: Can you calculate P95 TPOT by subtracting P95 TTFT from P95 total latency? Explain the decision, a failing case and a production limitation.

Quiz: Can you calculate P95 TPOT by subtracting P95 TTFT from P95 total latency?

Yes, quantiles always subtract correctly.

Only when the dashboard is blue.

No; calculate matched per-request values before aggregating.

Reference: No; calculate matched per-request values before aggregating. — No; calculate matched per-request values before aggregating. This teaching formula requires consistent start/end definitions and token counts. Aggregate quantiles cannot be combined by subtracting separate P95 values. Read the engine version’s metric definition.

Sources:

vLLM: production metrics and units: https://docs.vllm.ai/en/latest/usage/metrics/

OpenTelemetry: GenAI semantic conventions: https://opentelemetry.io/docs/specs/semconv/gen-ai/

### DCGM telemetry & suspected zombie GPU allocations

High VRAM occupancy with little compute can be intentional: cached models, warm pools and I/O waits are examples. Treat persistent low-compute occupancy as a signal to investigate with workload ownership and serving evidence, not as permission to terminate a process.

The fictional rule flags VRAM fraction above 0.8 and SM compute fraction below 0.05 sustained for more than 900 seconds. Independently trip the tenant budget breaker when used tokens reach the declared limit. Return separate flags; never infer budget exhaustion from GPU occupancy.

DCGM field units and aggregation depend on the exporter configuration. A circuit-breaker recommendation requires a separate authorized admission control; the fixture neither kills jobs nor changes budgets.

Mental model: DCGM plus tenant accounting → validated window → investigation and admission flags. Picture the boundary as a checked gate between stages.

Boundary: DCGM field units and aggregation depend on the exporter configuration. A circuit-breaker recommendation requires a separate authorized admission control; the fixture neither kills jobs nor changes budgets.

Worked example: function detectGpuAnomalies(p) {
  if(!p || ![p.vramFraction,p.smFraction].every(n=>Number.isFinite(n)&&n>=0&&n<=1) || !Number.isFinite(p.sustainedSeconds) || p.sustainedSeconds<0 || ![p.tokensUsed,p.tokenLimit].every(n=>Number.isSafeInteger(n)&&n>=0)) return null;
  return {investigate:p.vramFraction>0.8 && p.smFraction<0.05 && p.sustainedSeconds>900,blockNewRequests:p.tokensUsed>=p.tokenLimit};
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract genai-observability-finops.zip, install Node.js LTS, then open production-ai/14-03-gpu-anomalies.

Tools for this exercise: JavaScript · local isolated workbench; OpenTelemetry / Prometheus / DCGM Exporter, Karpenter / cloud GPU capacity as documented optional extensions

Course tool and framework map: OpenTelemetry / Prometheus / DCGM Exporter (Open-source projects · telemetry storage has costs); Karpenter / cloud GPU capacity (Open source controller · commercial cloud instances)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires your learning inference server. Inspect only authorized redacted telemetry. Compare documented units and versions before constructing a KEDA Prometheus query. DCGM requires compatible NVIDIA hardware and an independently configured exporter.

Implement detectGpuAnomalies and test exactly 15 minutes versus more than 15 minutes. Write an investigation checklist for an intentionally warm model.

Terminal folder: production-ai/14-03-gpu-anomalies

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The fictional rule flags VRAM fraction above 0.8 and SM compute fraction below 0.05 sustained for more than 900 seconds. Independently trip the tenant budget breaker when used tokens reach the declared limit. Return separate flags; never infer budget exhaustion from GPU occupancy.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement detectGpuAnomalies and test exactly 15 minutes versus more than 15 minutes. Write an investigation checklist for an intentionally warm model.

Expected: Detect sustained suspicion

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Keep strict boundary and independent breaker; Reject bad units

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Read bounded inference signals

Requires your learning inference server. Inspect only authorized redacted telemetry. Compare documented units and versions before constructing a KEDA Prometheus query. DCGM requires compatible NVIDIA hardware and an independently configured exporter.

```
curl --fail --max-time 10 http://127.0.0.1:8000/metrics > metrics-local.txt
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record available queue, TTFT and KV metrics with units and sample time. Explain missing signals instead of substituting guessed values.

Expected: Detect sustained suspicion; Keep strict boundary and independent breaker; Reject bad units. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Require sustained evidence; investigate the owner and enforce budget separately. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/14-03-gpu-anomalies/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: DCGM plus tenant accounting → validated window → investigation and admission flags. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. Does high VRAM plus low SM compute prove a job is safe to kill? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: Hardware utilization cannot identify business ownership or safe eviction alone. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: Does high VRAM plus low SM compute prove a job is safe to kill?

Interview: Does high VRAM plus low SM compute prove a job is safe to kill? Explain the decision, a failing case and a production limitation.

Quiz: Does high VRAM plus low SM compute prove a job is safe to kill?

Yes, immediately terminate it.

No; investigate sustained evidence and workload ownership.

Yes, token billing proves the process is abandoned.

Reference: No; investigate sustained evidence and workload ownership. — No; investigate sustained evidence and workload ownership. DCGM field units and aggregation depend on the exporter configuration. A circuit-breaker recommendation requires a separate authorized admission control; the fixture neither kills jobs nor changes budgets.

Sources:

NVIDIA: DCGM Exporter: https://docs.nvidia.com/datacenter/cloud-native/gpu-telemetry/latest/dcgm-exporter.html

vLLM: production metrics and units: https://docs.vllm.ai/en/latest/usage/metrics/

### Spot GPU interruptions & token chargeback

Spot capacity may disappear and replacement GPU capacity may not be available. Karpenter manages provisioning and interruption-related behavior on supported platforms; it cannot guarantee capacity or preserve every active stream.

The local chargeback function totals only events for the authenticated tenant and requires nonnegative integer token usage and a finite nonnegative rate per thousand tokens. Use fictional units and do not report this estimate as a cloud bill.

Real chargeback also includes reserved idle GPUs, storage, network and service overhead. Define the accounting window, idempotent usage identity and interruption/retry policy before relying on these numbers.

Mental model: Scoped token events → tenant ledger → estimated charge → capacity review. Picture the boundary as a checked gate between stages.

Boundary: Real chargeback also includes reserved idle GPUs, storage, network and service overhead. Define the accounting window, idempotent usage identity and interruption/retry policy before relying on these numbers.

Worked example: function estimateTenantCharge(events,tenant,rate) {
  if(!Array.isArray(events) || typeof tenant!=='string' || !tenant || !Number.isFinite(rate) || rate<0 || events.some(e=>!e || typeof e.tenant!=='string' || !Number.isSafeInteger(e.tokens) || e.tokens<0)) return null;
  return events.filter(e=>e.tenant===tenant).reduce((n,e)=>n+e.tokens,0)*rate/1000;
}

Setup: No setup for the in-browser workbench. Optional downloaded route: extract genai-observability-finops.zip, install Node.js LTS, then open production-ai/14-04-spot-token-finops.

Tools for this exercise: JavaScript · local isolated workbench; OpenTelemetry / Prometheus / DCGM Exporter, Karpenter / cloud GPU capacity as documented optional extensions

Course tool and framework map: OpenTelemetry / Prometheus / DCGM Exporter (Open-source projects · telemetry storage has costs); Karpenter / cloud GPU capacity (Open source controller · commercial cloud instances)

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser. Optional native extension: Requires your learning inference server. Inspect only authorized redacted telemetry. Compare documented units and versions before constructing a KEDA Prometheus query. DCGM requires compatible NVIDIA hardware and an independently configured exporter.

Implement estimateTenantCharge. Add a ledger-window and duplicate-event design, plus a Spot interruption runbook that honestly identifies lost-stream and unavailable-capacity risks.

Terminal folder: production-ai/14-04-spot-token-finops

```
node reference.mjs
# starter.mjs intentionally fails until you implement the contract
node starter.mjs
```

Predict the boundary

The local chargeback function totals only events for the authenticated tenant and requires nonnegative integer token usage and a finite nonnegative rate per thousand tokens. Use fictional units and do not report this estimate as a cloud bill.

Expected: A prediction for the normal case and the stated failure.

Implement the contract

Implement estimateTenantCharge. Add a ledger-window and duplicate-event design, plus a Spot interruption runbook that honestly identifies lost-stream and unavailable-capacity risks.

Expected: Scope tenant usage

Run the edge cases

Select Run & check my work. Inspect Results & console; repair the first failing assertion without deleting its check.

Expected: Support zero usage; Reject invalid billing inputs

Make it yours

Add one new failing input to a copy of the downloaded fixture. Repair it and write the observed result, remaining limit and a source link.

Expected: Changed code, test output and an ADR or short evidence note.

Optional native extension · Read bounded inference signals

Requires your learning inference server. Inspect only authorized redacted telemetry. Compare documented units and versions before constructing a KEDA Prometheus query. DCGM requires compatible NVIDIA hardware and an independently configured exporter.

```
curl --fail --max-time 10 http://127.0.0.1:8000/metrics > metrics-local.txt
```

Read-only inspection/verification in a separately authorized environment. Commands contain required placeholders and do not provision resources.

Expected: Record available queue, TTFT and KV metrics with units and sample time. Explain missing signals instead of substituting guessed values.

Expected: Scope tenant usage; Support zero usage; Reject invalid billing inputs. This validates a local deterministic contract, not a model, cloud deployment or universal safety claim.

Troubleshoot: A local checkpoint fails: Trace the failing input through the worked function. Filter by authenticated owner and validate units before aggregation. If syntax fails, compare braces and parameter names. Keep tests intact and change one cause at a time.

Cleanup: The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.

Deliverable: production-ai/14-04-spot-token-finops/your-work.mjs, actual test output and ADR.md with one failing input, repair and limitation.

new: Start by drawing this: Scoped token events → tenant ledger → estimated charge → capacity review. Read the glossary, then follow the reference one branch at a time. The last hint shows the reference if you get stuck.

seeker: Use this as a learning-project interview example. What is missing from a token-only estimate of GPU service cost? Show your changed code and failing case; describe the synthetic test scope honestly.

switcher: Compare this with a system you know: One tenant must not be billed for another tenant’s usage. Focus on the new failure mode and the resource/security trade-off, then validate it with additional cases.

Recall: What is missing from a token-only estimate of GPU service cost?

Interview: What is missing from a token-only estimate of GPU service cost? Explain the decision, a failing case and a production limitation.

Quiz: What is missing from a token-only estimate of GPU service cost?

Nothing; it is the complete cloud invoice.

Only the color of the GPU.

Idle capacity, infrastructure overhead and a reconciled accounting scope.

Reference: Idle capacity, infrastructure overhead and a reconciled accounting scope. — Idle capacity, infrastructure overhead and a reconciled accounting scope. Real chargeback also includes reserved idle GPUs, storage, network and service overhead. Define the accounting window, idempotent usage identity and interruption/retry policy before relying on these numbers.

Sources:

Karpenter: disruption and interruption handling: https://karpenter.sh/docs/concepts/disruption/

NVIDIA: DCGM Exporter: https://docs.nvidia.com/datacenter/cloud-native/gpu-telemetry/latest/dcgm-exporter.html
