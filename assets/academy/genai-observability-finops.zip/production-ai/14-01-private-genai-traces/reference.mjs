function safeGenAiAttributes(p) {
  const out={}; if(!p || typeof p!=='object') return out;
  for(const k of ['gen_ai.operation.name','gen_ai.request.model']) if(typeof p[k]==='string' && p[k].length<=100) out[k]=p[k];
  for(const k of ['gen_ai.usage.input_tokens','gen_ai.usage.output_tokens']) if(Number.isSafeInteger(p[k]) && p[k]>=0) out[k]=p[k];
  return out;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const r=safeGenAiAttributes({'gen_ai.operation.name':'chat','gen_ai.usage.input_tokens':12});assert(r['gen_ai.usage.input_tokens']===12);
console.log("PASS: Keep approved attributes");
}
{
const r=safeGenAiAttributes({prompt:'private',authorization:'secret','gen_ai.request.model':'m'});assert(!('prompt' in r));assert(!('authorization' in r));assert(r['gen_ai.request.model']==='m');
console.log("PASS: Drop content and credentials");
}
{
assert(Object.keys(safeGenAiAttributes(null)).length===0);assert(!('gen_ai.usage.output_tokens' in safeGenAiAttributes({'gen_ai.usage.output_tokens':-1}))); 
console.log("PASS: Reject invalid counts");
}
