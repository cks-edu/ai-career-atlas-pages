# GenAI OpenTelemetry without private payloads

A trace should explain timing and decisions without copying private prompts, responses or credentials. OpenTelemetry gen_ai conventions have attribute-specific maturity and versioning; pin the conventions used by your instrumentation.

Copy only an explicit allowlist of operation, model and nonnegative token counts into a new object. Do not stringify the entire input. The example uses selected gen_ai attributes; validate your installed SDK and semantic-convention version.

Task: Implement safeGenAiAttributes. Add a private response and secret baggage key to your fixture and demonstrate that neither reaches the returned object.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: AI request → selected attributes → trace exporter → restricted telemetry store.
State: Operation, model and bounded token counts; private content remains outside.
Boundary: Observability is not permission to record raw user data.
Failure: A debug trace exports prompts and authorization headers.
Control: Use an allowlist and test exporter redaction end to end.
Observability: Inspect an exported sample and denied attribute tests.
Blast radius: Anyone with access to the telemetry backend and its retention copies.
Trade-off: Less payload detail reduces debugging context while protecting users.

Limit: An allowlist reduces accidental collection but is not a full privacy review. Tenant identifiers, baggage, exporter configuration, retention and access controls also need review.

Sources:
https://opentelemetry.io/docs/specs/semconv/gen-ai/
