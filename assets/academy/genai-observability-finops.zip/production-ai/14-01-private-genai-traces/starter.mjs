function safeGenAiAttributes(...args) {
  return null; // Implement the declared policy. Keep the supplied checks.
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const r=safeGenAiAttributes({'gen_ai.operation.name':'chat','gen_ai.usage.input_tokens':12});assert(r['gen_ai.usage.input_tokens']===12);
console.log("PASS: Keep approved attributes");
}
{
const r=safeGenAiAttributes({prompt:'private',authorization:'secret','gen_ai.request.model':'m'});assert(!('prompt' in r));assert(!('authorization' in r));assert(r['gen_ai.request.model']==='m');
console.log("PASS: Drop content and credentials");
}
{
assert(Object.keys(safeGenAiAttributes(null)).length===0);assert(!('gen_ai.usage.output_tokens' in safeGenAiAttributes({'gen_ai.usage.output_tokens':-1}))); 
console.log("PASS: Reject invalid counts");
}
