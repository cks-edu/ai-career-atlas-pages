function detectGpuAnomalies(p) {
  if(!p || ![p.vramFraction,p.smFraction].every(n=>Number.isFinite(n)&&n>=0&&n<=1) || !Number.isFinite(p.sustainedSeconds) || p.sustainedSeconds<0 || ![p.tokensUsed,p.tokenLimit].every(n=>Number.isSafeInteger(n)&&n>=0)) return null;
  return {investigate:p.vramFraction>0.8 && p.smFraction<0.05 && p.sustainedSeconds>900,blockNewRequests:p.tokensUsed>=p.tokenLimit};
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
const r=detectGpuAnomalies({vramFraction:0.9,smFraction:0.01,sustainedSeconds:901,tokensUsed:2,tokenLimit:10});assert(r.investigate && !r.blockNewRequests);
console.log("PASS: Detect sustained suspicion");
}
{
const r=detectGpuAnomalies({vramFraction:0.9,smFraction:0.01,sustainedSeconds:900,tokensUsed:10,tokenLimit:10});assert(!r.investigate && r.blockNewRequests);
console.log("PASS: Keep strict boundary and independent breaker");
}
{
assert(detectGpuAnomalies({vramFraction:90,smFraction:1,sustainedSeconds:901,tokensUsed:2,tokenLimit:10})===null);assert(detectGpuAnomalies(null)===null);
console.log("PASS: Reject bad units");
}
