# DCGM telemetry & suspected zombie GPU allocations

High VRAM occupancy with little compute can be intentional: cached models, warm pools and I/O waits are examples. Treat persistent low-compute occupancy as a signal to investigate with workload ownership and serving evidence, not as permission to terminate a process.

The fictional rule flags VRAM fraction above 0.8 and SM compute fraction below 0.05 sustained for more than 900 seconds. Independently trip the tenant budget breaker when used tokens reach the declared limit. Return separate flags; never infer budget exhaustion from GPU occupancy.

Task: Implement detectGpuAnomalies and test exactly 15 minutes versus more than 15 minutes. Write an investigation checklist for an intentionally warm model.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: DCGM plus tenant accounting → validated window → investigation and admission flags.
State: VRAM fraction, SM fraction, sustained duration and tenant token allowance.
Boundary: Hardware utilization cannot identify business ownership or safe eviction alone.
Failure: A warm model is killed after one idle sample, causing another cold start.
Control: Require sustained evidence; investigate the owner and enforce budget separately.
Observability: Correlate allocation, queue age, request activity and token ledger.
Blast radius: Tenants using the device and requests blocked by the budget gate.
Trade-off: Warm capacity costs money but may be necessary for latency.

Limit: DCGM field units and aggregation depend on the exporter configuration. A circuit-breaker recommendation requires a separate authorized admission control; the fixture neither kills jobs nor changes budgets.

Sources:
https://docs.nvidia.com/datacenter/cloud-native/gpu-telemetry/latest/dcgm-exporter.html
https://docs.vllm.ai/en/latest/usage/metrics/
