function requestTpot(p) {
  if(!p || !Number.isSafeInteger(p.outputTokens) || p.outputTokens<2 || !Number.isFinite(p.ttftSeconds) || !Number.isFinite(p.totalSeconds) || p.ttftSeconds<0 || p.totalSeconds<p.ttftSeconds) return null;
  return (p.totalSeconds-p.ttftSeconds)/(p.outputTokens-1);
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(requestTpot({outputTokens:5,ttftSeconds:2,totalSeconds:6})===1);
console.log("PASS: Calculate request average");
}
{
assert(requestTpot({outputTokens:1,ttftSeconds:2,totalSeconds:2})===null);assert(requestTpot({outputTokens:5,ttftSeconds:6,totalSeconds:2})===null);
console.log("PASS: Avoid undefined one-token average");
}
{
assert(requestTpot(null)===null);assert(requestTpot({outputTokens:5,ttftSeconds:NaN,totalSeconds:6})===null);
console.log("PASS: Validate measurement inputs");
}
