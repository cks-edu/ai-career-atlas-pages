# TTFT, ITL, TPOT & cache pressure

TTFT measures time to the first output token. ITL measures gaps between streamed outputs; an output event can contain multiple tokens. Request-level TPOT averages generation time after the first token over remaining tokens. These measurements are related but not interchangeable.

Calculate TPOT from end-to-end seconds minus TTFT, divided by outputTokens minus one. Report null when there are fewer than two output tokens or timing is invalid. Keep the KV-cache fraction separate from latency.

Task: Implement requestTpot and annotate a synthetic five-token timeline. Explain why chunk gaps and request TPOT can differ.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Request arrival → first token → subsequent outputs → completion.
State: Seconds and token count for one declared request.
Boundary: A stream event is not necessarily one token.
Failure: A dashboard labels request TPOT as every user-visible inter-event gap.
Control: Name measurement boundaries and compute per-request values before aggregation.
Observability: Inspect raw synthetic timestamps and documented histogram names.
Blast radius: Capacity or release decisions based on a mislabeled dashboard.
Trade-off: Detailed timing improves diagnosis but increases instrumentation complexity.

Limit: This teaching formula requires consistent start/end definitions and token counts. Aggregate quantiles cannot be combined by subtracting separate P95 values. Read the engine version’s metric definition.

Sources:
https://docs.vllm.ai/en/latest/usage/metrics/
https://opentelemetry.io/docs/specs/semconv/gen-ai/
