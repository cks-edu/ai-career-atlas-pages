# Spot GPU interruptions & token chargeback

Spot capacity may disappear and replacement GPU capacity may not be available. Karpenter manages provisioning and interruption-related behavior on supported platforms; it cannot guarantee capacity or preserve every active stream.

The local chargeback function totals only events for the authenticated tenant and requires nonnegative integer token usage and a finite nonnegative rate per thousand tokens. Use fictional units and do not report this estimate as a cloud bill.

Task: Implement estimateTenantCharge. Add a ledger-window and duplicate-event design, plus a Spot interruption runbook that honestly identifies lost-stream and unavailable-capacity risks.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Scoped token events → tenant ledger → estimated charge → capacity review.
State: Tenant identity, counted tokens and declared rate per thousand.
Boundary: One tenant must not be billed for another tenant’s usage.
Failure: A shared ledger sums every tenant and misattributes cost.
Control: Filter by authenticated owner and validate units before aggregation.
Observability: Reconcile event identities, totals, invoices and interruption outcomes.
Blast radius: Tenant budgets and capacity decisions made from incorrect totals.
Trade-off: Spot savings introduce interruption and availability risk.

Limit: Real chargeback also includes reserved idle GPUs, storage, network and service overhead. Define the accounting window, idempotent usage identity and interruption/retry policy before relying on these numbers.

Sources:
https://karpenter.sh/docs/concepts/disruption/
https://docs.nvidia.com/datacenter/cloud-native/gpu-telemetry/latest/dcgm-exporter.html
