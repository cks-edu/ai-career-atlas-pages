function estimateTenantCharge(events,tenant,rate) {
  if(!Array.isArray(events) || typeof tenant!=='string' || !tenant || !Number.isFinite(rate) || rate<0 || events.some(e=>!e || typeof e.tenant!=='string' || !Number.isSafeInteger(e.tokens) || e.tokens<0)) return null;
  return events.filter(e=>e.tenant===tenant).reduce((n,e)=>n+e.tokens,0)*rate/1000;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(estimateTenantCharge([{tenant:'a',tokens:1000},{tenant:'b',tokens:9000}],'a',2)===2);
console.log("PASS: Scope tenant usage");
}
{
assert(estimateTenantCharge([],'a',2)===0);assert(estimateTenantCharge([{tenant:'a',tokens:0}],'a',2)===0);
console.log("PASS: Support zero usage");
}
{
assert(estimateTenantCharge([{tenant:'a',tokens:-1}],'a',2)===null);assert(estimateTenantCharge([],'a',NaN)===null);
console.log("PASS: Reject invalid billing inputs");
}
