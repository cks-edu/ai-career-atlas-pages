# Read bounded inference signals

Requires your learning inference server. Inspect only authorized redacted telemetry. Compare documented units and versions before constructing a KEDA Prometheus query. DCGM requires compatible NVIDIA hardware and an independently configured exporter.

```sh
curl --fail --max-time 10 http://127.0.0.1:8000/metrics > metrics-local.txt
```

Expected evidence: Record available queue, TTFT and KV metrics with units and sample time. Explain missing signals instead of substituting guessed values.

Cleanup: these inspection commands create no resources. Stop only separately started learning servers and remove only your own temporary resources after retaining evidence. No cloud resources are provisioned by this pack.
