# API / Enterprise Integration Engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Boundaries and ownership: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.

Apply boundaries and ownership in API / Enterprise Integration Engineer: Use the concept to complete this role exercise: Document a request schema and error contract between two systems

Contracts and schema mapping: An integration contract defines identity, field semantics, version and error behavior between independently changing systems. Map meaning, not merely matching field names.

### Boundaries and ownership

A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. In this role, work through: customer_id maps to accountReference, while empty email has a defined missing-value policy. The practical workshop develops this into: Create source and target JSON fixtures and a field mapping table. Write a small transformer with required-field checks and an explicit rejected-record output.

Mental model: Departments own different ledgers and exchange agreed forms.

Boundary: Drawing more boxes does not make a system more reliable.

Role application: A translator must preserve meaning even when the words differ.

An integration contract defines identity, field semantics, version and error behavior between independently changing systems. Map meaning, not merely matching field names.

Worked example: customer_id maps to accountReference, while empty email has a defined missing-value policy.

Shared foundation example: The order service owns orders; a notification consumer handles messages.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: HTTP APIs, queues and schema contracts (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for API / Enterprise Integration Engineer: customer_id maps to accountReference, while empty email has a defined missing-value policy.

Predict the worked case

Read this case without running a tool: customer_id maps to accountReference, while empty email has a defined missing-value policy. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in boundaries and ownership.

Connect the concept to the role

Apply this rule: A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Drawing more boxes does not make a system more reliable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies boundaries and ownership to this case: customer_id maps to accountReference, while empty email has a defined missing-value policy. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: customer_id maps to accountReference, while empty email has a defined missing-value policy. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Boundaries and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with boundaries and ownership. Use the glossary below, then write your prediction for: customer_id maps to accountReference, while empty email has a defined missing-value policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the API / Enterprise Integration Engineer role interview. Explain boundaries and ownership using this case: customer_id maps to accountReference, while empty email has a defined missing-value policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate boundaries and ownership to a system or workflow you know. Explain boundaries and ownership using this case: customer_id maps to accountReference, while empty email has a defined missing-value policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Which component owns the truth about whether an order exists?

Interview: Explain boundaries and ownership using this case: customer_id maps to accountReference, while empty email has a defined missing-value policy. State the evidence, one alternative and where the mental model stops.

Quiz: After the Contracts and schema mapping rehearsal, check this foundation: Two services both write one business record using incompatible rules. What should be clarified first?

The owning service and the contract through which others request changes.

Which service can issue writes faster.

Whether both services can share unrestricted credentials.

Reference: The owning service and the contract through which others request changes. — Ownership defines responsibility for invariants. Sharing write access does not resolve conflicting business rules.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Contracts and schema mapping

An integration contract defines identity, field semantics, version and error behavior between independently changing systems. Map meaning, not merely matching field names. In this role, work through: customer_id maps to accountReference, while empty email has a defined missing-value policy. The practical workshop develops this into: Create source and target JSON fixtures and a field mapping table. Write a small transformer with required-field checks and an explicit rejected-record output.

Mental model: A translator must preserve meaning even when the words differ.

Boundary: Silently dropping unknown fields can lose business meaning; define compatibility rules.

Worked example: customer_id maps to accountReference, while empty email has a defined missing-value policy.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: HTTP APIs, queues and schema contracts (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required API / Enterprise Integration Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create source and target JSON fixtures and a field mapping table. Write a small transformer with required-field checks and an explicit rejected-record output.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py beginner
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

customer_id maps to accountReference, while empty email has a defined missing-value policy. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create source and target JSON fixtures and a field mapping table. Write a small transformer with required-field checks and an explicit rejected-record output.

Expected: Every source record is accepted or rejected with a reason.

Role workshop · debug and verify

Silently dropping unknown fields can lose business meaning; define compatibility rules. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save mapping code, schemas and rejection examples. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: Every source record is accepted or rejected with a reason.

Expected: Every source record is accepted or rejected with a reason.

Troubleshoot: The role exercise differs from the prediction: Silently dropping unknown fields can lose business meaning; define compatibility rules.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: mapping code, schemas and rejection examples; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with contracts and schema mapping. Use the glossary below, then write your prediction for: customer_id maps to accountReference, while empty email has a defined missing-value policy. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the API / Enterprise Integration Engineer role interview. Explain contracts and schema mapping using this case: customer_id maps to accountReference, while empty email has a defined missing-value policy. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate contracts and schema mapping to a system or workflow you know. Explain contracts and schema mapping using this case: customer_id maps to accountReference, while empty email has a defined missing-value policy. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Silently dropping unknown fields can lose business meaning; define compatibility rules.

Interview: Explain contracts and schema mapping using this case: customer_id maps to accountReference, while empty email has a defined missing-value policy. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? customer_id maps to accountReference, while empty email has a defined missing-value policy.

Every source record is accepted or rejected with a reason.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: Every source record is accepted or rejected with a reason. — An integration contract defines identity, field semantics, version and error behavior between independently changing systems. Map meaning, not merely matching field names. Every source record is accepted or rejected with a reason.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Transactional outbox: Write business data and the event to publish in one local transaction, then deliver the event separately.

Apply transactional outbox in API / Enterprise Integration Engineer: Use the concept to complete this role exercise: Design retries with idempotency and a dead-letter path

Idempotence and delivery ordering: Messages can repeat or arrive out of order. Stable keys and versions distinguish duplicate transport from a newer business update.

### Transactional outbox

Write business data and the event to publish in one local transaction, then deliver the event separately. In this role, work through: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. The practical workshop develops this into: Use the outbox reference, add versioned consumer state and test duplicate, stale and newer events. Record the chosen policy for conflicting equal versions.

Mental model: Record a sale and its mailing slip in the same ledger before dispatch.

Boundary: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Role application: A duplicate letter and a corrected letter need different handling.

Messages can repeat or arrive out of order. Stable keys and versions distinguish duplicate transport from a newer business update.

Worked example: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state.

Shared foundation example: The reference stores order-1 and its pending event together.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: HTTP APIs, queues and schema contracts (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for API / Enterprise Integration Engineer: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state.

Predict the worked case

Read this case without running a tool: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transactional outbox.

Connect the concept to the role

Apply this rule: Write business data and the event to publish in one local transaction, then deliver the event separately. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transactional outbox to this case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Transactional outbox; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transactional outbox. Use the glossary below, then write your prediction for: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the API / Enterprise Integration Engineer role interview. Explain transactional outbox using this case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transactional outbox to a system or workflow you know. Explain transactional outbox using this case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Why can publishing first lose consistency if the database write fails?

Interview: Explain transactional outbox using this case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. State the evidence, one alternative and where the mental model stops.

Quiz: After the Idempotence and delivery ordering rehearsal, check this foundation: Business data commits but publishing its event fails. Which design closes this local write/publish gap?

Publish first, then hope the business write succeeds.

Commit the data and pending outbox entry in one local transaction.

Use a longer broker timeout without recording pending work.

Reference: Commit the data and pending outbox entry in one local transaction. — The outbox preserves a durable publication intent. Delivery can still repeat, so consumers need suitable deduplication.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Idempotence and delivery ordering

Messages can repeat or arrive out of order. Stable keys and versions distinguish duplicate transport from a newer business update. In this role, work through: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. The practical workshop develops this into: Use the outbox reference, add versioned consumer state and test duplicate, stale and newer events. Record the chosen policy for conflicting equal versions.

Mental model: A duplicate letter and a corrected letter need different handling.

Boundary: A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available.

Worked example: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: HTTP APIs, queues and schema contracts (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required API / Enterprise Integration Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Use the outbox reference, add versioned consumer state and test duplicate, stale and newer events. Record the chosen policy for conflicting equal versions.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py intermediate
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Use the outbox reference, add versioned consumer state and test duplicate, stale and newer events. Record the chosen policy for conflicting equal versions.

```
python3 outbox.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: One effect per event and no stale overwrite.

Role workshop · debug and verify

A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save consumer tests and delivery contract. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: One effect per event and no stale overwrite.

Expected: One effect per event and no stale overwrite.

Troubleshoot: The role exercise differs from the prediction: A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: consumer tests and delivery contract; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with idempotence and delivery ordering. Use the glossary below, then write your prediction for: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the API / Enterprise Integration Engineer role interview. Explain idempotence and delivery ordering using this case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate idempotence and delivery ordering to a system or workflow you know. Explain idempotence and delivery ordering using this case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available.

Interview: Explain idempotence and delivery ordering using this case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state.

Ignore the failing case and keep only the successful screenshot.

One effect per event and no stale overwrite.

Treat any successful command as proof that all business and access rules passed.

Reference: One effect per event and no stale overwrite. — Messages can repeat or arrive out of order. Stable keys and versions distinguish duplicate transport from a newer business update. One effect per event and no stale overwrite.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Failure semantics: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.

Apply failure semantics in API / Enterprise Integration Engineer: Use the concept to complete this role exercise: Rehearse partial failure, reconciliation and compatible schema evolution

Poison messages and recovery: A permanently invalid message should not cause infinite retries or block all unrelated work. Preserve it with context for review and replay only after a justified repair.

### Failure semantics

Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. In this role, work through: One malformed event among five should be quarantined with its ID and error. The practical workshop develops this into: Add bounded retries, a dead-letter collection and replay-by-ID to the local simulation. Repair the malformed fixture and prove successful replay without duplicating prior effects.

Mental model: Track a parcel even when the receipt acknowledgment is lost.

Boundary: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Role application: Move a damaged parcel to an exception desk while other deliveries continue.

A permanently invalid message should not cause infinite retries or block all unrelated work. Preserve it with context for review and replay only after a justified repair.

Worked example: One malformed event among five should be quarantined with its ID and error.

Shared foundation example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: HTTP APIs, queues and schema contracts (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for API / Enterprise Integration Engineer: One malformed event among five should be quarantined with its ID and error.

Predict the worked case

Read this case without running a tool: One malformed event among five should be quarantined with its ID and error. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in failure semantics.

Connect the concept to the role

Apply this rule: Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies failure semantics to this case: One malformed event among five should be quarantined with its ID and error. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: One malformed event among five should be quarantined with its ID and error. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Failure semantics; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with failure semantics. Use the glossary below, then write your prediction for: One malformed event among five should be quarantined with its ID and error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the API / Enterprise Integration Engineer role interview. Explain failure semantics using this case: One malformed event among five should be quarantined with its ID and error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate failure semantics to a system or workflow you know. Explain failure semantics using this case: One malformed event among five should be quarantined with its ID and error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you recover a permanently failing event without blocking all orders?

Interview: Explain failure semantics using this case: One malformed event among five should be quarantined with its ID and error. State the evidence, one alternative and where the mental model stops.

Quiz: After the Poison messages and recovery rehearsal, check this foundation: A consumer commits its effect and crashes before acknowledging. What must the design handle?

The broker can infer the effect and guarantee no replay.

The effect must be automatically rolled back by the broker.

The message can be delivered again after the effect already happened.

Reference: The message can be delivered again after the effect already happened. — Acknowledgment and the business effect are separate boundaries. Model the crash window and make replay safe.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html

### Poison messages and recovery

A permanently invalid message should not cause infinite retries or block all unrelated work. Preserve it with context for review and replay only after a justified repair. In this role, work through: One malformed event among five should be quarantined with its ID and error. The practical workshop develops this into: Add bounded retries, a dead-letter collection and replay-by-ID to the local simulation. Repair the malformed fixture and prove successful replay without duplicating prior effects.

Mental model: Move a damaged parcel to an exception desk while other deliveries continue.

Boundary: Deleting a poison message hides data loss; retain an auditable exception record.

Worked example: One malformed event among five should be quarantined with its ID and error.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: HTTP APIs, queues and schema contracts (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required API / Enterprise Integration Engineer workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Add bounded retries, a dead-letter collection and replay-by-ID to the local simulation. Repair the malformed fixture and prove successful replay without duplicating prior effects.

Inspect inputs and rules

Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.

Expected: A written prediction with the input and the expected behavior.

Run the reference exercise

Run this level. The reference is a deliberately small local fixture, not a deployed production system.

```
python3 outbox.py advanced
```

Run from the extracted lab folder. This command executes the supplied reference exercise.

Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

Change one input

Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.

Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

Role workshop · predict

One malformed event among five should be quarantined with its ID and error. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Add bounded retries, a dead-letter collection and replay-by-ID to the local simulation. Repair the malformed fixture and prove successful replay without duplicating prior effects.

```
python3 outbox.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: All five IDs accounted for and repaired replay is traceable.

Role workshop · debug and verify

Deleting a poison message hides data loss; retain an auditable exception record. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save integration recovery tool and runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: All five IDs accounted for and repaired replay is traceable.

Expected: All five IDs accounted for and repaired replay is traceable.

Troubleshoot: The role exercise differs from the prediction: Deleting a poison message hides data loss; retain an auditable exception record.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: integration recovery tool and runbook; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with poison messages and recovery. Use the glossary below, then write your prediction for: One malformed event among five should be quarantined with its ID and error. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the API / Enterprise Integration Engineer role interview. Explain poison messages and recovery using this case: One malformed event among five should be quarantined with its ID and error. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate poison messages and recovery to a system or workflow you know. Explain poison messages and recovery using this case: One malformed event among five should be quarantined with its ID and error. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Deleting a poison message hides data loss; retain an auditable exception record.

Interview: Explain poison messages and recovery using this case: One malformed event among five should be quarantined with its ID and error. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? One malformed event among five should be quarantined with its ID and error.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

All five IDs accounted for and repaired replay is traceable.

Reference: All five IDs accounted for and repaired replay is traceable. — A permanently invalid message should not cause infinite retries or block all unrelated work. Preserve it with context for review and replay only after a justified repair. All five IDs accounted for and repaired replay is traceable.

Sources:

AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html

Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/

Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework

Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
