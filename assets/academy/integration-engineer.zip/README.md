# API / Enterprise Integration Engineer

Software Engineering

Start with contracts and schema mapping. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward integration recovery tool and runbook.

## beginner

Create source and target JSON fixtures and a field mapping table. Write a small transformer with required-field checks and an explicit rejected-record output.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Boundaries and ownership
A boundary separates responsibilities. Each important piece of data needs an owner and a defined change contract.
Mental model: Departments own different ledgers and exchange agreed forms.
Limit: Drawing more boxes does not make a system more reliable.
Example: The order service owns orders; a notification consumer handles messages.
Recall: Which component owns the truth about whether an order exists?

### Contracts and schema mapping
An integration contract defines identity, field semantics, version and error behavior between independently changing systems. Map meaning, not merely matching field names.
Mental model: A translator must preserve meaning even when the words differ.
Limit: Silently dropping unknown fields can lose business meaning; define compatibility rules.
Example: customer_id maps to accountReference, while empty email has a defined missing-value policy.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Silently dropping unknown fields can lose business meaning; define compatibility rules.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py beginner
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
customer_id maps to accountReference, while empty email has a defined missing-value policy. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create source and target JSON fixtures and a field mapping table. Write a small transformer with required-field checks and an explicit rejected-record output.
Expected: Every source record is accepted or rejected with a reason.

6. Role workshop · debug and verify
Silently dropping unknown fields can lose business meaning; define compatibility rules. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save mapping code, schemas and rejection examples. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Every source record is accepted or rejected with a reason.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Contracts and schema mapping: Silently dropping unknown fields can lose business meaning; define compatibility rules.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: mapping code, schemas and rejection examples
Every source record is accepted or rejected with a reason.

Interview: Work through this API / Enterprise Integration Engineer case: customer_id maps to accountReference, while empty email has a defined missing-value policy. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An integration contract defines identity, field semantics, version and error behavior between independently changing systems. Map meaning, not merely matching field names. Expected evidence: Every source record is accepted or rejected with a reason. Diagnosis: Silently dropping unknown fields can lose business meaning; define compatibility rules. State the limits of the mental model: A translator must preserve meaning even when the words differ.

Resume: Built mapping code, schemas and rejection examples using HTTP APIs, queues and schema contracts; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Use the outbox reference, add versioned consumer state and test duplicate, stale and newer events. Record the chosen policy for conflicting equal versions.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Transactional outbox
Write business data and the event to publish in one local transaction, then deliver the event separately.
Mental model: Record a sale and its mailing slip in the same ledger before dispatch.
Limit: The dispatcher can deliver twice; consumers need deduplication or idempotent effects.
Example: The reference stores order-1 and its pending event together.
Recall: Why can publishing first lose consistency if the database write fails?

### Idempotence and delivery ordering
Messages can repeat or arrive out of order. Stable keys and versions distinguish duplicate transport from a newer business update.
Mental model: A duplicate letter and a corrected letter need different handling.
Limit: A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available.
Example: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py intermediate
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Use the outbox reference, add versioned consumer state and test duplicate, stale and newer events. Record the chosen policy for conflicting equal versions.
```
python3 outbox.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: One effect per event and no stale overwrite.

6. Role workshop · debug and verify
A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save consumer tests and delivery contract. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: One effect per event and no stale overwrite.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Idempotence and delivery ordering: A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: consumer tests and delivery contract
One effect per event and no stale overwrite.

Interview: Work through this API / Enterprise Integration Engineer case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Messages can repeat or arrive out of order. Stable keys and versions distinguish duplicate transport from a newer business update. Expected evidence: One effect per event and no stale overwrite. Diagnosis: A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available. State the limits of the mental model: A duplicate letter and a corrected letter need different handling.

Resume: Built consumer tests and delivery contract using HTTP APIs, queues and schema contracts; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Add bounded retries, a dead-letter collection and replay-by-ID to the local simulation. Repair the malformed fixture and prove successful replay without duplicating prior effects.

Setup: Install Python 3 from python.org. Verify python3 --version (Windows: py --version). Commands below use python3; use py on Windows. No third-party Python packages are required. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Failure semantics
Describe what can be lost, repeated or delayed at each failure point. Choose controls according to user impact.
Mental model: Track a parcel even when the receipt acknowledgment is lost.
Limit: Exactly-once business outcomes require precise scope; a transport slogan is insufficient.
Example: A crash after receipt but before acknowledgment causes replay; the consumer key prevents a duplicate receipt.
Recall: How would you recover a permanently failing event without blocking all orders?

### Poison messages and recovery
A permanently invalid message should not cause infinite retries or block all unrelated work. Preserve it with context for review and replay only after a justified repair.
Mental model: Move a damaged parcel to an exception desk while other deliveries continue.
Limit: Deleting a poison message hides data loss; retain an auditable exception record.
Example: One malformed event among five should be quarantined with its ID and error.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Deleting a poison message hides data loss; retain an auditable exception record.

1. Inspect inputs and rules
Open the reference file and included CSV/Markdown files. Predict a success and a failure case before running.
Expected: A written prediction with the input and the expected behavior.

2. Run the reference exercise
Run this level. The reference is a deliberately small local fixture, not a deployed production system.
```
python3 outbox.py advanced
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: One order and event commit together; later levels deliver twice but keep one receipt. Advanced leaves acknowledgment pending deliberately.

3. Change one input
Add a normal case and a boundary case in a copy. For a workbook-only route, add the cases to the evidence table instead of editing code.
Expected: Predictions and observed outcomes are recorded; discrepancies are investigated.

4. Role workshop · predict
One malformed event among five should be quarantined with its ID and error. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Add bounded retries, a dead-letter collection and replay-by-ID to the local simulation. Repair the malformed fixture and prove successful replay without duplicating prior effects.
```
python3 outbox.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: All five IDs accounted for and repaired replay is traceable.

6. Role workshop · debug and verify
Deleting a poison message hides data loss; retain an auditable exception record. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save integration recovery tool and runbook. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: All five IDs accounted for and repaired replay is traceable.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Poison messages and recovery: Deleting a poison message hides data loss; retain an auditable exception record.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: integration recovery tool and runbook
All five IDs accounted for and repaired replay is traceable.

Interview: Work through this API / Enterprise Integration Engineer case: One malformed event among five should be quarantined with its ID and error. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A permanently invalid message should not cause infinite retries or block all unrelated work. Preserve it with context for review and replay only after a justified repair. Expected evidence: All five IDs accounted for and repaired replay is traceable. Diagnosis: Deleting a poison message hides data loss; retain an auditable exception record. State the limits of the mental model: Move a damaged parcel to an exception desk while other deliveries continue.

Resume: Built integration recovery tool and runbook using HTTP APIs, queues and schema contracts; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
AWS Well-Architected Framework: https://docs.aws.amazon.com/wellarchitected/latest/framework/welcome.html
Azure Well-Architected Framework: https://learn.microsoft.com/en-us/azure/well-architected/
Google Cloud Well-Architected Framework: https://cloud.google.com/architecture/framework
Python sqlite3: parameters and transactions: https://docs.python.org/3/library/sqlite3.html
