# API / Enterprise Integration Engineer — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Contracts and schema mapping

An integration contract defines identity, field semantics, version and error behavior between independently changing systems. Map meaning, not merely matching field names.
Mental model: A translator must preserve meaning even when the words differ.
Case: customer_id maps to accountReference, while empty email has a defined missing-value policy.
Task: Create source and target JSON fixtures and a field mapping table. Write a small transformer with required-field checks and an explicit rejected-record output.
Acceptance: Every source record is accepted or rejected with a reason.
Troubleshooting: Silently dropping unknown fields can lose business meaning; define compatibility rules.
Deliverable: mapping code, schemas and rejection examples

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Idempotence and delivery ordering

Messages can repeat or arrive out of order. Stable keys and versions distinguish duplicate transport from a newer business update.
Mental model: A duplicate letter and a corrected letter need different handling.
Case: Event e2/version 2 arriving before e1/version 1 must not be overwritten by stale state.
Task: Use the outbox reference, add versioned consumer state and test duplicate, stale and newer events. Record the chosen policy for conflicting equal versions.
Acceptance: One effect per event and no stale overwrite.
Troubleshooting: A timestamp from unrelated clocks may not provide a reliable total order; use a source-defined version where available.
Deliverable: consumer tests and delivery contract

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Poison messages and recovery

A permanently invalid message should not cause infinite retries or block all unrelated work. Preserve it with context for review and replay only after a justified repair.
Mental model: Move a damaged parcel to an exception desk while other deliveries continue.
Case: One malformed event among five should be quarantined with its ID and error.
Task: Add bounded retries, a dead-letter collection and replay-by-ID to the local simulation. Repair the malformed fixture and prove successful replay without duplicating prior effects.
Acceptance: All five IDs accounted for and repaired replay is traceable.
Troubleshooting: Deleting a poison message hides data loss; retain an auditable exception record.
Deliverable: integration recovery tool and runbook

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
