import sqlite3,sys
c=sqlite3.connect(':memory:')
c.executescript('CREATE TABLE orders(id TEXT PRIMARY KEY); CREATE TABLE events(id TEXT PRIMARY KEY, delivered INTEGER DEFAULT 0); CREATE TABLE receipts(id TEXT PRIMARY KEY);')
def order(id):
    with c:
        c.execute('INSERT OR IGNORE INTO orders VALUES (?)',(id,))
        c.execute('INSERT OR IGNORE INTO events(id) VALUES (?)',(id,))
def deliver():
    for (id,) in c.execute('SELECT id FROM events WHERE delivered=0').fetchall():
        with c:c.execute('INSERT OR IGNORE INTO receipts VALUES (?)',(id,))
        # Simulate a crash before acknowledgment in the advanced exercise.
        if sys.argv[1]!='advanced':
            with c:c.execute('UPDATE events SET delivered=1 WHERE id=?',(id,))
order('order-1');print('1 order and 1 event committed together')
if sys.argv[1]!='beginner':
    order('order-1');deliver();deliver()
    assert c.execute('SELECT COUNT(*) FROM receipts').fetchone()[0]==1
    print('2 deliveries, 1 consumer receipt')
if sys.argv[1]=='advanced':
    assert c.execute('SELECT delivered FROM events').fetchone()[0]==0
    print('pending acknowledgment: duplicate delivery remains possible; consumer deduplicates')
print('PASS design '+sys.argv[1]);c.close()
