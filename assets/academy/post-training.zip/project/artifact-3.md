# Base-versus-adapter evaluation report

Project: Small-model adaptation with contamination checks
Status: blank work product — not completed evidence

## Purpose and audience
Adapt a small language model for a bounded task and compare it honestly with prompting.

## Required content
Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.

## Failure evidence
Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
