# Small-model adaptation with contamination checks

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Adapt a small language model for a bounded task and compare it honestly with prompting.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

## Limitations and next iteration
Compare adapter tuning with retrieval augmentation before recommending the more expensive approach.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
