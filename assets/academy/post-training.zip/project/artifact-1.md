# Adapter training recipe and model card

Project: Small-model adaptation with contamination checks
Status: blank work product — not completed evidence

## Purpose and audience
Adapt a small language model for a bounded task and compare it honestly with prompting.

## Required content
Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.

## Failure evidence
Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
