# Small-model adaptation with contamination checks

Career: LLM customization / post-training engineer
Reviewed: 2026-10-22

Adapt a small language model for a bounded task and compare it honestly with prompting.

## Prerequisites
Transformer training, data quality and evaluation; preference optimization requires additional statistical and safety judgment.

## Included starter versus your implementation
A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Adapter training recipe and model card — artifact-1.md
2. Split/contamination audit — artifact-2.md
3. Base-versus-adapter evaluation report — artifact-3.md

## Troubleshooting
- CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
- OOM: reduce batch/context size and inspect live allocations.
- Unstable timings: warm up, synchronize and isolate other workloads.

## Extension
Compare adapter tuning with retrieval augmentation before recommending the more expensive approach.

## Primary learning resources
- PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html — Open source · hardware dependent; Tensor operations, training and hardware-aware profiling.
- Transformers: https://huggingface.co/docs/transformers/installation — Open source · model licenses vary; Model loading and tokenizer/model compatibility.
- TRL SFTTrainer: https://huggingface.co/docs/trl/sft_trainer — Open source · compute required; Supervised adaptation with explicit dataset formatting.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
