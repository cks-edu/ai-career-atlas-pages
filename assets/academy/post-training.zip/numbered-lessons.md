# LLM customization / post-training engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Adaptation choices: Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Adaptation choices

Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure. In this role, work through: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Give a worker a clearer brief, a reference manual or additional training depending on the gap.

Boundary: Fine-tuning does not guarantee factuality or remove the need for evaluation.

Worked example: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); Transformers (Open source · model licenses vary); TRL SFTTrainer (Open source · compute required)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for LLM customization / post-training engineer: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update.

Predict the worked case

Read this case without running a tool: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in adaptation choices.

Connect the concept to the role

Apply this rule: Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Fine-tuning does not guarantee factuality or remove the need for evaluation.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies adaptation choices to this case: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Adaptation choices; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with adaptation choices. Use the glossary below, then write your prediction for: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLM customization / post-training engineer role interview. Explain adaptation choices using this case: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate adaptation choices to a system or workflow you know. Explain adaptation choices using this case: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain adaptation choices using this case: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update.

Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure. — Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure. Fine-tuning does not guarantee factuality or remove the need for evaluation.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Transformers: https://huggingface.co/docs/transformers/installation

TRL SFTTrainer: https://huggingface.co/docs/trl/sft_trainer

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

### Diagnose: The tuned model forgets adjacent tasks

The adaptation gate flags a capability drop greater than two points on protected regression tasks. Two protected tasks regress beyond the declared allowance after tuning. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Give a worker a clearer brief, a reference manual or additional training depending on the gap.

A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update.

Worked example: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: PyTorch (Open source · hardware dependent); Transformers (Open source · model licenses vary); TRL SFTTrainer (Open source · compute required)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The adaptation gate flags a capability drop greater than two points on protected regression tasks. Two protected tasks regress beyond the declared allowance after tuning. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The adaptation gate flags a capability drop greater than two points on protected regression tasks. Apply this toy-case rule manually: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Changing a prompt, adding documents and updating model weights solve different problems. Try the simpler option before deciding that training is necessary.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Consider three fictional failures: wrong output format, missing current company rules, and a recurring specialist writing style requirement.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An options table and an evaluation plan.

Preparation · Try step 2

Compare clearer instructions, retrieval of approved documents and model adaptation for each.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An options table and an evaluation plan.

Preparation · Try step 3

Write a small evaluation set and state what evidence would justify moving beyond the simpler approach.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An options table and an evaluation plan.

Preparation · Explain and check your result

Fresh facts are not treated as a reason to retrain automatically; every proposed change has a check against the original problem. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: An options table and an evaluation plan. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The adaptation gate flags a capability drop greater than two points on protected regression tasks. Apply this toy-case rule manually: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Two protected tasks regress beyond the declared allowance after tuning. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Two protected tasks regress beyond the declared allowance after tuning. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: the tuned model forgets adjacent tasks. Use the glossary below, then write your prediction for: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLM customization / post-training engineer role interview. Explain diagnose: the tuned model forgets adjacent tasks using this case: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: the tuned model forgets adjacent tasks to a system or workflow you know. Explain diagnose: the tuned model forgets adjacent tasks using this case: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Use separate adaptation and general-capability tests, with provenance and repeated evaluations. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: the tuned model forgets adjacent tasks using this case: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline. State the evidence, one alternative and where the mental model stops.

Quiz: The tuned model forgets adjacent tasks: The adaptation gate flags a capability drop greater than two points on protected regression tasks.

Change the acceptance rule after seeing an inconvenient result.

Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline.

Omit failed cases and report only the successful demonstrations.

Reference: Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline. — Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline. Use separate adaptation and general-capability tests, with provenance and repeated evaluations.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Transformers: https://huggingface.co/docs/transformers/installation

TRL SFTTrainer: https://huggingface.co/docs/trl/sft_trainer

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Transformer training, data quality and evaluation; preference optimization requires additional statistical and safety judgment.

Terms:

Supervised example quality: Training examples must reflect the intended input-output behavior with consistent formatting and rights to use the data. Keep evaluation examples separate from tuning decisions.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.

tensor: A multidimensional array of values with a shape and data type.

### Supervised example quality

Training examples must reflect the intended input-output behavior with consistent formatting and rights to use the data. Keep evaluation examples separate from tuning decisions. In this role, work through: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An apprentice learns the habits shown in the examples, including bad ones.

Boundary: More examples can amplify inconsistent or biased labeling.

Worked example: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Transformer training, data quality and evaluation; preference optimization requires additional statistical and safety judgment.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); Transformers (Open source · model licenses vary); TRL SFTTrainer (Open source · compute required)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for LLM customization / post-training engineer: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training.

Predict the worked case

Read this case without running a tool: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in supervised example quality.

Connect the concept to the role

Apply this rule: Training examples must reflect the intended input-output behavior with consistent formatting and rights to use the data. Keep evaluation examples separate from tuning decisions. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More examples can amplify inconsistent or biased labeling.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies supervised example quality to this case: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Supervised example quality; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with supervised example quality. Use the glossary below, then write your prediction for: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLM customization / post-training engineer role interview. Explain supervised example quality using this case: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate supervised example quality to a system or workflow you know. Explain supervised example quality using this case: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain supervised example quality using this case: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training.

Treat a passing starter as proof of the whole role workflow.

Training examples must reflect the intended input-output behavior with consistent formatting and rights to use the data. Keep evaluation examples separate from tuning decisions.

Ignore the failure because the tool produced an output.

Reference: Training examples must reflect the intended input-output behavior with consistent formatting and rights to use the data. Keep evaluation examples separate from tuning decisions. — Training examples must reflect the intended input-output behavior with consistent formatting and rights to use the data. Keep evaluation examples separate from tuning decisions. More examples can amplify inconsistent or biased labeling.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Transformers: https://huggingface.co/docs/transformers/installation

TRL SFTTrainer: https://huggingface.co/docs/trl/sft_trainer

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

### Integrate: Small-model adaptation with contamination checks

Adapt a small language model for a bounded task and compare it honestly with prompting. Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest. In this role, work through: Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Role application: An apprentice learns the habits shown in the examples, including bad ones.

Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training.

Worked example: Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.

Setup: Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PyTorch (Open source · hardware dependent); Transformers (Open source · model licenses vary); TRL SFTTrainer (Open source · compute required)

Adapt a small language model for a bounded task and compare it honestly with prompting. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Adapt a small language model for a bounded task and compare it honestly with prompting.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

Prepare the project inputs

Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The adaptation gate flags a capability drop greater than two points on protected regression tasks. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Deliverable: lesson-intermediate-2.md: Adapter training recipe and model card; Split/contamination audit. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: small-model adaptation with contamination checks. Use the glossary below, then write your prediction for: Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLM customization / post-training engineer role interview. Explain integrate: small-model adaptation with contamination checks using this case: Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: small-model adaptation with contamination checks to a system or workflow you know. Explain integrate: small-model adaptation with contamination checks using this case: Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. Identify one observation that would contradict your claim.

Interview: Explain integrate: small-model adaptation with contamination checks using this case: Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Small-model adaptation with contamination checks at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.

Reference: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. — Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Transformers: https://huggingface.co/docs/transformers/installation

TRL SFTTrainer: https://huggingface.co/docs/trl/sft_trainer

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Controlled tuning comparisons: Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.

CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.

OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.

tensor: A multidimensional array of values with a shape and data type.

### Controlled tuning comparisons

Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective. In this role, work through: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: An athlete improving one event may become worse at another.

Boundary: A lower training loss is not proof of improved user outcomes.

Worked example: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); Transformers (Open source · model licenses vary); TRL SFTTrainer (Open source · compute required)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for LLM customization / post-training engineer: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison.

Predict the worked case

Read this case without running a tool: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in controlled tuning comparisons.

Connect the concept to the role

Apply this rule: Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A lower training loss is not proof of improved user outcomes.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies controlled tuning comparisons to this case: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Controlled tuning comparisons; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with controlled tuning comparisons. Use the glossary below, then write your prediction for: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLM customization / post-training engineer role interview. Explain controlled tuning comparisons using this case: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate controlled tuning comparisons to a system or workflow you know. Explain controlled tuning comparisons using this case: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain controlled tuning comparisons using this case: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective.

Reference: Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective. — Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective. A lower training loss is not proof of improved user outcomes.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Transformers: https://huggingface.co/docs/transformers/installation

TRL SFTTrainer: https://huggingface.co/docs/trl/sft_trainer

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/

### Defend: Small-model adaptation with contamination checks

Adapt a small language model for a bounded task and compare it honestly with prompting. Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions. In this role, work through: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Role application: An athlete improving one event may become worse at another.

A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison.

Worked example: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

Setup: Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PyTorch (Open source · hardware dependent); Transformers (Open source · model licenses vary); TRL SFTTrainer (Open source · compute required)

Adapt a small language model for a bounded task and compare it honestly with prompting. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

Adapt a small language model for a bounded task and compare it honestly with prompting.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

Prepare the project inputs

Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. A reviewer must reproduce one result and identify which capabilities you implemented. Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

Deliverable: lesson-advanced-2.md: Adapter training recipe and model card; Split/contamination audit; Base-versus-adapter evaluation report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: small-model adaptation with contamination checks. Use the glossary below, then write your prediction for: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the LLM customization / post-training engineer role interview. Explain defend: small-model adaptation with contamination checks using this case: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: small-model adaptation with contamination checks to a system or workflow you know. Explain defend: small-model adaptation with contamination checks using this case: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. Identify one observation that would contradict your claim.

Interview: Explain defend: small-model adaptation with contamination checks using this case: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Small-model adaptation with contamination checks at this level?

Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training. — Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training. Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Transformers: https://huggingface.co/docs/transformers/installation

TRL SFTTrainer: https://huggingface.co/docs/trl/sft_trainer

Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

MLflow: https://mlflow.org/docs/latest/
