## beginner — Adaptation choices

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Adaptation choices
Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure.
Mental model: Give a worker a clearer brief, a reference manual or additional training depending on the gap.
Boundary: Fine-tuning does not guarantee factuality or remove the need for evaluation.
Worked example: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The tuned model forgets adjacent tasks
The adaptation gate flags a capability drop greater than two points on protected regression tasks. Two protected tasks regress beyond the declared allowance after tuning. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline.
Recall: Use separate adaptation and general-capability tests, with provenance and repeated evaluations. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Adaptation choices: Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Changing a prompt, adding documents and updating model weights solve different problems. Try the simpler option before deciding that training is necessary.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Consider three fictional failures: wrong output format, missing current company rules, and a recurring specialist writing style requirement.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An options table and an evaluation plan.

3. Try step 2
Compare clearer instructions, retrieval of approved documents and model adaptation for each.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An options table and an evaluation plan.

4. Try step 3
Write a small evaluation set and state what evidence would justify moving beyond the simpler approach.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An options table and an evaluation plan.

5. Explain and check your result
Fresh facts are not treated as a reason to retrain automatically; every proposed change has a check against the original problem. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An options table and an evaluation plan. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The adaptation gate flags a capability drop greater than two points on protected regression tasks. Apply this toy-case rule manually: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two protected tasks regress beyond the declared allowance after tuning. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to LLM customization / post-training engineer.
Consider three fictional failures: wrong output format, missing current company rules, and a recurring specialist writing style requirement.
Compare clearer instructions, retrieval of approved documents and model adaptation for each.
Write a small evaluation set and state what evidence would justify moving beyond the simpler approach.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An options table and an evaluation plan. Include beginner-worksheet.md and your completed Adaptation decision and regression report.
Check: Fresh facts are not treated as a reason to retrain automatically; every proposed change has a check against the original problem.

### Interview
Explain your beginner solution for LLM customization / post-training engineer. Use this scenario: The adaptation gate flags a capability drop greater than two points on protected regression tasks.
Review: Start with the task and permitted scope. Explain adaptation choices: Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure. Show the input and observed output, then address Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An options table and an evaluation plan. Include beginner-worksheet.md and your completed Adaptation decision and regression report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

