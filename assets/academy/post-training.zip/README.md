# LLM customization / post-training engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Adaptation choices. Changing a prompt, adding documents and updating model weights solve different problems. Try the simpler option before deciding that training is necessary. Then try Choose how to improve an assistant. The three levels build toward Small-model adaptation with contamination checks. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Adaptation choices

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Adaptation choices
Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure.
Mental model: Give a worker a clearer brief, a reference manual or additional training depending on the gap.
Boundary: Fine-tuning does not guarantee factuality or remove the need for evaluation.
Worked example: A policy changes weekly: first test retrieval with versioned policy text rather than expecting training to memorize every update.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: The tuned model forgets adjacent tasks
The adaptation gate flags a capability drop greater than two points on protected regression tasks. Two protected tasks regress beyond the declared allowance after tuning. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline.
Recall: Use separate adaptation and general-capability tests, with provenance and repeated evaluations. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Adaptation choices: Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Changing a prompt, adding documents and updating model weights solve different problems. Try the simpler option before deciding that training is necessary.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Consider three fictional failures: wrong output format, missing current company rules, and a recurring specialist writing style requirement.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An options table and an evaluation plan.

3. Try step 2
Compare clearer instructions, retrieval of approved documents and model adaptation for each.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An options table and an evaluation plan.

4. Try step 3
Write a small evaluation set and state what evidence would justify moving beyond the simpler approach.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An options table and an evaluation plan.

5. Explain and check your result
Fresh facts are not treated as a reason to retrain automatically; every proposed change has a check against the original problem. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An options table and an evaluation plan. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The adaptation gate flags a capability drop greater than two points on protected regression tasks. Apply this toy-case rule manually: Review when regression_drop > 2 (percentage points). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Two protected tasks regress beyond the declared allowance after tuning. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to LLM customization / post-training engineer.
Consider three fictional failures: wrong output format, missing current company rules, and a recurring specialist writing style requirement.
Compare clearer instructions, retrieval of approved documents and model adaptation for each.
Write a small evaluation set and state what evidence would justify moving beyond the simpler approach.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An options table and an evaluation plan. Include beginner-worksheet.md and your completed Adaptation decision and regression report.
Check: Fresh facts are not treated as a reason to retrain automatically; every proposed change has a check against the original problem.

### Interview
Explain your beginner solution for LLM customization / post-training engineer. Use this scenario: The adaptation gate flags a capability drop greater than two points on protected regression tasks.
Review: Start with the task and permitted scope. Explain adaptation choices: Prompting changes instructions, retrieval changes available evidence and fine-tuning changes learned parameters. Start with the cheapest method that addresses the observed failure. Show the input and observed output, then address Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An options table and an evaluation plan. Include beginner-worksheet.md and your completed Adaptation decision and regression report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Supervised example quality

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Transformer training, data quality and evaluation; preference optimization requires additional statistical and safety judgment.

### Supervised example quality
Training examples must reflect the intended input-output behavior with consistent formatting and rights to use the data. Keep evaluation examples separate from tuning decisions.
Mental model: An apprentice learns the habits shown in the examples, including bad ones.
Boundary: More examples can amplify inconsistent or biased labeling.
Worked example: Contradictory examples label the same refund request both approved and refused. Resolve the policy and annotation conflict before training.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Small-model adaptation with contamination checks
Adapt a small language model for a bounded task and compare it honestly with prompting. Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.
Recall: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. Identify one observation that would contradict your claim.

### Terms
Supervised example quality: Training examples must reflect the intended input-output behavior with consistent formatting and rights to use the data. Keep evaluation examples separate from tuning decisions.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Adapt a small language model for a bounded task and compare it honestly with prompting. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The adaptation gate flags a capability drop greater than two points on protected regression tasks. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Adapt a small language model for a bounded task and compare it honestly with prompting.
Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.
Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.
Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.
Deliverables: Adapter training recipe and model card; Split/contamination audit. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for LLM customization / post-training engineer. Use this scenario: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.
Review: Start with the task and permitted scope. Explain supervised example quality: Training examples must reflect the intended input-output behavior with consistent formatting and rights to use the data. Keep evaluation examples separate from tuning decisions. Show the input and observed output, then address Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Adapter training recipe and model card; Split/contamination audit. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Controlled tuning comparisons

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Controlled tuning comparisons
Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective.
Mental model: An athlete improving one event may become worse at another.
Boundary: A lower training loss is not proof of improved user outcomes.
Worked example: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Small-model adaptation with contamination checks
Adapt a small language model for a bounded task and compare it honestly with prompting. Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.
Recall: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. Identify one observation that would contradict your claim.

### Terms
Controlled tuning comparisons: Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Adapt a small language model for a bounded task and compare it honestly with prompting. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Adapt a small language model for a bounded task and compare it honestly with prompting.
Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.
Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.
Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.
Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions.
Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.
Compare adapter tuning with retrieval augmentation before recommending the more expensive approach.
Deliverables: Adapter training recipe and model card; Split/contamination audit; Base-versus-adapter evaluation report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. A reviewer must reproduce one result and identify which capabilities you implemented. Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

### Interview
Explain your advanced solution for LLM customization / post-training engineer. Use this scenario: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.
Review: Start with the task and permitted scope. Explain controlled tuning comparisons: Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective. Show the input and observed output, then address Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Adapter training recipe and model card; Split/contamination audit; Base-versus-adapter evaluation report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Transformers — Open source · model licenses vary
Model loading and tokenizer/model compatibility.
Alternative: A model-specific PyTorch implementation or llama.cpp for supported inference; API and model coverage differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

TRL SFTTrainer — Open source · compute required
Supervised adaptation with explicit dataset formatting.
Alternative: A plain PyTorch training loop or another supported fine-tuning framework; compare objective, memory and evaluation support.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
Transformers: https://huggingface.co/docs/transformers/installation
TRL SFTTrainer: https://huggingface.co/docs/trl/sft_trainer
Hugging Face LLM Course: https://huggingface.co/learn/llm-course/chapter1/1
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
MLflow: https://mlflow.org/docs/latest/
