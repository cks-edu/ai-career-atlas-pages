# LLM customization / post-training engineer — first attempt

Read the beginner instructions in README.md.

Goal:
Inputs:
My prediction and reasoning:
My result:
What I changed after checking:
One ambiguous case:
What I still need to learn:
