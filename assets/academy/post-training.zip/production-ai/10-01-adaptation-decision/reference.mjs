function adaptationRoute(failure) {
  const routes={format:'prompt-and-schema',missing_facts:'permission-aware-rag',stable_behavior:'evaluate-adaptation'};
  return Object.hasOwn(routes,failure) ? routes[failure] : 'investigate';
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(adaptationRoute('format')==='prompt-and-schema');
console.log("PASS: Formatting begins with simpler controls");
}
{
assert(adaptationRoute('missing_facts')==='permission-aware-rag');
console.log("PASS: Missing facts use approved evidence");
}
{
assert(adaptationRoute('stable_behavior')==='evaluate-adaptation'); assert(adaptationRoute('unknown')==='investigate');
console.log("PASS: Stable behavior and unknown problems remain explicit");
}
