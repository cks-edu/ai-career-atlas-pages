# Choose prompting, retrieval or adaptation from the failure

Prompting changes instructions; retrieval changes the evidence available at inference; fine-tuning changes learned parameters. Start from an observed failure and a strong simpler baseline. Fresh private facts usually require permission-aware retrieval, not memorizing them through training.

The toy decision table maps format failures to a prompt/schema baseline, missing approved facts to retrieval, and a stable specialist behavior to evaluation before adaptation. Unknown failures require investigation. It is a starting decision aid, not automatic model selection.

Task: Implement adaptationRoute. Compare a prompt baseline, RAG and LoRA in an ADR with the same held-out decision cases.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Observed failure → baseline comparison → adaptation decision → held-out evaluation.
State: The failure category and evidence determine the next experiment.
Boundary: New facts and stable behavior are different requirements.
Failure: A team retrains to incorporate a frequently changing policy.
Control: Try evidence retrieval for facts and validate cheaper baselines first.
Observability: Record baseline and candidate results on the same held-out cases.
Blast radius: All users receiving the adapted model or retrieved data.
Trade-off: Adaptation may improve a stable behavior but adds training, versioning and regression risk.

Limit: Fine-tuning needs lawful data use, adequate evaluation and operational resources. A recurring failure alone does not establish that adaptation will solve it.

Sources:
https://huggingface.co/docs/peft/main/conceptual_guides/lora
https://www.nist.gov/itl/ai-risk-management-framework
