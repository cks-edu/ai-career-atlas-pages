function adaptationPass(base, next, maxDrop) {
  const values=[base.format,base.refusal,next.format,next.refusal];
  return values.every(n=>Number.isFinite(n) && n>=0 && n<=1) && Number.isFinite(maxDrop) && maxDrop>=0 &&
    next.format >= base.format && base.refusal-next.refusal <= maxDrop;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(adaptationPass({format:.6,refusal:.9},{format:.8,refusal:.9},.02));
console.log("PASS: Improvement without protected loss passes");
}
{
assert(!adaptationPass({format:.6,refusal:.9},{format:.9,refusal:.45},.02));
console.log("PASS: A protected regression blocks despite format gains");
}
{
assert(adaptationPass({format:.6,refusal:.9},{format:.7,refusal:.8},.100001)); assert(!adaptationPass({format:.6,refusal:.9},{format:NaN,refusal:.9},.02));
console.log("PASS: Boundary tolerance and invalid data are handled");
}
