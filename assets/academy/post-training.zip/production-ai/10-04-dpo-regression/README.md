# DPO gains must survive protected regression tests

DPO learns from preferred and rejected responses. Better preference or formatting scores can coincide with worse safety behavior or forgotten capabilities. Compare the candidate with the frozen baseline on unchanged, held-out protected suites before promotion.

The fixture accepts improved format accuracy only when the drop in refusal accuracy stays within a predeclared tolerance and all inputs are valid proportions. The metric choice and tolerance are fictional exercise policy, not a universal safety standard.

Task: Implement adaptationPass. Create a candidate report with formatting, appropriate refusal and benign-helpfulness slices plus a compatible rollback plan.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Preference pairs → DPO candidate → protected evaluation → promote or hold.
State: Baseline and candidate metrics use the same declared cases.
Boundary: Improved formatting cannot erase an unacceptable protected regression.
Failure: A tuned model formats JSON better while failing safety cases.
Control: Apply predeclared regression limits before promotion.
Observability: Retain per-case diffs, benign refusal errors and protected-slice metrics.
Blast radius: Every user served the promoted base/adapter revision.
Trade-off: Task specialization can trade against retained behavior; rollback must remain available.

Limit: Refusal rate alone does not measure safety or helpfulness: a model can refuse harmless tasks. Add appropriate risk and benign slices, case review and uncertainty analysis.

Sources:
https://huggingface.co/docs/trl/main/dpo_trainer
https://scikit-learn.org/stable/common_pitfalls.html#data-leakage
https://www.nist.gov/itl/ai-risk-management-framework
