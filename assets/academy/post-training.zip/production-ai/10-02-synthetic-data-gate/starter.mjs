function filterSyntheticPairs(samples,heldOut=[],minMargin=0.2) { return samples; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(filterSyntheticPairs([{prompt:'p',chosen:'a',rejected:'b',margin:.5}]).length===1);
console.log("PASS: A valid preference pair survives");
}
{
const s={prompt:'Test  Q',chosen:'a',rejected:'b',margin:.5}; assert(filterSyntheticPairs([s],[' test q ']).length===0); assert(filterSyntheticPairs([s,s]).length===1);
console.log("PASS: Held-out overlap and duplicates are excluded");
}
{
assert(filterSyntheticPairs([{prompt:'p',chosen:'a',rejected:'a',margin:.5},{prompt:'q',chosen:'a',rejected:'b',margin:.1},{prompt:'x',chosen:3,rejected:'b',margin:.5}]).length===0);
console.log("PASS: Malformed, tied and weak pairs are rejected");
}
