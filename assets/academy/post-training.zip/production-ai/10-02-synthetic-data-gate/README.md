# Teacher–student distillation needs a data-quality gate

A larger teacher can generate examples for a smaller student, but synthetic output can be wrong, duplicated or contaminated by evaluation data. Record provenance and permissions. Keep held-out cases out of generation and training, and verify both shape and quality.

The quality gate accepts exact nonempty prompt/chosen/rejected fields plus a finite preference margin. It removes held-out overlap, identical choices and low-margin pairs. The fixture uses normalized prompt equality; real decontamination requires more than this exact-match check.

Task: Implement filterSyntheticPairs. Save rejection reasons in your own extension and manually inspect a small sample before proposing any training.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Teacher output → provenance/schema → contamination check → preference quality → training set.
State: Prompt fingerprints and choice margins accompany each pair.
Boundary: Held-out evaluation examples must not enter adaptation data.
Failure: Synthetic examples memorize the test questions and inflate scores.
Control: Reject overlapping, malformed, tied and low-margin pairs.
Observability: Report rejection counts and sampled human-review findings.
Blast radius: The trained model and every evaluation claim using contaminated cases.
Trade-off: Stricter filtering reduces dataset size but protects evidence quality.

Limit: A score margin from an automated judge may be biased or miscalibrated. Filtering does not make a dataset factual, licensed or safe by itself.

Sources:
https://scikit-learn.org/stable/common_pitfalls.html#data-leakage
https://huggingface.co/docs/trl/main/dpo_trainer
