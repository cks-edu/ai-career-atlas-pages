function filterSyntheticPairs(samples, heldOut=[], minMargin=0.2) {
  const norm=s=>s.trim().toLowerCase().replace(/\s+/g,' ');
  const excluded=new Set(heldOut.map(norm)); const seen=new Set();
  return samples.filter(s=>{
    if (!s || Object.keys(s).sort().join(',') !== 'chosen,margin,prompt,rejected') return false;
    if (![s.prompt,s.chosen,s.rejected].every(x=>typeof x==='string' && x.trim())) return false;
    const key=norm(s.prompt);
    if (excluded.has(key) || seen.has(key) || norm(s.chosen)===norm(s.rejected) || !Number.isFinite(s.margin) || s.margin<minMargin) return false;
    seen.add(key); return true;
  });
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(filterSyntheticPairs([{prompt:'p',chosen:'a',rejected:'b',margin:.5}]).length===1);
console.log("PASS: A valid preference pair survives");
}
{
const s={prompt:'Test  Q',chosen:'a',rejected:'b',margin:.5}; assert(filterSyntheticPairs([s],[' test q ']).length===0); assert(filterSyntheticPairs([s,s]).length===1);
console.log("PASS: Held-out overlap and duplicates are excluded");
}
{
assert(filterSyntheticPairs([{prompt:'p',chosen:'a',rejected:'a',margin:.5},{prompt:'q',chosen:'a',rejected:'b',margin:.1},{prompt:'x',chosen:3,rejected:'b',margin:.5}]).length===0);
console.log("PASS: Malformed, tied and weak pairs are rejected");
}
