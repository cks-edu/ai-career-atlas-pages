# LoRA and QLoRA: rank is a capacity choice

LoRA learns small low-rank matrices while keeping base weights frozen. Rank controls adapter capacity and affects resource use; alpha affects scaling. QLoRA combines parameter-efficient training with a quantized base. Neither method removes activation, optimizer or evaluation costs.

Validate a configuration before a training job: positive integer rank, finite positive alpha and an allowlisted precision strategy. This checks a worksheet contract, not a universal optimal setting. Select actual target modules and compatible versions using the library documentation.

Task: Implement validLoRA. Write a resource and version manifest for an optional future training run; label the 256 rank cap as this lab’s policy, not a library limit.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Base model + adapter config → resource check → training → held-out comparison.
State: Base revision, rank, alpha and quantization strategy identify the experiment.
Boundary: A small adapter file does not imply a small total training footprint.
Failure: A job fits the weights but runs out of memory during training.
Control: Validate config, profile a tiny run and preserve a reproducible manifest.
Observability: Record peak memory, loss, held-out metrics and exact package revisions.
Blast radius: Every deployment loading the base/adapter combination.
Trade-off: Higher rank adds capacity and resource use; quality must be tested, not assumed.

Limit: There is no rank/alpha pair that guarantees a good result for every task. Hardware, model, data and library behavior must be measured; this browser does not train a model.

Sources:
https://huggingface.co/docs/peft/main/conceptual_guides/lora
https://huggingface.co/docs/transformers/quantization/overview
