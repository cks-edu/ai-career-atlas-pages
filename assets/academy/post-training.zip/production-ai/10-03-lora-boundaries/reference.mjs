function validLoRA(c) {
  return !!c && Number.isSafeInteger(c.rank) && c.rank > 0 && c.rank <= 256 &&
    Number.isFinite(c.alpha) && c.alpha > 0 && ['fp16','bf16','qlora-4bit'].includes(c.strategy);
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(validLoRA({rank:16,alpha:32,strategy:'bf16'}));
console.log("PASS: A declared supported configuration passes");
}
{
assert(!validLoRA({rank:0,alpha:32,strategy:'bf16'})); assert(!validLoRA({rank:1.5,alpha:32,strategy:'bf16'})); assert(!validLoRA({rank:16,alpha:NaN,strategy:'bf16'}));
console.log("PASS: Invalid rank and scaling fail");
}
{
assert(!validLoRA({rank:16,alpha:32,strategy:'magic'})); assert(validLoRA({rank:8,alpha:16,strategy:'qlora-4bit'}));
console.log("PASS: Unknown strategies are rejected");
}
