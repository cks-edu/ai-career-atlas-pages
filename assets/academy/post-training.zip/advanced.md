## advanced — Controlled tuning comparisons

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Controlled tuning comparisons
Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective.
Mental model: An athlete improving one event may become worse at another.
Boundary: A lower training loss is not proof of improved user outcomes.
Worked example: A tuned model improves formatting but refuses more valid questions. Report both effects and keep the base model as a comparison.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Small-model adaptation with contamination checks
Adapt a small language model for a bounded task and compare it honestly with prompting. Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.
Worked example: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.
Recall: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. Identify one observation that would contradict your claim.

### Terms
Controlled tuning comparisons: Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
GPU: Graphics processing unit: hardware used for many parallel computations; software and memory compatibility matter.
CUDA: NVIDIA GPU programming/runtime ecosystem; compatible hardware, drivers and framework builds are required.
OOM: Out of memory: an allocation exceeds available memory. Inspect allocations and reduce the workload rather than repeatedly retrying unchanged.
tensor: A multidimensional array of values with a shape and data type.

### Lab
Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Adapt a small language model for a bounded task and compare it honestly with prompting. A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build. CPU probe works without a GPU. CUDA, Triton and distributed experiments need compatible hardware/software and can incur rental costs if you choose cloud compute.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+; install the PyTorch build recommended by its official selector for your OS and hardware. The command below is a CPU-capable starting point, not a CUDA compatibility guarantee. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install torch
python tensor_probe.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A bounded tensor correctness/timing probe. It does not implement distributed training, fine-tuning or custom kernels; those are the advanced milestones you build.

2. Prepare the project inputs
Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CUDA unavailable: verify driver/build compatibility; do not label CPU results as GPU tests.
OOM: reduce batch/context size and inspect live allocations.
Unstable timings: warm up, synchronize and isolate other workloads.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop workers and release any rented accelerator after exporting logs. The probe itself exits and releases its tensors.

### Portfolio
Adapt a small language model for a bounded task and compare it honestly with prompting.
Choose a model and dataset with compatible licenses and hardware needs. Create disjoint training, validation and held-out examples grouped by source; record hashes and a baseline prompt.
Run the tensor starter as an environment check, then follow the TRL SFTTrainer guide for the selected model. Begin with a tiny overfit sanity check, explicitly excluded from evaluation.
Train an adapter with a fixed token budget and record base revision, tokenizer, adapter settings and seeds. Save the dataset formatting code and training manifest.
Compare base prompting and the adapted model on the same held-out tasks. Test unrelated general capability and refusal behavior for regressions.
Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.
Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation.
Compare adapter tuning with retrieval augmentation before recommending the more expensive approach.
Deliverables: Adapter training recipe and model card; Split/contamination audit; Base-versus-adapter evaluation report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. A reviewer must reproduce one result and identify which capabilities you implemented. Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.

### Interview
Explain your advanced solution for LLM customization / post-training engineer. Use this scenario: Plant a duplicate held-out example in a copy of training data and verify your contamination scanner catches it before training.
Review: Start with the task and permitted scope. Explain controlled tuning comparisons: Compare a tuned candidate with its base model using fixed tasks, resource budgets and independent evaluation. Inspect regressions beyond the training objective. Show the input and observed output, then address Report task accuracy, unsupported output rate, base-capability regressions and compute. A lower training loss does not establish useful adaptation. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Adapter training recipe and model card; Split/contamination audit; Base-versus-adapter evaluation report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

