# SAMPLE — Adaptation decision and regression report
Role: LLM customization / post-training engineer
Case: The tuned model forgets adjacent tasks
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The adaptation gate flags a capability drop greater than two points on protected regression tasks.

## Evidence table
| Record | regression_drop (percentage points) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 2 | within_demo_bound |
| case-3 | 3 | review |
| case-4 | 8 | review |
| case-5 | 1 | within_demo_bound |

## Finding and reasoning
2/5 cases need review: case-3, case-4.
Two protected tasks regress beyond the declared allowance after tuning.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Hold promotion, inspect the tuning data mix and compare with a strong prompt baseline.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in llm customization / post-training engineer.
Before release: Use separate adaptation and general-capability tests, with provenance and repeated evaluations.

## Design choice and trade-off
Compare tuning against retrieval and prompting; preserve the base model and rollback path.
Specialization can improve target behavior while degrading other capabilities; make that trade-off explicit.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Domain style adapter: Blind review finds gains without hidden evaluation overlap.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
