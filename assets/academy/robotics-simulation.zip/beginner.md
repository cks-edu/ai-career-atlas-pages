## beginner — Coordinate frames and observations

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Coordinate frames and observations
A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion.
Mental model: Directions such as left depend on which way the traveler is facing.
Boundary: A frame error can produce plausible numbers and physically incorrect actions.
Worked example: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Simulation success hides collisions
The simulated task protocol rejects any run with a collision, even if the object reaches its target. Three simulated successes violate the collision condition and cannot count as valid completion. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Make collision and control-limit checks independent of the learned success signal.
Recall: Replay varied friction, sensor noise and latency; keep simulated and hardware evidence distinct. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Coordinate frames and observations: A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
ROS: Robot Operating System: middleware and tools for robotics, with distribution and operating-system requirements.
coordinate: A position described relative to a named frame or coordinate reference system.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A coordinate frame describes where measurements are taken from. A simulator needs explicit movement limits and timing assumptions.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Draw a two-dimensional grid in metres. Place a robot at (0, 0), a goal at (2, 0) and an obstacle at (1, 0).
Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled grid and a simulation-only movement specification.

3. Try step 2
Sketch a route around the obstacle and define a maximum step length and stopping rule.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled grid and a simulation-only movement specification.

4. Try step 3
List assumptions about position accuracy, obstacle size and update timing.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled grid and a simulation-only movement specification.

5. Explain and check your result
The route avoids the stated obstacle under explicit assumptions; it is not used as a physical robot safety plan. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A labeled grid and a simulation-only movement specification. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The simulated task protocol rejects any run with a collision, even if the object reaches its target. Apply this toy-case rule manually: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three simulated successes violate the collision condition and cannot count as valid completion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Robotics simulation & sim-to-real engineering.
Draw a two-dimensional grid in metres. Place a robot at (0, 0), a goal at (2, 0) and an obstacle at (1, 0).
Sketch a route around the obstacle and define a maximum step length and stopping rule.
List assumptions about position accuracy, obstacle size and update timing.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A labeled grid and a simulation-only movement specification. Include beginner-worksheet.md and your completed Simulation test matrix and supervised transfer plan.
Check: The route avoids the stated obstacle under explicit assumptions; it is not used as a physical robot safety plan.

### Interview
Explain your beginner solution for Robotics simulation & sim-to-real engineering. Use this scenario: The simulated task protocol rejects any run with a collision, even if the object reaches its target.
Review: Start with the task and permitted scope. Explain coordinate frames and observations: A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion. Show the input and observed output, then address Make collision and control-limit checks independent of the learned success signal. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A labeled grid and a simulation-only movement specification. Include beginner-worksheet.md and your completed Simulation test matrix and supervised transfer plan.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

