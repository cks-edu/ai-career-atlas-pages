# SAMPLE — Simulation test matrix and supervised transfer plan
Role: Robotics simulation & sim-to-real engineering
Case: Simulation success hides collisions
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The simulated task protocol rejects any run with a collision, even if the object reaches its target.

## Evidence table
| Record | collisions (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 3 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three simulated successes violate the collision condition and cannot count as valid completion.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Make collision and control-limit checks independent of the learned success signal.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in robotics simulation & sim-to-real engineering.
Before release: Replay varied friction, sensor noise and latency; keep simulated and hardware evidence distinct.

## Design choice and trade-off
Evaluate safety and completion separately; stage any physical validation with qualified supervision.
More realistic simulation reduces some gaps but cannot establish safe real-world behavior by itself.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Simulated pick-and-place evaluation: Publish seeds, simulator settings and failure cases.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
