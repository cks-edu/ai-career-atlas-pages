# Robotics simulation & sim-to-real engineering — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Coordinate frames and observations: A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.

ROS: Robot Operating System: middleware and tools for robotics, with distribution and operating-system requirements.

coordinate: A position described relative to a named frame or coordinate reference system.

### Coordinate frames and observations

A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion. In this role, work through: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Directions such as left depend on which way the traveler is facing.

Boundary: A frame error can produce plausible numbers and physically incorrect actions.

Worked example: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: ROS 2 (Open source · supported OS required); Hugging Face robotics course (Public learning material · hardware varies); Python (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Robotics simulation & sim-to-real engineering: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map.

Predict the worked case

Read this case without running a tool: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in coordinate frames and observations.

Connect the concept to the role

Apply this rule: A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A frame error can produce plausible numbers and physically incorrect actions.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies coordinate frames and observations to this case: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Coordinate frames and observations; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with coordinate frames and observations. Use the glossary below, then write your prediction for: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Robotics simulation & sim-to-real engineering role interview. Explain coordinate frames and observations using this case: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate coordinate frames and observations to a system or workflow you know. Explain coordinate frames and observations using this case: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain coordinate frames and observations using this case: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map.

A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion. — A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion. A frame error can produce plausible numbers and physically incorrect actions.

Sources:

ROS 2: https://docs.ros.org/en/jazzy/Tutorials/Beginner-CLI-Tools/Introducing-Turtlesim/Introducing-Turtlesim.html

Hugging Face robotics course: https://huggingface.co/learn/robotics-course/unit0/1

Python: https://docs.python.org/3/library/venv.html

Hugging Face Robotics Course: https://huggingface.co/learn/robotics-course/unit0/1

ROS 2 tutorials: https://docs.ros.org/en/rolling/Tutorials.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Diagnose: Simulation success hides collisions

The simulated task protocol rejects any run with a collision, even if the object reaches its target. Three simulated successes violate the collision condition and cannot count as valid completion. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Make collision and control-limit checks independent of the learned success signal. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Directions such as left depend on which way the traveler is facing.

An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map.

Worked example: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Make collision and control-limit checks independent of the learned success signal.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: ROS 2 (Open source · supported OS required); Hugging Face robotics course (Public learning material · hardware varies); Python (Open source · local)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The simulated task protocol rejects any run with a collision, even if the object reaches its target. Three simulated successes violate the collision condition and cannot count as valid completion. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The simulated task protocol rejects any run with a collision, even if the object reaches its target. Apply this toy-case rule manually: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A coordinate frame describes where measurements are taken from. A simulator needs explicit movement limits and timing assumptions.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Draw a two-dimensional grid in metres. Place a robot at (0, 0), a goal at (2, 0) and an obstacle at (1, 0).

Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled grid and a simulation-only movement specification.

Preparation · Try step 2

Sketch a route around the obstacle and define a maximum step length and stopping rule.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled grid and a simulation-only movement specification.

Preparation · Try step 3

List assumptions about position accuracy, obstacle size and update timing.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled grid and a simulation-only movement specification.

Preparation · Explain and check your result

The route avoids the stated obstacle under explicit assumptions; it is not used as a physical robot safety plan. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A labeled grid and a simulation-only movement specification. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The simulated task protocol rejects any run with a collision, even if the object reaches its target. Apply this toy-case rule manually: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three simulated successes violate the collision condition and cannot count as valid completion. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three simulated successes violate the collision condition and cannot count as valid completion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: simulation success hides collisions. Use the glossary below, then write your prediction for: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Make collision and control-limit checks independent of the learned success signal. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Robotics simulation & sim-to-real engineering role interview. Explain diagnose: simulation success hides collisions using this case: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Make collision and control-limit checks independent of the learned success signal. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: simulation success hides collisions to a system or workflow you know. Explain diagnose: simulation success hides collisions using this case: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Make collision and control-limit checks independent of the learned success signal. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Replay varied friction, sensor noise and latency; keep simulated and hardware evidence distinct. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: simulation success hides collisions using this case: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Make collision and control-limit checks independent of the learned success signal. State the evidence, one alternative and where the mental model stops.

Quiz: Simulation success hides collisions: The simulated task protocol rejects any run with a collision, even if the object reaches its target.

Change the acceptance rule after seeing an inconvenient result.

Make collision and control-limit checks independent of the learned success signal.

Omit failed cases and report only the successful demonstrations.

Reference: Make collision and control-limit checks independent of the learned success signal. — Make collision and control-limit checks independent of the learned success signal. Replay varied friction, sensor noise and latency; keep simulated and hardware evidence distinct.

Sources:

ROS 2: https://docs.ros.org/en/jazzy/Tutorials/Beginner-CLI-Tools/Introducing-Turtlesim/Introducing-Turtlesim.html

Hugging Face robotics course: https://huggingface.co/learn/robotics-course/unit0/1

Python: https://docs.python.org/3/library/venv.html

Hugging Face Robotics Course: https://huggingface.co/learn/robotics-course/unit0/1

ROS 2 tutorials: https://docs.ros.org/en/rolling/Tutorials.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Geometry, control, sensors and robotics software; physical testing needs supervised safety procedures.

Terms:

Simulation experiments: Build a repeatable scene with explicit initial state, physics settings and control inputs. Test a simple controller before adding learning-based behavior.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

ROS: Robot Operating System: middleware and tools for robotics, with distribution and operating-system requirements.

### Simulation experiments

Build a repeatable scene with explicit initial state, physics settings and control inputs. Test a simple controller before adding learning-based behavior. In this role, work through: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A flight simulator lets pilots repeat a maneuver under controlled conditions.

Boundary: Simulation cannot reproduce every sensor, actuator or environmental effect.

Worked example: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Geometry, control, sensors and robotics software; physical testing needs supervised safety procedures.

Tools for this exercise: Document or text editor

Course tool and framework map: ROS 2 (Open source · supported OS required); Hugging Face robotics course (Public learning material · hardware varies); Python (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Robotics simulation & sim-to-real engineering: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts.

Predict the worked case

Read this case without running a tool: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in simulation experiments.

Connect the concept to the role

Apply this rule: Build a repeatable scene with explicit initial state, physics settings and control inputs. Test a simple controller before adding learning-based behavior. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Simulation cannot reproduce every sensor, actuator or environmental effect.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies simulation experiments to this case: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Simulation experiments; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with simulation experiments. Use the glossary below, then write your prediction for: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Robotics simulation & sim-to-real engineering role interview. Explain simulation experiments using this case: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate simulation experiments to a system or workflow you know. Explain simulation experiments using this case: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain simulation experiments using this case: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Reset the same scene and seed, run the controller and compare collision and completion logs across attempts.

Treat a passing starter as proof of the whole role workflow.

Build a repeatable scene with explicit initial state, physics settings and control inputs. Test a simple controller before adding learning-based behavior.

Ignore the failure because the tool produced an output.

Reference: Build a repeatable scene with explicit initial state, physics settings and control inputs. Test a simple controller before adding learning-based behavior. — Build a repeatable scene with explicit initial state, physics settings and control inputs. Test a simple controller before adding learning-based behavior. Simulation cannot reproduce every sensor, actuator or environmental effect.

Sources:

ROS 2: https://docs.ros.org/en/jazzy/Tutorials/Beginner-CLI-Tools/Introducing-Turtlesim/Introducing-Turtlesim.html

Hugging Face robotics course: https://huggingface.co/learn/robotics-course/unit0/1

Python: https://docs.python.org/3/library/venv.html

Hugging Face Robotics Course: https://huggingface.co/learn/robotics-course/unit0/1

ROS 2 tutorials: https://docs.ros.org/en/rolling/Tutorials.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Integrate: Reproducible robot navigation simulation

Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions. In this role, work through: Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.

Role application: A flight simulator lets pilots repeat a maneuver under controlled conditions.

Reset the same scene and seed, run the controller and compare collision and completion logs across attempts.

Worked example: Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.

Setup: Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: ROS 2 (Open source · supported OS required); Hugging Face robotics course (Public learning material · hardware varies); Python (Open source · local)

Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator. Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.

Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
ros2 run turtlesim turtlesim_node
# In a second sourced terminal:
ros2 topic list
ros2 topic echo /turtle1/pose
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator.

Prepare the project inputs

Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Follow the linked ROS installation and turtlesim instructions, launch the node and inspect topics/services. Save the exact distribution and package versions; this source could not be automatically retrieved during authoring.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The simulated task protocol rejects any run with a collision, even if the object reaches its target. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the simulation and recorder with Ctrl+C; save trajectory logs before closing the environment.

Deliverable: lesson-intermediate-2.md: ROS launch/controller package; Scenario and trajectory logs. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: reproducible robot navigation simulation. Use the glossary below, then write your prediction for: Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Robotics simulation & sim-to-real engineering role interview. Explain integrate: reproducible robot navigation simulation using this case: Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: reproducible robot navigation simulation to a system or workflow you know. Explain integrate: reproducible robot navigation simulation using this case: Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. Identify one observation that would contradict your claim.

Interview: Explain integrate: reproducible robot navigation simulation using this case: Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Reproducible robot navigation simulation at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer.

Reference: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. — Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer.

Sources:

ROS 2: https://docs.ros.org/en/jazzy/Tutorials/Beginner-CLI-Tools/Introducing-Turtlesim/Introducing-Turtlesim.html

Hugging Face robotics course: https://huggingface.co/learn/robotics-course/unit0/1

Python: https://docs.python.org/3/library/venv.html

Hugging Face Robotics Course: https://huggingface.co/learn/robotics-course/unit0/1

ROS 2 tutorials: https://docs.ros.org/en/rolling/Tutorials.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Sim-to-real uncertainty: Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

ROS: Robot Operating System: middleware and tools for robotics, with distribution and operating-system requirements.

### Sim-to-real uncertainty

Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step. In this role, work through: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal on a painted stage does not prove footing on a wet outdoor surface.

Boundary: This course does not authorize unattended operation of physical machinery.

Worked example: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: ROS 2 (Open source · supported OS required); Hugging Face robotics course (Public learning material · hardware varies); Python (Open source · local)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Robotics simulation & sim-to-real engineering: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests.

Predict the worked case

Read this case without running a tool: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in sim-to-real uncertainty.

Connect the concept to the role

Apply this rule: Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: This course does not authorize unattended operation of physical machinery.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies sim-to-real uncertainty to this case: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Sim-to-real uncertainty; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with sim-to-real uncertainty. Use the glossary below, then write your prediction for: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Robotics simulation & sim-to-real engineering role interview. Explain sim-to-real uncertainty using this case: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate sim-to-real uncertainty to a system or workflow you know. Explain sim-to-real uncertainty using this case: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain sim-to-real uncertainty using this case: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step.

Reference: Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step. — Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step. This course does not authorize unattended operation of physical machinery.

Sources:

ROS 2: https://docs.ros.org/en/jazzy/Tutorials/Beginner-CLI-Tools/Introducing-Turtlesim/Introducing-Turtlesim.html

Hugging Face robotics course: https://huggingface.co/learn/robotics-course/unit0/1

Python: https://docs.python.org/3/library/venv.html

Hugging Face Robotics Course: https://huggingface.co/learn/robotics-course/unit0/1

ROS 2 tutorials: https://docs.ros.org/en/rolling/Tutorials.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

### Defend: Reproducible robot navigation simulation

Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. Add obstacle or timing scenarios in the chosen simulator and compare a simple baseline with your revised controller. Keep scenario seeds and reset procedures explicit. In this role, work through: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.

Role application: A rehearsal on a painted stage does not prove footing on a wet outdoor surface.

Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests.

Worked example: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.

Setup: Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: ROS 2 (Open source · supported OS required); Hugging Face robotics course (Public learning material · hardware varies); Python (Open source · local)

Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator. Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.

Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
ros2 run turtlesim turtlesim_node
# In a second sourced terminal:
ros2 topic list
ros2 topic echo /turtle1/pose
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator.

Prepare the project inputs

Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Follow the linked ROS installation and turtlesim instructions, launch the node and inspect topics/services. Save the exact distribution and package versions; this source could not be automatically retrieved during authoring.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Add obstacle or timing scenarios in the chosen simulator and compare a simple baseline with your revised controller. Keep scenario seeds and reset procedures explicit.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the simulation and recorder with Ctrl+C; save trajectory logs before closing the environment.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. A reviewer must reproduce one result and identify which capabilities you implemented. Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the simulation and recorder with Ctrl+C; save trajectory logs before closing the environment.

Deliverable: lesson-advanced-2.md: ROS launch/controller package; Scenario and trajectory logs; Simulation report with transfer limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: reproducible robot navigation simulation. Use the glossary below, then write your prediction for: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Robotics simulation & sim-to-real engineering role interview. Explain defend: reproducible robot navigation simulation using this case: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: reproducible robot navigation simulation to a system or workflow you know. Explain defend: reproducible robot navigation simulation using this case: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. Identify one observation that would contradict your claim.

Interview: Explain defend: reproducible robot navigation simulation using this case: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Reproducible robot navigation simulation at this level?

Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware. — Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware. Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer.

Sources:

ROS 2: https://docs.ros.org/en/jazzy/Tutorials/Beginner-CLI-Tools/Introducing-Turtlesim/Introducing-Turtlesim.html

Hugging Face robotics course: https://huggingface.co/learn/robotics-course/unit0/1

Python: https://docs.python.org/3/library/venv.html

Hugging Face Robotics Course: https://huggingface.co/learn/robotics-course/unit0/1

ROS 2 tutorials: https://docs.ros.org/en/rolling/Tutorials.html

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
