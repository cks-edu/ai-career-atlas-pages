## advanced — Sim-to-real uncertainty

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Sim-to-real uncertainty
Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step.
Mental model: A rehearsal on a painted stage does not prove footing on a wet outdoor surface.
Boundary: This course does not authorize unattended operation of physical machinery.
Worked example: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Reproducible robot navigation simulation
Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. Add obstacle or timing scenarios in the chosen simulator and compare a simple baseline with your revised controller. Keep scenario seeds and reset procedures explicit.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.
Worked example: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.
Recall: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. Identify one observation that would contradict your claim.

### Terms
Sim-to-real uncertainty: Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ROS: Robot Operating System: middleware and tools for robotics, with distribution and operating-system requirements.

### Lab
Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator. Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
ros2 run turtlesim turtlesim_node
# In a second sourced terminal:
ros2 topic list
ros2 topic echo /turtle1/pose
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator.

2. Prepare the project inputs
Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Follow the linked ROS installation and turtlesim instructions, launch the node and inspect topics/services. Save the exact distribution and package versions; this source could not be automatically retrieved during authoring.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add obstacle or timing scenarios in the chosen simulator and compare a simple baseline with your revised controller. Keep scenario seeds and reset procedures explicit.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the simulation and recorder with Ctrl+C; save trajectory logs before closing the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
ros2 not found: source the installed distribution environment.
No topics: confirm nodes share the intended ROS domain.
Unstable simulation: inspect update rate and stale observations before tuning control gains.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the simulation and recorder with Ctrl+C; save trajectory logs before closing the environment.

### Portfolio
Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits.
Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.
Follow the linked ROS installation and turtlesim instructions, launch the node and inspect topics/services. Save the exact distribution and package versions; this source could not be automatically retrieved during authoring.
Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions.
Add obstacle or timing scenarios in the chosen simulator and compare a simple baseline with your revised controller. Keep scenario seeds and reset procedures explicit.
Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.
Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer.
Add sensor noise and test whether the same conclusion holds across several seeds before any supervised hardware work.
Deliverables: ROS launch/controller package; Scenario and trajectory logs; Simulation report with transfer limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. A reviewer must reproduce one result and identify which capabilities you implemented. Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.

### Interview
Explain your advanced solution for Robotics simulation & sim-to-real engineering. Use this scenario: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.
Review: Start with the task and permitted scope. Explain sim-to-real uncertainty: Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step. Show the input and observed output, then address Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [ROS launch/controller package; Scenario and trajectory logs; Simulation report with transfer limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

