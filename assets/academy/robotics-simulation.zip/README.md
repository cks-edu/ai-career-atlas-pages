# Robotics simulation & sim-to-real engineering

AI Engineering · Beginner → Intermediate → Advanced

Start with Coordinate frames and observations. A coordinate frame describes where measurements are taken from. A simulator needs explicit movement limits and timing assumptions. Then try Plan a simulated move. The three levels build toward Reproducible robot navigation simulation. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Coordinate frames and observations

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Coordinate frames and observations
A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion.
Mental model: Directions such as left depend on which way the traveler is facing.
Boundary: A frame error can produce plausible numbers and physically incorrect actions.
Worked example: An obstacle at positive x in a camera frame must be transformed before using it in the robot's world map.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Simulation success hides collisions
The simulated task protocol rejects any run with a collision, even if the object reaches its target. Three simulated successes violate the collision condition and cannot count as valid completion. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Make collision and control-limit checks independent of the learned success signal.
Recall: Replay varied friction, sensor noise and latency; keep simulated and hardware evidence distinct. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Coordinate frames and observations: A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
latency: Elapsed time for a defined operation; specify its start and finish before comparing systems.
ROS: Robot Operating System: middleware and tools for robotics, with distribution and operating-system requirements.
coordinate: A position described relative to a named frame or coordinate reference system.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: A coordinate frame describes where measurements are taken from. A simulator needs explicit movement limits and timing assumptions.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Draw a two-dimensional grid in metres. Place a robot at (0, 0), a goal at (2, 0) and an obstacle at (1, 0).
Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled grid and a simulation-only movement specification.

3. Try step 2
Sketch a route around the obstacle and define a maximum step length and stopping rule.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled grid and a simulation-only movement specification.

4. Try step 3
List assumptions about position accuracy, obstacle size and update timing.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A labeled grid and a simulation-only movement specification.

5. Explain and check your result
The route avoids the stated obstacle under explicit assumptions; it is not used as a physical robot safety plan. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A labeled grid and a simulation-only movement specification. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The simulated task protocol rejects any run with a collision, even if the object reaches its target. Apply this toy-case rule manually: Review when collisions >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three simulated successes violate the collision condition and cannot count as valid completion. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Robotics simulation & sim-to-real engineering.
Draw a two-dimensional grid in metres. Place a robot at (0, 0), a goal at (2, 0) and an obstacle at (1, 0).
Sketch a route around the obstacle and define a maximum step length and stopping rule.
List assumptions about position accuracy, obstacle size and update timing.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A labeled grid and a simulation-only movement specification. Include beginner-worksheet.md and your completed Simulation test matrix and supervised transfer plan.
Check: The route avoids the stated obstacle under explicit assumptions; it is not used as a physical robot safety plan.

### Interview
Explain your beginner solution for Robotics simulation & sim-to-real engineering. Use this scenario: The simulated task protocol rejects any run with a collision, even if the object reaches its target.
Review: Start with the task and permitted scope. Explain coordinate frames and observations: A robot interprets measurements relative to coordinate frames and time. Record how sensor, robot and world frames relate before commanding motion. Show the input and observed output, then address Make collision and control-limit checks independent of the learned success signal. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A labeled grid and a simulation-only movement specification. Include beginner-worksheet.md and your completed Simulation test matrix and supervised transfer plan.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Simulation experiments

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Geometry, control, sensors and robotics software; physical testing needs supervised safety procedures.

### Simulation experiments
Build a repeatable scene with explicit initial state, physics settings and control inputs. Test a simple controller before adding learning-based behavior.
Mental model: A flight simulator lets pilots repeat a maneuver under controlled conditions.
Boundary: Simulation cannot reproduce every sensor, actuator or environmental effect.
Worked example: Reset the same scene and seed, run the controller and compare collision and completion logs across attempts.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Reproducible robot navigation simulation
Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.
Worked example: Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.
Recall: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. Identify one observation that would contradict your claim.

### Terms
Simulation experiments: Build a repeatable scene with explicit initial state, physics settings and control inputs. Test a simple controller before adding learning-based behavior.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ROS: Robot Operating System: middleware and tools for robotics, with distribution and operating-system requirements.

### Lab
Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator. Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
ros2 run turtlesim turtlesim_node
# In a second sourced terminal:
ros2 topic list
ros2 topic echo /turtle1/pose
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator.

2. Prepare the project inputs
Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Follow the linked ROS installation and turtlesim instructions, launch the node and inspect topics/services. Save the exact distribution and package versions; this source could not be automatically retrieved during authoring.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The simulated task protocol rejects any run with a collision, even if the object reaches its target. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
ros2 not found: source the installed distribution environment.
No topics: confirm nodes share the intended ROS domain.
Unstable simulation: inspect update rate and stale observations before tuning control gains.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the simulation and recorder with Ctrl+C; save trajectory logs before closing the environment.

### Portfolio
Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits.
Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.
Follow the linked ROS installation and turtlesim instructions, launch the node and inspect topics/services. Save the exact distribution and package versions; this source could not be automatically retrieved during authoring.
Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions.
Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer.
Deliverables: ROS launch/controller package; Scenario and trajectory logs. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Robotics simulation & sim-to-real engineering. Use this scenario: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.
Review: Start with the task and permitted scope. Explain simulation experiments: Build a repeatable scene with explicit initial state, physics settings and control inputs. Test a simple controller before adding learning-based behavior. Show the input and observed output, then address Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [ROS launch/controller package; Scenario and trajectory logs. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Sim-to-real uncertainty

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Sim-to-real uncertainty
Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step.
Mental model: A rehearsal on a painted stage does not prove footing on a wet outdoor surface.
Boundary: This course does not authorize unattended operation of physical machinery.
Worked example: Vary friction and sensor noise in simulation; record failure regions and propose bounded supervised hardware tests.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Reproducible robot navigation simulation
Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. Add obstacle or timing scenarios in the chosen simulator and compare a simple baseline with your revised controller. Keep scenario seeds and reset procedures explicit.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.
Worked example: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.
Recall: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. Identify one observation that would contradict your claim.

### Terms
Sim-to-real uncertainty: Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
ROS: Robot Operating System: middleware and tools for robotics, with distribution and operating-system requirements.

### Lab
Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits. A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator. Requires the ROS-supported OS/container setup. The linked ROS page blocked automated retrieval during authoring; confirm commands against installed help. No real robot is controlled.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install ROS 2 and turtlesim for a supported distribution using official instructions. Commands assume the ROS environment has already been sourced. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
ros2 run turtlesim turtlesim_node
# In a second sourced terminal:
ros2 topic list
ros2 topic echo /turtle1/pose
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A simulation experiment worksheet and launch recipe. No controller, robot model or sim-to-real validation is bundled; implement these against the chosen simulator.

2. Prepare the project inputs
Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Follow the linked ROS installation and turtlesim instructions, launch the node and inspect topics/services. Save the exact distribution and package versions; this source could not be automatically retrieved during authoring.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Add obstacle or timing scenarios in the chosen simulator and compare a simple baseline with your revised controller. Keep scenario seeds and reset procedures explicit.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the simulation and recorder with Ctrl+C; save trajectory logs before closing the environment.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
ros2 not found: source the installed distribution environment.
No topics: confirm nodes share the intended ROS domain.
Unstable simulation: inspect update rate and stale observations before tuning control gains.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the simulation and recorder with Ctrl+C; save trajectory logs before closing the environment.

### Portfolio
Build a bounded simulation experiment with observable state, repeatable scenarios and explicit sim-to-real limits.
Use a supported ROS 2 distribution in its recommended environment. Begin with turtlesim, then choose a simulator and robot model whose version and license you can reproduce.
Follow the linked ROS installation and turtlesim instructions, launch the node and inspect topics/services. Save the exact distribution and package versions; this source could not be automatically retrieved during authoring.
Implement a controller that publishes bounded velocity commands and stops on stale observations. Record trajectories and controller settings for three initial conditions.
Add obstacle or timing scenarios in the chosen simulator and compare a simple baseline with your revised controller. Keep scenario seeds and reset procedures explicit.
Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.
Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer.
Add sensor noise and test whether the same conclusion holds across several seeds before any supervised hardware work.
Deliverables: ROS launch/controller package; Scenario and trajectory logs; Simulation report with transfer limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. A reviewer must reproduce one result and identify which capabilities you implemented. Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.

### Interview
Explain your advanced solution for Robotics simulation & sim-to-real engineering. Use this scenario: Delay observations and interrupt command delivery in simulation. Demonstrate a stop condition and recovery; do not transfer unvalidated commands to real hardware.
Review: Start with the task and permitted scope. Explain sim-to-real uncertainty: Vary plausible conditions and document which assumptions need hardware validation. Treat transfer as an experiment with safety review rather than an automatic deployment step. Show the input and observed output, then address Report collisions, goal success, path length and recovery by scenario. Simulation success does not establish real-world safety or sim-to-real transfer. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [ROS launch/controller package; Scenario and trajectory logs; Simulation report with transfer limitations. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
ROS 2 — Open source · supported OS required
Simulation topics/services. Automated source retrieval was blocked; verify commands against your installed distribution.
Alternative: A standalone Python state-machine simulation can teach foundations; commercial robotics simulators and hardware require their own validation.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Hugging Face robotics course — Public learning material · hardware varies
Robotics concepts and simulation-to-hardware limitations.
Alternative: ROS 2 official tutorials provide another learning route; select according to supported OS and whether hardware is actually needed.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Python — Open source · local
Isolated environments and reproducible scripts.
Alternative: A spreadsheet for manual evidence exercises, or another supported programming language for implementation; reproduce the same acceptance checks.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
ROS 2: https://docs.ros.org/en/jazzy/Tutorials/Beginner-CLI-Tools/Introducing-Turtlesim/Introducing-Turtlesim.html
Hugging Face robotics course: https://huggingface.co/learn/robotics-course/unit0/1
Python: https://docs.python.org/3/library/venv.html
Hugging Face Robotics Course: https://huggingface.co/learn/robotics-course/unit0/1
ROS 2 tutorials: https://docs.ros.org/en/rolling/Tutorials.html
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
