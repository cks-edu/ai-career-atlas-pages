## advanced — Product outcome guardrails

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Product outcome guardrails
Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement.
Mental model: A busy help desk is not necessarily a helpful help desk.
Boundary: Exploratory usability observations do not establish a causal business uplift.
Worked example: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Review-and-approve writing workspace
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.
Recall: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. Identify one observation that would contradict your claim.

### Terms
Product outcome guardrails: Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text.
Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.
Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.
Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.
Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion.
Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.
Add authenticated workspaces and server-side authorization; test one user attempting to read another user’s document.
Deliverables: Interactive prototype and application demo; Revision model and state-transition diagram; Accessibility and stale-response test report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. A reviewer must reproduce one result and identify which capabilities you implemented. Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

### Interview
Explain your advanced solution for AI product / full-stack engineer. Use this scenario: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.
Review: Start with the task and permitted scope. Explain product outcome guardrails: Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement. Show the input and observed output, then address Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Interactive prototype and application demo; Revision model and state-transition diagram; Accessibility and stale-response test report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

