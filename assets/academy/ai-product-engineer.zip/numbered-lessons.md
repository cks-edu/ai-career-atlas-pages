# AI product / full-stack engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Visible AI interaction states: Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Visible AI interaction states

Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over. In this role, work through: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A parcel tracker distinguishes accepted, in transit and delivered.

Boundary: A polished interface cannot establish the quality of a generated answer.

Worked example: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI product / full-stack engineer: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete.

Predict the worked case

Read this case without running a tool: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in visible ai interaction states.

Connect the concept to the role

Apply this rule: Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A polished interface cannot establish the quality of a generated answer.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies visible ai interaction states to this case: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Visible AI interaction states; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with visible ai interaction states. Use the glossary below, then write your prediction for: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product / full-stack engineer role interview. Explain visible ai interaction states using this case: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate visible ai interaction states to a system or workflow you know. Explain visible ai interaction states using this case: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain visible ai interaction states using this case: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete.

Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over. — Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over. A polished interface cannot establish the quality of a generated answer.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: https://docs.github.com/en/actions

### Diagnose: Cancellation that users cannot trust

A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Three cancelled sessions still append text, so the visible interface disagrees with user intent. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Reject chunks with a cancelled request ID and reconcile server cancellation separately. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A parcel tracker distinguishes accepted, in transit and delivered.

Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete.

Worked example: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Reject chunks with a cancelled request ID and reconcile server cancellation separately.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: FastAPI (Open source · local); Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Three cancelled sessions still append text, so the visible interface disagrees with user intent. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Apply this toy-case rule manually: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An AI answer may take time, fail or need correction. Design these states before building the full interface.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Choose a fictional study assistant that answers a question from class notes.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Four annotated screen sketches on paper or in a document.

Preparation · Try step 2

Sketch four versions of its screen: waiting, answer ready, request failed and answer being edited.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Four annotated screen sketches on paper or in a document.

Preparation · Try step 3

Add a clearly labeled action to each screen, including cancel, retry or edit where appropriate.

Expected: Record the input, your reasoning and the resulting part of this deliverable: Four annotated screen sketches on paper or in a document.

Preparation · Explain and check your result

A learner can stop waiting, recover from an error and correct an answer without losing their question. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: Four annotated screen sketches on paper or in a document. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Apply this toy-case rule manually: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three cancelled sessions still append text, so the visible interface disagrees with user intent. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three cancelled sessions still append text, so the visible interface disagrees with user intent. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: cancellation that users cannot trust. Use the glossary below, then write your prediction for: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Reject chunks with a cancelled request ID and reconcile server cancellation separately. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product / full-stack engineer role interview. Explain diagnose: cancellation that users cannot trust using this case: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Reject chunks with a cancelled request ID and reconcile server cancellation separately. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: cancellation that users cannot trust to a system or workflow you know. Explain diagnose: cancellation that users cannot trust using this case: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Reject chunks with a cancelled request ID and reconcile server cancellation separately. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Replay normal completion, cancel, late arrival and retry with a new request ID. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: cancellation that users cannot trust using this case: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Reject chunks with a cancelled request ID and reconcile server cancellation separately. State the evidence, one alternative and where the mental model stops.

Quiz: Cancellation that users cannot trust: A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk.

Change the acceptance rule after seeing an inconvenient result.

Reject chunks with a cancelled request ID and reconcile server cancellation separately.

Omit failed cases and report only the successful demonstrations.

Reference: Reject chunks with a cancelled request ID and reconcile server cancellation separately. — Reject chunks with a cancelled request ID and reconcile server cancellation separately. Replay normal completion, cancel, late arrival and retry with a new request ID.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: https://docs.github.com/en/actions

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Web application fundamentals, authentication, persistent state and user-focused debugging.

Terms:

End-to-end acceptance contracts: Connect the interface's promise to the server's behavior and a test. Include cancellation, validation and accessibility when deciding whether a feature works for a person.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### End-to-end acceptance contracts

Connect the interface's promise to the server's behavior and a test. Include cancellation, validation and accessibility when deciding whether a feature works for a person. In this role, work through: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Trace one order from the menu to the kitchen and back to the diner.

Boundary: Stopping UI updates does not always cancel work already running on a remote service.

Worked example: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Web application fundamentals, authentication, persistent state and user-focused debugging.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI product / full-stack engineer: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft.

Predict the worked case

Read this case without running a tool: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in end-to-end acceptance contracts.

Connect the concept to the role

Apply this rule: Connect the interface's promise to the server's behavior and a test. Include cancellation, validation and accessibility when deciding whether a feature works for a person. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Stopping UI updates does not always cancel work already running on a remote service.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies end-to-end acceptance contracts to this case: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for End-to-end acceptance contracts; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with end-to-end acceptance contracts. Use the glossary below, then write your prediction for: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product / full-stack engineer role interview. Explain end-to-end acceptance contracts using this case: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate end-to-end acceptance contracts to a system or workflow you know. Explain end-to-end acceptance contracts using this case: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain end-to-end acceptance contracts using this case: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft.

Treat a passing starter as proof of the whole role workflow.

Connect the interface's promise to the server's behavior and a test. Include cancellation, validation and accessibility when deciding whether a feature works for a person.

Ignore the failure because the tool produced an output.

Reference: Connect the interface's promise to the server's behavior and a test. Include cancellation, validation and accessibility when deciding whether a feature works for a person. — Connect the interface's promise to the server's behavior and a test. Include cancellation, validation and accessibility when deciding whether a feature works for a person. Stopping UI updates does not always cancel work already running on a remote service.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: https://docs.github.com/en/actions

### Integrate: Review-and-approve writing workspace

Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API. In this role, work through: Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: Trace one order from the menu to the kitchen and back to the diner.

Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft.

Worked example: Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance)

Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build an AI editing experience where users can inspect a diff, reject changes and recover their original text.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-intermediate-2.md: Interactive prototype and application demo; Revision model and state-transition diagram. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: review-and-approve writing workspace. Use the glossary below, then write your prediction for: Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product / full-stack engineer role interview. Explain integrate: review-and-approve writing workspace using this case: Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: review-and-approve writing workspace to a system or workflow you know. Explain integrate: review-and-approve writing workspace using this case: Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. Identify one observation that would contradict your claim.

Interview: Explain integrate: review-and-approve writing workspace using this case: Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Review-and-approve writing workspace at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.

Reference: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. — Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: https://docs.github.com/en/actions

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Product outcome guardrails: Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement.

API: Application programming interface: the agreed way one program requests work or data from another.

HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.

JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.

schema: A specification of fields, types and constraints expected in structured data.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Product outcome guardrails

Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement. In this role, work through: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A busy help desk is not necessarily a helpful help desk.

Boundary: Exploratory usability observations do not establish a causal business uplift.

Worked example: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: FastAPI (Open source · local); Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI product / full-stack engineer: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value.

Predict the worked case

Read this case without running a tool: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in product outcome guardrails.

Connect the concept to the role

Apply this rule: Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Exploratory usability observations do not establish a causal business uplift.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies product outcome guardrails to this case: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Product outcome guardrails; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with product outcome guardrails. Use the glossary below, then write your prediction for: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product / full-stack engineer role interview. Explain product outcome guardrails using this case: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate product outcome guardrails to a system or workflow you know. Explain product outcome guardrails using this case: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain product outcome guardrails using this case: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement.

Reference: Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement. — Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement. Exploratory usability observations do not establish a causal business uplift.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: https://docs.github.com/en/actions

### Defend: Review-and-approve writing workspace

Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion. In this role, work through: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Role application: A busy help desk is not necessarily a helpful help desk.

Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value.

Worked example: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

Setup: Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: FastAPI (Open source · local); Penpot (Open source · hosted account or self-hosting); W3C WAI checks (Public guidance)

Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

Build an AI editing experience where users can inspect a diff, reject changes and recover their original text.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

Prepare the project inputs

Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Optional runtime probes after prerequisite setup

Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.

```
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Expected: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. A reviewer must reproduce one result and identify which capabilities you implemented. Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Deliverable: lesson-advanced-2.md: Interactive prototype and application demo; Revision model and state-transition diagram; Accessibility and stale-response test report. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: review-and-approve writing workspace. Use the glossary below, then write your prediction for: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI product / full-stack engineer role interview. Explain defend: review-and-approve writing workspace using this case: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: review-and-approve writing workspace to a system or workflow you know. Explain defend: review-and-approve writing workspace using this case: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. Identify one observation that would contradict your claim.

Interview: Explain defend: review-and-approve writing workspace using this case: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Review-and-approve writing workspace at this level?

Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original. — Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original. Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.

Sources:

FastAPI: https://fastapi.tiangolo.com/tutorial/

Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/

W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/

Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction

W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: https://docs.github.com/en/actions
