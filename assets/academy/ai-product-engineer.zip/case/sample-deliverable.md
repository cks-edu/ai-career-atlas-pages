# SAMPLE — UI state specification and cancellation test report
Role: AI product / full-stack engineer
Case: Cancellation that users cannot trust
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk.

## Evidence table
| Record | chunks_after_cancel (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 4 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 1 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three cancelled sessions still append text, so the visible interface disagrees with user intent.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Reject chunks with a cancelled request ID and reconcile server cancellation separately.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai product / full-stack engineer.
Before release: Replay normal completion, cancel, late arrival and retry with a new request ID.

## Design choice and trade-off
Model loading, streaming, cancelled and failed states explicitly; associate chunks with request identity.
Discarding stale UI chunks protects interaction but may not stop provider billing; measure both boundaries.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
AI document workspace: Edits survive reload and users can distinguish drafts from approved text.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
