# Review-and-approve writing workspace

Career: AI product / full-stack engineer
Reviewed: 2026-10-22

Build an AI editing experience where users can inspect a diff, reject changes and recover their original text.

## Prerequisites
Web application fundamentals, authentication, persistent state and user-focused debugging.

## Included starter versus your implementation
FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Additional tool commands
Run only after the relevant tool/data setup above.

```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```

## Portfolio deliverables
1. Interactive prototype and application demo — artifact-1.md
2. Revision model and state-transition diagram — artifact-2.md
3. Accessibility and stale-response test report — artifact-3.md

## Troubleshooting
- Port occupied: select an unused local port and update client URLs.
- 422 response: inspect the request JSON and schema.
- Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.

## Extension
Add authenticated workspaces and server-side authorization; test one user attempting to read another user’s document.

## Primary learning resources
- FastAPI: https://fastapi.tiangolo.com/tutorial/ — Open source · local; Typed API, validation and local service tests.
- Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/ — Open source · hosted account or self-hosting; Connect prototype boards and test interaction flows; Figma is an alternative.
- W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/ — Public guidance; Manual accessibility checks; preliminary checks are not full conformance assessment.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
