# Interactive prototype and application demo

Project: Review-and-approve writing workspace
Status: blank work product — not completed evidence

## Purpose and audience
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text.

## Required content
Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.

## Failure evidence
Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
