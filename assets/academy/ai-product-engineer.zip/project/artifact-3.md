# Accessibility and stale-response test report

Project: Review-and-approve writing workspace
Status: blank work product — not completed evidence

## Purpose and audience
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text.

## Required content
Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.

## Failure evidence
Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
