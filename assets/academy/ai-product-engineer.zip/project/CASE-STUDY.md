# Review-and-approve writing workspace

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

## Limitations and next iteration
Add authenticated workspaces and server-side authorization; test one user attempting to read another user’s document.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
