## beginner — Visible AI interaction states

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Visible AI interaction states
Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over.
Mental model: A parcel tracker distinguishes accepted, in transit and delivered.
Boundary: A polished interface cannot establish the quality of a generated answer.
Worked example: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Cancellation that users cannot trust
A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Three cancelled sessions still append text, so the visible interface disagrees with user intent. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Reject chunks with a cancelled request ID and reconcile server cancellation separately.
Recall: Replay normal completion, cancel, late arrival and retry with a new request ID. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Visible AI interaction states: Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An AI answer may take time, fail or need correction. Design these states before building the full interface.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose a fictional study assistant that answers a question from class notes.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Four annotated screen sketches on paper or in a document.

3. Try step 2
Sketch four versions of its screen: waiting, answer ready, request failed and answer being edited.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Four annotated screen sketches on paper or in a document.

4. Try step 3
Add a clearly labeled action to each screen, including cancel, retry or edit where appropriate.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Four annotated screen sketches on paper or in a document.

5. Explain and check your result
A learner can stop waiting, recover from an error and correct an answer without losing their question. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Four annotated screen sketches on paper or in a document. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Apply this toy-case rule manually: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three cancelled sessions still append text, so the visible interface disagrees with user intent. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI product / full-stack engineer.
Choose a fictional study assistant that answers a question from class notes.
Sketch four versions of its screen: waiting, answer ready, request failed and answer being edited.
Add a clearly labeled action to each screen, including cancel, retry or edit where appropriate.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Four annotated screen sketches on paper or in a document. Include beginner-worksheet.md and your completed UI state specification and cancellation test report.
Check: A learner can stop waiting, recover from an error and correct an answer without losing their question.

### Interview
Explain your beginner solution for AI product / full-stack engineer. Use this scenario: A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk.
Review: Start with the task and permitted scope. Explain visible ai interaction states: Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over. Show the input and observed output, then address Reject chunks with a cancelled request ID and reconcile server cancellation separately. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Four annotated screen sketches on paper or in a document. Include beginner-worksheet.md and your completed UI state specification and cancellation test report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

