# AI product / full-stack engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Visible AI interaction states. An AI answer may take time, fail or need correction. Design these states before building the full interface. Then try Sketch an answer screen. The three levels build toward Review-and-approve writing workspace. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Visible AI interaction states

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Visible AI interaction states
Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over.
Mental model: A parcel tracker distinguishes accepted, in transit and delivered.
Boundary: A polished interface cannot establish the quality of a generated answer.
Worked example: Draft text remains after a timeout; the interface shows Retry and Edit rather than an empty answer labeled complete.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Cancellation that users cannot trust
A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Three cancelled sessions still append text, so the visible interface disagrees with user intent. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Reject chunks with a cancelled request ID and reconcile server cancellation separately.
Recall: Replay normal completion, cancel, late arrival and retry with a new request ID. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Visible AI interaction states: Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: An AI answer may take time, fail or need correction. Design these states before building the full interface.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Choose a fictional study assistant that answers a question from class notes.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Four annotated screen sketches on paper or in a document.

3. Try step 2
Sketch four versions of its screen: waiting, answer ready, request failed and answer being edited.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Four annotated screen sketches on paper or in a document.

4. Try step 3
Add a clearly labeled action to each screen, including cancel, retry or edit where appropriate.
Expected: Record the input, your reasoning and the resulting part of this deliverable: Four annotated screen sketches on paper or in a document.

5. Explain and check your result
A learner can stop waiting, recover from an error and correct an answer without losing their question. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: Four annotated screen sketches on paper or in a document. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Apply this toy-case rule manually: Review when chunks_after_cancel >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three cancelled sessions still append text, so the visible interface disagrees with user intent. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI product / full-stack engineer.
Choose a fictional study assistant that answers a question from class notes.
Sketch four versions of its screen: waiting, answer ready, request failed and answer being edited.
Add a clearly labeled action to each screen, including cancel, retry or edit where appropriate.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: Four annotated screen sketches on paper or in a document. Include beginner-worksheet.md and your completed UI state specification and cancellation test report.
Check: A learner can stop waiting, recover from an error and correct an answer without losing their question.

### Interview
Explain your beginner solution for AI product / full-stack engineer. Use this scenario: A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk.
Review: Start with the task and permitted scope. Explain visible ai interaction states: Show pending, successful, uncertain and failed states explicitly. Preserve the user's input while a request is running so that a failure does not force them to start over. Show the input and observed output, then address Reject chunks with a cancelled request ID and reconcile server cancellation separately. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Four annotated screen sketches on paper or in a document. Include beginner-worksheet.md and your completed UI state specification and cancellation test report.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — End-to-end acceptance contracts

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Web application fundamentals, authentication, persistent state and user-focused debugging.

### End-to-end acceptance contracts
Connect the interface's promise to the server's behavior and a test. Include cancellation, validation and accessibility when deciding whether a feature works for a person.
Mental model: Trace one order from the menu to the kitchen and back to the diner.
Boundary: Stopping UI updates does not always cancel work already running on a remote service.
Worked example: Submitting a blank request produces a readable error and zero model calls. Canceling a request prevents a late response from replacing a newer draft.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Review-and-approve writing workspace
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.
Recall: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. Identify one observation that would contradict your claim.

### Terms
End-to-end acceptance contracts: Connect the interface's promise to the server's behavior and a test. Include cancellation, validation and accessibility when deciding whether a feature works for a person.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
A draft editor contract requires cancelled sessions to discard every subsequent streamed chunk. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

7. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text.
Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.
Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.
Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.
Deliverables: Interactive prototype and application demo; Revision model and state-transition diagram. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI product / full-stack engineer. Use this scenario: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.
Review: Start with the task and permitted scope. Explain end-to-end acceptance contracts: Connect the interface's promise to the server's behavior and a test. Include cancellation, validation and accessibility when deciding whether a feature works for a person. Show the input and observed output, then address Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Interactive prototype and application demo; Revision model and state-transition diagram. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Product outcome guardrails

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Product outcome guardrails
Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement.
Mental model: A busy help desk is not necessarily a helpful help desk.
Boundary: Exploratory usability observations do not establish a causal business uplift.
Worked example: Ten users open the assistant but four cannot complete the task. Investigate those failures before claiming adoption proves value.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Review-and-approve writing workspace
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.
Worked example: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.
Recall: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. Identify one observation that would contradict your claim.

### Terms
Product outcome guardrails: Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement.
API: Application programming interface: the agreed way one program requests work or data from another.
HTTP: The web request/response protocol. Its status code describes transport/application handling, not whether a model answer is true.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
schema: A specification of fields, types and constraints expected in structured data.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text. FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration. CPU service starts locally. Ollama/model downloads need additional RAM, disk and a separately checked license. No paid API is required for the baseline.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ in a new extracted project folder. Install packages in a virtual environment; a local model is optional until the generation milestone. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m unittest -v
python -m uvicorn app:app --host 127.0.0.1 --port 8010
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: FastAPI service, four tests and an Ollama probe. /propose returns a deterministic text excerpt, always marked for review. You implement the project-specific workflow and model integration.

2. Prepare the project inputs
Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

9. Optional runtime probes after prerequisite setup
Read project/PROJECT.md before these commands. Run only after the relevant local server/model/runtime is configured. In a second terminal, enter the extracted project/ directory and activate its environment. Placeholder model names must be replaced with an installed, permitted model.
```sh
# After installing Ollama and pulling a suitable model:
# export OLLAMA_MODEL=your-installed-model
python model_probe.py
# In another terminal while the API is running:
curl -s http://127.0.0.1:8010/health
curl -s http://127.0.0.1:8010/propose -H 'Content-Type: application/json' -d '{"text":"Review this fictional ticket"}'
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Save the actual response or error. A missing model or unavailable server is incomplete execution, not a pass.

Troubleshooting:
Port occupied: select an unused local port and update client URLs.
422 response: inspect the request JSON and schema.
Model probe fails: check Ollama is running and OLLAMA_MODEL matches an installed model.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Stop the local server with Ctrl+C; deactivate the virtual environment. Stop Ollama/model processes when finished.

### Portfolio
Build an AI editing experience where users can inspect a diff, reject changes and recover their original text.
Write twelve short documents with protected names, dates and code fragments. Create tasks for summarize, shorten and correct style; define what must remain unchanged.
Start the API starter, add document and revision IDs, and store originals in SQLite. Return an explicit proposed revision instead of overwriting the source.
Create five Penpot boards: input, generating, proposed diff, accepted and failed. Link approve, reject and undo transitions. Implement the same flow in a small HTML client calling the local API.
Connect model_probe.py through the API and render the response as text, never raw HTML. Cancel in-flight requests when the document revision changes; preserve keyboard focus and announce completion.
Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.
Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such.
Add authenticated workspaces and server-side authorization; test one user attempting to read another user’s document.
Deliverables: Interactive prototype and application demo; Revision model and state-transition diagram; Accessibility and stale-response test report. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. A reviewer must reproduce one result and identify which capabilities you implemented. Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.

### Interview
Explain your advanced solution for AI product / full-stack engineer. Use this scenario: Edit the source while a generation is running, then return the old response. It must be identified as stale; an undo after acceptance restores the exact original.
Review: Start with the task and permitted scope. Explain product outcome guardrails: Compare successful user tasks with the extra effort and errors introduced by AI. Define a hold condition before launch and measure it alongside engagement. Show the input and observed output, then address Test all twelve documents, keyboard-only navigation and one screen reader. Record preservation errors, undo success and task completion separately; label solo walkthroughs as such. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Interactive prototype and application demo; Revision model and state-transition diagram; Accessibility and stale-response test report. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
FastAPI — Open source · local
Typed API, validation and local service tests.
Alternative: Django REST Framework (open source); compare validation, async support and existing team skills.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Penpot — Open source · hosted account or self-hosting
Connect prototype boards and test interaction flows; Figma is an alternative.
Alternative: Figma (commercial hosted service with plan-specific access); paper prototypes are sufficient for the first exercise.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

W3C WAI checks — Public guidance
Manual accessibility checks; preliminary checks are not full conformance assessment.
Alternative: Use manual keyboard and assistive-technology checks alongside axe-core (open source); automated tests do not replace WAI guidance or user testing.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
FastAPI: https://fastapi.tiangolo.com/tutorial/
Penpot: https://help.penpot.app/user-guide/prototyping-testing/prototyping/
W3C WAI checks: https://www.w3.org/WAI/test-evaluate/preliminary/
Hugging Face Agents Course: https://huggingface.co/learn/agents-course/unit0/introduction
W3C Web Accessibility Tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: https://docs.github.com/en/actions
