# Fictional worked example — not actual approval

Decision: HOLD. HCM and reporting cases have passed in the fictional register; payroll impact is not tested. Ask the payroll process owner to define and execute the affected UAT case in the authorized training environment. Record the observation and reviewer before reconsidering release. Verify in-flight cases and the recovery procedure. Do not replace missing evidence with an assumed pass.

Your deliverable: fill the observed/evidence columns in uat-cases.csv. For a tabletop, write simulated reasoning rather than claiming tenant execution.
