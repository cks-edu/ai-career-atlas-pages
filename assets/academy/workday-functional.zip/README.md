# Workday HCM / Functional Analyst

Software Engineering

Begin with acceptance criteria. Map a fictional hire-to-onboard business process and approval ownership. Use the shared foundation exercise first, then complete your role-specific extension. Each level is a guided learning module, not a claim of complete professional readiness.

## beginner

Map a fictional hire-to-onboard business process and approval ownership

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Business process and roles
Define who initiates, approves, reviews and completes a process. A process name is not enough to establish ownership.
Mental model: A relay has named handoffs and a rule for who may accept the baton.
Limit: Workday roles and configuration require authorized platform access; the workbook is a simulation.
Example: Map a fictional onboarding request and a manager approval with a backup reviewer.
Recall: Which change would require a different approver?

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Apply the role exercise
Map a fictional hire-to-onboard business process and approval ownership
Expected: A role-specific artifact linked to a requirement and at least one test.

4. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: workday-functional-beginner/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Map a fictional hire-to-onboard business process and approval ownership? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Describe an observable result that determines whether a requirement has been met. For this role, explicitly address: Map a fictional hire-to-onboard business process and approval ownership.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## intermediate

Write five acceptance cases including missing data and an unauthorized approver

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Effective-dated configuration
Distinguish when a decision is made from when its business effect begins, and test future, current and corrected cases.
Mental model: A timetable can contain changes that have been announced but have not started.
Limit: Tenant-specific rules determine correction behavior and available actions.
Example: Test a future transfer, an immediate transfer and a corrected department value.
Recall: What should a report show before the transfer takes effect?

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Apply the role exercise
Write five acceptance cases including missing data and an unauthorized approver
Expected: A role-specific artifact linked to a requirement and at least one test.

4. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: workday-functional-intermediate/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Write five acceptance cases including missing data and an unauthorized approver? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Connect a user need to the proposed change, its test and its evidence. For this role, explicitly address: Write five acceptance cases including missing data and an unauthorized approver.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## advanced

Prepare a change-impact, access-review and release-signoff workbook

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Change impact and signoff
A configuration change can affect reporting, integrations, access and downstream business processes. Trace affected cases before signoff.
Mental model: Change one junction on a route map and check every route passing through it.
Limit: A completed checklist does not replace accountable stakeholder review.
Example: Link a changed approval rule to affected roles, tests and integration consumers.
Recall: What evidence would cause you to hold the release?

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Apply the role exercise
Prepare a change-impact, access-review and release-signoff workbook
Expected: A role-specific artifact linked to a requirement and at least one test.

4. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: workday-functional-advanced/ with README, code or decision workbook, test table, source links and evidence.
A reader can follow setup, reproduce at least one normal and one failure case, and see your contribution. Include the role-specific extension; running only the shared reference is insufficient.

Interview: How would you complete this task: Prepare a change-impact, access-review and release-signoff workbook? Include a failure and a recovery or review step.
Review criteria: A strong answer identifies the user outcome, input and state, relevant boundary, alternative, observable success check and remaining uncertainty. Apply this concept: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. For this role, explicitly address: Prepare a change-impact, access-review and release-signoff workbook.

Resume: Built / evaluated [specific artifact] for [synthetic scenario], verified [observed result and test conditions], and documented [failure, recovery and limitation]. Learning project: [link].

## Official sources
Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
SAP Learning Journeys: https://learning.sap.com/learning-journeys
