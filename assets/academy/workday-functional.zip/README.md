# Workday HCM / Functional Analyst

Software Engineering

Start with business process ownership. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward functional change pack with UAT, impact analysis and proposed signoff.

## beginner

Read the process fixture and complete the supplied decision table manually. Run the optional beginner checker, then draw initiation → data check → manager approval → onboarding and name each owner.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Business process ownership
A functional analyst defines who initiates, approves and completes a process and what evidence is required. The lab's fictional hire policy prevents self-approval and requires a manager and department; real tenant rules must be confirmed.
Mental model: A relay has named handoffs and rules for who may accept the baton.
Limit: A process diagram without actors cannot establish accountability; name roles at each handoff.
Example: Hire h1 has complete data; h2 has no manager and must stop before approval.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A process diagram without actors cannot establish accountability; name roles at each handoff.

1. Inspect the business fixture
Open uat-cases.csv in a spreadsheet or text editor. Keep observed and evidence columns blank until you execute or reason through each case. Read sample-signoff.md as a fictional worked example after your own decision. Hire h1 has complete data; h2 has no manager and must stop before approval.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Read the process fixture and complete the supplied decision table manually. Run the optional beginner checker, then draw initiation → data check → manager approval → onboarding and name each owner.
```
python3 enterprise_lab.py beginner
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: h1 is eligible for review; h2 is rejected with missing-manager reason.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py beginner --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Prepare the tenant-independent UAT pack
Fill role, required data, effective date, approval and expected result columns for h1 and h2. Use expected.json as a sample answer after making your own decision. Select an appropriate Workday learning route; configuration requires the authorized tenant’s current instructions.
Expected: A complete manual deliverable works without Python or a tenant.

6. Assemble the portfolio evidence
Create hire-process map and sample completed acceptance table. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: h1 is eligible for review; h2 is rejected with missing-manager reason.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: A process diagram without actors cannot establish accountability; name roles at each handoff.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: hire-process map and sample completed acceptance table
h1 is eligible for review; h2 is rejected with missing-manager reason.

Interview: Work through this Workday HCM / Functional Analyst case: Hire h1 has complete data; h2 has no manager and must stop before approval. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A functional analyst defines who initiates, approves and completes a process and what evidence is required. The lab's fictional hire policy prevents self-approval and requires a manager and department; real tenant rules must be confirmed. Expected evidence: h1 is eligible for review; h2 is rejected with missing-manager reason. Diagnosis: A process diagram without actors cannot establish accountability; name roles at each handoff. State the limits of the mental model: A relay has named handoffs and rules for who may accept the baton.

Resume: Built hire-process map and sample completed acceptance table using Workday business processes and reporting; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Run intermediate or evaluate the decision table by hand. Test requester, assigned manager and unrelated manager, then compare the current/future transfer snapshots.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Approval and effective-date cases
Approval authority and business-effective time answer different questions. A completed approval may authorize a future change without making it current immediately.
Mental model: A signed future appointment is authorized now but begins on its scheduled day.
Limit: Testing only with an administrator masks role-routing defects; use the intended actors in an authorized tenant.
Example: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Testing only with an administrator masks role-routing defects; use the intended actors in an authorized tenant.

1. Inspect the business fixture
Open uat-cases.csv in a spreadsheet or text editor. Keep observed and evidence columns blank until you execute or reason through each case. Read sample-signoff.md as a fictional worked example after your own decision. The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run intermediate or evaluate the decision table by hand. Test requester, assigned manager and unrelated manager, then compare the current/future transfer snapshots.
```
python3 enterprise_lab.py intermediate
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py intermediate --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Validate authorized tenant cases
With the training owner, map the fictional actors to actual permitted test roles. Execute missing-data, self-approval, authorized-approval and future-transfer cases using the tenant’s documented process. Capture non-sensitive case references and observations; never change security just to make a case pass.
Expected: Four UAT outcomes and documented differences between the fictional policy and actual tenant configuration.

6. Assemble the portfolio evidence
Create role/date UAT matrix and expected-results workbook. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: Testing only with an administrator masks role-routing defects; use the intended actors in an authorized tenant.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: role/date UAT matrix and expected-results workbook
The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit.

Interview: Work through this Workday HCM / Functional Analyst case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Approval authority and business-effective time answer different questions. A completed approval may authorize a future change without making it current immediately. Expected evidence: The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit. Diagnosis: Testing only with an administrator masks role-routing defects; use the intended actors in an authorized tenant. State the limits of the mental model: A signed future appointment is authorized now but begins on its scheduled day.

Resume: Built role/date UAT matrix and expected-results workbook using Workday business processes and reporting; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run advanced, identify the deliberately untested payroll impact in the release register and produce a hold decision. Write the missing UAT case, reviewer and recovery check; mark simulated approvals clearly.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Change impact and release signoff
Configuration changes can alter reporting, integrations, security and in-flight processes. Signoff requires evidence from affected owners; a complete template is not an actual approval.
Mental model: Changing a junction requires checking every route that crosses it.
Limit: Do not convert not-tested to passed just to close the checklist.
Example: A new approval threshold changes which manager receives the case and which test boundary must be updated.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not convert not-tested to passed just to close the checklist.

1. Inspect the business fixture
Open uat-cases.csv in a spreadsheet or text editor. Keep observed and evidence columns blank until you execute or reason through each case. Read sample-signoff.md as a fictional worked example after your own decision. A new approval threshold changes which manager receives the case and which test boundary must be updated.
Expected: A prediction for every accepted, rejected or pending case.

2. Run the role reference
Run advanced, identify the deliberately untested payroll impact in the release register and produce a hold decision. Write the missing UAT case, reviewer and recovery check; mark simulated approvals clearly.
```
python3 enterprise_lab.py advanced
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: The release remains held until the missing evidence is resolved by an accountable owner.

3. Investigate a deliberately broken rule
Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.
```
python3 enterprise_lab.py advanced --broken
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

4. Extend the fixture independently
Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.
Expected: Two additional cases and an explained expected/observed comparison.

5. Optional platform lab · Prepare a reviewable change decision
Trace the proposed rule change through HCM, payroll, reporting and integrations. Ask each responsible reviewer for the needed evidence in your exercise plan; do not invent signoff. Define a recovery path for in-flight cases and mark unexecuted tenant cases pending.
Expected: A release/hold recommendation supported by evidence, with owner and due action for every gap.

6. Assemble the portfolio evidence
Create functional change pack with UAT, impact analysis and proposed signoff. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.
Expected: The release remains held until the missing evidence is resolved by an accountable owner.

Troubleshooting:
File not found: Open a terminal in the extracted folder containing enterprise_lab.py, fixture.json and expected.json.
The deliberate broken run exits with AssertionError: Expected: --broken injects a defect. Compare printed values against expected.json, locate the broken branch and repair a copy before rerunning. Do not remove assertions.
Platform access is unavailable: Complete the local/manual route and mark the tenant steps not executed. Local outputs are not evidence of vendor configuration or certification.
Role-specific failure: Do not convert not-tested to passed just to close the checklist.
Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Portfolio: functional change pack with UAT, impact analysis and proposed signoff
The release remains held until the missing evidence is resolved by an accountable owner.

Interview: Work through this Workday HCM / Functional Analyst case: A new approval threshold changes which manager receives the case and which test boundary must be updated. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Configuration changes can alter reporting, integrations, security and in-flight processes. Signoff requires evidence from affected owners; a complete template is not an actual approval. Expected evidence: The release remains held until the missing evidence is resolved by an accountable owner. Diagnosis: Do not convert not-tested to passed just to close the checklist. State the limits of the mental model: Changing a junction requires checking every route that crosses it.

Resume: Built functional change pack with UAT, impact analysis and proposed signoff using Workday business processes and reporting; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html
