"""Local contract models using synthetic data, not vendor SDKs or tenant emulators.
Run from an extracted course pack: python3 enterprise_lab.py beginner [--broken]
--broken intentionally introduces a bug; a nonzero exit is the expected outcome.
Expected results live independently in expected.json so fixture changes need review.
"""
import argparse
import copy
import datetime
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parent

def can_approve(requester, assigned_approver, actor):
    return actor == assigned_approver and actor != requester

def can_read(owner, actor):
    return actor == owner

def procurement(data, level, broken):
    accepted, rejected = [], []
    for po in data['orders']:
        if po['quantity'] <= 0 or Decimal(po['price']) < 0:
            rejected.append(po['id'])
        else:
            accepted.append(po)
    po = accepted[0]
    result = {'total': str(Decimal(po['price']) * po['quantity']),
              'rejected': rejected, 'self_approval_allowed': True if broken and level == 'beginner' else can_approve(po['requester'], po['approver'], po['requester'])}
    if level != 'beginner':
        seen, received = set(), 0
        for receipt in data['receipts']:
            if receipt['id'] in seen and not (broken and level == 'intermediate'):
                continue
            seen.add(receipt['id'])
            if receipt['order'] == po['id']:
                received += receipt['quantity']
        result['received'] = received
    if level == 'advanced':
        variance = Decimal(data['invoice']) - Decimal(result['total'])
        result.update(variance=str(variance), hold=False if broken else variance != 0)
    return result

def crm(data, level, broken):
    if level == 'beginner':
        return {'accepted': [r['id'] for r in data['requests'] if r['amount'] >= 0],
                'rejected': [r['id'] for r in data['requests'] if r['amount'] < 0],
                'bob_reads_alice': True if broken else can_read(data['requests'][0]['owner'], 'bob')}
    if level == 'intermediate':
        batch = [{'id': str(i), 'amount': -1 if i == 199 else 10} for i in range(200)]
        if broken:
            batch = batch[:1]
        return {'accepted': sum(r['amount'] >= 0 for r in batch),
                'rejected': sum(r['amount'] < 0 for r in batch), 'processed': len(batch)}
    access = []
    for user, action in [('alice', 'read'), ('alice', 'write'), ('bob', 'read'), ('unknown', 'read')]:
        allowed = user == 'alice' and action == 'read'
        if broken and user == 'bob':
            allowed = True
        access.append({'user': user, 'action': action, 'allowed': allowed})
    return {'access': access}

def worker_events(data):
    accepted, rejected = [], []
    for event in data['events']:
        if not event['worker']:
            rejected.append({'event': event['id'], 'reason': 'missing worker ID'})
            continue
        datetime.date.fromisoformat(event['effective'])
        accepted.append(event)
    return accepted, rejected

def snapshot(events, asof, ignore_future=False):
    state = {}
    for event in sorted(events, key=lambda r: (r['effective'], r['id'])):
        if event['effective'] <= asof or ignore_future:
            state[event['worker']] = event['department']
    return state

def workday_integration(data, level, broken):
    events, rejected = worker_events(data)
    if level == 'beginner':
        return {'accepted': len(events), 'rejected': [] if broken else rejected}
    if level == 'intermediate':
        return {date: snapshot(events, date, broken) for date in data['asof']}
    seen, unique, duplicates = set(), [], []
    for event in events + [events[0]]:
        if event['id'] in seen and not broken:
            duplicates.append(event['id'])
            continue
        seen.add(event['id'])
        unique.append(event)
    return {'processed': len(unique), 'duplicates': duplicates,
            'snapshot': snapshot(unique, data['asof'][-1])}

def workday_functional(data, level, broken):
    if level == 'beginner':
        return {'review': [r['id'] for r in data['hires'] if r['manager'] and r['department']],
                'rejected': [] if broken else [r['id'] for r in data['hires'] if not r['manager'] or not r['department']]}
    if level == 'intermediate':
        hire = data['hires'][0]
        return {'approvals': {actor: (actor == hire['manager'] and actor != hire['requester']) or
                             (broken and actor == hire['requester']) for actor in data['actors']},
                'transfer_current': data['transfer_date'] <= data['asof']}
    missing = [r['area'] for r in data['release'] if r['status'] != 'passed']
    return {'missing_evidence': missing, 'decision': 'release' if broken or not missing else 'hold'}

def mapping_rows(data):
    accepted, rejected, duplicates, seen = [], [], [], set()
    for row in data['rows']:
        try:
            amount = Decimal(row['amount'])
            if not amount.is_finite() or amount < 0:
                raise ValueError('amount must be finite and nonnegative')
        except (InvalidOperation, ValueError):
            rejected.append(row['id'])
            continue
        if row['id'] in seen:
            duplicates.append(row['id'])
            continue
        seen.add(row['id'])
        accepted.append((row['id'], int(amount * 100), row['version']))
    return accepted, rejected, duplicates

def data_pipeline(data, level, broken, azure=False):
    accepted, rejected, duplicates = mapping_rows(data)
    if level == 'beginner':
        return {'accepted': len(accepted), 'duplicates': duplicates,
                'rejected': [] if broken else rejected,
                'total': format(Decimal(sum(x[1] for x in accepted)) / 100, 'f')}
    db = sqlite3.connect(':memory:')
    try:
        db.executescript('CREATE TABLE orders(id TEXT PRIMARY KEY, cents INTEGER CHECK(cents>=0), version INTEGER);'
                         'CREATE TABLE checkpoint(version INTEGER); INSERT INTO checkpoint VALUES(1);')
        db.executemany('INSERT INTO orders VALUES(?,?,?)', accepted)
        db.commit()
        def state():
            return {'count': db.execute('SELECT count(*) FROM orders').fetchone()[0],
                    'total': format(Decimal(db.execute('SELECT sum(cents) FROM orders').fetchone()[0]) / 100, 'f'),
                    'watermark': db.execute('SELECT version FROM checkpoint').fetchone()[0]}
        def apply(fail=False):
            old = db.execute('SELECT version FROM checkpoint').fetchone()[0]
            high = max(row['version'] for row in data['delta'])
            # Deliberately wrong checkpoint commit demonstrates data-loss risk after a failure.
            if broken and level == 'advanced':
                db.execute('UPDATE checkpoint SET version=?', (high,))
                db.commit()
            with db:
                for row in data['delta']:
                    if old < row['version'] <= high:
                        if broken and level == 'intermediate' and row['id'] == 'a':
                            continue
                        db.execute('INSERT INTO orders VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET '
                                   'cents=excluded.cents,version=excluded.version WHERE excluded.version>orders.version',
                                   (row['id'], int(Decimal(row['amount']) * 100), row['version']))
                        if fail:
                            raise RuntimeError('injected target failure')
                # Quality gate is deliberately inside the same local transaction.
                if azure and db.execute('SELECT count(*) FROM orders').fetchone()[0] != 3:
                    raise RuntimeError('quality gate: expected three target orders')
                db.execute('UPDATE checkpoint SET version=?', (high,))
        if level == 'intermediate':
            apply()
            return state()
        try:
            apply(fail=True)
        except RuntimeError:
            pass
        after_failure = state()
        try:
            apply()
        except RuntimeError as error:
            return {'after_failure': after_failure, 'after_replay': state(), 'replay_error': str(error)}
        return {'after_failure': after_failure, 'after_replay': state()}
    finally:
        db.close()

MODELS = {'enterprise-erp': procurement, 'enterprise-crm': crm,
          'workday-integrations': workday_integration, 'workday-functional': workday_functional,
          'informatica': data_pipeline,
          'azure-data-engineer': lambda d, l, b: data_pipeline(d, l, b, azure=True)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('level', choices=['beginner', 'intermediate', 'advanced'])
    parser.add_argument('--broken', action='store_true', help='Inject a deliberate defect; expect a failed assertion')
    args = parser.parse_args()
    fixture = json.loads((ROOT / 'fixture.json').read_text())
    expected = json.loads((ROOT / 'expected.json').read_text())[args.level]
    actual = MODELS[fixture['course']](copy.deepcopy(fixture), args.level, args.broken)
    print(json.dumps(actual, indent=2, sort_keys=True))
    if actual != expected:
        raise AssertionError('Contract mismatch. Compare printed results with expected.json; inspect the rule before changing the expected result.')
    print('PASS ' + fixture['course'] + ' ' + args.level + ' (local contract model only)')
if __name__ == '__main__':
    main()
