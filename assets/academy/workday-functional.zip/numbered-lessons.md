# Workday HCM / Functional Analyst — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Acceptance criteria: Describe an observable result that determines whether a requirement has been met.

Business process and roles: Define who initiates, approves, reviews and completes a process. A process name is not enough to establish ownership.

UAT: User acceptance testing: checking a business process against agreed user requirements.

Segregation of duties: Separating responsibilities such as requesting and approving to reduce conflicting authority.

Tenant: An organization-specific platform environment with its own configuration, data and access rules.

Business process ownership: A functional analyst defines who initiates, approves and completes a process and what evidence is required. The lab's fictional hire policy prevents self-approval and requires a manager and department; real tenant rules must be confirmed.

### Acceptance criteria

Describe an observable result that determines whether a requirement has been met. In this role, work through: Hire h1 has complete data; h2 has no manager and must stop before approval. The practical workshop develops this into: Read the process fixture and complete the supplied decision table manually. Run the optional beginner checker, then draw initiation → data check → manager approval → onboarding and name each owner.

Mental model: A delivery receipt lists what must arrive, not just that a truck drove.

Boundary: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Role application: A relay has named handoffs and rules for who may accept the baton.

A functional analyst defines who initiates, approves and completes a process and what evidence is required. The lab's fictional hire policy prevents self-approval and requires a manager and department; real tenant rules must be confirmed.

Worked example: Hire h1 has complete data; h2 has no manager and must stop before approval.

Shared foundation example: Given an empty title, submitting a request shows an error and creates no ticket.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Workday business processes and reporting (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Workday HCM / Functional Analyst: Hire h1 has complete data; h2 has no manager and must stop before approval.

Predict the worked case

Read this case without running a tool: Hire h1 has complete data; h2 has no manager and must stop before approval. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in acceptance criteria.

Connect the concept to the role

Apply this rule: Describe an observable result that determines whether a requirement has been met. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies acceptance criteria to this case: Hire h1 has complete data; h2 has no manager and must stop before approval. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Hire h1 has complete data; h2 has no manager and must stop before approval. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Acceptance criteria; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with acceptance criteria. Use the glossary below, then write your prediction for: Hire h1 has complete data; h2 has no manager and must stop before approval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday HCM / Functional Analyst role interview. Explain acceptance criteria using this case: Hire h1 has complete data; h2 has no manager and must stop before approval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate acceptance criteria to a system or workflow you know. Explain acceptance criteria using this case: Hire h1 has complete data; h2 has no manager and must stop before approval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Turn “make it easier” into a measurable task outcome.

Interview: Explain acceptance criteria using this case: Hire h1 has complete data; h2 has no manager and must stop before approval. State the evidence, one alternative and where the mental model stops.

Quiz: After the Business process ownership rehearsal, check this foundation: A requirement says “make this workflow easier.” What makes its acceptance testable?

A defined user task and observable result, reviewed with the relevant stakeholder.

A count of implementation files without a user outcome.

A statement that the chosen tool is widely used.

Reference: A defined user task and observable result, reviewed with the relevant stakeholder. — Acceptance criteria describe observable outcomes. Stakeholder review is still needed to ensure the outcome solves the right problem.

Sources:

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

### Business process ownership

A functional analyst defines who initiates, approves and completes a process and what evidence is required. The lab's fictional hire policy prevents self-approval and requires a manager and department; real tenant rules must be confirmed. In this role, work through: Hire h1 has complete data; h2 has no manager and must stop before approval. The practical workshop develops this into: Read the process fixture and complete the supplied decision table manually. Run the optional beginner checker, then draw initiation → data check → manager approval → onboarding and name each owner.

Mental model: A relay has named handoffs and rules for who may accept the baton.

Boundary: A process diagram without actors cannot establish accountability; name roles at each handoff.

Worked example: Hire h1 has complete data; h2 has no manager and must stop before approval.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Workday business processes and reporting (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. The functional route can be completed manually using uat-cases.csv and sample-signoff.md; Python is optional.

Read the process fixture and complete the supplied decision table manually. Run the optional beginner checker, then draw initiation → data check → manager approval → onboarding and name each owner.

Inspect the business fixture

Open uat-cases.csv in a spreadsheet or text editor. Keep observed and evidence columns blank until you execute or reason through each case. Read sample-signoff.md as a fictional worked example after your own decision. Hire h1 has complete data; h2 has no manager and must stop before approval.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Read the process fixture and complete the supplied decision table manually. Run the optional beginner checker, then draw initiation → data check → manager approval → onboarding and name each owner.

```
python3 enterprise_lab.py beginner
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: h1 is eligible for review; h2 is rejected with missing-manager reason.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py beginner --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Prepare the tenant-independent UAT pack

Fill role, required data, effective date, approval and expected result columns for h1 and h2. Use expected.json as a sample answer after making your own decision. Select an appropriate Workday learning route; configuration requires the authorized tenant’s current instructions.

Expected: A complete manual deliverable works without Python or a tenant.

Assemble the portfolio evidence

Create hire-process map and sample completed acceptance table. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: h1 is eligible for review; h2 is rejected with missing-manager reason.

Expected: h1 is eligible for review; h2 is rejected with missing-manager reason.

Troubleshoot: The role exercise differs from the prediction: A process diagram without actors cannot establish accountability; name roles at each handoff.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-beginner-2.md: hire-process map and sample completed acceptance table; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with business process ownership. Use the glossary below, then write your prediction for: Hire h1 has complete data; h2 has no manager and must stop before approval. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday HCM / Functional Analyst role interview. Explain business process ownership using this case: Hire h1 has complete data; h2 has no manager and must stop before approval. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate business process ownership to a system or workflow you know. Explain business process ownership using this case: Hire h1 has complete data; h2 has no manager and must stop before approval. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A process diagram without actors cannot establish accountability; name roles at each handoff.

Interview: Explain business process ownership using this case: Hire h1 has complete data; h2 has no manager and must stop before approval. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? Hire h1 has complete data; h2 has no manager and must stop before approval.

h1 is eligible for review; h2 is rejected with missing-manager reason.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: h1 is eligible for review; h2 is rejected with missing-manager reason. — A functional analyst defines who initiates, approves and completes a process and what evidence is required. The lab's fictional hire policy prevents self-approval and requires a manager and department; real tenant rules must be confirmed. h1 is eligible for review; h2 is rejected with missing-manager reason.

Sources:

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Traceability: Connect a user need to the proposed change, its test and its evidence.

Effective-dated configuration: Distinguish when a decision is made from when its business effect begins, and test future, current and corrected cases.

UAT: User acceptance testing: checking a business process against agreed user requirements.

Segregation of duties: Separating responsibilities such as requesting and approving to reduce conflicting authority.

Tenant: An organization-specific platform environment with its own configuration, data and access rules.

Approval and effective-date cases: Approval authority and business-effective time answer different questions. A completed approval may authorize a future change without making it current immediately.

### Traceability

Connect a user need to the proposed change, its test and its evidence. In this role, work through: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. The practical workshop develops this into: Run intermediate or evaluate the decision table by hand. Test requester, assigned manager and unrelated manager, then compare the current/future transfer snapshots.

Mental model: Labels connect a parcel to its order and delivery receipt.

Boundary: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Role application: A signed future appointment is authorized now but begins on its scheduled day.

Approval authority and business-effective time answer different questions. A completed approval may authorize a future change without making it current immediately.

Worked example: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date.

Shared foundation example: Need R1 points to screen S1, test T1 and a recorded observation.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Workday business processes and reporting (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Workday HCM / Functional Analyst: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date.

Predict the worked case

Read this case without running a tool: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in traceability.

Connect the concept to the role

Apply this rule: Connect a user need to the proposed change, its test and its evidence. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies traceability to this case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Traceability; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with traceability. Use the glossary below, then write your prediction for: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday HCM / Functional Analyst role interview. Explain traceability using this case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate traceability to a system or workflow you know. Explain traceability using this case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you identify which tests are affected by a changed requirement?

Interview: Explain traceability using this case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. State the evidence, one alternative and where the mental model stops.

Quiz: After the Approval and effective-date cases rehearsal, check this foundation: A requirement changes. What evidence helps identify affected checks?

The total number of screenshots in the project.

Links from the requirement to its design, test cases and recorded results.

Only the latest file modification time.

Reference: Links from the requirement to its design, test cases and recorded results. — Traceability connects a need to the change and its verification; documents without those links do not establish impact.

Sources:

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

### Approval and effective-date cases

Approval authority and business-effective time answer different questions. A completed approval may authorize a future change without making it current immediately. In this role, work through: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. The practical workshop develops this into: Run intermediate or evaluate the decision table by hand. Test requester, assigned manager and unrelated manager, then compare the current/future transfer snapshots.

Mental model: A signed future appointment is authorized now but begins on its scheduled day.

Boundary: Testing only with an administrator masks role-routing defects; use the intended actors in an authorized tenant.

Worked example: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Workday business processes and reporting (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. The functional route can be completed manually using uat-cases.csv and sample-signoff.md; Python is optional.

Run intermediate or evaluate the decision table by hand. Test requester, assigned manager and unrelated manager, then compare the current/future transfer snapshots.

Inspect the business fixture

Open uat-cases.csv in a spreadsheet or text editor. Keep observed and evidence columns blank until you execute or reason through each case. Read sample-signoff.md as a fictional worked example after your own decision. The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run intermediate or evaluate the decision table by hand. Test requester, assigned manager and unrelated manager, then compare the current/future transfer snapshots.

```
python3 enterprise_lab.py intermediate
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py intermediate --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Validate authorized tenant cases

With the training owner, map the fictional actors to actual permitted test roles. Execute missing-data, self-approval, authorized-approval and future-transfer cases using the tenant’s documented process. Capture non-sensitive case references and observations; never change security just to make a case pass.

Expected: Four UAT outcomes and documented differences between the fictional policy and actual tenant configuration.

Assemble the portfolio evidence

Create role/date UAT matrix and expected-results workbook. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit.

Expected: The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit.

Troubleshoot: The role exercise differs from the prediction: Testing only with an administrator masks role-routing defects; use the intended actors in an authorized tenant.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-intermediate-2.md: role/date UAT matrix and expected-results workbook; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with approval and effective-date cases. Use the glossary below, then write your prediction for: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday HCM / Functional Analyst role interview. Explain approval and effective-date cases using this case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate approval and effective-date cases to a system or workflow you know. Explain approval and effective-date cases using this case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Testing only with an administrator masks role-routing defects; use the intended actors in an authorized tenant.

Interview: Explain approval and effective-date cases using this case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date.

Ignore the failing case and keep only the successful screenshot.

The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit.

Treat any successful command as proof that all business and access rules passed.

Reference: The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit. — Approval authority and business-effective time answer different questions. A completed approval may authorize a future change without making it current immediately. The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit.

Sources:

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Release decision and ownership: Document the evidence, remaining risk, responsible owner and recovery trigger for a change.

Change impact and signoff: A configuration change can affect reporting, integrations, access and downstream business processes. Trace affected cases before signoff.

UAT: User acceptance testing: checking a business process against agreed user requirements.

Segregation of duties: Separating responsibilities such as requesting and approving to reduce conflicting authority.

Tenant: An organization-specific platform environment with its own configuration, data and access rules.

Change impact and release signoff: Configuration changes can alter reporting, integrations, security and in-flight processes. Signoff requires evidence from affected owners; a complete template is not an actual approval.

### Release decision and ownership

Document the evidence, remaining risk, responsible owner and recovery trigger for a change. In this role, work through: A new approval threshold changes which manager receives the case and which test boundary must be updated. The practical workshop develops this into: Run advanced, identify the deliberately untested payroll impact in the release register and produce a hold decision. Write the missing UAT case, reviewer and recovery check; mark simulated approvals clearly.

Mental model: A flight checklist has an accountable pilot and reasons to delay departure.

Boundary: A checklist supports judgment; it does not transfer accountability to a tool.

Role application: Changing a junction requires checking every route that crosses it.

Configuration changes can alter reporting, integrations, security and in-flight processes. Signoff requires evidence from affected owners; a complete template is not an actual approval.

Worked example: A new approval threshold changes which manager receives the case and which test boundary must be updated.

Shared foundation example: Hold a release if unauthorized users can export records, even if basic navigation works.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Workday business processes and reporting (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Workday HCM / Functional Analyst: A new approval threshold changes which manager receives the case and which test boundary must be updated.

Predict the worked case

Read this case without running a tool: A new approval threshold changes which manager receives the case and which test boundary must be updated. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in release decision and ownership.

Connect the concept to the role

Apply this rule: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A checklist supports judgment; it does not transfer accountability to a tool.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies release decision and ownership to this case: A new approval threshold changes which manager receives the case and which test boundary must be updated. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A new approval threshold changes which manager receives the case and which test boundary must be updated. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Release decision and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with release decision and ownership. Use the glossary below, then write your prediction for: A new approval threshold changes which manager receives the case and which test boundary must be updated. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday HCM / Functional Analyst role interview. Explain release decision and ownership using this case: A new approval threshold changes which manager receives the case and which test boundary must be updated. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate release decision and ownership to a system or workflow you know. Explain release decision and ownership using this case: A new approval threshold changes which manager receives the case and which test boundary must be updated. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would make a conditional approval expire?

Interview: Explain release decision and ownership using this case: A new approval threshold changes which manager receives the case and which test boundary must be updated. State the evidence, one alternative and where the mental model stops.

Quiz: After the Change impact and release signoff rehearsal, check this foundation: A release has a known access-control defect but basic navigation passes. What should the decision include?

Only the navigation pass count.

An anonymous approval with no recovery trigger.

The defect evidence, impact, accountable owner and explicit release or hold criteria.

Reference: The defect evidence, impact, accountable owner and explicit release or hold criteria. — A release decision needs evidence and ownership. Basic checks do not cancel a serious unresolved risk.

Sources:

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html

### Change impact and release signoff

Configuration changes can alter reporting, integrations, security and in-flight processes. Signoff requires evidence from affected owners; a complete template is not an actual approval. In this role, work through: A new approval threshold changes which manager receives the case and which test boundary must be updated. The practical workshop develops this into: Run advanced, identify the deliberately untested payroll impact in the release register and produce a hold decision. Write the missing UAT case, reviewer and recovery check; mark simulated approvals clearly.

Mental model: Changing a junction requires checking every route that crosses it.

Boundary: Do not convert not-tested to passed just to close the checklist.

Worked example: A new approval threshold changes which manager receives the case and which test boundary must be updated.

Setup: Extract the course pack into a new folder. Open fixture.json and expected.json in an editor. For local execution install Python 3.9 or newer; no third-party packages, credentials or cloud account are used. Run python3 --version (Windows: py --version and replace python3 with py). Read platform access/cost requirements before the optional tenant steps.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Workday business processes and reporting (Commercial platform); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Two clearly separated routes: a local synthetic contract lab and an optional authorized platform exercise. The local model does not connect to, emulate or certify the vendor platform. The functional route can be completed manually using uat-cases.csv and sample-signoff.md; Python is optional.

Run advanced, identify the deliberately untested payroll impact in the release register and produce a hold decision. Write the missing UAT case, reviewer and recovery check; mark simulated approvals clearly.

Inspect the business fixture

Open uat-cases.csv in a spreadsheet or text editor. Keep observed and evidence columns blank until you execute or reason through each case. Read sample-signoff.md as a fictional worked example after your own decision. A new approval threshold changes which manager receives the case and which test boundary must be updated.

Expected: A prediction for every accepted, rejected or pending case.

Run the role reference

Run advanced, identify the deliberately untested payroll impact in the release register and produce a hold decision. Write the missing UAT case, reviewer and recovery check; mark simulated approvals clearly.

```
python3 enterprise_lab.py advanced
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: The release remains held until the missing evidence is resolved by an accountable owner.

Investigate a deliberately broken rule

Run with --broken. This command should fail. Compare actual output with expected.json, find the conditional defect in enterprise_lab.py and explain why it violates the contract. Repair a copy and rerun the baseline.

```
python3 enterprise_lab.py advanced --broken
```

Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.

Expected: Nonzero exit with Contract mismatch for the broken case; a normal run passes after the deliberate fault is removed.

Extend the fixture independently

Add one normal and one boundary case. Calculate expected values yourself, then update a copy of expected.json with a written reason. Compare every identifier, value and rejection; do not infer correctness from counts alone.

Expected: Two additional cases and an explained expected/observed comparison.

Optional platform lab · Prepare a reviewable change decision

Trace the proposed rule change through HCM, payroll, reporting and integrations. Ask each responsible reviewer for the needed evidence in your exercise plan; do not invent signoff. Define a recovery path for in-flight cases and mark unexecuted tenant cases pending.

Expected: A release/hold recommendation supported by evidence, with owner and due action for every gap.

Assemble the portfolio evidence

Create functional change pack with UAT, impact analysis and proposed signoff. Separate observed local, observed platform and planned checks. Include versions, command output, failure diagnosis and source links.

Expected: The release remains held until the missing evidence is resolved by an accountable owner.

Expected: The release remains held until the missing evidence is resolved by an accountable owner.

Troubleshoot: The role exercise differs from the prediction: Do not convert not-tested to passed just to close the checklist.

Cleanup: The local script uses an in-memory database and reads fixtures; it creates no cloud resources. Keep your evidence and changed files. For platform exercises remove only your own disposable lab objects/resources after retaining results and reviewing dependencies.

Deliverable: lesson-advanced-2.md: functional change pack with UAT, impact analysis and proposed signoff; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with change impact and release signoff. Use the glossary below, then write your prediction for: A new approval threshold changes which manager receives the case and which test boundary must be updated. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Workday HCM / Functional Analyst role interview. Explain change impact and release signoff using this case: A new approval threshold changes which manager receives the case and which test boundary must be updated. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate change impact and release signoff to a system or workflow you know. Explain change impact and release signoff using this case: A new approval threshold changes which manager receives the case and which test boundary must be updated. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not convert not-tested to passed just to close the checklist.

Interview: Explain change impact and release signoff using this case: A new approval threshold changes which manager receives the case and which test boundary must be updated. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A new approval threshold changes which manager receives the case and which test boundary must be updated.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

The release remains held until the missing evidence is resolved by an accountable owner.

Reference: The release remains held until the missing evidence is resolved by an accountable owner. — Configuration changes can alter reporting, integrations, security and in-flight processes. Signoff requires evidence from affected owners; a complete template is not an actual approval. The release remains held until the missing evidence is resolved by an accountable owner.

Sources:

Workday learning and access options: https://www.workday.com/en-us/services/learn-with-workday.html
