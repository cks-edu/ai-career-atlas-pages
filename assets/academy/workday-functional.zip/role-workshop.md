# Workday HCM / Functional Analyst — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Business process ownership

A functional analyst defines who initiates, approves and completes a process and what evidence is required. The lab's fictional hire policy prevents self-approval and requires a manager and department; real tenant rules must be confirmed.
Mental model: A relay has named handoffs and rules for who may accept the baton.
Case: Hire h1 has complete data; h2 has no manager and must stop before approval.
Task: Read the process fixture and complete the supplied decision table manually. Run the optional beginner checker, then draw initiation → data check → manager approval → onboarding and name each owner.
Acceptance: h1 is eligible for review; h2 is rejected with missing-manager reason.
Troubleshooting: A process diagram without actors cannot establish accountability; name roles at each handoff.
Deliverable: hire-process map and sample completed acceptance table

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Approval and effective-date cases

Approval authority and business-effective time answer different questions. A completed approval may authorize a future change without making it current immediately.
Mental model: A signed future appointment is authorized now but begins on its scheduled day.
Case: The requester is denied self-approval; an assigned manager can approve; the future transfer is not current before its date.
Task: Run intermediate or evaluate the decision table by hand. Test requester, assigned manager and unrelated manager, then compare the current/future transfer snapshots.
Acceptance: The baseline authorized manager passes while unauthorized approvers fail; the date rule is explicit.
Troubleshooting: Testing only with an administrator masks role-routing defects; use the intended actors in an authorized tenant.
Deliverable: role/date UAT matrix and expected-results workbook

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Change impact and release signoff

Configuration changes can alter reporting, integrations, security and in-flight processes. Signoff requires evidence from affected owners; a complete template is not an actual approval.
Mental model: Changing a junction requires checking every route that crosses it.
Case: A new approval threshold changes which manager receives the case and which test boundary must be updated.
Task: Run advanced, identify the deliberately untested payroll impact in the release register and produce a hold decision. Write the missing UAT case, reviewer and recovery check; mark simulated approvals clearly.
Acceptance: The release remains held until the missing evidence is resolved by an accountable owner.
Troubleshooting: Do not convert not-tested to passed just to close the checklist.
Deliverable: functional change pack with UAT, impact analysis and proposed signoff

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
