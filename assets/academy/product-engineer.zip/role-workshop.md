# Product Engineer / Technical Product Manager — role workshops

Complete the shared setup in README.md first. These briefs require your own implementation or decision artifact. Reference answers are review criteria, not automatic certification.

## beginner
Problem framing and outcomes

A feature is a hypothesis about improving a user's outcome. Define the user, problem frequency and success measure before choosing an implementation.
Mental model: A medicine is selected for a diagnosed problem, not because the bottle looks impressive.
Case: A task tool aims to reduce lost follow-ups, not merely increase button clicks.
Task: Write a problem statement, three interview prompts and a baseline measurement plan. Build a small task-form prototype and state what evidence would disprove the idea.
Acceptance: A falsifiable hypothesis and a prototype tied to it.
Troubleshooting: Activity metrics can increase while users struggle; identify the outcome behind each metric.
Deliverable: problem brief and prototype

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## intermediate
Experiments and guardrails

An experiment needs a comparison, assignment method and decision rule. Guardrails protect outcomes that could worsen while the primary metric improves.
Mental model: A new route is useful only if it saves time without increasing accidents.
Case: A shorter form may improve completion while increasing invalid requests.
Task: Design an A/B or staged pilot with completion and invalid-request rates, sample assumptions and a stop rule. Use synthetic data to calculate both metrics and mark it as simulated.
Acceptance: A decision table that considers benefit and harm together.
Troubleshooting: Do not describe an uncontrolled before/after comparison as proof of causation.
Deliverable: experiment plan and metric worksheet

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:

## advanced
Ship, hold and learn

A release decision combines user evidence, reliability, security and operational cost. State uncertainty and what will be monitored after launch.
Mental model: Opening a new service includes a plan for learning from the first customers.
Case: A useful prototype with a data-loss defect should be held until recovery is addressed.
Task: Create a launch review with five evidence categories, unresolved risks, owners and a rollback trigger. Draft a post-launch review agenda and one resume bullet limited to work actually performed.
Acceptance: A concrete ship/hold decision with conditions and next evidence.
Troubleshooting: A compelling demo cannot substitute for operational readiness.
Deliverable: launch decision and learning plan

### Evidence to fill in
Environment/version:
Prediction:
Changed code/configuration or decision:
Observed output:
Failure and recovery:
Executed locally / on vendor / planned:
Limitations:
