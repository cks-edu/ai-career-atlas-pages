# Product Engineer / Technical Product Manager — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Shared foundations below; no prior experience with this subject required.

Terms:

Acceptance criteria: Describe an observable result that determines whether a requirement has been met.

Apply acceptance criteria in Product Engineer / Technical Product Manager: Use the concept to complete this role exercise: Choose a user problem and a measurable outcome

Problem framing and outcomes: A feature is a hypothesis about improving a user's outcome. Define the user, problem frequency and success measure before choosing an implementation.

### Acceptance criteria

Describe an observable result that determines whether a requirement has been met. In this role, work through: A task tool aims to reduce lost follow-ups, not merely increase button clicks. The practical workshop develops this into: Write a problem statement, three interview prompts and a baseline measurement plan. Build a small task-form prototype and state what evidence would disprove the idea.

Mental model: A delivery receipt lists what must arrive, not just that a truck drove.

Boundary: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Role application: A medicine is selected for a diagnosed problem, not because the bottle looks impressive.

A feature is a hypothesis about improving a user's outcome. Define the user, problem frequency and success measure before choosing an implementation.

Worked example: A task tool aims to reduce lost follow-ups, not merely increase button clicks.

Shared foundation example: Given an empty title, submitting a request shows an error and creates no ticket.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Shared foundations below; no prior experience with this subject required.

Tools for this exercise: Document or text editor

Course tool and framework map: Issue tracking, analytics definitions and prototypes (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Product Engineer / Technical Product Manager: A task tool aims to reduce lost follow-ups, not merely increase button clicks.

Predict the worked case

Read this case without running a tool: A task tool aims to reduce lost follow-ups, not merely increase button clicks. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in acceptance criteria.

Connect the concept to the role

Apply this rule: Describe an observable result that determines whether a requirement has been met. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Criteria need stakeholder review; they can be precise and still solve the wrong problem.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies acceptance criteria to this case: A task tool aims to reduce lost follow-ups, not merely increase button clicks. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A task tool aims to reduce lost follow-ups, not merely increase button clicks. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Acceptance criteria; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with acceptance criteria. Use the glossary below, then write your prediction for: A task tool aims to reduce lost follow-ups, not merely increase button clicks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Product Engineer / Technical Product Manager role interview. Explain acceptance criteria using this case: A task tool aims to reduce lost follow-ups, not merely increase button clicks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate acceptance criteria to a system or workflow you know. Explain acceptance criteria using this case: A task tool aims to reduce lost follow-ups, not merely increase button clicks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Turn “make it easier” into a measurable task outcome.

Interview: Explain acceptance criteria using this case: A task tool aims to reduce lost follow-ups, not merely increase button clicks. State the evidence, one alternative and where the mental model stops.

Quiz: After the Problem framing and outcomes rehearsal, check this foundation: A requirement says “make this workflow easier.” What makes its acceptance testable?

A defined user task and observable result, reviewed with the relevant stakeholder.

A count of implementation files without a user outcome.

A statement that the chosen tool is widely used.

Reference: A defined user task and observable result, reviewed with the relevant stakeholder. — Acceptance criteria describe observable outcomes. Stakeholder review is still needed to ensure the outcome solves the right problem.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Problem framing and outcomes

A feature is a hypothesis about improving a user's outcome. Define the user, problem frequency and success measure before choosing an implementation. In this role, work through: A task tool aims to reduce lost follow-ups, not merely increase button clicks. The practical workshop develops this into: Write a problem statement, three interview prompts and a baseline measurement plan. Build a small task-form prototype and state what evidence would disprove the idea.

Mental model: A medicine is selected for a diagnosed problem, not because the bottle looks impressive.

Boundary: Activity metrics can increase while users struggle; identify the outcome behind each metric.

Worked example: A task tool aims to reduce lost follow-ups, not merely increase button clicks.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Issue tracking, analytics definitions and prototypes (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Product Engineer / Technical Product Manager workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Write a problem statement, three interview prompts and a baseline measurement plan. Build a small task-form prototype and state what evidence would disprove the idea.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

A task tool aims to reduce lost follow-ups, not merely increase button clicks. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Write a problem statement, three interview prompts and a baseline measurement plan. Build a small task-form prototype and state what evidence would disprove the idea.

Expected: A falsifiable hypothesis and a prototype tied to it.

Role workshop · debug and verify

Activity metrics can increase while users struggle; identify the outcome behind each metric. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save problem brief and prototype. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A falsifiable hypothesis and a prototype tied to it.

Expected: A falsifiable hypothesis and a prototype tied to it.

Troubleshoot: The role exercise differs from the prediction: Activity metrics can increase while users struggle; identify the outcome behind each metric.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-beginner-2.md: problem brief and prototype; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with problem framing and outcomes. Use the glossary below, then write your prediction for: A task tool aims to reduce lost follow-ups, not merely increase button clicks. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Product Engineer / Technical Product Manager role interview. Explain problem framing and outcomes using this case: A task tool aims to reduce lost follow-ups, not merely increase button clicks. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate problem framing and outcomes to a system or workflow you know. Explain problem framing and outcomes using this case: A task tool aims to reduce lost follow-ups, not merely increase button clicks. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Activity metrics can increase while users struggle; identify the outcome behind each metric.

Interview: Explain problem framing and outcomes using this case: A task tool aims to reduce lost follow-ups, not merely increase button clicks. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A task tool aims to reduce lost follow-ups, not merely increase button clicks.

A falsifiable hypothesis and a prototype tied to it.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

Reference: A falsifiable hypothesis and a prototype tied to it. — A feature is a hypothesis about improving a user's outcome. Define the user, problem frequency and success measure before choosing an implementation. A falsifiable hypothesis and a prototype tied to it.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## intermediate

Prerequisite: Explain the beginner concepts and reproduce the first lab before proceeding.

Terms:

Traceability: Connect a user need to the proposed change, its test and its evidence.

Apply traceability in Product Engineer / Technical Product Manager: Use the concept to complete this role exercise: Design a small experiment with success and guardrail metrics

Experiments and guardrails: An experiment needs a comparison, assignment method and decision rule. Guardrails protect outcomes that could worsen while the primary metric improves.

### Traceability

Connect a user need to the proposed change, its test and its evidence. In this role, work through: A shorter form may improve completion while increasing invalid requests. The practical workshop develops this into: Design an A/B or staged pilot with completion and invalid-request rates, sample assumptions and a stop rule. Use synthetic data to calculate both metrics and mark it as simulated.

Mental model: Labels connect a parcel to its order and delivery receipt.

Boundary: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Role application: A new route is useful only if it saves time without increasing accidents.

An experiment needs a comparison, assignment method and decision rule. Guardrails protect outcomes that could worsen while the primary metric improves.

Worked example: A shorter form may improve completion while increasing invalid requests.

Shared foundation example: Need R1 points to screen S1, test T1 and a recorded observation.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Explain the beginner concepts and reproduce the first lab before proceeding.

Tools for this exercise: Document or text editor

Course tool and framework map: Issue tracking, analytics definitions and prototypes (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Product Engineer / Technical Product Manager: A shorter form may improve completion while increasing invalid requests.

Predict the worked case

Read this case without running a tool: A shorter form may improve completion while increasing invalid requests. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in traceability.

Connect the concept to the role

Apply this rule: Connect a user need to the proposed change, its test and its evidence. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: More documents do not guarantee useful evidence; keep the chain short and verifiable.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies traceability to this case: A shorter form may improve completion while increasing invalid requests. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A shorter form may improve completion while increasing invalid requests. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Traceability; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with traceability. Use the glossary below, then write your prediction for: A shorter form may improve completion while increasing invalid requests. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Product Engineer / Technical Product Manager role interview. Explain traceability using this case: A shorter form may improve completion while increasing invalid requests. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate traceability to a system or workflow you know. Explain traceability using this case: A shorter form may improve completion while increasing invalid requests. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: How would you identify which tests are affected by a changed requirement?

Interview: Explain traceability using this case: A shorter form may improve completion while increasing invalid requests. State the evidence, one alternative and where the mental model stops.

Quiz: After the Experiments and guardrails rehearsal, check this foundation: A requirement changes. What evidence helps identify affected checks?

The total number of screenshots in the project.

Links from the requirement to its design, test cases and recorded results.

Only the latest file modification time.

Reference: Links from the requirement to its design, test cases and recorded results. — Traceability connects a need to the change and its verification; documents without those links do not establish impact.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Experiments and guardrails

An experiment needs a comparison, assignment method and decision rule. Guardrails protect outcomes that could worsen while the primary metric improves. In this role, work through: A shorter form may improve completion while increasing invalid requests. The practical workshop develops this into: Design an A/B or staged pilot with completion and invalid-request rates, sample assumptions and a stop rule. Use synthetic data to calculate both metrics and mark it as simulated.

Mental model: A new route is useful only if it saves time without increasing accidents.

Boundary: Do not describe an uncontrolled before/after comparison as proof of causation.

Worked example: A shorter form may improve completion while increasing invalid requests.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Issue tracking, analytics definitions and prototypes (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Product Engineer / Technical Product Manager workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Design an A/B or staged pilot with completion and invalid-request rates, sample assumptions and a stop rule. Use synthetic data to calculate both metrics and mark it as simulated.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

A shorter form may improve completion while increasing invalid requests. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Design an A/B or staged pilot with completion and invalid-request rates, sample assumptions and a stop rule. Use synthetic data to calculate both metrics and mark it as simulated.

Expected: A decision table that considers benefit and harm together.

Role workshop · debug and verify

Do not describe an uncontrolled before/after comparison as proof of causation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save experiment plan and metric worksheet. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A decision table that considers benefit and harm together.

Expected: A decision table that considers benefit and harm together.

Troubleshoot: The role exercise differs from the prediction: Do not describe an uncontrolled before/after comparison as proof of causation.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-intermediate-2.md: experiment plan and metric worksheet; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with experiments and guardrails. Use the glossary below, then write your prediction for: A shorter form may improve completion while increasing invalid requests. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Product Engineer / Technical Product Manager role interview. Explain experiments and guardrails using this case: A shorter form may improve completion while increasing invalid requests. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate experiments and guardrails to a system or workflow you know. Explain experiments and guardrails using this case: A shorter form may improve completion while increasing invalid requests. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not describe an uncontrolled before/after comparison as proof of causation.

Interview: Explain experiments and guardrails using this case: A shorter form may improve completion while increasing invalid requests. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A shorter form may improve completion while increasing invalid requests.

Ignore the failing case and keep only the successful screenshot.

A decision table that considers benefit and harm together.

Treat any successful command as proof that all business and access rules passed.

Reference: A decision table that considers benefit and harm together. — An experiment needs a comparison, assignment method and decision rule. Guardrails protect outcomes that could worsen while the primary metric improves. A decision table that considers benefit and harm together.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

## advanced

Prerequisite: Complete intermediate work and explain its test evidence and limitations.

Terms:

Release decision and ownership: Document the evidence, remaining risk, responsible owner and recovery trigger for a change.

Apply release decision and ownership in Product Engineer / Technical Product Manager: Use the concept to complete this role exercise: Make a ship/hold decision using evidence and explicit uncertainty

Ship, hold and learn: A release decision combines user evidence, reliability, security and operational cost. State uncertainty and what will be monitored after launch.

### Release decision and ownership

Document the evidence, remaining risk, responsible owner and recovery trigger for a change. In this role, work through: A useful prototype with a data-loss defect should be held until recovery is addressed. The practical workshop develops this into: Create a launch review with five evidence categories, unresolved risks, owners and a rollback trigger. Draft a post-launch review agenda and one resume bullet limited to work actually performed.

Mental model: A flight checklist has an accountable pilot and reasons to delay departure.

Boundary: A checklist supports judgment; it does not transfer accountability to a tool.

Role application: Opening a new service includes a plan for learning from the first customers.

A release decision combines user evidence, reliability, security and operational cost. State uncertainty and what will be monitored after launch.

Worked example: A useful prototype with a data-loss defect should be held until recovery is addressed.

Shared foundation example: Hold a release if unauthorized users can export records, even if basic navigation works.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete intermediate work and explain its test evidence and limitations.

Tools for this exercise: Document or text editor

Course tool and framework map: Issue tracking, analytics definitions and prototypes (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Product Engineer / Technical Product Manager: A useful prototype with a data-loss defect should be held until recovery is addressed.

Predict the worked case

Read this case without running a tool: A useful prototype with a data-loss defect should be held until recovery is addressed. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in release decision and ownership.

Connect the concept to the role

Apply this rule: Document the evidence, remaining risk, responsible owner and recovery trigger for a change. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A checklist supports judgment; it does not transfer accountability to a tool.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies release decision and ownership to this case: A useful prototype with a data-loss defect should be held until recovery is addressed. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A useful prototype with a data-loss defect should be held until recovery is addressed. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Release decision and ownership; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with release decision and ownership. Use the glossary below, then write your prediction for: A useful prototype with a data-loss defect should be held until recovery is addressed. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Product Engineer / Technical Product Manager role interview. Explain release decision and ownership using this case: A useful prototype with a data-loss defect should be held until recovery is addressed. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate release decision and ownership to a system or workflow you know. Explain release decision and ownership using this case: A useful prototype with a data-loss defect should be held until recovery is addressed. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: What would make a conditional approval expire?

Interview: Explain release decision and ownership using this case: A useful prototype with a data-loss defect should be held until recovery is addressed. State the evidence, one alternative and where the mental model stops.

Quiz: After the Ship, hold and learn rehearsal, check this foundation: A release has a known access-control defect but basic navigation passes. What should the decision include?

Only the navigation pass count.

An anonymous approval with no recovery trigger.

The defect evidence, impact, accountable owner and explicit release or hold criteria.

Reference: The defect evidence, impact, accountable owner and explicit release or hold criteria. — A release decision needs evidence and ownership. Basic checks do not cancel a serious unresolved risk.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys

### Ship, hold and learn

A release decision combines user evidence, reliability, security and operational cost. State uncertainty and what will be monitored after launch. In this role, work through: A useful prototype with a data-loss defect should be held until recovery is addressed. The practical workshop develops this into: Create a launch review with five evidence categories, unresolved risks, owners and a rollback trigger. Draft a post-launch review agenda and one resume bullet limited to work actually performed.

Mental model: Opening a new service includes a plan for learning from the first customers.

Boundary: A compelling demo cannot substitute for operational readiness.

Worked example: A useful prototype with a data-loss defect should be held until recovery is addressed.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: Issue tracking, analytics definitions and prototypes (Mixed licensing); Git (Open source); Visual Studio Code (Commercial distribution / open-source core)

Part A is the shared foundation and setup. Part B is the required Product Engineer / Technical Product Manager workshop below. Reference checks validate the supplied foundation; write and run the additional checks for your changed implementation. Cloud, device and commercial-platform work requires the environment specified in the task.

Create a launch review with five evidence categories, unresolved risks, owners and a rollback trigger. Draft a post-launch review agenda and one resume bullet limited to work actually performed.

Open the workbook

Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.

Expected: A clear user, problem, scope and acceptance example.

Gather evidence

Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.

Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

Review as another person

Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.

Expected: A dated revision note, one explicit limitation and a reproducible next action.

Role workshop · predict

A useful prototype with a data-loss defect should be held until recovery is addressed. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.

Expected: A prediction tied to the business or technical contract, before implementation.

Role workshop · build

Create a launch review with five evidence categories, unresolved risks, owners and a rollback trigger. Draft a post-launch review agenda and one resume bullet limited to work actually performed.

Expected: A concrete ship/hold decision with conditions and next evidence.

Role workshop · debug and verify

A compelling demo cannot substitute for operational readiness. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.

Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

Role workshop · package the evidence

Save launch decision and learning plan. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.

Expected: A concrete ship/hold decision with conditions and next evidence.

Expected: A concrete ship/hold decision with conditions and next evidence.

Troubleshoot: The role exercise differs from the prediction: A compelling demo cannot substitute for operational readiness.

Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Deliverable: lesson-advanced-2.md: launch decision and learning plan; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with ship, hold and learn. Use the glossary below, then write your prediction for: A useful prototype with a data-loss defect should be held until recovery is addressed. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Product Engineer / Technical Product Manager role interview. Explain ship, hold and learn using this case: A useful prototype with a data-loss defect should be held until recovery is addressed. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate ship, hold and learn to a system or workflow you know. Explain ship, hold and learn using this case: A useful prototype with a data-loss defect should be held until recovery is addressed. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the expected result before running the exercise, then diagnose this failure: A compelling demo cannot substitute for operational readiness.

Interview: Explain ship, hold and learn using this case: A useful prototype with a data-loss defect should be held until recovery is addressed. State the evidence, one alternative and where the mental model stops.

Quiz: For this case, which result meets the contract? A useful prototype with a data-loss defect should be held until recovery is addressed.

Treat any successful command as proof that all business and access rules passed.

Ignore the failing case and keep only the successful screenshot.

A concrete ship/hold decision with conditions and next evidence.

Reference: A concrete ship/hold decision with conditions and next evidence. — A release decision combines user evidence, reliability, security and operational cost. State uncertainty and what will be monitored after launch. A concrete ship/hold decision with conditions and next evidence.

Sources:

W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/

GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions

Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner

SAP Learning Journeys: https://learning.sap.com/learning-journeys
