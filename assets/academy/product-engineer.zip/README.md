# Product Engineer / Technical Product Manager

Software Engineering

Start with problem framing and outcomes. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward launch decision and learning plan.

## beginner

Write a problem statement, three interview prompts and a baseline measurement plan. Build a small task-form prototype and state what evidence would disprove the idea.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Acceptance criteria
Describe an observable result that determines whether a requirement has been met.
Mental model: A delivery receipt lists what must arrive, not just that a truck drove.
Limit: Criteria need stakeholder review; they can be precise and still solve the wrong problem.
Example: Given an empty title, submitting a request shows an error and creates no ticket.
Recall: Turn “make it easier” into a measurable task outcome.

### Problem framing and outcomes
A feature is a hypothesis about improving a user's outcome. Define the user, problem frequency and success measure before choosing an implementation.
Mental model: A medicine is selected for a diagnosed problem, not because the bottle looks impressive.
Limit: Activity metrics can increase while users struggle; identify the outcome behind each metric.
Example: A task tool aims to reduce lost follow-ups, not merely increase button clicks.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Activity metrics can increase while users struggle; identify the outcome behind each metric.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A task tool aims to reduce lost follow-ups, not merely increase button clicks. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Write a problem statement, three interview prompts and a baseline measurement plan. Build a small task-form prototype and state what evidence would disprove the idea.
Expected: A falsifiable hypothesis and a prototype tied to it.

6. Role workshop · debug and verify
Activity metrics can increase while users struggle; identify the outcome behind each metric. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save problem brief and prototype. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A falsifiable hypothesis and a prototype tied to it.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Problem framing and outcomes: Activity metrics can increase while users struggle; identify the outcome behind each metric.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: problem brief and prototype
A falsifiable hypothesis and a prototype tied to it.

Interview: Work through this Product Engineer / Technical Product Manager case: A task tool aims to reduce lost follow-ups, not merely increase button clicks. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A feature is a hypothesis about improving a user's outcome. Define the user, problem frequency and success measure before choosing an implementation. Expected evidence: A falsifiable hypothesis and a prototype tied to it. Diagnosis: Activity metrics can increase while users struggle; identify the outcome behind each metric. State the limits of the mental model: A medicine is selected for a diagnosed problem, not because the bottle looks impressive.

Resume: Built problem brief and prototype using Issue tracking, analytics definitions and prototypes; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Design an A/B or staged pilot with completion and invalid-request rates, sample assumptions and a stop rule. Use synthetic data to calculate both metrics and mark it as simulated.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Traceability
Connect a user need to the proposed change, its test and its evidence.
Mental model: Labels connect a parcel to its order and delivery receipt.
Limit: More documents do not guarantee useful evidence; keep the chain short and verifiable.
Example: Need R1 points to screen S1, test T1 and a recorded observation.
Recall: How would you identify which tests are affected by a changed requirement?

### Experiments and guardrails
An experiment needs a comparison, assignment method and decision rule. Guardrails protect outcomes that could worsen while the primary metric improves.
Mental model: A new route is useful only if it saves time without increasing accidents.
Limit: Do not describe an uncontrolled before/after comparison as proof of causation.
Example: A shorter form may improve completion while increasing invalid requests.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Do not describe an uncontrolled before/after comparison as proof of causation.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A shorter form may improve completion while increasing invalid requests. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Design an A/B or staged pilot with completion and invalid-request rates, sample assumptions and a stop rule. Use synthetic data to calculate both metrics and mark it as simulated.
Expected: A decision table that considers benefit and harm together.

6. Role workshop · debug and verify
Do not describe an uncontrolled before/after comparison as proof of causation. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save experiment plan and metric worksheet. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A decision table that considers benefit and harm together.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Experiments and guardrails: Do not describe an uncontrolled before/after comparison as proof of causation.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: experiment plan and metric worksheet
A decision table that considers benefit and harm together.

Interview: Work through this Product Engineer / Technical Product Manager case: A shorter form may improve completion while increasing invalid requests. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: An experiment needs a comparison, assignment method and decision rule. Guardrails protect outcomes that could worsen while the primary metric improves. Expected evidence: A decision table that considers benefit and harm together. Diagnosis: Do not describe an uncontrolled before/after comparison as proof of causation. State the limits of the mental model: A new route is useful only if it saves time without increasing accidents.

Resume: Built experiment plan and metric worksheet using Issue tracking, analytics definitions and prototypes; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Create a launch review with five evidence categories, unresolved risks, owners and a rollback trigger. Draft a post-launch review agenda and one resume bullet limited to work actually performed.

Setup: Use a text editor or spreadsheet. No code execution is required. Vendor learning environments are optional extensions and may require an account or paid access; use synthetic data only. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Release decision and ownership
Document the evidence, remaining risk, responsible owner and recovery trigger for a change.
Mental model: A flight checklist has an accountable pilot and reasons to delay departure.
Limit: A checklist supports judgment; it does not transfer accountability to a tool.
Example: Hold a release if unauthorized users can export records, even if basic navigation works.
Recall: What would make a conditional approval expire?

### Ship, hold and learn
A release decision combines user evidence, reliability, security and operational cost. State uncertainty and what will be monitored after launch.
Mental model: Opening a new service includes a plan for learning from the first customers.
Limit: A compelling demo cannot substitute for operational readiness.
Example: A useful prototype with a data-loss defect should be held until recovery is addressed.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A compelling demo cannot substitute for operational readiness.

1. Open the workbook
Open workbook.md. Use a fictional service request from a new employee who cannot access a team application.
Expected: A clear user, problem, scope and acceptance example.

2. Gather evidence
Beginner: draw the request-to-resolution workflow. Intermediate: fill five input/expected/observed cases. Advanced: fill the release decision with owner, threshold and recovery.
Expected: All fields for the chosen level are complete; proposed observations are marked as proposed.

3. Review as another person
Try to follow the artifact without guessing. Find one ambiguity, revise it and record the change.
Expected: A dated revision note, one explicit limitation and a reproducible next action.

4. Role workshop · predict
A useful prototype with a data-loss defect should be held until recovery is addressed. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create a launch review with five evidence categories, unresolved risks, owners and a rollback trigger. Draft a post-launch review agenda and one resume bullet limited to work actually performed.
Expected: A concrete ship/hold decision with conditions and next evidence.

6. Role workshop · debug and verify
A compelling demo cannot substitute for operational readiness. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save launch decision and learning plan. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: A concrete ship/hold decision with conditions and next evidence.

Troubleshooting:
Command not found: Check the official installation guide. Close and reopen the terminal after installation. Verify the version command before continuing.
File not found: Check the working directory. List files and confirm the named file is inside the extracted pack.
Assertion or expected result fails: Record the exact command, input and error. Compare your changed file with a fresh copy of the reference; do not delete evidence.
Ship, hold and learn: A compelling demo cannot substitute for operational readiness.
Cleanup: The reference uses synthetic data. Keep your evidence, then remove only your extracted practice folder if you want to start again.

Portfolio: launch decision and learning plan
A concrete ship/hold decision with conditions and next evidence.

Interview: Work through this Product Engineer / Technical Product Manager case: A useful prototype with a data-loss defect should be held until recovery is addressed. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A release decision combines user evidence, reliability, security and operational cost. State uncertainty and what will be monitored after launch. Expected evidence: A concrete ship/hold decision with conditions and next evidence. Diagnosis: A compelling demo cannot substitute for operational readiness. State the limits of the mental model: Opening a new service includes a plan for learning from the first customers.

Resume: Built launch decision and learning plan using Issue tracking, analytics definitions and prototypes; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
W3C accessibility tutorials: https://www.w3.org/WAI/tutorials/
GitHub Actions: workflows, jobs and steps: https://docs.github.com/en/actions/get-started/understand-github-actions
Salesforce: developer beginner trail: https://trailhead.salesforce.com/content/learn/trails/force_com_dev_beginner
SAP Learning Journeys: https://learning.sap.com/learning-journeys
