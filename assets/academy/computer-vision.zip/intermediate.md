## intermediate — Transform consistency

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, linear algebra, image data and supervised-learning evaluation.

### Transform consistency
Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics.
Mental model: A map and its location pins must be resized together.
Boundary: A tensor with the expected shape can still contain incorrectly interpreted pixels.
Worked example: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Visual inspection model with abstention
Build an image classifier and inspect how lighting and background changes affect its decisions. Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.
Worked example: Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Recall: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. Identify one observation that would contradict your claim.

### Terms
Transform consistency: Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
tensor: A multidimensional array of values with a shape and data type.
abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Lab
Use Python 3.11+ and Pillow for the included image fixture generator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an image classifier and inspect how lighting and background changes affect its decisions. Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path. Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and Pillow for the included image fixture generator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python image_starter.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path.

2. Prepare the project inputs
Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The evaluation protocol forbids any scene identity from appearing in both training and test data. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Training learns background: inspect grouped splits and counterfactual images.
ONNX mismatch: compare preprocessing, opset and output interpretation.
Invalid image: decode and validate format before processing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.

### Portfolio
Build an image classifier and inspect how lighting and background changes affect its decisions.
Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.
Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.
Deliverables: Image manifest and training pipeline; Model card with corruption analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Computer-vision engineer. Use this scenario: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Review: Start with the task and permitted scope. Explain transform consistency: Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics. Show the input and observed output, then address Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Image manifest and training pipeline; Model card with corruption analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

