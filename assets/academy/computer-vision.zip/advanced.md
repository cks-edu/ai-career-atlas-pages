## advanced — Domain shift in vision

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Domain shift in vision
Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review.
Mental model: A driver trained only on sunny roads needs testing in rain.
Boundary: Digital perturbations do not represent every physical-world condition.
Worked example: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Visual inspection model with abstention
Build an image classifier and inspect how lighting and background changes affect its decisions. Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.
Worked example: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Recall: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. Identify one observation that would contradict your claim.

### Terms
Domain shift in vision: Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Lab
Use Python 3.11+ and Pillow for the included image fixture generator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an image classifier and inspect how lighting and background changes affect its decisions. Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path. Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and Pillow for the included image fixture generator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python image_starter.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path.

2. Prepare the project inputs
Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Training learns background: inspect grouped splits and counterfactual images.
ONNX mismatch: compare preprocessing, opset and output interpretation.
Invalid image: decode and validate format before processing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.

### Portfolio
Build an image classifier and inspect how lighting and background changes affect its decisions.
Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.
Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated.
Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.
Test a new capture session as an external validation set.
Deliverables: Image manifest and training pipeline; Model card with corruption analysis; ONNX parity report and review demo. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A reviewer must reproduce one result and identify which capabilities you implemented. Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

### Interview
Explain your advanced solution for Computer-vision engineer. Use this scenario: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Review: Start with the task and permitted scope. Explain domain shift in vision: Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review. Show the input and observed output, then address Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Image manifest and training pipeline; Model card with corruption analysis; ONNX parity report and review demo. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

