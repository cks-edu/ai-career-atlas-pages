# Computer-vision engineer

AI Engineering · Beginner → Intermediate → Advanced

Start with Image labels and splits. Labels describe the answer a model is meant to learn. Near-identical images in training and testing can make results misleading. Then try Plan an image split. The three levels build toward Visual inspection model with abstention. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Image labels and splits

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Image labels and splits
Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation.
Mental model: A photo album should not be divided so two copies of one photo count as unseen evidence.
Boundary: Synthetic shapes are useful for code checks but not proof of real-world vision performance.
Worked example: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A model sees the same scene twice
The evaluation protocol forbids any scene identity from appearing in both training and test data. Three reported evaluations leak scene identity across the split. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Split by scene or object group before augmentation and model selection.
Recall: Evaluate unseen cameras and lighting conditions; report per-class misses and false alarms. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Image labels and splits: Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Labels describe the answer a model is meant to learn. Near-identical images in training and testing can make results misleading.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine six photos: three of the same red mug from one camera and three of a different blue mug from another camera.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An image-group table and an honest evaluation limitation.

3. Try step 2
Group photos by object and camera before assigning training and testing sets.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An image-group table and an honest evaluation limitation.

4. Try step 3
Explain why splitting each near-duplicate group across both sets would not demonstrate performance on new objects; list extra data you would need.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An image-group table and an honest evaluation limitation.

5. Explain and check your result
You identify object/camera overlap and the tiny sample’s limits rather than claiming general accuracy. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An image-group table and an honest evaluation limitation. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The evaluation protocol forbids any scene identity from appearing in both training and test data. Apply this toy-case rule manually: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three reported evaluations leak scene identity across the split. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Computer-vision engineer.
Imagine six photos: three of the same red mug from one camera and three of a different blue mug from another camera.
Group photos by object and camera before assigning training and testing sets.
Explain why splitting each near-duplicate group across both sets would not demonstrate performance on new objects; list extra data you would need.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An image-group table and an honest evaluation limitation. Include beginner-worksheet.md and your completed Scene-split audit and vision model card.
Check: You identify object/camera overlap and the tiny sample’s limits rather than claiming general accuracy.

### Interview
Explain your beginner solution for Computer-vision engineer. Use this scenario: The evaluation protocol forbids any scene identity from appearing in both training and test data.
Review: Start with the task and permitted scope. Explain image labels and splits: Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation. Show the input and observed output, then address Split by scene or object group before augmentation and model selection. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An image-group table and an honest evaluation limitation. Include beginner-worksheet.md and your completed Scene-split audit and vision model card.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Transform consistency

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, linear algebra, image data and supervised-learning evaluation.

### Transform consistency
Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics.
Mental model: A map and its location pins must be resized together.
Boundary: A tensor with the expected shape can still contain incorrectly interpreted pixels.
Worked example: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: Visual inspection model with abstention
Build an image classifier and inspect how lighting and background changes affect its decisions. Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.
Worked example: Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Recall: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. Identify one observation that would contradict your claim.

### Terms
Transform consistency: Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
tensor: A multidimensional array of values with a shape and data type.
abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Lab
Use Python 3.11+ and Pillow for the included image fixture generator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an image classifier and inspect how lighting and background changes affect its decisions. Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path. Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and Pillow for the included image fixture generator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python image_starter.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path.

2. Prepare the project inputs
Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The evaluation protocol forbids any scene identity from appearing in both training and test data. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Training learns background: inspect grouped splits and counterfactual images.
ONNX mismatch: compare preprocessing, opset and output interpretation.
Invalid image: decode and validate format before processing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.

### Portfolio
Build an image classifier and inspect how lighting and background changes affect its decisions.
Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.
Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.
Deliverables: Image manifest and training pipeline; Model card with corruption analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for Computer-vision engineer. Use this scenario: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Review: Start with the task and permitted scope. Explain transform consistency: Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics. Show the input and observed output, then address Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Image manifest and training pipeline; Model card with corruption analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Domain shift in vision

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Domain shift in vision
Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review.
Mental model: A driver trained only on sunny roads needs testing in rain.
Boundary: Digital perturbations do not represent every physical-world condition.
Worked example: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: Visual inspection model with abstention
Build an image classifier and inspect how lighting and background changes affect its decisions. Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.
Worked example: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Recall: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. Identify one observation that would contradict your claim.

### Terms
Domain shift in vision: Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Lab
Use Python 3.11+ and Pillow for the included image fixture generator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build an image classifier and inspect how lighting and background changes affect its decisions. Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path. Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and Pillow for the included image fixture generator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python image_starter.py
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path.

2. Prepare the project inputs
Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Training learns background: inspect grouped splits and counterfactual images.
ONNX mismatch: compare preprocessing, opset and output interpretation.
Invalid image: decode and validate format before processing.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.

### Portfolio
Build an image classifier and inspect how lighting and background changes affect its decisions.
Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.
Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.
Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated.
Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.
Test a new capture session as an external validation set.
Deliverables: Image manifest and training pipeline; Model card with corruption analysis; ONNX parity report and review demo. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A reviewer must reproduce one result and identify which capabilities you implemented. Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

### Interview
Explain your advanced solution for Computer-vision engineer. Use this scenario: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.
Review: Start with the task and permitted scope. Explain domain shift in vision: Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review. Show the input and observed output, then address Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Image manifest and training pipeline; Model card with corruption analysis; ONNX parity report and review demo. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
PyTorch — Open source · hardware dependent
Tensor operations, training and hardware-aware profiling.
Alternative: JAX or TensorFlow (open source); accelerator support, numerical behavior and ecosystem differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

Pillow — Open source
Image validation, generation and controlled transformations.
Alternative: OpenCV (open source) for broader vision operations; image color order and transforms need explicit checks.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

ONNX Runtime — Open source
Local exported-model inference and parity checks.
Alternative: Native framework inference or platform runtimes such as Core ML; supported operators and devices differ.
Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html
Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html
ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html
Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome
PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html
ONNX Runtime: https://onnxruntime.ai/docs/
