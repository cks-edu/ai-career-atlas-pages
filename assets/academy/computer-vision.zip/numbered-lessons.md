# Computer-vision engineer — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Image labels and splits: Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Image labels and splits

Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation. In this role, work through: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A photo album should not be divided so two copies of one photo count as unseen evidence.

Boundary: Synthetic shapes are useful for code checks but not proof of real-world vision performance.

Worked example: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); Pillow (Open source); ONNX Runtime (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Computer-vision engineer: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples.

Predict the worked case

Read this case without running a tool: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in image labels and splits.

Connect the concept to the role

Apply this rule: Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Synthetic shapes are useful for code checks but not proof of real-world vision performance.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies image labels and splits to this case: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Image labels and splits; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with image labels and splits. Use the glossary below, then write your prediction for: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Computer-vision engineer role interview. Explain image labels and splits using this case: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate image labels and splits to a system or workflow you know. Explain image labels and splits using this case: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain image labels and splits using this case: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples.

Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation. — Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation. Synthetic shapes are useful for code checks but not proof of real-world vision performance.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

### Diagnose: A model sees the same scene twice

The evaluation protocol forbids any scene identity from appearing in both training and test data. Three reported evaluations leak scene identity across the split. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Split by scene or object group before augmentation and model selection. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: A photo album should not be divided so two copies of one photo count as unseen evidence.

Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples.

Worked example: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Split by scene or object group before augmentation and model selection.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: PyTorch (Open source · hardware dependent); Pillow (Open source); ONNX Runtime (Open source)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The evaluation protocol forbids any scene identity from appearing in both training and test data. Three reported evaluations leak scene identity across the split. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The evaluation protocol forbids any scene identity from appearing in both training and test data. Apply this toy-case rule manually: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Labels describe the answer a model is meant to learn. Near-identical images in training and testing can make results misleading.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine six photos: three of the same red mug from one camera and three of a different blue mug from another camera.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An image-group table and an honest evaluation limitation.

Preparation · Try step 2

Group photos by object and camera before assigning training and testing sets.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An image-group table and an honest evaluation limitation.

Preparation · Try step 3

Explain why splitting each near-duplicate group across both sets would not demonstrate performance on new objects; list extra data you would need.

Expected: Record the input, your reasoning and the resulting part of this deliverable: An image-group table and an honest evaluation limitation.

Preparation · Explain and check your result

You identify object/camera overlap and the tiny sample’s limits rather than claiming general accuracy. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: An image-group table and an honest evaluation limitation. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The evaluation protocol forbids any scene identity from appearing in both training and test data. Apply this toy-case rule manually: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three reported evaluations leak scene identity across the split. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three reported evaluations leak scene identity across the split. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: a model sees the same scene twice. Use the glossary below, then write your prediction for: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Split by scene or object group before augmentation and model selection. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Computer-vision engineer role interview. Explain diagnose: a model sees the same scene twice using this case: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Split by scene or object group before augmentation and model selection. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: a model sees the same scene twice to a system or workflow you know. Explain diagnose: a model sees the same scene twice using this case: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Split by scene or object group before augmentation and model selection. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Evaluate unseen cameras and lighting conditions; report per-class misses and false alarms. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: a model sees the same scene twice using this case: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Split by scene or object group before augmentation and model selection. State the evidence, one alternative and where the mental model stops.

Quiz: A model sees the same scene twice: The evaluation protocol forbids any scene identity from appearing in both training and test data.

Change the acceptance rule after seeing an inconvenient result.

Split by scene or object group before augmentation and model selection.

Omit failed cases and report only the successful demonstrations.

Reference: Split by scene or object group before augmentation and model selection. — Split by scene or object group before augmentation and model selection. Evaluate unseen cameras and lighting conditions; report per-class misses and false alarms.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, linear algebra, image data and supervised-learning evaluation.

Terms:

Transform consistency: Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

tensor: A multidimensional array of values with a shape and data type.

abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Transform consistency

Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics. In this role, work through: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A map and its location pins must be resized together.

Boundary: A tensor with the expected shape can still contain incorrectly interpreted pixels.

Worked example: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Python, linear algebra, image data and supervised-learning evaluation.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); Pillow (Open source); ONNX Runtime (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Computer-vision engineer: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result.

Predict the worked case

Read this case without running a tool: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in transform consistency.

Connect the concept to the role

Apply this rule: Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A tensor with the expected shape can still contain incorrectly interpreted pixels.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies transform consistency to this case: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Transform consistency; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with transform consistency. Use the glossary below, then write your prediction for: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Computer-vision engineer role interview. Explain transform consistency using this case: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate transform consistency to a system or workflow you know. Explain transform consistency using this case: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain transform consistency using this case: An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result.

Treat a passing starter as proof of the whole role workflow.

Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics.

Ignore the failure because the tool produced an output.

Reference: Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics. — Keep image transformations and label coordinates aligned. Record color format, scaling and orientation, and verify them visually before trusting model metrics. A tensor with the expected shape can still contain incorrectly interpreted pixels.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

### Integrate: Visual inspection model with abstention

Build an image classifier and inspect how lighting and background changes affect its decisions. Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error. In this role, work through: Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.

Role application: A map and its location pins must be resized together.

An image is flipped horizontally; move the bounding boxes too and render an overlay to inspect the result.

Worked example: Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.

Setup: Use Python 3.11+ and Pillow for the included image fixture generator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PyTorch (Open source · hardware dependent); Pillow (Open source); ONNX Runtime (Open source)

Build an image classifier and inspect how lighting and background changes affect its decisions. Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path. Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.

Build an image classifier and inspect how lighting and background changes affect its decisions.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and Pillow for the included image fixture generator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python image_starter.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path.

Prepare the project inputs

Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The evaluation protocol forbids any scene identity from appearing in both training and test data. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.

Deliverable: lesson-intermediate-2.md: Image manifest and training pipeline; Model card with corruption analysis. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: visual inspection model with abstention. Use the glossary below, then write your prediction for: Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Computer-vision engineer role interview. Explain integrate: visual inspection model with abstention using this case: Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: visual inspection model with abstention to a system or workflow you know. Explain integrate: visual inspection model with abstention using this case: Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. Identify one observation that would contradict your claim.

Interview: Explain integrate: visual inspection model with abstention using this case: Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Visual inspection model with abstention at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.

Reference: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. — Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Domain shift in vision: Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

abstention: Explicitly declining to provide an answer or decision when the required evidence or confidence is insufficient.

### Domain shift in vision

Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review. In this role, work through: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A driver trained only on sunny roads needs testing in rain.

Boundary: Digital perturbations do not represent every physical-world condition.

Worked example: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: PyTorch (Open source · hardware dependent); Pillow (Open source); ONNX Runtime (Open source)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for Computer-vision engineer: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report.

Predict the worked case

Read this case without running a tool: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in domain shift in vision.

Connect the concept to the role

Apply this rule: Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Digital perturbations do not represent every physical-world condition.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies domain shift in vision to this case: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Domain shift in vision; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with domain shift in vision. Use the glossary below, then write your prediction for: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Computer-vision engineer role interview. Explain domain shift in vision using this case: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate domain shift in vision to a system or workflow you know. Explain domain shift in vision using this case: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain domain shift in vision using this case: A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review.

Reference: Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review. — Test changes in lighting, viewpoint, camera and background separately. Report subgroup failures and decide when the system should ask for review. Digital perturbations do not represent every physical-world condition.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/

### Defend: Visual inspection model with abstention

Build an image classifier and inspect how lighting and background changes affect its decisions. Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated. In this role, work through: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.

Role application: A driver trained only on sunny roads needs testing in rain.

A detector works on bright tabletop images but misses objects in shadows; keep that condition visible in the evaluation report.

Worked example: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

Setup: Use Python 3.11+ and Pillow for the included image fixture generator. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: PyTorch (Open source · hardware dependent); Pillow (Open source); ONNX Runtime (Open source)

Build an image classifier and inspect how lighting and background changes affect its decisions. Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path. Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.

Build an image classifier and inspect how lighting and background changes affect its decisions.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Use Python 3.11+ and Pillow for the included image fixture generator. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.

```
cd project
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python image_starter.py
```

Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path.

Prepare the project inputs

Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. A reviewer must reproduce one result and identify which capabilities you implemented. Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.

Deliverable: lesson-advanced-2.md: Image manifest and training pipeline; Model card with corruption analysis; ONNX parity report and review demo. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: visual inspection model with abstention. Use the glossary below, then write your prediction for: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the Computer-vision engineer role interview. Explain defend: visual inspection model with abstention using this case: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: visual inspection model with abstention to a system or workflow you know. Explain defend: visual inspection model with abstention using this case: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline. Identify one observation that would contradict your claim.

Interview: Explain defend: visual inspection model with abstention using this case: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate Visual inspection model with abstention at this level?

Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object. — Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object. Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.

Sources:

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html

Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html

ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html

Hugging Face Computer Vision Course: https://huggingface.co/learn/computer-vision-course/unit0/welcome/welcome

PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/intro.html

ONNX Runtime: https://onnxruntime.ai/docs/
