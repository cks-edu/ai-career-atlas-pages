## beginner — Image labels and splits

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Image labels and splits
Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation.
Mental model: A photo album should not be divided so two copies of one photo count as unseen evidence.
Boundary: Synthetic shapes are useful for code checks but not proof of real-world vision performance.
Worked example: Frames from one video remain in one split; document image size, label meanings and excluded ambiguous examples.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: A model sees the same scene twice
The evaluation protocol forbids any scene identity from appearing in both training and test data. Three reported evaluations leak scene identity across the split. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Split by scene or object group before augmentation and model selection.
Recall: Evaluate unseen cameras and lighting conditions; report per-class misses and false alarms. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Image labels and splits: Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Labels describe the answer a model is meant to learn. Near-identical images in training and testing can make results misleading.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine six photos: three of the same red mug from one camera and three of a different blue mug from another camera.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An image-group table and an honest evaluation limitation.

3. Try step 2
Group photos by object and camera before assigning training and testing sets.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An image-group table and an honest evaluation limitation.

4. Try step 3
Explain why splitting each near-duplicate group across both sets would not demonstrate performance on new objects; list extra data you would need.
Expected: Record the input, your reasoning and the resulting part of this deliverable: An image-group table and an honest evaluation limitation.

5. Explain and check your result
You identify object/camera overlap and the tiny sample’s limits rather than claiming general accuracy. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: An image-group table and an honest evaluation limitation. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The evaluation protocol forbids any scene identity from appearing in both training and test data. Apply this toy-case rule manually: Review when shared_scenes >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three reported evaluations leak scene identity across the split. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to Computer-vision engineer.
Imagine six photos: three of the same red mug from one camera and three of a different blue mug from another camera.
Group photos by object and camera before assigning training and testing sets.
Explain why splitting each near-duplicate group across both sets would not demonstrate performance on new objects; list extra data you would need.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: An image-group table and an honest evaluation limitation. Include beginner-worksheet.md and your completed Scene-split audit and vision model card.
Check: You identify object/camera overlap and the tiny sample’s limits rather than claiming general accuracy.

### Interview
Explain your beginner solution for Computer-vision engineer. Use this scenario: The evaluation protocol forbids any scene identity from appearing in both training and test data.
Review: Start with the task and permitted scope. Explain image labels and splits: Define the visual task and annotation unit before training. Keep related images together when splitting so near-identical frames do not inflate evaluation. Show the input and observed output, then address Split by scene or object group before augmentation and model selection. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [An image-group table and an honest evaluation limitation. Include beginner-worksheet.md and your completed Scene-split audit and vision model card.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

