"""Generate original synthetic images for a pipeline smoke test, not ML validation."""
import csv
from pathlib import Path
from PIL import Image,ImageDraw
Path('output/images').mkdir(parents=True,exist_ok=True)
rows=[]
for i in range(12):
    image=Image.new('RGB',(128,128),'white');draw=ImageDraw.Draw(image)
    label='circle' if i%2==0 else 'square';box=(20+i,20,100,100-i)
    (draw.ellipse if label=='circle' else draw.rectangle)(box,fill='blue')
    path=f'output/images/{i:02d}.png';image.save(path);rows.append([path,label,'synthetic-smoke-only'])
with open('output/manifest.csv','w',newline='') as f:
    writer=csv.writer(f);writer.writerow(['path','label','scope']);writer.writerows(rows)
print('Created 12 synthetic images; independent validation data still required.')
