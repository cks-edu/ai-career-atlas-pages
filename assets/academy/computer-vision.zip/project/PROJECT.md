# Visual inspection model with abstention

Career: Computer-vision engineer
Reviewed: 2026-10-22

Build an image classifier and inspect how lighting and background changes affect its decisions.

## Prerequisites
Python, linear algebra, image data and supervised-learning evaluation.

## Included starter versus your implementation
Twelve original synthetic images and a manifest generator. You implement training, export and review; synthetic shape images only smoke-test the data path.

Image generation needs only CPU. Real datasets, PyTorch and ONNX Runtime are installed separately as required by the milestones.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Use Python 3.11+ and Pillow for the included image fixture generator.

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python image_starter.py
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Generate starter images with shapes, then replace them with a licensed non-sensitive inspection dataset. Split by object or capture session to avoid near-identical train/test images.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Train a small PyTorch classifier with train-only augmentation. Save confusion matrices and inspect source images for every error.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Keep output/manifest.csv and selected image evidence; stop any training jobs when finished.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Image manifest and training pipeline — artifact-1.md
2. Model card with corruption analysis — artifact-2.md
3. ONNX parity report and review demo — artifact-3.md

## Troubleshooting
- Training learns background: inspect grouped splits and counterfactual images.
- ONNX mismatch: compare preprocessing, opset and output interpretation.
- Invalid image: decode and validate format before processing.

## Extension
Test a new capture session as an external validation set.

## Primary learning resources
- PyTorch: https://docs.pytorch.org/tutorials/beginner/basics/quickstart_tutorial.html — Open source · hardware dependent; Tensor operations, training and hardware-aware profiling.
- Pillow: https://pillow.readthedocs.io/en/stable/handbook/tutorial.html — Open source; Image validation, generation and controlled transformations.
- ONNX Runtime: https://onnxruntime.ai/docs/get-started/with-python.html — Open source; Local exported-model inference and parity checks.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
