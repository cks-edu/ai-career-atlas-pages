# ONNX parity report and review demo

Project: Visual inspection model with abstention
Status: blank work product — not completed evidence

## Purpose and audience
Build an image classifier and inspect how lighting and background changes affect its decisions.

## Required content
Export a supported model to ONNX and compare outputs on a fixed test batch. Build a review interface that shows the image and uncertainty without claiming calibrated confidence unless evaluated.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.

## Failure evidence
Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
