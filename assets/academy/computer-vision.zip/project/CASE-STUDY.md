# Visual inspection model with abstention

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Build an image classifier and inspect how lighting and background changes affect its decisions.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

## Limitations and next iteration
Test a new capture session as an external validation set.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
