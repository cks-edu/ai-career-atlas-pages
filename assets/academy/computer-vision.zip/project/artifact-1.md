# Image manifest and training pipeline

Project: Visual inspection model with abstention
Status: blank work product — not completed evidence

## Purpose and audience
Build an image classifier and inspect how lighting and background changes affect its decisions.

## Required content
Run image_starter.py to create image fixtures and a manifest. Define classes, ambiguous examples and reject conditions before training.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report per-class accuracy, corruption sensitivity, abstention coverage and CPU inference time. Synthetic shapes only validate the pipeline.

## Failure evidence
Apply brightness, blur and background changes to copies of held-out images. Check whether the model relies on shortcuts rather than the intended object.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
