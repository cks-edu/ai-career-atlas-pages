# SAMPLE — Scene-split audit and vision model card
Role: Computer-vision engineer
Case: A model sees the same scene twice
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The evaluation protocol forbids any scene identity from appearing in both training and test data.

## Evidence table
| Record | shared_scenes (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 3 | review |
| case-4 | 0 | within_demo_bound |
| case-5 | 2 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-3, case-5.
Three reported evaluations leak scene identity across the split.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Split by scene or object group before augmentation and model selection.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in computer-vision engineer.
Before release: Evaluate unseen cameras and lighting conditions; report per-class misses and false alarms.

## Design choice and trade-off
Keep correlated images grouped; evaluate deployment-relevant capture conditions.
A harder grouped split may lower scores but better reflects generalization to new scenes.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
Visual quality inspection: Report missed defects and false alarms by defect type.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
