## intermediate — Authorized adversarial tests

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Threat modeling, identity, application security and responsible assessment practices.

### Authorized adversarial tests
Test only a system and scope you are permitted to assess. Capture the exact input, expected denial and observed effect using synthetic secrets and disposable resources.
Mental model: A fire drill uses an agreed building and safe smoke, not an unannounced fire.
Boundary: Failure on one test does not measure all attack variants or real credential exposure.
Worked example: Place a fake API key in a test fixture and attempt a scoped prompt injection; check whether output or tool calls expose it.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI assistant authorization and injection testbed
Build a defensive testbed showing that untrusted content cannot grant access or authorize actions. Place authorization before retrieval and tool execution in the API. Keep model output separate from policy input and log decision IDs without sensitive content.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Local CLI only; no credentials or real tenant data are provided.
Worked example: Create fictional users, tenants, documents and tool requests. Restrict tests to your local application and explicitly allowed actions.
Recall: Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security. Identify one observation that would contradict your claim.

### Terms
Authorized adversarial tests: Test only a system and scope you are permitted to assess. Capture the exact input, expected denial and observed effect using synthetic secrets and disposable resources.
API: Application programming interface: the agreed way one program requests work or data from another.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CLI: Command-line interface: a program operated by commands in a terminal.
baseline: A simple reference method used to judge whether a more complex approach helps.
fixture: A fixed test input with a declared expected behavior; it is not evidence about all real-world cases.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Install OPA from its official distribution and use Rego v1. Run only the local policy files in this pack. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a defensive testbed showing that untrusted content cannot grant access or authorize actions. A tenant-scoped read policy and four allow/deny tests. Real identity verification, delegation, revocation and enforcement integration are tasks to implement. Local CLI only; no credentials or real tenant data are provided.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install OPA from its official distribution and use Rego v1. Run only the local policy files in this pack. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
opa version
opa test . -v
opa eval -d authz.rego -i request.json data.portfolio.authz.allow
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A tenant-scoped read policy and four allow/deny tests. Real identity verification, delegation, revocation and enforcement integration are tasks to implement.

2. Prepare the project inputs
Create fictional users, tenants, documents and tool requests. Restrict tests to your local application and explicitly allowed actions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the OPA policy tests. Extend the policy with resource ownership, action allowlists and expired approvals; default to deny on missing attributes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Place authorization before retrieval and tool execution in the API. Keep model output separate from policy input and log decision IDs without sensitive content.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The sandbox policy allows no writes authorized only by retrieved or generated text. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
Parse error: check OPA/Rego version and imports.
Unexpected allow: inspect all decision inputs and missing attributes.
Policy passes but app leaks: verify enforcement happens before retrieval/tool execution.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: No server is started. Retain test output and policy revision.

### Portfolio
Build a defensive testbed showing that untrusted content cannot grant access or authorize actions.
Create fictional users, tenants, documents and tool requests. Restrict tests to your local application and explicitly allowed actions.
Run the OPA policy tests. Extend the policy with resource ownership, action allowlists and expired approvals; default to deny on missing attributes.
Place authorization before retrieval and tool execution in the API. Keep model output separate from policy input and log decision IDs without sensitive content.
Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security.
Deliverables: Threat model and authorization implementation; Defensive test corpus with expected outcomes. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI security / red-team engineer. Use this scenario: Replay a valid action under a different tenant and place an instruction to bypass approval in a retrieved document. Both must fail at the deterministic enforcement point.
Review: Start with the task and permitted scope. Explain authorized adversarial tests: Test only a system and scope you are permitted to assess. Capture the exact input, expected denial and observed effect using synthetic secrets and disposable resources. Show the input and observed output, then address Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Threat model and authorization implementation; Defensive test corpus with expected outcomes. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

