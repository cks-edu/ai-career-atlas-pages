## advanced — Enforced mitigations

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Enforced mitigations
Place controls at execution and data boundaries, then repeat the original exploit and benign cases. Prompts can guide behavior but cannot replace authorization.
Mental model: A sign saying keep out supports a locked door but does not replace it.
Boundary: A mitigation can introduce new bypasses or block legitimate tasks.
Worked example: Add a server-side allowlist for export destinations and confirm the malicious tool call is denied while the permitted export still works.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI assistant authorization and injection testbed
Build a defensive testbed showing that untrusted content cannot grant access or authorize actions. Create a local attack corpus containing malicious document instructions, cross-tenant requests and encoded path traversal. Test the boundary even when the model proposes the forbidden action.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Local CLI only; no credentials or real tenant data are provided.
Worked example: Replay a valid action under a different tenant and place an instruction to bypass approval in a retrieved document. Both must fail at the deterministic enforcement point.
Recall: Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security. Identify one observation that would contradict your claim.

### Terms
Enforced mitigations: Place controls at execution and data boundaries, then repeat the original exploit and benign cases. Prompts can guide behavior but cannot replace authorization.
API: Application programming interface: the agreed way one program requests work or data from another.
JSON: A text format for structured data using objects, arrays, strings, numbers, booleans and null.
CLI: Command-line interface: a program operated by commands in a terminal.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

### Lab
Install OPA from its official distribution and use Rego v1. Run only the local policy files in this pack. All runtime files are in project/. Beginner case files are separate in case/. Check the official installation instructions for your operating system and hardware.
Build a defensive testbed showing that untrusted content cannot grant access or authorize actions. A tenant-scoped read policy and four allow/deny tests. Real identity verification, delegation, revocation and enforcement integration are tasks to implement. Local CLI only; no credentials or real tenant data are provided.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Install OPA from its official distribution and use Rego v1. Run only the local policy files in this pack. macOS/Linux activation is shown. On Windows use py -3 to create the environment and .venv\Scripts\Activate.ps1 in PowerShell. If a server command keeps running, leave it running and use a second terminal for requests.
```sh
cd project
opa version
opa test . -v
opa eval -d authz.rego -i request.json data.portfolio.authz.allow
```
Run from the indicated extracted directory. These commands prepare or exercise the supplied starter; role-specific implementation tasks below remain your work.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: A tenant-scoped read policy and four allow/deny tests. Real identity verification, delegation, revocation and enforcement integration are tasks to implement.

2. Prepare the project inputs
Create fictional users, tenants, documents and tool requests. Restrict tests to your local application and explicitly allowed actions.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Run the OPA policy tests. Extend the policy with resource ownership, action allowlists and expired approvals; default to deny on missing attributes.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Place authorization before retrieval and tool execution in the API. Keep model output separate from policy input and log decision IDs without sensitive content.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create a local attack corpus containing malicious document instructions, cross-tenant requests and encoded path traversal. Test the boundary even when the model proposes the forbidden action.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Replay a valid action under a different tenant and place an instruction to bypass approval in a retrieved document. Both must fail at the deterministic enforcement point.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. No server is started. Retain test output and policy revision.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
Parse error: check OPA/Rego version and imports.
Unexpected allow: inspect all decision inputs and missing attributes.
Policy passes but app leaks: verify enforcement happens before retrieval/tool execution.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: No server is started. Retain test output and policy revision.

### Portfolio
Build a defensive testbed showing that untrusted content cannot grant access or authorize actions.
Create fictional users, tenants, documents and tool requests. Restrict tests to your local application and explicitly allowed actions.
Run the OPA policy tests. Extend the policy with resource ownership, action allowlists and expired approvals; default to deny on missing attributes.
Place authorization before retrieval and tool execution in the API. Keep model output separate from policy input and log decision IDs without sensitive content.
Create a local attack corpus containing malicious document instructions, cross-tenant requests and encoded path traversal. Test the boundary even when the model proposes the forbidden action.
Replay a valid action under a different tenant and place an instruction to bypass approval in a retrieved document. Both must fail at the deterministic enforcement point.
Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security.
Add a second enforcement point at the downstream resource and test inconsistent policy versions.
Deliverables: Threat model and authorization implementation; Defensive test corpus with expected outcomes; Remediation report and regression checks. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security. A reviewer must reproduce one result and identify which capabilities you implemented. Replay a valid action under a different tenant and place an instruction to bypass approval in a retrieved document. Both must fail at the deterministic enforcement point.

### Interview
Explain your advanced solution for AI security / red-team engineer. Use this scenario: Replay a valid action under a different tenant and place an instruction to bypass approval in a retrieved document. Both must fail at the deterministic enforcement point.
Review: Start with the task and permitted scope. Explain enforced mitigations: Place controls at execution and data boundaries, then repeat the original exploit and benign cases. Prompts can guide behavior but cannot replace authorization. Show the input and observed output, then address Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Threat model and authorization implementation; Defensive test corpus with expected outcomes; Remediation report and regression checks. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

