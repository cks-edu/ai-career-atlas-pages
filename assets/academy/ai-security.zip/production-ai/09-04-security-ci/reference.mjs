function redTeamPass(cases) {
  return Array.isArray(cases) && cases.length > 0 &&
    cases.every(c=>typeof c.id === 'string' && c.id.length > 0 && c.passed === true) &&
    new Set(cases.map(c=>c.id)).size === cases.length;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(redTeamPass([{id:'normal',passed:true},{id:'attack',passed:true}]));
console.log("PASS: A distinct clean suite passes");
}
{
assert(!redTeamPass([{id:'attack',passed:false}])); assert(!redTeamPass([{id:'a',passed:true},{id:'a',passed:true}]));
console.log("PASS: One failed or duplicated case blocks");
}
{
assert(!redTeamPass([])); assert(!redTeamPass([{id:'a',passed:'true'}]));
console.log("PASS: Empty and unknown results are not success");
}
