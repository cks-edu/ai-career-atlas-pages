# Red-team cases as a repeatable release suite

An adversarial test suite turns known failure patterns into repeatable checks. Include normal authorized work as well as malicious attempts so a defense does not simply block everything. Preserve case identity and expected behavior before comparing releases.

The local gate requires unique case IDs, explicit boolean outcomes, a nonempty suite and every expected boundary check passing. It does not attack a real model or prove the test set covers every injection technique.

Task: Implement redTeamPass. Create an authorized synthetic CI case file with normal reads, forbidden egress and a changed-action approval test.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Versioned adversarial cases → candidate run → case-level checks → CI gate.
State: Case IDs and results remain attributable to one suite revision.
Boundary: The test result cannot be replaced with a model’s self-rating.
Failure: A renamed or duplicated case hides a failed boundary.
Control: Require unique case identity and explicit passing outcomes.
Observability: Retain raw outcomes, policy revision and failure traces.
Blast radius: Every release relying on the suite’s protection claims.
Trade-off: A growing suite improves regression coverage but needs maintenance and risk review.

Limit: A finite passing suite cannot certify security. Record environment, authorization, uncovered threats and real follow-up testing before deployment.

Sources:
https://genai.owasp.org/llmrisk/llm01-prompt-injection/
https://www.nist.gov/itl/ai-risk-management-framework
