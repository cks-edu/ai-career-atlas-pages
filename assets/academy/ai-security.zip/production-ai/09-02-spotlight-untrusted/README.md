# Indirect injection: label evidence, enforce permissions

Indirect prompt injection arrives through data such as documents, web pages or tool results. Labeling or delimiting that data can help the model distinguish it from instructions, but prompts alone do not guarantee separation. The executor must maintain its own permission boundary.

Create a data record whose source is explicit and whose canGrantPermission field is always false. The observation’s prose stays data. Never copy an externally supplied admin or approval flag into a trusted principal.

Task: Implement observation. Feed a fictional hostile document to a separate mock executor and show that its permissions never change.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Retrieved content → data record → model context → independently checked action.
State: Provenance is retained; authority stays outside the retrieved record.
Boundary: Third-party text cannot update the principal’s permissions.
Failure: Hidden document text tells the agent to override its instructions.
Control: Keep data labeled and enforce action authorization outside generation.
Observability: Track source IDs and rejected action proposals without exposing private content.
Blast radius: Resources reachable through any confused tool executor.
Trade-off: Clear labels aid interpretation but must not replace enforceable isolation.

Limit: Metadata can support handling and auditing; it cannot make a susceptible model immune. Use least privilege, independent action checks and adversarial tests as well.

Sources:
https://genai.owasp.org/llmrisk/llm01-prompt-injection/
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
