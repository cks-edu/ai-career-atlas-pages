# AI Security, Red-Teaming & Autonomous Guardrails

Enforce permission outside the model and test malicious inputs.

Use the in-browser Practise workbench, or extract the course ZIP and install a currently supported Node.js LTS from nodejs.org. Run each reference.mjs from its numbered production-ai folder; run starter.mjs to see the failing initial checks. No packages or model files are required.

Four synthetic JavaScript policy/state exercises execute locally. They do not run an MCP server, GPU inference, voice service or model training. Native-tool setup is optional and external to the browser.

Mental model: follow Path → State → Boundary → Failure → Control → Observability → Blast radius → Trade-off; inspect each lesson’s concrete version before changing code.

Tools and alternatives:
OWASP GenAI guidance — Open guidance · local testing. Threat modeling and authorized adversarial regression cases. Alternative: NIST AI RMF for complementary risk management.
Application policy / CI — Local code · runner cost depends on hosting. Enforce permissions and run synthetic attack fixtures before release. Alternative: Policy engines such as OPA for a larger reviewed policy surface.

Project: Build an independently changed learning artifact for AI Security, Red-Teaming & Autonomous Guardrails. Enforce permission outside the model and test malicious inputs. Use synthetic data and make the tested scope explicit.
Draw the eight-node path and identify data, authority and resource boundaries.
Implement your own changed policy using the four lessons; retain valid and invalid cases.
Inject a declared failure, capture the result, repair it and run the regression checks.
Write an ADR with options, trade-offs, source/runtime versions, limitations and a rollback/recovery decision.

The local fixtures create no external resources. Save your work and close the tab/terminal. Optional real-tool work must stop only its own servers/jobs and remove only its own stated temporary/cloud resources.
