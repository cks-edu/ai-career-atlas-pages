function trifecta(c) {
  return c.untrustedInput === true && c.privateData === true && c.externalAction === true;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(trifecta({untrustedInput:true,privateData:true,externalAction:true}));
console.log("PASS: The dangerous combination is flagged");
}
{
assert(!trifecta({untrustedInput:true,privateData:true,externalAction:false})); assert(!trifecta({untrustedInput:false,privateData:true,externalAction:true}));
console.log("PASS: Removing one capability changes this specific flag");
}
{
assert(!trifecta({})); assert(!trifecta({untrustedInput:true,privateData:false,externalAction:true}));
console.log("PASS: Missing capabilities are not invented");
}
