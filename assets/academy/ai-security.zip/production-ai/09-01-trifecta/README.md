# The dangerous combination: untrusted input, private data and external actions

An assistant that reads untrusted documents, can access private data and can send information externally has a serious exfiltration path. This combination is sometimes called the lethal trifecta. It describes a threat pattern, not a complete security taxonomy.

Model the three capabilities explicitly. If all are present, require architectural isolation before allowing the autonomous path. Other configurations can still be risky; the toy indicator identifies this combination only.

Task: Implement trifecta and draw the three permissions. Propose an architectural separation, then name one risk the detector does not cover.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Untrusted document → private retrieval → external action.
State: Three independently granted capabilities combine into a sensitive path.
Boundary: Reading an instruction in a document does not authorize exporting data.
Failure: A resume instructs an HR assistant to email private salaries.
Control: Separate private retrieval from autonomous external egress.
Observability: Trace permission grants, rejected egress and source provenance.
Blast radius: All private records reachable with the assistant’s credentials.
Trade-off: Capability isolation reduces automation convenience but contains data exposure.

Limit: A false result does not mean safe. Threat modeling must also examine authorization, tools, supply chain, storage and the actual data flow.

Sources:
https://simonwillison.net/2025/Jun/16/the-lethal-trifecta/
https://genai.owasp.org/llmrisk/llm01-prompt-injection/
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
