# Parallel guardrails must stop the side effect in time

A guardrail that detects a problem after an email is sent cannot recover the secret. Run independent checks before sensitive egress, even when answer text streams earlier. Allowlisting destinations and redacting known fields can reduce exposure, but neither is a universal PII detector.

This deliberately conservative firewall blocks send_email and network_post whenever the context includes untrusted third-party material. Only reviewed internal_lookup and summarize_local remain available. A real product can design a narrower reviewed release path without allowing document text to approve itself.

Task: Implement the firewall. Add denial cases for unknown tools and destinations. Keep approved outside model state in your architecture diagram.

Run: node reference.mjs

Expected: three PASS results. starter.mjs deliberately fails at least one contract. Preserve the checks while changing your implementation, then add your own boundary case.

Mental model:
Path: Proposed action → provenance check → tool/destination policy → execution.
State: Context sources and reviewed tool names govern the decision.
Boundary: A streamed answer does not authorize a later external side effect.
Failure: A third-party resume causes a private-data email to be sent.
Control: Deny sensitive egress from untrusted context and unknown tools.
Observability: Record blocked destination category, policy revision and source IDs.
Blast radius: Data reachable by the network/email credential.
Trade-off: Conservative blocking may require a separate human-reviewed export workflow.

Limit: A source label must come from application provenance, not model output. This local allowlist is a policy rehearsal and does not inspect real network traffic.

Sources:
https://genai.owasp.org/llmrisk/llm01-prompt-injection/
https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html
