function validateAgentAction(contextSource,toolName,payload) { return true; }

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(validateAgentAction(['third-party'],'summarize_local',{}));
console.log("PASS: Reviewed internal work remains possible");
}
{
assert(!validateAgentAction(['third-party'],'send_email',{approved:true,destination:'approved.example'})); assert(!validateAgentAction(['third-party'],'network_post',{approved:true,destination:'approved.example'}));
console.log("PASS: Third-party material cannot authorize egress");
}
{
assert(!validateAgentAction(['direct-user'],'shell',{})); assert(!validateAgentAction(['direct-user'],'send_email',{approved:true,destination:'evil.example'})); assert(validateAgentAction(['direct-user'],'send_email',{approved:true,destination:'approved.example'}));
console.log("PASS: Unknown tools, destinations and absent approval fail");
}
