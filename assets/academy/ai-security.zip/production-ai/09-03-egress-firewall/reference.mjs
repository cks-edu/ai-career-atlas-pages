function validateAgentAction(contextSource, toolName, payload) {
  // Provenance and payload.approved come from trusted application checks, never model-provided flags.
  const untrusted = contextSource.includes('third-party');
  if (!['internal_lookup','summarize_local','send_email','network_post'].includes(toolName)) return false;
  if (['send_email','network_post'].includes(toolName)) {
    return !untrusted && payload?.approved === true && payload?.destination === 'approved.example';
  }
  return true;
}

const assert=(v)=>{if(!v) throw new Error("Checkpoint failed");};
{
assert(validateAgentAction(['third-party'],'summarize_local',{}));
console.log("PASS: Reviewed internal work remains possible");
}
{
assert(!validateAgentAction(['third-party'],'send_email',{approved:true,destination:'approved.example'})); assert(!validateAgentAction(['third-party'],'network_post',{approved:true,destination:'approved.example'}));
console.log("PASS: Third-party material cannot authorize egress");
}
{
assert(!validateAgentAction(['direct-user'],'shell',{})); assert(!validateAgentAction(['direct-user'],'send_email',{approved:true,destination:'evil.example'})); assert(validateAgentAction(['direct-user'],'send_email',{approved:true,destination:'approved.example'}));
console.log("PASS: Unknown tools, destinations and absent approval fail");
}
