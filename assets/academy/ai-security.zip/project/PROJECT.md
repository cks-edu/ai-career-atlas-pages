# AI assistant authorization and injection testbed

Career: AI security / red-team engineer
Reviewed: 2026-10-22

Build a defensive testbed showing that untrusted content cannot grant access or authorize actions.

## Prerequisites
Threat modeling, identity, application security and responsible assessment practices.

## Included starter versus your implementation
A tenant-scoped read policy and four allow/deny tests. Real identity verification, delegation, revocation and enforcement integration are tasks to implement.

Local CLI only; no credentials or real tenant data are provided.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Install OPA from its official distribution and use Rego v1. Run only the local policy files in this pack.

```sh
opa version
opa test . -v
opa eval -d authz.rego -i request.json data.portfolio.authz.allow
```

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Create fictional users, tenants, documents and tool requests. Restrict tests to your local application and explicitly allowed actions.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Run the OPA policy tests. Extend the policy with resource ownership, action allowlists and expired approvals; default to deny on missing attributes.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Place authorization before retrieval and tool execution in the API. Keep model output separate from policy input and log decision IDs without sensitive content.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Create a local attack corpus containing malicious document instructions, cross-tenant requests and encoded path traversal. Test the boundary even when the model proposes the forbidden action.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Replay a valid action under a different tenant and place an instruction to bypass approval in a retrieved document. Both must fail at the deterministic enforcement point.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. No server is started. Retain test output and policy revision.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Threat model and authorization implementation — artifact-1.md
2. Defensive test corpus with expected outcomes — artifact-2.md
3. Remediation report and regression checks — artifact-3.md

## Troubleshooting
- Parse error: check OPA/Rego version and imports.
- Unexpected allow: inspect all decision inputs and missing attributes.
- Policy passes but app leaks: verify enforcement happens before retrieval/tool execution.

## Extension
Add a second enforcement point at the downstream resource and test inconsistent policy versions.

## Primary learning resources
- Open Policy Agent: https://www.openpolicyagent.org/docs/policy-testing — Open source · local CLI; Rego policy decisions and allow/deny regression tests.
- OWASP GenAI security guidance: https://genai.owasp.org/llm-top-10/ — Public guidance; Threat-model and defensive-test planning.
- FastAPI: https://fastapi.tiangolo.com/tutorial/ — Open source · local; Typed API, validation and local service tests.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
