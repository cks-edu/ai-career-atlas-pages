package portfolio.authz_test
import rego.v1
import data.portfolio.authz

test_allow if {
    authz.allow with input as {"subject":{"tenant":"a"},"resource":{"tenant":"a"},"action":"read","approved":true}
}
test_cross_tenant_denied if {
    not authz.allow with input as {"subject":{"tenant":"a"},"resource":{"tenant":"b"},"action":"read","approved":true}
}
test_missing_denied if { not authz.allow with input as {} }
test_write_denied if {
    not authz.allow with input as {"subject":{"tenant":"a"},"resource":{"tenant":"a"},"action":"write","approved":true}
}
