# Defensive test corpus with expected outcomes

Project: AI assistant authorization and injection testbed
Status: blank work product — not completed evidence

## Purpose and audience
Build a defensive testbed showing that untrusted content cannot grant access or authorize actions.

## Required content
Place authorization before retrieval and tool execution in the API. Keep model output separate from policy input and log decision IDs without sensitive content.

## Inputs and provenance
[Source IDs, dates, permissions, versions; distinguish synthetic from real.]

## Implementation / analysis
[Your work, screenshots or source links, and decisions with evidence IDs.]

## Validation
Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security.

## Failure evidence
Replay a valid action under a different tenant and place an instruction to bypass approval in a retrieved document. Both must fail at the deterministic enforcement point.

## Handover
[Owner, review date, residual gaps, reproduction instructions.]
