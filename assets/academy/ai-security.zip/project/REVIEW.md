# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Threat model and authorization implementation.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report attack coverage, denied/allowed confusion, false positives and residual risks. A passed corpus is not a claim of complete security.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
