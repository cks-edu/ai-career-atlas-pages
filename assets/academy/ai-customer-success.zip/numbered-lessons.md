# AI customer-success / implementation specialist — numbered lessons

Original labs, projects and source files remain in this pack. Complete setup before running commands. Quiz reference answers appear after each exercise.

## beginner

Prerequisite: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Terms:

Success plans: Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

### Success plans

Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit. In this role, work through: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Joining a gym, attending and improving fitness are different milestones.

Boundary: A success plan is an agreement, not evidence of achieved outcomes.

Worked example: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI customer-success / implementation specialist: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats.

Predict the worked case

Read this case without running a tool: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in success plans.

Connect the concept to the role

Apply this rule: Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: A success plan is an agreement, not evidence of achieved outcomes.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies success plans to this case: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-beginner-1.md: two-case decision worksheet for Success plans; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with success plans. Use the glossary below, then write your prediction for: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI customer-success / implementation specialist role interview. Explain success plans using this case: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate success plans to a system or workflow you know. Explain success plans using this case: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain success plans using this case: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats.

Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Reference: Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit. — Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit. A success plan is an agreement, not evidence of achieved outcomes.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

diagrams.net: https://www.drawio.com/docs/getting-started/

Google Technical Writing: https://developers.google.com/tech-writing

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

### Diagnose: Seat activation hides failed onboarding

The onboarding gate flags any account missing an approved data owner or support escalation contact. Three activated accounts lack required ownership and escalation readiness. The case separates an observed contract failure from an unproven root cause. In this role, work through: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Complete the success plan and resolve ownership before encouraging broader data use. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.

Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.

Role application: Joining a gym, attending and improving fitness are different milestones.

A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats.

Worked example: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Complete the success plan and resolve ownership before encouraging broader data use.

Setup: Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.

Tools for this exercise: Text editor or spreadsheet; optional case replay only

Course tool and framework map: LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed); diagrams.net (Open source editor · browser/desktop)

First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

The onboarding gate flags any account missing an approved data owner or support escalation contact. Three activated accounts lack required ownership and escalation readiness. The case separates an observed contract failure from an unproven root cause. Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The onboarding gate flags any account missing an approved data owner or support escalation contact. Apply this toy-case rule manually: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Preparation · Prepare your first worksheet

Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Customer success means helping a customer achieve a useful result. Tool activation is not the same as successful adoption.

Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

Preparation · Try step 1

Imagine a library team trialing an assistant for finding policy passages.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page success plan and a sample issue-triage reply.

Preparation · Try step 2

Define the user task, current baseline, training activity, reviewer and one measurable outcome.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page success plan and a sample issue-triage reply.

Preparation · Try step 3

Write a response to “The answer used an old rule” that captures the source/version and routes the issue to an owner.

Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page success plan and a sample issue-triage reply.

Preparation · Explain and check your result

The plan measures useful, checked answers; the reply does not promise a fix before the cause is understood. Compare your reasoning with the worked example in Learn, then add one new boundary case.

Expected: A one-page success plan and a sample issue-triage reply. Keep the first attempt and a note explaining one correction.

Diagnose a realistic failure

Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The onboarding gate flags any account missing an approved data owner or support escalation contact. Apply this toy-case rule manually: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.

Expected: Three activated accounts lack required ownership and escalation readiness. Compare with case/sample-deliverable.md only after your own attempt.

Expected: Three activated accounts lack required ownership and escalation readiness. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshoot: You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.

Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

Deliverable: lesson-beginner-2.md and case/learner-deliverable.md: record-by-record decisions using the declared case rule, evidence IDs, a repair proposal and a verification check. Keep beginner-worksheet.md as preparation evidence; do not claim the underlying system was tested by a document review.

new: Start with diagnose: seat activation hides failed onboarding. Use the glossary below, then write your prediction for: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Complete the success plan and resolve ownership before encouraging broader data use. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI customer-success / implementation specialist role interview. Explain diagnose: seat activation hides failed onboarding using this case: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Complete the success plan and resolve ownership before encouraging broader data use. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate diagnose: seat activation hides failed onboarding to a system or workflow you know. Explain diagnose: seat activation hides failed onboarding using this case: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Complete the success plan and resolve ownership before encouraging broader data use. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Run a sample support escalation and confirm the customer can identify allowed data. Explain why repairing the replay alone cannot establish the real system is fixed.

Interview: Explain diagnose: seat activation hides failed onboarding using this case: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Complete the success plan and resolve ownership before encouraging broader data use. State the evidence, one alternative and where the mental model stops.

Quiz: Seat activation hides failed onboarding: The onboarding gate flags any account missing an approved data owner or support escalation contact.

Change the acceptance rule after seeing an inconvenient result.

Complete the success plan and resolve ownership before encouraging broader data use.

Omit failed cases and report only the successful demonstrations.

Reference: Complete the success plan and resolve ownership before encouraging broader data use. — Complete the success plan and resolve ownership before encouraging broader data use. Run a sample support escalation and confirm the customer can identify allowed data.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

diagrams.net: https://www.drawio.com/docs/getting-started/

Google Technical Writing: https://developers.google.com/tech-writing

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

## intermediate

Prerequisite: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Customer communication, onboarding, issue triage and data-handling awareness; technical variants require integrations.

Terms:

Implementation readiness: Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Implementation readiness

Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff. In this role, work through: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A hotel checks keys, rooms and emergency contacts before guests arrive.

Boundary: Product access does not imply permission to use all customer data.

Worked example: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Customer communication, onboarding, issue triage and data-handling awareness; technical variants require integrations.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI customer-success / implementation specialist: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route.

Predict the worked case

Read this case without running a tool: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in implementation readiness.

Connect the concept to the role

Apply this rule: Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Product access does not imply permission to use all customer data.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies implementation readiness to this case: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-intermediate-1.md: two-case decision worksheet for Implementation readiness; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with implementation readiness. Use the glossary below, then write your prediction for: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI customer-success / implementation specialist role interview. Explain implementation readiness using this case: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate implementation readiness to a system or workflow you know. Explain implementation readiness using this case: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain implementation readiness using this case: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route.

Treat a passing starter as proof of the whole role workflow.

Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff.

Ignore the failure because the tool produced an output.

Reference: Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff. — Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff. Product access does not imply permission to use all customer data.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

diagrams.net: https://www.drawio.com/docs/getting-started/

Google Technical Writing: https://developers.google.com/tech-writing

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

### Integrate: AI customer implementation and recovery plan

Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register. In this role, work through: Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A connected chain is only useful when each handoff preserves the task contract.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A hotel checks keys, rooms and emergency contacts before guests arrive.

A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route.

Worked example: Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed); diagrams.net (Open source editor · browser/desktop)

Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Plan a fictional customer rollout with measurable success criteria and a clear path through incidents.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Verify the integrated result

Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.

Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

Review one failure before progressing

The onboarding gate flags any account missing an approved data owner or support escalation contact. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.

Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Expected: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-intermediate-2.md: Implementation plan and stakeholder map; Success dashboard and risk register. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with integrate: ai customer implementation and recovery plan. Use the glossary below, then write your prediction for: Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI customer-success / implementation specialist role interview. Explain integrate: ai customer implementation and recovery plan using this case: Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate integrate: ai customer implementation and recovery plan to a system or workflow you know. Explain integrate: ai customer implementation and recovery plan using this case: Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. Identify one observation that would contradict your claim.

Interview: Explain integrate: ai customer implementation and recovery plan using this case: Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI customer implementation and recovery plan at this level?

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.

Reference: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. — Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

diagrams.net: https://www.drawio.com/docs/getting-started/

Google Technical Writing: https://developers.google.com/tech-writing

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

## advanced

Prerequisite: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Terms:

Renewal evidence and escalation: Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts.

CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.

baseline: A simple reference method used to judge whether a more complex approach helps.

provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.

checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.

rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Renewal evidence and escalation

Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts. In this role, work through: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A service review includes repairs and missed commitments as well as mileage.

Boundary: Observed benefit should not be generalized to untested teams or regions.

Worked example: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date.

Setup: Use a document or a plain-text worksheet. No installation is needed for this concept rehearsal. Read the level prerequisite before the practical lesson: Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

Tools for this exercise: Document or text editor

Course tool and framework map: LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed); diagrams.net (Open source editor · browser/desktop)

Concept rehearsal — no runtime execution claimed.

Concept rehearsal for AI customer-success / implementation specialist: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date.

Predict the worked case

Read this case without running a tool: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date. Write the input, the decision and the expected result. Mark any missing evidence as unknown.

Expected: A prediction with a reason grounded in renewal evidence and escalation.

Connect the concept to the role

Apply this rule: Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts. Explain how it changes your decision in the case above.

Expected: Your explanation connects the rule to the case, rather than only naming a tool.

Challenge one assumption

Change one input or assumption in the case. Predict what changes and what stays true. Use this boundary when checking your reasoning: Observed benefit should not be generalized to untested teams or regions.

Expected: Two labeled cases (original and changed), with an explanation of the difference. This is a reasoning rehearsal, not a runtime test.

Check, then prepare the practical exercise

Compare your reasoning with the worked explanation and linked source. Correct one gap in your worksheet. Continue to the next numbered lesson for the role exercise.

Expected: A corrected worksheet with the source and one question you still need to resolve.

Expected: A short decision worksheet that applies renewal evidence and escalation to this case: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date. Keep predictions separate from observed runtime results.

Troubleshoot: I can repeat the definition but cannot apply it: Return to the specific case: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date. Name the input, decision, evidence and limit separately. Use the next lesson to test the practical behavior; the analogy alone is not evidence.

Cleanup: Save the worksheet; no services were started.

Deliverable: lesson-advanced-1.md: two-case decision worksheet for Renewal evidence and escalation; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with renewal evidence and escalation. Use the glossary below, then write your prediction for: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI customer-success / implementation specialist role interview. Explain renewal evidence and escalation using this case: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate renewal evidence and escalation to a system or workflow you know. Explain renewal evidence and escalation using this case: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

Interview: Explain renewal evidence and escalation using this case: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date. State the evidence, one alternative and where the mental model stops.

Quiz: In this worked case, which principle should guide your decision? Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date.

Treat a passing starter as proof of the whole role workflow.

Ignore the failure because the tool produced an output.

Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts.

Reference: Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts. — Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts. Observed benefit should not be generalized to untested teams or regions.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

diagrams.net: https://www.drawio.com/docs/getting-started/

Google Technical Writing: https://developers.google.com/tech-writing

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/

### Defend: AI customer implementation and recovery plan

Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Create support playbooks for incorrect output, access failure and degraded service. Rehearse a customer update that states impact, workaround, owner and next checkpoint. In this role, work through: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success. Use the worked example to explain the decision before inspecting the reference answer.

Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.

Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Role application: A service review includes repairs and missed commitments as well as mileage.

Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date.

Worked example: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.

Setup: Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.

Tools for this exercise: Use the tools and access stated in the setup above; the ordered steps identify each command or worksheet

Course tool and framework map: LibreOffice Calc (Open source · no account needed); LibreOffice Writer / Impress (Open source · no account needed); diagrams.net (Open source editor · browser/desktop)

Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

Plan a fictional customer rollout with measurable success criteria and a clear path through incidents.

Set up and run the starter

From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Prepare the project inputs

Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.

Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

Build the baseline workflow

Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

Implement the core capability

Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

Integrate and harden

Create support playbooks for incorrect output, access failure and degraded service. Rehearse a customer update that states impact, workaround, owner and next checkpoint.

Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

Run a controlled failure drill

Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.

Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

Evaluate and challenge the result

Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.

Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

Package and hand over

Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Expected: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A reviewer must reproduce one result and identify which capabilities you implemented. Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.

Troubleshoot: The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.

Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Deliverable: lesson-advanced-2.md: Implementation plan and stakeholder map; Success dashboard and risk register; Incident communication and renewal-readiness review. Include project/CASE-STUDY.md, editable files and an environment manifest.; include inputs, prediction, actual or simulated result, one correction, limitations and source links.

new: Start with defend: ai customer implementation and recovery plan. Use the glossary below, then write your prediction for: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success. Follow one numbered step at a time and keep unknown terms as questions.

seeker: Prepare evidence for the AI customer-success / implementation specialist role interview. Explain defend: ai customer implementation and recovery plan using this case: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success. State the evidence, one alternative and where the mental model stops. Keep a before/after example and link your actual artifact. Describe simulated exercises as learning projects, not employment experience.

switcher: Relate defend: ai customer implementation and recovery plan to a system or workflow you know. Explain defend: ai customer implementation and recovery plan using this case: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success. State the evidence, one alternative and where the mental model stops. Compare assumptions and tool boundaries before transferring an existing practice. Use synthetic data or an authorized sandbox, then record what would need validation at work.

Recall: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. Identify one observation that would contradict your claim.

Interview: Explain defend: ai customer implementation and recovery plan using this case: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success. State the evidence, one alternative and where the mental model stops.

Quiz: How should you validate AI customer implementation and recovery plan at this level?

Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.

Change the acceptance rule after seeing an inconvenient result.

Omit failed cases and report only the successful demonstrations.

Reference: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success. — Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success. Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.

Sources:

LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html

LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/

diagrams.net: https://www.drawio.com/docs/getting-started/

Google Technical Writing: https://developers.google.com/tech-writing

NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework

Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/
