# AI customer-success / implementation specialist

AI Engineering · Beginner → Intermediate → Advanced

Start with Success plans. Customer success means helping a customer achieve a useful result. Tool activation is not the same as successful adoption. Then try Create a customer success plan. The three levels build toward AI customer implementation and recovery plan. Existing guide checkpoints stay separate; course completion is self-reported.

Extract into a fresh directory. First worksheet: beginner-worksheet.md. Diagnostic sample: case/sample-deliverable.md. Real-tool starter and portfolio templates: project/. Never run a command from an unfamiliar working directory.

## beginner — Success plans

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Success plans
Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit.
Mental model: Joining a gym, attending and improving fitness are different milestones.
Boundary: A success plan is an agreement, not evidence of achieved outcomes.
Worked example: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Seat activation hides failed onboarding
The onboarding gate flags any account missing an approved data owner or support escalation contact. Three activated accounts lack required ownership and escalation readiness. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Complete the success plan and resolve ownership before encouraging broader data use.
Recall: Run a sample support escalation and confirm the customer can identify allowed data. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Success plans: Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Customer success means helping a customer achieve a useful result. Tool activation is not the same as successful adoption.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine a library team trialing an assistant for finding policy passages.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page success plan and a sample issue-triage reply.

3. Try step 2
Define the user task, current baseline, training activity, reviewer and one measurable outcome.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page success plan and a sample issue-triage reply.

4. Try step 3
Write a response to “The answer used an old rule” that captures the source/version and routes the issue to an owner.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page success plan and a sample issue-triage reply.

5. Explain and check your result
The plan measures useful, checked answers; the reply does not promise a fix before the cause is understood. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A one-page success plan and a sample issue-triage reply. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The onboarding gate flags any account missing an approved data owner or support escalation contact. Apply this toy-case rule manually: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three activated accounts lack required ownership and escalation readiness. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI customer-success / implementation specialist.
Imagine a library team trialing an assistant for finding policy passages.
Define the user task, current baseline, training activity, reviewer and one measurable outcome.
Write a response to “The answer used an old rule” that captures the source/version and routes the issue to an owner.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A one-page success plan and a sample issue-triage reply. Include beginner-worksheet.md and your completed Account success plan and escalation map.
Check: The plan measures useful, checked answers; the reply does not promise a fix before the cause is understood.

### Interview
Explain your beginner solution for AI customer-success / implementation specialist. Use this scenario: The onboarding gate flags any account missing an approved data owner or support escalation contact.
Review: Start with the task and permitted scope. Explain success plans: Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit. Show the input and observed output, then address Complete the success plan and resolve ownership before encouraging broader data use. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A one-page success plan and a sample issue-triage reply. Include beginner-worksheet.md and your completed Account success plan and escalation map.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## intermediate — Implementation readiness

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Customer communication, onboarding, issue triage and data-handling awareness; technical variants require integrations.

### Implementation readiness
Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff.
Mental model: A hotel checks keys, rooms and emergency contacts before guests arrive.
Boundary: Product access does not imply permission to use all customer data.
Worked example: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI customer implementation and recovery plan
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Recall: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. Identify one observation that would contradict your claim.

### Terms
Implementation readiness: Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The onboarding gate flags any account missing an approved data owner or support escalation contact. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents.
Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.
Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.
Deliverables: Implementation plan and stakeholder map; Success dashboard and risk register. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI customer-success / implementation specialist. Use this scenario: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Review: Start with the task and permitted scope. Explain implementation readiness: Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff. Show the input and observed output, then address Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Implementation plan and stakeholder map; Success dashboard and risk register. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## advanced — Renewal evidence and escalation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Renewal evidence and escalation
Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts.
Mental model: A service review includes repairs and missed commitments as well as mileage.
Boundary: Observed benefit should not be generalized to untested teams or regions.
Worked example: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI customer implementation and recovery plan
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Create support playbooks for incorrect output, access failure and degraded service. Rehearse a customer update that states impact, workaround, owner and next checkpoint.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Recall: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. Identify one observation that would contradict your claim.

### Terms
Renewal evidence and escalation: Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create support playbooks for incorrect output, access failure and degraded service. Rehearse a customer update that states impact, workaround, owner and next checkpoint.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents.
Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.
Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Create support playbooks for incorrect output, access failure and degraded service. Rehearse a customer update that states impact, workaround, owner and next checkpoint.
Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.
Run a consented internal pilot and document actual customer feedback separately from the demonstration.
Deliverables: Implementation plan and stakeholder map; Success dashboard and risk register; Incident communication and renewal-readiness review. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A reviewer must reproduce one result and identify which capabilities you implemented. Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.

### Interview
Explain your advanced solution for AI customer-success / implementation specialist. Use this scenario: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Review: Start with the task and permitted scope. Explain renewal evidence and escalation: Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts. Show the input and observed output, then address Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Implementation plan and stakeholder map; Success dashboard and risk register; Incident communication and renewal-readiness review. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

## Tools and alternatives
LibreOffice Calc — Open source · no account needed
Import CSV evidence, build review registers and calculate summaries.
Alternative: Microsoft Excel (commercial) or Google Sheets (hosted, plan-specific terms); CSV is portable but formulas and privacy settings differ.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

LibreOffice Writer / Impress — Open source · no account needed
Edit reports, workshop decks and export PDF deliverables.
Alternative: Microsoft Word/PowerPoint (commercial) or Google Docs/Slides (hosted); retain editable and accessible exports.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

diagrams.net — Open source editor · browser/desktop
Architecture diagrams, process maps and trust boundaries.
Alternative: Mermaid (open source) for text diagrams or Microsoft Visio (commercial); choose an editable format teammates can use.
No programming or paid account is required for the first worksheet. Use the documented local option where available. Hosted services, licenses, model downloads and hardware can have separate costs; check current terms before provisioning.

## Official sources
LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html
LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/
diagrams.net: https://www.drawio.com/docs/getting-started/
Google Technical Writing: https://developers.google.com/tech-writing
NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/
