## beginner — Success plans

Start with files and evidence foundations. The first exercise uses fictional examples and needs no code. Full professional scope may require the skills listed under Starting point.

### Success plans
Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit.
Mental model: Joining a gym, attending and improving fitness are different milestones.
Boundary: A success plan is an agreement, not evidence of achieved outcomes.
Worked example: A customer has enabled the assistant but has not verified one real workflow; schedule a bounded task review before expanding seats.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Diagnose: Seat activation hides failed onboarding
The onboarding gate flags any account missing an approved data owner or support escalation contact. Three activated accounts lack required ownership and escalation readiness. The case separates an observed contract failure from an unproven root cause.
Mental model: Inspect a labeled inspection sheet: each record must be judged against the stated rule, not against the preferred outcome.
Boundary: This numeric replay teaches evidence review. It does not run the underlying model, hardware or organizational process.
Worked example: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Complete the success plan and resolve ownership before encouraging broader data use.
Recall: Run a sample support escalation and confirm the customer can identify allowed data. Explain why repairing the replay alone cannot establish the real system is fixed.

### Terms
Success plans: Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.

### Lab
Use a text editor or spreadsheet. Keep the sample answer closed until you have drafted your own result. The optional Python case replay is explained inside case/README.md and is not required.
First role-specific exercise and a synthetic diagnostic case. No coding, model download, paid account or cloud resource is required.

1. Prepare your first worksheet
Extract the course pack. Open beginner-worksheet.md in a text editor or use a blank document. Read the two starting ideas: Customer success means helping a customer achieve a useful result. Tool activation is not the same as successful adoption.
Expected: A worksheet naming your goal, what you already know and the terms you need to look up.

2. Try step 1
Imagine a library team trialing an assistant for finding policy passages.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page success plan and a sample issue-triage reply.

3. Try step 2
Define the user task, current baseline, training activity, reviewer and one measurable outcome.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page success plan and a sample issue-triage reply.

4. Try step 3
Write a response to “The answer used an old rule” that captures the source/version and routes the issue to an owner.
Expected: Record the input, your reasoning and the resulting part of this deliverable: A one-page success plan and a sample issue-triage reply.

5. Explain and check your result
The plan measures useful, checked answers; the reply does not promise a fix before the cause is understood. Compare your reasoning with the worked example in Learn, then add one new boundary case.
Expected: A one-page success plan and a sample issue-triage reply. Keep the first attempt and a note explaining one correction.

6. Diagnose a realistic failure
Open case/learner-deliverable.md and case/evidence.csv. Read this scenario: The onboarding gate flags any account missing an approved data owner or support escalation contact. Apply this toy-case rule manually: Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard. Do not edit the evidence to match your answer.
Expected: Three activated accounts lack required ownership and escalation readiness. Compare with case/sample-deliverable.md only after your own attempt.

Troubleshooting:
The terminology is unfamiliar: Read Words you will meet and the linked first resource. Use the worked example to identify an input, a decision and an output before adding more tools.
Your decision differs from the sample: Compare record IDs, units and the exact boundary in the case rule. The threshold is a classroom contract, not an industry standard.
You cannot determine the answer: Record unknown and what evidence is missing. Do not invent an observation or professional judgment.
Cleanup: Save your worksheet and a copy of the original evidence. No running services or paid resources are created.

### Portfolio
Create a clear explanation of this first task for someone new to AI customer-success / implementation specialist.
Imagine a library team trialing an assistant for finding policy passages.
Define the user task, current baseline, training activity, reviewer and one measurable outcome.
Write a response to “The answer used an old rule” that captures the source/version and routes the issue to an owner.
Add one normal and one ambiguous example of your own, explain how you handled each, and record what remains unknown.
Deliverables: A one-page success plan and a sample issue-triage reply. Include beginner-worksheet.md and your completed Account success plan and escalation map.
Check: The plan measures useful, checked answers; the reply does not promise a fix before the cause is understood.

### Interview
Explain your beginner solution for AI customer-success / implementation specialist. Use this scenario: The onboarding gate flags any account missing an approved data owner or support escalation contact.
Review: Start with the task and permitted scope. Explain success plans: Translate a customer's desired outcome into tasks, owners and checkpoints. Distinguish activation, adoption and demonstrated benefit. Show the input and observed output, then address Complete the success plan and resolve ownership before encouraging broader data use. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [A one-page success plan and a sample issue-triage reply. Include beginner-worksheet.md and your completed Account success plan and escalation map.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

