# SAMPLE — Account success plan and escalation map
Role: AI customer-success / implementation specialist
Case: Seat activation hides failed onboarding
Status: Educational example using five synthetic records; not real deployment or user-study evidence.

## Decision and scope
Hold the affected cases for review. Continue only cases within this one demonstration bound; that label does not establish full system quality or safety.
The onboarding gate flags any account missing an approved data owner or support escalation contact.

## Evidence table
| Record | missing_onboarding_owners (count) | Decision |
|---|---:|---|
| case-1 | 0 | within_demo_bound |
| case-2 | 1 | review |
| case-3 | 0 | within_demo_bound |
| case-4 | 2 | review |
| case-5 | 1 | review |

## Finding and reasoning
3/5 cases need review: case-2, case-4, case-5.
Three activated accounts lack required ownership and escalation readiness.
The initial demo rule hides these violations. The evidence identifies a contract failure; it does not establish every underlying causal mechanism.

## Proposed action
Complete the success plan and resolve ownership before encouraging broader data use.
Owner (fictional): pilot lead; reviewer: a practitioner qualified in ai customer-success / implementation specialist.
Before release: Run a sample support escalation and confirm the customer can identify allowed data.

## Design choice and trade-off
Connect adoption to customer outcomes; separate training gaps from product defects.
High activity without task value or support readiness is not a reliable renewal signal.

## Acceptance and reopening conditions
Re-run all five records and values immediately below, at and above the boundary. Any expected review case that passes reopens the finding. Inspect a fresh representative sample before a real decision; do not generalize from these five records.

## Next deliverable
AI customer onboarding pack: Account owners and product limits are clear.
Keep original evidence, revised rule, replay output and this decision record together. A report alone is not evidence that the proposed operational repair was implemented.
