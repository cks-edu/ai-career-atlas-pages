# AI customer-success / implementation specialist — Seat activation hides failed onboarding

Local synthetic evidence-and-decision lab. The Python replay tests a numeric contract; it does not call a model, run a GPU workload, deploy cloud infrastructure or validate a real business decision.

## Brief
The onboarding gate flags any account missing an approved data owner or support escalation contact.

## Contract
Review when missing_onboarding_owners >= 1 (count). This is a declared toy-case contract, not an industry standard.

## Setup
Extract this ZIP into a new empty folder. Open a terminal there for the optional Python replay. On macOS/Linux use python3; on Windows use py -3 instead. Python 3.9+; standard library only. No installation commands or paid resources. Spreadsheet/browser learners can complete the same table and memo without Python.

## 1. Set up and define the contract
Read the brief and account success plan and escalation map template. Restate the acceptance rule in your own words, including its units. Use this browser, a text editor or any spreadsheet. No coding or paid account is required. Download the pack if you want to work offline in a spreadsheet.

Exit check: You can distinguish the case contract from a general industry rule.

## 2. Inspect the evidence before checking the answer
Read evidence.csv. Make a five-row decision table using missing_onboarding_owners in count. Mark each record as review or within_demo_bound. Explain what a value exactly on the threshold means.

Exit check: All five records have a decision and an evidence-based reason; keep this first attempt.

## 3. Reproduce and repair the broken review rule
The supplied rule uses 3 and misses the case failures. Use the threshold and comparison controls, or edit policy.json locally, to match the stated contract. Do not edit the evidence or answer contract to make a test pass. Complete the success plan and resolve ownership before encouraging broader data use. The threshold edit repairs only this replay, not the underlying system.

Exit check: Run Check policy. The fixture and boundary cases must agree with the contract.

## 4. Write the role-specific deliverable
Complete the draft template as account success plan and escalation map. Cite record IDs, state your decision, name a fictional accountable owner and distinguish observations from causal hypotheses. Address this trade-off: High activity without task value or support readiness is not a reliable renewal signal.

Exit check: A reviewer can trace the recommendation to evidence and identify who must act.

## 5. Rehearse verification and challenge an assumption
Run a sample support escalation and confirm the customer can identify allowed data. Add one new example on each side of the boundary and one exactly at it. Explain how missing or unreliable evidence should be handled. For this lab, an absent numeric field is an error, not an automatic pass.

Exit check: Document expected results, one rejected alternative and a condition that reopens the finding.

## 6. Compare, revise and present
Reveal the sample only after drafting. Compare the evidence table, decision, trade-off and limitations; revise your own artifact rather than copying it. Present a two-minute explanation. Then extend the work toward: AI customer onboarding pack — Define a fictional account.

Exit check: Export your notes and compare with a peer. Self-checkmarks do not certify the written deliverable.

## Expected execution
The original policy deliberately reports zero reviews; verify.py exits nonzero on the fixture and boundary checks. After repair, the report lists 3 review cases and all four tests pass. The report prints to standard output and does not overwrite your files.

## Troubleshooting
- Missing file: open the terminal in the extracted pack directory.
- Python missing: use the in-browser exercise; install Python only from its official distribution if you choose the local route.
- JSON error: use double quotes, numeric threshold and no trailing comma.
- Fixture passes but boundary fails: distinguish > from >= and keep the stated units.
- Missing evidence: reject the malformed record for review; do not silently treat missing as zero.

## Files and answer disclosure
policy.json is the intentionally broken rule; contract.json contains the check oracle. sample-deliverable.md is the worked answer. Keep them closed until you have made an attempt. learner-deliverable.md is your editable template. In-browser notes are separate from these local files.

## Sources
- Google Technical Writing: https://developers.google.com/tech-writing
- NIST AI Risk Management Framework: https://www.nist.gov/itl/ai-risk-management-framework
- Microsoft Power Automate: https://learn.microsoft.com/en-us/power-automate/
