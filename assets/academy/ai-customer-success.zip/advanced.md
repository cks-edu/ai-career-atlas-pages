## advanced — Renewal evidence and escalation

Complete the intermediate artifact and reproduce its checks. Advanced here means a deeper course exercise; specialized research and domain roles may require further education, experience or credentials.

### Renewal evidence and escalation
Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts.
Mental model: A service review includes repairs and missed commitments as well as mileage.
Boundary: Observed benefit should not be generalized to untested teams or regions.
Worked example: Report improved task completion for one team and an unresolved accuracy issue for another, with an owner and review date.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Defend: AI customer implementation and recovery plan
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Create support playbooks for incorrect output, access failure and degraded service. Rehearse a customer update that states impact, workaround, owner and next checkpoint.
Mental model: A rehearsal deliberately interrupts the performance so the team can demonstrate recovery.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Recall: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. Identify one observation that would contradict your claim.

### Terms
Renewal evidence and escalation: Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
checkpoint: Saved state used to resume or inspect a run; a training checkpoint may need optimizer and data-position state as well as model weights.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Integrate and harden
Create support playbooks for incorrect output, access failure and degraded service. Rehearse a customer update that states impact, workaround, owner and next checkpoint.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

6. Run a controlled failure drill
Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Expected: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

7. Evaluate and challenge the result
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.
Expected: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.
Expected: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents.
Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.
Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Create support playbooks for incorrect output, access failure and degraded service. Rehearse a customer update that states impact, workaround, owner and next checkpoint.
Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.
Run a consented internal pilot and document actual customer feedback separately from the demonstration.
Deliverables: Implementation plan and stakeholder map; Success dashboard and risk register; Incident communication and renewal-readiness review. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A reviewer must reproduce one result and identify which capabilities you implemented. Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.

### Interview
Explain your advanced solution for AI customer-success / implementation specialist. Use this scenario: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Review: Start with the task and permitted scope. Explain renewal evidence and escalation: Summarize achieved outcomes, unresolved issues and next actions using agreed measures. Escalate quality or safety failures rather than hiding them behind usage charts. Show the input and observed output, then address Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Implementation plan and stakeholder map; Success dashboard and risk register; Incident communication and renewal-readiness review. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

