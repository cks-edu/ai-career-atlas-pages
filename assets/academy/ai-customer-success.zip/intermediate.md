## intermediate — Implementation readiness

Complete the first exercise and explain its limits. Before tool setup, build these prerequisites: Customer communication, onboarding, issue triage and data-handling awareness; technical variants require integrations.

### Implementation readiness
Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff.
Mental model: A hotel checks keys, rooms and emergency contacts before guests arrive.
Boundary: Product access does not imply permission to use all customer data.
Worked example: A connector fails during onboarding; identify the owner, preserve the error and show the customer a supported manual route.
Recall: Explain the worked example in your own words. Change one input or assumption and predict how the result changes. State where this mental model stops being reliable.

### Integrate: AI customer implementation and recovery plan
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Mental model: A connected chain is only useful when each handoff preserves the task contract.
Boundary: Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.
Worked example: Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Recall: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. Identify one observation that would contradict your claim.

### Terms
Implementation readiness: Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff.
CSV: A table stored as text with separated columns. Import with the stated delimiter and keep identifiers from being converted accidentally.
baseline: A simple reference method used to judge whether a more complex approach helps.
provenance: Recorded origin and history; it does not by itself prove truth or permission to use an asset.
rollout: Introducing a new version in a controlled way and checking whether it behaves as intended.

### Lab
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor. All runtime files are in project/. Beginner case files are separate in case/. No Python is required for this workbook route.
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents. Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account. Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

1. Set up and run the starter
From the extracted course root, open the project/ directory. For commands below, start a fresh terminal in the course root; cd project is shown explicitly. If continuing an existing environment, do not nest another project directory. Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.
Expected: Record tool versions and baseline output. Identify exactly what the starter does and does not implement. Starter scope: Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

2. Prepare the project inputs
Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Expected: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

3. Build the baseline workflow
Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

4. Implement the core capability
Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Expected: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

5. Verify the integrated result
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. At this level, evaluate only the baseline and capability you actually built. Keep later hardening tasks marked planned.
Expected: A versioned evidence table linked to artifact-1.md and artifact-2.md; failed and uncertain cases remain visible.

6. Review one failure before progressing
The onboarding gate flags any account missing an approved data owner or support escalation contact. Use case/sample-deliverable.md as a diagnostic example, then explain whether the same issue exists in your implementation.
Expected: One observed or explicitly simulated failure, a proposed repair and a regression check. Do not claim the sample proves your implementation.

Troubleshooting:
CSV appears in one column: select comma as the separator during import.
Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.
The starter runs but the role project is unfinished: The supplied code demonstrates a bounded foundation. Complete the role-specific build steps, add your own tests and produce the named artifacts before marking completion.
Cleanup: Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

### Portfolio
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents.
Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.
Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.
Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.
Deliverables: Implementation plan and stakeholder map; Success dashboard and risk register. Include project/CASE-STUDY.md, editable files and an environment manifest.
Check: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A reviewer must reproduce one result and identify which capabilities you implemented. The full failure drill follows at advanced level.

### Interview
Explain your intermediate solution for AI customer-success / implementation specialist. Use this scenario: Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.
Review: Start with the task and permitted scope. Explain implementation readiness: Verify data access, configuration, training and support responsibilities before rollout. Rehearse a failed integration and a support handoff. Show the input and observed output, then address Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results. A strong answer identifies an alternative, a failure boundary, an accountable reviewer and what remains untested.

### Resume
Describe this as a learning project. Name the artifact, tools you actually used and evidence you collected. Do not claim production deployment, customer research or business impact from templates or simulated observations.
Created [Implementation plan and stakeholder map; Success dashboard and risk register. Include project/CASE-STUDY.md, editable files and an environment manifest.] for [synthetic or consented scope], used [actual tools], evaluated [observed result and sample size], and documented [failure and limitation]. Portfolio: [link].

