# AI customer implementation and recovery plan

> Portfolio template — fill with your own observed evidence. No completed client engagement or production outcome is implied.

## Problem and audience
Plan a fictional customer rollout with measurable success criteria and a clear path through incidents.

## My contribution and scope
[What you built; what came from the starter; collaborators; simulated versus real.]

## Decisions and alternatives
[Link decision-log.csv and explain one rejected option.]

## Architecture or process
[Include your diagram, ownership and failure boundaries.]

## Demonstration
[Link a 3–5 minute demo and editable/source artifacts.]

## Results
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.

[Insert measured values, sample sizes, uncertainty and raw evidence links; leave unrun work explicitly unrun.]

## Failure and recovery
Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.

## Limitations and next iteration
Run a consented internal pilot and document actual customer feedback separately from the demonstration.

## Reproduction
[Environment, versions, data provenance, commands or UI steps, costs and cleanup.]
