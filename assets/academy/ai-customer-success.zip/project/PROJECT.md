# AI customer implementation and recovery plan

Career: AI customer-success / implementation specialist
Reviewed: 2026-10-22

Plan a fictional customer rollout with measurable success criteria and a clear path through incidents.

## Prerequisites
Customer communication, onboarding, issue triage and data-handling awareness; technical variants require integrations.

## Included starter versus your implementation
Role-specific brief, three deliverable templates, evidence/decision registers, review matrix and a portfolio case-study template. A complete local spreadsheet/document route needs no programming or paid account.

Use the listed local tools where possible. Hosted design, automation or media services may require accounts/credits. Recruiting qualified reviewers is separate work; label solo rehearsals as simulations.

These are advanced project instructions and starter assets, not a completed production deployment. Complete the milestones and collect your own evidence before presenting the work as finished. Allow several focused sessions plus prerequisite study; no job-readiness deadline is implied.

## Setup notes
Run commands in the extracted project folder. Shell examples use Bash/zsh. On Windows use WSL for Linux-specific tools or replace venv commands with `py -3 -m venv .venv` and `.venv\Scripts\Activate.ps1` in PowerShell. Do not disable execution policy; use the environment's Python executable directly if activation is blocked. Dependency ranges are starter constraints, not a universal lockfile. After a successful setup, save `python -m pip freeze > environment-lock.txt` and record OS/tool versions.

## 1. Set up and run the starter
Download and extract the pack. Open evidence-register.csv in LibreOffice Calc using UTF-8, comma separation and a header row. Save an .ods working copy; open artifact templates in Writer or a text editor.

Exit evidence: Record tool versions and baseline output. Identify exactly what the starter does and does not implement.

## 2. Prepare the project inputs
Define a fictional customer, three user groups and an initial workflow. Record baseline task performance, stakeholders, access needs and success criteria.

Exit evidence: Inputs have stable IDs, provenance and a declared scope; record assumptions before collecting results.

## 3. Build the baseline workflow
Create an onboarding plan with milestones, owners and evidence of readiness. Include data setup, training, evaluation and support handoff.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-1.md.

## 4. Implement the core capability
Build a success dashboard distinguishing usage, task outcome, quality failures and business assumptions. Write a weekly review agenda and risk register.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-2.md.

## 5. Integrate and harden
Create support playbooks for incorrect output, access failure and degraded service. Rehearse a customer update that states impact, workaround, owner and next checkpoint.

Exit evidence: Save the changed work product, reproduction steps and evidence of this milestone in artifact-3.md.

## 6. Run a controlled failure drill
Usage rises while a critical task fails repeatedly. Escalate the quality issue, revise rollout scope and explain why adoption alone is not success.

Exit evidence: Capture trigger, observed failure, diagnosis, recovery and a regression check. Label any unexecuted drill as planned.

## 7. Evaluate and challenge the result
Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.

Exit evidence: Keep raw evidence, sample counts and limitations; have a reviewer inspect at least one counterexample.

## 8. Package and hand over
Complete the three named artifacts, CASE-STUDY.md and REVIEW.md. Include editable files, a 3–5 minute demonstration, source references and your individual contribution. Export a PDF report and CSV evidence plus native editable files. Remove private participant information before sharing; retain only consented/public assets.

Exit evidence: A reviewer can find the problem, inspect the work, reproduce one result and identify the remaining limits.

## Portfolio deliverables
1. Implementation plan and stakeholder map — artifact-1.md
2. Success dashboard and risk register — artifact-2.md
3. Incident communication and renewal-readiness review — artifact-3.md

## Troubleshooting
- CSV appears in one column: select comma as the separator during import.
- Claims lack evidence: link each recommendation to an evidence ID and record uncertainty.
- No participants available: perform a labeled walkthrough and write a recruitment plan; do not invent interviews.

## Extension
Run a consented internal pilot and document actual customer feedback separately from the demonstration.

## Primary learning resources
- LibreOffice Calc: https://help.libreoffice.org/latest/en-US/text/scalc/guide/csv_files.html — Open source · no account needed; Import CSV evidence, build review registers and calculate summaries.
- LibreOffice Writer / Impress: https://documentation.libreoffice.org/en/english-documentation/ — Open source · no account needed; Edit reports, workshop decks and export PDF deliverables.
- diagrams.net: https://www.drawio.com/docs/getting-started/ — Open source editor · browser/desktop; Architecture diagrams, process maps and trust boundaries.

The project design, milestones and acceptance criteria are editorial recommendations. Sources document tools and methods, not an endorsement or proof of job demand. Live services, GPU runs, user studies and cloud deployments require separate execution and evidence.
