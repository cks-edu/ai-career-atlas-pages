# Reviewer walkthrough

1. Read the problem and scope; identify simulated inputs.
2. Inspect Implementation plan and stakeholder map.
3. Trace one decision to the evidence register.
4. Reproduce the failure drill and inspect recovery evidence.
5. Challenge the evaluation: Report milestone completion with evidence, time to unblock and task outcomes. Label simulated customer data and never invent retention or revenue results.
6. Record one blocking issue and one improvement.

## Feedback
Reviewer/date:
Evidence inspected:
Reproduction result:
Unresolved gaps:
