# Cross-platform Mobile Developer

Software Engineering

Start with widgets and state transitions. Complete the foundation setup, then the numbered role workshop. Keep your predictions, changed artifact and observed result. Each level builds toward cross-platform evidence matrix and release checklist.

## beginner

Create the Flutter sample, replace the counter with a task form, validate blanks and display keyed rows. Run flutter test with a widget test that taps Add and finds the title.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### UI state
The visible interface is a projection of state. User actions update state and trigger a new view.
Mental model: A scoreboard reflects the current score rather than owning the game rules.
Limit: Rendering frameworks differ; re-rendering does not automatically persist data.
Example: Adding one task changes count from zero to one.
Recall: Which state must survive app restart?

### Widgets and state transitions
Flutter rebuilds widgets from state. Keep the event that changes state distinct from build(), and use keys when a list item's identity must survive reordering.
Mental model: A blueprint is redrawn when the room changes; drawing it must not move the furniture.
Limit: Mutating the list inside build can duplicate work; update it only through an action.
Example: Adding A and B then reordering must preserve each item's completion state.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Mutating the list inside build can duplicate work; update it only through an action.

1. Start the native template
Run the Flutter scaffold and open lib/main.dart. Start with the generated counter before changing state.
```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter run
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
Adding A and B then reordering must preserve each item's completion state. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Create the Flutter sample, replace the counter with a task form, validate blanks and display keyed rows. Run flutter test with a widget test that taps Add and finds the title.
```
flutter test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Exactly one row per valid add and stable state when order changes.

6. Role workshop · debug and verify
Mutating the list inside build can duplicate work; update it only through an action. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save widget implementation and widget tests. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Exactly one row per valid add and stable state when order changes.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Widgets and state transitions: Mutating the list inside build can duplicate work; update it only through an action.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: widget implementation and widget tests
Exactly one row per valid add and stable state when order changes.

Interview: Work through this Cross-platform Mobile Developer case: Adding A and B then reordering must preserve each item's completion state. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Flutter rebuilds widgets from state. Keep the event that changes state distinct from build(), and use keys when a list item's identity must survive reordering. Expected evidence: Exactly one row per valid add and stable state when order changes. Diagnosis: Mutating the list inside build can duplicate work; update it only through an action. State the limits of the mental model: A blueprint is redrawn when the room changes; drawing it must not move the furniture.

Resume: Built widget implementation and widget tests using Flutter and Dart; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## intermediate

Define a repository interface, add a platform-supported persistence implementation and a failing fake. Test restart on one target and use the fake to verify the error UI.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Local persistence and offline work
Save data explicitly and show whether it is local, queued or synchronized.
Mental model: An outbox keeps letters until the courier is available.
Limit: Local storage can be removed or unavailable; it is not cloud backup.
Example: Create a task offline, restart and verify it remains marked unsent.
Recall: Why must the user see a queued status?

### Offline persistence adapter
Separate the widget tree from the local store so a fake can test loading and failure. Surface an unsaved state instead of claiming persistence before the write completes.
Mental model: The screen is a display connected to a filing service that can fail.
Limit: Hot reload is not a restart test; close and reopen the app process.
Example: A failed save leaves the draft visible and marked unsaved.
Recall: Explain the expected result before running the exercise, then diagnose this failure: Hot reload is not a restart test; close and reopen the app process.

1. Start the native template
Run the Flutter scaffold and open lib/main.dart. Start with the generated counter before changing state.
```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter run
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
A failed save leaves the draft visible and marked unsaved. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Define a repository interface, add a platform-supported persistence implementation and a failing fake. Test restart on one target and use the fake to verify the error UI.
```
flutter test
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: Saved items survive restart; failed writes never show a saved badge.

6. Role workshop · debug and verify
Hot reload is not a restart test; close and reopen the app process. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save repository interface, restart log and failure widget test. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: Saved items survive restart; failed writes never show a saved badge.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Offline persistence adapter: Hot reload is not a restart test; close and reopen the app process.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: repository interface, restart log and failure widget test
Saved items survive restart; failed writes never show a saved badge.

Interview: Work through this Cross-platform Mobile Developer case: A failed save leaves the draft visible and marked unsaved. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: Separate the widget tree from the local store so a fake can test loading and failure. Surface an unsaved state instead of claiming persistence before the write completes. Expected evidence: Saved items survive restart; failed writes never show a saved badge. Diagnosis: Hot reload is not a restart test; close and reopen the app process. State the limits of the mental model: The screen is a display connected to a filing service that can fail.

Resume: Built repository interface, restart log and failure widget test using Flutter and Dart; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## advanced

Run the task flow on two supported sizes or platforms, interrupt sync and repeat a queued operation. Record screenshots, target SDK versions and failure outcomes before preparing a release checklist.

Setup: Use the official platform setup linked below. Android Studio needs emulator-capable hardware; Xcode requires a supported Mac; Flutter requires SDK and platform dependencies. The pack is an acceptance workbook, not a prebuilt signed app. The role workshop may use a different native toolchain from the shared foundation. Install the course’s named language/platform from its official source before that step; run native commands inside the project you create, not inside an unrelated foundation folder. Follow the authored build task before running its verification command.

### Lifecycle and synchronization
Applications can pause or stop between operations. Retry with stable identifiers and resolve conflicting edits deliberately.
Mental model: A bookmark preserves your place when a reading session is interrupted.
Limit: A bookmark cannot decide how to merge two different edits.
Example: Retry the same task ID after reconnecting and verify one remote record.
Recall: What happens if two devices change the same title offline?

### Cross-platform release evidence
A shared codebase still encounters different text sizes, navigation and platform APIs. Test the same acceptance contract on each intended platform and name untested targets.
Mental model: One recipe may need different ovens; the result must still be checked in each.
Limit: A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity.
Example: Long titles and large system text must not hide the Add action on a small screen.
Recall: Explain the expected result before running the exercise, then diagnose this failure: A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity.

1. Start the native template
Run the Flutter scaffold and open lib/main.dart. Start with the generated counter before changing state.
```
flutter doctor
flutter create atlas_tasks
cd atlas_tasks
flutter run
```
Run from the extracted lab folder. This command executes the supplied reference exercise.
Expected: The official template launches on the selected emulator or desktop. Record SDK and OS versions.

2. Build a small task screen
Add a text field, an Add button and a visible task list. Start with in-memory state. Give every control a readable label.
Expected: Adding a nonempty task changes the count from 0 to 1; blank input shows an error.

3. Exercise lifecycle boundaries
Beginner: rotate or resize the window. Intermediate: restart after saving a task. Advanced: interrupt and repeat synchronization with the same task identifier.
Expected: Document what survives, what resets and whether duplicate tasks appear. Do not assume behavior without observing it.

4. Role workshop · predict
Long titles and large system text must not hide the Add action on a small screen. Write the expected behavior and identify the code/configuration or decision artifact you will change. Open role-workshop.md for the same brief offline.
Expected: A prediction tied to the business or technical contract, before implementation.

5. Role workshop · build
Run the task flow on two supported sizes or platforms, interrupt sync and repeat a queued operation. Record screenshots, target SDK versions and failure outcomes before preparing a release checklist.
```
flutter devices
```
Run from the extracted pack or the native project directory named in the task. These checks supplement the role-specific assertions you add; the shared baseline alone does not prove your extension works.
Expected: No clipped essential controls; duplicate retry creates one effect in the test service.

6. Role workshop · debug and verify
A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity. Reproduce one failure safely in the lab, preserve its evidence, repair it and repeat the original case.
Expected: A failing observation followed by a repaired result. Add role-specific assertions; do not count an unchanged reference test as validation of new code.

7. Role workshop · package the evidence
Save cross-platform evidence matrix and release checklist. Include source changes, inputs, expected/observed results, environment versions and remaining limitations. Compare against the model answer after writing your own explanation.
Expected: No clipped essential controls; duplicate retry creates one effect in the test service.

Troubleshooting:
Emulator or build tools unavailable: Run the platform setup checks. Use an officially supported environment; record the exercise as not yet executed rather than inventing a pass.
State disappears after restart: In-memory UI state is temporary. Add platform persistence at intermediate level and test it explicitly.
Duplicate synchronized tasks: Reuse a stable identifier across retries and enforce uniqueness at the receiving store.
Cross-platform release evidence: A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity.
Cleanup: Stop the emulator/app and remove only your sample project if desired. Do not publish to a store or enroll in a paid program for this exercise.

Portfolio: cross-platform evidence matrix and release checklist
No clipped essential controls; duplicate retry creates one effect in the test service.

Interview: Work through this Cross-platform Mobile Developer case: Long titles and large system text must not hide the Add action on a small screen. Explain implementation, failure diagnosis and recovery.
Review criteria: A strong answer explains: A shared codebase still encounters different text sizes, navigation and platform APIs. Test the same acceptance contract on each intended platform and name untested targets. Expected evidence: No clipped essential controls; duplicate retry creates one effect in the test service. Diagnosis: A plugin that works on mobile may lack desktop support; inspect its supported platforms before promising parity. State the limits of the mental model: One recipe may need different ovens; the result must still be checked in each.

Resume: Built cross-platform evidence matrix and release checklist using Flutter and Dart; verified [your actual observed result] with [test cases/evidence]. Scope: [local simulation / authorized platform], limitations: [what you did not execute].

## Official sources
Flutter learning pathway: https://docs.flutter.dev/learn
Android Basics with Compose: https://developer.android.com/courses/android-basics-compose/course
Apple: SwiftUI tutorials: https://developer.apple.com/tutorials/swiftui
